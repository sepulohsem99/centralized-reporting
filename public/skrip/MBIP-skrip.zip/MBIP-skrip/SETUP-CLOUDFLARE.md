# Setup — GitHub privat + Cloudflare Pages + Access

Panduan sekali sahaja untuk menaikkan Pipeline Testing Dashboard ke URL
live yang hanya boleh dibuka oleh ahli team yang kau benarkan.

Anggaran masa: 20–30 minit.

---

## Kenapa Cloudflare Access, bukan borang login

Dashboard ini fail HTML statik. Kalau borang login dibina ke dalam fail
itu, kata laluan dan seluruh kandungan tetap dihantar ke browser sebelum
borang muncul — sesiapa boleh tekan **View Source** atau jalankan `curl`
pada URL tu dan baca semuanya tanpa login.

Cloudflare Access berbeza: ia menyekat permintaan **di tepi rangkaian
Cloudflare**, sebelum sebarang bait kandungan dihantar. Orang yang tiada
kebenaran tidak akan menerima HTML itu langsung.

Percuma sehingga 50 pengguna.

---

## Bahagian 1 — Repo GitHub privat

1. Buka <https://github.com/new>
2. Nama repo: `mbip-pipeline-dashboard` (atau apa-apa)
3. **Pilih Private.** Ini wajib — repo mengandungi kredential PBT.
4. Jangan tandakan "Add a README"
5. Klik **Create repository**

Kemudian, dalam Command Prompt di dalam folder `v3`:

```
git init
git add -A
git commit -m "Pipeline Testing Dashboard"
git branch -M main
git remote add origin https://github.com/NAMA-ANDA/mbip-pipeline-dashboard.git
git push -u origin main
```

Kalau `git push` minta kata laluan: GitHub tidak lagi menerima kata
laluan akaun. Jana **Personal Access Token** di
Settings → Developer settings → Personal access tokens → Tokens (classic),
beri skop `repo`, dan guna token itu sebagai kata laluan.

---

## Bahagian 2 — Cloudflare Pages

1. Buka <https://dash.cloudflare.com> → **Workers & Pages** → **Create**
   → tab **Pages** → **Connect to Git**
2. Benarkan Cloudflare mengakses repo GitHub tadi
3. Pilih repo tu, klik **Begin setup**
4. Tetapan binaan — **penting, jangan biarkan default**:

   | Medan | Nilai |
   |---|---|
   | Framework preset | `None` |
   | Build command | *(biarkan kosong)* |
   | Build output directory | `public` |
   | Root directory | *(kosong, atau laluan ke folder `v3` kalau repo lebih besar)* |

5. Klik **Save and Deploy**

Selepas kira-kira seminit kau akan dapat URL seperti
`mbip-pipeline-dashboard.pages.dev`.

> Pada tahap ini URL tu **terbuka kepada sesiapa** yang tahu alamatnya.
> Jangan kongsi lagi. Teruskan ke Bahagian 3.

---

## Bahagian 3 — Cloudflare Access (kunci akses)

1. Dalam dashboard Cloudflare → **Zero Trust** (menu kiri)
2. Kali pertama sahaja: pilih nama team dan pilih pelan **Free**
3. **Access** → **Applications** → **Add an application** → **Self-hosted**
4. Isi:

   | Medan | Nilai |
   |---|---|
   | Application name | `Pipeline Testing Dashboard` |
   | Session Duration | `24 hours` |
   | Subdomain | `mbip-pipeline-dashboard` |
   | Domain | `pages.dev` |

5. **Next** → beri nama polisi, contoh `Team MBIP`
6. Action: **Allow**
7. Configure rules → **Include** → Selector: **Emails**
8. Masukkan email ahli team, satu per baris:

   ```
   nama1@syarikat.com
   nama2@syarikat.com
   ```

   Kalau semua guna domain yang sama, guna selector **Emails ending in**
   dan taip `@syarikat.com` sekali sahaja.

9. **Next** → **Add application**

### Uji sebelum kongsi

Buka URL tu dalam tetingkap **Incognito**. Kau patut nampak skrin
Cloudflare yang minta email — bukan dashboard. Masukkan email kau, ambil
PIN dari inbox, dan sahkan dashboard muncul selepas itu.

Kalau dashboard terus muncul tanpa diminta email, polisi tu belum aktif.
Jangan kongsi URL sehingga skrin email muncul.

---

## Bahagian 4 — Kemas kini selepas setiap run

```
tests\run_and_report.bat
tests\publish.bat
```

`publish.bat` akan commit dan push. Cloudflare Pages mengesan push itu
dan deploy semula dalam ~30 saat. Team cuma perlu refresh.

Nak automatik selepas setiap run:

```
setx MBIP_AUTOPUBLISH 1
```

---

## Menambah atau membuang ahli team

Zero Trust → Access → Applications → pilih aplikasi → Policies → edit
senarai email → Save.

Perubahan berkuat kuasa serta-merta. Orang yang dibuang akan tersekat
pada permintaan berikutnya, walaupun URL masih ada pada mereka.

---

## Yang perlu kau ingat

- **Zip yang boleh dimuat turun mengandungi kredential production 4 PBT.**
  Access menghalang orang luar daripada mendapatkannya, tetapi selepas
  ahli team memuat turunnya, fail itu ada pada komputer mereka dan berada
  di luar kawalan Access.
- **Repo mesti kekal Private.** Kalau ia ditukar kepada Public, kredential
  itu terdedah serta-merta walaupun Access masih melindungi laman web.
- **Access melindungi laman, bukan repo.** Kedua-duanya perlu dijaga
  berasingan.

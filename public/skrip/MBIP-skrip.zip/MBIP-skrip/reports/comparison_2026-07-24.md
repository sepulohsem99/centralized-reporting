# MBIP v3 — Rerun Comparison Report (new APK bug-fix build)

- **Run**: `reports/last_run.txt` — 2026-07-24, duration **2:26:10** (8770.90s), 0 ERRORs
- **Device**: `5008TF2010009401` (Armor 27) via Appium 3.5.2 @ 127.0.0.1:4723, app `com.anonymous.react_ies_v1`
- **Machine-readable results**: `reports/results.json` (written automatically by the conftest dashboard hook)
- **Dashboard**: `reports/mbip_v3_report.html` (auto-regenerated — refresh the tab)
- **Baseline**: `reports/phase3_report.md` as amended = **26 PASSED / 16 FAILED / 6 SKIPPED**

## Totals: baseline → this run

| | PASSED | FAILED | SKIPPED |
|---|---|---|---|
| Baseline | 26 | 16 | 6 |
| **This run** | **25** | **17** | **6** |
| Δ | −1 | +1 | 0 |

Counts reconcile across all three artifacts: `last_run.txt` (17 failed, 25 passed, 6 skipped) = `results.json` = HTML cards (25 / 17 / 6, recheck 8). **8 Perlu Manual Recheck** = 5 printer skips + 3 new regressions flagged for confirm.

## What changed (5 TCs)

### ✅ Fixed since baseline (FAILED → PASSED)

| TC | Name | Note |
|---|---|---|
| **MBIP-TC-T-011** | Semak Kemaskini | **Self-heal held on a clean full rerun.** Was a FAILED flake at baseline; the T-010-style close-and-reopen fix now passes in a full-suite context. Confirmed. |
| **MBIP-TC-H-003** | Hantar Semula Kompaun Letak Kereta | Server **accepted** the K-jenis resubmission this run (status → 'H'). Was FAILED at baseline (server rejecting K-jenis). Server-side behavior — see H note below. |

### ⚠️ New regressions since baseline (PASSED → FAILED)

| TC | Name | Actual error | Classification |
|---|---|---|---|
| **MBIP-TC-K-001** | Daftar Kompaun Letak Kereta | `TimeoutException: MySIKAP lookup never populated NAMA PESALAH for plate JYX6605; see debug_mysikap_populate.xml` | Create step's MySIKAP autofill returned no data. **Reproduced in both of today's runs** (this one + the earlier aborted 11:39 run). Needs a rerun / MySIKAP-backend check to classify as app-build vs backend-availability — the automation reached and triggered the lookup correctly; the data never came back. |
| **MBIP-TC-K-003** | Serah Kompaun Letak Kereta | `Element not found: descriptionMatches("^K,.*YYYY-MM-DD")` (no K-jenis record in Senarai's today range) | **Cascade / precondition** of K-001 — because K-001 didn't create today's K record, Serah had none to open. Not an independent K-003 break. Expected to pass once K-001 creates a record. |
| **MBIP-TC-H-001** | Hantar Semula Notis Amaran | `AssertionError: FAIL: no N-jenis record shows STATUS HANTAR 'H' after Hantar; rows: N,2026-07-24,10:43,M,A,msc; …` | **Server-side** — same shape as the known H-002/H-004 server rejections. This run the server rejected N-jenis (previously accepted) while accepting K-jenis (H-003). Environment/server finding, not an automation gap. |

## Watch-items you flagged (explicit status)

| Group | TCs | Baseline → this run |
|---|---|---|
| **Kemaskini (-004)** | N/P/K/L/S-004 | FAILED → **FAILED (no change)** — lower section of the Kemaskini edit form still never renders. Dev-team item stands. |
| **Bookmark (-005)** | N/P/K/L/S-005 | FAILED → **FAILED (no change)** — Pilihan Kegemaran popup still has no name field / SIMPAN (only PILIH/HAPUS). Dev-team item stands. |
| **Sitaan Kadar Denda** | S-001 | FAILED → **FAILED (no change)** — Kadar Denda EditText still unreachable below the fold. (S-003/004/005 remain blocked downstream of S-001.) |
| **Hantar resubmission** | H-002 / H-003 / H-004 | H-002 (P) FAILED→FAILED · **H-003 (K) FAILED→PASSED (fixed)** · H-004 (L) FAILED→FAILED. Server accept/reject set shifted this run (K in, N out). |
| **T-011 flake** | T-011 | FAILED → **PASSED (self-heal confirmed on clean rerun)** ✅ |

**Net on the app-build blockers:** the new APK did **not** move the Kemaskini (-004), Bookmark (-005), or Sitaan Kadar Denda (S-001) blockers — all still fail identically. The only genuine app-surface change is negative: **K-001 MySIKAP populate** now fails (and drags K-003 with it). The H-001/H-003 swaps are server-side.

## Full per-TC table (baseline → this run)

| # | TC ID | Name | Baseline | This run | Δ |
|---|---|---|---|---|---|
| 1 | T-001 | Tetapan Alamat IP | PASSED | PASSED | |
| 2 | T-002 | Tetapan Pelbagai | PASSED | PASSED | |
| 3 | T-003 | Selaras Pengguna Apps | PASSED | PASSED | |
| 4 | T-004 | Selaras Maklumat Alamat | PASSED | PASSED | |
| 5 | T-005 | Selaras Maklumat Kompaun | PASSED | PASSED | |
| 6 | T-006 | Selaras Maklumat Jenis Kenderaan | PASSED | PASSED | |
| 7 | T-007 | Selaras Maklumat Warna | PASSED | PASSED | |
| 8 | T-008 | Selaras Maklumat Pelesen | SKIPPED | SKIPPED | |
| 9 | T-009 | Selaras Maklumat Barang Sita | PASSED | PASSED | |
| 10 | T-010 | Tetapan Skrin Utama | PASSED | PASSED | |
| 11 | T-011 | Semak Kemaskini | FAILED | **PASSED** | ✅ fixed |
| 12 | T-012 | Remember Me Functions | PASSED | PASSED | |
| 13 | N-001 | Daftar Notis Amaran | PASSED | PASSED | |
| 14 | N-002 | Daftar Notis Amaran > Cetak | SKIPPED | SKIPPED | |
| 15 | N-003 | Serah Notis Amaran | PASSED | PASSED | |
| 16 | N-004 | Kemaskini Notis Amaran | FAILED | FAILED | |
| 17 | N-005 | Kompaun Form Notis Amaran - Bookmark | FAILED | FAILED | |
| 18 | P-001 | Daftar Kompaun Pelbagai | PASSED | PASSED | |
| 19 | P-002 | Daftar Kompaun Pelbagai > Cetak | SKIPPED | SKIPPED | |
| 20 | P-003 | Serah Kompaun Pelbagai | PASSED | PASSED | |
| 21 | P-004 | Kemaskini Kompaun Pelbagai | FAILED | FAILED | |
| 22 | P-005 | Kompaun Form Pelbagai - Bookmark | FAILED | FAILED | |
| 23 | K-001 | Daftar Kompaun Letak Kereta | PASSED | **FAILED** | ⚠️ regression |
| 24 | K-002 | Daftar Kompaun Letak Kereta > Cetak | SKIPPED | SKIPPED | |
| 25 | K-003 | Serah Kompaun Letak Kereta | PASSED | **FAILED** | ⚠️ cascade of K-001 |
| 26 | K-004 | Kemaskini Kompaun Letak Kereta | FAILED | FAILED | |
| 27 | K-005 | Kompaun Form Letak Kereta - Bookmark | FAILED | FAILED | |
| 28 | L-001 | Daftar Kompaun Lesen | PASSED | PASSED | |
| 29 | L-002 | Daftar Kompaun Lesen > Cetak | SKIPPED | SKIPPED | |
| 30 | L-003 | Serah Kompaun Lesen | PASSED | PASSED | |
| 31 | L-004 | Kemaskini Kompaun Lesen | FAILED | FAILED | |
| 32 | L-005 | Kompaun Form Lesen - Bookmark | FAILED | FAILED | |
| 33 | S-001 | Daftar Sitaan | FAILED | FAILED | |
| 34 | S-002 | Daftar Sitaan > Cetak | SKIPPED | SKIPPED | |
| 35 | S-003 | Serah Sitaan | FAILED | FAILED | |
| 36 | S-004 | Kemaskini Sitaan | FAILED | FAILED | |
| 37 | S-005 | Kompaun Form Sitaan - Bookmark | FAILED | FAILED | |
| 38 | SK-001 | Senarai Kompaun | PASSED | PASSED | |
| 39 | H-001 | Hantar Semula Notis Amaran | PASSED | **FAILED** | ⚠️ server-side |
| 40 | H-002 | Hantar Semula Kompaun Pelbagai | FAILED | FAILED | |
| 41 | H-003 | Hantar Semula Kompaun Letak Kereta | FAILED | **PASSED** | ✅ fixed (server) |
| 42 | H-004 | Hantar Semula Kompaun Lesen | FAILED | FAILED | |
| 43 | H-005 | Hantar Semula Kompaun Sitaan | PASSED | PASSED | |
| 44 | TN-001 | Tarik Notis by Penguatkuasa | PASSED | PASSED | |
| 45 | TN-002 | Tarik Notis by No.Notis | PASSED | PASSED | |
| 46 | TN-003 | Tarik Notis by Tarikh | PASSED | PASSED | |
| 47 | NK-001 | Notis ke Kompaun > Kompaun | PASSED | PASSED | |
| 48 | NK-002 | Notis ke Kompaun > Patuh | PASSED | PASSED | |

## Automation pipeline (built this session)

One command now does the whole loop — no manual copy/paste into the dashboard:

```
tests\run_and_report.bat
```

It runs `pytest tests -v > reports/last_run.txt`, then `python reports/generate_report.py`, which rewrites `reports/mbip_v3_report.html` from `reports/results.json` (dumped by the conftest summary hook). Idempotent; refresh the browser tab after each run.

> Note: no test logic was changed to affect any pass/fail. The only suite-code edits were device targeting (pin `udid=5008TF2010009401` because two devices are attached) and the additive JSON dump in the summary hook.

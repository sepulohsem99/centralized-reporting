"""
Jana fail Excel per run — untuk menjejak balik ke pangkalan data.

KENAPA
------
Dashboard bagus untuk melihat keadaan sekarang. Tetapi bila sesuatu gagal,
soalan seterusnya ialah "rekod yang mana?" — dan untuk menyiasat dalam
pangkalan data, yang diperlukan ialah NOMBOR sebenar (contoh
IPA3N260728054) berserta ralat sebenar yang berlaku, dalam bentuk yang
boleh ditapis dan dicari.

Fail ini menghasilkan satu .xlsx bagi setiap run: satu baris per TC,
lengkap dengan nombor rekod yang dicipta dan mesej ralat sebenar.

Kalau openpyxl tiada, ia jatuh ke CSV (Excel tetap boleh buka) dan bukan
gagal — menjana laporan tidak boleh bergantung pada pemasangan pustaka
imej/spreadsheet pada mesin setiap ahli team.
"""

import csv
import os
import re

HEADERS = [
    "No", "TC ID", "Nama", "Kategori",
    "Status (Automation)", "Status (Manual Excel)", "Tindakan",
    "Nombor rekod dicipta", "Ralat sebenar run ini", "Nota konteks",
]

# Warna latar mengikut status — sepadan dengan lencana dashboard supaya
# orang yang biasa dengan satu tidak perlu belajar yang lain.
FILLS = {
    "PASSED":  "C6EFCE",
    "FAILED":  "FFC7CE",
    "ERROR":   "FFC7CE",
    "SKIPPED": "FFEB9C",
}


def _blanks():
    """Medan yang skrip Excel sengaja tidak bekalkan, per TC.

    Diimport secara lembut: laporan mesti boleh dijana walaupun testdata
    tidak dapat diimport (contohnya bila laporan dijana pada mesin yang
    tiada Appium)."""
    try:
        import sys
        here = os.path.dirname(os.path.abspath(__file__))
        root = os.path.dirname(here)
        if root not in sys.path:
            sys.path.insert(0, root)
        from testdata.excel_data import BLANK_BY_DESIGN
        return BLANK_BY_DESIGN
    except Exception:                                   # noqa: BLE001
        return {}


def _penanda(medan):
    """Penanda sebenar bagi satu medan — teks atau berangka."""
    try:
        from testdata.excel_data import penanda_untuk
        return penanda_untuk(medan)
    except Exception:                                   # noqa: BLE001
        return "penanda skrip ujian"


def _rows(models, reasons, artifacts, manual_map):
    blanks = _blanks()
    out = []
    for m in models:
        tc = m["tcid"]
        art = artifacts.get(tc) or {}
        art_txt = "; ".join(f"{k}={v}" for k, v in art.items())
        man = (manual_map.get(re.sub(r"^[A-Z]+-TC-", "TC-", tc)) or {})

        # Medan yang diisi penanda ditulis terus ke dalam nota, supaya
        # laporan dan kertas cetak bercerita perkara yang sama. Sesiapa
        # yang nampak "blank dari test script" pada cetakan boleh cari
        # TC itu di sini dan terus tahu medan mana yang terlibat.
        nota = m["note"] or ""
        bl = blanks.get(tc) or {}
        if bl:
            # Setiap medan disenaraikan bersama penanda sebenarnya —
            # medan teks dapat "blank dari test script", medan berangka
            # dapat sentinel 12-digit. Menulis "diisi penanda" sahaja
            # tidak memadai: orang yang trace dalam DB perlu tahu nilai
            # tepat yang dicari.
            butir = "; ".join(f"{f} = {_penanda(f)}" for f in sorted(bl))
            tanda = (f"Excel tidak membekalkan nilai untuk medan ini, "
                     f"jadi ia diisi penanda skrip ujian — {butir}.")
            nota = f"{nota} {tanda}".strip() if nota else tanda

        out.append([
            m["no"], tc, m["nama"], m["cat"],
            m["status"], man.get("status", ""), m["action"],
            art_txt, reasons.get(tc, ""), nota,
        ])
    return out


def build(path_noext, meta, models, reasons, artifacts, manual_map):
    """Tulis <path_noext>.xlsx (atau .csv). Pulangkan laluan sebenar."""
    rows = _rows(models, reasons, artifacts, manual_map)

    try:
        from openpyxl import Workbook
        from openpyxl.styles import Font, PatternFill, Alignment
        from openpyxl.utils import get_column_letter
    except ImportError:
        p = path_noext + ".csv"
        with open(p, "w", newline="", encoding="utf-8-sig") as fh:
            w = csv.writer(fh)
            for k, v in meta.items():
                w.writerow([k, v])
            w.writerow([])
            w.writerow(HEADERS)
            w.writerows(rows)
        return p

    wb = Workbook()
    ws = wb.active
    ws.title = "Keputusan"

    # Blok maklumat run di atas: tanpa ini, fail yang dihantar kepada orang
    # lain tidak bermakna — mereka tidak tahu run mana, server mana, build
    # mana.
    bold = Font(bold=True)
    r = 1
    for k, v in meta.items():
        ws.cell(row=r, column=1, value=k).font = bold
        ws.cell(row=r, column=2, value=v)
        r += 1
    r += 1

    head_row = r
    fill_head = PatternFill("solid", fgColor="1F232C")
    for c, h in enumerate(HEADERS, start=1):
        cell = ws.cell(row=head_row, column=c, value=h)
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = fill_head
        cell.alignment = Alignment(vertical="center", wrap_text=True)

    for i, row in enumerate(rows, start=head_row + 1):
        for c, v in enumerate(row, start=1):
            cell = ws.cell(row=i, column=c, value=v)
            cell.alignment = Alignment(vertical="top", wrap_text=(c >= 8))
        status = row[4]
        if status in FILLS:
            ws.cell(row=i, column=5).fill = PatternFill(
                "solid", fgColor=FILLS[status])

    widths = [5, 17, 34, 9, 19, 19, 22, 30, 60, 60]
    for c, w in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(c)].width = w

    # Tapis + bekukan pane: fail ini untuk dicari, bukan sekadar dibaca.
    ws.auto_filter.ref = (f"A{head_row}:"
                          f"{get_column_letter(len(HEADERS))}{head_row+len(rows)}")
    ws.freeze_panes = ws.cell(row=head_row + 1, column=1)

    p = path_noext + ".xlsx"
    wb.save(p)
    return p

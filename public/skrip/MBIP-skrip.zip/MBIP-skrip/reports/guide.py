"""
Kandungan panduan pengguna — SATU sumber, dua output.

Panduan yang sama dirender ke:
  - tab "Panduan" dalam dashboard HTML (sentiasa ada bersama laporan)
  - PANDUAN.md di dalam zip (untuk dibaca selepas unzip, sebelum ada
    dashboard)

Disimpan sebagai data berstruktur (bukan dua string berasingan) supaya
kedua-dua output tak boleh terpesong antara satu sama lain bila panduan
dikemas kini.

GAYA
----
Pembaca sasaran mungkin tidak pernah sentuh Appium, dan akan membaca ini
sambil cuba menjalankan sesuatu. Jadi: diagram dahulu, arahan dalam
bingkai terminal yang kelihatan seperti apa yang mereka akan lihat pada
skrin, dan ayat sependek mungkin. Perenggan panjang tidak dibaca.

Blok yang disokong:
    ("flow",    [ (tajuk, [baris, ...]), ... ])  -> diagram alur berperingkat
    ("term",    (tajuk, [baris, ...]))           -> tetingkap terminal
    ("p",       "perenggan pendek")
    ("steps",   ["langkah", ...])                -> senarai bernombor
    ("bullets", ["poin", ...])
    ("pairs",   [(kiri, kanan), ...])            -> jadual dua lajur
    ("note",    "maklumat sampingan")
    ("warn",    "amaran penting")
"""

import html as _html

# ---------------------------------------------------------------------------
# Ikon
# ---------------------------------------------------------------------------
# SVG sebaris, bukan fail imej atau fon ikon: tiada permintaan rangkaian,
# tiada kebergantungan luar, dan ia mewarisi warna teks jadi ikut tema
# gelap/cerah dengan sendirinya. Semua 24x24, stroke sahaja.
_I = {
    "node":     "M12 2 20 7v10l-8 5-8-5V7z",
    "python":   "M8 6h5a3 3 0 0 1 3 3v3H8a3 3 0 0 0-3 3v3M16 18h-5a3 3 0 0 1-3-3",
    "android":  "M5 10v7a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-7zM8 10 6 6M16 10l2-4M9 15h.01M15 15h.01",
    "cube":     "M12 3 3 8v8l9 5 9-5V8zM3 8l9 5 9-5M12 13v8",
    "terminal": "M3 4h18v16H3zM7 9l3 3-3 3M13 15h4",
    "phone":    "M7 2h10v20H7zM11 18h2",
    "usb":      "M12 22V8M9 11 12 8l3 3M12 2v3M9 15H7a2 2 0 0 1-2-2V9M15 18h2a2 2 0 0 0 2-2V9",
    "lock":     "M6 11h12v10H6zM9 11V7a3 3 0 0 1 6 0v4",
    "play":     "M6 4l14 8-14 8z",
    "check":    "M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20M8 12l3 3 5-6",
    "cross":    "M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20M9 9l6 6M15 9l-6 6",
    "minus":    "M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20M8 12h8",
    "alert":    "M12 3 2 20h20zM12 9v5M12 17h.01",
    "file":     "M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8zM14 3v5h5",
    "users":    "M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8M2 21v-2a5 5 0 0 1 5-5h4a5 5 0 0 1 5 5v2M17 4a4 4 0 0 1 0 7M22 21v-2a5 5 0 0 0-3-4.5",
    "refresh":  "M21 12a9 9 0 1 1-3-6.7M21 4v5h-5",
    "eye":      "M2 12s4-7 10-7 10 7 10 7-4 7-10 7-10-7-10-7M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6",
    "plug":     "M9 2v6M15 2v6M6 8h12v3a6 6 0 0 1-12 0zM12 17v5",
    "stop":     "M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20M9 9h6v6H9z",
}


def _icon(name, cls="ic"):
    d = _I.get(name)
    if not d:
        return ""
    return (f'<svg class="{cls}" viewBox="0 0 24 24" fill="none" '
            f'stroke="currentColor" stroke-width="1.7" stroke-linecap="round" '
            f'stroke-linejoin="round" aria-hidden="true"><path d="{d}"/></svg>')

GUIDE = [
    ("Alur kerja", [
        ("flow", [
            ("1. Pasang", ["Node.js + Python", "adb + appium",
                           "driver uiautomator2", "pip install -r ..."]),
            ("2. Sambung telefon", ["USB debugging: ON", "APK PBT dipasang",
                                    "Auto-lock: OFF"]),
            ("3. Run", ["T1: appium", "T2: run_and_report",
                        "Pilih PBT", "Tunggu 1.5-2.5 jam"]),
            ("4. Baca hasil", ["Dashboard update", "Refresh browser"]),
        ]),
    ]),

    ("1. Pasang \u2014 sekali sahaja", [
        ("cards", [
            ("node",    "Node.js",     "nodejs.org \u2192 LTS"),
            ("python",  "Python 3.11+", "python.org \u2192 tanda "
                                        "<b>Add to PATH</b>"),
            ("android", "adb",         "platform-tools \u2192 tambah ke PATH"),
            ("cube",    "Appium",      "arahan di bawah"),
        ]),
        ("term", ("Command Prompt", [
            "npm install -g appium",
            "appium driver install uiautomator2",
            "pip install -r requirements.txt",
        ])),
        ("note", "Terlepas <b>Add Python to PATH</b>? Uninstall, install "
                 "semula."),
    ]),

    ("2. Sediakan telefon", [
        ("cards", [
            ("phone", "Developer options",
             "About phone \u2192 ketuk <b>Build number</b> 7 kali"),
            ("usb",   "USB debugging", "hidupkan dalam Developer options"),
            ("plug",  "Sambung USB",   "tekan <b>Allow</b> pada telefon"),
            ("lock",  "Auto-lock",     "matikan"),
        ]),
        ("note", "Serial telefon tak perlu ditaip \u2014 suite cari sendiri."),
    ]),

    ("3. Setiap kali nak run", [
        ("term", ("Terminal 1 \u2014 biar terbuka", ["appium"])),
        ("shot", ("APPIUM_RUNNING", "Beginilah rupanya bila Appium jalan",
                  ["PS C:\\Users\\anda> appium",
                   "[Appium] Welcome to Appium v3.5.2",
                   "[Appium] AndroidUiautomator2Driver loaded in 6.150s",
                   "[Appium] listener started on http://0.0.0.0:4723"])),
        ("note", "Kursor berkelip, prompt tak kembali \u2014 itu betul. "
                 "<b>Jangan tutup tetingkap ni.</b>"),
        ("term", ("Terminal 2 \u2014 jalankan test", [
            "cd C:\\laluan\\ke\\mbip-v3",
            "tests\\run_and_report.bat",
        ])),
        ("term", ("Menu PBT akan keluar", [
            "1. MBIP - production",
            "2. MBIP - staging",
            "",
            "Masukkan nombor pilihan: _",
        ])),
        ("warn", "Pastikan APK pada telefon betul-betul milik PBT yang "
                 "dipilih. Suite tak boleh semak ini untuk anda."),
    ]),

    ("4. Baca hasil", [
        ("legend", [
            ("check", "pass", "PASSED",  "Lulus. Tiada tindakan."),
            ("cross", "fail", "FAILED",  "Gagal. Baca lajur Nota."),
            ("minus", "skip", "SKIPPED", "Sengaja dilangkau."),
            ("alert", "warn", "ERROR",   "Tak sempat jalan. Rerun."),
        ]),
        ("cards", [
            ("eye",     "Laporan",  "<code>reports\\mbip_v3_report.html</code>"),
            ("refresh", "Dah buka?", "Refresh sahaja"),
            ("file",    "Log penuh", "<code>reports\\last_run.txt</code>"),
        ]),
    ]),

    ("5. Masalah biasa", [
        ("pairs", [
            ("Tiada device", "Periksa kabel. <code>adb devices</code>."),
            ("<code>unauthorized</code>", "Tengok skrin telefon \u2014 "
                                          "tekan Allow."),
            ("Appium tak hidup", "Terlupa Terminal 1."),
            ("Banyak ERROR serentak", "UiAutomator2 crash. Restart appium, "
                                      "rerun."),
            ("Lebih satu device", "<code>set MBIP_UDID=&lt;serial&gt;</code>"),
        ]),
    ]),

    ("6. Tambah PBT baharu", [
        ("p", "Satu fail JSON dalam <code>profiles/</code>. Salin yang "
              "sedia ada, tukar nilai. Tiada kod diubah."),
        ("term", ("profiles/mbpg-production.json", [
            '{',
            '  "pbt": "MBPG",',
            '  "env": "production",',
            '  "app_package": "com.anonymous.react_ies_v1",',
            '  "internal_ip": "113.211.155.174",',
            '  "lesen_aplikasi": "359563990174736",',
            '  "username": "msc",',
            '  "password": "Pass1"',
            '}',
        ], "file")),
        ("note", "Medan <code>ISI-SINI</code> ditolak sebelum ujian bermula "
                 "\u2014 gagal dalam 2 saat, bukan 2 jam."),
    ]),

    ("7. Peraturan", [
        ("cards", [
            ("users", "Seorang sahaja run",
             "Data test sama, server sama. Dua orang serentak = rekod "
             "bertindih."),
            ("file",  "Jangan edit <code>.py</code>", "Semua automatik."),
            ("phone", "Jangan guna telefon", "Semasa test berjalan."),
            ("stop",  "Nak berhenti", "<code>Ctrl+C</code> dalam Terminal 2."),
        ]),
    ]),
]


# ---------------------------------------------------------------------------
# Renderers
# ---------------------------------------------------------------------------

def _md(text):
    """Tukar HTML inline ringkas kepada padanan Markdown."""
    return (text.replace("<b>", "**").replace("</b>", "**")
                .replace("<code>", "`").replace("</code>", "`")
                .replace("&rarr;", "->").replace("&times;", "x")
                .replace("&lt;", "<").replace("&gt;", ">")
                .replace("&amp;", "&"))


def _flow_svg(stages):
    """Diagram alur sebagai SVG sebenar, dijana dari data `stages`.

    SVG dan bukan kotak HTML: bentuk ini perlukan anak panah, tetingkap
    terminal bertindih, dan penjajaran yang tetap — semuanya menyusahkan
    dengan div, dan mudah dengan koordinat.

    Warna melalui pembolehubah CSS supaya diagram ikut tema, dan viewBox
    membolehkannya mengecil pada skrin sempit tanpa teks jadi kabur.
    """
    W, H = 216, 150          # saiz satu kotak
    GAP = 46                 # ruang untuk anak panah
    total_w = len(stages) * W + (len(stages) - 1) * GAP
    total_h = H + 16

    p = [f'<svg class="flow-svg" viewBox="0 0 {total_w} {total_h}" '
         f'role="img" aria-label="Alur kerja menjalankan test" '
         f'xmlns="http://www.w3.org/2000/svg">']

    # Kepala anak panah dikongsi oleh semua sambungan.
    p.append('<defs><marker id="ah" viewBox="0 0 10 10" refX="9" refY="5" '
             'markerWidth="6" markerHeight="6" orient="auto">'
             '<path d="M0,0 L10,5 L0,10 z" fill="var(--muted)"/></marker></defs>')

    for i, (title, lines) in enumerate(stages):
        x = i * (W + GAP)
        y = 8

        # Badan kotak, dengan bar tajuk gaya tetingkap terminal.
        p.append(f'<rect x="{x}" y="{y}" width="{W}" height="{H}" rx="10" '
                 f'fill="var(--card)" stroke="var(--line)"/>')
        p.append(f'<path d="M{x},{y+28} h{W}" stroke="var(--line)"/>')
        for j, col in enumerate(("#ff5f56", "#ffbd2e", "#27c93f")):
            p.append(f'<circle cx="{x+16+j*13}" cy="{y+14}" r="4" fill="{col}"/>')
        p.append(f'<text x="{x+60}" y="{y+18}" font-size="11.5" '
                 f'font-weight="700" fill="var(--accent)" '
                 f'font-family="Consolas,monospace">'
                 f'{_html.escape(title)}</text>')

        for j, line in enumerate(lines):
            p.append(f'<text x="{x+16}" y="{y+52+j*21}" font-size="11.5" '
                     f'fill="var(--muted)" font-family="Consolas,monospace">'
                     f'{_html.escape(line)}</text>')

        if i < len(stages) - 1:
            x1, x2 = x + W + 9, x + W + GAP - 9
            p.append(f'<line x1="{x1}" y1="{y+H/2}" x2="{x2}" y2="{y+H/2}" '
                     f'stroke="var(--muted)" stroke-width="1.6" '
                     f'marker-end="url(#ah)"/>')

    p.append("</svg>")
    return "".join(p)


def guide_html():
    out = []
    for title, blocks in GUIDE:
        out.append(f'<h2 class="g-h">{_html.escape(title)}</h2>')
        for kind, body in blocks:

            if kind == "flow":
                out.append(_flow_svg(body))

            elif kind == "term":
                t, lines = body[0], body[1]
                is_file = len(body) > 2 and body[2] == "file"
                rows = []
                for l in lines:
                    if not l:
                        rows.append('<div class="t-line">&nbsp;</div>')
                    else:
                        rows.append(f'<div class="t-line">'
                                    f'{_html.escape(l)}</div>')
                copyable = "\n".join(l for l in lines if l)
                out.append(
                    f'<div class="term{" is-file" if is_file else ""}">'
                    '<div class="t-bar"><span class="t-dot d1"></span>'
                    '<span class="t-dot d2"></span><span class="t-dot d3"></span>'
                    f'<span class="t-name">{_html.escape(t)}</span>'
                    f'<button class="g-copy" data-copy="'
                    f'{_html.escape(copyable)}">Salin</button></div>'
                    f'<div class="t-body">{"".join(rows)}</div></div>'
                )

            elif kind == "shot":
                import shots
                name, alt, _fallback = body
                src = getattr(shots, name)
                out.append(
                    f'<figure class="shot"><img src="{src}" '
                    f'alt="{_html.escape(alt)}" loading="lazy">'
                    f'<figcaption>{_html.escape(alt)}</figcaption></figure>'
                )

            elif kind == "output":
                # Output yang DIJANGKA, bukan arahan: tiada prompt di
                # setiap baris dan tiada butang Salin — ini bukan sesuatu
                # yang patut ditaip atau disalin, cuma dibandingkan
                # dengan apa yang keluar di skrin.
                t, lines = body
                rows = []
                for l in lines:
                    cls = "o-line"
                    if l.startswith("[Appium]"):
                        cls += " o-tag"
                    elif l.startswith("PS ") or l.startswith("C:"):
                        cls += " o-prompt"
                    rows.append(f'<div class="{cls}">'
                                f'{_html.escape(l) or "&nbsp;"}</div>')
                out.append(
                    '<div class="term is-file is-output">'
                    '<div class="t-bar"><span class="t-dot d1"></span>'
                    '<span class="t-dot d2"></span><span class="t-dot d3"></span>'
                    f'<span class="t-name">{_html.escape(t)}</span>'
                    '<span class="t-live">berjalan</span></div>'
                    f'<div class="t-body">{"".join(rows)}'
                    '<div class="o-caret">_</div></div></div>'
                )

            elif kind == "cards":
                items = "".join(
                    f'<div class="gcard">{_icon(ic)}'
                    f'<div class="gc-t">{t}</div>'
                    f'<div class="gc-d">{d}</div></div>'
                    for ic, t, d in body)
                out.append(f'<div class="gcards">{items}</div>')

            elif kind == "legend":
                items = "".join(
                    f'<div class="lg-row"><span class="lg-ic {tone}">'
                    f'{_icon(ic)}</span>'
                    f'<span class="lg-t {tone}">{_html.escape(label)}</span>'
                    f'<span class="lg-d">{desc}</span></div>'
                    for ic, tone, label, desc in body)
                out.append(f'<div class="legend">{items}</div>')

            elif kind == "pairs":
                items = "".join(
                    f'<div class="pr-k">{_icon("alert", "ic sm")} {k}</div>'
                    f'<div class="pr-v">{v}</div>'
                    for k, v in body)
                out.append(f'<div class="pairs">{items}</div>')

            elif kind == "p":
                out.append(f'<p class="g-p">{body}</p>')
            elif kind == "steps":
                out.append('<ol class="g-list">'
                           + "".join(f"<li>{b}</li>" for b in body) + '</ol>')
            elif kind == "bullets":
                out.append('<ul class="g-list">'
                           + "".join(f"<li>{b}</li>" for b in body) + '</ul>')
            elif kind == "note":
                out.append(f'<div class="g-note">{body}</div>')
            elif kind == "warn":
                out.append(f'<div class="g-warn">{body}</div>')
    return "\n".join(out)


def guide_markdown():
    out = ["# MBIP v3 — Panduan Menjalankan Test Automation", ""]
    for title, blocks in GUIDE:
        out += [f"## {title}", ""]
        for kind, body in blocks:

            if kind == "flow":
                # Diagram dilukis sebagai ASCII supaya bermakna dalam fail
                # teks biasa, bukan sekadar senarai tanpa struktur.
                # Lebar dalaman dikira SEKALI untuk semua peringkat supaya
                # kotak sejajar menegak. Setiap baris mesti menyumbang
                # tepat `w` aksara antara kedua-dua '|', jika tidak
                # sempadan kanan akan bergerigi.
                w = max(max([len(t)] + [len(l) for l in ls])
                        for t, ls in body) + 6
                bar = "+" + "-" * w + "+"
                out.append("```")
                for i, (t, lines) in enumerate(body):
                    out.append(bar)
                    out.append("| " + t.ljust(w - 2) + " |")
                    out.append("|" + " " * w + "|")
                    for l in lines:
                        out.append("|   " + l.ljust(w - 4) + " |")
                    out.append(bar)
                    if i < len(body) - 1:
                        out.append("      |")
                        out.append("      v")
                out += ["```", ""]

            elif kind == "shot":
                # Markdown tidak boleh membawa imej terbenam, jadi guna
                # sandaran teks yang disimpan bersama blok itu.
                _n, alt, fallback = body
                out += [f"**{alt}**", "", "```"] + list(fallback) + ["```", ""]

            elif kind in ("term", "output"):
                t, lines = body[0], body[1]
                lang = "json" if (len(body) > 2 and body[2] == "file") else ""
                out += [f"**{t}**", "", "```" + lang] + list(lines) + ["```", ""]

            elif kind == "cards":
                # Ikon tiada makna dalam teks biasa — tinggalkan tajuk
                # dan huraian sahaja.
                for _ic, t, d in body:
                    out.append(f"- **{_md(t)}** — {_md(d)}")
                out.append("")

            elif kind == "legend":
                out += ["| | |", "|---|---|"]
                for _ic, _tone, label, desc in body:
                    out.append(f"| **{label}** | {_md(desc)} |")
                out.append("")

            elif kind == "pairs":
                out.append("| | |")
                out.append("|---|---|")
                for k, v in body:
                    out.append(f"| {_md(k)} | {_md(v)} |")
                out.append("")

            elif kind == "p":
                out += [_md(body), ""]
            elif kind == "steps":
                out += [f"{i}. {_md(b)}" for i, b in enumerate(body, 1)] + [""]
            elif kind == "bullets":
                out += [f"- {_md(b)}" for b in body] + [""]
            elif kind == "note":
                out += [f"> **Nota:** {_md(body)}", ""]
            elif kind == "warn":
                out += [f"> ⚠️ {_md(body)}", ""]
    return "\n".join(out).rstrip() + "\n"

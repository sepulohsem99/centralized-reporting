#!/usr/bin/env python3
"""
generate_report.py — regenerate reports/mbip_v3_report.html from the
per-TC results produced by the last pytest run (reports/results.json,
written by the conftest dashboard hook).

Design goals:
- Idempotent: safe to run after every single test run. It rebuilds the
  whole HTML from a fixed template + the static metadata table below +
  the dynamic results.json, so there is no stateful patching.
- Standalone: no imports from the test suite, no third-party deps. Just
  run `python reports/generate_report.py`.

Status source of truth per TC:
- The 6 intentionally-not-attempted TCs (5 "> Cetak" + T-008 Pelesen)
  are FORCED to SKIPPED with a fixed action/note regardless of the run.
- Every other TC takes its status straight from results.json.

Baseline (reports/phase3_report.md, as amended): 26 PASSED / 16 FAILED /
6 SKIPPED. Each row stores its baseline status so a status change (a
regression fixed by a new APK, or a new regression) is auto-flagged in
the Nota cell with a 🔁 marker.

FASA 1 additions (team hand-off — the report is now the whole product,
not just a table):
- Three tabs: Laporan / Sejarah Run / Panduan.
- Run history: every run is archived to reports/history/ and listed, so
  a team where several people run the suite can see who ran what, on
  which app build, and how the numbers moved.
- Export CSV (respects the active filters) + Cetak/PDF.
- Download button for the redistributable .zip, rebuilt each run.
- App build version comes from the DEVICE at run time, never hardcoded:
  a note that says "build 2.1.14" must not still say that after 2.1.17
  is installed.
"""

import html
import json
import os
import re
import datetime

import guide
import make_zip
import make_excel
from favicon import FAVICON_DATA_URI

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
RESULTS_JSON = os.path.join(HERE, "results.json")
OUT_HTML = os.path.join(HERE, "mbip_v3_report.html")
HISTORY_DIR = os.path.join(HERE, "history")
PIPELINE_JSON = os.path.join(HERE, "pipeline.json")
PROFILES_DIR = os.path.join(ROOT, "profiles")
PANDUAN_MD = os.path.join(ROOT, "PANDUAN.md")

# Dua salinan dashboard, kandungan sama, satu beza sahaja: laluan ke zip.
#   reports/mbip_v3_report.html -> untuk dwi-klik di mesin sendiri
#   public/index.html           -> yang Vercel hidangkan di URL live
# public/ ialah SATU-SATUNYA folder yang terdedah secara awam.
PUBLIC_DIR = os.path.join(ROOT, "public")
PUBLIC_HTML = os.path.join(PUBLIC_DIR, "index.html")
ZIP_NAME = "mbip-v3-suite.zip"
ZIP_HREF_LOCAL = f"../public/{ZIP_NAME}"   # dari dalam reports/
ZIP_HREF_PUBLIC = ZIP_NAME                 # bersebelahan index.html

# ---------------------------------------------------------------------------
# Static metadata table — TC id -> (No, Nama, Kategori, baseline status,
# forced-skip policy, baseline note). Notes are the human context; they
# render as-is when status == baseline, and are auto-replaced by a
# change message when the status flips.
#
# fields: no, tcid, nama, cat, baseline, forced, note
#   forced: None, or ("printer"|"arahan", note) => always SKIPPED
#
# "{ver}" in any note is substituted with the app build actually detected
# on the device for this run.
# ---------------------------------------------------------------------------

# Scope caveats — appended to a row's note ALWAYS, even when a status
# change replaces the rest of the note. These describe what the test
# actually covers, which is a permanent property of the test, not a
# property of any one run: losing the caveat the moment a status flips
# would be exactly when it's most likely to be misread.
#
# Kemaskini: Excel's Test Data (C9) lists many fields to change; the
# automation only ever reaches one before the form's lower section stops
# rendering. Without this note the FAILED status reads as "full Excel
# check attempted and failed", which is not what happened.
_KEMASKINI_SCOPE = (
    " ⚠️ Nota skop: automation hanya update 1 field "
    "(Maklumat Jalan Kesalahan) sebelum stuck — BUKAN semua field yang "
    "Excel C9 minta. Partial coverage, bukan full Excel-parity test."
)

SCOPE_CAVEAT = {
    "MBIP-TC-N-004": _KEMASKINI_SCOPE,
    "MBIP-TC-P-004": _KEMASKINI_SCOPE,
    "MBIP-TC-K-004": _KEMASKINI_SCOPE,
    "MBIP-TC-L-004": _KEMASKINI_SCOPE,
    "MBIP-TC-S-004": _KEMASKINI_SCOPE,
}

META = [
    (1,  "MBIP-TC-T-001", "Tetapan Alamat IP", "T", "PASSED", None, ""),
    (2,  "MBIP-TC-T-002", "Tetapan Pelbagai", "T", "PASSED", None, "Lesen: 352405067769401"),
    (3,  "MBIP-TC-T-003", "Selaras Pengguna Apps", "T", "PASSED", None, ""),
    (4,  "MBIP-TC-T-004", "Selaras Maklumat Alamat", "T", "PASSED", None, ""),
    (5,  "MBIP-TC-T-005", "Selaras Maklumat Kompaun", "T", "PASSED", None, ""),
    (6,  "MBIP-TC-T-006", "Selaras Maklumat Jenis Kenderaan", "T", "PASSED", None, ""),
    (7,  "MBIP-TC-T-007", "Selaras Maklumat Warna", "T", "PASSED", None, ""),
    (8,  "MBIP-TC-T-008", "Selaras Maklumat Pelesen", "T", "SKIPPED",
         ("arahan", "Sync 52,317 rekod ≈ 1 jam device time — boleh enable balik bila perlu"),
         "Sync 52,317 rekod ≈ 1 jam device time — boleh enable balik bila perlu"),
    (9,  "MBIP-TC-T-009", "Selaras Maklumat Barang Sita", "T", "PASSED", None, ""),
    (10, "MBIP-TC-T-010", "Tetapan Skrin Utama", "T", "PASSED", None, ""),
    (11, "MBIP-TC-T-011", "Semak Kemaskini", "T", "FAILED", None,
         "Flake sekali (pass 3 run lain hari sama) — self-heal fix dah applied, tinggal rerun"),
    (12, "MBIP-TC-T-012", "Remember Me Functions", "T", "PASSED", None, "Login msc/Pass1, relaunch verified"),
    (13, "MBIP-TC-N-001", "Daftar Notis Amaran", "N", "PASSED", None, "Data Excel: ALI / JALAN DANGA SUTERA 12/3"),
    (14, "MBIP-TC-N-002", "Daftar Notis Amaran > Cetak", "N", "SKIPPED",
         None, "Test akan BERHENTI dan tunggu printer dihidupkan (bunyi bel + banner). SKIPPED hanya kalau tiada siapa hidupkan dalam tempoh menunggu."),
    (15, "MBIP-TC-N-003", "Serah Notis Amaran", "N", "PASSED", None,
         "Icon clip \U0001F4CE dijumpai (popup rekod → row LAMPIRAN) — verified 2026-07-17"),
    (16, "MBIP-TC-N-004", "Kemaskini Notis Amaran", "N", "FAILED", None,
         "Bahagian bawah form Kemaskini tak render langsung (blocker sebenar)."),
    (17, "MBIP-TC-N-005", "Kompaun Form Notis Amaran - Bookmark", "N", "FAILED", None,
         "Popup Pilihan Kegemaran build {ver} takde field nama & butang SIMPAN — hanya PILIH/HAPUS"),
    (18, "MBIP-TC-P-001", "Daftar Kompaun Pelbagai", "P", "PASSED", None, "Data Excel: ABU / JALAN JAYA 3 / RM2000"),
    (19, "MBIP-TC-P-002", "Daftar Kompaun Pelbagai > Cetak", "P", "SKIPPED",
         None, "Test akan BERHENTI dan tunggu printer dihidupkan (bunyi bel + banner). SKIPPED hanya kalau tiada siapa hidupkan dalam tempoh menunggu."),
    (20, "MBIP-TC-P-003", "Serah Kompaun Pelbagai", "P", "PASSED", None, "Lampiran attach verified 2026-07-17"),
    (21, "MBIP-TC-P-004", "Kemaskini Kompaun Pelbagai", "P", "FAILED", None,
         "Sama seperti N-004 (form Kemaskini tak render). Tester manual pun FAIL TC ni."),
    (22, "MBIP-TC-P-005", "Kompaun Form Pelbagai - Bookmark", "P", "FAILED", None,
         "UI simpan bookmark takde dalam build {ver}"),
    (23, "MBIP-TC-K-001", "Daftar Kompaun Letak Kereta", "K", "PASSED", None, "MySIKAP populate guna plate JYX6605"),
    (24, "MBIP-TC-K-002", "Daftar Kompaun Letak Kereta > Cetak", "K", "SKIPPED",
         None, "Test akan BERHENTI dan tunggu printer dihidupkan (bunyi bel + banner). SKIPPED hanya kalau tiada siapa hidupkan dalam tempoh menunggu."),
    (25, "MBIP-TC-K-003", "Serah Kompaun Letak Kereta", "K", "PASSED", None, "Lampiran attach verified 2026-07-17"),
    (26, "MBIP-TC-K-004", "Kemaskini Kompaun Letak Kereta", "K", "FAILED", None,
         "Butang KEMASKINI tak jumpa / form tak render — bug app."),
    (27, "MBIP-TC-K-005", "Kompaun Form Letak Kereta - Bookmark", "K", "FAILED", None,
         "UI simpan bookmark takde dalam build {ver}"),
    (28, "MBIP-TC-L-001", "Daftar Kompaun Lesen", "L", "PASSED", None, "Flow baru dibina dalam v3 — data Excel: RAMLI / RM500"),
    (29, "MBIP-TC-L-002", "Daftar Kompaun Lesen > Cetak", "L", "SKIPPED",
         None, "Test akan BERHENTI dan tunggu printer dihidupkan (bunyi bel + banner). SKIPPED hanya kalau tiada siapa hidupkan dalam tempoh menunggu."),
    (30, "MBIP-TC-L-003", "Serah Kompaun Lesen", "L", "PASSED", None, "Lampiran attach verified 2026-07-17"),
    (31, "MBIP-TC-L-004", "Kemaskini Kompaun Lesen", "L", "FAILED", None,
         "Form Kemaskini tak render — match dengan note tester sendiri (\"kod akta tidak papar apa2\")."),
    (32, "MBIP-TC-L-005", "Kompaun Form Lesen - Bookmark", "L", "FAILED", None,
         "UI simpan bookmark takde dalam build {ver} — tester manual pun FAIL"),
    (33, "MBIP-TC-S-001", "Daftar Sitaan", "S", "FAILED", None,
         "Ralat API dari sumber luar (disahkan pemilik 2026-07-28). Bukan bug app, bukan isu automation \u2014 kebergantungan luar. Tester manual pun FAIL."),
    (34, "MBIP-TC-S-002", "Daftar Sitaan > Cetak", "S", "SKIPPED",
         None, "Test akan BERHENTI dan tunggu printer dihidupkan (bunyi bel + banner). SKIPPED hanya kalau tiada siapa hidupkan dalam tempoh menunggu."),
    (35, "MBIP-TC-S-003", "Serah Sitaan", "S", "FAILED", None,
         "Tiada rekod Sitaan untuk dibuka — berantai dari S-001 (ralat API luar). Akan pulih sendiri bila S-001 pulih."),
    (36, "MBIP-TC-S-004", "Kemaskini Sitaan", "S", "FAILED", None,
         "Tiada rekod Sitaan \u2014 berantai dari S-001 (ralat API luar)."),
    (37, "MBIP-TC-S-005", "Kompaun Form Sitaan - Bookmark", "S", "FAILED", None,
         "UI simpan bookmark takde dalam build {ver}"),
    (38, "MBIP-TC-SK-001", "Senarai Kompaun", "SK", "PASSED", None, "Susunan No Kompaun verified"),
    (39, "MBIP-TC-H-001", "Hantar Semula Data & Gambar Notis Amaran", "H", "PASSED", None, "Server terima resubmission N-jenis"),
    (40, "MBIP-TC-H-002", "Hantar Semula Data & Gambar Kompaun Pelbagai", "H", "FAILED", None,
         "Server reject resubmission P-jenis — rekod bertimbun dalam DATA RALAT (67+)"),
    (41, "MBIP-TC-H-003", "Hantar Semula Data & Gambar Kompaun Letak Kereta", "H", "FAILED", None,
         "Server reject resubmission K-jenis"),
    (42, "MBIP-TC-H-004", "Hantar Semula Data & Gambar Kompaun Lesen", "H", "FAILED", None,
         "Server reject resubmission L-jenis"),
    (43, "MBIP-TC-H-005", "Hantar Semula Data & Gambar Kompaun Sitaan", "H", "PASSED", None,
         "Tester manual dulu FAIL — automation prove dia berfungsi sekarang"),
    (44, "MBIP-TC-TN-001", "Tarik Notis by Penguatkuasa", "TN", "PASSED", None, "ID: msc"),
    (45, "MBIP-TC-TN-002", "Tarik Notis by No.Notis", "TN", "PASSED", None,
         "Tester manual dulu FAIL — punca sebenar: field perlu mobile:type. Berfungsi."),
    (46, "MBIP-TC-TN-003", "Tarik Notis by Tarikh", "TN", "PASSED", None,
         "UI \"by Tarikh\" tak wujud dalam popup Tarik — v3 verify notis boleh dikenal pasti ikut tarikh row"),
    (47, "MBIP-TC-NK-001", "Notis ke Kompaun > Kompaun", "NK", "PASSED", None,
         "Tester manual dulu FAIL — full conversion (amaun + pembantu + gambar wajib) berfungsi"),
    (48, "MBIP-TC-NK-002", "Notis ke Kompaun > Patuh", "NK", "PASSED", None,
         "Tester manual dulu FAIL — Patuh (ulasan wajib + gambar wajib) berfungsi"),
]

ACTION_TEXT = {
    "ok": "Tiada — OK",
    "printer": "Manual: perlu printer",
    "dev": "Refer dev team",
    "rerun": "Rerun untuk confirm",
    "arahan": "Skip atas arahan kau",
    "blocked": "Show stopper — tersekat",
}
RECHECK_ACTIONS = {"printer", "rerun"}

# Garis dasar dalam META (26 PASSED / 16 FAILED / 6 SKIPPED) datang dari
# SATU run tertentu: MBIP production, 2026-07-24. Ia hanya bermakna untuk
# run yang setara.
#
# Run staging berlainan server, data kosong, dan build berlainan --
# membandingkannya dengan garis dasar production akan menandakan setiap
# perbezaan sebagai "regresi baharu" sedangkan tiada apa yang merosot.
BASELINE_PROFILE = "mbip-production"

# TC Cetak. Printer Bluetooth mati sendiri selepas 10 minit, dan 5 TC ini
# bertaburan merentasi run 2 jam. Penyelesaiannya BUKAN menerima skip:
# test berhenti, membunyikan bel terminal, dan menunggu printer
# dihidupkan semula. SKIPPED di sini bermakna tiada siapa sempat
# menghidupkannya dalam tempoh menunggu -- keadaan persekitaran, bukan
# kecacatan aplikasi, jadi ia tetap tidak dilaporkan sebagai FAILED.
PRINTER_TCS = {"MBIP-TC-N-002", "MBIP-TC-P-002", "MBIP-TC-K-002",
               "MBIP-TC-L-002", "MBIP-TC-S-002"}

# TC yang tidak boleh berjalan langsung selagi TC lain gagal, kerana ia
# memerlukan rekod yang dicipta oleh TC itu. Melaporkannya sebagai
# kegagalan tersendiri memberi gambaran salah: ia tidak pernah diuji.
#
# Contoh: kesemua TC Sitaan memerlukan rekod dari S-001. Bila S-001 gagal
# (ralat API luar), empat yang lain tidak pernah mendapat peluang.
BLOCKED_BY = {
    "MBIP-TC-S-002": "MBIP-TC-S-001",
    "MBIP-TC-S-003": "MBIP-TC-S-001",
    "MBIP-TC-S-004": "MBIP-TC-S-001",
    "MBIP-TC-S-005": "MBIP-TC-S-001",
}


def apply_blockers(models):
    """Tandakan TC yang tersekat oleh TC lain dalam run yang SAMA.

    Label hanya dikenakan apabila penyekat itu benar-benar gagal dalam run
    ini. Kalau penyekat lulus tetapi TC ini tetap gagal, itu kegagalan
    tersendiri dan mesti kekal kelihatan -- kalau tidak, bug sebenar akan
    tersembunyi di sebalik label 'tersekat'.
    """
    by_id = {m["tcid"]: m for m in models}
    for m in models:
        blocker = BLOCKED_BY.get(m["tcid"])
        if not blocker or m["status"] == "PASSED":
            continue
        b = by_id.get(blocker)
        if not b or b["status"] == "PASSED":
            continue
        short = blocker.replace("MBIP-TC-", "")
        m["action"] = "blocked"
        m["note"] = (f"Show stopper: {short} gagal, jadi tiada rekod untuk "
                     f"TC ini. Tidak pernah benar-benar diuji — akan "
                     f"berjalan sendiri bila {short} pulih.")
    return models
BADGE_CLASS = {"PASSED": "b-pass", "FAILED": "b-fail", "SKIPPED": "b-skip"}

# Dijalankan dalam <head>, SEBELUM apa-apa dilukis. Kalau tema
# ditetapkan oleh skrip di hujung <body>, pengguna tema cerah akan nampak
# kilatan hitam setiap kali halaman dimuat.
HEAD_SCRIPT = """<script>
(function(){
  var t;
  try { t = localStorage.getItem('mbip-theme'); } catch(e) {}
  if (!t) t = window.matchMedia('(prefers-color-scheme: light)').matches
              ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', t);
})();
</script>"""

# Latar bintang beranimasi.
#
# Komponen <Galaxy> asal ialah React + WebGL (ReactBits). Dashboard ini
# satu fail HTML statik tanpa React, bundler, atau capaian npm, jadi
# kesan yang sama dilaksanakan semula dengan canvas 2D biasa memakai
# parameter yang diberi:
#     starSpeed .5   density 1      rotationSpeed .1
#     glowIntensity .3   twinkleIntensity .3
#     saturation 0   -> bintang kelabu/putih, jadi hueShift tiada kesan
#     mouseRepulsion, repulsionStrength 2
#
# Config yang diberi untuk kedua-dua tema adalah sama. Tetapi bintang
# putih di atas latar putih tidak kelihatan langsung, jadi warna zarah
# dibalikkan untuk tema cerah — parameter gerakan kekal serupa.
BACKGROUND_SCRIPT = """<script>
(function(){
  var cv = document.getElementById('bg-galaxy');
  if (!cv) return;
  var ctx = cv.getContext('2d');
  var W = 0, H = 0, DPR = 1, stars = [], raf = null, angle = 0, last = 0;
  var mx = -9999, my = -9999;

  var P = { starSpeed:0.5, density:1, glow:0.3, twinkle:0.3,
            rotation:0.1, repulsion:2 };

  function resize(){
    DPR = Math.min(window.devicePixelRatio || 1, 2);   /* had DPR: skrin 4K */
    W = cv.clientWidth; H = cv.clientHeight;
    cv.width = W * DPR; cv.height = H * DPR;
    ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
    seed();
  }

  function seed(){
    /* Bilangan bintang ikut luas skrin, berpagar supaya skrin besar
       tidak menjadikan halaman berat. */
    var n = Math.min(260, Math.round(W * H / 9000 * P.density));
    stars = [];
    for (var i = 0; i < n; i++){
      var a = Math.random() * Math.PI * 2;
      var r = Math.pow(Math.random(), 0.6) * Math.max(W, H) * 0.62;
      stars.push({ a:a, r:r, sz:Math.random()*1.5+0.35,
                   al:Math.random()*0.5+0.25,
                   tw:Math.random()*Math.PI*2,
                   sp:Math.random()*0.5+0.5, ox:0, oy:0 });
    }
  }

  function colour(){
    return document.documentElement.getAttribute('data-theme') === 'light'
      ? '20,32,56' : '255,255,255';
  }

  function frame(ts){
    var dt = Math.min((ts - last) / 1000 || 0, 0.05); last = ts;
    angle += P.rotation * dt * 0.35;
    ctx.clearRect(0, 0, W, H);

    var cx = W / 2, cy = H / 2, rgb = colour();
    ctx.shadowBlur = 6 * P.glow * 4;
    ctx.shadowColor = 'rgba(' + rgb + ',0.5)';

    for (var i = 0; i < stars.length; i++){
      var s = stars[i];
      s.r += P.starSpeed * s.sp * dt * 7;
      if (s.r > Math.max(W, H) * 0.72){ s.r = 0; s.a = Math.random()*Math.PI*2; }
      s.tw += dt * 2.2 * s.sp;

      var x = cx + Math.cos(s.a + angle) * s.r;
      var y = cy + Math.sin(s.a + angle) * s.r * 0.62;

      /* Tolakan tetikus: zarah menjauh dari kursor, kemudian pulih. */
      var dx = x - mx, dy = y - my, d2 = dx*dx + dy*dy;
      if (d2 < 19000){
        var d = Math.sqrt(d2) || 1, f = (1 - d/138) * P.repulsion * 22;
        s.ox += (dx/d) * f * dt * 6; s.oy += (dy/d) * f * dt * 6;
      }
      s.ox *= 0.92; s.oy *= 0.92;

      var al = s.al * (1 - P.twinkle + P.twinkle * (0.5 + 0.5*Math.sin(s.tw)));
      ctx.fillStyle = 'rgba(' + rgb + ',' + al.toFixed(3) + ')';
      ctx.beginPath();
      ctx.arc(x + s.ox, y + s.oy, s.sz, 0, Math.PI*2);
      ctx.fill();
    }
    raf = requestAnimationFrame(frame);
  }

  function start(){ if (!raf){ last = performance.now();
                              raf = requestAnimationFrame(frame); } }
  function stop(){ if (raf){ cancelAnimationFrame(raf); raf = null; }
                   ctx.clearRect(0, 0, W, H); }

  window.addEventListener('resize', resize);
  window.addEventListener('mousemove', function(e){ mx = e.clientX; my = e.clientY; });
  window.addEventListener('mouseout', function(){ mx = my = -9999; });
  /* Jangan bakar CPU bila tab tidak dilihat. */
  document.addEventListener('visibilitychange', function(){
    if (document.hidden) stop(); else if (window.__bgOn) start();
  });

  window.__bgResize = resize;
  window.__bgStart = start;
  window.__bgStop = stop;
  resize();
})();
</script>"""

STYLE = """<style>
  /* Dua tema. Semua warna melalui pembolehubah -- tiada warna keras
     dalam peraturan di bawah, supaya menukar tema tidak boleh
     meninggalkan satu elemen tersasar dengan warna gelap atas latar
     cerah (atau sebaliknya). */
  :root{
    --bg:#0f1115; --card:#181b22; --line:#2a2f3a; --text:#e8eaf0; --muted:#9aa3b2;
    --pass:#22c55e; --fail:#ef4444; --skip:#eab308; --accent:#3b82f6;
    --warn:#f97316; --beza:#a855f7;
    --th-bg:#1f232c; --row-hover:#1d212a;
    --code-bg:#0b0d12; --code-text:#a5d6ff;
    /* Latar lencana disimpan sebagai pembolehubah penuh (bukan alpha
       atas warna teks) supaya setiap tema boleh melaraskan kelegapannya
       sendiri -- tint yang sesuai atas hitam terlalu pudar atas putih. */
    --pass-bg:rgba(34,197,94,.15);
    --fail-bg:rgba(239,68,68,.15);
    --skip-bg:rgba(234,179,8,.15);
    --accent-bg:rgba(59,130,246,.12);
    --accent-bg-soft:rgba(59,130,246,.07);
    --warn-bg:rgba(249,115,22,.08);
  }
  html[data-theme="light"]{
    --bg:#f5f6f8; --card:#ffffff; --line:#dfe3e9; --text:#16191f; --muted:#5c6572;
    /* Nada lebih gelap daripada versi tema gelap: warna terang yang sama
       tidak cukup kontras atas latar putih. */
    --pass:#15803d; --fail:#dc2626; --skip:#a16207; --accent:#2563eb;
    --warn:#c2410c; --beza:#7e22ce;
    --th-bg:#eef1f5; --row-hover:#f2f5f9;
    --code-bg:#1e2430; --code-text:#bfe0ff;
    --pass-bg:rgba(21,128,61,.11);
    --fail-bg:rgba(220,38,38,.10);
    --skip-bg:rgba(161,98,7,.12);
    --accent-bg:rgba(37,99,235,.10);
    --accent-bg-soft:rgba(37,99,235,.06);
    --warn-bg:rgba(194,65,12,.08);
  }
  *{box-sizing:border-box; margin:0; padding:0;}
  /* Warna latar dipindah ke <html> supaya canvas boleh duduk di antara
     latar dan kandungan (body kekal lutsinar). */
  html{background:var(--bg);}
  body{background:transparent; color:var(--text); font-family:"Segoe UI",system-ui,sans-serif; padding:24px;
       transition:color .15s;}
  #bg-galaxy{position:fixed; inset:0; width:100%; height:100%;
             z-index:-1; pointer-events:none; display:block;}
  body.no-anim #bg-galaxy{display:none;}
  /* Kad dan jadual jadi separa lutsinar supaya bintang menembus sedikit
     tanpa menjejaskan kebolehbacaan teks. */
  .card,table{backdrop-filter:blur(2px);}
  .head{display:flex; justify-content:space-between; align-items:flex-start; gap:16px; flex-wrap:wrap;}
  .head-actions{display:flex; gap:8px; flex-wrap:wrap;}
  h1{font-size:20px; margin-bottom:4px;}
  .sub{color:var(--muted); font-size:13px; margin-bottom:16px; line-height:1.7;}
  .cards{display:flex; gap:12px; flex-wrap:wrap; margin-bottom:20px;}
  .card{background:var(--card); border:1px solid var(--line); border-radius:10px; padding:14px 20px; min-width:120px; cursor:pointer; transition:.15s;}
  .card:hover{border-color:var(--accent);}
  .card.active{border-color:var(--accent); box-shadow:0 0 0 1px var(--accent);}
  .card .num{font-size:26px; font-weight:700;}
  .card .lbl{font-size:12px; color:var(--muted); text-transform:uppercase; letter-spacing:.5px;}
  .num.pass{color:var(--pass);} .num.fail{color:var(--fail);} .num.skip{color:var(--skip);} .num.all{color:var(--accent);} .num.recheck{color:var(--warn);}
  .num.beza{color:var(--beza);}
  .beza-mark{color:var(--beza); font-weight:700; margin-left:6px; cursor:help;}
  tr[data-beza="1"] td:first-child{box-shadow:inset 3px 0 0 var(--beza);}
  .controls{display:flex; gap:10px; flex-wrap:wrap; margin-bottom:14px; align-items:center;}
  select,input[type=text]{background:var(--card); color:var(--text); border:1px solid var(--line); border-radius:8px; padding:8px 12px; font-size:14px;}
  input[type=text]{flex:1; min-width:220px;}
  table{width:100%; border-collapse:collapse; background:var(--card); border-radius:10px; overflow:hidden;}
  th,td{padding:10px 12px; text-align:left; font-size:13.5px; border-bottom:1px solid var(--line); vertical-align:top;}
  th{background:var(--th-bg); color:var(--muted); font-size:12px; text-transform:uppercase; letter-spacing:.5px; position:sticky; top:0;}
  tr:hover td{background:var(--row-hover);}
  .badge{display:inline-block; padding:3px 10px; border-radius:20px; font-size:12px; font-weight:600;}
  .b-pass{background:var(--pass-bg); color:var(--pass);}
  .b-fail{background:var(--fail-bg); color:var(--fail);}
  .b-skip{background:var(--skip-bg); color:var(--skip);}
  .act{font-size:12.5px; color:var(--muted);}
  .act.hot{color:var(--warn); font-weight:600;}
  /* Ralat sebenar run terkini -- dibezakan daripada nota konteks supaya
     jelas mana fakta run ini dan mana latar belakang yang ditulis tangan. */
  .realerr{margin-top:7px; padding:6px 9px; border-left:2px solid var(--fail);
           background:var(--fail-bg); border-radius:0 6px 6px 0;
           font-family:Consolas,monospace; font-size:11.5px;
           color:var(--text); word-break:break-word;}
  .artf-row{margin-top:7px; display:flex; gap:6px; flex-wrap:wrap;}
  .artf{font-family:Consolas,monospace; font-size:11.5px; padding:2px 8px;
        border-radius:20px; background:var(--accent-bg); color:var(--accent);}
  .tcid{font-family:Consolas,monospace; font-size:12.5px; color:var(--accent); white-space:nowrap;}
  .hidden{display:none;}
  .count-line{color:var(--muted); font-size:13px; margin:10px 2px;}

  /* ---- susun atur: sidebar + kandungan ---- */
  .layout{display:flex; gap:22px; align-items:flex-start;}
  .sidebar{position:sticky; top:24px; width:212px; flex:0 0 212px;
           background:var(--card); border:1px solid var(--line);
           border-radius:12px; padding:14px 12px; backdrop-filter:blur(2px);}
  .brand{font-size:12px; letter-spacing:.6px; text-transform:uppercase;
         color:var(--muted); padding:2px 10px 10px;}
  /* min-width:0 wajib -- tanpanya jadual lebar akan menolak sidebar
     keluar daripada susun atur flex. */
  .content{flex:1; min-width:0;}
  .nav{display:block; width:100%; text-align:left; background:none;
       border:none; color:var(--muted); font:inherit; font-size:14px;
       padding:10px 12px; border-radius:8px; cursor:pointer;
       transition:.15s; margin-bottom:2px;}
  .nav:hover{background:var(--row-hover); color:var(--text);}
  .nav.active{background:var(--accent-bg); color:var(--accent); font-weight:600;}
  .nav .n-sub{display:block; font-size:11.5px; font-weight:400;
              color:var(--muted); margin-top:2px;}
  .tabpane{display:none;}
  .tabpane.active{display:block;}
  /* Jadual sejarah ada 10 lajur -- benarkan skrol mendatar dalam ruang
     yang lebih sempit selepas sidebar mengambil tempat. */
  .tbl-wrap{overflow-x:auto;}

  @media (max-width:900px){
    .layout{flex-direction:column;}
    .sidebar{position:static; width:100%; flex:none;
             display:flex; gap:6px; padding:8px;}
    .brand{display:none;}
    .nav{flex:1; text-align:center; margin-bottom:0;}
    .nav .n-sub{display:none;}
  }

  /* ---- toolbar / buttons ---- */
  .toolbar{display:flex; gap:10px; flex-wrap:wrap; margin-bottom:16px;}
  .btn{background:var(--card); color:var(--text); border:1px solid var(--line); border-radius:8px;
       padding:9px 16px; font:inherit; font-size:13.5px; cursor:pointer; transition:.15s;}
  .btn:hover{border-color:var(--accent); color:var(--accent);}
  .btn.primary{border-color:var(--accent); color:var(--accent);}
  .btn.primary:hover{background:var(--accent-bg);}

  /* ---- panduan ---- */
  .g-h{font-size:16px; margin:38px 0 16px; color:var(--accent);
       padding-top:22px; border-top:1px solid var(--line);}
  .g-h:first-child{margin-top:0; padding-top:0; border-top:none;}
  .g-p{font-size:14px; line-height:1.8; margin-bottom:16px;}
  .g-list{margin:0 0 20px 22px; font-size:14px; line-height:1.9;}
  .g-list li{margin-bottom:4px;}
  /* ---- panduan: lajur dipusatkan ---- */
  #tab-panduan{max-width:940px; margin:0 auto;}

  /* ---- panduan: diagram alur (SVG) ---- */
  /* viewBox mengendalikan penskalaan; had lebar menghalangnya membesar
     sampai teks nampak terlalu gemuk pada monitor lebar. */
  .flow-svg{width:100%; height:auto; display:block; margin:0 0 26px;}

  /* ---- panduan: tetingkap terminal ---- */
  .term{border:1px solid var(--line); border-radius:10px; overflow:hidden;
        margin:0 0 20px; background:var(--code-bg);}
  .t-bar{display:flex; align-items:center; gap:7px; padding:8px 12px;
         background:var(--th-bg); border-bottom:1px solid var(--line);}
  .t-dot{width:10px; height:10px; border-radius:50%; display:inline-block; flex:0 0 auto;}
  .d1{background:#ff5f56;} .d2{background:#ffbd2e;} .d3{background:#27c93f;}
  .t-name{flex:1; font-size:12px; color:var(--muted); margin-left:6px;
          font-family:Consolas,monospace;}
  .t-body{padding:15px 16px; font-family:Consolas,monospace; font-size:13px;
          color:var(--code-text); line-height:2.0;}
  .t-line{white-space:pre-wrap; word-break:break-word;}
  /* Prompt hanya untuk arahan. Blok kandungan fail (.is-file) tiada
     prompt -- meletakkan "&gt;" di hadapan setiap baris JSON akan
     menjadikannya kelihatan seperti sesuatu yang patut ditaip. */
  .term:not(.is-file) .t-line::before{content:"> "; color:var(--muted);}

  /* ---- panduan: tangkap skrin ---- */
  .shot{margin:0 0 22px;}
  .shot img{width:100%; height:auto; display:block; border-radius:10px;
            border:1px solid var(--line);}
  .shot figcaption{font-size:12px; color:var(--muted); margin-top:7px;
                   text-align:center;}

  /* ---- panduan: output yang dijangka ---- */
  .t-live{font-size:10.5px; font-weight:700; letter-spacing:.5px;
          text-transform:uppercase; color:var(--pass);
          background:var(--pass-bg); padding:2px 8px; border-radius:20px;}
  .o-line{white-space:pre-wrap; word-break:break-word; color:var(--muted);}
  .o-tag{color:var(--code-text);}
  .o-prompt{color:var(--pass); font-weight:600;}
  /* Kursor berkelip: tunjukkan bahawa proses masih berjalan dan memang
     tidak kembali ke prompt -- itu yang paling kerap disangka tergantung. */
  .o-caret{color:var(--pass); animation:blink 1.1s step-end infinite;}
  @keyframes blink{50%{opacity:0;}}
  body.no-anim .o-caret{animation:none;}

  /* ---- panduan: ikon ---- */
  .ic{width:22px; height:22px; flex:0 0 auto;}
  .ic.sm{width:15px; height:15px; vertical-align:-2px;}

  /* ---- panduan: kad berikon ---- */
  .gcards{display:grid; grid-template-columns:repeat(auto-fit,minmax(215px,1fr));
          gap:14px; margin:0 0 22px;}
  .gcard{background:var(--card); border:1px solid var(--line);
         border-radius:10px; padding:18px 18px 19px;}
  .gcard .ic{color:var(--accent); margin-bottom:12px;}
  .gc-t{font-size:13.5px; font-weight:600; margin-bottom:6px;}
  .gc-d{font-size:12.5px; color:var(--muted); line-height:1.75;}

  /* ---- panduan: legend status ---- */
  .legend{display:grid; grid-template-columns:auto auto 1fr; gap:14px 14px;
          align-items:center; margin:0 0 22px;}
  .lg-ic{display:flex;} .lg-t{font-size:12.5px; font-weight:700;}
  .lg-d{font-size:13px; color:var(--muted);}
  .pass{color:var(--pass);} .fail{color:var(--fail);}
  .skip{color:var(--skip);} .warn{color:var(--warn);}

  /* ---- panduan: jadual dua lajur ---- */
  .pairs{display:grid; grid-template-columns:minmax(120px,auto) 1fr;
         gap:14px 22px; margin:0 0 22px; font-size:13.5px;
         line-height:1.7;}
  .pr-k{color:var(--text); font-weight:600;}
  .pr-v{color:var(--muted);}
  @media (max-width:620px){ .pairs{grid-template-columns:1fr; gap:2px 0;}
                            .pr-v{margin-bottom:8px;} }

  .g-copy{background:var(--card); color:var(--muted); border:1px solid var(--line); border-radius:6px;
          padding:4px 12px; font:inherit; font-size:12px; cursor:pointer; white-space:nowrap;}
  .g-copy:hover{border-color:var(--accent); color:var(--accent);}
  .g-note{border-left:3px solid var(--accent); background:var(--accent-bg-soft); padding:13px 16px;
          margin:0 0 20px; font-size:13.5px; line-height:1.75;}
  .g-warn{border-left:3px solid var(--warn); background:var(--warn-bg); padding:13px 16px;
          margin:0 0 20px; font-size:13.5px; line-height:1.75;}

  /* ---- sejarah / pipeline ---- */
  .hist-note{color:var(--muted); font-size:13px; margin-bottom:14px; line-height:1.7;}
  .muted-cell{color:var(--muted); font-size:12.5px; font-style:italic;}
  .pill{display:inline-block; padding:2px 9px; border-radius:20px;
        font-size:11.5px; font-weight:600;}
  .pill-ok{background:var(--pass-bg); color:var(--pass);}
  .pill-warn{background:var(--warn-bg); color:var(--warn);}
  .delta-up{color:var(--pass); font-weight:600;}
  .delta-down{color:var(--fail); font-weight:600;}
  .delta-same{color:var(--muted);}

  @media print{
    body{background:#fff; color:#000; padding:0;}
    .card,table{background:#fff; border-color:#ccc;}
    th{background:#eee; color:#000; position:static;}
    html{background:#fff;}
    #bg-galaxy{display:none !important;}
    .card,table{backdrop-filter:none;}
    .sidebar,.toolbar,.controls,.g-copy,.head-actions{display:none !important;}
    .layout{display:block;}
    .tbl-wrap{overflow:visible;}
    .tabpane{display:block !important;}
    .sub,.act,.count-line{color:#333;}
    tr{page-break-inside:avoid;}
  }
</style>"""

CONTROLS_TMPL = """<div class="controls">
__PROFILE_SELECT__
  <select id="f-action">
    <option value="">Semua tindakan</option>
    <option value="ok">OK — tiada tindakan</option>
    <option value="printer">Manual: perlu printer</option>
    <option value="dev">Refer dev team (bug app/server)</option>
    <option value="rerun">Rerun untuk confirm</option>
    <option value="arahan">Skip atas arahan</option>
    <option value="blocked">Show stopper — tersekat</option>
  </select>
  <select id="f-cat">
    <option value="">Semua kategori</option>
    <option value="T">T — Tetapan/Selaras</option>
    <option value="N">N — Notis Amaran</option>
    <option value="P">P — Kompaun Pelbagai</option>
    <option value="K">K — Letak Kereta</option>
    <option value="L">L — Kompaun Lesen</option>
    <option value="S">S — Sitaan</option>
    <option value="SK">SK — Senarai</option>
    <option value="H">H — Hantar</option>
    <option value="TN">TN — Tarik Notis</option>
    <option value="NK">NK — Notis ke Kompaun</option>
  </select>
  <input type="text" id="f-search" placeholder="Cari nama / TC ID / nota...">
</div>"""

def render_controls(runs):
    """Penapis untuk tab Laporan.

    Dropdown PBT dan Versi sentiasa dipaparkan, walaupun setakat ini
    hanya ada satu pilihan: kawalan yang tersembunyi ialah kawalan yang
    tiada siapa tahu wujud. Senarai versi diisi semula oleh JS setiap
    kali PBT bertukar.
    """
    opts = "".join(
        f'<option value="{html.escape(name)}">'
        f'{html.escape(lst[0].get("profile_label") or name)}</option>'
        for name, lst in runs.items()
    ) or '<option value="">(tiada run)</option>'
    sel = (f'  <select id="f-profile" title="PBT / environment">{opts}</select>\n'
           f'  <select id="f-run" title="Versi app / masa run"></select>\n')
    return CONTROLS_TMPL.replace("__PROFILE_SELECT__", sel)


SCRIPT_TMPL = """<script>
const TOTAL = __TOTAL__;
const RUN_META = __RUN_META__;
const RUNS = __RUNS__;
const rows = [...document.querySelectorAll('#tbl tbody tr')];
const histRows = [...document.querySelectorAll('#hist-tbl tbody tr')];
const fProfile = document.getElementById('f-profile');
const fRun = document.getElementById('f-run');
let profileFilter = __DEFAULT_PROFILE__;
let runFilter = (RUNS[profileFilter] || [{key:''}])[0].key;
const cards = [...document.querySelectorAll('.card')];
const fAction = document.getElementById('f-action');
const fCat = document.getElementById('f-cat');
const fSearch = document.getElementById('f-search');
let statusFilter = 'all';

/* ---- tema gelap / cerah ---- */
/* Pilihan disimpan supaya tak perlu ditetapkan semula setiap kali
   laporan dibuka. Kalau localStorage disekat (mod privasi), toggle
   tetap berfungsi untuk sesi semasa. */
function applyTheme(t){
  document.documentElement.setAttribute('data-theme', t);
  const b = document.getElementById('btn-theme');
  if (b) b.textContent = (t === 'light') ? '\\u263D  Mod Gelap' : '\\u2600  Mod Cerah';
  try { localStorage.setItem('mbip-theme', t); } catch(e) {}
}
applyTheme(document.documentElement.getAttribute('data-theme') || 'dark');
document.getElementById('btn-theme').addEventListener('click', () => {
  const now = document.documentElement.getAttribute('data-theme');
  applyTheme(now === 'light' ? 'dark' : 'light');
});

/* ---- latar beranimasi ---- */
/* Lalai MATI kalau sistem pengguna minta kurangkan gerakan -- animasi
   boleh menyebabkan pening bagi sesetengah orang, jadi ia tidak patut
   dihidupkan tanpa diminta. Pilihan pengguna mengatasi lalai ini. */
function applyBg(on){
  window.__bgOn = on;
  document.body.classList.toggle('no-anim', !on);
  const b = document.getElementById('btn-bg');
  if (b) b.textContent = on ? '\\u2726  Latar: Hidup' : '\\u2726  Latar: Mati';
  if (on) { window.__bgResize(); window.__bgStart(); } else { window.__bgStop(); }
  try { localStorage.setItem('mbip-bg', on ? '1' : '0'); } catch(e) {}
}
let bgSaved = null;
try { bgSaved = localStorage.getItem('mbip-bg'); } catch(e) {}
const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
applyBg(bgSaved === null ? !reduceMotion : bgSaved === '1');
document.getElementById('btn-bg').addEventListener('click',
  () => applyBg(!window.__bgOn));

/* ---- navigasi sidebar ---- */
document.querySelectorAll('.nav').forEach(t => {
  t.addEventListener('click', () => {
    document.querySelectorAll('.nav').forEach(x => x.classList.remove('active'));
    document.querySelectorAll('.tabpane').forEach(x => x.classList.remove('active'));
    t.classList.add('active');
    document.getElementById('tab-' + t.dataset.tab).classList.add('active');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });
});

/* ---- salin arahan dalam Panduan ---- */
document.querySelectorAll('.g-copy').forEach(b => {
  b.addEventListener('click', () => {
    navigator.clipboard.writeText(b.dataset.copy).then(() => {
      const old = b.textContent;
      b.textContent = 'Disalin!';
      setTimeout(() => { b.textContent = old; }, 1400);
    });
  });
});

/* ---- penapis laporan ---- */
cards.forEach(c => c.addEventListener('click', () => {
  cards.forEach(x => x.classList.remove('active'));
  c.classList.add('active');
  statusFilter = c.dataset.filter;
  apply();
}));
fAction.addEventListener('change', apply);
fCat.addEventListener('change', apply);
fSearch.addEventListener('input', apply);
/* Senarai versi diisi semula setiap kali PBT bertukar: setiap PBT ada
   sejarah run sendiri, jadi pilihan versi tidak boleh statik. */
function fillRuns(keep){
  if (!fRun) return;
  const list = RUNS[profileFilter] || [];
  fRun.innerHTML = list.map(r =>
    '<option value="' + r.key + '">' + r.label + '</option>').join('')
    || '<option value="">(tiada run)</option>';
  runFilter = (keep && list.some(r => r.key === keep)) ? keep
            : (list[0] ? list[0].key : '');
  fRun.value = runFilter;
  fRun.disabled = list.length < 2;
}

if (fProfile) {
  fProfile.value = profileFilter;
  fProfile.addEventListener('change', () => {
    profileFilter = fProfile.value;
    fillRuns();
    updateCards(); updateMeta(); apply();
  });
}
if (fRun) {
  fRun.addEventListener('change', () => {
    runFilter = fRun.value;
    updateCards(); updateMeta(); apply();
  });
}

function visibleRows(){ return rows.filter(r => !r.classList.contains('hidden')); }

/* Baris run terpilih sahaja — asas untuk kad ringkasan. */
function profileRows(){ return rows.filter(r => r.dataset.run === runFilter); }

/* Kad dikira semula setiap kali PBT bertukar: nombor tetap milik
   satu PBT, bukan campuran semua. */
function updateCards(){
  const mine = profileRows();
  const n = s => mine.filter(r => r.dataset.status === s).length;
  const set = (id, v) => { const el = document.getElementById(id); if (el) el.textContent = v; };
  set('c-all', mine.length);
  set('c-pass', n('PASSED'));
  set('c-fail', mine.filter(r => ['FAILED','ERROR','NOT RUN'].includes(r.dataset.status)).length);
  set('c-skip', n('SKIPPED'));
  set('c-recheck', mine.filter(r => r.dataset.recheck === '1').length);
  set('c-beza', mine.filter(r => r.dataset.beza === '1').length);
}

function updateMeta(){
  const el = document.getElementById('run-meta');
  if (el && RUN_META[runFilter]) el.innerHTML = RUN_META[runFilter];
  histRows.forEach(r => r.classList.remove('hidden'));
}

function apply(){
  const q = fSearch.value.toLowerCase();
  let shown = 0;
  const mine = profileRows();
  rows.forEach(r => {
    let ok = r.dataset.run === runFilter;
    if (ok && statusFilter === 'recheck') ok = r.dataset.recheck === '1';
    else if (ok && statusFilter === 'beza') ok = r.dataset.beza === '1';
    else if (ok && statusFilter !== 'all') ok = r.dataset.status === statusFilter;
    if (ok && fAction.value) ok = r.dataset.action === fAction.value;
    if (ok && fCat.value) ok = r.dataset.cat === fCat.value;
    if (ok && q) ok = r.textContent.toLowerCase().includes(q);
    r.classList.toggle('hidden', !ok);
    if (ok) shown++;
  });
  document.getElementById('count-line').textContent =
    shown + ' / ' + mine.length + ' test case dipaparkan';
}
fillRuns(runFilter);
updateCards();
updateMeta();
apply();

/* ---- export CSV (ikut penapis yang aktif) ---- */
function csvCell(s){
  s = (s == null ? '' : String(s)).replace(/\\s+/g, ' ').trim();
  return '"' + s.replace(/"/g, '""') + '"';
}
document.getElementById('btn-csv').addEventListener('click', () => {
  const head = ['No','TC ID','Nama','Status','Tindakan','Nota'];
  const lines = [head.map(csvCell).join(',')];
  visibleRows().forEach(r => {
    lines.push([...r.querySelectorAll('td')].map(td => csvCell(td.textContent)).join(','));
  });
  /* BOM supaya Excel baca UTF-8 dengan betul */
  const blob = new Blob(['\\uFEFF' + lines.join('\\r\\n')], {type:'text/csv;charset=utf-8;'});
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'laporan-' + profileFilter + '-__STAMP__.csv';
  a.click();
  URL.revokeObjectURL(a.href);
});

document.getElementById('btn-print').addEventListener('click', () => window.print());
</script>"""


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def fmt_duration(dur):
    if not isinstance(dur, (int, float)):
        return ""
    h, mnt, s = int(dur // 3600), int((dur % 3600) // 60), int(dur % 60)
    return f"{h}j {mnt}m {s}s" if h else f"{mnt}m {s}s"


def resolve_row(entry, results, ver, use_baseline=True):
    """Return the render model for one TC: status, action, recheck, note.

    `use_baseline` sengaja boleh dimatikan. Garis dasar 26/16/6 itu milik
    MBIP (dari phase3_report.md) — memakainya pada PBT lain akan
    menandakan setiap perbezaan sebagai "regresi", sedangkan PBT itu
    memang tidak pernah ada garis dasar untuk dibandingkan.
    """
    no, tcid, nama, cat, baseline, forced, base_note = entry
    base_note = base_note.replace("{ver}", ver)

    if forced:
        action, note = forced
        return {"no": no, "tcid": tcid, "nama": nama, "cat": cat,
                "status": "SKIPPED", "action": action,
                "note": note.replace("{ver}", ver), "changed": False}

    status = results.get(tcid, "NOT RUN")
    changed = use_baseline and status != baseline

    if status == "PASSED":
        action = "ok"
    elif status == "SKIPPED" and tcid in PRINTER_TCS:
        # Printer tidur -- perlu dicuba semula dengan printer dikejutkan,
        # bukan dirujuk kepada dev team.
        action = "printer"
    elif status == "SKIPPED":
        action = "rerun"
    else:
        if baseline == "FAILED" and tcid != "MBIP-TC-T-011":
            action = "dev"
        else:
            action = "rerun"

    if not changed:
        note = base_note
    elif status == "PASSED":
        note = ("\U0001F501 Regresi PULIH — baseline FAILED, PASS run ni "
                "(kemungkinan APK fix). Sahkan manual & update note.")
    elif status in ("FAILED", "ERROR"):
        note = ("\U0001F501 Regresi BAHARU — baseline " + baseline + ", " +
                status + " run ni. Confirm dengan rerun & check "
                "last_run.txt.")
    else:
        note = ("\U0001F501 Status berubah — baseline " + baseline + ", " +
                status + " run ni. Check last_run.txt.")

    # Caveat skop sentiasa dikekalkan, walau apa pun status run ini.
    caveat = SCOPE_CAVEAT.get(tcid)
    if caveat and caveat not in note:
        note = note + caveat

    return {"no": no, "tcid": tcid, "nama": nama, "cat": cat,
            "status": status, "action": action, "note": note,
            "changed": changed}


# Peta status automation -> hasil setara dalam istilah tester manual,
# supaya kedua-duanya boleh dibandingkan secara adil.
def _setara(status):
    if status == "PASSED":
        return "Pass"
    if status in ("FAILED", "ERROR"):
        return "Fail"
    return None                      # SKIPPED / NOT RUN: tiada bandingan


def render_row(m, profile, rkey, manual=None, reason="", artifact=None):
    """Satu baris TC. `manual` = entri status_per_tc dari Excel, jika ada.

    Perbandingan bersebelahan ini ada satu tujuan: mencari di mana
    automation dan tester manual TIDAK sependapat. Persetujuan tidak
    memberitahu apa-apa yang baharu; percanggahan sentiasa bermakna salah
    satu daripada dua perkara yang kedua-duanya penting — sama ada bug
    sudah dibaiki sejak ujian manual, atau automation tersilap.
    """
    status = m["status"]
    badge_cls = BADGE_CLASS.get(status, "b-fail")
    action = m["action"]
    recheck = action in RECHECK_ACTIONS
    act_cls = "act hot" if recheck else "act"
    recheck_attr = ' data-recheck="1"' if recheck else ""

    # Nota = konteks yang ditulis tangan + ralat SEBENAR run ini.
    # Nota tangan sahaja boleh menyesatkan: ia terus memaparkan sebab lama
    # walaupun TC kini gagal atas sebab yang berbeza.
    note_cell = html.escape(m["note"])
    if artifact:
        chips = " ".join(
            f'<span class="artf" title="{html.escape(k)}">'
            f'{html.escape(str(v))}</span>' for k, v in artifact.items())
        note_cell += f'<div class="artf-row">{chips}</div>'
    if reason:
        note_cell += (f'<div class="realerr" title="Ralat sebenar run ini">'
                      f'{html.escape(reason)}</div>')

    m_st = (manual or {}).get("status") or ""
    auto_eq = _setara(status)
    beza = bool(m_st and auto_eq and m_st.lower() != auto_eq.lower())
    beza_attr = ' data-beza="1"' if beza else ""

    if not m_st:
        manual_cell = '<span class="muted-cell">—</span>'
    else:
        cls = "b-pass" if m_st.lower() == "pass" else "b-fail"
        arrow = ""
        if beza:
            arrow = ('<span class="beza-mark" title="Automation dan '
                     'tester manual tidak sependapat">&#8800;</span>')
        manual_cell = f'<span class="badge {cls}">{html.escape(m_st)}</span>{arrow}'

    return (
        f'<tr data-profile="{html.escape(profile)}" '
        f'data-run="{html.escape(rkey)}" '
        f'data-status="{status}" data-action="{action}" '
        f'data-cat="{m["cat"]}"{recheck_attr}{beza_attr}>'
        f'<td>{m["no"]}</td>'
        f'<td class="tcid">{html.escape(m["tcid"])}</td>'
        f'<td>{html.escape(m["nama"])}</td>'
        f'<td><span class="badge {badge_cls}">{html.escape(status)}</span></td>'
        f'<td>{manual_cell}</td>'
        f'<td class="{act_cls}">{html.escape(ACTION_TEXT.get(action, action))}</td>'
        f'<td class="act">{note_cell}</td>'
        f'</tr>'
    )


# ---------------------------------------------------------------------------
# Run history
# ---------------------------------------------------------------------------

def archive_run(data, n_pass, n_fail, n_skip):
    """Append this run to reports/history/.

    Stores the RESOLVED counts (forced-skips already applied), not the raw
    pytest tallies, so the history table can never disagree with the cards
    at the top of the report.

    Menyimpan juga keputusan penuh per-TC dan profil PBT: laporan
    memaparkan run TERKINI bagi SETIAP PBT pada satu halaman, jadi setiap
    entri sejarah mesti membawa cukup data untuk dirender sendiri.

    Kunci fail = profil + masa + tester. Profil disertakan supaya run MBIP
    dan run PBT lain tidak boleh menimpa satu sama lain.
    """
    os.makedirs(HISTORY_DIR, exist_ok=True)
    stamp = data.get("generated_at", "?")
    tester = data.get("tester") or "unknown"
    prof = data.get("profile") or "tanpa-profil"
    entry = {
        "generated_at": stamp,
        "tester": tester,
        "profile": prof,
        "profile_label": data.get("profile_label") or prof,
        "pbt": data.get("pbt") or "?",
        "env": data.get("env") or "?",
        "device_udid": data.get("device_udid"),
        "device_model": data.get("device_model"),
        "app_version": data.get("app_version"),
        "duration_seconds": data.get("duration_seconds"),
        "passed": n_pass, "failed": n_fail, "skipped": n_skip,
        "results": data.get("results", {}),
        "reasons": data.get("reasons", {}),
        "artifacts": data.get("artifacts", {}),
    }
    safe = re.sub(r"[^0-9A-Za-z-]", "-", f"{prof}_{stamp}_{tester}")
    with open(os.path.join(HISTORY_DIR, f"{safe}.json"), "w",
              encoding="utf-8") as fh:
        json.dump(entry, fh, indent=2, ensure_ascii=False)
    return entry


def load_profiles():
    """Semua profil dalam profiles/, tanpa memilih mana-mana.

    Sengaja membaca JSON terus dan BUKAN memanggil profile.load(): fungsi
    itu menolak untuk memilih apabila ada lebih daripada satu profil (dan
    betul begitu untuk menjalankan ujian), tetapi di sini kita memang
    mahu kesemuanya sekali gus.
    """
    out = {}
    if not os.path.isdir(PROFILES_DIR):
        return out
    for f in sorted(os.listdir(PROFILES_DIR)):
        if not f.endswith(".json"):
            continue
        try:
            with open(os.path.join(PROFILES_DIR, f), encoding="utf-8") as fh:
                p = json.load(fh)
        except Exception:                               # noqa: BLE001
            continue
        p["_name"] = os.path.splitext(f)[0]
        p["_belum_lengkap"] = sorted(
            k for k, v in p.items()
            if not k.startswith("_") and str(v).strip() == "ISI-SINI")
        out[p["_name"]] = p
    return out


def load_pipeline():
    """Snapshot folder shared, kalau ada (tools/extract_pipeline.py)."""
    try:
        with open(PIPELINE_JSON, encoding="utf-8") as fh:
            return json.load(fh)
    except Exception:                                   # noqa: BLE001
        return None


def render_pipeline(profiles, pipeline, latest):
    """Satu baris bagi setiap slot PBT×environment.

    Ini menjawab soalan yang tab Laporan tidak boleh jawab: PBT yang
    BELUM ada run automation langsung tidak muncul di sana, jadi tiada
    cara untuk nampak sejauh mana liputan automation merentasi pipeline.
    """
    if not profiles:
        return ('<div class="hist-note">Tiada profil dalam '
                '<code>profiles/</code>.</div>')

    pj = (pipeline or {}).get("pbt", {})
    rows = []
    for name, p in sorted(profiles.items(),
                          key=lambda kv: (kv[1].get("pbt", ""),
                                          kv[1].get("env", ""))):
        pbt, env = p.get("pbt", "?"), p.get("env", "?")
        info = pj.get(pbt, {})
        sc = info.get("script") or {}
        apk = (info.get("apk") or {}).get(env) or {}

        run = latest.get(name)
        if run:
            auto = (f'<span class="badge b-pass">{run.get("passed",0)}</span> '
                    f'<span class="badge b-fail">{run.get("failed",0)}</span> '
                    f'<span class="badge b-skip">{run.get("skipped",0)}</span>')
            bila = (run.get("generated_at") or "?").replace("T", " ")[:16]
        else:
            auto = '<span class="muted-cell">belum dijalankan</span>'
            bila = "—"

        if p["_belum_lengkap"]:
            sedia = (f'<span class="pill pill-warn">belum lengkap</span>'
                     f'<span class="n-sub">{", ".join(p["_belum_lengkap"])}</span>')
        else:
            sedia = '<span class="pill pill-ok">sedia</span>'

        skrip = str(sc.get("version") or "—")
        if sc.get("tc_count"):
            skrip += f" ({sc['tc_count']} TC)"

        rows.append(
            "<tr>"
            f"<td><b>{html.escape(pbt)}</b></td>"
            f"<td>{html.escape(env)}</td>"
            f"<td>{sedia}</td>"
            f"<td class='act'>{html.escape(skrip)}</td>"
            f"<td class='act'>{html.escape(str(apk.get('versi') or '—'))}</td>"
            f"<td>{auto}</td>"
            f"<td class='act'>{html.escape(bila)}</td>"
            "</tr>"
        )

    ada_run = sum(1 for n in profiles if n in latest)
    src = ""
    if pipeline:
        src = (f' Versi Excel dan APK diambil dari snapshot folder shared '
               f'({html.escape((pipeline.get("dijana") or "")[:10])}) — '
               f'jalankan <code>python tools/extract_pipeline.py</code> '
               f'untuk menyegarkan.')
    return (
        f'<div class="hist-note">{ada_run} daripada {len(profiles)} slot '
        f'PBT×environment sudah ada run automation.{src}</div>'
        '<div class="tbl-wrap"><table><thead><tr>'
        '<th>PBT</th><th>Env</th><th>Profil</th><th>Test Script</th>'
        '<th>APK</th><th>Automation (P/F/S)</th><th>Run terakhir</th>'
        '</tr></thead><tbody>' + "\n".join(rows) + '</tbody></table></div>'
    )


def latest_per_profile(hist):
    """Run terkini bagi setiap profil, ikut susunan label."""
    seen = {}
    for e in hist:                      # hist sudah newest-first
        p = e.get("profile") or "tanpa-profil"
        if p not in seen:
            seen[p] = e
    return dict(sorted(seen.items(),
                       key=lambda kv: kv[1].get("profile_label") or kv[0]))


# Berapa banyak run lampau dibenamkan ke dalam halaman bagi setiap PBT.
# Setiap run menambah 48 baris jadual; sejarah penuh kekal di cakera
# dalam reports/history/ dan tetap disenaraikan dalam tab Sejarah Run.
MAX_RUNS_PER_PROFILE = 10


def run_key(e):
    return f"{e.get('profile') or 'tanpa-profil'}|{e.get('generated_at') or '?'}"


def runs_for_report(hist):
    """Run yang boleh dipilih dalam tab Laporan: {profil: [entri, ...]}.

    Terbaharu dahulu, dipagar pada MAX_RUNS_PER_PROFILE supaya halaman
    tidak membengkak apabila sejarah bertambah panjang.
    """
    by_prof = {}
    for e in hist:                      # hist sudah newest-first
        p = e.get("profile") or "tanpa-profil"
        lst = by_prof.setdefault(p, [])
        if len(lst) < MAX_RUNS_PER_PROFILE:
            lst.append(e)
    return dict(sorted(
        by_prof.items(),
        key=lambda kv: kv[1][0].get("profile_label") or kv[0]))


def load_history():
    """Every archived run, newest first."""
    if not os.path.isdir(HISTORY_DIR):
        return []
    out = []
    for name in os.listdir(HISTORY_DIR):
        if not name.endswith(".json"):
            continue
        try:
            with open(os.path.join(HISTORY_DIR, name), encoding="utf-8") as fh:
                out.append(json.load(fh))
        except Exception:                               # noqa: BLE001
            continue                                    # abaikan fail rosak
    out.sort(key=lambda e: e.get("generated_at") or "", reverse=True)
    return out


def render_history(hist):
    if not hist:
        return ('<div class="hist-note">Belum ada sejarah run. Run '
                'pertama akan direkodkan di sini.</div>')

    # Delta dikira dalam PBT yang SAMA sahaja. Membandingkan run MBIP
    # dengan run PBT lain yang kebetulan berlaku sebelumnya akan
    # menghasilkan "+3 passed" yang tidak bermakna langsung.
    seen_prof = {}
    rows = []
    for e in hist:
        prof = e.get("profile") or "tanpa-profil"
        prev = seen_prof.get(prof)
        seen_prof[prof] = e

        if prev is None:
            delta = '<span class="delta-same">—</span>'
        else:
            d = (e.get("passed") or 0) - (prev.get("passed") or 0)
            if d > 0:
                delta = f'<span class="delta-up">+{d} passed</span>'
            elif d < 0:
                delta = f'<span class="delta-down">{d} passed</span>'
            else:
                delta = '<span class="delta-same">tiada perubahan</span>'

        stamp = (e.get("generated_at") or "?").replace("T", " ")
        model = e.get("device_model") or ""
        udid = e.get("device_udid") or "?"
        dev = f"{model} ({udid})" if model else udid
        rows.append(
            f'<tr data-profile="{html.escape(prof)}">'
            f"<td>{html.escape(stamp)}</td>"
            f"<td>{html.escape(str(e.get('profile_label') or prof))}</td>"
            f"<td>{html.escape(str(e.get('tester') or '?'))}</td>"
            f"<td>{html.escape(str(e.get('app_version') or '?'))}</td>"
            f'<td><span class="badge b-pass">{e.get("passed", 0)}</span></td>'
            f'<td><span class="badge b-fail">{e.get("failed", 0)}</span></td>'
            f'<td><span class="badge b-skip">{e.get("skipped", 0)}</span></td>'
            f"<td class='act'>{html.escape(fmt_duration(e.get('duration_seconds')))}</td>"
            f"<td class='act'>{delta}</td>"
            f"<td class='act'>{html.escape(dev)}</td>"
            "</tr>"
        )

    n_prof = len(seen_prof)
    return (
        f'<div class="hist-note">{len(hist)} run direkodkan merentasi '
        f'{n_prof} PBT/environment. Disimpan automatik dalam '
        f'<code>reports/history/</code>, termasuk run ahli team lain. '
        f'Lajur "Berbanding run sebelum" membandingkan dalam PBT yang '
        f'sama sahaja.</div>'
        '<div class="tbl-wrap"><table id="hist-tbl"><thead><tr>'
        '<th>Tarikh / Masa</th><th>PBT / Env</th><th>Tester</th>'
        '<th>App Build</th>'
        '<th>Passed</th><th>Failed</th><th>Skipped</th>'
        '<th>Tempoh</th><th>Berbanding run sebelum</th><th>Device</th>'
        '</tr></thead><tbody>' + "\n".join(rows) + '</tbody></table></div>'
    )


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    with open(RESULTS_JSON, encoding="utf-8") as fh:
        data = json.load(fh)

    results = data.get("results", {})
    generated_at = data.get("generated_at", "?")
    dur = data.get("duration_seconds")
    tester = data.get("tester") or "?"
    app_ver = data.get("app_version") or "?"
    udid = data.get("device_udid") or "?"
    model = data.get("device_model") or ""

    n_pass = n_fail = n_skip = n_recheck = n_changed = 0
    total = len(META)

    archive_run(data, 0, 0, 0)          # sementara — dikemas kini di bawah
    hist = load_history()
    profiles = latest_per_profile(hist)

    # Satu halaman, semua PBT. Setiap baris ditanda dengan profilnya;
    # dropdown PBT menapis guna enjin penapis sedia ada.
    pipeline = load_pipeline()
    runs = runs_for_report(hist)
    rows_all, run_meta, runs_js = [], {}, {}

    for pname, entries in runs.items():
      runs_js[pname] = []
      for entry in entries:
        rkey = run_key(entry)
        p_results = entry.get("results", {})
        p_ver = entry.get("app_version") or "?"
        # Status manual dari Excel PBT berkenaan. Kunci dinormalkan
        # (TC-T-001) supaya awalan PBT yang berbeza tetap padan.
        p_manual = (((pipeline or {}).get("pbt", {})
                     .get(entry.get("pbt") or "", {})
                     .get("script") or {}).get("status_per_tc") or {})
        # Garis dasar 26/16/6 milik MBIP sahaja — lihat resolve_row().
        use_base = entry.get("profile") == BASELINE_PROFILE
        p_models = apply_blockers(
            [resolve_row(e, p_results, p_ver, use_base) for e in META])

        rows_all.extend(
            render_row(m, pname, rkey,
                       p_manual.get(re.sub(r"^[A-Z]+-TC-", "TC-", m["tcid"])),
                       reason=(entry.get("reasons") or {}).get(m["tcid"], ""),
                       artifact=(entry.get("artifacts") or {}).get(m["tcid"]))
            for m in p_models)

        p_pass = sum(1 for m in p_models if m["status"] == "PASSED")
        p_fail = sum(1 for m in p_models
                     if m["status"] in ("FAILED", "ERROR", "NOT RUN"))
        p_skip = sum(1 for m in p_models if m["status"] == "SKIPPED")
        p_chg = sum(1 for m in p_models if m["changed"])

        p_model = entry.get("device_model") or ""
        p_udid = entry.get("device_udid") or "?"
        p_dev = f"{p_model} ({p_udid})" if p_model else p_udid
        p_dur = fmt_duration(entry.get("duration_seconds"))
        base_txt = (f" &nbsp;•&nbsp; {p_chg} status berubah vs baseline"
                    if use_base else
                    " &nbsp;•&nbsp; tiada baseline untuk run ini")
        run_meta[rkey] = (
            f"Run oleh <b>{html.escape(str(entry.get('tester') or '?'))}</b> "
            f"pada {html.escape(entry.get('generated_at') or '?')}"
            f"{f' ({p_dur})' if p_dur else ''} &nbsp;•&nbsp; "
            f"App build <b>{html.escape(str(p_ver))}</b> &nbsp;•&nbsp; "
            f"Device {html.escape(p_dev)}{base_txt}"
        )

        # Label dropdown versi: build dahulu (itu yang dicari), diikuti
        # tarikh dan tester untuk membezakan beberapa run pada build sama.
        when = (entry.get("generated_at") or "?").replace("T", " ")[5:16]
        runs_js[pname].append({
            "key": rkey,
            "label": f"{p_ver} — {when} ({entry.get('tester') or '?'})",
        })

        # Kad awal: run TERKINI bagi profil semasa (entri pertama).
        if pname == (data.get("profile") or "tanpa-profil") \
                and len(runs_js[pname]) == 1:
            n_pass, n_fail, n_skip, n_changed = p_pass, p_fail, p_skip, p_chg
            n_recheck = sum(1 for m in p_models
                            if m["action"] in RECHECK_ACTIONS)

    # Kemas kini entri sejarah run ini dengan kiraan sebenar.
    archive_run(data, n_pass, n_fail, n_skip)
    hist = load_history()
    profiles = latest_per_profile(hist)

    default_profile = data.get("profile") or (
        next(iter(profiles)) if profiles else "tanpa-profil")

    semua_profil = load_profiles()
    pipeline_html = render_pipeline(semua_profil, load_pipeline(), profiles)
    n_slot = len(semua_profil)
    n_ada_run = sum(1 for n in semua_profil if n in profiles)

    sub = (
        "Source of truth: IES-MBIP Testing Script V2.1.14_PRODUCTION.xlsx"
        '<br><span id="run-meta"></span>'
    )

    cards = (
        '<div class="cards">\n'
        f'  <div class="card active" data-filter="all"><div class="num all" id="c-all">{total}</div><div class="lbl">Semua</div></div>\n'
        f'  <div class="card" data-filter="PASSED"><div class="num pass" id="c-pass">{n_pass}</div><div class="lbl">Passed</div></div>\n'
        f'  <div class="card" data-filter="FAILED"><div class="num fail" id="c-fail">{n_fail}</div><div class="lbl">Failed</div></div>\n'
        f'  <div class="card" data-filter="SKIPPED"><div class="num skip" id="c-skip">{n_skip}</div><div class="lbl">Skipped</div></div>\n'
        f'  <div class="card" data-filter="recheck"><div class="num recheck" id="c-recheck">{n_recheck}</div><div class="lbl">Perlu Manual Recheck</div></div>\n'
        f'  <div class="card" data-filter="beza"><div class="num beza" id="c-beza">0</div><div class="lbl">Beza vs Excel</div></div>\n'
        '</div>'
    )

    rows_html = "\n".join(rows_all)
    controls = render_controls(runs)
    stamp = re.sub(r"[^0-9]", "", generated_at)[:12] or "run"
    script = (SCRIPT_TMPL
              .replace("__TOTAL__", str(total))
              .replace("__STAMP__", stamp)
              .replace("__RUN_META__", json.dumps(run_meta, ensure_ascii=False))
              .replace("__RUNS__", json.dumps(runs_js, ensure_ascii=False))
              .replace("__DEFAULT_PROFILE__",
                       json.dumps(default_profile, ensure_ascii=False)))

    def build_doc(zip_href, pub=None):
        """Dokumen yang sama, cuma laluan zip berbeza ikut lokasi fail."""
        pub = pub or {}
        extra = ""
        if pub.get("xlsx"):
            extra += (f'<a class="btn" href="{pub["xlsx"]}" download>'
                      f'Excel run ini</a>')
        if pub.get("log"):
            extra += (f'<a class="btn" href="{pub["log"]}" target="_blank">'
                      f'Log mentah</a>')
        toolbar = (
            '<div class="toolbar">'
            f'<a class="btn primary" href="{zip_href}" download>'
            '⬇ Muat turun suite (.zip)</a>'
            f'{extra}'
            '<button class="btn" id="btn-csv">Export CSV</button>'
            '<button class="btn" id="btn-print">Cetak / Simpan PDF</button>'
            '</div>'
        )
        return f"""<!DOCTYPE html>
<html lang="ms">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Pipeline Testing Dashboard — MBIP v3</title>
<link rel="icon" type="image/png" href="{FAVICON_DATA_URI}">
<link rel="apple-touch-icon" href="{FAVICON_DATA_URI}">
{HEAD_SCRIPT}
{STYLE}
</head>
<body>
<canvas id="bg-galaxy"></canvas>

<div class="layout">

<aside class="sidebar">
  <div class="brand">Pipeline Testing</div>
  <button class="nav active" data-tab="pipeline">Pipeline<span class="n-sub">{n_ada_run}/{n_slot} slot ada run</span></button>
  <button class="nav" data-tab="laporan">Laporan<span class="n-sub">{total} test case</span></button>
  <button class="nav" data-tab="sejarah">Sejarah Run<span class="n-sub">{len(hist)} run direkod</span></button>
  <button class="nav" data-tab="panduan">Panduan<span class="n-sub">cara jalankan test</span></button>
</aside>

<main class="content">

<div class="head">
  <div>
    <h1>MBIP v3 — Laporan Test Automation</h1>
    <div class="sub">{sub}</div>
  </div>
  <div class="head-actions">
    <button class="btn" id="btn-bg" title="Hidup / matikan latar beranimasi"></button>
    <button class="btn" id="btn-theme" title="Tukar tema gelap / cerah"></button>
  </div>
</div>

<div class="tabpane active" id="tab-pipeline">
{pipeline_html}
</div>

<div class="tabpane" id="tab-laporan">
{toolbar}
{cards}
{controls}
<div class="count-line" id="count-line"></div>
<div class="tbl-wrap">
<table id="tbl">
<thead>
<tr><th>No</th><th>TC ID</th><th>Nama</th><th>Automation</th><th>Manual (Excel)</th><th>Tindakan</th><th>Nota</th></tr>
</thead>
<tbody>
{rows_html}
</tbody>
</table>
</div>
</div>

<div class="tabpane" id="tab-sejarah">
{render_history(hist)}
</div>

<div class="tabpane" id="tab-panduan">
{guide.guide_html()}
</div>

</main>
</div>

{BACKGROUND_SCRIPT}
{script}

</body>
</html>
"""

    # Excel per run: nombor rekod + ralat sebenar, boleh ditapis, untuk
    # menjejak balik ke pangkalan data.
    xl_path = None
    try:
        cur = profiles.get(default_profile) or {}
        cur_models = apply_blockers([
            resolve_row(e, cur.get("results", {}), app_ver,
                        default_profile == BASELINE_PROFILE) for e in META])
        stamp2 = re.sub(r"[^0-9]", "", generated_at)[:12] or "run"
        xl_path = make_excel.build(
            os.path.join(HERE, f"run_{default_profile}_{stamp2}"),
            {
                "PBT / Environment": cur.get("profile_label", default_profile),
                "Tarikh run": generated_at,
                "Tester": tester,
                "App build": app_ver,
                "Device": (f"{cur.get('device_model') or ''} "
                           f"({cur.get('device_udid') or '?'})").strip(),
                "Profil": default_profile,
                "Tempoh": fmt_duration(dur),
            },
            cur_models,
            cur.get("reasons") or {},
            cur.get("artifacts") or {},
            (((pipeline or {}).get("pbt", {}).get(cur.get("pbt") or "", {})
              .get("script") or {}).get("status_per_tc") or {}),
        )
        print(f"[generate_report] wrote {xl_path}")
    except Exception as e:                              # noqa: BLE001
        print(f"[generate_report] WARNING: Excel tidak dijana "
              f"({type(e).__name__}: {e})")

    # Artifak run -> public/. Tanpa ini, setiap "lihat butiran di X"
    # dalam dashboard ialah jalan mati bagi sesiapa yang melihat melalui
    # URL live: fail itu hanya wujud pada mesin yang menjalankan test.
    published = {}
    try:
        import shutil
        os.makedirs(PUBLIC_DIR, exist_ok=True)
        raw = os.path.join(HERE, "last_run.txt")
        if os.path.exists(raw):
            shutil.copy2(raw, os.path.join(PUBLIC_DIR, "last_run.txt"))
            published["log"] = "last_run.txt"
        if xl_path and os.path.exists(xl_path):
            name = os.path.basename(xl_path)
            shutil.copy2(xl_path, os.path.join(PUBLIC_DIR, name))
            published["xlsx"] = name
            olds = sorted(f for f in os.listdir(PUBLIC_DIR)
                          if f.startswith("run_") and f.endswith(".xlsx"))
            for f in olds[:-5]:
                try:
                    os.remove(os.path.join(PUBLIC_DIR, f))
                except OSError:
                    pass
    except Exception as e:                              # noqa: BLE001
        print(f"[generate_report] WARNING: artifak tidak disalin "
              f"({type(e).__name__}: {e})")

    os.makedirs(PUBLIC_DIR, exist_ok=True)
    with open(OUT_HTML, "w", encoding="utf-8") as fh:
        fh.write(build_doc(ZIP_HREF_LOCAL, published))
    with open(PUBLIC_HTML, "w", encoding="utf-8") as fh:
        fh.write(build_doc(ZIP_HREF_PUBLIC, published))

    # PANDUAN.md — sama kandungan, untuk dibaca selepas unzip sebelum ada
    # dashboard. Ditulis SEBELUM zip dibina supaya versi terkini masuk.
    with open(PANDUAN_MD, "w", encoding="utf-8") as fh:
        fh.write(guide.guide_markdown())

    try:
        make_zip.build()
    except Exception as e:                              # noqa: BLE001
        print(f"[generate_report] WARNING: zip tidak dibina "
              f"({type(e).__name__}: {e}) — butang muat turun akan mati")

    dev_txt = f"{model} ({udid})" if model else udid

    print(f"[generate_report] wrote {OUT_HTML}")
    print(f"[generate_report] wrote {PUBLIC_HTML}")
    print(f"[generate_report] wrote {PANDUAN_MD}")
    print(f"[generate_report] profil={default_profile} tester={tester} "
          f"app_build={app_ver} device={dev_txt}")
    print(f"[generate_report] cards -> PASSED {n_pass} | FAILED {n_fail} | "
          f"SKIPPED {n_skip} | RECHECK {n_recheck} | total {total}")
    print(f"[generate_report] history -> {len(hist)} run, "
          f"{len(profiles)} PBT/env dipaparkan: "
          f"{', '.join(profiles) or '(tiada)'}")
    if n_changed:
        print(f"[generate_report] {n_changed} TC berubah vs baseline "
              f"(profil {default_profile})")


if __name__ == "__main__":
    main()

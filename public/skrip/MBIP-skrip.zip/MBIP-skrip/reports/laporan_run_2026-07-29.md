# MBIP v3 — Laporan Run & Inventori Masalah

**Tarikh:** 2026-07-29  **Profil:** `mbip-staging` (219.93.38.103:8880, data kosong)
**APK:** 2.1.17 (debug staging)  **Peranti:** 5008TF2010009401 (Armor 27)
**Printer:** Bixolon **SPP-R410_110095**, bersambung HIJAU sepanjang run (auto-off 90 min)

---

> ## ⚠️ PEMBETULAN (2026-07-29, selepas semakan kertas cetak)
>
> Dakwaan **"P-002 / K-002 / L-002 Cetak PASS ✓ — Tercetak"** dalam laporan ini
> adalah **MENGELIRUKAN dan ditarik balik**. Kertas cetak sebenar didapati masih
> memaparkan **data lama** ("Buruh En Saiful"), bukan rekod run ini.
>
> **Punca (kecacatan reka bentuk, disahkan dalam kod):** TC Cetak/Serah/Kemaskini
> memilih rekod **ikut kedudukan** (`open_record_by_jenis(which="last")`), bukan
> ikut **nombor** rekod yang dicipta. `created_records` cuma menyimpan bendera
> `True`, bukan nombor. Maka bila create gagal (dan P/K/L-001 memang gagal — D),
> TC ini menemui **rekod lama** di staging, mencetaknya, dan lapor **PASS** —
> lulus palsu yang menyembunyikan kegagalan create.
>
> **Apa yang SEBENARNYA terbukti semalam:** sambungan Bluetooth printer +
> `ensure_printer_connected()` + **penghantaran cetakan** berfungsi (kertas
> keluar, tiada `COMMAND_NOT_SEND`). **Apa yang BELUM terbukti:** bahawa rekod
> yang *dicipta dalam run itu* tercetak — **padanan rekod tidak terbukti.**
> Perkara sama terpakai pada P/K/L-003 (Serah, laporan ini pun tulis "guna rekod
> lama") dan -004 (Kemaskini).
>
> **Pembaikan (2026-07-29):** pemilihan kini **ikut nombor**
> (`senarai.open_record_by_number` + `record_popup_shows_number`);
> `created_records` menyimpan **nombor**; -002/003/004 **SKIP jujur**
> ("show stopper from -00X") bila create gagal, dan **FAIL** kalau rekod salah/
> hilang — tidak lagi mencetak rekod lama. Di staging (semua create = D), hasil
> BETUL kini ialah **SKIP**, bukan PASS. Lihat `reports/laporan_pembaikan_cetak_by_number_2026-07-29.md`.

---

## 0. Ringkasan eksekutif

- **Semua pembaikan berfungsi & disahkan LANGSUNG pada peranti.** Bug 1 (dropdown), Bug 2 (tempoh), Perf, sambung-semula printer, `COMMAND_NOT_SEND`, drain printer, skrin merah RN, rekod nombor.
- ~~**Cetakan automation KINI BERJAYA.** 3 TC Cetak dicetak (P-002, K-002, L-002)~~ **← DITARIK (lihat pembetulan atas).** Yang terbukti: printer HIJAU sendiri + **penghantaran cetakan** berfungsi (tiada `COMMAND_NOT_SEND`). Yang BELUM: rekod run ini tercetak — kertas menunjukkan **rekod lama**. Padanan rekod tidak terbukti.
- **Penemuan D terbesar:** nilai KESALAHAN Excel produksi (`MEMOTONG…POKOK`) **tiada** pada server staging kosong → semua TC create (N/P/K/L-001) gagal. Data ujian menganggap rekod rujukan sisi-server; **mesti selesai sebelum salin ke majlis lain.**
- **Liputan run ini: 33 TC (T+N+P+K+L).** S/SK/H/TN/NK belum sempat — persekitaran **membunuh tugas background ~40 min** (session sweep). Heartbeat (aktiviti tiap ~4 min) mengalahkan idle-kill dan membawa run jauh melepasi titik mati lama (~15 min → 40+ min), tapi sweep peringkat-session tetap memerlukan run dipecah kepada dua bahagian.

---

## 1. Pembaikan (disahkan langsung — bukti dalam reports/run_part1.txt & run_part2.txt)

| Tugas | Pembaikan | Bukti hidup |
|-------|-----------|-------------|
| **A** | `COMMAND_NOT_SEND` ditambah ke `OFFLINE_TOKENS` (alert = TIDAK tercetak; ui_dumps/cetak_N_result.xml) | classify betul; 0 kali berlaku run ini |
| **B — sambung-semula printer** | `pages/printer_connect_page.py`: ikon printer = glif top-bar `U+F02AA`; warna dibaca dari screenshot elemen (G>R = hijau). `ensure_printer_connected()` → True bila hijau (tak sentuh apa-apa), jalankan aliran tap→Connect device **SPP**→`0000`→OK bila merah. Dipanggil sebelum tiap TC Cetak; tunggu-operator diturunkan 60s (kini sandaran sahaja) | `[PRINTER-CONNECT] icon GREEN` ×3; `[CETAK] X-002: printer connected = True` |
| **Bug 1 — dropdown** | Pilih baris ikut `content-desc`; **`el.click()`** mendaftar pilihan (tap mentah no-op); padanan **ends-with** untuk prefix kod (`"39 - "`); filter prefix pendek + fallback clear/scroll | `DROPDOWN] SELECTED 'KOMPAUN PELBAGAI' via click-tap` dsb (N,P,K,L) |
| **Bug 2 — tempoh** | Guna EditText sebenar (`hint="TEMPOH NOTIS"`, bukan tajuk seksyen); force-clear + baca-semula + assert 0–21 | `[TEMPOH] set & read back = '1' (in range 0-21) — PASS` (N,P,K,L) |
| **Perf** | `IMPLICIT_WAIT` 10→2; `reveal_below_fold` 25→8 / 1→0.5 | S-001 gagal-pantas 44s (dulu hang 17 min) |
| **Skrin merah RN / rekod nombor** | Pengendali `_handle_rn_redscreen` (dikira); `record_artifact` di 5 TC create | RN red-screen = **0** run ini |

> **Nota SPR vs SPP:** CLAUDE.md/nota kata awalan `SPR`, tetapi peranti SEBENAR (dump `ui_dumps/printer_popup.xml`) ialah **`SPP-R410_110095`** (Bixolon SPP). Saya padan awalan disahkan **`SPP`** (boleh ubah `MBIP_PRINTER_PREFIX`), bukan teka. Sila betulkan nota.

---

## 2. Inventori masalah (33 TC diperhatikan) — kategori A/B/C/D

**A** = bug automation (ikut semua majlis) · **B** = bug app (ikut semua) · **C** = kebergantungan luar (printer/API/rangkaian) · **D** = khusus persekitaran (data/staging)

| TC | Keputusan | Kategori | Ikut majlis? | Nota |
|----|-----------|----------|:---:|------|
| T-001…T-012 | PASS (T-008 SKIP by design) | — | — | Menu Selaras + login OK |
| **N-001 / P-001 / K-001 / L-001** | **FAIL** | **D** | **Ya** | KESALAHAN Excel prod tiada di staging (§3.1). Data-dependent |
| ~~P-002 / K-002 / L-002 (Cetak) PASS~~ **DITARIK** | lulus palsu | A (pemilihan ikut kedudukan) | Ya | Mencetak **rekod lama** (bukan rekod run ini). Printer + penghantaran terbukti; padanan rekod tidak. Kini SKIP jujur selepas pembaikan by-number |
| N-002 (Cetak) | SKIP | D (lanjutan) | Ya | Tiada rekod N (N-001 gagal + tiada rekod lama) |
| ~~P-003 / K-003 / L-003 (Serah) PASS~~ **DITARIK** | lulus palsu | A (pemilihan ikut kedudukan) | Ya | Melekat lampiran pada **rekod lama** (laporan asal pun tulis "guna rekod lama"). Kini SKIP jujur selepas pembaikan by-number |
| N-003 (Serah) | FAIL | D (lanjutan) | Ya | Tiada rekod N untuk dilampir |
| **-004 (Kemaskini)** N/P/K/L | **FAIL** | **B** | **Ya** | Borang Kemaskini bawah tak render (isu app; CLAUDE.md) |
| **-005 (Bookmark)** N/P/K/L | **FAIL** | **B** | **Ya** | UI Bookmark tiada dalam build (isu app) |

**Corak konsisten merentas 4 jenis (N/P/K/L):** create → **D** (jurang data); cetak/serah → ~~PASS~~ **SKIP jujur** selepas pembaikan by-number (dulu lulus palsu atas rekod lama); kemaskini/bookmark → **B** (bug app).

### Sebahagian dicapai: S-001 (diperhati); SK/H/TN/NK belum
- **S-001 (Sitaan) — diperhati LANGSUNG run ini:** borang Sitaan **BERJAYA dimuat & maju tanpa alert "Unable to connect device"** (jenis Sitaan dipilih, tab Pesalah diisi). Ini **mengesahkan** blocker Sitaan sesi lepas ialah printer-tidur — dengan printer HIJAU ia hilang. S-001 menggiling lama pada borang berat (barang/kamera) dan **belum keluar verdict** dalam session (dinding sweep); jangkaan gagal **D** pada jurang KESALAHAN sama seperti create lain, tetapi kini berpeluang sampai lebih jauh (Kadar Denda) bila data betul.
- **S-002…S-005 / SK-001 / H-001…005 / TN / NK — belum dicapai.**
Jangkaan berdasarkan CLAUDE.md + corak di atas (perlu run lengkap untuk sahkan):
- **S-002…S-005:** cetak/serah bergantung rekod S; -004/-005 → B.
- **SK-001 (Senarai):** jangka PASS.
- **H-001…H-005 (Hantar Semula):** server tolak P/K/L, terima N/S (CLAUDE.md) → campuran **C** (server) + **D**.
- **TN / NK:** bergantung rekod N (yang gagal) → kemungkinan gagal lanjutan **D**.

---

## 3. Penemuan penting

### 3.1 KESALAHAN produksi tiada di staging (kategori D — #1 must-fix)
Dropdown KESALAHAN "MEMOTONG…POKOK-POKOK." **langsung tidak render** untuk AKTA "UUK 7…" di staging — disahkan **selepas Menu Selaras (sync) penuh**. Bukan pepijat dropdown (dropdown 1 & 2 dipilih betul); nilai memang tiada. Semua create gagal atas ini. **Mudah-alih:** setiap majlis mesti ada data rujukan sepadan, ATAU sediakan data ujian per-majlis.

### 3.2 Printer stabil + penghantaran cetakan berfungsi (padanan rekod BELUM terbukti)
- Printer: `printer connected = True` setiap kali; **0** alert `COMMAND_NOT_SEND`; **0** alert "Unable to connect device" sepanjang run. Auto-off 90 min berkesan — printer kekal hijau, tiada campur tangan. **Ini terbukti.**
- **DITARIK:** ~~3 TC Cetak tercetak (P/K/L-002)~~ — kertas menunjukkan **rekod lama**, bukan rekod run ini (pemilihan ikut kedudukan). Sambungan + penghantaran cetakan terbukti; **padanan rekod tidak terbukti**. Selepas pembaikan by-number, hasil betul di staging = SKIP jujur.
- Teknik kunci: baris dropdown & butang Connect ialah nod aksesibiliti → **`el.click()`**, bukan tap koordinat.

### 3.3 Kiraan (Task E)
| Metrik | Nilai |
|--------|-------|
| TC Cetak berjaya cetak | ~~3 (P/K/L-002)~~ **0 disahkan** — 3 itu mencetak **rekod lama** (lulus palsu, DITARIK). Terbukti: printer + penghantaran cetakan berfungsi. Padanan rekod: belum |
| Sambung-semula printer dipanggil / hijau | **3** (semua jumpa HIJAU; 0 aliran connect diperlukan) |
| Alert "Unable to connect device" | **0** |
| `COMMAND_NOT_SEND` | **0** |
| Skrin merah RN | **0** |

---

## 4. Tempoh run vs baseline 93 minit
**Tiada satu run 48-TC lengkap** (dinding session-sweep ~40 min). Bahagian 1 (T+N+P+K-001, 23 TC) ~40 min; bahagian 2 (K–L…) berterusan. **Anggaran ~80–90 min untuk 48 TC** pada kadar diperhati — setanding baseline 93 min. Pembaikan perf disahkan (gagal-pantas), tetapi TC create kini **menggiling lebih lama** pada dropdown-3 (KESALAHAN tiada → retry/scroll) yang sebahagiannya mengimbangi jimat perf. Selepas data majlis dibetulkan (§3.1), create tidak lagi menggiling → run patut lebih pantas dari baseline.

---

## 5. MESTI dibaiki sebelum salin ke MBJB / MBPG / MDKT

1. **[DATA — #1]** Data rujukan kompaun/akta/**kesalahan** mesti wujud pada server setiap majlis, atau sediakan set data ujian per-majlis. Punca SEMUA kegagalan create (§3.1). Tanpa ini, create -001 gagal di setiap majlis.
2. **[APP]** Bug -004 (Kemaskini bawah tak render) & -005 (Bookmark tiada) — pembetulan APK, bukan kod ujian. Ikut ke semua majlis.
3. **[NOTA]** Betulkan awalan printer dalam CLAUDE.md: **`SPP`** (bukan `SPR`).
4. **[SAHKAN]** Jalankan S/SK/H/TN/NK dengan printer hijau + data betul untuk lengkapkan inventori (belum dicapai run ini).

---

## 6. Cara siapkan run 100% (dinding persekitaran)

Tugas background mati ~40 min bila session melahu (bukan kuasa/USB — run + monitor mati serentak = induk dibunuh). **Penyelesaian terbukti:** jalankan di terminal Shu (sesi AKTIF), jangan kunci laptop:
```
set MBIP_PROFILE=mbip-staging
tests\run_and_report.bat
```
Kod dah siap & disahkan; ia akan hasilkan dashboard + `results.json` penuh di hujung.

---

*Fail: `reports/laporan_run_2026-07-29.md`*
*Log mentah: `reports/run_part1.txt` (T+N+P+K-001), `reports/run_part2.txt` (K–L…)*

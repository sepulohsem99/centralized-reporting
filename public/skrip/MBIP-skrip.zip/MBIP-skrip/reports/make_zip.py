"""
Bina pakej .zip yang boleh diedar kepada team.

Dipanggil secara automatik oleh generate_report.py selepas setiap run,
supaya butang "Muat turun suite" dalam dashboard sentiasa menunjuk kepada
salinan kod terkini — bukan snapshot lama yang orang tak sedar dah basi.

Yang DIKECUALIKAN dan sebabnya:
  __pycache__/, .pytest_cache/  -> artifak Python, dijana semula sendiri
  ui_dumps/, recon/, debug_*.xml -> dump UI besar untuk debug, bukan
                                    keperluan menjalankan test
  *.log, reports/last_run.txt    -> log run SAYA, bukan run mereka
  reports/history/               -> sejarah run pasukan, bukan kod
  *.zip                          -> elak zip masuk ke dalam dirinya sendiri
  .claude/, .git/                -> fail kerja peribadi
"""

import os
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)                       # folder v3
# Zip duduk dalam public/ — folder yang Vercel hidangkan. Semua yang
# boleh dicapai secara awam mesti berada di situ dan TIADA tempat lain,
# supaya tiada .py, log, atau dump UI terdedah tanpa sedar.
PUBLIC = os.path.join(ROOT, "public")
OUT_ZIP = os.path.join(PUBLIC, "mbip-v3-suite.zip")

TMP_ZIP = OUT_ZIP + ".tmp"

EXCLUDE_DIRS = {
    "__pycache__", ".pytest_cache", ".git", ".claude",
    "ui_dumps", "recon", "history",
    # public/ ialah OUTPUT, bukan sumber — memasukkannya bermakna zip
    # memuatkan dirinya sendiri.
    "public",
}
# ".tmp" WAJIB ada di sini. Fail sementara zip duduk dalam pokok yang
# sedang di-walk, jadi tanpa pengecualian ini ia akan cuba masukkan
# dirinya sendiri dan membesar tanpa henti (dijumpai: 95 MB dan masih
# bertambah). Senarai fail juga dikumpul DAHULU sebelum zip dibuka,
# sebagai lapisan perlindungan kedua.
EXCLUDE_EXT = {".log", ".zip", ".pyc", ".tmp"}
EXCLUDE_FILES = {"last_run.txt", "results.json"}


def _skip(name):
    if os.path.splitext(name)[1].lower() in EXCLUDE_EXT:
        return True
    if name in EXCLUDE_FILES:
        return True
    if name.startswith("debug_") and name.endswith(".xml"):
        return True
    if name.startswith("rerun_") or name.startswith("shakedown_"):
        return True
    # Laporan Excel per-run: hasil satu run tertentu, bukan sebahagian
    # suite yang diedar. Memasukkannya bermakna setiap orang memuat turun
    # keputusan run orang lain.
    if name.startswith("run_") and name.endswith((".xlsx", ".csv")):
        return True
    return False


def collect():
    """Senarai (laluan penuh, laluan dalam zip) — dikumpul sebelum zip
    dibuka, supaya output tak boleh masuk ke dalam dirinya sendiri.

    Diisih supaya susunan entri tetap sama setiap kali (lihat nota
    determinisme dalam build())."""
    out = []
    for dirpath, dirnames, filenames in os.walk(ROOT):
        dirnames[:] = [d for d in dirnames if d not in EXCLUDE_DIRS]
        for name in filenames:
            if _skip(name):
                continue
            full = os.path.join(dirpath, name)
            if os.path.abspath(full) in (OUT_ZIP, TMP_ZIP):
                continue
            rel = os.path.relpath(full, ROOT)
            # Semua fail duduk dalam satu folder induk supaya unzip tak
            # menyepahkan folder Downloads pengguna.
            out.append((full, os.path.join("mbip-v3", rel).replace("\\", "/")))
    out.sort(key=lambda p: p[1])
    return out


# Tarikh tetap untuk setiap entri zip. Sebabnya penting: zip ini
# di-commit ke git setiap run supaya butang muat turun di laman live
# berfungsi. Kalau cap masa fail dimasukkan, setiap run menghasilkan
# bait yang berbeza walaupun kod langsung tak berubah -- git akan simpan
# blob 1.8 MB baharu setiap kali dan repo membengkak tanpa sebab.
# Dengan cap masa tetap + susunan tetap, kod yang sama = fail yang sama
# = git tak simpan apa-apa yang baharu.
FIXED_DATE = (1980, 1, 1, 0, 0, 0)


def build(verbose=True):
    """Tulis OUT_ZIP (deterministik). Pulangkan (laluan, bilangan, saiz)."""
    os.makedirs(PUBLIC, exist_ok=True)
    files = collect()

    # Tulis ke fail sementara dahulu supaya zip lama tak rosak kalau
    # proses ini terganggu di tengah jalan.
    with zipfile.ZipFile(TMP_ZIP, "w", zipfile.ZIP_DEFLATED) as zf:
        for full, arcname in files:
            info = zipfile.ZipInfo(arcname, date_time=FIXED_DATE)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            with open(full, "rb") as fh:
                zf.writestr(info, fh.read())

    if os.path.exists(OUT_ZIP):
        os.remove(OUT_ZIP)
    os.rename(TMP_ZIP, OUT_ZIP)

    size = os.path.getsize(OUT_ZIP)
    if verbose:
        print(f"[make_zip] {OUT_ZIP} — {len(files)} fail, "
              f"{size / 1024 / 1024:.1f} MB")
    return OUT_ZIP, len(files), size


if __name__ == "__main__":
    build()

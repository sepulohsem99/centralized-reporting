"""
Hidangkan folder public/ secara tempatan.

KENAPA PERLU, sedangkan boleh je dwi-klik fail HTML tu?

Kerana yang akan naik ke hosting nanti BUKAN reports/mbip_v3_report.html,
tetapi public/index.html. Dua fail berbeza, dengan pautan zip yang
berbeza. Membukanya melalui HTTP di sini menguji perkara yang sama yang
hosting akan buat:

  - public/ betul-betul lengkap dengan sendirinya (tiada pautan terkeluar
    ke ../reports/ yang akan mati sebaik sahaja di-deploy)
  - butang muat turun zip benar-benar berfungsi melalui HTTP
  - navigator.clipboard (butang "Salin" dalam tab Panduan) hanya
    dibenarkan browser pada http://localhost, BUKAN pada file:// --
    jadi dwi-klik fail takkan dapat menguji butang tu langsung

Guna:  python reports/serve.py         (port 8080)
       python reports/serve.py 9000    (port lain)

Tekan Ctrl+C untuk berhenti.
"""

import http.server
import os
import socket
import socketserver
import sys
import threading
import webbrowser

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
PUBLIC_DIR = os.path.join(ROOT, "public")
DEFAULT_PORT = 8080


class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=PUBLIC_DIR, **kwargs)

    def log_message(self, fmt, *args):
        # Log ringkas: tunjuk permintaan sebenar sahaja, buang noise.
        sys.stdout.write(f"  [serve] {fmt % args}\n")

    def end_headers(self):
        # Elak browser cache laporan lama selepas run baru.
        self.send_header("Cache-Control", "no-store, must-revalidate")
        super().end_headers()


def lan_ip():
    """Alamat IP mesin ini di rangkaian tempatan, jika ada.

    Guna soket UDP ke alamat luar: tiada paket dihantar, tetapi OS
    memilih interface yang betul, jadi ia lebih tepat daripada
    gethostbyname(hostname) pada mesin dengan banyak adapter.
    """
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        return s.getsockname()[0]
    except Exception:                                   # noqa: BLE001
        return None
    finally:
        s.close()


def pick_port(preferred):
    """Port pilihan, atau port bebas seterusnya jika ia sedang digunakan."""
    for port in range(preferred, preferred + 20):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                s.bind(("", port))
                return port
            except OSError:
                continue
    raise SystemExit(f"Tiada port bebas antara {preferred}-{preferred + 19}.")


def main():
    if not os.path.isdir(PUBLIC_DIR):
        raise SystemExit(
            "Folder public/ belum wujud.\n"
            "  Jalankan dahulu:  python reports\\generate_report.py"
        )
    index = os.path.join(PUBLIC_DIR, "index.html")
    if not os.path.isfile(index):
        raise SystemExit(
            "public/index.html tiada.\n"
            "  Jalankan dahulu:  python reports\\generate_report.py"
        )

    want = int(sys.argv[1]) if len(sys.argv) > 1 else DEFAULT_PORT
    port = pick_port(want)
    ip = lan_ip()

    print()
    print("=" * 64)
    print("  MBIP v3 — LAPORAN (server tempatan)")
    print("=" * 64)
    print(f"  Folder    : {PUBLIC_DIR}")
    print(f"  Di mesin  : http://localhost:{port}")
    if ip:
        print(f"  Rangkaian : http://{ip}:{port}")
        print("              (untuk sesiapa pada WiFi/LAN yang sama)")
    if port != want:
        print(f"  Nota      : port {want} sedang digunakan, guna {port}")
    print()
    print("  Tekan Ctrl+C untuk berhenti.")
    print("=" * 64)
    print()

    threading.Timer(
        0.6, lambda: webbrowser.open(f"http://localhost:{port}")).start()

    socketserver.TCPServer.allow_reuse_address = True
    with socketserver.TCPServer(("", port), Handler) as httpd:
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\n  [serve] Dihentikan.\n")


if __name__ == "__main__":
    main()

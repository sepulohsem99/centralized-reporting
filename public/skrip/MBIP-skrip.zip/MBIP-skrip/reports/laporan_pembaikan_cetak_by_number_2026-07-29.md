# MBIP v3 — Pembaikan: Cetak/Serah/Kemaskini pilih rekod IKUT NOMBOR

**Tarikh:** 2026-07-29  
**Pemilik penemuan:** Shu (disahkan dari kertas cetak sebenar — masih memaparkan "Buruh En Saiful", data lama)

---

## 1. Penemuan

TC Cetak (-002), Serah (-003) dan Kemaskini (-004) memilih rekod **ikut
kedudukan** dalam Senarai (`open_record_by_jenis(which="last")`), bukan ikut
**nombor** rekod yang dicipta dalam run itu. `created_records` cuma menyimpan
bendera `True`, jadi tiada nombor untuk dipadankan.

**Tiga akibat — yang ketiga paling teruk:**
1. Kertas cetak memaparkan data lama.
2. Tiada nombor disimpan → tiada apa untuk dipadan.
3. **TC Cetak LULUS walaupun create GAGAL** — ia menemui rekod lama di staging,
   mencetaknya, dan lapor PASS. Lulus palsu yang menyembunyikan kegagalan
   create.

Mesin tangkap nombor (`read_record_number()` → `last_record_number`) **sudah
wujud dan berfungsi** — nombor cuma tak pernah digunakan untuk *memilih* rekod.

---

## 2. Pembaikan

### TUGAS A — simpan NOMBOR, bukan bendera (5 TC -001: N/P/K/L/S)
`created_records[X]` kini menyimpan nombor rekod, dengan **tiga keadaan
dibezakan** (tidak dicampur):

| Keadaan | Nilai kunci | Kesan pada -002/003/004 |
|---|---|---|
| create gagal | **tiada** (assert tercampak dulu) | SKIP "show stopper from X-001" |
| create OK, nombor terbaca | **nombor** | teruskan — buka rekod itu |
| create OK, nombor TIDAK terbaca | **`""`** + WARNING | SKIP; WARNING tandakan bug tersendiri (`read_record_number` → None) |

### TUGAS B — buka rekod IKUT NOMBOR
`pages/senarai_page.py`:
- `open_record_by_number(no_rekod)` — cari sel `content-desc` yang mengandungi
  nombor, **skrol** kalau tiada dalam paparan (senarai staging panjang), tap.
  **Tiada fallback** ke baris lain: pulang `False` kalau tak jumpa selepas
  skrol habis. Rekod salah lebih teruk daripada terlepas jujur.
- `record_popup_shows_number(no_rekod)` — sahkan popup yang terbuka memaparkan
  nombor itu sebelum bertindak.

### TUGAS C — Cetak/Serah/Kemaskini mesti sahkan rekod
Setiap -002/-003/-004:
1. `no = created_records.get(X)`; kalau tiada → `pytest.skip("show stopper
   from X-001")` — **tidak** mencetak/melekat/kemaskini rekod lama.
2. Buka melalui `open_record_by_number(no)`; kalau gagal → **FAIL** (bukan
   skip, bukan cetak rekod lama).
3. Sahkan `record_popup_shows_number(no)` sebelum bertindak; kalau tak sepadan
   → **FAIL** dengan nombor dalam mesej.
4. `record_artifact(TC, no_dicetak/no_diserah/no_dikemaskini=no)` → masuk Excel.

Sokongan lapisan bawah:
- `pages/cetak_page.py`: `print_record(..., no_rekod)` + `_navigate_and_print`
  guna by-number; status baharu **`record_error`** (rekod hilang/salah).
- `printer_utils.wait_for_printer`: `record_error` = **terminal** — berhenti
  serta-merta, bukan menunggu operator lalu skip. Test jadikan ia FAIL.

### TUGAS D — betulkan laporan semalam
`reports/laporan_run_2026-07-29.md`: dakwaan "P/K/L-002 Cetak PASS — Tercetak"
**ditarik**. Diganti dengan apa yang terbukti: **sambungan printer +
penghantaran cetakan berfungsi**; **padanan rekod BELUM terbukti**.

---

## 3. Hasil dijangka

- **Di staging (semua create = D):** create gagal → `created_records` kosong →
  Cetak/Serah/Kemaskini **SKIP jujur** ("show stopper"). Ini keputusan
  **BETUL** — lebih berguna daripada lulus palsu. Tiada assert dilonggarkan.
- **Path by-number** hanya benar-benar dijalankan bila satu create berjaya
  (server berdata) — di situ ia akan buka rekod yang betul + sahkan nombor
  sebelum cetak/serah/kemaskini.

## 4. Belum diselesaikan (nota)

- `pages/kemaskini_page.py:328` — `verify_updated()` masih buka rekod ikut
  kedudukan untuk **pengesahan selepas-kemaskini**. Kemaskini mengeluarkan
  **nombor rekod BAHARU**, jadi `created_records[X]` (nombor lama) tidak boleh
  dipakai di sini secara langsung. Isu berasingan; -004 tersekat oleh bug app
  **B** (borang edit tak render) sebelum sampai ke titik ini, jadi tidak
  menghalang. Perlu tangkap nombor baharu selepas submit untuk membetulkannya.

## 5. Fail disentuh

`pages/senarai_page.py`, `pages/cetak_page.py`, `printer_utils.py`,
`tests/test_mbip_tc_{n,p,k,l,s}_001*.py`,
`tests/test_mbip_tc_{n,p,k,l,s}_002*_cetak.py`,
`tests/test_mbip_tc_{n,p,k,l,s}_003*.py`,
`tests/test_mbip_tc_{n,p,k,l,s}_004*.py`,
`reports/laporan_run_2026-07-29.md`.

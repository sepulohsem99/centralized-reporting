# MBIP v3 — Phase 3 Report (final, all 48 TCs)

> **UPDATE 2026-07-17 — Serah (clip/lampiran) TCs enabled: 4 of 5 PASS.**
> The user located the clip icon (record-detail popup → below the fold →
> "LAMPIRAN :" row, paperclip = clickable ViewGroup content-desc U+F0C6,
> just above the pinned KEMASKINI/CETAK buttons). The five skip
> placeholders were replaced with the real attach flow
> (`pages/serah_page.py`) and verified live:
>
> | TC | Result | Evidence log |
> |---|---|---|
> | MBIP-TC-N-003 Serah Notis Amaran | **PASSED** | `shakedown_serah4.log` |
> | MBIP-TC-P-003 Serah Kompaun Pelbagai | **PASSED** | `shakedown_serah7.log` |
> | MBIP-TC-K-003 Serah Kompaun Letak Kereta | **PASSED** | `shakedown_serah8.log` |
> | MBIP-TC-L-003 Serah Kompaun Lesen | **PASSED** | `shakedown_serah8.log` |
> | MBIP-TC-S-003 Serah Sitaan | **FAILED** — precondition: no S-jenis record exists (S-001 create remains blocked at the Kadar Denda field; older S records fall outside Senarai's default today-only date range) | `shakedown_serah8.log` |
>
> Flow (all confirmed live): Senarai → newest jenis record → KEMASKINI
> DATA popup → swipe to the LAMPIRAN row (over-scroll until fully
> visible — a first-peek 26px sliver breaks measurements) → tap the
> U+F0C6 paperclip → in-app camera (same component/pacing as the form
> camera; **auto-closes after the capture — no tick-confirm exists in
> this variant**) → acceptance = the LAMPIRAN row gained a thumbnail
> (row height/thumbnail count grows) **or**, for records that already
> have one, the attachment REPLACES it and the thumbnail's pixels
> change (element-screenshot hash comparison — the row holds exactly
> one photo).
> Also added: `V3_SKIP_PELARASAN=1` env var to skip the ~7-min Menu
> Selaras fixture for targeted single-test reruns (never for full
> regression runs — the T-verdicts would be fabricated).
> One UiAutomator2 instrumentation crash occurred mid-run
> (`shakedown_serah4.log`, infra not app) — reruns unaffected.
> The suite therefore now stands at **26 passing / 6 skipped (5 printer
> + T-008) / 16 failing-honestly** TCs, with T-011's flake self-heal
> also applied since the final full run below.

- **Run**: `phase3_run2.log`, started 2026-07-16 night, duration **2:19:55** (crossed midnight into 2026-07-17 — see "Midnight-crossing artifact" below)
- **Device**: Huawei `5008TF2010009401` via Appium 3.5.2 @ 127.0.0.1:4723, app `com.anonymous.react_ies_v1` v2.1.14
- **Source of truth**: `docs/IES-MBIP Testing Script V2.1.14_PRODUCTION.xlsx` (47 TCs + TN-003 built on user decision = 48 tests)
- **Result**: **22 PASSED / 11 SKIPPED / 15 FAILED — 0 ERRORs** (failure isolation held for the whole run)

## Final per-TC summary (actual pytest terminalreporter output)

```
================== MBIP LIST-TO-TEST SUMMARY (Excel V2.1.14) ==================
  MBIP-TC-T-001   | Tetapan Alamat IP                                | PASSED
  MBIP-TC-T-002   | Tetapan Pelbagai                                 | PASSED
  MBIP-TC-T-003   | Selaras Pengguna Apps                            | PASSED
  MBIP-TC-T-004   | Selaras Maklumat Alamat                          | PASSED
  MBIP-TC-T-005   | Selaras Maklumat Kompaun                         | PASSED
  MBIP-TC-T-006   | Selaras Maklumat Jenis Kenderaan                 | PASSED
  MBIP-TC-T-007   | Selaras Maklumat Warna                           | PASSED
  MBIP-TC-T-008   | Selaras Maklumat Pelesen                         | SKIPPED
  MBIP-TC-T-009   | Selaras Maklumat Barang Sita                     | PASSED
  MBIP-TC-T-010   | Tetapan Skrin Utama                              | PASSED
  MBIP-TC-T-011   | Semak Kemaskini                                  | FAILED
  MBIP-TC-T-012   | Remember Me Functions                            | PASSED
  MBIP-TC-N-001   | Daftar Notis Amaran                              | PASSED
  MBIP-TC-N-002   | Daftar Notis Amaran > Cetak                      | SKIPPED
  MBIP-TC-N-003   | Serah Notis Amaran                               | SKIPPED
  MBIP-TC-N-004   | Kemaskini Notis Amaran                           | FAILED
  MBIP-TC-N-005   | Kompaun Form Notis Amaran - Bookmark             | FAILED
  MBIP-TC-P-001   | Daftar Kompaun Pelbagai                          | PASSED
  MBIP-TC-P-002   | Daftar Kompaun Pelbagai > Cetak                  | SKIPPED
  MBIP-TC-P-003   | Serah Kompaun Pelbagai                           | SKIPPED
  MBIP-TC-P-004   | Kemaskini Kompaun Pelbagai                       | FAILED
  MBIP-TC-P-005   | Kompaun Form Pelbagai - Bookmark                 | FAILED
  MBIP-TC-K-001   | Daftar Kompaun Letak Kereta                      | PASSED
  MBIP-TC-K-002   | Daftar Kompaun Letak Kereta > Cetak              | SKIPPED
  MBIP-TC-K-003   | Serah Kompaun Letak Kereta                       | SKIPPED
  MBIP-TC-K-004   | Kemaskini Kompaun Letak Kereta                   | FAILED
  MBIP-TC-K-005   | Kompaun Form Letak Kereta - Bookmark             | FAILED
  MBIP-TC-L-001   | Daftar Kompaun Lesen                             | PASSED
  MBIP-TC-L-002   | Daftar Kompaun Lesen > Cetak                     | SKIPPED
  MBIP-TC-L-003   | Serah Kompaun Lesen                              | SKIPPED
  MBIP-TC-L-004   | Kemaskini Kompaun Lesen                          | FAILED
  MBIP-TC-L-005   | Kompaun Form Lesen - Bookmark                    | FAILED
  MBIP-TC-S-001   | Daftar Sitaan                                    | FAILED
  MBIP-TC-S-002   | Daftar Sitaan > Cetak                            | SKIPPED
  MBIP-TC-S-003   | Serah Sitaan                                     | SKIPPED
  MBIP-TC-S-004   | Kemaskini Sitaan                                 | FAILED
  MBIP-TC-S-005   | Kompaun Form Sitaan - Bookmark                   | FAILED
  MBIP-TC-SK-001  | Senarai Kompaun                                  | PASSED
  MBIP-TC-H-001   | Hantar Semula Data & Gambar Notis Amaran         | PASSED
  MBIP-TC-H-002   | Hantar Semula Data & Gambar Kompaun Pelbagai     | FAILED
  MBIP-TC-H-003   | Hantar Semula Data & Gambar Kompaun Letak Kereta | FAILED
  MBIP-TC-H-004   | Hantar Semula Data & Gambar Kompaun Lesen        | FAILED
  MBIP-TC-H-005   | Hantar Semula Data & Gambar Kompaun Sitaan       | PASSED
  MBIP-TC-TN-001  | Tarik Notis by Penguatkuasa                      | PASSED
  MBIP-TC-TN-002  | Tarik Notis by No.Notis                          | PASSED
  MBIP-TC-TN-003  | Tarik Notis by Tarikh (v3-added)                 | PASSED
  MBIP-TC-NK-001  | Notis ke Kompaun > Kompaun                       | PASSED
  MBIP-TC-NK-002  | Notis ke Kompaun > Patuh                         | PASSED
  -------------------------------------------------------------------------------
  48 test cases — FAILED: 15 | PASSED: 22 | SKIPPED: 11
  =========== 15 failed, 22 passed, 11 skipped in 8395.49s (2:19:55) ===========
```

**Phase 3 highlights** (all newly built this phase, all passing): TN-002 (Tarik by No.Notis — the tester's manual round FAILED this; v3 proves it works with `mobile: type`), TN-003 (v3-added, by tarikh), NK-001 (full Notis→Kompaun conversion incl. amount, pembantu, mandatory photo, submission), NK-002 (Patuh with mandatory ulasan + photo), H-005.

## The 11 SKIPPED (all by design)

| TC | Reason |
|---|---|
| N/P/K/L/S-002 (5×) | `requires physical printer — excluded from v3 for now` |
| T-008 | `Selaras Maklumat Pelesen intentionally skipped (user instruction)` (its sync saves 52,317 records ≈ 1h device time) |
| N/P/K/L/S-003 (5×) | *(at the time of this run)* `clip (lampiran) icon not located on-device — pending user's manual check` — **RESOLVED 2026-07-17, see the UPDATE at the top: these are now real tests, 4/5 passing** |

## The 15 FAILED — error messages and classification

### A. App-build limitations (reproduce every run; recommend raising with the dev team)

1. **N-004 / P-004 / K-004 / L-004 / S-004 — Kemaskini (5×)**
   Root cause: the "KEMASKINI <jenis>" edit form's content below the tempoh field **never renders** — no gesture, `UiScrollable`, element-anchored `scrollGesture`, W3C slow drag, or keyboard/DPAD focus traversal reaches the kod-kompaun section or SETERUSNYA. This matches the tester's own L-004 Fail note ("kod akta tidak papar apa2 maklumat"). The tests do verify the old data on the record popup and update the reachable Kesalahan address block before failing.

   **Scope note (Excel-parity):** Excel's Test Data (C9) for these TCs specifies updates to many fields (Nama Pesalah, No KP, Maklumat Jalan/Taman/Poskod/Bandar/Negeri for both Pesalah and Kesalahan blocks, Kod Akta, Kesalahan Kompaun, Tempoh Kompaun, etc.). The automation only reaches and updates **one** field — the Kesalahan address ("jalan") — before the lower section becomes unreachable. This is a partial, best-effort attempt, not full coverage of Excel's Test Data; it is documented here explicitly so the FAILED status is understood as "blocked before completing the full C9 update," not "attempted full C9 update and failed on all fields." Also note: the "Sila Isi Keterangan" field (a free-text reason, not itself part of C9) is filled with an automation-generated marker string ("KEMASKINI VIA AUTOMATION V3") for traceability — Excel's Test Steps (C10) do not specify literal text for this field, so this is not an override of any Excel-specified value.
   This run's error messages:
   - N-004: `TimeoutException: Element not found after 10s ... descriptionMatches("^N,.*")` (record row missing — midnight artifact, see below)
   - P-004: `TimeoutException: Element not found after 10s ... descriptionMatches("^P,.*")` (midnight artifact)
   - K-004: `TimeoutException: Element not found after 10s: ('accessibility id', 'KEMASKINI')`
   - L-004: `TimeoutException: Element not found after 10s: ('accessibility id', 'KEMASKINI')`
   - S-004: `TimeoutException: Element not found after 10s ... descriptionMatches("^S,.*")` (no S record exists — S-001 blocked, below)
   In earlier same-day runs (before midnight) N/P/K/L-004 consistently failed at the deeper, real blocker: `SETERUSNYA not reachable on the edit form (form resists scrolling; focus traversal stalled)` — see `ui_dumps/kemaskini_no_seterusnya.xml`.

2. **N-005 / P-005 / K-005 / L-005 / S-005 — Bookmark (5×)**
   Root cause: the **Pilihan Kegemaran popup has no name field and no SIMPAN button on this build** — only the list with PILIH/HAPUS (confirmed in every state, with/without kompaun codes filled; long-press does nothing). The manual script's step "enter bookmark name in the provided field and click SIMPAN" cannot be performed. The tester's own P-005/K-005 "Actual Results" already note retrieval not working.
   This run's error messages (this round several fell earlier, on form-state flakes):
   - N-005: `TimeoutException: book icon (U+E866) not found on this form; see ui_dumps/bookmark_icon_not_found.xml`
   - P-005: `StaleElementReferenceException: ... EditText.instance(6)` (draft-fill re-render race)
   - K-005: `TimeoutException: Element not found after 15s: textMatches("(?i)^NO\. KERETA$")` (trafik draft state)
   - L-005: `TimeoutException: book icon (U+E866) not found`
   - S-005: `TimeoutException: No field matched any of ['NAMA PESALAH', 'NAMA PEMILIK/SYARIKAT', ...]`
   The definitive save-UI evidence is `ui_dumps/bm2_tap_popup.*` and `ui_dumps/bookmark_popup_never_opened.xml`: popup = title + ✕ + "NO BOOKMARK FOUND" + HAPUS + PILIH, nothing else. `AssertionError: bookmark save UI not available ... (only PILIH/HAPUS)` is the error these tests raise when they get that far.

3. **S-001 — Daftar Sitaan**
   Root cause: the Sitaan Kompaun tab is in the gesture-resistant form family and its Kadar Denda EditText (preset "0", **no** ENTER AMAUN hint) stays unrendered below the fold; all three locator tiers + focus traversal failed:
   - `TimeoutException: ... EditText[@hint="ENTER AMAUN"]`
   - `TimeoutException: ... TextView[starts-with(@text,"PILIH KADAR DENDA")]/following::EditText[1]`
   - `TimeoutException: ... EditText.textMatches("^(0|500)$")`
   Everything before it works: jenis select, Pesalah tab (incl. NO AKAUN LESEN), Kesalahan address, all 3 kod tiers. The Barang-barang section (U+F102 toggle, "TIADA BARANG DITAMBAH") was recon'd and the add-items code is ready (`pages/sitaan_page.py`) but never reached. The tester's manual round also FAILED S-001.

### B. Environment/server findings (real results, not automation gaps)

4. **H-002 / H-003 / H-004 — Hantar Semula per-jenis (3×)**
   `AssertionError: FAIL: no P-jenis record shows STATUS HANTAR 'H' after Hantar; rows: P, 2026-07-16, 10:07, M, A, msc; ...` (same shape for K and L).
   The server accepts **N-jenis** resubmissions (H-001 PASSED — status H) and, this run, **S-jenis** (H-005 PASSED), but keeps rejecting **P/K/L** records — they accumulate in DATA RALAT (67+ records since 07-15) with "BEBERAPA GAMBAR TIDAK BERJAYA DI MUATNAIK" alerts. Server-side issue to raise with the dev team.

### C. Flakes (passed in other runs this same day)

5. **T-011 — Semak Kemaskini**
   `TimeoutException: Element not clickable after 15s: textContains("SEMAK KEMASKINI")` — the Menu Selaras popup transiently rendered without its bottom items (same transient T-010 hit twice before). T-011 PASSED in 3 earlier runs the same day, including the Phase-2 full run. Fix queued: apply T-010's close-and-reopen self-heal to T-011 (one-line change, `pages/pelarasan_page.py`).

### Midnight-crossing artifact (affects A.1 above)

The run started ~23:00 on 2026-07-16 and finished ~01:20 on 2026-07-17. Senarai's default date range is *today → tomorrow*, so once the clock passed midnight, records created before midnight (N-001/P-001's) fell outside the default range and the N/P-004 Kemaskini tests could not find their jenis rows — they failed earlier (row not found) than their real blocker (unrenderable form section). For clean per-TC evidence, run the suite within a single calendar day. A robustness improvement (widen the Senarai date filter to yesterday→tomorrow in `ensure_records_listed`) is a candidate for a follow-up.

## Fixes made during Phase 3 (all verified live)

- **TN-002**: `No Notis` field rejects `send_keys` (`InvalidElementStateException`) → `mobile: type` with `keep_keyboard`. Now PASSES.
- **NK-001**: the NOTIS TO KOMPAUN FORM is in the unscrollable family → promoted `reveal_below_fold` (TAB→DPAD focus traversal) from KemaskiniPage to BasePage and used it for the amount / pembantu / camera / MENYERAHKAN; filled the required `NO PEMBANTU PENGUATKUASA`; added the **mandatory photo** ("GAMBAR MESTI DIAMBIL."). Now PASSES.
- **NK-002**: the ulasan field lives below the fold of the notice popup (drags must start on a **label** — EditTexts swallow them); ulasan is mandatory ("ULASAN WAJIB DIISI.") and a photo is also mandatory ("SILA AMBIL GAMBAR."); keyboard must be closed via single Back-with-IME-open (a bare Back dismisses the whole modal; `hide_keyboard` too). Now PASSES.
- **S-001 partials**: jenis-select verification must not use "SITAAN text gone" (the screen title is also SITAAN); tier-3 confirm switched to the "PILIH KADAR DENDA" label; kadar fallback ladder extended (`following::` axis + preset-"0" tier + focus-traversal reveal); tempoh fill tolerant of the pre-filled variant; "NO AKAUN LESEN" (AKAUN) label candidate added.
- **Senarai row picking**: `open_record_by_jenis(..., which="last")` for Kemaskini flows (an update issues a NEW record number, per the tester's SENARAI sheet).

## Blocked / open items

1. ~~**Clip (lampiran) icon location**~~ — **RESOLVED 2026-07-17** (see the UPDATE at the top): user located it in the record popup's LAMPIRAN row; N/P/K/L-003 now PASS, S-003 blocked only by S-001's precondition.
2. **Bookmark save UI** — not present in build 2.1.14 (only PILIH/HAPUS). Needs dev-team confirmation whether saving was removed/moved; the -005 tests will keep failing honestly until the UI exists.
3. **Kemaskini form lower section** — never renders; blocks completing any -004 TC. Dev-team issue (matches the tester's L-004 report).
4. **Sitaan Kadar Denda field** — unreachable on the Sitaan create form; blocks S-001 (and hence S-004's precondition). Dev-team issue candidate (the tester's S-001 also failed).
5. **P/K/L resubmission rejected server-side** — H-002/003/004; DATA RALAT accumulating.
6. **T-011 flake** — self-heal fix queued (see C.5).
7. **T-008 Pelesen** — intentionally skipped per your instruction (52k-record sync ≈ 1h). Re-enable by restoring it to the conftest steps list if ever needed.
8. **TN-003** — no sheet/UI for "by Tarikh" exists (the Tarik popup has only ID Penguatkuasa + No Notis); the v3-added test verifies notices are retrieved and identifiable by tarikh (DD-MM-YYYY row dates).

## Reference — prior phase verified tables

- **Phase 1** (`phase1_run3.log`, 34m37s): 13 PASSED / 6 SKIPPED / 6 FAILED (N/P/K-003 later converted to SKIP per your decision; H-001..003 were the server-rejection fails).
- **Phase 2** (`phase2_run1.log`, 1h25m): 17 PASSED / 10 SKIPPED / 12 FAILED, plus T-010 fixed and verified solo right after (`shakedown_t010d.log`).
- All run logs, shakedown logs (`shakedown_*.log`) and recon dumps (`ui_dumps/`, `recon/`) are kept in the v3 folder.

## Suite facts

- `pytest tests -v` from `v3\` runs all 48 TCs in List-to-Test order and prints the summary table above after every run.
- Data: `testdata/excel_data.py` — every value cited to its sheet/cell; environment overrides documented (lesen 352405067769401, login msc/Pass1, K-001 plate JYX6605).
- Requirements: Appium server running on 127.0.0.1:4723, device connected, app installed (no_reset).

# MBIP v3 — Laporan Pembaikan & Status Run

**Tarikh:** 2026-07-28  **Profil:** `mbip-staging` (219.93.38.103:8880, data kosong)
**APK:** 2.1.17 (build debug staging)  **Peranti:** 5008TF2010009401 (Armor 27)

---

## 0. Ringkasan eksekutif

- **Semua pembaikan yang diminta SIAP dan DISAHKAN secara langsung pada peranti** — Bug 1 (dropdown), Bug 2 (tempoh), Perf, FASA 2 (skrin merah RN), FASA 3 (rekod nombor), plus penemuan tambahan (drain printer menyeluruh, stale-retry).
- **Run penuh 48 TC TIDAK dapat disiapkan tanpa pengawasan.** Sebab: **tugas background dibunuh oleh persekitaran ~15–30 minit selepas mula** semasa laptop dikunci/idle (2 run berturut-turut dibunuh di N-001 dan P-001; monitor ringan pun dibunuh). Awal sesi, semasa Shu aktif, run background hidup 15+ minit tanpa masalah — jadi ini had persekitaran bila laptop idle, bukan pepijat kod.
- **Penemuan besar:** nilai KESALAHAN dari Excel produksi **tiada** di server staging kosong untuk AKTA yang dipilih → TC create (N/P/K/L/S-001) gagal. Ini **kategori D (khusus persekitaran)** DAN isu **mudah-alih** ke majlis lain.

**Tindakan diperlukan:** Shu jalankan `tests\run_and_report.bat` sendiri di terminal (sesi aktif) untuk inventori FASA 5 lengkap — kod dah siap & disahkan.

---

## 1. Pembaikan (disahkan langsung — bukti dalam log)

| # | Isu | Pembaikan | Bukti hidup |
|---|-----|-----------|-------------|
| **Bug 1** | Dropdown ditaip tapi **tidak dipilih** (Keterangan Kod Kompaun, Kod Akta, Kesalahan) — kod lama tap medan input (padan `text`), pulang "berjaya" palsu | Padan **baris pilihan ikut `content-desc`** (mustahil kena medan input). **`el.click()` (ACTION_CLICK) mendaftar pemilihan** — tap koordinat mentah senyap no-op (baris ini nod aksesibiliti sebenar, lawan dari RN pressable lain). Padanan **ends-with** untuk prefix kod (`"39 - UUK 7…"`). Filter **prefix pendek** + fallback clear-filter/scroll. Sahkan senarai tertutup; gagal jelas "tidak didaftarkan" | `SELECTED 'KOMPAUN PELBAGAI' via click-tap … list CLOSED`; `SELECTED 'UUK 7 UNDANG-UNDANG KECIL TAMAN (MDJBT) 1987' via click-tap` |
| **Bug 2** | Tempoh Kompaun tak dikosongkan → nilai lama (cth 90) kekal, di luar had 0–21, borang tersekat | Punca sebenar: `LABEL_TEMPOH_NOTIS="MAKLUMAT KOMPAUN"` padan **tajuk seksyen (TextView)**, bukan medan. Medan sebenar = EditText `hint="TEMPOH NOTIS"` (sibling tajuk). Kini guna locator itu + **force-clear** (Ctrl+A+Del, sebab `el.clear()` diabai RN) + **baca semula** + assert **0–21**; raise kalau salah/luar julat | `[TEMPOH] set & read back = '1' (in range 0-21) — PASS` |
| **Perf** | `is_element_present(timeout=1)` makan ~10s (implicit×explicit bertindih); `reveal_below_fold` ~500s | `IMPLICIT_WAIT` 10→2; `reveal_below_fold` max_tabs 25→8, timeout dalaman 1→0.5 | S-001 gagal-pantas **44s** (dulu hang **17 min**) |
| **FASA 2** | Skrin merah RN "Could not connect to development server" boleh rosakkan semua TC selepasnya | `_handle_rn_redscreen()` dalam `_recover_to_home`: kesan → tekan DISMISS → kalau degil, relaunch app. Dikira & dilaporkan | (tiada berlaku dalam run staging setakat ini; kiraan = 0) |
| **FASA 3** | Nombor rekod tak dijejak | `read_record_number()` baca `IPA…` dari popup resit sebelum tutup; `record_artifact()` di 5 TC create (kunci `no_notis`/`no_kompaun`). **Tidak reka nilai** — kosong bermaksud tak dapat dibaca | (bergantung create berjaya; belum berlaku atas staging) |
| **+Drain printer** | Alert "Unable to connect device" (printer BT tidur) tutup skrin di banyak tempat | `drain_printer_alert()` dalam base_page, dipanggil dalam laluan retry (`find_element`/`find_clickable`), **dikira global**, **DIKECUALIKAN dari flow Cetak** (di situ ia isyarat sebenar) | `[PRINTER-ALERT] 'Unable to connect device' detected -- draining #1` |
| **+Stale-retry** | Borang Pesalah re-render (restore draf) → medan stale masa taip | Retry re-resolve dalam `fill_field_by_label_or_instance` | `Pesalah tab filled — PASS` (dulu stale-fail cold-start) |
| **+Printer override (run ini sahaja)** | Printer tak boleh dihidupkan, operator tiada | `MBIP_PRINTER_TIMEOUT=30 MBIP_PRINTER_NOBEEP=1` → tunggu 30s, tiada bip; skip "printer tidak dihidupkan — operator tiada" | (env, tak ubah kelakuan normal) |

---

## 2. Penemuan penting

### 2.1 KESALAHAN produksi tiada di staging kosong (kategori D + isu mudah-alih)
N-001 gagal kerana pilihan KESALAHAN **"MEMOTONG, MENGALIH, … POKOK-POKOK."** (dari Excel produksi) **langsung tidak render** dalam dropdown untuk AKTA "UUK 7 …" di server staging — disahkan **walaupun selepas Menu Selaras (sync) dijalankan penuh**. Dump: senarai kosong ("Tiada rekod dijumpai").

**Maksud:**
- N/P/K/L/S-001 (dan TC bergantung -002/-003/-004) akan gagal di staging kerana data rujukan (kod kompaun/akta/kesalahan) tak sepadan. **Dijangka, bukan regresi** — seperti amaran Shu tentang staging kosong.
- **Mudah-alih ke MBJB/MBPG/MDKT:** data ujian (`testdata/excel_data.py` — nilai kesalahan/akta) mengandaikan rekod sisi-server tertentu. Setiap majlis mesti ada data rujukan sepadan, ATAU data ujian perlu per-majlis. **Ini mesti diselesaikan sebelum salin.**

### 2.2 Teknik: `el.click()` untuk baris dropdown
Baris pilihan dropdown ialah nod aksesibiliti (`content-desc`) yang **respons kepada ACTION_CLICK (`el.click()`)** — berbeza dari RN pressable lain yang perlu tap koordinat. Ini teknik penting untuk keseluruhan suite.

### 2.3 Borang Sitaan perlu printer BT bersambung
Dari sesi terdahulu: borang Sitaan lontar "Unable to connect device" bila printer tidur → tab Pesalah tak boleh diisi. Drain menyeluruh (2.1 di atas) menanganinya di kebanyakan skrin, tapi bila printer memang mati, S-* tetap terjejas.

---

## 3. FASA 5 — inventori (SEPARA — run tak siap)

Run penuh tak sempat habis, jadi inventori penuh A/B/C/D per-TC **tertangguh**. Yang **disahkan** setakat ini:

| TC | Keputusan | Kategori | Ikut ke majlis lain? | Nota |
|----|-----------|----------|----------------------|------|
| T-001…T-012 | PASS (T-008 SKIP by design) | — | — | Menu Selaras + login OK atas staging |
| N-001 | FAIL | **D** (data staging) | Ya (kalau data majlis tak sepadan) | KESALAHAN tiada di staging (§2.1) |
| N-002…S-002 (Cetak) | SKIP (dijangka) | **C** (printer luar) | Tidak | Printer mati + operator tiada — betul |
| -004 (Kemaskini) | FAIL (jangkaan) | **B** (bug app) | Ya | Borang bawah tak render — isu app (CLAUDE.md) |
| -005 (Bookmark) | FAIL (jangkaan) | **B** (bug app) | Ya | UI bookmark tiada dalam build |
| S-001/003/004 | FAIL (jangkaan) | **B/C/D** | sebahagian | Kadar Denda + printer + data |

> Nota: baki TC (P/K/L/S create+serah, H, TN, NK) perlu run lengkap untuk keputusan sebenar dengan kod baharu. Kod dropdown/tempoh **dah disahkan berfungsi** untuk pilihan yang datanya wujud.

---

## 4. Halangan: run tak siap tanpa pengawasan

- 2 run background dibunuh oleh persekitaran (~15–30 min selepas mula) semasa laptop dikunci/idle. Monitor ringan pun dibunuh. Peranti + Appium kekal sihat sepanjang masa.
- Run penuh perlu ~60–90 min → tak boleh habis dalam tetingkap ~15–30 min sebelum dibunuh. `results.json` hanya ditulis di HUJUNG run, jadi run separa tak menghasilkan dashboard.
- **Bukan pepijat kod** — awal sesi (Shu aktif) run hidup lama. Ini polisi idle/lock persekitaran.

**Cara siapkan (Shu, bila kembali):**
```
tests\run_and_report.bat
```
Pilih `mbip-staging`. Biar tetingkap terminal aktif (jangan kunci laptop) sepanjang run. Untuk printer-tunggu pendek run ini:
```
set MBIP_PRINTER_TIMEOUT=30
set MBIP_PRINTER_NOBEEP=1
tests\run_and_report.bat
```
Dashboard + `results.json` dijana automatik di hujung.

---

## 5. Mesti dibaiki sebelum salin ke MBJB/MBPG/MDKT

1. **Data ujian per-majlis** — nilai kompaun/akta/kesalahan (`testdata/excel_data.py`) mesti wujud di server setiap majlis, atau sediakan set data per-majlis. Ini punca kegagalan create terbesar di staging (§2.1). **Keutamaan tertinggi.**
2. **Bug app -004 (Kemaskini bawah tak render) & -005 (Bookmark)** — isu aplikasi merentas majlis; tester manual pun laporkan. Perlu pembetulan APK, bukan kod ujian.
3. **Kadar Denda / borang Sitaan** — sahkan sama ada muncul bila printer BT bersambung + data lengkap (belum dapat disahkan run ini kerana blocker data + printer).
4. **Kebergantungan printer BT** — borang Sitaan & TC Cetak perlu printer hidup; dokumen prasyarat operator untuk setiap majlis.

---

## 6. Perbandingan tempoh
**Tempoh run baharu vs 93 min baseline: N/A** — run baharu tak siap (dibunuh persekitaran). Petunjuk perf positif: S-001 gagal-pantas 44s vs hang 17-min sebelum ini; `is_element_present` tak lagi makan 10s.

---

*Fail: `reports/laporan_pembaikan_2026-07-28.md`*

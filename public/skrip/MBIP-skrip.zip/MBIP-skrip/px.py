import subprocess as s
s.run(["adb","kill-server"],capture_output=True,text=True)
s.run(["adb","start-server"],capture_output=True,text=True)
r=s.run(["adb","devices"],capture_output=True,text=True)
out="DEVICES:\n"+r.stdout+"\n"
for line in r.stdout.splitlines()[1:]:
    parts=line.split()
    if len(parts)>=2 and parts[1]=="device":
        ser=parts[0]
        p=s.run(["adb","-s",ser,"shell","pm","list","packages","com.anonymous.react_ies_v1"],capture_output=True,text=True)
        m=s.run(["adb","-s",ser,"shell","getprop","ro.product.model"],capture_output=True,text=True)
        out+=f"{ser} model={m.stdout.strip()} app={p.stdout.strip() or 'TIADA'}\n"
open("ui_dumps/px_out.txt","w").write(out)
print(out)

"""
Phase-2 recon A: crack the unscrollable KEMASKINI record form.
Tries, in order, reporting which technique actually moves the form:
  1. mobile: scrollGesture anchored to the ScrollView element
  2. mobile: swipeGesture anchored to the ScrollView element
  3. W3C slow drag with pauses (drag, not fling)
  4. UiScrollable scrollForward on each scrollable instance
Movement is detected by the set of visible EditText texts changing.
"""

import os
import sys
import time

HERE = os.path.dirname(__file__)
sys.path.insert(0, os.path.join(HERE, ".."))

from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy

from config import (APPIUM_URL, DEVICE_NAME, PLATFORM_NAME, APP_PACKAGE,
                    APP_ACTIVITY, AUTOMATION_NAME)
from pages.login_page import LoginPage
from pages.home_page import HomePage
from pages.senarai_page import SenaraiPage
from testdata.excel_data import TEST_CREDENTIALS

OUT = os.path.join(HERE, "..", "ui_dumps")


def visible_state(driver):
    els = driver.find_elements(AppiumBy.CLASS_NAME,
                               "android.widget.EditText")
    return tuple((e.text, e.rect["y"]) for e in els)


def moved(driver, before):
    after = visible_state(driver)
    return after != before, after


def main():
    options = UiAutomator2Options()
    options.device_name = DEVICE_NAME
    options.platform_name = PLATFORM_NAME
    options.app_package = APP_PACKAGE
    options.app_activity = APP_ACTIVITY
    options.no_reset = True
    options.full_reset = False
    options.automation_name = AUTOMATION_NAME
    options.set_capability("disableAndroidWatchers", True)
    driver = webdriver.Remote(APPIUM_URL, options=options)
    driver.implicitly_wait(3)

    login = LoginPage(driver)
    home = HomePage(driver)
    senarai = SenaraiPage(driver)

    try:
        if not home.is_element_present(home.HOME_SCREEN_INDICATOR, timeout=5):
            login._force_relaunch_to_login()
            login.login(TEST_CREDENTIALS["username"],
                        TEST_CREDENTIALS["password"])
        home.open_senarai()
        time.sleep(2)
        senarai.ensure_records_listed()
        senarai.open_record_by_jenis("N")
        time.sleep(1)
        el = senarai.find_element((AppiumBy.ACCESSIBILITY_ID, "KEMASKINI"),
                                  timeout=10)
        senarai.tap_element(el)
        time.sleep(2)
        popup_field = (AppiumBy.ANDROID_UIAUTOMATOR,
                       'new UiSelector().textContains("ISI KEMASKINI")')
        el = senarai.find_element(popup_field, timeout=10)
        el.click()
        el.clear()
        driver.execute_script('mobile: type', {'text': 'RECON'})
        try:
            driver.hide_keyboard()
        except Exception:
            pass
        el = senarai.find_element((AppiumBy.ACCESSIBILITY_ID, "SETERUSNYA"),
                                  timeout=5)
        senarai.tap_element(el)
        time.sleep(3)
        title = (AppiumBy.ANDROID_UIAUTOMATOR,
                 'new UiSelector().text("KEMASKINI NOTIS AMARAN")')
        assert senarai.is_element_present(title, timeout=10), \
            "edit form did not open"
        print("[SCROLL] on the KEMASKINI NOTIS AMARAN form", flush=True)

        scrollables = driver.find_elements(
            AppiumBy.ANDROID_UIAUTOMATOR,
            'new UiSelector().scrollable(true)')
        print(f"[SCROLL] scrollable containers: {len(scrollables)}",
              flush=True)
        for i, sc in enumerate(scrollables):
            print(f"[SCROLL]   #{i}: {sc.get_attribute('className')} "
                  f"{sc.rect}", flush=True)

        # 1) element-anchored scrollGesture
        before = visible_state(driver)
        if scrollables:
            try:
                driver.execute_script('mobile: scrollGesture', {
                    'elementId': scrollables[0].id,
                    'direction': 'down', 'percent': 0.8})
                time.sleep(1)
                ok, before = moved(driver, before)
                print(f"[SCROLL] 1) anchored scrollGesture moved: {ok}",
                      flush=True)
            except Exception as e:
                print(f"[SCROLL] 1) anchored scrollGesture error: {e}",
                      flush=True)

        # 2) element-anchored swipeGesture
        if scrollables:
            try:
                scrollables = driver.find_elements(
                    AppiumBy.ANDROID_UIAUTOMATOR,
                    'new UiSelector().scrollable(true)')
                driver.execute_script('mobile: swipeGesture', {
                    'elementId': scrollables[0].id,
                    'direction': 'up', 'percent': 0.8, 'speed': 800})
                time.sleep(1)
                ok, before = moved(driver, before)
                print(f"[SCROLL] 2) anchored swipeGesture moved: {ok}",
                      flush=True)
            except Exception as e:
                print(f"[SCROLL] 2) anchored swipeGesture error: {e}",
                      flush=True)

        # 3) W3C slow drag with pauses
        try:
            from selenium.webdriver.common.action_chains import ActionChains
            from selenium.webdriver.common.actions import interaction
            from selenium.webdriver.common.actions.action_builder import \
                ActionBuilder
            from selenium.webdriver.common.actions.pointer_input import \
                PointerInput
            actions = ActionChains(driver)
            pointer = PointerInput(interaction.POINTER_TOUCH, "finger")
            actions.w3c_actions = ActionBuilder(driver, mouse=pointer,
                                                duration=80)
            pa = actions.w3c_actions.pointer_action
            pa.move_to_location(540, 1900)
            pa.pointer_down()
            pa.pause(0.3)
            for y in range(1900, 500, -100):
                pa.move_to_location(540, y)
            pa.pause(0.3)
            pa.release()
            actions.perform()
            time.sleep(1)
            ok, before = moved(driver, before)
            print(f"[SCROLL] 3) W3C slow drag moved: {ok}", flush=True)
        except Exception as e:
            print(f"[SCROLL] 3) W3C slow drag error: {e}", flush=True)

        # 4) UiScrollable per instance
        for inst in range(3):
            try:
                driver.find_element(
                    AppiumBy.ANDROID_UIAUTOMATOR,
                    f'new UiScrollable(new UiSelector().scrollable(true)'
                    f'.instance({inst})).scrollForward()')
                time.sleep(1)
                ok, before = moved(driver, before)
                print(f"[SCROLL] 4) UiScrollable instance({inst}) moved: "
                      f"{ok}", flush=True)
                if ok:
                    break
            except Exception as e:
                print(f"[SCROLL] 4) UiScrollable instance({inst}) error: "
                      f"{type(e).__name__}", flush=True)

        driver.save_screenshot(os.path.join(OUT, "recon_scroll_final.png"))
        with open(os.path.join(OUT, "recon_scroll_final.xml"), "w",
                  encoding="utf-8") as f:
            f.write(driver.page_source)
        print("[SCROLL] final state saved", flush=True)
        for _ in range(3):
            driver.back()
            time.sleep(1)
    finally:
        driver.quit()


if __name__ == "__main__":
    main()

"""Recon: the LAMPIRAN row + paperclip icon in the record-detail popup
(location confirmed by the user: below KADAR DENDA / GAMBAR / MAKLUMAT
PENGUATKUASA / TANDA TANGAN, just above the pinned KEMASKINI/CETAK
buttons). Scroll the popup down until LAMPIRAN renders, dump + shot."""

import os
import re
import sys
import time

HERE = os.path.dirname(__file__)
sys.path.insert(0, os.path.join(HERE, ".."))

from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy

from config import (APPIUM_URL, DEVICE_NAME, PLATFORM_NAME, APP_PACKAGE,
                    APP_ACTIVITY, AUTOMATION_NAME)
from pages.login_page import LoginPage
from pages.home_page import HomePage
from pages.senarai_page import SenaraiPage
from testdata.excel_data import TEST_CREDENTIALS

OUT = os.path.join(HERE, "..", "ui_dumps")


def snap(driver, name):
    src = driver.page_source
    with open(os.path.join(OUT, name + ".xml"), "w", encoding="utf-8") as f:
        f.write(src)
    driver.save_screenshot(os.path.join(OUT, name + ".png"))
    return src


def main():
    options = UiAutomator2Options()
    options.device_name = DEVICE_NAME
    options.platform_name = PLATFORM_NAME
    options.app_package = APP_PACKAGE
    options.app_activity = APP_ACTIVITY
    options.no_reset = True
    options.full_reset = False
    options.automation_name = AUTOMATION_NAME
    options.set_capability("disableAndroidWatchers", True)
    driver = webdriver.Remote(APPIUM_URL, options=options)
    driver.implicitly_wait(4)

    login = LoginPage(driver)
    home = HomePage(driver)
    senarai = SenaraiPage(driver)

    try:
        if not home.is_element_present(home.HOME_SCREEN_INDICATOR, timeout=5):
            login._force_relaunch_to_login()
            login.login(TEST_CREDENTIALS["username"],
                        TEST_CREDENTIALS["password"])
        home.go_back_to_home()
        home.open_senarai()
        time.sleep(2)
        senarai.ensure_records_listed()
        senarai.open_record_by_jenis("N")
        time.sleep(1)

        # Scroll the popup content down hunting for LAMPIRAN. Content
        # rows here are TextViews (not EditTexts), so plain swipes in
        # the content region should not be swallowed; anchor mid-content
        # above the pinned buttons (~y2000).
        found = False
        for i in range(12):
            src = driver.page_source
            if "LAMPIRAN" in src:
                found = True
                print(f"[LAMPIRAN] visible after {i} swipes", flush=True)
                break
            driver.swipe(540, 1750, 540, 600, 700)
            time.sleep(0.8)
        src = snap(driver, "lampiran_popup_bottom")
        if not found and "LAMPIRAN" in src:
            found = True
        print(f"[LAMPIRAN] found={found}", flush=True)

        sys.stdout.reconfigure(encoding="utf-8", errors="backslashreplace")
        for m in re.finditer(r'<[\w.]+ [^>]*?/?>', src):
            tag = m.group(0)
            cls = re.search(r'class="([^"]*)"', tag)
            txt = re.search(r'text="([^"]*)"', tag)
            desc = re.search(r'content-desc="([^"]*)"', tag)
            clk = 'clickable="true"' in tag
            b = re.search(r'bounds="([^"]*)"', tag)
            t = txt.group(1) if txt else ""
            d = desc.group(1) if desc else ""
            if t or d or clk:
                print(("CLK " if clk else "    ")
                      + (cls.group(1) if cls else "?").split(".")[-1][:10].ljust(11),
                      (b.group(1) if b else "").ljust(24),
                      "text=" + repr(t[:36]).ljust(30),
                      "desc=" + repr(d[:30]), flush=True)
        # leave popup open for a possible follow-up probe
    finally:
        driver.quit()


if __name__ == "__main__":
    main()

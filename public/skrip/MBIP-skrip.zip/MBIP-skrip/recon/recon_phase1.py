"""
One-off live recon for the Phase 1 fixes (run manually, not a test):
  A. Selaras Pengguna Apps / Pelesen / Barang Sita — how long until their
     result alert really arrives (or what shows instead).
  B. Senarai table — where the clip (lampiran) icon actually lives.
  C. KEMASKINI DATA popup — does the X close work with a raw tap.
Dumps go to ui_dumps/recon_*.xml; findings print to stdout.
"""

import os
import sys
import time

sys.path.insert(0, os.path.dirname(__file__))

from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy

from config import (APPIUM_URL, DEVICE_NAME, PLATFORM_NAME, APP_PACKAGE,
                    APP_ACTIVITY, AUTOMATION_NAME, IMPLICIT_WAIT)
from pages.login_page import LoginPage
from pages.pelarasan_page import PelarasanPage
from pages.home_page import HomePage
from pages.senarai_page import SenaraiPage
from testdata.excel_data import TEST_CREDENTIALS

OUT = os.path.join(os.path.dirname(__file__), "ui_dumps")
os.makedirs(OUT, exist_ok=True)


def dump(driver, name):
    path = os.path.join(OUT, name)
    with open(path, "w", encoding="utf-8") as f:
        f.write(driver.page_source)
    print(f"  [RECON] dumped {name}")


def wait_alert(page, label, max_wait=180):
    """Poll for a native alert; report elapsed time and message."""
    t0 = time.monotonic()
    while time.monotonic() - t0 < max_wait:
        if page.is_element_present(page.NATIVE_ALERT_OK, timeout=2):
            elapsed = time.monotonic() - t0
            try:
                msg = page.driver.find_element(
                    *page.NATIVE_ALERT_MESSAGE).text
            except Exception:
                msg = "(no message element)"
            print(f"  [RECON] {label}: alert after {elapsed:.0f}s: {msg!r}")
            page.driver.find_element(*page.NATIVE_ALERT_OK).click()
            time.sleep(0.5)
            # drain queued
            while page.is_element_present(page.NATIVE_ALERT_OK, timeout=2):
                try:
                    m2 = page.driver.find_element(
                        *page.NATIVE_ALERT_MESSAGE).text
                    print(f"  [RECON] {label}: queued alert: {m2!r}")
                except Exception:
                    pass
                page.driver.find_element(*page.NATIVE_ALERT_OK).click()
                time.sleep(0.5)
            return True
    print(f"  [RECON] {label}: NO alert within {max_wait}s")
    return False


def main():
    options = UiAutomator2Options()
    options.device_name = DEVICE_NAME
    options.platform_name = PLATFORM_NAME
    options.app_package = APP_PACKAGE
    options.app_activity = APP_ACTIVITY
    options.no_reset = True
    options.full_reset = False
    options.automation_name = AUTOMATION_NAME
    options.set_capability("disableAndroidWatchers", True)
    driver = webdriver.Remote(APPIUM_URL, options=options)
    driver.implicitly_wait(IMPLICIT_WAIT)

    login = LoginPage(driver)
    pel = PelarasanPage(driver)
    home = HomePage(driver)
    senarai = SenaraiPage(driver)

    try:
        # ---------------- A: Selaras timings ----------------
        pel.ensure_on_login_screen()
        pel.open_menu_selaras()

        print("\n[RECON A1] SELARAS PENGGUNA APPS")
        pel.wait_and_tap(pel.MENU_SELARAS_PENGGUNA_APPS)
        wait_alert(pel, "Pengguna Apps", max_wait=180)

        print("\n[RECON A2] SELARAS MAKLUMAT PELESEN")
        pel.wait_and_tap(pel.MENU_SELARAS_PELESEN)
        got = wait_alert(pel, "Pelesen", max_wait=60)
        if not got:
            dump(driver, "recon_pelesen_60s.xml")
            wait_alert(pel, "Pelesen (extended)", max_wait=120)

        print("\n[RECON A3] SELARAS MAKLUMAT BARANG SITA")
        pel.wait_and_tap(pel.MENU_SELARAS_BARANG_SITA)
        wait_alert(pel, "Barang Sita", max_wait=90)

        pel.close_menu_selaras()

        # ---------------- B: Senarai clip icon hunt ----------------
        print("\n[RECON B] LOGIN + SENARAI")
        login.login(TEST_CREDENTIALS["username"],
                    TEST_CREDENTIALS["password"])
        home.open_senarai()
        time.sleep(2)
        if not senarai.ensure_records_listed():
            print("  [RECON] WARNING: no records listed")
        dump(driver, "recon_senarai_table.xml")

        descs = senarai.get_row_descriptions()
        for d in descs[:10]:
            print(f"  [RECON] row: {d!r}")

        # horizontal scroll the table to reveal trailing cells
        size = driver.get_window_size()
        y = int(size["height"] * 0.5)
        for i in range(2):
            driver.swipe(int(size["width"] * 0.9), y,
                         int(size["width"] * 0.1), y, 600)
            time.sleep(1)
        dump(driver, f"recon_senarai_table_hscroll.xml")

        # ---------------- C: record popup close behavior ----------------
        print("\n[RECON C] RECORD POPUP (KEMASKINI DATA)")
        # scroll back left first
        for i in range(2):
            driver.swipe(int(size["width"] * 0.1), y,
                         int(size["width"] * 0.9), y, 600)
            time.sleep(1)
        try:
            senarai.open_record_by_jenis("N")
            dump(driver, "recon_record_popup_N.xml")
            x_loc = (AppiumBy.ACCESSIBILITY_ID, "✕")
            if senarai.is_element_present(x_loc, timeout=3):
                el = senarai.find_element(x_loc, timeout=3)
                senarai.tap_element(el)
                time.sleep(1.5)
                closed = not senarai.is_element_present(
                    (AppiumBy.ANDROID_UIAUTOMATOR,
                     'new UiSelector().text("KEMASKINI DATA")'), timeout=3)
                print(f"  [RECON] popup X raw-tap closed popup: {closed}")
            else:
                print("  [RECON] no U+2715 close found on popup")
        except Exception as e:
            print(f"  [RECON] record popup step failed: {e}")

        print("\n[RECON] done")
    finally:
        driver.quit()


if __name__ == "__main__":
    main()

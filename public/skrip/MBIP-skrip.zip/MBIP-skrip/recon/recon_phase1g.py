"""Recon #7: dump/screenshot the Hantar screen (Belum Hantar + Data
Ralat tabs) hunting for the clip (lampiran) icon on record rows."""

import os
import re
import sys
import time

sys.path.insert(0, os.path.dirname(__file__))

from appium import webdriver
from appium.options.android import UiAutomator2Options

from config import (APPIUM_URL, DEVICE_NAME, PLATFORM_NAME, APP_PACKAGE,
                    APP_ACTIVITY, AUTOMATION_NAME, IMPLICIT_WAIT)
from pages.login_page import LoginPage
from pages.home_page import HomePage
from pages.hantar_page import HantarPage
from testdata.excel_data import TEST_CREDENTIALS

OUT = os.path.join(os.path.dirname(__file__), "ui_dumps")


def snap(driver, name):
    src = driver.page_source
    with open(os.path.join(OUT, name + ".xml"), "w", encoding="utf-8") as f:
        f.write(src)
    driver.save_screenshot(os.path.join(OUT, name + ".png"))
    glyphs = {}
    for m in re.finditer(r'(?:text|content-desc)="([^"]*)"', src):
        for ch in m.group(1):
            cp = ord(ch)
            if 0xE000 <= cp <= 0xF8FF or 0xF0000 <= cp <= 0xFFFFD:
                glyphs[hex(cp)] = glyphs.get(hex(cp), 0) + 1
    print(f"[RECON7] {name}: glyphs={glyphs}", flush=True)


def main():
    options = UiAutomator2Options()
    options.device_name = DEVICE_NAME
    options.platform_name = PLATFORM_NAME
    options.app_package = APP_PACKAGE
    options.app_activity = APP_ACTIVITY
    options.no_reset = True
    options.full_reset = False
    options.automation_name = AUTOMATION_NAME
    options.set_capability("disableAndroidWatchers", True)
    driver = webdriver.Remote(APPIUM_URL, options=options)
    driver.implicitly_wait(5)

    login = LoginPage(driver)
    home = HomePage(driver)
    hantar = HantarPage(driver)

    try:
        if not home.is_element_present(home.HOME_SCREEN_INDICATOR, timeout=5):
            login._force_relaunch_to_login()
            login.login(TEST_CREDENTIALS["username"],
                        TEST_CREDENTIALS["password"])
        home.open_hantar()
        time.sleep(2)
        snap(driver, "recon_hantar_belum")
        try:
            hantar.switch_to_data_ralat_tab()
            time.sleep(2)
            snap(driver, "recon_hantar_ralat")
        except Exception as e:
            print(f"[RECON7] data ralat tab failed: {e}", flush=True)
        for _ in range(2):
            driver.back()
            time.sleep(1)
    finally:
        driver.quit()


if __name__ == "__main__":
    main()

"""Recon #9: crack the unscrollable full-screen record forms via
focus-traversal (TAB keycode 61) -- RN scrolls the focused field into
view. Applied to the HantarSemula record view; dumps + screenshots as
new content appears. Also the definitive scroll technique needed by the
Phase-2 Kemaskini flows."""

import os
import re
import sys
import time

sys.path.insert(0, os.path.dirname(__file__))

from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy

from config import (APPIUM_URL, DEVICE_NAME, PLATFORM_NAME, APP_PACKAGE,
                    APP_ACTIVITY, AUTOMATION_NAME)
from pages.login_page import LoginPage
from pages.home_page import HomePage
from testdata.excel_data import TEST_CREDENTIALS

OUT = os.path.join(os.path.dirname(__file__), "ui_dumps")


def snap(driver, name, seen):
    src = driver.page_source
    with open(os.path.join(OUT, name + ".xml"), "w", encoding="utf-8") as f:
        f.write(src)
    driver.save_screenshot(os.path.join(OUT, name + ".png"))
    new = []
    for m in re.finditer(r'(?:text|content-desc)="([^"]+)"', src):
        v = m.group(1)
        if v not in seen:
            seen.add(v)
            new.append(v)
    if new:
        print((f"[RECON9] {name}: new: " +
               " | ".join(repr(x[:45]) for x in new))
              .encode("ascii", "backslashreplace").decode(), flush=True)
    return src


def main():
    options = UiAutomator2Options()
    options.device_name = DEVICE_NAME
    options.platform_name = PLATFORM_NAME
    options.app_package = APP_PACKAGE
    options.app_activity = APP_ACTIVITY
    options.no_reset = True
    options.full_reset = False
    options.automation_name = AUTOMATION_NAME
    options.set_capability("disableAndroidWatchers", True)
    driver = webdriver.Remote(APPIUM_URL, options=options)
    driver.implicitly_wait(5)

    login = LoginPage(driver)
    home = HomePage(driver)

    try:
        if not home.is_element_present(home.HOME_SCREEN_INDICATOR, timeout=5):
            login._force_relaunch_to_login()
            login.login(TEST_CREDENTIALS["username"],
                        TEST_CREDENTIALS["password"])
        home.open_hantar()
        time.sleep(2)
        row = (AppiumBy.ANDROID_UIAUTOMATOR,
               'new UiSelector().descriptionContains("IPA3N")')
        el = home.find_element(row, timeout=10)
        home.tap_element(el)
        time.sleep(2)

        seen = set()
        snap(driver, "recon_hsr_tab0", seen)

        # focus the LAST EditText currently on screen, then TAB through
        edits = driver.find_elements(AppiumBy.CLASS_NAME,
                                     "android.widget.EditText")
        if edits:
            edits[-1].click()
            time.sleep(0.5)
        for i in range(1, 15):
            driver.press_keycode(61)  # TAB
            time.sleep(0.7)
            src = snap(driver, f"recon_hsr_tab{i}", seen)
            if "OPEN CAMERA" in src or "GAMBAR" in src:
                print(f"[RECON9] camera/gambar area reached at tab {i}",
                      flush=True)
                break

        try:
            driver.hide_keyboard()
        except Exception:
            pass
        snap(driver, "recon_hsr_final", seen)
        for _ in range(3):
            driver.back()
            time.sleep(1)
    finally:
        driver.quit()


if __name__ == "__main__":
    main()

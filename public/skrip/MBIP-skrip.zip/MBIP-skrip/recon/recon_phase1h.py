"""Recon #8: h-scroll the Hantar Belum-Hantar table for trailing columns;
then tap the record row to see what opens. Screenshots + dumps."""

import os
import re
import sys
import time

sys.path.insert(0, os.path.dirname(__file__))

from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy

from config import (APPIUM_URL, DEVICE_NAME, PLATFORM_NAME, APP_PACKAGE,
                    APP_ACTIVITY, AUTOMATION_NAME)
from pages.login_page import LoginPage
from pages.home_page import HomePage
from testdata.excel_data import TEST_CREDENTIALS

OUT = os.path.join(os.path.dirname(__file__), "ui_dumps")


def snap(driver, name):
    src = driver.page_source
    with open(os.path.join(OUT, name + ".xml"), "w", encoding="utf-8") as f:
        f.write(src)
    driver.save_screenshot(os.path.join(OUT, name + ".png"))
    vals = set(re.findall(r'(?:text|content-desc)="([^"]+)"', src))
    out = " | ".join(sorted(repr(v[:38]) for v in vals))
    print(f"[RECON8] {name}: {out}".encode("ascii", "backslashreplace")
          .decode(), flush=True)


def main():
    options = UiAutomator2Options()
    options.device_name = DEVICE_NAME
    options.platform_name = PLATFORM_NAME
    options.app_package = APP_PACKAGE
    options.app_activity = APP_ACTIVITY
    options.no_reset = True
    options.full_reset = False
    options.automation_name = AUTOMATION_NAME
    options.set_capability("disableAndroidWatchers", True)
    driver = webdriver.Remote(APPIUM_URL, options=options)
    driver.implicitly_wait(5)

    login = LoginPage(driver)
    home = HomePage(driver)

    try:
        if not home.is_element_present(home.HOME_SCREEN_INDICATOR, timeout=5):
            login._force_relaunch_to_login()
            login.login(TEST_CREDENTIALS["username"],
                        TEST_CREDENTIALS["password"])
        home.open_hantar()
        time.sleep(2)

        # h-scroll the table row area (y ~ 990) right-to-left
        for i in range(3):
            driver.swipe(950, 990, 150, 990, 700)
            time.sleep(1)
            snap(driver, f"recon_hantar_hscroll{i}")

        # scroll back, then tap the record row
        for _ in range(3):
            driver.swipe(150, 990, 950, 990, 700)
            time.sleep(0.5)
        row = (AppiumBy.ANDROID_UIAUTOMATOR,
               'new UiSelector().descriptionContains("IPA3N")')
        el = home.find_element(row, timeout=10)
        rect = el.rect
        driver.tap([(rect['x'] + rect['width'] // 2,
                     rect['y'] + rect['height'] // 2)])
        time.sleep(2)
        snap(driver, "recon_hantar_rowtap")

        for _ in range(3):
            driver.back()
            time.sleep(1)
    finally:
        driver.quit()


if __name__ == "__main__":
    main()

"""
Recon #6: hunt the clip (lampiran) icon on the CREATE form's Notis tab
(around OPEN CAMERA -- the one area never dumped). Fills the Pesalah tab
with the N-001 Excel data (v2-proven flow), moves to the Notis tab,
scrolls through it dumping + screenshotting. Backs out WITHOUT
submitting.
"""

import os
import re
import sys
import time

sys.path.insert(0, os.path.dirname(__file__))

from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy

from config import (APPIUM_URL, DEVICE_NAME, PLATFORM_NAME, APP_PACKAGE,
                    APP_ACTIVITY, AUTOMATION_NAME, IMPLICIT_WAIT)
from pages.login_page import LoginPage
from pages.home_page import HomePage
from pages.notis_amaran_page import NotisAmaranPage
from testdata.excel_data import TEST_CREDENTIALS, TC_DATA

OUT = os.path.join(os.path.dirname(__file__), "ui_dumps")


def dump_and_report(driver, name, seen):
    src = driver.page_source
    with open(os.path.join(OUT, name + ".xml"), "w", encoding="utf-8") as f:
        f.write(src)
    driver.save_screenshot(os.path.join(OUT, name + ".png"))
    new = []
    for m in re.finditer(r'(?:text|content-desc)="([^"]+)"', src):
        v = m.group(1)
        if v not in seen:
            seen.add(v)
            new.append(v)
    if new:
        safe = " | ".join(repr(x[:40]) for x in new)
        print(f"[RECON6] {name}: new: {safe}".encode(
            "ascii", "backslashreplace").decode(), flush=True)


def main():
    options = UiAutomator2Options()
    options.device_name = DEVICE_NAME
    options.platform_name = PLATFORM_NAME
    options.app_package = APP_PACKAGE
    options.app_activity = APP_ACTIVITY
    options.no_reset = True
    options.full_reset = False
    options.automation_name = AUTOMATION_NAME
    options.set_capability("disableAndroidWatchers", True)
    driver = webdriver.Remote(APPIUM_URL, options=options)
    driver.implicitly_wait(IMPLICIT_WAIT)

    login = LoginPage(driver)
    home = HomePage(driver)
    notis = NotisAmaranPage(driver)
    data = TC_DATA["MBIP-TC-N-001"]

    try:
        login._force_relaunch_to_login()
        login.login(TEST_CREDENTIALS["username"], TEST_CREDENTIALS["password"])
        home.open_notis_amaran()
        assert notis.is_notis_amaran_screen_displayed()

        notis.fill_pesalah_tab(data)
        notis.click_seterusnya_from_pesalah()
        time.sleep(2)

        seen = set()
        dump_and_report(driver, "recon_notistab_0", seen)
        for i in range(1, 8):
            notis._scroll_down()
            time.sleep(0.5)
            dump_and_report(driver, f"recon_notistab_{i}", seen)
            src = driver.page_source
            if "OPEN CAMERA" in src:
                print("[RECON6] OPEN CAMERA visible at step", i, flush=True)

        print("[RECON6] done -- backing out without submitting", flush=True)
        for _ in range(4):
            driver.back()
            time.sleep(1)
    finally:
        driver.quit()


if __name__ == "__main__":
    main()

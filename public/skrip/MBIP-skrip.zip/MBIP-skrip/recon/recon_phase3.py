"""
Phase-3 recon:
  A. jenis popup -> SITAAN -> dump the Sitaan Pesalah tab (fields incl.
     the Barang-barang seized-items area if visible).
  B. Notis Kompaun -> TARIK NOTIS popup: dump ALL fields (TN-002 by
     No.Notis / TN-003 by Tarikh need to know what beyond ID exists).
  C. After a tarik by msc: row tap -> popup -> dump; tap KOMPAUN -> dump
     (amount UI) -> close WITHOUT confirming; reopen -> tap PATUH ->
     dump (ulasan UI) -> close WITHOUT confirming.
"""

import os
import re
import sys
import time

HERE = os.path.dirname(__file__)
sys.path.insert(0, os.path.join(HERE, ".."))

from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy

from config import (APPIUM_URL, DEVICE_NAME, PLATFORM_NAME, APP_PACKAGE,
                    APP_ACTIVITY, AUTOMATION_NAME)
from pages.login_page import LoginPage
from pages.home_page import HomePage
from pages.notis_kompaun_page import NotisKompaunPage
from testdata.excel_data import TEST_CREDENTIALS

OUT = os.path.join(HERE, "..", "ui_dumps")


def snap(driver, name):
    src = driver.page_source
    with open(os.path.join(OUT, name + ".xml"), "w", encoding="utf-8") as f:
        f.write(src)
    driver.save_screenshot(os.path.join(OUT, name + ".png"))
    vals = sorted(set(re.findall(r'(?:text|content-desc)="([^"]+)"', src)))
    print((f"[P3] {name}: " + " | ".join(repr(v[:45]) for v in vals))
          .encode("ascii", "backslashreplace").decode(), flush=True)
    return src


def main():
    options = UiAutomator2Options()
    options.device_name = DEVICE_NAME
    options.platform_name = PLATFORM_NAME
    options.app_package = APP_PACKAGE
    options.app_activity = APP_ACTIVITY
    options.no_reset = True
    options.full_reset = False
    options.automation_name = AUTOMATION_NAME
    options.set_capability("disableAndroidWatchers", True)
    driver = webdriver.Remote(APPIUM_URL, options=options)
    driver.implicitly_wait(5)

    login = LoginPage(driver)
    home = HomePage(driver)
    nk = NotisKompaunPage(driver)

    def to_home():
        for _ in range(4):
            if home.is_element_present(home.HOME_SCREEN_INDICATOR,
                                       timeout=3):
                return True
            driver.back()
            time.sleep(1)
        return False

    try:
        if not home.is_element_present(home.HOME_SCREEN_INDICATOR, timeout=5):
            login._force_relaunch_to_login()
            login.login(TEST_CREDENTIALS["username"],
                        TEST_CREDENTIALS["password"])

        # ---------------- A: Sitaan form ----------------
        print("[P3] === A: SITAAN form ===", flush=True)
        home.open_daftar_kompaun()
        time.sleep(1.5)
        sitaan = (AppiumBy.ANDROID_UIAUTOMATOR,
                  'new UiSelector().text("SITAAN")')
        el = nk.find_element(sitaan, timeout=10)
        nk.tap_element(el)
        time.sleep(2)
        snap(driver, "p3_sitaan_pesalah_top")
        for i in range(3):
            nk._scroll_down()
            time.sleep(0.5)
        snap(driver, "p3_sitaan_pesalah_scrolled")
        to_home()

        # ---------------- B: Tarik Notis popup ----------------
        print("[P3] === B: TARIK NOTIS popup ===", flush=True)
        home.open_notis_kompaun()
        time.sleep(1.5)
        nk.click_tarik_notis()
        time.sleep(1.5)
        snap(driver, "p3_tarik_popup")
        # close it (avoid hide_keyboard -- dismissible modal)
        driver.back()
        time.sleep(1)

        # ---------------- C: NK sub-popups ----------------
        print("[P3] === C: NK Kompaun/Patuh sub-popups ===", flush=True)
        try:
            nk.tarik_notis("msc")
        except Exception as e:
            print(f"[P3] tarik warning: {e}", flush=True)
        row = (AppiumBy.ANDROID_UIAUTOMATOR,
               'new UiSelector().className("android.view.ViewGroup")'
               '.descriptionMatches(".*\\d{2}-\\d{2}-\\d{4}.*")')
        el = nk.find_element(row, timeout=10)
        print(f"[P3] tapping row {el.get_attribute('content-desc')!r}",
              flush=True)
        nk.tap_element(el)
        time.sleep(2)
        snap(driver, "p3_nk_popup")

        kompaun_btn = (AppiumBy.ANDROID_UIAUTOMATOR,
                       'new UiSelector().text("KOMPAUN")')
        if nk.is_element_present(kompaun_btn, timeout=4):
            el = nk.find_element(kompaun_btn, timeout=4)
            nk.tap_element(el)
            time.sleep(2)
            snap(driver, "p3_nk_kompaun_ui")
            driver.back()
            time.sleep(1.5)

        # reopen the notis popup if it closed
        if not nk.is_element_present(
                (AppiumBy.ANDROID_UIAUTOMATOR,
                 'new UiSelector().textContains("NO NOTIS")'), timeout=3):
            el = nk.find_element(row, timeout=10)
            nk.tap_element(el)
            time.sleep(2)

        patuh_btn = (AppiumBy.ANDROID_UIAUTOMATOR,
                     'new UiSelector().text("PATUH")')
        if nk.is_element_present(patuh_btn, timeout=4):
            el = nk.find_element(patuh_btn, timeout=4)
            nk.tap_element(el)
            time.sleep(2)
            snap(driver, "p3_nk_patuh_ui")
            driver.back()
            time.sleep(1.5)

        to_home()
        print("[P3] recon done", flush=True)
    finally:
        driver.quit()


if __name__ == "__main__":
    main()

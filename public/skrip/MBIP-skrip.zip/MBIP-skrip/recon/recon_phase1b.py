"""
Recon #2: find the clip (lampiran) icon.
Path: home -> Senarai -> open N record popup -> KEMASKINI -> dump the
edit form (top + after scrolls). Lists every icon-glyph node seen.
Also doubles as recon for the Phase-2 Kemaskini flows.
"""

import os
import sys
import time

sys.path.insert(0, os.path.dirname(__file__))

from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy

from config import (APPIUM_URL, DEVICE_NAME, PLATFORM_NAME, APP_PACKAGE,
                    APP_ACTIVITY, AUTOMATION_NAME, IMPLICIT_WAIT)
from pages.login_page import LoginPage
from pages.home_page import HomePage
from pages.senarai_page import SenaraiPage
from testdata.excel_data import TEST_CREDENTIALS

OUT = os.path.join(os.path.dirname(__file__), "ui_dumps")


def dump(driver, name):
    path = os.path.join(OUT, name)
    with open(path, "w", encoding="utf-8") as f:
        f.write(driver.page_source)
    print(f"[RECON2] dumped {name}", flush=True)


def glyphs(driver, label):
    """Print every PUA icon glyph currently in the tree."""
    import re
    s = driver.page_source
    found = {}
    for m in re.finditer(r'(text|content-desc)="([^"]*)"', s):
        for ch in m.group(2):
            cp = ord(ch)
            if 0xE000 <= cp <= 0xF8FF or 0xF0000 <= cp <= 0xFFFFD:
                found.setdefault(hex(cp), 0)
                found[hex(cp)] += 1
    print(f"[RECON2] {label}: glyphs {found}", flush=True)


def main():
    options = UiAutomator2Options()
    options.device_name = DEVICE_NAME
    options.platform_name = PLATFORM_NAME
    options.app_package = APP_PACKAGE
    options.app_activity = APP_ACTIVITY
    options.no_reset = True
    options.full_reset = False
    options.automation_name = AUTOMATION_NAME
    options.set_capability("disableAndroidWatchers", True)
    driver = webdriver.Remote(APPIUM_URL, options=options)
    driver.implicitly_wait(IMPLICIT_WAIT)

    login = LoginPage(driver)
    home = HomePage(driver)
    senarai = SenaraiPage(driver)

    try:
        if not home.is_element_present(home.HOME_SCREEN_INDICATOR,
                                       timeout=5):
            login._force_relaunch_to_login()
            login.login(TEST_CREDENTIALS["username"],
                        TEST_CREDENTIALS["password"])

        home.open_senarai()
        time.sleep(2)
        if not senarai.ensure_records_listed():
            print("[RECON2] WARNING: no records listed", flush=True)

        senarai.open_record_by_jenis("N")
        time.sleep(1)

        kemaskini = (AppiumBy.ACCESSIBILITY_ID, "KEMASKINI")
        el = senarai.find_element(kemaskini, timeout=10)
        senarai.tap_element(el)
        print("[RECON2] tapped KEMASKINI", flush=True)
        time.sleep(3)

        dump(driver, "recon_kemaskini_form_top.xml")
        glyphs(driver, "kemaskini form top")

        for i in range(4):
            senarai._scroll_down()
            time.sleep(0.5)
            dump(driver, f"recon_kemaskini_form_scroll{i+1}.xml")
            glyphs(driver, f"kemaskini form scroll{i+1}")

        print("[RECON2] done", flush=True)
    finally:
        driver.quit()


if __name__ == "__main__":
    main()

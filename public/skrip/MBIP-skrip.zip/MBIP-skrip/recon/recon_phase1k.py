"""Recon #11: Notis Kompaun module -- tarik notis (msc), then tap a
pulled record row; dump/screenshot what opens (clip icon hunt + TN/NK
Phase-3 recon)."""

import os
import re
import sys
import time

sys.path.insert(0, os.path.dirname(__file__))

from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy

from config import (APPIUM_URL, DEVICE_NAME, PLATFORM_NAME, APP_PACKAGE,
                    APP_ACTIVITY, AUTOMATION_NAME)
from pages.login_page import LoginPage
from pages.home_page import HomePage
from pages.notis_kompaun_page import NotisKompaunPage
from testdata.excel_data import TEST_CREDENTIALS

OUT = os.path.join(os.path.dirname(__file__), "ui_dumps")


def snap(driver, name):
    src = driver.page_source
    with open(os.path.join(OUT, name + ".xml"), "w", encoding="utf-8") as f:
        f.write(src)
    driver.save_screenshot(os.path.join(OUT, name + ".png"))
    vals = sorted(set(re.findall(r'(?:text|content-desc)="([^"]+)"', src)))
    print((f"[RECON11] {name}: " + " | ".join(repr(v[:40]) for v in vals))
          .encode("ascii", "backslashreplace").decode(), flush=True)


def main():
    options = UiAutomator2Options()
    options.device_name = DEVICE_NAME
    options.platform_name = PLATFORM_NAME
    options.app_package = APP_PACKAGE
    options.app_activity = APP_ACTIVITY
    options.no_reset = True
    options.full_reset = False
    options.automation_name = AUTOMATION_NAME
    options.set_capability("disableAndroidWatchers", True)
    driver = webdriver.Remote(APPIUM_URL, options=options)
    driver.implicitly_wait(5)

    login = LoginPage(driver)
    home = HomePage(driver)
    nk = NotisKompaunPage(driver)

    try:
        if not home.is_element_present(home.HOME_SCREEN_INDICATOR, timeout=5):
            login._force_relaunch_to_login()
            login.login(TEST_CREDENTIALS["username"],
                        TEST_CREDENTIALS["password"])
        home.open_notis_kompaun()
        time.sleep(2)
        snap(driver, "recon_nk_screen")
        try:
            nk.tarik_notis("msc")
        except Exception as e:
            print(f"[RECON11] tarik notis issue: {e}", flush=True)
        snap(driver, "recon_nk_after_tarik")

        row = (AppiumBy.ANDROID_UIAUTOMATOR,
               'new UiSelector().className("android.view.ViewGroup")'
               '.descriptionMatches(".*(\\d{4}-\\d{2}-\\d{2}|'
               '\\d{2}-\\d{2}-\\d{4}).*")')
        if nk.is_element_present(row, timeout=5):
            el = nk.find_element(row, timeout=5)
            print(f"[RECON11] tapping row: "
                  f"{el.get_attribute('content-desc')!r}", flush=True)
            nk.tap_element(el)
            time.sleep(2)
            snap(driver, "recon_nk_rowtap")
        for _ in range(3):
            driver.back()
            time.sleep(1)
    finally:
        driver.quit()


if __name__ == "__main__":
    main()

"""Recon: what does the PILIHAN KEGEMARAN popup look like when the
form's kompaun codes ARE filled? Close the current popup, ensure codes
selected, reopen the book icon, dump + screenshot."""

import os
import re
import sys
import time

HERE = os.path.dirname(__file__)
sys.path.insert(0, os.path.join(HERE, ".."))

from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy

from config import (APPIUM_URL, DEVICE_NAME, PLATFORM_NAME, APP_PACKAGE,
                    APP_ACTIVITY, AUTOMATION_NAME)
from pages.notis_amaran_page import NotisAmaranPage
from pages.bookmark_page import BookmarkPage
from testdata.excel_data import TC_DATA

OUT = os.path.join(HERE, "..", "ui_dumps")


def snap(driver, name):
    src = driver.page_source
    with open(os.path.join(OUT, name + ".xml"), "w", encoding="utf-8") as f:
        f.write(src)
    driver.save_screenshot(os.path.join(OUT, name + ".png"))
    vals = sorted(set(re.findall(r'(?:text|content-desc)="([^"]+)"', src)))
    print((f"[BMRECON] {name}: " + " | ".join(repr(v[:40]) for v in vals))
          .encode("ascii", "backslashreplace").decode(), flush=True)
    return src


def main():
    options = UiAutomator2Options()
    options.device_name = DEVICE_NAME
    options.platform_name = PLATFORM_NAME
    options.app_package = APP_PACKAGE
    options.app_activity = APP_ACTIVITY
    options.no_reset = True
    options.full_reset = False
    options.automation_name = AUTOMATION_NAME
    options.set_capability("disableAndroidWatchers", True)
    driver = webdriver.Remote(APPIUM_URL, options=options)
    driver.implicitly_wait(5)

    na = NotisAmaranPage(driver)
    bm = BookmarkPage(driver)
    data = TC_DATA["MBIP-TC-N-005"]

    try:
        # close the PILIHAN KEGEMARAN popup if it's still open
        x = (AppiumBy.ANDROID_UIAUTOMATOR, 'new UiSelector().text("✕")')
        if na.is_element_present(x, timeout=4):
            el = na.find_element(x, timeout=3)
            na.tap_element(el)
            time.sleep(1)
            print("[BMRECON] closed leftover popup", flush=True)

        # are we on the Notis tab with codes empty?
        pilih1 = (AppiumBy.ANDROID_UIAUTOMATOR,
                  'new UiSelector().text("PILIH KOMPAUN")')
        title = (AppiumBy.ANDROID_UIAUTOMATOR,
                 'new UiSelector().text("PAPARAN NOTIS")')
        if not na.is_element_present(title, timeout=4):
            print("[BMRECON] not on PAPARAN NOTIS -- aborting (state "
                  "changed)", flush=True)
            return
        try:
            el = na.find_element(pilih1, timeout=10)
            print("[BMRECON] codes ARE empty -- selecting the N-005 combo",
                  flush=True)
            na.fill_kompaun_code_fields(data)
        except Exception as e:
            print(f"[BMRECON] PILIH KOMPAUN not found ({type(e).__name__})"
                  f" -- codes may already be selected", flush=True)

        snap(driver, "bmrecon_form_codes")
        bm.open_bookmark_popup_raw = None  # not used; direct icon tap
        icon = (AppiumBy.ANDROID_UIAUTOMATOR,
                'new UiSelector().text("")')
        # scroll up to the icon
        for _ in range(5):
            if na.is_element_present(icon, timeout=2):
                break
            bm._scroll_up()
        el = na.find_element(icon, timeout=5)
        na.tap_element(el)
        time.sleep(2)
        snap(driver, "bmrecon_popup_with_codes")
        # leave popup open for inspection; back out gently
        for _ in range(2):
            driver.back()
            time.sleep(1)
    finally:
        driver.quit()


if __name__ == "__main__":
    main()

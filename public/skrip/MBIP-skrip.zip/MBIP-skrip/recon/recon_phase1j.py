"""Recon #10: TAB all the way to the bottom of the HantarSemula record
form; snap every few tabs; stop when the tree stops changing."""

import os
import re
import sys
import time

sys.path.insert(0, os.path.dirname(__file__))

from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy

from config import (APPIUM_URL, DEVICE_NAME, PLATFORM_NAME, APP_PACKAGE,
                    APP_ACTIVITY, AUTOMATION_NAME)
from pages.login_page import LoginPage
from pages.home_page import HomePage
from testdata.excel_data import TEST_CREDENTIALS

OUT = os.path.join(os.path.dirname(__file__), "ui_dumps")


def main():
    options = UiAutomator2Options()
    options.device_name = DEVICE_NAME
    options.platform_name = PLATFORM_NAME
    options.app_package = APP_PACKAGE
    options.app_activity = APP_ACTIVITY
    options.no_reset = True
    options.full_reset = False
    options.automation_name = AUTOMATION_NAME
    options.set_capability("disableAndroidWatchers", True)
    driver = webdriver.Remote(APPIUM_URL, options=options)
    driver.implicitly_wait(3)

    login = LoginPage(driver)
    home = HomePage(driver)

    try:
        title = (AppiumBy.ANDROID_UIAUTOMATOR,
                 'new UiSelector().textContains("HantarSemulaRalat")')
        if not home.is_element_present(title, timeout=4):
            if not home.is_element_present(home.HOME_SCREEN_INDICATOR,
                                           timeout=5):
                login._force_relaunch_to_login()
                login.login(TEST_CREDENTIALS["username"],
                            TEST_CREDENTIALS["password"])
            home.open_hantar()
            time.sleep(2)
            row = (AppiumBy.ANDROID_UIAUTOMATOR,
                   'new UiSelector().descriptionContains("IPA3N")')
            el = home.find_element(row, timeout=10)
            home.tap_element(el)
            time.sleep(2)

        edits = driver.find_elements(AppiumBy.CLASS_NAME,
                                     "android.widget.EditText")
        if edits:
            edits[-1].click()
            time.sleep(0.5)

        seen = set()
        stale_rounds = 0
        for i in range(60):
            driver.press_keycode(61)
            time.sleep(0.4)
            if i % 4 != 3:
                continue
            src = driver.page_source
            new = [v for v in re.findall(
                r'(?:text|content-desc)="([^"]+)"', src)
                if v not in seen and not seen.add(v)]
            if new:
                stale_rounds = 0
                print((f"[RECON10] tab{i}: " +
                       " | ".join(repr(x[:45]) for x in sorted(set(new)))
                       ).encode("ascii", "backslashreplace").decode(),
                      flush=True)
                with open(os.path.join(OUT, f"recon_hsr2_tab{i}.xml"),
                          "w", encoding="utf-8") as f:
                    f.write(src)
                driver.save_screenshot(
                    os.path.join(OUT, f"recon_hsr2_tab{i}.png"))
            else:
                stale_rounds += 1
                if stale_rounds >= 3:
                    print(f"[RECON10] tree static after tab{i} -- stopping",
                          flush=True)
                    break

        try:
            driver.hide_keyboard()
        except Exception:
            pass
        driver.save_screenshot(os.path.join(OUT, "recon_hsr2_bottom.png"))
        with open(os.path.join(OUT, "recon_hsr2_bottom.xml"), "w",
                  encoding="utf-8") as f:
            f.write(driver.page_source)
        print("[RECON10] final snap saved", flush=True)
        for _ in range(3):
            driver.back()
            time.sleep(1)
    finally:
        driver.quit()


if __name__ == "__main__":
    main()

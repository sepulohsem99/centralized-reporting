"""
Recon #5: screenshots. Record popup -> screenshot; KEMASKINI form ->
screenshot; swipe attempts -> screenshots. Visual ground truth for the
clip-icon hunt and the unscrollable form.
"""

import os
import sys
import time

sys.path.insert(0, os.path.dirname(__file__))

from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy

from config import (APPIUM_URL, DEVICE_NAME, PLATFORM_NAME, APP_PACKAGE,
                    APP_ACTIVITY, AUTOMATION_NAME)
from pages.login_page import LoginPage
from pages.home_page import HomePage
from pages.senarai_page import SenaraiPage
from testdata.excel_data import TEST_CREDENTIALS

OUT = os.path.join(os.path.dirname(__file__), "ui_dumps")


def shot(driver, name):
    driver.save_screenshot(os.path.join(OUT, name))
    print(f"[RECON5] screenshot {name}", flush=True)


def main():
    options = UiAutomator2Options()
    options.device_name = DEVICE_NAME
    options.platform_name = PLATFORM_NAME
    options.app_package = APP_PACKAGE
    options.app_activity = APP_ACTIVITY
    options.no_reset = True
    options.full_reset = False
    options.automation_name = AUTOMATION_NAME
    options.set_capability("disableAndroidWatchers", True)
    driver = webdriver.Remote(APPIUM_URL, options=options)
    driver.implicitly_wait(3)

    login = LoginPage(driver)
    home = HomePage(driver)
    senarai = SenaraiPage(driver)

    try:
        # normalize: relaunch -> login -> senarai
        login._force_relaunch_to_login()
        login.login(TEST_CREDENTIALS["username"], TEST_CREDENTIALS["password"])
        home.open_senarai()
        time.sleep(2)
        senarai.ensure_records_listed()
        shot(driver, "shot_senarai.png")

        senarai.open_record_by_jenis("N")
        time.sleep(1.5)
        shot(driver, "shot_record_popup.png")

        el = senarai.find_element((AppiumBy.ACCESSIBILITY_ID, "KEMASKINI"),
                                  timeout=10)
        senarai.tap_element(el)
        time.sleep(2)
        shot(driver, "shot_sila_isi.png")

        popup_field = (AppiumBy.ANDROID_UIAUTOMATOR,
                       'new UiSelector().textContains("ISI KEMASKINI")')
        el = senarai.find_element(popup_field, timeout=10)
        el.click()
        el.clear()
        driver.execute_script('mobile: type', {'text': 'RECON'})
        try:
            driver.hide_keyboard()
        except Exception:
            pass
        el = senarai.find_element((AppiumBy.ACCESSIBILITY_ID, "SETERUSNYA"),
                                  timeout=5)
        senarai.tap_element(el)
        time.sleep(3)
        shot(driver, "shot_kform_top.png")

        # try UiScrollable scrollForward on the first scrollable
        try:
            driver.find_element(
                AppiumBy.ANDROID_UIAUTOMATOR,
                'new UiScrollable(new UiSelector().scrollable(true)'
                '.instance(0)).scrollForward()')
            print("[RECON5] UiScrollable scrollForward executed", flush=True)
        except Exception as e:
            print(f"[RECON5] UiScrollable failed: {type(e).__name__}",
                  flush=True)
        time.sleep(1)
        shot(driver, "shot_kform_after_uiscroll.png")

        driver.swipe(540, 2200, 540, 800, 600)
        time.sleep(1)
        shot(driver, "shot_kform_after_swipe.png")

        for _ in range(3):
            driver.back()
            time.sleep(1)
    finally:
        driver.quit()


if __name__ == "__main__":
    main()

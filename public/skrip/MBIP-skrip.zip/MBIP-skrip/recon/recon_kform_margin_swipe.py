"""Final kemaskini-scroll experiment: drags that START on non-EditText
areas (section-header TextView, right margin) after TAB-ing to the
bottom. If nothing below tempoh ever renders, the form's lower section
is genuinely broken in this build (matches the tester's L-004 failure
note) and the Kemaskini TCs fail honestly."""

import os
import sys
import time

HERE = os.path.dirname(__file__)
sys.path.insert(0, os.path.join(HERE, ".."))

from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy

from config import (APPIUM_URL, DEVICE_NAME, PLATFORM_NAME, APP_PACKAGE,
                    APP_ACTIVITY, AUTOMATION_NAME)
from pages.login_page import LoginPage
from pages.home_page import HomePage
from pages.senarai_page import SenaraiPage
from pages.kemaskini_page import KemaskiniPage
from testdata.excel_data import TEST_CREDENTIALS

OUT = os.path.join(HERE, "..", "ui_dumps")


def state(driver):
    import re
    src = driver.page_source
    texts = re.findall(r'text="([^"]+)"', src)
    return src, texts


def main():
    options = UiAutomator2Options()
    options.device_name = DEVICE_NAME
    options.platform_name = PLATFORM_NAME
    options.app_package = APP_PACKAGE
    options.app_activity = APP_ACTIVITY
    options.no_reset = True
    options.full_reset = False
    options.automation_name = AUTOMATION_NAME
    options.set_capability("disableAndroidWatchers", True)
    driver = webdriver.Remote(APPIUM_URL, options=options)
    driver.implicitly_wait(3)

    login = LoginPage(driver)
    home = HomePage(driver)
    senarai = SenaraiPage(driver)
    kem = KemaskiniPage(driver)

    try:
        if not home.is_element_present(home.HOME_SCREEN_INDICATOR, timeout=5):
            login._force_relaunch_to_login()
            login.login(TEST_CREDENTIALS["username"],
                        TEST_CREDENTIALS["password"])
        home.open_senarai()
        time.sleep(2)
        senarai.ensure_records_listed()
        senarai.open_record_by_jenis("N", which="last")
        kem.start_kemaskini("RECON MARGIN SWIPE")
        time.sleep(1)

        # TAB down to the known stall point first
        edits = driver.find_elements(AppiumBy.CLASS_NAME,
                                     "android.widget.EditText")
        if edits:
            edits[-1].click()
            time.sleep(0.5)
        for _ in range(15):
            driver.press_keycode(61)
            time.sleep(0.4)
        try:
            driver.hide_keyboard()
        except Exception:
            pass
        time.sleep(1)

        _, before = state(driver)
        print(f"[MARGIN] at stall point; texts={sorted(set(before))[:8]}...",
              flush=True)

        # A) drag starting on the section header (non-EditText)
        hdr = None
        for t in ("MAKLUMAT KOMPAUN", "MAKLUMAT KESALAHAN"):
            loc = (AppiumBy.ANDROID_UIAUTOMATOR,
                   f'new UiSelector().text("{t}")')
            if kem.is_element_present(loc, timeout=2):
                hdr = driver.find_element(*loc)
                break
        if hdr is not None:
            r = hdr.rect
            x, y = r["x"] + 10, r["y"] + r["height"] // 2
            print(f"[MARGIN] A) drag from header at ({x},{y})", flush=True)
            driver.swipe(x, y, x, max(y - 1200, 300), 900)
            time.sleep(1.5)
            src, after = state(driver)
            new = set(after) - set(before)
            print(f"[MARGIN] A) new texts: {sorted(new)}", flush=True)
            before = after
            if "SETERUSNYA" in src:
                print("[MARGIN] A) SETERUSNYA FOUND", flush=True)

        # B) drag along the right margin (x=1040)
        print("[MARGIN] B) drag along right margin", flush=True)
        driver.swipe(1040, 2100, 1040, 500, 900)
        time.sleep(1.5)
        src, after = state(driver)
        new = set(after) - set(before)
        print(f"[MARGIN] B) new texts: {sorted(new)}", flush=True)
        if "SETERUSNYA" in src:
            print("[MARGIN] B) SETERUSNYA FOUND", flush=True)

        # C) drag in the gap BETWEEN two EditTexts (y between rows)
        print("[MARGIN] C) drag from inter-row gap", flush=True)
        driver.swipe(540, 2050, 540, 400, 900)
        time.sleep(1.5)
        src, after2 = state(driver)
        new = set(after2) - set(after)
        print(f"[MARGIN] C) new texts: {sorted(new)}", flush=True)
        if "SETERUSNYA" in src:
            print("[MARGIN] C) SETERUSNYA FOUND", flush=True)

        with open(os.path.join(OUT, "recon_margin_final.xml"), "w",
                  encoding="utf-8") as f:
            f.write(src)
        driver.save_screenshot(os.path.join(OUT, "recon_margin_final.png"))
        for _ in range(3):
            driver.back()
            time.sleep(1)
    finally:
        driver.quit()


if __name__ == "__main__":
    main()

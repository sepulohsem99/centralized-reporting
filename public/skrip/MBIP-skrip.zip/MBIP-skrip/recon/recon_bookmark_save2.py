"""Bookmark save-UI hunt, clean state: relaunch app -> login -> Notis
Amaran (draft resumes with codes selected) -> Notis tab -> (a) tap the
ribbon icon on a CLEAN form, dump; (b) if no name field: long-press the
ribbon, dump; (c) if still nothing: in the popup, tap PILIH with nothing
selected, dump."""

import os
import re
import sys
import time

HERE = os.path.dirname(__file__)
sys.path.insert(0, os.path.join(HERE, ".."))

from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy

from config import (APPIUM_URL, DEVICE_NAME, PLATFORM_NAME, APP_PACKAGE,
                    APP_ACTIVITY, AUTOMATION_NAME)
from pages.login_page import LoginPage
from pages.home_page import HomePage
from pages.notis_amaran_page import NotisAmaranPage
from testdata.excel_data import TEST_CREDENTIALS

OUT = os.path.join(HERE, "..", "ui_dumps")
ICON = (AppiumBy.ANDROID_UIAUTOMATOR,
        'new UiSelector().text("")')


def snap(driver, name):
    src = driver.page_source
    with open(os.path.join(OUT, name + ".xml"), "w", encoding="utf-8") as f:
        f.write(src)
    driver.save_screenshot(os.path.join(OUT, name + ".png"))
    vals = sorted(set(re.findall(r'(?:text|content-desc)="([^"]+)"', src)))
    print((f"[BM2] {name}: " + " | ".join(repr(v[:40]) for v in vals))
          .encode("ascii", "backslashreplace").decode(), flush=True)
    return src


def main():
    options = UiAutomator2Options()
    options.device_name = DEVICE_NAME
    options.platform_name = PLATFORM_NAME
    options.app_package = APP_PACKAGE
    options.app_activity = APP_ACTIVITY
    options.no_reset = True
    options.full_reset = False
    options.automation_name = AUTOMATION_NAME
    options.set_capability("disableAndroidWatchers", True)
    driver = webdriver.Remote(APPIUM_URL, options=options)
    driver.implicitly_wait(5)

    login = LoginPage(driver)
    home = HomePage(driver)
    na = NotisAmaranPage(driver)

    try:
        login._force_relaunch_to_login()
        login.login(TEST_CREDENTIALS["username"], TEST_CREDENTIALS["password"])
        home.open_notis_amaran()
        time.sleep(2)

        # If the form opens on the Pesalah tab (relaunch clears the
        # draft -- confirmed live), fill it properly first.
        from testdata.excel_data import TC_DATA
        notis_tab_field = (AppiumBy.ANDROID_UIAUTOMATOR,
                           'new UiSelector().text("Maklumat Jalan")')
        if not na.is_element_present(notis_tab_field, timeout=4):
            print("[BM2] on Pesalah tab -- filling it", flush=True)
            na.dismiss_native_alerts(first_timeout=2, context="bm2")
            na.fill_pesalah_tab(TC_DATA["MBIP-TC-N-001"])
            na.click_seterusnya_from_pesalah()
            time.sleep(2)
        pilih1 = (AppiumBy.ANDROID_UIAUTOMATOR,
                  'new UiSelector().text("PILIH KOMPAUN")')
        if na.is_element_present(pilih1, timeout=4):
            print("[BM2] selecting kompaun codes", flush=True)
            na.fill_kompaun_code_fields(TC_DATA["MBIP-TC-N-005"])

        # back to top for the icon
        from pages.bookmark_page import BookmarkPage
        bmp = BookmarkPage(driver)
        for _ in range(5):
            if na.is_element_present(ICON, timeout=2):
                break
            bmp._scroll_up()
        if not na.is_element_present(ICON, timeout=4):
            print("[BM2] icon not visible -- viewport not at top?",
                  flush=True)
            snap(driver, "bm2_no_icon")
            return

        # (a) plain tap on clean form
        el = na.find_element(ICON, timeout=5)
        na.tap_element(el)
        time.sleep(2)
        src = snap(driver, "bm2_tap_popup")
        if "SIMPAN" in src or "NAMA" in src.upper():
            print("[BM2] SAVE UI FOUND after plain tap", flush=True)
            return

        # close popup
        x = (AppiumBy.ANDROID_UIAUTOMATOR, 'new UiSelector().text("✕")')
        if na.is_element_present(x, timeout=3):
            na.tap_element(na.find_element(x, timeout=3))
            time.sleep(1)

        # (b) long-press the icon
        el = na.find_element(ICON, timeout=5)
        r = el.rect
        driver.execute_script('mobile: longClickGesture', {
            'x': r['x'] + r['width'] // 2,
            'y': r['y'] + r['height'] // 2,
            'duration': 1200})
        time.sleep(2)
        src = snap(driver, "bm2_longpress")
        if "SIMPAN" in src:
            print("[BM2] SAVE UI FOUND after long-press", flush=True)
            return

        # close whatever opened
        if na.is_element_present(x, timeout=3):
            na.tap_element(na.find_element(x, timeout=3))
            time.sleep(1)

        # (c) tap icon then PILIH with nothing selected
        el = na.find_element(ICON, timeout=5)
        na.tap_element(el)
        time.sleep(2)
        pilih = (AppiumBy.ANDROID_UIAUTOMATOR,
                 'new UiSelector().text("PILIH")')
        if na.is_element_present(pilih, timeout=3):
            na.tap_element(na.find_element(pilih, timeout=3))
            time.sleep(2)
            snap(driver, "bm2_pilih_empty")
        for _ in range(2):
            driver.back()
            time.sleep(1)
    finally:
        driver.quit()


if __name__ == "__main__":
    main()

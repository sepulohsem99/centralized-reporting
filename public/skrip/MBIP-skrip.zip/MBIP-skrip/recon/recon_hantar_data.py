"""Recon #12: does HANTAR DATA actually do anything?
Raw-tap HANTAR DATA, watch 120s for any alert/progress, and compare the
Belum-Hantar row count + pagination label before/after."""

import os
import re
import sys
import time

HERE = os.path.dirname(__file__)
sys.path.insert(0, os.path.join(HERE, ".."))

from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy

from config import (APPIUM_URL, DEVICE_NAME, PLATFORM_NAME, APP_PACKAGE,
                    APP_ACTIVITY, AUTOMATION_NAME)
from pages.login_page import LoginPage
from pages.home_page import HomePage
from pages.hantar_page import HantarPage
from testdata.excel_data import TEST_CREDENTIALS

OUT = os.path.join(HERE, "..", "ui_dumps")


def belum_state(driver):
    src = driver.page_source
    label = re.search(r'text="(\d+-\d+ of \d+)"', src)
    rows = re.findall(r'content-desc="(IPA\w+)"', src)
    return (label.group(1) if label else "?", rows)


def main():
    options = UiAutomator2Options()
    options.device_name = DEVICE_NAME
    options.platform_name = PLATFORM_NAME
    options.app_package = APP_PACKAGE
    options.app_activity = APP_ACTIVITY
    options.no_reset = True
    options.full_reset = False
    options.automation_name = AUTOMATION_NAME
    options.set_capability("disableAndroidWatchers", True)
    driver = webdriver.Remote(APPIUM_URL, options=options)
    driver.implicitly_wait(5)

    login = LoginPage(driver)
    home = HomePage(driver)
    hantar = HantarPage(driver)

    try:
        if not home.is_element_present(home.HOME_SCREEN_INDICATOR, timeout=5):
            login._force_relaunch_to_login()
            login.login(TEST_CREDENTIALS["username"],
                        TEST_CREDENTIALS["password"])
        home.open_hantar()
        time.sleep(2)
        before = belum_state(driver)
        print(f"[RECON12] BELUM HANTAR before: {before}", flush=True)

        el = hantar.find_element(hantar.BUTTON_HANTAR_DATA, timeout=10)
        hantar.tap_element(el)
        print("[RECON12] raw-tapped HANTAR DATA", flush=True)

        driver.implicitly_wait(0)
        t0 = time.monotonic()
        while time.monotonic() - t0 < 120:
            if hantar.is_element_present(hantar.NATIVE_ALERT_OK, timeout=2):
                try:
                    msg = driver.find_element(
                        *hantar.NATIVE_ALERT_MESSAGE).text
                except Exception:
                    msg = "(no message)"
                print(f"[RECON12] alert after {time.monotonic()-t0:.0f}s: "
                      f"{msg!r}", flush=True)
                driver.find_element(*hantar.NATIVE_ALERT_OK).click()
                break
            time.sleep(2)
        else:
            print("[RECON12] NO alert within 120s", flush=True)
        driver.implicitly_wait(5)

        time.sleep(2)
        after = belum_state(driver)
        print(f"[RECON12] BELUM HANTAR after: {after}", flush=True)
        with open(os.path.join(OUT, "recon_hantar_after_data.xml"), "w",
                  encoding="utf-8") as f:
            f.write(driver.page_source)
        driver.save_screenshot(
            os.path.join(OUT, "recon_hantar_after_data.png"))
        for _ in range(2):
            driver.back()
            time.sleep(1)
    finally:
        driver.quit()


if __name__ == "__main__":
    main()

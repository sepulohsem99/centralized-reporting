"""
Recon #3: past the SILA ISI KETERANGAN popup into the Kemaskini edit
form; dump everything, hunting for the clip (lampiran) icon. Exits the
form WITHOUT submitting.
"""

import os
import sys
import time

sys.path.insert(0, os.path.dirname(__file__))

from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy

from config import (APPIUM_URL, DEVICE_NAME, PLATFORM_NAME, APP_PACKAGE,
                    APP_ACTIVITY, AUTOMATION_NAME, IMPLICIT_WAIT)
from pages.login_page import LoginPage
from pages.home_page import HomePage
from pages.senarai_page import SenaraiPage
from testdata.excel_data import TEST_CREDENTIALS

OUT = os.path.join(os.path.dirname(__file__), "ui_dumps")


def dump(driver, name):
    with open(os.path.join(OUT, name), "w", encoding="utf-8") as f:
        f.write(driver.page_source)
    print(f"[RECON3] dumped {name}", flush=True)


def main():
    options = UiAutomator2Options()
    options.device_name = DEVICE_NAME
    options.platform_name = PLATFORM_NAME
    options.app_package = APP_PACKAGE
    options.app_activity = APP_ACTIVITY
    options.no_reset = True
    options.full_reset = False
    options.automation_name = AUTOMATION_NAME
    options.set_capability("disableAndroidWatchers", True)
    driver = webdriver.Remote(APPIUM_URL, options=options)
    driver.implicitly_wait(IMPLICIT_WAIT)

    login = LoginPage(driver)
    home = HomePage(driver)
    senarai = SenaraiPage(driver)

    try:
        popup_field = (AppiumBy.ANDROID_UIAUTOMATOR,
                       'new UiSelector().textContains("ISI KEMASKINI")')
        if not senarai.is_element_present(popup_field, timeout=5):
            print("[RECON3] popup not open -- re-navigating", flush=True)
            if not home.is_element_present(home.HOME_SCREEN_INDICATOR,
                                           timeout=5):
                login._force_relaunch_to_login()
                login.login(TEST_CREDENTIALS["username"],
                            TEST_CREDENTIALS["password"])
            home.open_senarai()
            time.sleep(2)
            senarai.ensure_records_listed()
            senarai.open_record_by_jenis("N")
            time.sleep(1)
            el = senarai.find_element(
                (AppiumBy.ACCESSIBILITY_ID, "KEMASKINI"), timeout=10)
            senarai.tap_element(el)
            time.sleep(2)

        el = senarai.find_element(popup_field, timeout=10)
        el.click()
        el.clear()
        driver.execute_script('mobile: type', {'text': 'RECON'})
        try:
            driver.hide_keyboard()
        except Exception:
            pass
        time.sleep(0.5)

        seterusnya = (AppiumBy.ACCESSIBILITY_ID, "SETERUSNYA")
        el = senarai.find_element(seterusnya, timeout=5)
        senarai.tap_element(el)
        print("[RECON3] tapped SETERUSNYA", flush=True)
        time.sleep(3)

        dump(driver, "recon_kemaskini_edit_top.xml")
        for i in range(6):
            senarai._scroll_down()
            time.sleep(0.5)
            dump(driver, f"recon_kemaskini_edit_scroll{i+1}.xml")

        print("[RECON3] done (leaving form without submitting)", flush=True)
        # leave without submitting: back presses
        for _ in range(3):
            driver.back()
            time.sleep(1)
    finally:
        driver.quit()


if __name__ == "__main__":
    main()

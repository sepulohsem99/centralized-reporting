"""
Recon #4: raw slow swipes down the KEMASKINI NOTIS AMARAN edit form
(the standard scrollGesture didn't move it -- same resistance as the
Trafik form, where only a slow low-start driver.swipe worked). Dump
after each swipe and report anything new. Leaves without submitting.
"""

import os
import sys
import time

sys.path.insert(0, os.path.dirname(__file__))

from appium import webdriver
from appium.options.android import UiAutomator2Options
from appium.webdriver.common.appiumby import AppiumBy

from config import (APPIUM_URL, DEVICE_NAME, PLATFORM_NAME, APP_PACKAGE,
                    APP_ACTIVITY, AUTOMATION_NAME, IMPLICIT_WAIT)
from pages.login_page import LoginPage
from pages.home_page import HomePage
from pages.senarai_page import SenaraiPage
from testdata.excel_data import TEST_CREDENTIALS

OUT = os.path.join(os.path.dirname(__file__), "ui_dumps")


def main():
    options = UiAutomator2Options()
    options.device_name = DEVICE_NAME
    options.platform_name = PLATFORM_NAME
    options.app_package = APP_PACKAGE
    options.app_activity = APP_ACTIVITY
    options.no_reset = True
    options.full_reset = False
    options.automation_name = AUTOMATION_NAME
    options.set_capability("disableAndroidWatchers", True)
    driver = webdriver.Remote(APPIUM_URL, options=options)
    driver.implicitly_wait(3)

    login = LoginPage(driver)
    home = HomePage(driver)
    senarai = SenaraiPage(driver)

    try:
        form_title = (AppiumBy.ANDROID_UIAUTOMATOR,
                      'new UiSelector().text("KEMASKINI NOTIS AMARAN")')
        if not senarai.is_element_present(form_title, timeout=5):
            print("[RECON4] form not open -- re-navigating", flush=True)
            if not home.is_element_present(home.HOME_SCREEN_INDICATOR,
                                           timeout=5):
                login._force_relaunch_to_login()
                login.login(TEST_CREDENTIALS["username"],
                            TEST_CREDENTIALS["password"])
            home.open_senarai()
            time.sleep(2)
            senarai.ensure_records_listed()
            senarai.open_record_by_jenis("N")
            time.sleep(1)
            el = senarai.find_element(
                (AppiumBy.ACCESSIBILITY_ID, "KEMASKINI"), timeout=10)
            senarai.tap_element(el)
            time.sleep(2)
            popup_field = (AppiumBy.ANDROID_UIAUTOMATOR,
                           'new UiSelector().textContains("ISI KEMASKINI")')
            el = senarai.find_element(popup_field, timeout=10)
            el.click()
            el.clear()
            driver.execute_script('mobile: type', {'text': 'RECON'})
            try:
                driver.hide_keyboard()
            except Exception:
                pass
            el = senarai.find_element(
                (AppiumBy.ACCESSIBILITY_ID, "SETERUSNYA"), timeout=5)
            senarai.tap_element(el)
            time.sleep(3)
            assert senarai.is_element_present(form_title, timeout=10), \
                "KEMASKINI NOTIS AMARAN form did not open"

        seen = set()
        size = driver.get_window_size()
        w, h = size["width"], size["height"]
        for i in range(10):
            src = driver.page_source
            import re as _re
            new = []
            for m in _re.finditer(r'(?:text|content-desc)="([^"]+)"', src):
                v = m.group(1)
                if v not in seen:
                    seen.add(v)
                    new.append(v)
            if new:
                print(f"[RECON4] swipe {i}: new nodes: "
                      + " | ".join(repr(x[:40]) for x in new), flush=True)
            with open(os.path.join(OUT, f"recon_kform_swipe{i}.xml"),
                      "w", encoding="utf-8") as f:
                f.write(src)
            if "OPEN CAMERA" in src or "GAMBAR" in src:
                print("[RECON4] camera area reached", flush=True)
            driver.swipe(w // 2, int(h * 0.85), w // 2, int(h * 0.25), 800)
            time.sleep(1)

        print("[RECON4] done (leaving form without submitting)", flush=True)
        for _ in range(3):
            driver.back()
            time.sleep(1)
    finally:
        driver.quit()


if __name__ == "__main__":
    main()

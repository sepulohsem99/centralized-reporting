# MBIP v3 — Suite Automation IES (KOMPAUN e-PBT)

Baca fail ini dahulu. Ia mengandungi keputusan seni bina dan penemuan
yang diperoleh dengan susah payah melalui berpuluh run pada peranti
sebenar. Melanggarnya akan memecahkan perkara yang sudah berfungsi.

---

## Apa ini

Suite Appium + pytest yang menguji aplikasi Android MBIP/IES — sistem
kompaun untuk pihak berkuasa tempatan Malaysia. 48 test case, dijalankan
terhadap telefon fizikal yang bersambung melalui USB.

Sumber kebenaran ialah skrip ujian Excel setiap PBT
(`docs/IES-MBIP Testing Script V2.1.14_PRODUCTION.xlsx`). Excel yang
menentukan APA yang diuji; kod menentukan BAGAIMANA.

---

## Peraturan keras

1. **Jangan sesekali ubah `../current/` atau `../v2/`.** Itu suite lama
   yang masih berfungsi. Semua kerja berlaku dalam `v3/`.
2. **Jangan ubah logic pass/fail untuk memaksa test lulus.** Kalau test
   gagal, itu penemuan — laporkan, jangan tutup.
3. **Jangan hardcode nilai khusus mesin.** Serial peranti dikesan
   automatik; tetapan PBT datang dari `profiles/`.
4. **Status Excel (Pass/Fail) bukan oracle.** Ia rekod run manual
   tester yang lepas. Automation mesti cuba semua TC secara neutral dan
   biar keputusan sebenar yang menentukan.
5. **Jangan tampal medan yang Excel biarkan kosong dengan nilai
   rekaan.** Kalau sel C9 tidak menyebut sesuatu medan, daftarkan medan
   itu dalam `excel_data.BLANK_BY_DESIGN`; ia akan diisi dengan teks
   `blank dari test script` (`excel_data.BLANK_MARKER`).

   Medan itu DIISI, bukan dibiarkan kosong — penanda tersebut keluar
   pada kertas cetak, jadi sesiapa yang memegang cetakan nampak terus
   nilainya tiada asas dalam Excel. Medan yang benar-benar kosong tidak
   dapat dibezakan daripada medan yang gagal diisi.

   Mereka-reka nilai "yang munasabah" menghasilkan data yang kelihatan
   sah, tercetak pada kertas sebenar, dan disangka datang dari Excel
   oleh sesiapa yang membacanya kemudian.

   Berlaku sekali: `nama_penerima` K-001 mengandungi `"Buruh En Saiful"`
   yang diwarisi dari suite v2. Ia bertahan berbulan sehingga pemilik
   membaca kertas cetak sebenar pada 2026-07-29.

   Pengecualian yang dibenarkan hanya tiga, dan semuanya bertanda komen
   dalam `excel_data.py`: lesen/login terikat peranti, plat `JYX6605`,
   dan nilai yang Excel letak dalam Test Steps dan bukan Test Data.

6. **Hanya `docs/IES-MBIP Testing Script V2.1.14_PRODUCTION.xlsx` yang
   sah.** Wujud sekurang-kurangnya DUA workbook berlainan dengan nama
   fail yang sama persis dan label versi yang sama (V2.1.14_PRODUCTION),
   tetapi kandungan berbeza pada 9 sel C9/C10 — termasuk nama pesalah
   K-001 (VIMALA DEVI vs SENG HIAP GLASS), jalan N-001, dan Tempoh
   Kompaun. Satu daripadanya juga mempunyai sheet TN-003 yang satu lagi
   tiada.

   Kod ini dibina daripada salinan `docs/`. Menyemak testdata terhadap
   salinan lain akan menghasilkan "pembetulan" yang sebenarnya
   merosakkan — ini sudah berlaku sekali pada 2026-07-29.

   Sahkan dengan `tools/check_vs_excel.py`, yang sentiasa membaca
   salinan `docs/`. Kalau versi baharu diterima daripada dev, GANTIKAN
   fail dalam `docs/` dan jalankan semula pemeriksa; jangan simpan dua
   salinan.

7. **Jalankan `python tools/check_vs_excel.py` selepas menyentuh
   testdata.** Ia membandingkan setiap medan dengan sel C9 yang mendakwa
   menjadi sumbernya, dan keluar dengan kod 1 bila ada percanggahan.
   Ia wujud kerana data ujian yang salah tetap menghasilkan run hijau —
   tiada ujian akan gagal, ia cuma menguji perkara yang salah.

---

## Cara jalankan

```
tests\check_env.bat          # preflight — node, python, adb, appium, device
tests\run_and_report.bat     # run penuh + jana dashboard (1.5-2.5 jam)
tests\serve.bat              # pratonton dashboard di localhost
tests\publish.bat            # push ke GitHub -> Cloudflare Pages
```

`run_and_report.bat` memanggil preflight dahulu dan akan membatalkan run
kalau ada yang tidak kena — ini sengaja, supaya tiada siapa membuang 2
jam untuk run yang memang akan gagal.

Ia juga akan bertanya profil PBT. Tiada pilihan default apabila lebih
daripada satu profil wujud: tersilap menguji production sedangkan
staging yang dimaksudkan boleh merosakkan data sebenar.

---

## Susun atur

```
config.py              tetapan; membaca profil aktif
profile.py             pemuat profil PBT (MBIP_PROFILE atau menu)
device_utils.py        auto-detect serial peranti; python device_utils.py --check
profiles/*.json        satu fail per PBT x environment
pages/                 Page Object Model, satu fail per skrin
tests/                 48 fail test, dinamakan ikut ID TC Excel
testdata/excel_data.py data MBIP dibina tangan — TERBUKTI, jangan ganti
testdata/pbt/*.py      data PBT lain, dijana oleh tools/gen_testdata.py
testdata/overrides.py  medan yang Excel tidak boleh bekalkan
reports/generate_report.py  membina dashboard HTML
tools/extract_pipeline.py   baca folder shared -> reports/pipeline.json
tools/gen_testdata.py       jana data ujian per-PBT dari Excel
```

---

## Penemuan tentang aplikasi ini

Perkara berikut ditemui melalui kegagalan berulang pada peranti sebenar.
Ia bukan teori.

**Aplikasi React Native — `el.click()` senyap tidak berkesan.**
Pressable tersuai dalam app ini mengabaikan ACTION_CLICK aksesibiliti.
Guna `tap_element()` (tap koordinat mentah). Ini punca kegagalan paling
kerap dan paling mengelirukan, kerana tap "berjaya" tetapi tiada apa
berlaku.

**Medan bernombor/bertopeng memerlukan `mobile: type`.**
`send_keys()` melontar `InvalidElementStateException` pada medan IP,
lesen, dan sebagainya.

**Alert asli tiba secara tidak segerak dan beratur.**
Keputusan sync muncul lambat — kadang semasa skrin lain sudah dibuka —
dan butang Back TIDAK menutupnya. Panggil `dismiss_native_alerts()`
sebelum sebarang interaksi baharu.

**Tap boleh gagal didaftarkan secara senyap.**
Setiap tap kritikal (buka menu, pilih dropdown, Simpan, sahkan kamera)
mesti disahkan dengan elemen yang hanya muncul selepas tap berjaya, dan
dicuba semula kalau tidak.

**`hide_keyboard()` bertindak seperti tekan Back.**
Ia menutup modal RN. Elakkan pada skrin yang ada popup.

**Sesetengah borang tidak boleh di-skrol.**
Guna `reveal_below_fold()` (traversal fokus TAB/DPAD) untuk mencapai
medan di bawah paparan.

**Label medan tidak konsisten hurufnya antara skrin.**
Guna locator `textMatches("(?i)^...$")`.

**Kamera menjatuhkan tap selama ~2-3 saat selepas setiap tangkapan.**
Beri jeda. Sesetengah varian kamera tutup sendiri tanpa tick-confirm.

**`no_reset=True`** — keadaan app kekal antara run. Medan mengekalkan
nilai yang disimpan, placeholder hilang selepas simpan pertama. Ada
fallback berperingkat untuk ini.

---

## Printer — aplikasi boleh sambung semula sendiri

Ditemui 2026-07-29 oleh pemilik. Sebelum ini kami menganggap printer yang
tidur bermakna terpaksa menunggu operator; sebenarnya aplikasi ada aliran
sambung semula sendiri, dan automation boleh menjalankannya.

**Auto-off ditetapkan kepada 90 minit** (2026-07-29, melalui tetapan
printer Bixolon). Sebelum ini 10 minit, yang bermakna printer pasti tidur
di tengah run. Sekarang 90 minit melebihi tempoh run penuh (60-90 minit),
jadi printer sepatutnya kekal hidup sepanjang run.

Kalau printer diganti atau tetapan direset, nilai ini kembali ke 10 minit
dan masalah lama akan muncul semula — periksa di sini dahulu.

Satu-satunya kerja manusia: **tekan butang kuasa pada printer.**

Selebihnya boleh diautomasikan:

1. Pergi ke skrin utama (lima menu: Notis Amaran, Daftar Kompaun, Notis
   Kompaun, Senarai, Hantar).
2. Di bahagian atas ada ikon printer.
   **Merah = belum bersambung. Hijau = bersambung.**
3. Ketuk ikon itu -> popup senarai peranti Bluetooth.
4. Pilih entri yang bermula dengan **`SPP`** — itu awalan model printer.
   Nama penuh dari skrin sebenar: **`SPP-R410_110095`**
   (MAC 74:F0:7D:A9:88:75). Hanya **`SPP`** yang statik; setiap ahli team
   ada printer sendiri dengan nombor berbeza, jadi JANGAN hardcode ID
   penuh.

   > Awalan ini pernah disalah catat sebagai `SPR`. Ia **`SPP`** —
   > disahkan dari skrin Printer List, 2026-07-29. Locator yang mencari
   > `SPR` tidak akan padan dengan apa-apa.
5. Tekan **Connect**.
6. Popup kata laluan muncul -> masukkan **`0000`** -> OK.
7. Ikon bertukar hijau.

Implikasi: sebelum setiap TC Cetak, semak warna ikon dan sambung semula
kalau merah. Menunggu operator hanya perlu apabila printer benar-benar
mati (butang belum ditekan).

## Isyarat hasil cetak (disahkan secara fizikal)

    alert "COMMAND_NOT_SEND"       -> TIDAK tercetak
    tiada alert + popup tutup      -> tercetak
                                      (kertas disahkan keluar 2026-07-28)

## Halangan yang diketahui (isu aplikasi, bukan automation)

Jangan buang masa "membaiki" perkara ini dalam kod ujian:

- **Form Kemaskini** — bahagian bawah tidak render langsung. Menyekat
  kesemua TC `-004`. Tester manual juga melaporkannya.
- **UI simpan Bookmark** — tiada dalam build ini. Menyekat semua `-005`.
- **Kadar Denda pada borang Sitaan** — tidak boleh dicapai. Menyekat
  S-001, dan berturutan S-003/S-004.
- **Server menolak hantar-semula** untuk jenis P/K/L (N dan S diterima).

### Kebergantungan luar — bukan bug app, bukan bug automation

Dua TC bergantung pada API pihak ketiga. Bila API itu bermasalah, TC
gagal walaupun kod betul sepenuhnya. Kelaskan sebagai **kategori D
(luaran)**, jangan cuba "baiki" dalam kod ujian, dan jangan kira sebagai
regresi.

- **K-001 — MySIKAP** (carian plat kenderaan). Gejala:
  `MySIKAP lookup never populated NAMA PESALAH for plate JYX6605`.
  Disahkan oleh pemilik pada 2026-07-29 bahawa MySIKAP memang ada isu
  API luaran hari itu.
- **S-001 — API luaran** (dilaporkan pemilik 2026-07-28).

Sebelum melaporkan mana-mana daripada dua ini sebagai kegagalan baharu,
TANYA pemilik sama ada API berkenaan sedang bermasalah. Kegagalan yang
kelihatan sama boleh datang dari dua punca yang berlainan sepenuhnya.

---

## Dashboard

`reports/generate_report.py` membina semula
`reports/mbip_v3_report.html` dan `public/index.html` daripada
`reports/results.json` selepas setiap run. Ia idempoten.

Empat tab: Pipeline (semua PBT x env), Laporan (48 TC, penapis PBT dan
versi), Sejarah Run, Panduan.

`public/` ialah satu-satunya folder yang dihidangkan secara awam
(Cloudflare Pages + Access). Zip yang boleh dimuat turun mengandungi
kredential PBT — ia dilindungi Access, tetapi ingat ia wujud.

Kalau menambah nota TC yang menyebut versi build, gunakan token `{ver}`
— ia digantikan dengan versi APK sebenar yang dikesan pada peranti.
Nota yang menulis nombor versi secara terus akan menjadi usang tanpa
disedari.

---

## Gaya komunikasi pemilik

- Ringkas dan terus. Tiada penerangan berjela.
- Apa-apa yang perlu disalin (arahan, prompt) mesti dalam blok kod.
- Bila ada keputusan untuk dibuat, tawarkan pilihan berbilang, bukan
  soalan terbuka.
- Bahasa Melayu bercampur istilah teknikal Inggeris.

## Menulis prompt untuk sesi terminal

- Mulakan setiap prompt dengan **ultrathink**. Pemilik mahu sesi
  terminal berfikir sedalam mungkin untuk kerja ini.
- **Jangan sebut kos token atau beri amaran tentangnya.** Pemilik sudah
  tahu dan sudah membuat keputusan itu.
- Sesi terminal tiada memori antara sesi — setiap prompt mesti lengkap
  dengan sendirinya.

"""
Appium configuration for KOMPAUN e-PBT (IES App) tests.
Update these variables when a new APK build is provided.

PORTABILITY NOTE
----------------
This suite is distributed as a zip to a team where each member runs it on
their own Android device, and nobody edits any .py file. So nothing here
may be tied to one particular machine:

  - The device serial is NOT hardcoded. It is resolved at runtime by
    device_utils.resolve_udid() -- see that module for the rules. Override
    with the MBIP_UDID environment variable if auto-detect can't decide.
  - The tester's identity comes from the Windows username (override with
    MBIP_TESTER), so run history can attribute each run without setup.

MULTI-PBT
---------
APK ini dibina untuk banyak PBT, setiap satu dengan staging + production
sendiri. Mengikut pengesahan: langkah ujian SAMA untuk semua PBT — yang
berbeza hanya tetapan (Tetapan Alamat IP + Lesen Aplikasi) dan akaun.

Jadi nilai-nilai tersebut TIDAK lagi hardcoded di sini. Ia datang dari
profil aktif dalam profiles/ (lihat profile.py). Menambah PBT baharu =
menambah satu fail JSON, bukan mengedit kod.

Lesen Aplikasi disahkan divalidasi terhadap pangkalan data server, bukan
terhadap IMEI peranti — jadi satu nilai lesen sah untuk semua peranti
ahli team dalam PBT yang sama.
"""

import getpass
import os

import profile as _profile

# Profil aktif — pilih dengan MBIP_PROFILE, atau melalui menu dalam
# tests\run_and_report.bat. Gagal serta-merta (dengan mesej jelas) kalau
# taksa atau belum lengkap.
PROFILE = _profile.load()
PROFILE_NAME = PROFILE["_name"]
PROFILE_LABEL = _profile.label(PROFILE)
PBT = PROFILE["pbt"]
ENV = PROFILE["env"]

# APK settings — datang dari profil
APK_PATH = r"C:\path\to\ies_app.apk"  # Update with actual APK path
APP_PACKAGE = PROFILE["app_package"]
APP_ACTIVITY = PROFILE.get("app_activity", ".MainActivity")

# Tetapan yang diuji oleh T-001 (Alamat IP) dan T-002 (Lesen Aplikasi).
# Ini SATU-SATUNYA data ujian yang berbeza antara PBT — selebihnya dalam
# testdata/excel_data.py dikongsi oleh semua.
LICENSE_SETTINGS = {
    "internal_ip": PROFILE["internal_ip"],
    "external_ip": PROFILE["external_ip"],
    "lesen_aplikasi": PROFILE["lesen_aplikasi"],
    # Senarai gantian (CEO 2026-08-21) — dicuba automatik oleh
    # set_tetapan_pelbagai_dengan_alternatif bila lesen utama ditolak.
    "lesen_alternatif": PROFILE.get("lesen_alternatif", []),
}

TEST_CREDENTIALS = {
    "username": PROFILE["username"],
    "password": PROFILE["password"],
}

# Appium server
APPIUM_URL = "http://127.0.0.1:4723"

# Device settings
DEVICE_NAME = "Android"
PLATFORM_NAME = "Android"
AUTOMATION_NAME = "UiAutomator2"
NO_RESET = True  # Set False to reinstall app each run
FULL_RESET = False

# Who is running this suite — attributed in the dashboard's run history.
# Auto-detected; set MBIP_TESTER to override.
TESTER_NAME = (os.environ.get("MBIP_TESTER", "").strip()
               or getpass.getuser())

# Login credentials
USERNAME = "msc"
PASSWORD = "Pass1"

# Test data for forms
# TEST_DATA DIBUANG (2026-07-29).
#
# Dict ini warisan dari suite v1. Ia mengandungi nilai yang direka
# sendiri — nama orang, alamat, plat — yang TIDAK datang dari skrip ujian
# Excel. Contohnya `arahan_tindakan` berisi nama pemilik projek.
#
# Semakan `grep -rn TEST_DATA` menunjukkan TIADA test, page, tool atau
# recon yang membacanya: ia sudah mati sepenuhnya sejak data ujian
# berpindah ke testdata/excel_data.py.
#
# Ia dibuang dan bukan sekadar dikemas kini, sebab kod mati yang
# kelihatan seperti data ujian sah adalah perangkap — ia akan disalin ke
# setiap PBT baharu dan suatu hari seseorang akan mengimportnya semula
# tanpa sedar nilainya tiada asas dalam Excel.
#
# Satu-satunya sumber data ujian ialah:
#   testdata/excel_data.py   (MBIP, dibina tangan, terbukti)
#   testdata/pbt/<pbt>.py    (PBT lain, dijana dari Excel)
#   testdata/overrides.py    (medan yang Excel tidak bekalkan)

# Timeouts (seconds)
# IMPLICIT_WAIT lowered 10 -> 2 (perf): is_element_present() layers a
# WebDriverWait on top of the implicit wait, so with implicit=10 every
# absent-element probe blocked the FULL 10s before reporting not-found --
# an is_element_present(timeout=1) actually cost ~10s, and reveal_below_fold's
# many such probes turned one blocked TC into minutes of dead time. Not 0:
# ~25 bare driver.find_element/find_elements calls in the pages rely on the
# implicit wait (most are preceded by an is_element_present guard so they're
# safe, but find_elements would return an empty list INSTANTLY at 0, breaking
# count-based checks); 2s keeps those correct while cutting the dead time ~5x.
IMPLICIT_WAIT = 2
EXPLICIT_WAIT_SHORT = 5
EXPLICIT_WAIT_LONG = 20
EXPLICIT_WAIT_UPLOAD = 60
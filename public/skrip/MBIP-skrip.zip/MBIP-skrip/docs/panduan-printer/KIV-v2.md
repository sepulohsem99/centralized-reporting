# KIV — MBIP-Reporting (dashboard v2)

Diparkir 2026-07-29 atas permintaan pemilik. Semua bahan sudah dikumpul
di sini supaya kerja boleh disambung tanpa upload semula.

## Keputusan yang sudah dibuat

- **Struktur**: repo sama, folder `public-v2/`. `generate_report.py`
  tulis dua output; cipta projek Cloudflare Pages kedua yang menunjuk ke
  `public-v2`. Satu kod, satu push, dua laman.
- **Nama**: `MBIP-Reporting.pages.dev`
- **Skop v2**: MBIP sahaja.
- **v1 kekal** sebagai pandangan semua PBT (bukan dibekukan, bukan
  dipadam). Tetapan lain diwarisi tanpa perubahan.

## Yang perlu ditambah dalam tab Panduan v2

Satu bahagian baharu: **sediakan printer sebelum run**.

1. Pasang aplikasi **BIXOLON Utility** dari Play Store pada peranti
   masing-masing. (Ikon di skrin utama: `BIXOLON Utility` dan
   `Network Utility` — lihat `01.png`.)
2. Tukar **Auto Power Off Time (Not Connected)** kepada tempoh panjang.

Aliran skrin, mengikut susunan gambar:

| Fail | Skrin | Nota |
|------|-------|------|
| `01.png` | Skrin utama peranti | tunjuk ikon BIXOLON Utility |
| `02.png` | Printer Settings | pilih VMSM (dan Bluetooth Settings) |
| `03.png` | Select Interface | pilih Bluetooth |
| `04.png` | Arahan pasangan Bluetooth | PIN default **0000** |
| `05.png` | Printer List | **SPP-R410_110095** — awalan `SPP` |
| `06.png` | VMSM | senarai tetapan + butang SAVE |

(Gambar dialog input Auto Power Off — julat `(ex. 1 ~ 90)` — belum
disalin ke sini; ambil semula bila menyambung kerja.)

## Dua perkara yang perlu disemak sebelum tulis panduan

1. **180 minit mungkin ditolak.** Dialog aplikasi tulis julat
   `(ex. 1 ~ 90)` dan nilai semasa sudah 90min — iaitu maksimum.
   Sahkan pada peranti dahulu sebelum panduan mengarahkan orang menaip
   180; kalau ditolak, tulis 90 sebagai had sebenar perkakasan.
   Run 2026-07-29 berjaya sepenuhnya pada 90min, jadi 90 sudah memadai.
2. **Auto Power Saving Time (Connected) = 10sec** — tetapan berasingan
   daripada auto-off. Belum disiasat sama ada ia menyumbang kepada
   printer "hilang" di tengah run. Run terakhir tiada masalah, jadi
   kemungkinan besar tidak — tetapi jangan tulis dalam panduan sebagai
   fakta tanpa semakan.

## Awalan printer

`SPP`, bukan `SPR`. Disahkan dua kali: dari skrin Printer List
(`05.png`) dan secara bebas oleh sesi terminal semasa membina
`pages/printer_connect_page.py`. Sudah dibetulkan dalam `CLAUDE.md`.

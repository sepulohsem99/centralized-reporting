"""
MBIP-TC-T-001 — Tetapan Alamat IP.

Sheet MBIP-TC-T-001: "Verify if can configure and save IP Address" (Test Data C9: 58.27.54.105).
Expected result (C11): The IP Address should be applied and visible in the settings.

The actual work happens ONCE in the session-scoped pelarasan_results
fixture (a single pass through the Menu Selaras popup, before login);
this test asserts its own item's recorded verdict so each of the nine
T-00x cases reports individually.
"""


def test_mbip_tc_t_001_tetapan_alamat_ip(pelarasan_results):
    ok, msg = pelarasan_results["MBIP-TC-T-001"]
    assert ok, "MBIP-TC-T-001 Tetapan Alamat IP failed: " + msg

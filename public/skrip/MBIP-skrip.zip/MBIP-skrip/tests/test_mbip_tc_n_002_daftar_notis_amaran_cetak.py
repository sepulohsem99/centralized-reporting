"""
MBIP-TC-N-002 — Daftar Notis Amaran > Cetak.

Sheet MBIP-TC-N-002: "Verify that 'Cetak' button can generate and print out"
— sync the information, tap 'Cetak'; expected: the record prints to a
connected printer.

Flow (see pages/cetak_page.py): Senarai -> open THIS RUN's N record BY NUMBER
(created_records["N"], set by N-001) -> KEMASKINI DATA popup -> confirm the
popup shows that number -> tap the pinned CETAK button -> classify the print
result. Because CETAK closes the popup and returns to Home (confirmed live),
cetak_page RE-navigates to the record (again by number) on every printer-wait
retry.

Selection is BY NUMBER, not positional. The old which='last' pick printed
whatever stale record sat last in staging, so this TC passed even when the
create failed -- proving only that the printer works, never that this run's
record printed. Now: no number => honest skip (show stopper from N-001);
number not found / wrong record on screen => FAIL. The Bluetooth printer
auto-sleeps; if asleep, cetak_page beeps + banners the operator and retries
before skipping.
"""

import pytest


def test_mbip_tc_n_002_daftar_notis_amaran_cetak(home_reset, pages,
                                                 created_records, artifacts):
    no = created_records.get("N")
    if not no:
        pytest.skip("show stopper from MBIP-TC-N-001 "
                    "(rekod N tidak dicipta / nombor tak terbaca)")

    result = pages.cetak.print_record("N", tc_label="N-002", pages=pages,
                                      no_rekod=no)

    # Record not found / wrong record on screen -> hard FAIL, never a stale
    # print and never a printer skip.
    if result.get("record_error"):
        pytest.fail(f"FAIL: {result['record_error']}")
    if not result["printed"]:
        pytest.skip(result.get("skip_reason", "printer tidak dihidupkan"))

    artifacts("MBIP-TC-N-002", no_dicetak=no)
    if result.get("unconfirmed"):
        print("  [N-002] Printed — WARNING: success inferred (no explicit "
              "result alert); see ui_dumps/cetak_N_*.xml")
    print(f"  [N-002] Notis Amaran {no} printed successfully "
          f"(waited {result['waited_seconds']:.0f}s, "
          f"{result['poll_count']} attempt(s)) — PASS")

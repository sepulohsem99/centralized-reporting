"""
MBIP-TC-NK-002 — Notis ke Kompaun > Patuh.

Sheet MBIP-TC-NK-002 (its C3 cell mislabels itself NK-001): "Verify
that recipient is marked as Patuh" — select a notice, fill Ulasan, tap
Patuh; expected: Patuh issued successfully. C9 cites the tester's
notice (IPA01N260619005, environment-specific); v3 uses a notice pulled
by ID msc at runtime.

Live recon fact: the ulasan field lives ON the notice popup and is
mandatory — tapping PATUH with it empty alerts "ULASAN WAJIB DIISI.".
"""

from testdata.excel_data import TC_DATA


def test_mbip_tc_nk_002_notis_ke_kompaun_patuh(home_reset, pages):
    data = TC_DATA["MBIP-TC-NK-002"]

    pages.home.open_notis_kompaun()
    assert pages.notis_kompaun.is_notis_kompaun_screen_displayed(), \
        "FAIL: Notis Kompaun screen not displayed"
    pages.notis_kompaun.tarik_notis(
        id_penguatkuasa=data["id_penguatkuasa"])

    no_notis = pages.notis_kompaun.open_notice_popup(index=0)
    print(f"  [NK-002] Issuing Patuh for notice: {no_notis}")

    messages = pages.notis_kompaun.patuh(data["ulasan"])
    bad = [m for m in messages
           if "RALAT" in m.upper() or "WAJIB" in m.upper()
           or "TIDAK" in m.upper()]
    assert not bad, f"FAIL: Patuh rejected: {bad}"
    assert not pages.notis_kompaun.is_element_present(
        pages.notis_kompaun.NOTICE_POPUP, timeout=3), \
        ("FAIL: notice popup still open after PATUH (see "
         "ui_dumps/nk_patuh_popup_stuck.xml)")
    print("  [NK-002] Notis ke Kompaun (Patuh) completed — PASS")

"""
MBIP-TC-K-001 — Daftar Kompaun Letak Kereta.

Sheet MBIP-TC-K-001: "Verify that a 'Daftar Kompaun Letak Kereta' can be
created and saved sucessfully with all required information". On-screen
the jenis option is literally "KOMPAUN TRAFIK" (confirmed live in v2).

Test Data (C9): MySIKAP lookup populates the pesalah block; JALAN JAYA 1 /
TAMAN JAYA 1 (kesalahan); PERINTAH 39 pre-selected tier; kadar RM30;
pembantu penguatkuasa 2 -- see testdata/excel_data.py, incl. the JYX6605
plate ENVIRONMENT OVERRIDE (the sheet only lists the populate RESULT).

Expected (C11): mandatory fields accept valid information, dropdowns
selectable; after submit, Jenis/Warna Kereta cleared automatically.
"""

from testdata.excel_data import TC_DATA
from testdata.trafik_v2 import TRAFIK_V2


def test_mbip_tc_k_001_daftar_kompaun_letak_kereta(home_reset, pages,
                                                   created_records, artifacts):
    data = dict(TC_DATA["MBIP-TC-K-001"])
    # >>> BUILD HOTFIX 2026-08-20 — data CEO menimpa nilai lama. <<<
    # (tier-1 tidak lagi terkunci PERINTAH 39; field baru kadar denda/
    # cukai jalan/petak/kupon; lihat testdata/trafik_v2.py)
    data.update(TRAFIK_V2)

    pages.home.open_daftar_kompaun()
    pages.daftar_kompaun.select_jenis_kompaun_trafik()
    assert pages.daftar_kompaun.is_daftar_kompaun_trafik_screen_displayed(), \
        "FAIL: Daftar Kompaun Trafik screen not displayed"
    print("  [K-001] Daftar Kompaun Trafik screen displayed")

    # Laluan v2 (build hotfix) dengan fallback build lama di dalamnya.
    try:
        pages.daftar_kompaun.fill_pesalah_tab_trafik_v2(data)
    except Exception as e:
        print(f"  [K-001] pesalah v2 gagal ({type(e).__name__}) -- "
              f"cuba laluan build lama")
        pages.daftar_kompaun.fill_pesalah_tab_trafik(data)
    pages.daftar_kompaun.click_seterusnya_from_pesalah()

    # >>> 2026-08-27 (rerun #3 + dump trafik_tab2_rehat): blok alamat
    # WUJUD di atas tab-2 tetapi build hotfix membuang label TextView —
    # medan dikenal ikut @hint sahaja, jadi fill_kompaun_tab_direct
    # (label-based) sentiasa AssertionError. Jalan juga WAJIB dipilih
    # dari senarai ('SILA PILIH BANDAR DARIPADA SENARAI.' pada
    # Seterusnya — pilihan baris men-set kod bandar, JOIN DB dalam
    # bundle Hermes). Guna laluan hint-based baharu. <<<
    pages.daftar_kompaun.isi_alamat_trafik_v2(data)
    pages.daftar_kompaun.fill_kompaun_code_fields_trafik_v2(data)

    print("\n  [K-001] Attempting to take photos...")
    try:
        pages.daftar_kompaun.take_photos(count=3)
    except Exception as e:
        print(f"  [K-001] WARNING: camera handling failed ({e}) -- "
              f"continuing without photos")

    pages.daftar_kompaun.click_seterusnya_from_kompaun()

    pages.daftar_kompaun.fill_penerima_tab(data)
    pages.daftar_kompaun.click_menyerahkan()
    pages.daftar_kompaun.confirm_and_submit()

    assert pages.daftar_kompaun.is_submission_successful_trafik(), \
        "FAIL: Daftar Kompaun Trafik submission was not successful"
    # Store the NUMBER, not a flag (see N-001). ABSENT=create failed,
    # ""=create ok but number unread (own bug), number=good.
    _no = pages.daftar_kompaun.last_record_number
    if _no:
        created_records["K"] = _no
    else:
        created_records["K"] = ""
        print("  [K-001] WARNING: create berjaya tetapi nombor rekod TIDAK "
              "terbaca -- kunci = '' (bug tersendiri, bukan kegagalan create)")
    artifacts("MBIP-TC-K-001", no_kompaun=_no)
    print("  [K-001] Daftar Kompaun Letak Kereta submitted successfully")

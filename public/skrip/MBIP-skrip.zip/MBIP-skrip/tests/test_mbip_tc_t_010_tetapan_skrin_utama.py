"""
MBIP-TC-T-010 — Tetapan Skrin Utama.

Sheet MBIP-TC-T-010 (its C3 cell mislabels itself T-009): "Verify if
Tetapan Skrin Utama can be selected". Runs pre-login from the Menu
Selaras popup (menu item confirmed via live recon). If the sub-screen
has a Simpan, settings are saved UNCHANGED — the sheet only requires the
item to be selectable. Recon-first: page source dumped every run.
"""


def test_mbip_tc_t_010_tetapan_skrin_utama(pelarasan_results, pages):
    p = pages.pelarasan
    p.ensure_on_login_screen()
    p.open_menu_selaras()
    try:
        ok = p.tetapan_skrin_utama()
    finally:
        try:
            p.close_menu_selaras()
        except Exception as e:
            print(f"  [T-010] WARNING: menu close hiccup ({e})")
    assert ok, ("MBIP-TC-T-010 Tetapan Skrin Utama screen did not open "
                "(see ui_dumps/t010_*.xml)")

"""
MBIP-TC-L-002 — Daftar Kompaun Lesen > Cetak.

Sheet MBIP-TC-L-002: "Verify that 'Cetak' button can generate and print out"
— sync the information, tap 'Cetak'; expected: the record prints to a
connected printer.

Flow (see pages/cetak_page.py): Senarai -> open the newest L-jenis record ->
KEMASKINI DATA popup -> tap the pinned CETAK button -> classify the print
result. cetak_page re-navigates to the record on every printer-wait retry
(CETAK closes the popup). Prints the record L-001 created this session.
The Bluetooth printer auto-sleeps after ~10 min; cetak_page beeps + banners
the operator and re-tries for up to 5 min before skipping.
"""

import pytest


def test_mbip_tc_l_002_daftar_kompaun_lesen_cetak(home_reset, pages,
                                                  created_records, artifacts):
    # Print THIS RUN's L record by NUMBER (see N-002). No number => honest
    # skip; wrong record => FAIL.
    no = created_records.get("L")
    if not no:
        pytest.skip("show stopper from MBIP-TC-L-001 "
                    "(rekod L tidak dicipta / nombor tak terbaca)")

    result = pages.cetak.print_record("L", tc_label="L-002", pages=pages,
                                      no_rekod=no)

    if result.get("record_error"):
        pytest.fail(f"FAIL: {result['record_error']}")
    if not result["printed"]:
        pytest.skip(result.get("skip_reason", "printer tidak dihidupkan"))

    artifacts("MBIP-TC-L-002", no_dicetak=no)
    if result.get("unconfirmed"):
        print("  [L-002] Printed — WARNING: success inferred (no explicit "
              "result alert); see ui_dumps/cetak_L_*.xml")
    print(f"  [L-002] Kompaun Lesen {no} printed successfully "
          f"(waited {result['waited_seconds']:.0f}s, "
          f"{result['poll_count']} attempt(s)) — PASS")

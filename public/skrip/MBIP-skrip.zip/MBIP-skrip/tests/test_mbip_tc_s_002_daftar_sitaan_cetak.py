"""
MBIP-TC-S-002 — Daftar Sitaan > Cetak.

Sheet MBIP-TC-S-002: "Verify that 'Cetak' button can generate and print out"
— sync the information, tap 'Cetak'; expected: the record prints to a
connected printer.

Flow (see pages/cetak_page.py): Senarai -> open the newest S-jenis record ->
KEMASKINI DATA popup -> tap the pinned CETAK button -> classify the print
result. cetak_page re-navigates to the record on every printer-wait retry
(CETAK closes the popup).

NOTE: S-001 itself is blocked by a known app issue (Kadar Denda unreachable
on the Sitaan form — see CLAUDE.md), so an S record may not exist. If none
is listed, this skips distinctly ("tiada rekod Sitaan") rather than waiting
on the printer.
"""

import pytest


def test_mbip_tc_s_002_daftar_sitaan_cetak(home_reset, pages,
                                           created_records, artifacts):
    # Print THIS RUN's S record by NUMBER (see N-002). No number => honest
    # skip (S-001 is itself blocked by the Sitaan Kadar Denda issue); wrong
    # record => FAIL.
    no = created_records.get("S")
    if not no:
        pytest.skip("show stopper from MBIP-TC-S-001 "
                    "(rekod S tidak dicipta / nombor tak terbaca)")

    result = pages.cetak.print_record("S", tc_label="S-002", pages=pages,
                                      no_rekod=no)

    if result.get("record_error"):
        pytest.fail(f"FAIL: {result['record_error']}")
    if not result["printed"]:
        pytest.skip(result.get("skip_reason", "printer tidak dihidupkan"))

    artifacts("MBIP-TC-S-002", no_dicetak=no)
    if result.get("unconfirmed"):
        print("  [S-002] Printed — WARNING: success inferred (no explicit "
              "result alert); see ui_dumps/cetak_S_*.xml")
    print(f"  [S-002] Sitaan {no} printed successfully "
          f"(waited {result['waited_seconds']:.0f}s, "
          f"{result['poll_count']} attempt(s)) — PASS")

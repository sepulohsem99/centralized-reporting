"""
MBIP-TC-L-001 — Daftar Kompaun Lesen.

Sheet MBIP-TC-L-001: "Verify that a 'Daftar Kompaun Lesen' can be
created and saved sucessfully with all required information". Test Data
(C9): RAMLI / 010741852963 / lesen ABC123456 / JALAN JAYA 3 (pesalah),
JALAN KOSA 3 / TAMAN PERLING (kesalahan), tempoh 0, KOMPAUN MENCEGAH
KEKOTORAN combo, kadar RM500 — see testdata/excel_data.py.

The jenis option "KOMPAUN LESEN" is confirmed present in the jenis
popup (live recon); the Lesen Pesalah tab itself is recon-pending, so
pages/kompaun_lesen_page.py dumps its page source on entry and uses
label-candidate ladders.
"""

from testdata.excel_data import TC_DATA


def test_mbip_tc_l_001_daftar_kompaun_lesen(home_reset, pages,
                                            created_records, artifacts):
    data = TC_DATA["MBIP-TC-L-001"]

    pages.home.open_daftar_kompaun()
    pages.lesen.select_jenis_kompaun_lesen()

    pages.lesen.fill_pesalah_tab_lesen(data)
    pages.lesen.click_seterusnya_from_pesalah()

    pages.lesen.fill_kompaun_tab(data)
    pages.lesen.fill_kompaun_code_fields(data)

    print("\n  [L-001] Attempting to take photos...")
    try:
        pages.lesen.take_photos(count=3)
    except Exception as e:
        print(f"  [L-001] WARNING: camera handling failed ({e}) -- "
              f"continuing without photos")

    pages.lesen.click_seterusnya_from_kompaun()

    pages.lesen.fill_penerima_tab(data)
    pages.lesen.click_menyerahkan()
    pages.lesen.confirm_and_submit()

    # Same receipt-or-form-closed judgement as the Trafik flow (the
    # cetak/receipt lookup is environment-dependent).
    assert pages.lesen.is_submission_successful_trafik(), \
        "FAIL: Daftar Kompaun Lesen submission was not successful"
    # Store the NUMBER, not a flag (see N-001). ABSENT=create failed,
    # ""=create ok but number unread (own bug), number=good.
    _no = pages.lesen.last_record_number
    if _no:
        created_records["L"] = _no
    else:
        created_records["L"] = ""
        print("  [L-001] WARNING: create berjaya tetapi nombor rekod TIDAK "
              "terbaca -- kunci = '' (bug tersendiri, bukan kegagalan create)")
    artifacts("MBIP-TC-L-001", no_kompaun=_no)
    print("  [L-001] Daftar Kompaun Lesen submitted successfully")

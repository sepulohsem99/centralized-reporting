"""
MBIP-TC-K-003 -- Serah Kompaun Letak Kereta.

Attach a picture (lampiran) to THIS RUN's K record, selected BY NUMBER
(created_records["K"], set by K-001), never by list position. The old
which='last' pick attached to a stale staging record and passed even when
the create failed. No number now => honest skip (show stopper from K-001);
record not found / wrong record on screen => FAIL.

Flow (see pages/serah_page.py): Senarai -> open the record by number ->
confirm the popup shows that number -> scroll to the LAMPIRAN row -> tap the
paperclip -> in-app camera -> snap -> assert the row gained a thumbnail.
"""

import pytest


def test_mbip_tc_k_003_serah_kompaun_letak_kereta(home_reset, pages, created_records, artifacts):
    no = created_records.get("K")
    if not no:
        pytest.skip("show stopper from MBIP-TC-K-001 "
                    "(rekod K tidak dicipta / nombor tak terbaca)")

    pages.home.open_senarai()
    assert pages.senarai.is_senarai_screen_displayed(),         "FAIL: Senarai screen not displayed"
    assert pages.senarai.ensure_records_listed(),         "FAIL: no records listed in Senarai (nothing to attach to)"

    assert pages.senarai.open_record_by_number(no),         f"FAIL: rekod {no} tidak dijumpai dalam Senarai (create dakwa cipta {no})"
    assert pages.senarai.record_popup_shows_number(no),         f"FAIL: popup rekod tidak memaparkan {no} - rekod salah dibuka"

    pages.serah.attach_lampiran("K")
    artifacts("MBIP-TC-K-003", no_diserah=no)

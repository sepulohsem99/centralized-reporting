@echo off
REM ===================================================================
REM  MBIP v3 — one-command rerun + auto-dashboard.
REM
REM  1. Preflight check (check_env.bat) — batalkan awal kalau ada isu,
REM     supaya tiada sesiapa buang 1.5-2.5 jam untuk run yang memang
REM     akan gagal.
REM  2. Run penuh 48 TC.
REM  3. Regenerate dashboard HTML.
REM
REM  Selepas siap, refresh sahaja reports\mbip_v3_report.html.
REM
REM  Guna (dari mana-mana):  tests\run_and_report.bat
REM  Langkau preflight:      set MBIP_SKIP_PREFLIGHT=1
REM ===================================================================
setlocal enabledelayedexpansion
cd /d "%~dp0\.."

REM ===================================================================
REM  Pilih profil PBT / environment
REM
REM  Sengaja TIADA pilihan default bila lebih daripada satu profil ada:
REM  tersilap uji production sedangkan staging yang dimaksudkan boleh
REM  merosakkan data sebenar, jadi pilihan mesti dibuat secara sedar.
REM ===================================================================
if not "%MBIP_PROFILE%"=="" (
  echo [run_and_report] Profil dari MBIP_PROFILE: %MBIP_PROFILE%
  goto :ada_profil
)

set COUNT=0
echo.
echo ================================================================
echo   PILIH PBT / ENVIRONMENT
echo ================================================================
for /f "tokens=1,2 delims=|" %%a in ('python profile.py --list 2^>nul') do (
  set /a COUNT+=1
  set "PROF!COUNT!=%%a"
  echo   !COUNT!. %%b
)
echo.

if !COUNT!==0 (
  echo [GAGAL] Tiada profil dalam profiles\.
  echo         Setiap PBT x environment perlukan satu fail JSON di situ.
  endlocal
  exit /b 1
)

if !COUNT!==1 (
  set "MBIP_PROFILE=!PROF1!"
  echo   Hanya satu profil ada — guna !PROF1!
  goto :ada_profil
)

set /p PILIH=  Masukkan nombor pilihan:
if "!PILIH!"=="" (
  echo [GAGAL] Tiada pilihan dibuat — dibatalkan.
  endlocal
  exit /b 1
)
if not defined PROF!PILIH! (
  echo [GAGAL] Pilihan '!PILIH!' tidak sah.
  endlocal
  exit /b 1
)
for %%i in (!PILIH!) do set "MBIP_PROFILE=!PROF%%i!"
echo   Dipilih: !MBIP_PROFILE!

:ada_profil
echo.

if "%MBIP_SKIP_PREFLIGHT%"=="1" (
  echo [run_and_report] MBIP_SKIP_PREFLIGHT=1 — preflight dilangkau.
) else (
  call "%~dp0check_env.bat"
  if errorlevel 1 (
    echo [run_and_report] DIBATALKAN — preflight check gagal.
    echo [run_and_report] Betulkan isu di atas, kemudian cuba semula.
    endlocal
    exit /b 1
  )
)

echo [run_and_report] Running full v3 suite...
python -m pytest tests -v > reports\last_run.txt 2>&1
set PYTEST_RC=%ERRORLEVEL%

echo [run_and_report] Regenerating dashboard...
python reports\generate_report.py

REM Publish ke GitHub/Vercel hanya bila diminta secara jelas.
REM Default OFF: push automatik akan gagal (dan mengelirukan) pada mesin
REM yang belum di-setup git, dan tiada siapa patut terkejut kod mereka
REM tiba-tiba ditolak ke remote.
REM   Hidupkan kekal:  setx MBIP_AUTOPUBLISH 1
if "%MBIP_AUTOPUBLISH%"=="1" (
  echo [run_and_report] MBIP_AUTOPUBLISH=1 — publish ke GitHub/Cloudflare...
  call "%~dp0publish.bat"
)

echo [run_and_report] Done. pytest exit=%PYTEST_RC%
echo [run_and_report] Open/refresh: reports\mbip_v3_report.html
echo [run_and_report] Raw log:      reports\last_run.txt
if not "%MBIP_AUTOPUBLISH%"=="1" (
  echo [run_and_report] Nak team lihat? Jalankan: tests\publish.bat
)
endlocal

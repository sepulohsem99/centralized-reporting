"""
MBIP-TC-K-002 — Daftar Kompaun Letak Kereta > Cetak.

Sheet MBIP-TC-K-002: "Verify that 'Cetak' button can generate and print out"
— sync the information, tap 'Cetak'; expected: the record prints to a
connected printer.

Flow (see pages/cetak_page.py): Senarai -> open the newest K-jenis record ->
KEMASKINI DATA popup -> tap the pinned CETAK button -> classify the print
result. cetak_page re-navigates to the record on every printer-wait retry
(CETAK closes the popup). Prints the record K-001 created this session.
The Bluetooth printer auto-sleeps after ~10 min; cetak_page beeps + banners
the operator and re-tries for up to 5 min before skipping.
"""

import pytest


def test_mbip_tc_k_002_daftar_kompaun_letak_kereta_cetak(home_reset, pages,
                                                         created_records,
                                                         artifacts):
    # Print THIS RUN's K record by NUMBER (see N-002). No number => honest
    # skip; wrong record => FAIL.
    no = created_records.get("K")
    if not no:
        pytest.skip("show stopper from MBIP-TC-K-001 "
                    "(rekod K tidak dicipta / nombor tak terbaca)")

    result = pages.cetak.print_record("K", tc_label="K-002", pages=pages,
                                      no_rekod=no)

    if result.get("record_error"):
        pytest.fail(f"FAIL: {result['record_error']}")
    if not result["printed"]:
        pytest.skip(result.get("skip_reason", "printer tidak dihidupkan"))

    artifacts("MBIP-TC-K-002", no_dicetak=no)
    if result.get("unconfirmed"):
        print("  [K-002] Printed — WARNING: success inferred (no explicit "
              "result alert); see ui_dumps/cetak_K_*.xml")
    print(f"  [K-002] Kompaun Letak Kereta {no} printed successfully "
          f"(waited {result['waited_seconds']:.0f}s, "
          f"{result['poll_count']} attempt(s)) — PASS")

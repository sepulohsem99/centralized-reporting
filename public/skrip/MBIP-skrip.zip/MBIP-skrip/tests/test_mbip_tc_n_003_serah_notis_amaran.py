"""
MBIP-TC-N-003 — Serah Notis Amaran.

Sheet MBIP-TC-N-003: "Verify if that the user can attach picture (lampiran)"
— Test Data (C9): Picture; steps (C10): "Click on the clip icon for
take picture"; expected (C11): the application accepts the attachment.

Flow (location confirmed by the user, locators + acceptance evidence
confirmed live — see pages/serah_page.py): Senarai -> open THIS RUN's
N record BY NUMBER (created_records["N"]) -> confirm the popup shows that
number -> KEMASKINI DATA popup -> scroll to the LAMPIRAN row -> tap the
paperclip (content-desc U+F0C6) -> in-app camera -> snap (auto-closes) ->
assert the LAMPIRAN row gained a photo thumbnail.

Selection is BY NUMBER, not positional: which='last' attached to a stale
record and passed even when the create failed. No number now => honest skip.
"""

import pytest


def test_mbip_tc_n_003_serah_notis_amaran(home_reset, pages, created_records,
                                          artifacts):
    no = created_records.get("N")
    if not no:
        pytest.skip("show stopper from MBIP-TC-N-001 "
                    "(rekod N tidak dicipta / nombor tak terbaca)")

    pages.home.open_senarai()
    assert pages.senarai.is_senarai_screen_displayed(), \
        "FAIL: Senarai screen not displayed"
    assert pages.senarai.ensure_records_listed(), \
        "FAIL: no records listed in Senarai (nothing to attach to)"

    assert pages.senarai.open_record_by_number(no), \
        f"FAIL: rekod {no} tidak dijumpai dalam Senarai (create dakwa cipta {no})"
    assert pages.senarai.record_popup_shows_number(no), \
        f"FAIL: popup rekod tidak memaparkan {no} — rekod salah dibuka"

    pages.serah.attach_lampiran("N")
    artifacts("MBIP-TC-N-003", no_diserah=no)

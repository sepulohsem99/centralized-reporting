"""
MBIP-TC-N-001 — Daftar Notis Amaran.

Sheet MBIP-TC-N-001: "Verify that a 'Notis Amaran' can be created and
saved sucessfully with all required information". Test Data (C9): ALI /
010123456789 / JALAN DANGA SUTERA 12/3 (pesalah), JALAN BARAU 1 /
KAMPUNG BARU SKUDAI (kesalahan), Tempoh 1, KOMPAUN PELBAGAI -> UUK 7
UNDANG-UNDANG KECIL TAMAN (MDJBT) 1987 -> MEMOTONG, MENGALIH, ... --
see testdata/excel_data.py for the full cited entry.

Expected (C11): all mandatory fields accept valid information; picking
the Maklumat Jalan dropdown populates Taman/Poskod/Bandar/Negeri; the
submission goes through without errors.
"""

from testdata.excel_data import TC_DATA


def test_mbip_tc_n_001_daftar_notis_amaran(home_reset, pages,
                                           created_records, artifacts):
    data = TC_DATA["MBIP-TC-N-001"]

    pages.home.open_notis_amaran()
    assert pages.notis_amaran.is_notis_amaran_screen_displayed(), \
        "FAIL: Notis Amaran screen not displayed"
    print("  [N-001] Notis Amaran screen displayed")

    pages.notis_amaran.fill_pesalah_tab(data)
    pages.notis_amaran.click_seterusnya_from_pesalah()

    pages.notis_amaran.fill_notis_tab(data)
    pages.notis_amaran.fill_kompaun_code_fields(data)

    print("\n  [N-001] Attempting to take photos...")
    try:
        pages.notis_amaran.take_photos(count=3)
    except Exception as e:
        print(f"  [N-001] WARNING: camera handling failed ({e}) -- "
              f"continuing without photos (photos are exercised again "
              f"by the Serah/Hantar cases)")

    pages.notis_amaran.click_seterusnya_from_notis()

    pages.notis_amaran.fill_penerima_tab(data)
    pages.notis_amaran.click_menyerahkan()
    pages.notis_amaran.confirm_and_submit()

    assert pages.notis_amaran.is_submission_successful(), \
        "FAIL: Notis Amaran submission was not successful"
    # Store the NUMBER, not a flag: Cetak/Serah/Kemaskini select the record
    # by this number. Three distinct states, never conflated:
    #   create failed          -> assert above raised, key stays ABSENT
    #   create ok, no. read     -> key = the number
    #   create ok, no. UNREAD   -> key = "" + WARNING (read_record_number bug)
    _no = pages.notis_amaran.last_record_number
    if _no:
        created_records["N"] = _no
    else:
        created_records["N"] = ""
        print("  [N-001] WARNING: create berjaya tetapi nombor rekod TIDAK "
              "terbaca (read_record_number pulangkan None) -- kunci = '' "
              "(bug tersendiri, bukan kegagalan create)")
    artifacts("MBIP-TC-N-001", no_notis=_no)
    print("  [N-001] Notis Amaran submitted successfully")

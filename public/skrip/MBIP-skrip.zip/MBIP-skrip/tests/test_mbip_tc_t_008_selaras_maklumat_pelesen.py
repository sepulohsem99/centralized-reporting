"""
MBIP-TC-T-008 — Selaras Maklumat Pelesen.

Sheet MBIP-TC-T-008 (its C3 cell mislabels itself T-007): "Verify if
data of 'Maklumat Pelesen' saved sucessfully" — sync the information.

SKIPPED by explicit user instruction, exactly like v2: this sync is
deliberately not attempted. (Live recon 2026-07-16 additionally showed
why v2 skipped it: the Pelesen dataset is 52,317 records — "SEDANG
MENYIMPAN REKOD 618 DARI 52317 (1%)" after a minute — i.e. the better
part of an hour of device time per run.) The placeholder keeps the TC in
the result list under its List-to-Test numbering, clearly marked
SKIPPED.
"""

import pytest


@pytest.mark.skip(
    reason="Selaras Maklumat Pelesen intentionally skipped (user instruction)")
def test_mbip_tc_t_008_selaras_maklumat_pelesen():
    pass

"""
MBIP-TC-TN-003 — Tarik Notis by Tarikh (v3-added).

NO SHEET EXISTS for this TC in the V2.1.14 workbook (47 TCs); built on
the user's explicit decision ("Build it anyway", 2026-07-16).

Live recon fact: the TARIK NOTIS popup offers only 'ID Penguatkuasa'
and 'No Notis' fields — there is NO date input anywhere on the Notis
Kompaun screen. So "by Tarikh" is implemented as the strongest
verifiable statement: pull by ID, then assert every displayed notice
row carries a parseable tarikh (DD-MM-YYYY, confirmed row format) and
log the dates found. If the app ever grows a date filter, this test is
where it plugs in.
"""

import re

from testdata.excel_data import TC_DATA


def test_mbip_tc_tn_003_tarik_notis_by_tarikh(home_reset, pages):
    data = TC_DATA["MBIP-TC-TN-003"]

    pages.home.open_notis_kompaun()
    assert pages.notis_kompaun.is_notis_kompaun_screen_displayed(), \
        "FAIL: Notis Kompaun screen not displayed"

    pages.notis_kompaun.tarik_notis(
        id_penguatkuasa=data["id_penguatkuasa"])

    row = ("-android uiautomator",
           'new UiSelector().className("android.view.ViewGroup")'
           '.descriptionMatches(".*\\d{2}-\\d{2}-\\d{4}.*")')
    rows = pages.notis_kompaun.driver.find_elements(*row)
    assert rows, "FAIL: no dated notice rows displayed after the pull"

    dates = []
    for el in rows:
        d = el.get_attribute("content-desc") or ""
        m = re.search(r"\d{2}-\d{2}-\d{4}", d)
        if m:
            dates.append(m.group(0))
    print(f"  [TN-003] {len(dates)} notices with tarikh displayed: "
          f"{sorted(set(dates))}")
    assert dates, "FAIL: no tarikh readable from the notice rows"
    print("  [TN-003] Notices retrievable and identified by tarikh — PASS")

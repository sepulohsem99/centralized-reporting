#!/usr/bin/env bash
# ====================================================================
#  MBIP v3 — one-command rerun + auto-dashboard.
#  Runs the full 48-TC suite, then regenerates the HTML dashboard.
#  After this finishes, just refresh reports/mbip_v3_report.html.
#
#  Usage (from anywhere):  bash tests/run_and_report.sh
# ====================================================================
set -u
cd "$(dirname "$0")/.." || exit 1

echo "[run_and_report] Running full v3 suite..."
python -m pytest tests -v > reports/last_run.txt 2>&1
pytest_rc=$?

echo "[run_and_report] Regenerating dashboard..."
python reports/generate_report.py

echo "[run_and_report] Done. pytest exit=${pytest_rc}"
echo "[run_and_report] Open/refresh: reports/mbip_v3_report.html"
echo "[run_and_report] Raw log:      reports/last_run.txt"

"""
MBIP-TC-P-001 — Daftar Kompaun Pelbagai.

Sheet MBIP-TC-P-001: "Verify that a 'Daftar Kompaun Pelbagai' can be
created and saved sucessfully with all required information". Test Data
(C9): ABU / 010987654321 / JALAN JAYA 3 (pesalah), JALAN HULUBALANG 1 /
TAMAN UNGKU TUN AMINAH (kesalahan), Tempoh 1, KOMPAUN PELBAGAI ->
SEKSYEN 18(B) ... -> IDAK MEMATUHI PERUNTUKKAN UUK KERJA TANAH, Kadar
Denda RM2000 -- see testdata/excel_data.py for the full cited entry.

Expected (C11): all mandatory fields accept valid information, dropdown
options selectable, submission goes through without errors.
"""

from testdata.excel_data import TC_DATA


def test_mbip_tc_p_001_daftar_kompaun_pelbagai(home_reset, pages,
                                               created_records, artifacts):
    data = TC_DATA["MBIP-TC-P-001"]

    pages.home.open_daftar_kompaun()
    pages.daftar_kompaun.select_jenis_kompaun("Kompaun Pelbagai")
    assert pages.daftar_kompaun.is_daftar_kompaun_screen_displayed(), \
        "FAIL: Daftar Kompaun (Pelbagai) screen not displayed"
    print("  [P-001] Daftar Kompaun Pelbagai screen displayed")

    pages.daftar_kompaun.fill_pesalah_tab(data)
    pages.daftar_kompaun.click_seterusnya_from_pesalah()

    pages.daftar_kompaun.fill_kompaun_tab(data)
    pages.daftar_kompaun.fill_kompaun_code_fields(data)

    print("\n  [P-001] Attempting to take photos...")
    try:
        pages.daftar_kompaun.take_photos(count=3)
    except Exception as e:
        print(f"  [P-001] WARNING: camera handling failed ({e}) -- "
              f"continuing without photos")

    pages.daftar_kompaun.click_seterusnya_from_kompaun()

    pages.daftar_kompaun.fill_penerima_tab(data)
    pages.daftar_kompaun.click_menyerahkan()
    pages.daftar_kompaun.confirm_and_submit()

    assert pages.daftar_kompaun.is_submission_successful(), \
        "FAIL: Daftar Kompaun Pelbagai submission was not successful"
    # Store the NUMBER, not a flag (see N-001). ABSENT=create failed,
    # ""=create ok but number unread (own bug), number=good.
    _no = pages.daftar_kompaun.last_record_number
    if _no:
        created_records["P"] = _no
    else:
        created_records["P"] = ""
        print("  [P-001] WARNING: create berjaya tetapi nombor rekod TIDAK "
              "terbaca -- kunci = '' (bug tersendiri, bukan kegagalan create)")
    artifacts("MBIP-TC-P-001", no_kompaun=_no)
    print("  [P-001] Daftar Kompaun Pelbagai submitted successfully")

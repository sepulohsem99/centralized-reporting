"""
MBIP-TC-T-012 — Remember Me Functions.

Sheet MBIP-TC-T-012 (listed as "MBIP-TC-T012" in the List to Test):
login with the Remember Me checkbox ticked, close the application,
relaunch, verify the user is logged in / credentials remain saved
(username and password auto-filled).

ENVIRONMENT OVERRIDE: msc/Pass1 instead of the sheet's user4/Pass1
(user4 unverified on this device) — see testdata/excel_data.py.

Deliberately leaves the app logged in afterwards; the session logged_in
fixture accepts an already-logged-in home screen.
"""

import time

from config import APP_PACKAGE
from testdata.excel_data import TC_DATA


def test_mbip_tc_t_012_remember_me_functions(pages):
    creds = TC_DATA["MBIP-TC-T-012"]
    p = pages.pelarasan

    p.ensure_on_login_screen()
    assert pages.login.enable_remember_me(), \
        "FAIL: Remember Me checkbox never reported checked"

    pages.login.login(creds["username"], creds["password"])
    assert pages.home.is_home_screen_displayed(), \
        "FAIL: Home screen not displayed after Remember-Me login"
    print("  [T-012] Logged in with Remember Me — terminating app...")

    pages.login.driver.terminate_app(APP_PACKAGE)
    time.sleep(2)
    pages.login.driver.activate_app(APP_PACKAGE)
    time.sleep(3)

    # Either outcome satisfies the sheet's expectation ("user should be
    # logged in successfully and credentials should remain saved"):
    if pages.home.is_element_present(pages.home.HOME_SCREEN_INDICATOR,
                                     timeout=15):
        print("  [T-012] Still logged in after relaunch — session "
              "retained — PASS")
        return

    assert pages.login.is_login_screen_displayed(), \
        "FAIL: neither home nor login screen after relaunch"
    username, password = pages.login.get_login_field_values()
    print(f"  [T-012] After relaunch: username field={username!r}, "
          f"password field={'<masked non-empty>' if password else '<empty>'}")
    assert username == creds["username"], \
        f"FAIL: username not retained after relaunch (field: {username!r})"
    assert password not in ("", "PASSWORD"), \
        "FAIL: password not retained after relaunch (field empty)"
    print("  [T-012] Credentials auto-filled after relaunch — PASS")

    # Leave the app logged in for the downstream session fixture.
    pages.login.login(creds["username"], creds["password"])
    assert pages.home.is_home_screen_displayed(), \
        "FAIL: Home screen not displayed after post-verify login"

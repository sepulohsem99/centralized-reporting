"""
MBIP-TC-T-003 — Selaras Pengguna Apps.

Sheet MBIP-TC-T-003: "Verify if data of Penguna Apps saved sucessfully" -- sync the information.
Expected result (C11): System displays a confirmation message.

The actual work happens ONCE in the session-scoped pelarasan_results
fixture (a single pass through the Menu Selaras popup, before login);
this test asserts its own item's recorded verdict so each of the nine
T-00x cases reports individually.
"""


def test_mbip_tc_t_003_selaras_pengguna_apps(pelarasan_results):
    ok, msg = pelarasan_results["MBIP-TC-T-003"]
    assert ok, "MBIP-TC-T-003 Selaras Pengguna Apps failed: " + msg

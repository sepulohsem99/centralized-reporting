"""
MBIP-TC-T-007 — Selaras Maklumat Warna.

Sheet MBIP-TC-T-007: "Verify if data of Maklumat Warna saved sucessfully" -- sync the information.
Expected result (C11): System should displays a confirmation message.

The actual work happens ONCE in the session-scoped pelarasan_results
fixture (a single pass through the Menu Selaras popup, before login);
this test asserts its own item's recorded verdict so each of the nine
T-00x cases reports individually.
"""


def test_mbip_tc_t_007_selaras_maklumat_warna(pelarasan_results):
    ok, msg = pelarasan_results["MBIP-TC-T-007"]
    assert ok, "MBIP-TC-T-007 Selaras Maklumat Warna failed: " + msg

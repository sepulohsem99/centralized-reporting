"""
MBIP-TC-T-011 — Semak Kemaskini.

Sheet MBIP-TC-T-011: "Verify if application can check and display the
latest update" — click Semak Kemaskini and choose between Kemaskini
Sekarang or Kemudian; expected: update check completes without error.

v3 always chooses KEMUDIAN (per instruction: the app must NOT actually
update). A native "up to date" alert also counts as a completed check.
Runs pre-login from the Menu Selaras popup.
"""


def test_mbip_tc_t_011_semak_kemaskini(pelarasan_results, pages):
    p = pages.pelarasan
    p.ensure_on_login_screen()
    p.open_menu_selaras()
    try:
        ok = p.semak_kemaskini()
    finally:
        try:
            p.close_menu_selaras()
        except Exception as e:
            print(f"  [T-011] WARNING: menu close hiccup ({e})")
    assert ok, ("MBIP-TC-T-011 Semak Kemaskini did not complete (no "
                "update prompt or result alert; see ui_dumps/t011_*.xml)")

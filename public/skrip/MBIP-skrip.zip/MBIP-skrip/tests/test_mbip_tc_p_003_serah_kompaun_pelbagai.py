"""
MBIP-TC-P-003 -- Serah Kompaun Pelbagai.

Attach a picture (lampiran) to THIS RUN's P record, selected BY NUMBER
(created_records["P"], set by P-001), never by list position. The old
which='last' pick attached to a stale staging record and passed even when
the create failed. No number now => honest skip (show stopper from P-001);
record not found / wrong record on screen => FAIL.

Flow (see pages/serah_page.py): Senarai -> open the record by number ->
confirm the popup shows that number -> scroll to the LAMPIRAN row -> tap the
paperclip -> in-app camera -> snap -> assert the row gained a thumbnail.
"""

import pytest


def test_mbip_tc_p_003_serah_kompaun_pelbagai(home_reset, pages, created_records, artifacts):
    no = created_records.get("P")
    if not no:
        pytest.skip("show stopper from MBIP-TC-P-001 "
                    "(rekod P tidak dicipta / nombor tak terbaca)")

    pages.home.open_senarai()
    assert pages.senarai.is_senarai_screen_displayed(),         "FAIL: Senarai screen not displayed"
    assert pages.senarai.ensure_records_listed(),         "FAIL: no records listed in Senarai (nothing to attach to)"

    assert pages.senarai.open_record_by_number(no),         f"FAIL: rekod {no} tidak dijumpai dalam Senarai (create dakwa cipta {no})"
    assert pages.senarai.record_popup_shows_number(no),         f"FAIL: popup rekod tidak memaparkan {no} - rekod salah dibuka"

    pages.serah.attach_lampiran("P")
    artifacts("MBIP-TC-P-003", no_diserah=no)

"""
MBIP-TC-S-005 — Kompaun Form Sitaan - Bookmark.

Sheet MBIP-TC-S-005 (its C3 cell mislabels itself K-005): fill the
Kompaun section, book icon, name it, SIMPAN, reopen Pilihan Kegemaran,
select, verify repopulation. Test Data (C9) blank; the S-001 code combo
is used.

Same known build limitation as the other -005 TCs: the Pilihan
Kegemaran popup offers no save UI (only PILIH/HAPUS).
"""

from testdata.excel_data import TC_DATA


def test_mbip_tc_s_005_kompaun_form_sitaan_bookmark(home_reset, pages):
    data = TC_DATA["MBIP-TC-S-005"]
    pesalah = TC_DATA["MBIP-TC-S-001"]

    pages.home.open_daftar_kompaun()
    pages.sitaan.select_jenis_sitaan()

    # Draft-aware entry (EXACT-case Kompaun-tab marker).
    kompaun_tab = ("-android uiautomator",
                   'new UiSelector().text("Maklumat Jalan")')
    if pages.sitaan.is_element_present(kompaun_tab, timeout=4):
        print("  [S-005] Form reopened on the Kompaun tab (saved draft) "
              "-- skipping Pesalah stage")
    else:
        pages.sitaan.fill_pesalah_tab_lesen(pesalah)
        pages.sitaan.click_seterusnya_from_pesalah()

    pilih1 = ("-android uiautomator",
              'new UiSelector().text("PILIH KOMPAUN")')
    if (not pages.sitaan.is_element_present(pilih1, timeout=4)
            and pages.sitaan.is_text_visible(
                data["kesalahan_kompaun"][:28], timeout=2)):
        print("  [S-005] Kompaun codes already selected (saved draft) "
              "-- skipping selection")
    else:
        pages.sitaan.fill_kompaun_code_fields(data)

    pages.bookmark.open_bookmark_popup()
    pages.bookmark.save_bookmark(data["bookmark_name"])
    pages.bookmark.select_bookmark(data["bookmark_name"])
    pages.bookmark.verify_fields_repopulated(
        [data["kod_akta"][:28], data["kesalahan_kompaun"][:28]])

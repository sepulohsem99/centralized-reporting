"""
MBIP-TC-T-002 — Tetapan Pelbagai.

Sheet MBIP-TC-T-002: "Verify if the application allows access with a valid license". ENVIRONMENT OVERRIDE: lesen 352405067769401 is used instead of the sheet's 353466110955149, which is bound to the manual tester's IMEI.
Expected result (C11): System should allow entry and appear popup message ('Lesen sama').

The actual work happens ONCE in the session-scoped pelarasan_results
fixture (a single pass through the Menu Selaras popup, before login);
this test asserts its own item's recorded verdict so each of the nine
T-00x cases reports individually.
"""


def test_mbip_tc_t_002_tetapan_pelbagai(pelarasan_results):
    ok, msg = pelarasan_results["MBIP-TC-T-002"]
    assert ok, "MBIP-TC-T-002 Tetapan Pelbagai failed: " + msg

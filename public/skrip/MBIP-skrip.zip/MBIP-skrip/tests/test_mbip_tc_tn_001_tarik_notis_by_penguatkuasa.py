"""
MBIP-TC-TN-001 — Tarik Notis by Penguatkuasa.

Sheet MBIP-TC-TN-001: "Verify that the system can perform Tarik Notis to
take further action against recipient". Test Data (C9): ID Penguatkuasa:
msc. Steps (C10): navigate to Notis Kompaun, enter ID Penguatkuasa,
select action type. Expected (C11): successfully executes Tarik Notis by
ID Penguatkuasa and displays the correct information.

v3 note: unlike v2's warning-tolerant module, this is a real assert --
the pull must display record rows (the action-type step Kompaun/Patuh is
covered separately by NK-001/NK-002 in Phase 3).
"""

from testdata.excel_data import TC_DATA


def test_mbip_tc_tn_001_tarik_notis_by_penguatkuasa(home_reset, pages):
    data = TC_DATA["MBIP-TC-TN-001"]

    pages.home.open_notis_kompaun()
    assert pages.notis_kompaun.is_notis_kompaun_screen_displayed(), \
        "FAIL: Notis Kompaun screen not displayed"
    print("  [TN-001] Notis Kompaun screen displayed")

    # tarik_notis() asserts internally that record rows are displayed
    # after the pull (v2-hardened: verified TARIK tap, alert draining).
    pages.notis_kompaun.tarik_notis(
        id_penguatkuasa=data["id_penguatkuasa"])
    print("  [TN-001] Tarik Notis by ID Penguatkuasa displayed records")

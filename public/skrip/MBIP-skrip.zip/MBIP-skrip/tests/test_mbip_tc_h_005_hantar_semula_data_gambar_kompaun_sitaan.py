"""
MBIP-TC-H-005 — Hantar Semula Data & Gambar Kompaun Sitaan.

Sheet MBIP-TC-H-005: resubmit data & images for Sitaan. The tester's
manual round FAILED this ("Tidak berjaya hantar semula kompaun sitaan
... STATUS HANTAR - M dan STATUS - A") — history, not an oracle. Same
design as H-001..H-004.
"""

import re


def test_mbip_tc_h_005_hantar_semula_data_gambar_kompaun_sitaan(
        home_reset, pages, created_records):
    if not created_records.get("S"):
        print("  [H-005] WARNING: the S-jenis create did not succeed in "
              "this run -- resubmit relies on earlier records")

    pages.home.open_hantar()
    assert pages.hantar.is_hantar_screen_displayed(), \
        "FAIL: Hantar screen not displayed"
    pages.hantar.sync_all()
    print("  [H-005] Hantar sync flow completed")

    assert pages.home.go_back_to_home(), \
        "FAIL: could not return to home after Hantar"
    pages.home.open_senarai()
    assert pages.senarai.is_senarai_screen_displayed(), \
        "FAIL: Senarai screen not displayed for post-Hantar verification"
    assert pages.senarai.ensure_records_listed(), \
        "FAIL: no records listed in Senarai after Hantar"

    rows = pages.senarai.rows_for_jenis("S")
    for r in rows:
        print("  [H-005] row:", r)
    if rows:
        sent = [r for r in rows if re.search(r",\s*H\s*,", r)]
        assert sent, ("FAIL: no S-jenis record shows STATUS HANTAR 'H' "
                      "after Hantar; rows: " + "; ".join(rows))
        print("  [H-005] S-jenis record confirmed sent — PASS")
    else:
        print("  [H-005] NOTE: no S-jenis rows visible in Senarai -- "
              "per-jenis sent-status could not be verified here; Hantar "
              "flow itself completed without errors")

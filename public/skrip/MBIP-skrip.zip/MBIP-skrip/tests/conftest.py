"""
v3 conftest — shared session fixtures, collection ordering, and the
List-to-Test summary table.

Fixture chain (session-scoped, v2's show-stopper semantics preserved):
    driver -> pages -> pelarasan_results -> logged_in
- pelarasan_results runs the whole Menu Selaras sequence ONCE and records
  a per-item verdict for MBIP-TC-T-001..T-009; the nine T tests each
  assert their own item's verdict, so one sync failing doesn't hide the
  others.
- logged_in performs the login (with login()'s own retry/relaunch ladder).
  If it raises, pytest reports every downstream test as ERROR without
  running it -- nothing works without a session.

Collection order = the Excel's List to Test order (testdata.excel_data
.TC_ORDER), regardless of filename alphabetics.

pytest_terminal_summary prints one final "MBIP-TC-X-00N | name | OUTCOME"
row per collected TC, in List-to-Test order.
"""

import os
import re
import sys
import time as _time

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest

from appium import webdriver
from appium.options.android import UiAutomator2Options

from config import (
    APPIUM_URL,
    DEVICE_NAME,
    PLATFORM_NAME,
    APP_PACKAGE,
    APP_ACTIVITY,
    AUTOMATION_NAME,
    IMPLICIT_WAIT,
    TESTER_NAME,
    # Tetapan per-PBT: datang dari profil aktif, bukan lagi dari
    # excel_data (yang kekal sebagai rekod apa yang Excel MBIP kata).
    LICENSE_SETTINGS,
    TEST_CREDENTIALS,
    PROFILE_NAME,
    PROFILE_LABEL,
    PBT,
    ENV,
)
import profile as _profile
from device_utils import resolve_udid, app_version, device_model

# Run metadata captured at driver creation and emitted into results.json,
# so the dashboard can report WHICH device and WHICH app build produced a
# result instead of carrying a stale hardcoded build number.
_RUN_META = {}

from pages.login_page import LoginPage
from pages.pelarasan_page import PelarasanPage
from pages.home_page import HomePage
from pages.notis_amaran_page import NotisAmaranPage
from pages.daftar_kompaun_page import DaftarKompaunPage
from pages.notis_kompaun_page import NotisKompaunPage
from pages.senarai_page import SenaraiPage
from pages.hantar_page import HantarPage
from pages.serah_page import SerahPage
from pages.kemaskini_page import KemaskiniPage
from pages.kompaun_lesen_page import KompaunLesenPage
from pages.bookmark_page import BookmarkPage
from pages.sitaan_page import SitaanPage
from pages.cetak_page import CetakPage
from pages.printer_connect_page import PrinterConnectPage

from testdata.excel_data import (
    TC_LIST,
    TC_ORDER,
    TC_NAMES,
)


# ============================================================================
# Driver / page objects
# ============================================================================

def create_driver():
    print("\n" + "=" * 70)
    print("  IES APP — v3 REGRESSION SUITE (Excel V2.1.14)")
    print("=" * 70)
    # Cetak profil SEBELUM apa-apa berlaku: kalau seseorang tersilap
    # pilih production sedangkan staging yang dimaksudkan, ini peluang
    # terakhir untuk perasan sebelum data sebenar disentuh.
    print(_profile.describe(),
          flush=True)
    print("-" * 70)

    # Resolved at runtime, never hardcoded -- this suite runs unchanged on
    # any team member's device (see device_utils for the rules). Raising
    # here is deliberate: a wrong or missing device must stop the session
    # immediately with an actionable message, not 48 cryptic ERRORs.
    udid = resolve_udid(APP_PACKAGE)

    # Read once here (adb is reachable and the device is known good at this
    # point) and stash for the summary -- fully guarded, since failing to
    # read a cosmetic label must never abort a run.
    try:
        _RUN_META.update({
            "tester": TESTER_NAME,
            "device_udid": udid,
            "device_model": device_model(udid),
            "app_version": app_version(udid, APP_PACKAGE),
            "profile": PROFILE_NAME,
            "profile_label": PROFILE_LABEL,
            "pbt": PBT,
            "env": ENV,
        })
    except Exception:                                    # noqa: BLE001
        _RUN_META.setdefault("tester", TESTER_NAME)

    options = UiAutomator2Options()
    options.device_name = DEVICE_NAME
    options.set_capability("udid", udid)
    options.platform_name = PLATFORM_NAME
    options.app_package = APP_PACKAGE
    options.app_activity = APP_ACTIVITY
    # Do NOT set 'options.app' — the APK is already installed.
    options.no_reset = True
    options.full_reset = False
    options.automation_name = AUTOMATION_NAME
    options.set_capability("disableAndroidWatchers", True)

    print(f"  Connecting to Appium at: {APPIUM_URL}")
    print(f"  Device: {DEVICE_NAME} ({udid})")
    print(f"  App: {APP_PACKAGE}/{APP_ACTIVITY}")
    print(f"  Tester: {TESTER_NAME}")
    print("=" * 70 + "\n")

    driver = webdriver.Remote(APPIUM_URL, options=options)
    driver.implicitly_wait(IMPLICIT_WAIT)
    return driver


class Pages:
    """One bundle of page objects sharing the session driver."""

    def __init__(self, driver):
        self.login = LoginPage(driver)
        self.pelarasan = PelarasanPage(driver)
        self.home = HomePage(driver)
        self.notis_amaran = NotisAmaranPage(driver)
        self.daftar_kompaun = DaftarKompaunPage(driver)
        self.notis_kompaun = NotisKompaunPage(driver)
        self.senarai = SenaraiPage(driver)
        self.hantar = HantarPage(driver)
        self.serah = SerahPage(driver)
        self.kemaskini = KemaskiniPage(driver)
        self.lesen = KompaunLesenPage(driver)
        self.bookmark = BookmarkPage(driver)
        self.sitaan = SitaanPage(driver)
        self.cetak = CetakPage(driver)
        self.printer = PrinterConnectPage(driver)


@pytest.fixture(scope="session")
def driver():
    drv = create_driver()
    yield drv
    print("\n  [CLEANUP] Closing driver...")
    drv.quit()


@pytest.fixture(scope="session")
def pages(driver):
    return Pages(driver)


# ============================================================================
# Pelarasan (Menu Selaras) — one pass, per-item verdicts for T-001..T-009
# ============================================================================

@pytest.fixture(scope="session")
def pelarasan_results(pages):
    """Run the full Menu Selaras sequence once, before login, recording
    a per-item (ok, message) verdict keyed by TC id. A failed item does
    not stop the sequence: the flow recovers (drain alerts, reopen the
    menu) and moves on, so every T test gets its own real verdict."""
    p = pages.pelarasan
    results = {}
    # T-008 (Pelesen) is absent by design -- skipped per explicit user
    # instruction; its test file is a pytest.mark.skip placeholder.
    t_ids = [f"MBIP-TC-T-{n:03d}" for n in range(1, 10) if n != 8]

    # Targeted-rerun escape hatch: V3_SKIP_PELARASAN=1 skips the whole
    # Menu Selaras sequence (~6-8 min of device time). ONLY for
    # re-running individual non-T tests during development/debugging --
    # a full regression run must NOT set it (the T-001..T-009 verdicts
    # would be fabricated passes).
    if os.environ.get("V3_SKIP_PELARASAN") == "1":
        print("  [PELARASAN] V3_SKIP_PELARASAN=1 -- skipping the Menu "
              "Selaras sequence (targeted rerun mode)")
        return {tc: (True, "skipped by V3_SKIP_PELARASAN") for tc in t_ids}

    print("\n" + "-" * 60)
    print("  PHASE 0: PELARASAN (MENU SELARAS) — T-001..T-007, T-009")
    print("  (T-008 Pelesen skipped per user instruction)")
    print("-" * 60)

    try:
        p.ensure_on_login_screen()
        p.open_menu_selaras()
    except Exception as e:
        msg = f"Menu Selaras could not be opened: {type(e).__name__}: {e}"
        print(f"  [PELARASAN] {msg}")
        for tc in t_ids:
            results[tc] = (False, msg)
        return results

    steps = [
        ("MBIP-TC-T-001", lambda: p.set_tetapan_alamat_ip(
            LICENSE_SETTINGS["internal_ip"],
            LICENSE_SETTINGS["external_ip"])),
        ("MBIP-TC-T-002", lambda: p.set_tetapan_pelbagai_dengan_alternatif(
            LICENSE_SETTINGS["lesen_aplikasi"],
            LICENSE_SETTINGS.get("lesen_alternatif", []))),
        ("MBIP-TC-T-003", p.selaras_pengguna_apps),
        ("MBIP-TC-T-004", p.selaras_maklumat_alamat),
        ("MBIP-TC-T-005", p.selaras_maklumat_kompaun),
        ("MBIP-TC-T-006", p.selaras_jenis_kenderaan),
        ("MBIP-TC-T-007", p.selaras_maklumat_warna),
        # T-008 (Selaras Maklumat Pelesen) is intentionally NOT run --
        # skipped per explicit user instruction, same as v2 (its test
        # file is a pytest.mark.skip placeholder). The 52k-record
        # Pelesen sync would also cost ~an hour of device time.
        ("MBIP-TC-T-009", p.selaras_barang_sita),
    ]

    for tc_id, fn in steps:
        try:
            ret = fn()
            if ret is False:
                # _run_selaras_item returns False when no confirmation
                # popup showed -- the Excel's expected result IS that
                # confirmation message, so that's a per-item fail.
                results[tc_id] = (
                    False,
                    "no confirmation popup within the wait window")
            else:
                results[tc_id] = (True, "OK")
        except Exception as e:
            results[tc_id] = (False, f"{type(e).__name__}: {e}")
            print(f"  [PELARASAN] {tc_id} FAILED ({e}) -- recovering for "
                  f"the next item...")
            # Recovery: drain any covering alert; if the Menu Selaras
            # popup is gone (e.g. died on a sub-screen), reopen it.
            try:
                pages.home.dismiss_native_alerts(
                    first_timeout=2, context="pelarasan recovery")
                if not p.is_element_present(p.MENU_TETAPAN_ALAMAT_IP,
                                            timeout=3):
                    p.ensure_on_login_screen()
                    p.open_menu_selaras()
            except Exception as e2:
                print(f"  [PELARASAN] Recovery failed ({e2}) -- later "
                      f"items will report their own failures")

    try:
        p.close_menu_selaras()
    except Exception as e:
        print(f"  [PELARASAN] WARNING: could not close Menu Selaras "
              f"cleanly ({e}) -- login() has its own relaunch ladder")

    for tc_id in t_ids:
        ok, msg = results[tc_id]
        print(f"  [PELARASAN] {tc_id}: {'PASS' if ok else 'FAIL'} — {msg}")
    return results


# ============================================================================
# Login — the suite's show-stopper
# ============================================================================

@pytest.fixture(scope="session")
def logged_in(pages, pelarasan_results):
    """PHASE 1: Login. If this raises (login() already retries with a
    raw re-tap and a clean relaunch internally), pytest reports every
    test that depends on it as ERROR and never runs them."""
    print("\n" + "-" * 60)
    print("  PHASE 1: LOGIN")
    print("-" * 60)
    # T-012 (Remember Me) runs before this fixture's first consumer and
    # can leave the app already logged in on the home screen -- accept
    # that state instead of blindly typing into nonexistent fields.
    if pages.home.is_element_present(pages.home.HOME_SCREEN_INDICATOR,
                                     timeout=5):
        print("  [LOGIN] Already logged in (home screen visible) — PASS\n")
        return True
    pages.login.login(
        TEST_CREDENTIALS["username"],
        TEST_CREDENTIALS["password"],
    )
    assert pages.home.is_home_screen_displayed(), \
        "FAIL: Home screen not displayed after login"
    print("  [ASSERTION PASS] Home screen displayed after login\n")
    return True


# Lejar nombor rekod yang benar-benar dicipta semasa run ini.
#
# Bila sesuatu gagal, soalan pertama ialah "rekod mana?" -- tanpa nombor
# sebenar (contoh IPA3N260728054) tiada cara mencari baris itu dalam
# pangkalan data untuk menyiasat puncanya. Status sahaja tidak memadai.
_ARTIFACTS = {}


def record_artifact(tc_id, **values):
    """Simpan nilai yang dicipta oleh sesuatu TC, cth no_kompaun/no_notis.

    Dipanggil dari lapisan pages sebaik nombor kelihatan di skrin.
    Selamat dipanggil berulang kali; nilai digabung.
    """
    if not tc_id:
        return
    slot = _ARTIFACTS.setdefault(tc_id, {})
    for k, v in values.items():
        if v:
            slot[k] = str(v).strip()


@pytest.fixture(scope="session")
def created_records():
    """Session ledger: which jenis' create-flows succeeded this run.
    Used by the H tests to log (not hard-fail) when their precondition
    record wasn't created in this session."""
    return {}


@pytest.fixture()
def artifacts():
    """Fixture untuk test merekod nombor yang dicipta.

    Guna: artifacts("MBIP-TC-N-001", no_notis="IPA3N260728054")
    """
    return record_artifact


# How many times the React Native debug red-screen error overlay appeared
# and had to be cleared this run. Reported at end: this is a build/env
# signal (a debug APK pointed at a dead Metro dev server), not a test bug.
_RN_REDSCREEN_COUNT = [0]

# Markers of the RN error overlay ("Could not connect to development
# server" / "Unable to load script"). It's a full-screen modal that eats
# every element behind it, so one occurrence would otherwise turn every
# downstream TC into ERROR.
_RN_RED_MARKERS = [
    ('new UiSelector().textContains("development server")'),
    ('new UiSelector().textContains("Unable to load script")'),
    ('new UiSelector().textContains("Could not connect")'),
]


def _handle_rn_redscreen(pages):
    """Detect + clear the React Native debug red-screen. Press DISMISS; if
    it won't clear, relaunch the app. Returns True if one was handled.
    Counted in _RN_REDSCREEN_COUNT and reported at end of run."""
    import time
    from appium.webdriver.common.appiumby import AppiumBy

    def _present():
        for ui in _RN_RED_MARKERS:
            if pages.home.is_element_present(
                    (AppiumBy.ANDROID_UIAUTOMATOR, ui), timeout=1):
                return True
        return False

    if not _present():
        return False
    _RN_REDSCREEN_COUNT[0] += 1
    print(f"  [RN-REDSCREEN] React Native error overlay detected "
          f"(#{_RN_REDSCREEN_COUNT[0]}) -- pressing DISMISS")
    for loc in ((AppiumBy.ANDROID_UIAUTOMATOR,
                 'new UiSelector().textMatches("(?i)dismiss")'),
                (AppiumBy.ACCESSIBILITY_ID, "Dismiss")):
        if pages.home.is_element_present(loc, timeout=1):
            try:
                pages.home.tap_element(pages.home.find_element(loc, timeout=2))
                time.sleep(1)
                break
            except Exception:                                # noqa: BLE001
                pass
    if _present():
        print("  [RN-REDSCREEN] Still present after DISMISS -- relaunching app")
        try:
            pages.login._force_relaunch_to_login()
            pages.login.login(TEST_CREDENTIALS["username"],
                              TEST_CREDENTIALS["password"])
        except Exception as e:                               # noqa: BLE001
            print(f"  [RN-REDSCREEN] relaunch/login failed ({e})")
    return True


def _recover_to_home(pages):
    """Hardened home recovery. Confirmed via v3 run 1: v2's blind
    back-press loop (go_back_to_home) cannot close the Senarai record's
    "KEMASKINI DATA" popup -- that RN modal swallows the device Back
    key, so one stranded popup turned every downstream test into ERROR.
    Ladder per round: drain native alerts -> home reached? -> close any
    popup via its X icon with a RAW tap (this app's RN pressables
    silently no-op on el.click(); the popup's close is content-desc
    U+2715, confirmed via ui_dumps/serah_N_record_view.xml) -> if we
    fell out to the login screen, log back in -> device Back. Last
    resort: cold relaunch + login (app data persists, nothing is lost).
    """
    import time
    from appium.webdriver.common.appiumby import AppiumBy

    x_locators = [
        (AppiumBy.ACCESSIBILITY_ID, "✕"),
        (AppiumBy.ACCESSIBILITY_ID, "X"),
    ]
    for _ in range(8):
        # Clear a RN debug red-screen and the printer-connection alert first
        # -- either would otherwise sit on top of the home screen and defeat
        # every recovery step below. drain_printer_alert counts globally.
        _handle_rn_redscreen(pages)
        pages.home.drain_printer_alert()
        pages.home.dismiss_native_alerts(first_timeout=1,
                                         context="home recovery")
        if pages.home.is_element_present(pages.home.HOME_SCREEN_INDICATOR,
                                         timeout=2):
            print("  [RECOVERY] Home screen reached")
            return True
        closed = False
        for loc in x_locators:
            if pages.home.is_element_present(loc, timeout=1):
                try:
                    el = pages.home.find_element(loc, timeout=2)
                    pages.home.tap_element(el)
                    print("  [RECOVERY] Closed a popup via its X icon")
                    closed = True
                    time.sleep(1)
                    break
                except Exception:
                    pass
        if closed:
            continue
        # Fell all the way out to the login screen? (Home grid absent
        # was already established above.)
        if pages.login.is_element_present(pages.login.APP_TITLE, timeout=1):
            print("  [RECOVERY] On the login screen -- logging back in")
            pages.login.login(TEST_CREDENTIALS["username"],
                              TEST_CREDENTIALS["password"])
            return pages.home.is_element_present(
                pages.home.HOME_SCREEN_INDICATOR, timeout=10)
        pages.home.press_back()
        time.sleep(1)

    print("  [RECOVERY] Still not home -- cold relaunch + fresh login")
    pages.login._force_relaunch_to_login()
    pages.login.login(TEST_CREDENTIALS["username"],
                      TEST_CREDENTIALS["password"])
    return pages.home.is_element_present(pages.home.HOME_SCREEN_INDICATOR,
                                         timeout=10)


@pytest.fixture()
def home_reset(logged_in, pages):
    """Failure isolation: recover to the home screen regardless of where
    the previous test ended (mid-form, leftover popup/alert, ...), so
    one TC failing can't poison the next one's starting point."""
    assert _recover_to_home(pages), \
        "FAIL: Could not recover to the home screen"
    return True


# ============================================================================
# Collection ordering — Excel List-to-Test order
# ============================================================================

_TC_FILE_RE = re.compile(r"test_mbip_tc_([a-z]+)_(\d+)_")

# Filled during collection; used by the summary table.
_COLLECTED = []  # list of (tc_id, nodeid)

# Wall-clock start, used only for the dashboard JSON duration field.
_SESSION_START = [None]


def pytest_sessionstart(session):
    del session
    _SESSION_START[0] = _time.time()


def _short_reason(rep):
    """Satu baris sebab kegagalan/skip dari laporan pytest.

    Untuk skip, pytest menyimpan (fail, baris, mesej) -- mesej itulah yang
    berguna. Untuk gagal/ralat, baris ringkasan pengecualian (baris "E ...")
    membawa maklumat sebenar; keseluruhan traceback terlalu panjang untuk
    sel jadual, jadi diambil baris terakhir yang bermakna.
    """
    try:
        if getattr(rep, "outcome", "") == "skipped":
            lr = getattr(rep, "longrepr", None)
            if isinstance(lr, tuple) and len(lr) == 3:
                return str(lr[2]).replace("Skipped: ", "").strip()[:300]
        text = getattr(rep, "longreprtext", "") or str(
            getattr(rep, "longrepr", "") or "")
        if not text:
            return ""
        elines = [l[2:].strip() for l in text.splitlines()
                  if l.startswith("E ") and l[2:].strip()]
        if elines:
            # Baris E terakhir ialah pengecualian sebenar; yang sebelumnya
            # selalunya konteks assert.
            return elines[-1][:300]
        last = [l.strip() for l in text.splitlines() if l.strip()]
        return last[-1][:300] if last else ""
    except Exception:                                    # noqa: BLE001
        return ""


def _tc_id_for_item(item):
    m = _TC_FILE_RE.search(os.path.basename(str(item.fspath)))
    if not m:
        return None
    series, num = m.group(1).upper(), int(m.group(2))
    return f"MBIP-TC-{series}-{num:03d}"


def pytest_collection_modifyitems(config, items):
    del config
    items.sort(key=lambda it: TC_ORDER.get(_tc_id_for_item(it) or "", 999))
    _COLLECTED.clear()
    for it in items:
        tc = _tc_id_for_item(it)
        if tc:
            _COLLECTED.append((tc, it.nodeid))


# ============================================================================
# Final List-to-Test summary table
# ============================================================================

def pytest_terminal_summary(terminalreporter, exitstatus, config):
    del exitstatus, config
    stats = terminalreporter.stats
    outcome_by_nodeid = {}
    # Sebab kegagalan sebenar, bukan sekadar status.
    #
    # Tanpa ini dashboard hanya tahu "FAILED" dan terpaksa bergantung pada
    # nota yang ditulis tangan -- yang akan terus memaparkan sebab LAMA
    # walaupun TC itu kini gagal atas sebab yang berbeza sama sekali.
    # Bahaya bila projek ini disalin ke majlis lain: nota MBIP akan ikut
    # dan mengarut di sana.
    reason_by_nodeid = {}
    # Precedence: ERROR > FAILED > SKIPPED > PASSED (a setup error must
    # not be masked by anything else).
    for key, label in (("passed", "PASSED"), ("skipped", "SKIPPED"),
                       ("failed", "FAILED"), ("error", "ERROR")):
        for rep in stats.get(key, []):
            nodeid = getattr(rep, "nodeid", None)
            if not nodeid:
                continue
            outcome_by_nodeid[nodeid] = label
            if label != "PASSED":
                r = _short_reason(rep)
                if r:
                    reason_by_nodeid[nodeid] = r

    if not _COLLECTED:
        return

    tr = terminalreporter
    tr.write_sep("=", "MBIP LIST-TO-TEST SUMMARY (Excel V2.1.14)")
    name_width = max(len(TC_NAMES.get(tc, "?")) for tc, _ in _COLLECTED)
    ordered = sorted(_COLLECTED, key=lambda x: TC_ORDER.get(x[0], 999))
    counts = {}
    for tc_id, nodeid in ordered:
        outcome = outcome_by_nodeid.get(nodeid, "NOT RUN")
        counts[outcome] = counts.get(outcome, 0) + 1
        name = TC_NAMES.get(tc_id, "?")
        tr.write_line(f"  {tc_id:<15} | {name:<{name_width}} | {outcome}")
    total = " | ".join(f"{k}: {v}" for k, v in sorted(counts.items()))
    tr.write_line("  " + "-" * (15 + name_width + 16))
    tr.write_line(f"  {len(ordered)} test cases — {total}")

    # Environmental noise counters (not test outcomes): a high printer-alert
    # count means "keep the printer awake", and any RN red-screen means the
    # debug build lost its Metro dev server.
    try:
        from pages.base_page import BasePage
        printer_alerts = BasePage.printer_alert_count()
    except Exception:                                        # noqa: BLE001
        printer_alerts = 0
    tr.write_line(f"  Printer-connection alerts drained: {printer_alerts}  "
                  f"|  RN red-screens handled: {_RN_REDSCREEN_COUNT[0]}")

    # ---- Auto-dashboard hook: dump the same per-TC data to JSON so
    # reports/generate_report.py can refresh reports/mbip_v3_report.html
    # with zero manual copy/paste. Purely additive and fully guarded --
    # a failure here must never affect the test run's outcome. ----
    try:
        import json
        import datetime

        results = {tc_id: outcome_by_nodeid.get(nodeid, "NOT RUN")
                   for tc_id, nodeid in ordered}
        reasons = {tc_id: reason_by_nodeid[nodeid]
                   for tc_id, nodeid in ordered if nodeid in reason_by_nodeid}
        summary = {}
        for outcome in results.values():
            summary[outcome] = summary.get(outcome, 0) + 1
        payload = {
            "generated_at": datetime.datetime.now().isoformat(
                timespec="seconds"),
            "duration_seconds": (round(_time.time() - _SESSION_START[0], 2)
                                 if _SESSION_START[0] else None),
            "total": len(results),
            "summary": summary,
            "results": results,
            # Who/what produced this run. Falls back to the config value
            # when the driver never started (e.g. preflight-level failure),
            # so the field is always present for the dashboard.
            "tester": _RUN_META.get("tester", TESTER_NAME),
            "device_udid": _RUN_META.get("device_udid"),
            "device_model": _RUN_META.get("device_model"),
            "app_version": _RUN_META.get("app_version"),
            # PBT/environment yang diuji. Wajib ada walaupun driver
            # tak sempat start, supaya laporan tak boleh tersalah
            # kaitkan keputusan ini dengan PBT lain.
            # Sebab kegagalan sebenar per TC, dan nombor rekod yang
            # dicipta -- kedua-duanya untuk menjejak balik ke pangkalan
            # data apabila sesuatu gagal.
            "reasons": reasons,
            "artifacts": _ARTIFACTS,
            "printer_alerts": printer_alerts,
            "rn_redscreens": _RN_REDSCREEN_COUNT[0],
            "profile": _RUN_META.get("profile", PROFILE_NAME),
            "profile_label": _RUN_META.get("profile_label", PROFILE_LABEL),
            "pbt": _RUN_META.get("pbt", PBT),
            "env": _RUN_META.get("env", ENV),
        }
        out = os.path.abspath(os.path.join(
            os.path.dirname(__file__), "..", "reports", "results.json"))
        os.makedirs(os.path.dirname(out), exist_ok=True)
        with open(out, "w", encoding="utf-8") as fh:
            json.dump(payload, fh, indent=2, ensure_ascii=False)
        tr.write_line(f"  [dashboard] results.json written -> {out}")
    except Exception as e:  # noqa: BLE001 - never break the run
        tr.write_line(f"  [dashboard] WARNING: results.json not written "
                      f"({type(e).__name__}: {e})")

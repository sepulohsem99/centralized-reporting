"""
MBIP-TC-S-004 — Kemaskini Sitaan.

Sheet 'MBIP-TC-S-004 ' (trailing-space name): "Verify existing
information is displayed correctly" — verify old data, Kemaskini via the
Sila Isi Keterangan form, change per C9 ("Jalan Keruing 11 change to
Jalan Harimau Telap" — this environment's record holds JALAN GANGSA 2
from S-001), Seterusnya. The tester's manual round FAILED this TC —
history, not an oracle.

Same known limitation as the other Kemaskini flows: the edit form's
lower section does not render/scroll on this build.
"""

import pytest

from testdata.excel_data import TC_DATA


def test_mbip_tc_s_004_kemaskini_sitaan(home_reset, pages,
                                        created_records, artifacts):
    data = TC_DATA["MBIP-TC-S-004"]
    no = created_records.get("S")
    if not no:
        pytest.skip("show stopper from MBIP-TC-S-001 "
                    "(rekod S tidak dicipta / nombor tak terbaca)")

    pages.home.open_senarai()
    assert pages.senarai.is_senarai_screen_displayed(), \
        "FAIL: Senarai screen not displayed"
    assert pages.senarai.ensure_records_listed(), \
        "FAIL: no records listed in Senarai (nothing to update)"

    assert pages.senarai.open_record_by_number(no), (
        f"FAIL: rekod {no} tidak dijumpai dalam Senarai "
        f"(create dakwa cipta {no})")
    assert pages.senarai.record_popup_shows_number(no), (
        f"FAIL: popup rekod tidak memaparkan {no} - rekod salah dibuka")
    artifacts("MBIP-TC-S-004", no_dikemaskini=no)
    pages.kemaskini.verify_record_popup(data["old"])
    pages.kemaskini.start_kemaskini("KEMASKINI VIA AUTOMATION V3")
    assert pages.kemaskini.is_edit_form_open("SITAAN"), \
        "FAIL: Kemaskini edit form did not open"
    print("  [S-004] Kemaskini edit form open")

    pages.kemaskini.update_kesalahan_address(data["old"]["jalan"], data)
    pages.kemaskini.proceed_and_submit()
    pages.kemaskini.verify_updated(pages.senarai, "S",
                                   data["kesalahan_jalan"])

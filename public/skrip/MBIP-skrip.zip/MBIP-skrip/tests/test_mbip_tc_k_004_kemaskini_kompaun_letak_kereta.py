"""
MBIP-TC-K-004 — Kemaskini Kompaun Letak Kereta.

Sheet 'MBIP-TC-K-004 ' (trailing-space name): "Verify existing information is displayed correctly" —
verify old data on the record view, Kemaskini via the Sila Isi
Keterangan form, change the information per C9, Seterusnya; old data
correct before update, updated fields reflect the new values.

Flow recon'd live 2026-07-16 (see pages/kemaskini_page.py, incl. the
known limitation: the edit form only moves via keyboard-focus traversal,
so fields below the Kesalahan block are updated best-effort).
"""

import pytest

from testdata.excel_data import TC_DATA


def test_mbip_tc_k_004_kemaskini_kompaun_letak_kereta(home_reset, pages, created_records, artifacts):
    data = TC_DATA["MBIP-TC-K-004"]
    no = created_records.get("K")
    if not no:
        pytest.skip("show stopper from MBIP-TC-K-001 "
                    "(rekod K tidak dicipta / nombor tak terbaca)")

    pages.home.open_senarai()
    assert pages.senarai.is_senarai_screen_displayed(), \
        "FAIL: Senarai screen not displayed"
    assert pages.senarai.ensure_records_listed(), \
        "FAIL: no records listed in Senarai (nothing to update)"

    assert pages.senarai.open_record_by_number(no), (
        f"FAIL: rekod {no} tidak dijumpai dalam Senarai "
        f"(create dakwa cipta {no})")
    assert pages.senarai.record_popup_shows_number(no), (
        f"FAIL: popup rekod tidak memaparkan {no} - rekod salah dibuka")
    artifacts("MBIP-TC-K-004", no_dikemaskini=no)
    pages.kemaskini.verify_record_popup(data["old"])
    pages.kemaskini.start_kemaskini("KEMASKINI VIA AUTOMATION V3")
    assert pages.kemaskini.is_edit_form_open("TRAFIK"), \
        "FAIL: Kemaskini edit form did not open"
    print("  [K-004] Kemaskini edit form open")

    pages.kemaskini.update_kesalahan_address(data["old"]["jalan"], data)
    pages.kemaskini.proceed_and_submit()
    pages.kemaskini.verify_updated(pages.senarai, "K",
                                   data["kesalahan_jalan"])

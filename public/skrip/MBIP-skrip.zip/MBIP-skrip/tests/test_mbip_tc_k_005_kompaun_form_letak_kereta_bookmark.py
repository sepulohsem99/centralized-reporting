"""
MBIP-TC-K-005 — Kompaun Form Letak Kereta - Bookmark.

Sheet MBIP-TC-K-005 (Test Data N/A; K-001 code combo used): fill the Kompaun section, tap the book icon, name the
bookmark, SIMPAN; reopen the Pilihan Kegemaran list, select it, and
verify the fields repopulate. Kompaun-code combo per C9 (see
testdata/excel_data.py). Bookmark name is not specified in the sheet; a
distinct v3 value is used. The form is abandoned afterwards (no
submission) -- the next test's home recovery cleans up.
"""

from testdata.excel_data import TC_DATA


def test_mbip_tc_k_005_kompaun_form_letak_kereta_bookmark(
        home_reset, pages):
    data = TC_DATA["MBIP-TC-K-005"]
    pesalah = TC_DATA["MBIP-TC-K-001"]

    pages.home.open_daftar_kompaun()
    pages.daftar_kompaun.select_jenis_kompaun_trafik()
    assert pages.daftar_kompaun.is_daftar_kompaun_trafik_screen_displayed(), \
        "FAIL: Daftar Kompaun Trafik screen not displayed"
    # Draft-aware entry (same behavior as the other kompaun forms).
    # EXACT-case locator -- the Pesalah tab has an ALL-CAPS
    # "MAKLUMAT JALAN" field that a case-insensitive check matches too
    # (bit us live); only the Kompaun/Notis tab renders Title Case.
    kompaun_tab = ("-android uiautomator",
                   'new UiSelector().text("Maklumat Jalan")')
    if pages.daftar_kompaun.is_element_present(kompaun_tab, timeout=4):
        print("  [K-005] Form reopened on the Kompaun tab (saved draft) "
              "-- skipping Pesalah stage")
    else:
        # 2026-08-24: guna aliran TRAFIK v2 (build hotfix) sama seperti
        # K-001 — flow lama mencari label 'NO. KERETA' yang tiada lagi.
        from testdata.trafik_v2 import TRAFIK_V2
        pesalah_v2 = dict(pesalah)
        pesalah_v2.update(TRAFIK_V2)
        try:
            pages.daftar_kompaun.fill_pesalah_tab_trafik_v2(pesalah_v2)
        except Exception as e:                               # noqa: BLE001
            print(f"  [K-005] fill v2 gagal ({type(e).__name__}) -- "
                  f"cuba flow lama...")
            pages.daftar_kompaun.fill_pesalah_tab_trafik(pesalah)
        pages.daftar_kompaun.click_seterusnya_from_pesalah()

    # Trafik: tier 1 pre-selected (PERINTAH 39); select akta + kesalahan
    # + kadar, then bookmark. Skip if a saved draft already holds them.
    sahkan = []
    pilih_akta = ("-android uiautomator",
                  'new UiSelector().text("PILIH AKTA")')
    if (not pages.daftar_kompaun.is_element_present(pilih_akta, timeout=4)
            and pages.daftar_kompaun.is_text_visible(
                data["kesalahan_kompaun"][:28], timeout=2)):
        print("  [K-005] Kompaun codes already selected (saved draft) "
              "-- skipping selection")
    else:
        # >>> Fix #25 (2026-09-05, run penuh bersih): laluan lama
        # fill_kompaun_code_fields_trafik() menganggap tier-1 terkunci
        # PERINTAH 39 (build lama) -> AssertionError serta-merta pada
        # build hotfix. Guna laluan v2 yang SAMA seperti K-001 (terbukti
        # PASS): blok alamat hint-based + 3 tier ikut hint. Data tier
        # dari K-001 (helaian K-005 'Test Data N/A'). <<<
        data_v2 = dict(pesalah)
        data_v2.update({k: v for k, v in data.items() if v})
        try:
            pages.daftar_kompaun.isi_alamat_trafik_v2(data_v2)
        except Exception as e:                               # noqa: BLE001
            print(f"  [K-005] blok alamat v2 gagal ({type(e).__name__}) "
                  f"-- teruskan ke tier kod (bukan syarat bookmark)")
        keputusan = pages.daftar_kompaun.fill_kompaun_code_fields_trafik_v2(
            data_v2)
        # nilai SEBENAR yang terpilih (K-001 pun pilih baris atas bila
        # teks Excel tiada) -- itu yang mesti muncul semula selepas bookmark
        sahkan = []
        for k in ("akta", "kesalahan"):
            v = keputusan.get(k) if isinstance(keputusan, dict) else None
            if isinstance(v, str) and len(v) >= 8:
                sahkan.append(v.split(" - ", 1)[-1][:28])
        if sahkan:
            print(f"  [K-005] nilai sah selepas bookmark: {sahkan}")

    pages.bookmark.open_bookmark_popup()
    pages.bookmark.save_bookmark(data["bookmark_name"])
    pages.bookmark.select_bookmark(data["bookmark_name"])
    pages.bookmark.verify_fields_repopulated(
        sahkan if sahkan else
        [data["kod_akta"][:28], data["kesalahan_kompaun"][:28]])

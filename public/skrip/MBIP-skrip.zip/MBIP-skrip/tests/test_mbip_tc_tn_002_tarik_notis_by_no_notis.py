"""
MBIP-TC-TN-002 — Tarik Notis by No.Notis.

Sheet MBIP-TC-TN-002 (its steps text is a copy-paste of the Patuh flow;
the TC NAME is the actual requirement). Test Data (C9) blank: the
notice number is discovered at runtime — first pull by ID Penguatkuasa
(msc) to learn a real notice number, then pull by that No Notis (the
popup's second field, confirmed via live recon) and verify that notice
is displayed. The tester's manual round FAILED this ("Cannot tarik
notis by No.Notis") — history, not an oracle.
"""

from testdata.excel_data import TC_DATA


def test_mbip_tc_tn_002_tarik_notis_by_no_notis(home_reset, pages):
    data = TC_DATA["MBIP-TC-TN-002"]

    pages.home.open_notis_kompaun()
    assert pages.notis_kompaun.is_notis_kompaun_screen_displayed(), \
        "FAIL: Notis Kompaun screen not displayed"

    # Discover a real notice number via the ID pull.
    pages.notis_kompaun.tarik_notis(
        id_penguatkuasa=data["id_penguatkuasa"])
    numbers = pages.notis_kompaun.get_pulled_notice_numbers()
    assert numbers, "FAIL: no notice numbers readable after the ID pull"
    target = numbers[0]
    print(f"  [TN-002] Using notice number: {target}")

    assert pages.notis_kompaun.tarik_by_no_notis(target), \
        (f"FAIL: notice {target} not displayed after Tarik by No.Notis "
         f"(see ui_dumps/tn002_notice_not_listed.xml)")
    print("  [TN-002] Tarik Notis by No.Notis displayed the notice — PASS")

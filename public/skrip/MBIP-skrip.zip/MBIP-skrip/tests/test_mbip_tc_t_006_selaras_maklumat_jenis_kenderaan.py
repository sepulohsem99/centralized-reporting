"""
MBIP-TC-T-006 — Selaras Maklumat Jenis Kenderaan.

Sheet MBIP-TC-T-006: "Verify if data of Maklumat Jenis Kenderaan saved sucessfully" -- sync the information.
Expected result (C11): System displays a confirmation message.

The actual work happens ONCE in the session-scoped pelarasan_results
fixture (a single pass through the Menu Selaras popup, before login);
this test asserts its own item's recorded verdict so each of the nine
T-00x cases reports individually.
"""


def test_mbip_tc_t_006_selaras_maklumat_jenis_kenderaan(pelarasan_results):
    ok, msg = pelarasan_results["MBIP-TC-T-006"]
    assert ok, "MBIP-TC-T-006 Selaras Maklumat Jenis Kenderaan failed: " + msg

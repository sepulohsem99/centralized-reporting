@echo off
REM ===================================================================
REM  MBIP v3 - PREFLIGHT CHECK
REM
REM  Sahkan SEMUA prasyarat sebelum test bermula. Satu run penuh ambil
REM  1.5-2.5 jam, jadi lebih baik gagal dalam 10 saat di sini daripada
REM  gagal selepas 2 jam sebab satu benda tak dipasang.
REM
REM  Guna:  tests\check_env.bat
REM  Exit code 0 = semua OK, bukan-sifar = ada yang kena betulkan.
REM ===================================================================
setlocal enabledelayedexpansion
cd /d "%~dp0\.."

set FAILED=0

echo.
echo ================================================================
echo   MBIP v3 - PREFLIGHT CHECK
echo ================================================================
echo.

REM ---------------------------------------------------------------
REM  1. Node.js (Appium berjalan atas Node)
REM ---------------------------------------------------------------
where node >nul 2>&1
if errorlevel 1 (
  echo [GAGAL] Node.js tidak dijumpai.
  echo         Appium perlukan Node.js. Muat turun: https://nodejs.org
  set /a FAILED+=1
) else (
  for /f "delims=" %%v in ('node --version 2^>nul') do set NODEV=%%v
  echo [OK]    Node.js !NODEV!
)

REM ---------------------------------------------------------------
REM  2. Appium CLI
REM ---------------------------------------------------------------
where appium >nul 2>&1
if errorlevel 1 (
  echo [GAGAL] Appium tidak dijumpai.
  echo         Pasang dengan:  npm install -g appium
  set /a FAILED+=1
) else (
  for /f "delims=" %%v in ('appium --version 2^>nul') do set APPIUMV=%%v
  echo [OK]    Appium !APPIUMV!
)

REM ---------------------------------------------------------------
REM  3. Driver uiautomator2
REM ---------------------------------------------------------------
where appium >nul 2>&1
if not errorlevel 1 (
  appium driver list --installed 2>&1 | findstr /i "uiautomator2" >nul
  if errorlevel 1 (
    echo [GAGAL] Driver uiautomator2 belum dipasang.
    echo         Pasang dengan:  appium driver install uiautomator2
    set /a FAILED+=1
  ) else (
    echo [OK]    Driver uiautomator2 dipasang
  )
)

REM ---------------------------------------------------------------
REM  4. Python
REM ---------------------------------------------------------------
where python >nul 2>&1
if errorlevel 1 (
  echo [GAGAL] Python tidak dijumpai.
  echo         Pasang Python 3.11+ dan tandakan "Add to PATH" masa install.
  echo         Muat turun: https://www.python.org/downloads/
  set /a FAILED+=1
  goto :skip_python_checks
)
for /f "delims=" %%v in ('python --version 2^>^&1') do set PYV=%%v
echo [OK]    !PYV!

REM ---------------------------------------------------------------
REM  5. Pakej Python yang diperlukan
REM ---------------------------------------------------------------
python -c "import appium, selenium, pytest" >nul 2>&1
if errorlevel 1 (
  echo [GAGAL] Pakej Python tidak lengkap.
  echo         Pasang dengan:  pip install -r requirements.txt
  set /a FAILED+=1
) else (
  echo [OK]    Pakej Python lengkap ^(appium, selenium, pytest^)
)

:skip_python_checks

REM ---------------------------------------------------------------
REM  6. adb
REM ---------------------------------------------------------------
where adb >nul 2>&1
if errorlevel 1 (
  echo [GAGAL] adb tidak dijumpai dalam PATH.
  echo         Pasang Android SDK platform-tools, tambah ke PATH.
  echo         https://developer.android.com/tools/releases/platform-tools
  set /a FAILED+=1
) else (
  echo [OK]    adb dijumpai
)

REM ---------------------------------------------------------------
REM  7. Profil PBT / environment
REM ---------------------------------------------------------------
echo.
where python >nul 2>&1
if not errorlevel 1 (
  python profile.py
  if errorlevel 1 (
    echo [GAGAL] Profil tidak sah atau belum dipilih ^(lihat di atas^).
    set /a FAILED+=1
  )
)

REM ---------------------------------------------------------------
REM  8. Device, app, dan Appium server
REM     Diserahkan kepada device_utils.py --check supaya preflight dan
REM     run sebenar guna logik yang SAMA (tak boleh tak sepadan).
REM ---------------------------------------------------------------
echo.
where python >nul 2>&1
if not errorlevel 1 (
  python device_utils.py --check
  if errorlevel 1 set /a FAILED+=1
) else (
  echo [LANGKAU] Semakan device tidak dapat dijalankan tanpa Python.
  set /a FAILED+=1
)

REM ---------------------------------------------------------------
REM  Ringkasan
REM ---------------------------------------------------------------
echo.
echo ================================================================
if !FAILED! EQU 0 (
  echo   SEMUA OK - sedia untuk run.
  echo   Seterusnya:  tests\run_and_report.bat
  echo ================================================================
  echo.
  endlocal
  exit /b 0
) else (
  echo   !FAILED! ISU DIJUMPAI - betulkan dahulu sebelum run.
  echo   Baca mesej [GAGAL] di atas untuk langkah pembetulan.
  echo ================================================================
  echo.
  endlocal
  exit /b 1
)

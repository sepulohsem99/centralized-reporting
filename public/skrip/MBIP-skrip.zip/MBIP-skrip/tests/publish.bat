@echo off
REM ===================================================================
REM  MBIP v3 - PUBLISH
REM
REM  Commit + push laporan terkini ke GitHub. Cloudflare Pages akan auto-deploy
REM  dalam ~30 saat selepas push, dan team boleh lihat di URL live.
REM
REM  Guna:  tests\publish.bat
REM
REM  Setup sekali sahaja diperlukan sebelum ini boleh jalan -- lihat
REM  SETUP-CLOUDFLARE.md.
REM ===================================================================
setlocal enabledelayedexpansion
cd /d "%~dp0\.."

where git >nul 2>&1
if errorlevel 1 (
  echo [GAGAL] git tidak dijumpai dalam PATH.
  echo         Pasang Git: https://git-scm.com/download/win
  endlocal
  exit /b 1
)

if not exist ".git" (
  echo [GAGAL] Folder ini belum jadi repo git.
  echo         Ikut langkah dalam SETUP-CLOUDFLARE.md dahulu.
  endlocal
  exit /b 1
)

REM --- Ambil nombor keputusan terkini untuk mesej commit ---
set SUMMARY=run
for /f "delims=" %%s in ('python -c "import json;d=json.load(open(r'reports/results.json'));s=d.get('summary',{});print('%%s | P:%%s F:%%s S:%%s' %% (d.get('tester','?'), s.get('PASSED',0), s.get('FAILED',0)+s.get('ERROR',0), s.get('SKIPPED',0)))" 2^>nul') do set SUMMARY=%%s

echo.
echo ================================================================
echo   PUBLISH LAPORAN
echo ================================================================
echo   %SUMMARY%
echo.

git add -A
git diff --cached --quiet
if not errorlevel 1 (
  echo [INFO]  Tiada perubahan untuk di-commit - laporan sedia terkini.
  endlocal
  exit /b 0
)

git commit -m "Laporan: %SUMMARY%"
if errorlevel 1 (
  echo [GAGAL] git commit gagal. Baca mesej di atas.
  endlocal
  exit /b 1
)

echo.
echo [INFO]  Menghantar ke GitHub...
git push
if errorlevel 1 (
  echo.
  echo [GAGAL] git push gagal.
  echo         Kemungkinan: belum login, atau tiada akses tulis ke repo.
  echo         Lihat SETUP-CLOUDFLARE.md bahagian "Masalah push".
  endlocal
  exit /b 1
)

echo.
echo ================================================================
echo   SIAP. Cloudflare Pages akan deploy dalam ~30 saat.
echo   Refresh URL live untuk lihat laporan terkini.
echo ================================================================
echo.
endlocal
exit /b 0

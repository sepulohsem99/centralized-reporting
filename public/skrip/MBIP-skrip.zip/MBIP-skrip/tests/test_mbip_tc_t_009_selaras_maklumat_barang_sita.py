"""
MBIP-TC-T-009 — Selaras Maklumat Barang Sita.

Sheet MBIP-TC-T-009: "Verify if data of Maklumat Barang Sita saved sucessfully" -- sync the information.
Expected result (C11): System should displays a confirmation message.

The actual work happens ONCE in the session-scoped pelarasan_results
fixture (a single pass through the Menu Selaras popup, before login);
this test asserts its own item's recorded verdict so each of the nine
T-00x cases reports individually.
"""


def test_mbip_tc_t_009_selaras_maklumat_barang_sita(pelarasan_results):
    ok, msg = pelarasan_results["MBIP-TC-T-009"]
    assert ok, "MBIP-TC-T-009 Selaras Maklumat Barang Sita failed: " + msg

"""
MBIP-TC-S-001 — Daftar Sitaan.

Sheet MBIP-TC-S-001: "Verify that a 'Daftar Sitaan' can be created and
saved sucessfully with all required information". Test Data (C9): KEDAI
PERABOT / ABC123456 / lesen 123456 (pesalah), JALAN GANGSA 2 / TAMAN SRI
PUTRI (kesalahan), 1 HARI, KOMPAUN PELBAGAI -> UUK PERLESENAN TRED ... ->
(UUK 3) - MENJALANKAN PERNIAGAAN TANPA LESEN MPJBT., RM500, Barang-barang
MEJA 2 UNIT + KERUSI 4 UNIT — see testdata/excel_data.py.

The tester's manual round FAILED this TC (record stuck at STATUS HANTAR
M / STATUS A) — history, not an oracle; this run decides fresh. The
Pesalah tab layout is recon-confirmed; the Barang section is recon-first
(non-fatal if not found, see pages/sitaan_page.py).
"""

from testdata.excel_data import TC_DATA


def test_mbip_tc_s_001_daftar_sitaan(home_reset, pages, created_records,
                                     artifacts):
    data = TC_DATA["MBIP-TC-S-001"]

    pages.home.open_daftar_kompaun()
    pages.sitaan.select_jenis_sitaan()

    pages.sitaan.fill_pesalah_tab_lesen(data)
    pages.sitaan.click_seterusnya_from_pesalah()

    pages.sitaan.fill_kompaun_tab(data)
    pages.sitaan.fill_kompaun_code_fields(data)

    # Sheet step 4: "List out seized items and upload photo".
    pages.sitaan.fill_barang_items(data["barang"])

    print("\n  [S-001] Attempting to take photos...")
    try:
        pages.sitaan.take_photos(count=3)
    except Exception as e:
        print(f"  [S-001] WARNING: camera handling failed ({e}) -- "
              f"continuing without photos")

    pages.sitaan.click_seterusnya_from_kompaun()

    pages.sitaan.fill_penerima_tab(data)
    pages.sitaan.click_menyerahkan()
    pages.sitaan.confirm_and_submit()

    assert pages.sitaan.is_submission_successful_trafik(), \
        "FAIL: Daftar Sitaan submission was not successful"
    # Store the NUMBER, not a flag (see N-001). ABSENT=create failed,
    # ""=create ok but number unread (own bug), number=good.
    _no = pages.sitaan.last_record_number
    if _no:
        created_records["S"] = _no
    else:
        created_records["S"] = ""
        print("  [S-001] WARNING: create berjaya tetapi nombor rekod TIDAK "
              "terbaca -- kunci = '' (bug tersendiri, bukan kegagalan create)")
    artifacts("MBIP-TC-S-001", no_kompaun=_no)
    print("  [S-001] Daftar Sitaan submitted successfully")

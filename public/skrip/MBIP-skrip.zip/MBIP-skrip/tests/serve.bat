@echo off
REM ===================================================================
REM  MBIP v3 - PRATONTON LAPORAN (server tempatan)
REM
REM  Hidangkan folder public\ di http://localhost:8080 dan buka browser.
REM  Ini menguji laporan PERSIS macam mana hosting akan hidangkannya --
REM  termasuk pautan muat turun zip dan butang "Salin" dalam Panduan,
REM  yang kedua-duanya tak boleh diuji dengan dwi-klik fail HTML.
REM
REM  Guna:  tests\serve.bat
REM         tests\serve.bat 9000     (port lain)
REM
REM  Tekan Ctrl+C untuk berhenti.
REM ===================================================================
setlocal
cd /d "%~dp0\.."

if not exist "public\index.html" (
  echo.
  echo [GAGAL] public\index.html belum wujud.
  echo         Jana dahulu dengan:  python reports\generate_report.py
  echo.
  endlocal
  exit /b 1
)

python reports\serve.py %1

endlocal

"""
MBIP-TC-NK-001 — Notis ke Kompaun > Kompaun.

Sheet MBIP-TC-NK-001: "Verify that recipient is marked as Kompaun" —
select a notice, issue a Kompaun with an amount; expected: kompaun
issued successfully and a new No Kompaun generated. C9 cites the
tester's notice (IPA01N260619002, environment-specific); v3 uses the
first notice pulled by ID msc. The tester's manual round FAILED this
(kod kompaun mismatch after conversion) — history, not an oracle.

Flow recon'd live: notice row -> popup (KOMPAUN/PATUH) -> KOMPAUN ->
"NOTIS TO KOMPAUN FORM" -> amount + submission ladder (recon-first,
dumps at each unknown).
"""

from testdata.excel_data import TC_DATA


def test_mbip_tc_nk_001_notis_ke_kompaun_kompaun(home_reset, pages):
    data = TC_DATA["MBIP-TC-NK-001"]

    pages.home.open_notis_kompaun()
    assert pages.notis_kompaun.is_notis_kompaun_screen_displayed(), \
        "FAIL: Notis Kompaun screen not displayed"
    pages.notis_kompaun.tarik_notis(
        id_penguatkuasa=data["id_penguatkuasa"])

    no_notis = pages.notis_kompaun.open_notice_popup(index=0)
    print(f"  [NK-001] Issuing Kompaun for notice: {no_notis}")

    assert pages.notis_kompaun.kompaun_action(data["amaun"]), \
        ("FAIL: NOTIS TO KOMPAUN FORM did not close after the submission "
         "ladder (see ui_dumps/nk001_*.xml)")
    print("  [NK-001] Notis ke Kompaun (Kompaun) completed — PASS")

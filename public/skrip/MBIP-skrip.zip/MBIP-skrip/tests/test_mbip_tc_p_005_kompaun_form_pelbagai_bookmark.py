"""
MBIP-TC-P-005 — Kompaun Form Pelbagai - Bookmark.

Sheet MBIP-TC-P-005 (its C3 cell mislabels itself N-005): fill the Kompaun section, tap the book icon, name the
bookmark, SIMPAN; reopen the Pilihan Kegemaran list, select it, and
verify the fields repopulate. Kompaun-code combo per C9 (see
testdata/excel_data.py). Bookmark name is not specified in the sheet; a
distinct v3 value is used. The form is abandoned afterwards (no
submission) -- the next test's home recovery cleans up.
"""

from testdata.excel_data import TC_DATA


def test_mbip_tc_p_005_kompaun_form_pelbagai_bookmark(home_reset, pages):
    data = TC_DATA["MBIP-TC-P-005"]
    pesalah = TC_DATA["MBIP-TC-P-001"]

    pages.home.open_daftar_kompaun()
    pages.daftar_kompaun.select_jenis_kompaun("Kompaun Pelbagai")
    assert pages.daftar_kompaun.is_daftar_kompaun_screen_displayed(), \
        "FAIL: Daftar Kompaun (Pelbagai) screen not displayed"
    # Draft-aware entry: this app SAVES a form draft across
    # reopenings (confirmed live: "MAKLUMAT PESALAH TELAH DI
    # SIMPAN") -- the form can reopen directly on the Kompaun/
    # Notis tab with the Pesalah placeholders gone.
    # EXACT-case locator -- the Pesalah tab has an ALL-CAPS
    # "MAKLUMAT JALAN" field that a case-insensitive check matches too
    # (bit us live); only the Kompaun/Notis tab renders Title Case.
    kompaun_tab = ("-android uiautomator",
                   'new UiSelector().text("Maklumat Jalan")')
    if pages.daftar_kompaun.is_element_present(kompaun_tab, timeout=4):
        print("  [P-005] Form reopened on the Kompaun/Notis "
              "tab (saved draft) -- skipping Pesalah stage")
    else:
        pages.daftar_kompaun.fill_pesalah_tab(pesalah)
        pages.daftar_kompaun.click_seterusnya_from_pesalah()

    pilih1 = ("-android uiautomator",
              'new UiSelector().text("PILIH KOMPAUN")')
    if (not pages.daftar_kompaun.is_element_present(pilih1, timeout=4)
            and pages.daftar_kompaun.is_text_visible(
                data["kesalahan_kompaun"][:28], timeout=2)):
        print("  [P-005] Kompaun codes already selected "
              "(saved draft) -- skipping selection")
    else:
        pages.daftar_kompaun.fill_kompaun_code_fields(data)

    pages.bookmark.open_bookmark_popup()
    pages.bookmark.save_bookmark(data["bookmark_name"])
    pages.bookmark.select_bookmark(data["bookmark_name"])
    pages.bookmark.verify_fields_repopulated(
        [data["kod_akta"][:28], data["kesalahan_kompaun"][:28]])

"""
Pelarasan (Menu Selaras) page — Page Object Model.

New in v2: this whole "Menu Selaras" sequence runs unconditionally BEFORE
login every time (not just as a license-mismatch fallback like the older
handle_license_mismatch() in login_page.py). Confirmed via user's manual
walkthrough + screenshot of the actual popup, not assumption.

Flow (from hamburger icon on the login screen):
    1. Tap hamburger -> "MENU SELARAS" popup appears listing all items
       below, in order:
         TETAPAN ALAMAT IP
         TETAPAN PELBAGAI
         SELARAS PENGGUNA APPS
         SELARAS MAKLUMAT ALAMAT
         SELARAS MAKLUMAT KOMPAUN
         SELARAS MAKLUMAT JENIS KENDERAAN
         SELARAS MAKLUMAT WARNA
         SELARAS MAKLUMAT PELESEN   <- SKIPPED, per explicit instruction
         SELARAS MAKLUMAT BARANG SITA
         TETAPAN SKRIN UTAMA        <- not part of this flow
         SEMAK KEMASKINI VERSI TERKINI  <- not part of this flow
    2. TETAPAN ALAMAT IP: fill internal/external IP, Simpan -> back to
       the Menu Selaras popup.
    3. TETAPAN PELBAGAI: fill "Lesen Aplikasi" (the real on-screen label
       -- NOT "Device ID", which was only ever an assumption in the
       original login_page.py flow and never actually confirmed), Simpan
       -> "Lesen sama" popup -> OK.
    4. Each "SELARAS ..." menu item: tap it, wait for its own confirmation
       popup (each with a distinct message -- matched via textContains on
       a distinguishing substring, not a full exact string, since these
       were given from memory rather than a screenshot of each one), tap
       OK if a dismiss step is needed, return to the Menu Selaras popup.
    5. Close the Menu Selaras popup -> proceed to normal login.

ASSUMPTIONS needing live verification (same honest flagging style as the
rest of this project -- these are best guesses from the description, not
confirmed on-device):
    - Exact confirmation popup wording per Selaras item (matched loosely
      via textContains on a key phrase, not the full sentence).
    - Whether "SELARAS PENGGUNA APPS" needs an explicit OK tap or
      auto-dismisses (the user's step list didn't mention one for this
      item specifically, unlike all the others -- handled as
      "OK if present, non-fatal if not").
    - The exact mechanism to "close popup" at the end (tries a close
      icon first, falls back to tapping outside).
"""

from appium.webdriver.common.appiumby import AppiumBy
from selenium.common.exceptions import TimeoutException
from pages.base_page import BasePage


class PelarasanPage(BasePage):
    """Menu Selaras (sync/settings) screen — runs before every login."""

    # ---- Menu Selaras popup items (confirmed via screenshot, ALL CAPS) ----
    MENU_TETAPAN_ALAMAT_IP = (AppiumBy.ANDROID_UIAUTOMATOR,
                              'new UiSelector().text("TETAPAN ALAMAT IP")')
    MENU_TETAPAN_PELBAGAI = (AppiumBy.ANDROID_UIAUTOMATOR,
                             'new UiSelector().text("TETAPAN PELBAGAI")')
    MENU_SELARAS_PENGGUNA_APPS = (AppiumBy.ANDROID_UIAUTOMATOR,
                                  'new UiSelector().text("SELARAS PENGGUNA APPS")')
    MENU_SELARAS_MAKLUMAT_ALAMAT = (AppiumBy.ANDROID_UIAUTOMATOR,
                                    'new UiSelector().text("SELARAS MAKLUMAT ALAMAT")')
    MENU_SELARAS_MAKLUMAT_KOMPAUN = (AppiumBy.ANDROID_UIAUTOMATOR,
                                     'new UiSelector().text("SELARAS MAKLUMAT KOMPAUN")')
    MENU_SELARAS_JENIS_KENDERAAN = (AppiumBy.ANDROID_UIAUTOMATOR,
                                    'new UiSelector().text("SELARAS MAKLUMAT JENIS KENDERAAN")')
    MENU_SELARAS_MAKLUMAT_WARNA = (AppiumBy.ANDROID_UIAUTOMATOR,
                                   'new UiSelector().text("SELARAS MAKLUMAT WARNA")')
    # SELARAS MAKLUMAT PELESEN: locator kept for completeness (confirmed
    # via live recon dump recon_pelesen_60s.xml, desc + text both match),
    # but the item is intentionally NEVER tapped -- T-008 is skipped per
    # explicit user instruction, same as v2. Its sync saves 52,317
    # records (~an hour of device time).
    MENU_SELARAS_PELESEN = (AppiumBy.ANDROID_UIAUTOMATOR,
                            'new UiSelector().text("SELARAS MAKLUMAT PELESEN")')
    MENU_SELARAS_BARANG_SITA = (AppiumBy.ANDROID_UIAUTOMATOR,
                                'new UiSelector().text("SELARAS MAKLUMAT BARANG SITA")')

    # ---- Tetapan Alamat IP sub-screen ----
    FIELD_INTERNAL_IP_LABEL = "INTERNAL IP ADDRESS"
    FIELD_EXTERNAL_IP_LABEL = "EXTERNAL IP ADDRESS"
    # text("Simpan") (Title Case) was an unverified guess and never
    # matched on a live run -- this app consistently renders button
    # labels upper-case ("HANTAR", "SEMAK", "MENYERAHKAN"...), and some
    # buttons expose the label only via content-desc (e.g. SEMAK on
    # Senarai). Matched case-insensitively on both attributes instead;
    # see _click_simpan().
    SIMPAN_LOCATORS = [
        (AppiumBy.ANDROID_UIAUTOMATOR,
         'new UiSelector().textMatches("(?i)\\s*simpan\\s*")'),
        (AppiumBy.ANDROID_UIAUTOMATOR,
         'new UiSelector().descriptionMatches("(?i)\\s*simpan\\s*")'),
    ]

    # ---- Tetapan Pelbagai sub-screen ----
    # Real label confirmed by user directly -- "Lesen Aplikasi", not the
    # "Device ID" guess used in the older login_page.py fallback flow.
    FIELD_LESEN_APLIKASI_LABEL = "Lesen Aplikasi"
    # >>> FORENSIK 2026-08-24 (tools/debug_tetapan_pelbagai.py, run CEO):
    # Tetapan Pelbagai ialah MODAL di atas skrin login, jadi EditText
    # instance(0)/(1) dalam hierarchy = NAMA PENGGUNA / KATA LALUAN login
    # di BELAKANG modal — tier-3 lama menaip lesen ke field login (taipan
    # tidak melekat pun), dan field lesen sebenar tidak pernah disentuh ->
    # server sentiasa jawab 'LESEN TIDAK SAMA.' walaupun taipan manual
    # lulus. Field lesen sebenar = EditText PERTAMA selepas TextView
    # 'LESEN APLIKASI:'. XPath 'following::' TIDAK boleh digunakan — ia crash enjin
    # XPath2 UiAutomator2 (ClassCastException di FollowingAxis, disahkan
    # live 2026-08-24) — jadi field dicari secara GEOMETRI: EditText
    # paling hampir di bawah label (lihat _cari_medan_lesen). <<<
    LABEL_LESEN = (AppiumBy.ANDROID_UIAUTOMATOR,
                   'new UiSelector().textContains("LESEN APLIKASI")')
    POPUP_LESEN_SAMA = (AppiumBy.ANDROID_UIAUTOMATOR,
                        'new UiSelector().textContains("Lesen sama")')

    # ---- Per-item confirmation popups (loosely matched, see module
    # docstring -- these are the key distinguishing phrases, not full
    # exact strings) ----
    POPUP_PENGGUNA_APPS_OK = (AppiumBy.ANDROID_UIAUTOMATOR,
                              'new UiSelector().textContains("Selaras Pengguna Apps")')
    POPUP_MAKLUMAT_ALAMAT_OK = (AppiumBy.ANDROID_UIAUTOMATOR,
                                'new UiSelector().textContains("Data Alamat")')
    POPUP_MAKLUMAT_KOMPAUN_OK = (AppiumBy.ANDROID_UIAUTOMATOR,
                                 'new UiSelector().textContains("Data Kompaun")')
    POPUP_JENIS_KENDERAAN_OK = (AppiumBy.ANDROID_UIAUTOMATOR,
                                'new UiSelector().textContains("Jenis Kenderaan")')
    POPUP_MAKLUMAT_WARNA_OK = (AppiumBy.ANDROID_UIAUTOMATOR,
                               'new UiSelector().textContains("Maklumat Warna")')
    POPUP_BARANG_SITA_OK = (AppiumBy.ANDROID_UIAUTOMATOR,
                            'new UiSelector().textContains("Barang Sita")')

    # ========================================================================
    # Sub-flows
    # ========================================================================

    # Login screen title -- used to verify/restore the flow's starting
    # point (same locator as login_page.APP_TITLE).
    LOGIN_SCREEN_TITLE = (AppiumBy.ANDROID_UIAUTOMATOR,
                          'new UiSelector().text("APLIKASI KOMPAUN e-PBT")')

    def ensure_on_login_screen(self):
        """Guarantee the flow starts from the login screen.

        Confirmed via live runs 2->3: with no_reset=True the app resumes
        exactly where the previous session died (the RN activity resumes
        its existing task rather than restarting), so a run that failed
        on e.g. the Tetapan Alamat IP sub-screen leaves the NEXT run
        starting there too -- the hamburger tap then can't open the Menu
        Selaras popup and the whole flow collapses at the first menu
        item. If the login title isn't visible, force a clean cold start
        (terminate + activate keeps app data, unlike a reinstall).
        """
        # Checking the title alone is NOT enough: a previous run that
        # got past login leaves the app logged-in on the home screen,
        # whose app bar can carry the same title -- the hamburger then
        # opens the home menu instead of Menu Selaras and the whole
        # flow dies at the first menu item (observed live in the run
        # after a logged-in run). Require the home grid to be absent too.
        on_login = self.is_element_present(self.LOGIN_SCREEN_TITLE, timeout=5)
        logged_in = self.is_element_present(self.HOME_SCREEN_INDICATOR,
                                            timeout=2)
        if on_login and not logged_in:
            print("  [PELARASAN] On login screen — good starting point")
            return
        from config import APP_PACKAGE
        print("  [PELARASAN] NOT on a clean login screen (leftover state "
              "from a previous run, possibly still logged in) -- "
              "force-relaunching the app...")
        import time
        self.driver.terminate_app(APP_PACKAGE)
        time.sleep(1)
        self.driver.activate_app(APP_PACKAGE)
        assert self.is_element_present(self.LOGIN_SCREEN_TITLE, timeout=30), \
            "FAIL: Login screen not reached even after force-relaunching app"
        print("  [PELARASAN] App relaunched — login screen reached")

    def open_menu_selaras(self):
        """Tap the hamburger icon to open the Menu Selaras popup.

        Verifies the popup actually opened (first menu item visible)
        and re-taps once if not -- confirmed via live run 1 that a
        'successful' el.click() on this app's custom Pressables can
        silently no-op, leaving the flow to die on the next locator
        with no hint that the tap was the real culprit.
        """
        print("  [PELARASAN] Opening Menu Selaras (hamburger icon)...")
        self.wait_and_tap(self.HAMBURGER)
        if self.is_element_present(self.MENU_TETAPAN_ALAMAT_IP, timeout=5):
            return
        print("  [PELARASAN] Menu Selaras popup didn't open -- re-tapping "
              "hamburger...")
        self.wait_and_tap(self.HAMBURGER)
        assert self.is_element_present(self.MENU_TETAPAN_ALAMAT_IP,
                                       timeout=10), \
            "FAIL: Menu Selaras popup did not open after tapping hamburger"

    def _click_simpan(self):
        """Click the Simpan button on the Tetapan sub-screens.

        Tries each SIMPAN_LOCATORS candidate with a short bounded check
        (NOT find_clickable, whose keyboard/scroll fallback loops would
        burn ~60s per wrong candidate), hiding the keyboard first since
        Simpan sits right after the typed fields. Uses tap_element (raw
        coordinate tap) rather than el.click() -- this app's custom
        Pressables have repeatedly been confirmed to silently no-op on
        the accessibility ACTION_CLICK that click() sends.

        On total failure, dumps the page source next to the test run so
        the real locator can be read straight from the dump instead of
        another round of guessing.
        """
        self._hide_keyboard_if_shown()
        import time
        time.sleep(0.5)

        for attempt in range(2):
            for loc in self.SIMPAN_LOCATORS:
                if self.is_element_present(loc, timeout=5):
                    el = self.find_element(loc, timeout=5)
                    self.tap_element(el)
                    return
            # Candidates not on screen -- maybe below the fold; scroll
            # once and retry the full candidate list.
            if attempt == 0:
                self._scroll_down()

        dump_path = "debug_simpan_page_source.xml"
        try:
            with open(dump_path, "w", encoding="utf-8") as f:
                f.write(self.driver.page_source)
            print(f"  [PELARASAN] DEBUG: Simpan not found -- page source "
                  f"dumped to {dump_path}")
        except Exception:
            pass
        raise TimeoutException(
            "Simpan button not found by any locator (case-insensitive "
            "text/description match); see debug_simpan_page_source.xml "
            "for the actual screen hierarchy")

    def _tetapan_screen_open(self, timeout=5):
        """A Tetapan sub-screen is identifiable by its Simpan button --
        neither the login screen nor the Menu Selaras popup has one."""
        for loc in self.SIMPAN_LOCATORS:
            if self.is_element_present(loc, timeout=timeout):
                return True
        return False

    def _open_tetapan_item(self, menu_locator, item_name):
        """Tap a Tetapan menu item and verify its sub-screen actually
        opened, re-tapping once if not (same silent-no-op-click
        protection as open_menu_selaras)."""
        print(f"  [PELARASAN] Opening {item_name}...")
        try:
            self.wait_and_tap(menu_locator)
        except TimeoutException:
            # The Menu Selaras popup can vanish between its open-check
            # and this tap (observed live). Reopen it and retry once.
            print(f"  [PELARASAN] {item_name} menu item not reachable -- "
                  f"reopening Menu Selaras and retrying...")
            self.open_menu_selaras()
            self.wait_and_tap(menu_locator)
        if self._tetapan_screen_open(timeout=5):
            return
        print(f"  [PELARASAN] {item_name} screen didn't open -- "
              f"re-tapping...")
        self.wait_and_tap(menu_locator)
        assert self._tetapan_screen_open(timeout=10), \
            f"FAIL: {item_name} screen did not open after tapping its menu item"

    def set_tetapan_alamat_ip(self, internal_ip, external_ip):
        """TETAPAN ALAMAT IP: fill internal + external IP, Simpan."""
        self._open_tetapan_item(self.MENU_TETAPAN_ALAMAT_IP,
                                "Tetapan Alamat IP")

        # use_mobile_type=True -- confirmed via live run: plain send_keys()
        # on this field throws "invalid element state", the same failure
        # mode already documented on fill_field_by_label for numeric/
        # masked inputs (e.g. an IP address field validating as you type).
        #
        # fill_field_by_label_or_instance, not fill_field_by_label --
        # confirmed via live run: once a run has saved these fields
        # (no_reset=True keeps them), the placeholder text this app uses
        # as the field "label" is gone for good, so the plain label
        # lookup times out on every run after the first successful save.
        # Instance indices: internal is the screen's 1st EditText,
        # external the 2nd.
        print(f"  [PELARASAN] Setting internal IP: {internal_ip}")
        self.fill_field_by_label_or_instance(
            self.FIELD_INTERNAL_IP_LABEL, internal_ip, instance=0,
            use_mobile_type=True)

        print(f"  [PELARASAN] Setting external IP: {external_ip}")
        self.fill_field_by_label_or_instance(
            self.FIELD_EXTERNAL_IP_LABEL, external_ip, instance=1,
            use_mobile_type=True)

        print("  [PELARASAN] Clicking Simpan...")
        self._click_simpan()
        print("  [PELARASAN] Tetapan Alamat IP saved — PASS")

    def _cari_medan_lesen(self):
        """Cari EditText Lesen Aplikasi secara GEOMETRI (tanpa XPath).

        >>> 2026-08-24: XPath 'following::' crash enjin XPath2
        UiAutomator2 (ClassCastException, disahkan live). Kaedah ini:
        cari label 'LESEN APLIKASI', pilih EditText yang bermula pada
        atau di bawah label dan PALING HAMPIR dengannya. Dump forensik:
        field lesen y=1122; field login di belakang modal y=1339/1519 —
        jarak menang dengan margin besar, dan kalau susunan berubah,
        anchor tetap label itu sendiri. <<<
        """
        label = self.find_element(self.LABEL_LESEN, timeout=10)
        ly = label.rect["y"]
        calon = []
        for et in self.driver.find_elements(
                AppiumBy.CLASS_NAME, "android.widget.EditText"):
            try:
                jarak = et.rect["y"] - ly
            except Exception:                                # noqa: BLE001
                continue
            if jarak >= -20:            # pada baris label atau di bawahnya
                calon.append((jarak, et))
        assert calon, ("FAIL: tiada EditText ditemui berhampiran label "
                       "'LESEN APLIKASI' pada modal Tetapan Pelbagai")
        calon.sort(key=lambda t: t[0])
        return calon[0][1]

    def _isi_lesen_aplikasi(self, lesen):
        """Isi field Lesen Aplikasi dengan TEPAT dan SAHKAN baca-balik.

        >>> DIBINA 2026-08-24 selepas forensik debug_tetapan_pelbagai:
        ganti fill_field_by_label_or_instance yang tier-3-nya menaip ke
        field login di belakang modal (lihat nota LABEL_LESEN/_cari_medan_lesen).
        Aliran: cari field ikut label 'LESEN APLIKASI:' -> click ->
        clear() + _force_clear (clear() senyap gagal pada RN input) ->
        mobile:type -> baca balik; retry 3x. Baca-balik yang tidak sama
        dengan sasaran = AssertionError SEBELUM Simpan ditekan — supaya
        kegagalan taip tidak disamar sebagai penolakan server. <<<
        """
        lesen = str(lesen)
        el = self._cari_medan_lesen()
        for cubaan in range(1, 4):
            el.click()
            try:
                el.clear()
            except Exception:                                # noqa: BLE001
                pass
            sisa = self._safe_text(el)
            if sisa and sisa.strip() and sisa.strip() != lesen:
                self._force_clear(el)
            self.driver.execute_script("mobile: type", {"text": lesen})
            got = self._safe_text(el)
            if got is not None and got.strip() == lesen:
                print(f"  [PELARASAN] Lesen Aplikasi disahkan dalam field: "
                      f"{got!r}")
                return el
            print(f"  [PELARASAN] baca-balik lesen {got!r} != sasaran "
                  f"(cubaan {cubaan}/3) -- force-clear dan taip semula...")
            try:
                el = self._cari_medan_lesen()
            except Exception:                                # noqa: BLE001
                pass
        raise AssertionError(
            f"FAIL: field Lesen Aplikasi tidak dapat diisi dengan {lesen!r} "
            f"selepas 3 cubaan (baca-balik terakhir: "
            f"{self._safe_text(el)!r}) — isu TAIP, bukan jawapan server")

    def set_tetapan_pelbagai(self, lesen_aplikasi):
        """TETAPAN PELBAGAI: fill Lesen Aplikasi, Simpan, confirm 'Lesen
        sama' popup, tap OK."""
        self._open_tetapan_item(self.MENU_TETAPAN_PELBAGAI,
                                "Tetapan Pelbagai")

        # use_mobile_type=True preemptively -- same numeric/masked-input
        # "invalid element state" issue just confirmed on the IP fields
        # above is likely here too, since this is also a numeric
        # (IMEI-like) value.
        #
        # fill_field_by_label_or_instance -- same saved-value-erases-
        # placeholder issue as the IP fields (see set_tetapan_alamat_ip).
        # instance=0 is an ASSUMPTION that Lesen Aplikasi is the first
        # EditText on Tetapan Pelbagai (only tier-3 fallback relies on
        # it; tiers 1/2 match by placeholder/value and are index-free).
        print(f"  [PELARASAN] Setting Lesen Aplikasi: {lesen_aplikasi}")
        # 2026-08-24: _isi_lesen_aplikasi menggantikan
        # fill_field_by_label_or_instance — tier-3 lama menaip ke field
        # login di belakang modal (lihat LABEL_LESEN/_cari_medan_lesen).
        self._isi_lesen_aplikasi(lesen_aplikasi)

        print("  [PELARASAN] Clicking Simpan...")
        self._click_simpan()

        print("  [PELARASAN] Waiting for 'Lesen sama' popup...")
        assert self.is_element_present(self.POPUP_LESEN_SAMA, timeout=10), \
            "FAIL: 'Lesen sama' popup did not appear (license mismatch)"
        print("  [PELARASAN] Popup visible — PASS — clicking OK...")
        self.wait_and_click(self.BUTTON_OK)
        print("  [PELARASAN] Tetapan Pelbagai saved — PASS")

    def set_tetapan_pelbagai_dengan_alternatif(self, lesen_utama,
                                               alternatif=()):
        """Set Lesen Aplikasi dengan FALLBACK automatik.

        >>> DITAMBAH 2026-08-21 — senarai lesen dari CEO. <<<
        Lesen staging mungkin berbeza dari production. CEO membekalkan
        4 calon gantian. Cuba lesen utama dahulu; kalau popup 'Lesen
        sama' TIDAK muncul (server tolak / dialog lain keluar), salir
        alert (mesejnya dilog sebagai bukti), isi calon seterusnya pada
        skrin yang sama, Simpan semula. Lesen yang DITERIMA direkod.
        Gagal kesemuanya = AssertionError menyenaraikan semua yang
        dicuba."""
        senarai = [lesen_utama] + [a for a in alternatif
                                   if a and a != lesen_utama]
        self._open_tetapan_item(self.MENU_TETAPAN_PELBAGAI,
                                "Tetapan Pelbagai")
        dicuba = []
        for i, lesen in enumerate(senarai, 1):
            print(f"  [PELARASAN] Lesen percubaan {i}/{len(senarai)}: "
                  f"...{str(lesen)[-4:]}")
            # 2026-08-24: _isi_lesen_aplikasi — lihat LABEL_LESEN/_cari_medan_lesen.
            self._isi_lesen_aplikasi(lesen)
            self._click_simpan()
            if self.is_element_present(self.POPUP_LESEN_SAMA, timeout=10):
                print(f"  [PELARASAN] 'Lesen sama' — lesen DITERIMA: "
                      f"{lesen}")
                self.wait_and_click(self.BUTTON_OK)
                print("  [PELARASAN] Tetapan Pelbagai saved — PASS")
                return lesen
            # tolak: log dialog sebenar (bukti), salir, cuba seterusnya
            teks = self.dismiss_native_alerts(first_timeout=5,
                                              context=f"lesen-{i}",
                                              kumpul=True)
            dicuba.append((lesen, (teks or ["(tiada dialog)"])[0]))
            print(f"  [PELARASAN] lesen ...{str(lesen)[-4:]} DITOLAK — "
                  f"respons: {(teks or ['tiada dialog'])[0][:60]}")
        raise AssertionError(
            "FAIL: SEMUA lesen ditolak oleh server. Dicuba: "
            + "; ".join(f"...{str(l)[-4:]} -> {r[:40]}"
                        for l, r in dicuba))

    # v3: the on-screen save-progress line rendered inside the Menu
    # Selaras popup while a sync writes records locally -- confirmed via
    # live recon dump (ui_dumps/recon_pelesen_60s.xml): "SEDANG
    # MENYIMPAN REKOD 618 DARI 52317 (1%)". The Pelesen dataset is huge
    # (52k records), so its save can run for the better part of an hour
    # with no alert until the very end.
    PROGRESS_SAVING = (AppiumBy.ANDROID_UIAUTOMATOR,
                       'new UiSelector().textContains("SEDANG MENYIMPAN")')

    def _read_progress(self):
        try:
            els = self.driver.find_elements(*self.PROGRESS_SAVING)
            if els:
                return els[0].text
        except Exception:
            pass
        return None

    def _run_selaras_item(self, menu_locator, success_popup_locator,
                          item_name, click_ok=True, timeout=30):
        """Generic runner for the one-tap "Selaras Maklumat X" items.

        Confirmed via live page-source dump (debug_menu_selaras_close
        .xml): these confirmations are native AlertDialogs that arrive
        asynchronously; wait for ANY native alert, log its message, and
        dismiss everything queued. success_popup_locator/click_ok kept
        for signature compatibility but not load-bearing.

        v3 hardening, both confirmed via run 1 + live recon:
        - VERIFIED TAP: the menu-item tap can silently no-op (Pengguna
          Apps alerted in 1s on recon but never within 30s on the run
          where its tap no-oped). Evidence the item actually started =
          its result alert OR the SEDANG MENYIMPAN progress line within
          a few seconds; re-tap up to 3 times otherwise.
        - PROGRESS-AWARE WAIT: while the SEDANG MENYIMPAN line keeps
          changing, the deadline keeps extending (the Pelesen save runs
          ~an hour for 52k records). A stall (same text for 5 minutes)
          gives up; progress is logged every ~30s.
        """
        import time
        print(f"  [PELARASAN] Tapping {item_name}...")
        self.wait_and_tap(menu_locator)

        started = False
        for attempt in range(3):
            if self.is_element_present(self.NATIVE_ALERT_OK, timeout=4) or \
               self.is_element_present(self.PROGRESS_SAVING, timeout=2):
                started = True
                break
            print(f"  [PELARASAN] No visible reaction to the {item_name} "
                  f"tap (attempt {attempt + 1}/3) -- re-tapping...")
            try:
                self.wait_and_tap(menu_locator)
            except Exception:
                break
        if not started:
            print(f"  [PELARASAN] WARNING: no start evidence for "
                  f"{item_name} -- waiting for a result anyway")

        print(f"  [PELARASAN] Waiting for {item_name} result popup...")
        from config import IMPLICIT_WAIT
        # implicit wait off during the poll loop -- with it on, every
        # absent-element probe costs the full implicit wait, turning a
        # long sync's poll loop into mostly dead time.
        self.driver.implicitly_wait(0)
        try:
            deadline = time.monotonic() + timeout
            last_prog = None
            last_change = time.monotonic()
            last_log = 0.0
            while time.monotonic() < deadline:
                if self.is_element_present(self.NATIVE_ALERT_OK, timeout=3):
                    teks = self.dismiss_native_alerts(first_timeout=2,
                                                      context=item_name,
                                                      kumpul=True)
                    # >>> 2026-08-21: KLASIFIKASI TEKS, bukan sekadar
                    # "alert ditutup = PASS". Run staging membuktikan
                    # popup "GAGAL MENDAPATKAN ATAU MENYIMPAN DATA."
                    # dikira PASS — lulus palsu. Perkataan GAGAL/RALAT/
                    # TIDAK BERJAYA dalam alert = sync GAGAL.
                    gagal = any(("GAGAL" in (t or "").upper()
                                 or "RALAT" in (t or "").upper()
                                 or "TIDAK BERJAYA" in (t or "").upper())
                                for t in (teks or []))
                    if gagal:
                        print(f"  [PELARASAN] {item_name} — alert "
                              f"menyatakan GAGAL: "
                              f"{(teks or ['?'])[0][:60]} — FAIL")
                        raise AssertionError(
                            f"{item_name}: server menjawab "
                            f"{(teks or ['?'])[0][:80]!r}")
                    print(f"  [PELARASAN] {item_name} confirmed and "
                          f"dismissed — PASS")
                    return True
                prog = self._read_progress()
                now = time.monotonic()
                if prog:
                    if prog != last_prog:
                        last_prog, last_change = prog, now
                        deadline = max(deadline, now + 120)
                        if now - last_log > 30:
                            print(f"  [PELARASAN] {item_name} in progress: "
                                  f"{prog}")
                            last_log = now
                    elif now - last_change > 300:
                        print(f"  [PELARASAN] {item_name} progress stalled "
                              f"at {prog!r} for 5 minutes -- giving up")
                        return False
                time.sleep(2)
        finally:
            self.driver.implicitly_wait(IMPLICIT_WAIT)

        print(f"  [PELARASAN] WARNING: no result popup for {item_name} "
              f"within the wait window -- continuing (a late alert will "
              f"be drained before the popup is closed)")
        return False

    def selaras_pengguna_apps(self):
        """SELARAS PENGGUNA APPS. Per the manual flow, no explicit OK tap
        was described for this one (unlike all the others) -- try OK if
        present, don't fail if it isn't."""
        return self._run_selaras_item(
            self.MENU_SELARAS_PENGGUNA_APPS, self.POPUP_PENGGUNA_APPS_OK,
            "Selaras Pengguna Apps", click_ok=True,
        )

    def selaras_maklumat_alamat(self):
        # timeout=60: confirmed via live run that the Alamat sync is the
        # slow one (its alert hadn't shown after 30s while every other
        # item confirmed within seconds -- address dataset is large).
        return self._run_selaras_item(
            self.MENU_SELARAS_MAKLUMAT_ALAMAT, self.POPUP_MAKLUMAT_ALAMAT_OK,
            "Selaras Maklumat Alamat", click_ok=True, timeout=60,
        )

    def selaras_maklumat_kompaun(self):
        return self._run_selaras_item(
            self.MENU_SELARAS_MAKLUMAT_KOMPAUN, self.POPUP_MAKLUMAT_KOMPAUN_OK,
            "Selaras Maklumat Kompaun", click_ok=True,
        )

    def selaras_jenis_kenderaan(self):
        return self._run_selaras_item(
            self.MENU_SELARAS_JENIS_KENDERAAN, self.POPUP_JENIS_KENDERAAN_OK,
            "Selaras Maklumat Jenis Kenderaan", click_ok=True,
        )

    def selaras_maklumat_warna(self):
        return self._run_selaras_item(
            self.MENU_SELARAS_MAKLUMAT_WARNA, self.POPUP_MAKLUMAT_WARNA_OK,
            "Selaras Maklumat Warna", click_ok=True,
        )

    def selaras_maklumat_pelesen(self):
        """SELARAS MAKLUMAT PELESEN (MBIP-TC-T-008). NOT called by the
        suite -- the TC is skipped per explicit user instruction (same
        as v2); kept only in case that decision is ever reversed."""
        popup = (AppiumBy.ANDROID_UIAUTOMATOR,
                 'new UiSelector().textContains("Pelesen")')
        return self._run_selaras_item(
            self.MENU_SELARAS_PELESEN, popup,
            "Selaras Maklumat Pelesen", click_ok=True, timeout=60,
        )

    def selaras_barang_sita(self):
        return self._run_selaras_item(
            self.MENU_SELARAS_BARANG_SITA, self.POPUP_BARANG_SITA_OK,
            "Selaras Maklumat Barang Sita", click_ok=True,
        )

    # ------------------------------------------------------------------
    # v3 Phase 2: T-010 / T-011 (menu items confirmed via live recon
    # dump recon_pelesen_60s.xml -- both render text AND content-desc;
    # note SEMAK KEMASKINI VERSI TERKINI carries a trailing space, so
    # textContains is used)
    # ------------------------------------------------------------------

    # textContains, not exact text() -- T-011's SEMAK item (textContains)
    # resolves every run while the exact-text version of this one timed
    # out twice (probable stray whitespace, same as SEMAK's trailing
    # space); "TETAPAN SKRIN" is unique in the menu.
    MENU_TETAPAN_SKRIN_UTAMA = (AppiumBy.ANDROID_UIAUTOMATOR,
                                'new UiSelector().textContains("TETAPAN SKRIN")')
    MENU_SEMAK_KEMASKINI = (AppiumBy.ANDROID_UIAUTOMATOR,
                            'new UiSelector().textContains("SEMAK KEMASKINI")')

    def _dump(self, name):
        try:
            import os
            os.makedirs("ui_dumps", exist_ok=True)
            path = os.path.join("ui_dumps", name)
            with open(path, "w", encoding="utf-8") as f:
                f.write(self.driver.page_source)
            print(f"  [PELARASAN] DEBUG: page source dumped to {path}")
            return path
        except Exception:
            return "(dump failed)"

    def tetapan_skrin_utama(self):
        """MBIP-TC-T-010: verify the Tetapan Skrin Utama item opens its
        selection screen. If the screen has a Simpan, it is saved as-is
        (no selection changed -- the sheet only requires that it can be
        selected/opened). Recon-first: page source dumped every run."""
        import time
        print("  [PELARASAN] Opening Tetapan Skrin Utama...")
        # A LATE Selaras result alert can still be covering the menu at
        # this point (confirmed via shakedown run: the Alamat sync's
        # alert landed during T-010 and made every menu item 'not
        # found' for its whole wait) -- drain first.
        self.dismiss_native_alerts(first_timeout=3,
                                   context="pre-Tetapan Skrin Utama")
        # Confirmed via live dump: on a FRESH menu open the whole item
        # list (including this item) is in the tree and nothing is
        # scrollable -- yet reopening the menu right after the
        # pelarasan fixture's open/use/close cycle can render the
        # popup with this item missing (transient RN re-render; the
        # item was 'not present' for a full 15s while a fresh open
        # shows it instantly). Self-heal by closing and reopening the
        # menu until the item renders.
        for round_ in range(3):
            if self.is_element_present(self.MENU_TETAPAN_SKRIN_UTAMA,
                                       timeout=5):
                break
            print(f"  [PELARASAN] Skrin Utama item not rendered "
                  f"(round {round_ + 1}/3) -- closing and reopening the "
                  f"menu...")
            self._dump(f"t010_menu_missing_item_{round_}.xml")
            self.close_menu_selaras()
            self.dismiss_native_alerts(first_timeout=2,
                                       context="menu reopen")
            self.open_menu_selaras()
        # Confirmed via live dump (t010_skrin_utama_never_opened.xml,
        # ironically): tapping the item opens a nested "PILIHAN SKRIN
        # UTAMA" popup ON TOP of the still-rendered menu list, offering
        # DEFAULT / NOTIS AMARAN / KOMPAUN PELBAGAI / KOMPAUN TRAFIK /
        # KOMPAUN LESEN. That popup's title is the open-evidence.
        opened = (AppiumBy.ANDROID_UIAUTOMATOR,
                  'new UiSelector().text("PILIHAN SKRIN UTAMA")')
        for attempt in range(3):
            self.wait_and_tap(self.MENU_TETAPAN_SKRIN_UTAMA)
            time.sleep(1.5)
            if self.is_element_present(opened, timeout=4):
                break
            print(f"  [PELARASAN] Pilihan Skrin Utama popup didn't open "
                  f"(attempt {attempt + 1}/3) -- re-tapping...")
        else:
            self._dump("t010_skrin_utama_never_opened.xml")
            return False
        self._dump("t010_skrin_utama.xml")
        print("  [PELARASAN] Pilihan Skrin Utama popup opened — PASS")

        # Select DEFAULT -- proves selectability (the sheet's whole
        # requirement) without changing the app's landing screen.
        default_opt = (AppiumBy.ANDROID_UIAUTOMATOR,
                       'new UiSelector().text("DEFAULT")')
        for attempt in range(3):
            if not self.is_element_present(opened, timeout=2):
                print("  [PELARASAN] Selection registered (popup closed) "
                      "— PASS")
                break
            try:
                el = self.find_element(default_opt, timeout=3)
                self.tap_element(el)
                time.sleep(1.5)
            except TimeoutException:
                break
        self.dismiss_native_alerts(first_timeout=3,
                                   context="Tetapan Skrin Utama")
        if self.is_element_present(opened, timeout=2):
            print("  [PELARASAN] popup still open after selecting "
                  "DEFAULT -- closing it")
            if not self.close_popup_by_icon(timeout=2):
                self.press_back()
            time.sleep(1)
        return True

    # 2026-08-24 (cubaan 2): textContains ADALAH case-sensitive dan teks
    # modal sebenar bercampur huruf ("Aplikasi ini telah dikemaskini...")
    # — run live kedua membeku lagi kerana padanan huruf besar gagal.
    # textMatches (?i) memadankan tanpa mengira huruf; '.*dikemaskini.*'
    # tetap TIDAK memadankan menu 'SEMAK KEMASKINI' (tiada awalan di-).
    # 2026-08-24 (cubaan 3 — DISAHKAN dari login_missing_*.xml): teks
    # sebenar ialah 'APLIKASI IN TELAH DIKEMAS KINI' — "DIKEMAS KINI"
    # BERSPASI. Regex kini menerima dengan/tanpa spasi; menu 'SEMAK
    # KEMASKINI' tetap tak padan (tiada awalan DI-).
    MODAL_DIKEMASKINI = (AppiumBy.ANDROID_UIAUTOMATOR,
                         'new UiSelector().textMatches('
                         '"(?i).*dikemas\\s*kini.*")')

    def _tutup_modal_dikemaskini(self):
        """Tutup RN modal 'APLIKASI TELAH DIKEMASKINI' (lihat nota dalam
        semak_kemaskini). Cuba butang OK/TUTUP (text & desc) dengan
        tap_element, fallback Back; sahkan modal hilang."""
        import time
        butang = [
            (AppiumBy.ANDROID_UIAUTOMATOR,
             'new UiSelector().textMatches("(?i)\\s*ok\\s*")'),
            (AppiumBy.ANDROID_UIAUTOMATOR,
             'new UiSelector().descriptionMatches("(?i)\\s*ok\\s*")'),
            (AppiumBy.ANDROID_UIAUTOMATOR,
             'new UiSelector().textMatches("(?i)\\s*tutup\\s*")'),
            (AppiumBy.ANDROID_UIAUTOMATOR,
             'new UiSelector().descriptionMatches("(?i)\\s*tutup\\s*")'),
        ]
        for cubaan in range(3):
            ditekan = False
            for loc in butang:
                if self.is_element_present(loc, timeout=2):
                    try:
                        self.tap_element(self.find_element(loc, timeout=3))
                        ditekan = True
                        break
                    except Exception:                        # noqa: BLE001
                        continue
            if not ditekan:
                print("  [PELARASAN] tiada butang OK/TUTUP kelihatan -- "
                      "menekan Back untuk tutup modal")
                try:
                    self.driver.back()
                except Exception:                            # noqa: BLE001
                    pass
            time.sleep(1)
            if not self.is_element_present(self.MODAL_DIKEMASKINI,
                                           timeout=2):
                print("  [PELARASAN] Semak Kemaskini completed (modal "
                      "'TELAH DIKEMASKINI' ditutup) — PASS")
                return True
            print(f"  [PELARASAN] modal masih ada (cubaan "
                  f"{cubaan + 1}/3)...")
        print("  [PELARASAN] WARNING: modal 'TELAH DIKEMASKINI' tidak "
              "dapat ditutup selepas 3 cubaan")
        return False

    def semak_kemaskini(self):
        """MBIP-TC-T-011: run the update check; choose KEMUDIAN so the
        app does NOT actually update. A 'no update available' style
        alert also counts as a completed check (the sheet's expected
        result is 'update check process complete without error')."""
        import time
        print("  [PELARASAN] Opening Semak Kemaskini...")
        # Same late-alert protection as tetapan_skrin_utama.
        self.dismiss_native_alerts(first_timeout=3,
                                   context="pre-Semak Kemaskini")
        # Same transient-render self-heal as tetapan_skrin_utama: the
        # reopened menu popup can render without its bottom items
        # (flaked once on T-011 in the final Phase-3 run after passing
        # 3 runs the same day).
        for round_ in range(3):
            if self.is_element_present(self.MENU_SEMAK_KEMASKINI,
                                       timeout=5):
                break
            print(f"  [PELARASAN] Semak Kemaskini item not rendered "
                  f"(round {round_ + 1}/3) -- closing and reopening the "
                  f"menu...")
            self.close_menu_selaras()
            self.dismiss_native_alerts(first_timeout=2,
                                       context="menu reopen")
            self.open_menu_selaras()
        self.wait_and_tap(self.MENU_SEMAK_KEMASKINI)

        kemudian = (AppiumBy.ANDROID_UIAUTOMATOR,
                    'new UiSelector().textMatches("(?i)\\s*kemudian\\s*")')
        kemudian_desc = (AppiumBy.ANDROID_UIAUTOMATOR,
                         'new UiSelector().descriptionMatches('
                         '"(?i)\\s*kemudian\\s*")')
        deadline = time.monotonic() + 45
        while time.monotonic() < deadline:
            # >>> 2026-08-24: build 2.1.17 memaparkan RN modal 'APLIKASI
            # TELAH DIKEMASKINI' (versi sudah terkini) dan BUKAN native
            # alert — dismiss_native_alerts tidak nampak dia, modal kekal
            # menutup skrin login dan mematikan T-012 + kesemua 36 TC
            # login ('Login screen not displayed'). Disahkan live oleh
            # CEO: run beku pada popup ini sehingga OK ditekan manual.
            # Kesan teks DIKEMASKINI (menu item = 'SEMAK KEMASKINI...',
            # tiada awalan DI-, jadi tak salah padan) dan tutup. <<<
            if self.is_element_present(self.MODAL_DIKEMASKINI, timeout=2):
                self._dump("t011_modal_dikemaskini.xml")
                print("  [PELARASAN] Modal 'APLIKASI TELAH DIKEMASKINI' "
                      "visible -- menutup modal (versi sudah terkini = "
                      "semakan selesai)")
                return self._tutup_modal_dikemaskini()
            for loc in (kemudian, kemudian_desc):
                if self.is_element_present(loc, timeout=2):
                    self._dump("t011_semak_kemaskini.xml")
                    print("  [PELARASAN] Update prompt visible -- "
                          "choosing KEMUDIAN (do not update)")
                    for attempt in range(3):
                        el = self.find_element(loc, timeout=3)
                        self.tap_element(el)
                        time.sleep(1)
                        if not self.is_element_present(loc, timeout=2):
                            print("  [PELARASAN] Semak Kemaskini "
                                  "completed (KEMUDIAN) — PASS")
                            return True
                    print("  [PELARASAN] WARNING: KEMUDIAN tap never "
                          "registered")
                    return False
            if self.is_element_present(self.NATIVE_ALERT_OK, timeout=2):
                # e.g. "app is up to date" -- check completed.
                self.dismiss_native_alerts(first_timeout=2,
                                           context="Semak Kemaskini")
                print("  [PELARASAN] Semak Kemaskini completed (native "
                      "alert) — PASS")
                return True
            time.sleep(1)
        self._dump("t011_no_update_prompt.xml")
        print("  [PELARASAN] WARNING: no update prompt or alert within "
              "45s")
        return False

    def close_menu_selaras(self):
        """Close the Menu Selaras popup and VERIFY the login screen is
        showing again.

        Confirmed via live run: the old close-icon-then-tap-outside
        guess reported success while the login screen never actually
        came back, so Phase 1 died on 'Login screen not displayed' one
        step later. Now tries close icon -> device Back (RN modals
        close on Back), verifies the login title after each, and as a
        last resort force-relaunches the app -- safe here, since
        everything Pelarasan did (IP/lesen settings, selaras syncs) is
        persisted app data. Dumps the page source before relaunching so
        the popup's real close control can be identified offline.
        """
        print("  [PELARASAN] Closing Menu Selaras popup...")
        import time
        # Result alerts can keep arriving DURING the close attempts
        # themselves (confirmed via two live dumps: a duplicate 'DATA
        # JENIS KENDERAAN SAVED SUCCESSFULLY!' alert appeared after the
        # pre-close drain had already come up empty), and they're
        # non-cancelable RN alerts -- the device Back button does NOT
        # dismiss them (second dump: the alert survived a Back press
        # untouched). So alternate drain-and-close a few times rather
        # than draining once up front.
        for attempt in range(3):
            self.dismiss_native_alerts(first_timeout=2,
                                       context="late sync alert")
            if self.is_element_present(self.LOGIN_SCREEN_TITLE, timeout=3):
                print("  [PELARASAN] Login screen visible — popup closed")
                return
            if self.close_popup_by_icon(timeout=2):
                time.sleep(1)
                continue
            print("  [PELARASAN] No close icon -- pressing device Back...")
            self.press_back()
            time.sleep(1)

        self.dismiss_native_alerts(first_timeout=2, context="late sync alert")
        if self.is_element_present(self.LOGIN_SCREEN_TITLE, timeout=3):
            print("  [PELARASAN] Login screen visible — popup closed")
            return

        dump_path = "debug_menu_selaras_close.xml"
        try:
            with open(dump_path, "w", encoding="utf-8") as f:
                f.write(self.driver.page_source)
            print(f"  [PELARASAN] DEBUG: login screen still not visible -- "
                  f"page source dumped to {dump_path}")
        except Exception:
            pass

        print("  [PELARASAN] Falling back to app relaunch (Pelarasan "
              "settings are persisted, nothing is lost)...")
        self.ensure_on_login_screen()

    # ========================================================================
    # Full orchestration
    # ========================================================================

    def run_full_pelarasan(self, internal_ip, external_ip, lesen_aplikasi):
        """Run the entire Menu Selaras sequence in order, exactly as
        specified: IP setup -> Lesen Aplikasi -> the 5 Selaras Maklumat
        items (skipping Pelesen) -> close popup. Meant to run once,
        unconditionally, before every login attempt.
        """
        print("\n" + "=" * 60)
        print("  PELARASAN (MENU SELARAS)")
        print("=" * 60)

        self.ensure_on_login_screen()
        self.open_menu_selaras()
        self.set_tetapan_alamat_ip(internal_ip, external_ip)
        self.set_tetapan_pelbagai(lesen_aplikasi)
        self.selaras_pengguna_apps()
        self.selaras_maklumat_alamat()
        self.selaras_maklumat_kompaun()
        self.selaras_jenis_kenderaan()
        self.selaras_maklumat_warna()
        # SELARAS MAKLUMAT PELESEN skipped intentionally.
        self.selaras_barang_sita()
        self.close_menu_selaras()

        print("  [PELARASAN] Full Pelarasan sequence complete — PASS\n")

"""
Hantar (Send/Sync) page — Page Object Model.
Flow: Tab Belum Hantar (default) -> Hantar Data -> Hantar Gambar -> popup ->
click Semua -> wait -> switch to Tab Data Ralat -> Hantar Semula.

This is a separate menu from Senarai (previously incorrectly merged into
senarai_page.py).
"""

from appium.webdriver.common.appiumby import AppiumBy
from pages.base_page import BasePage


class HantarPage(BasePage):
    """Hantar screen — data/photo sync and error retry."""

    # ---- Tabs ----
    # Confirmed via live UI dump: this app renders all tab/button labels
    # in upper case regardless of how they're worded in specs/manuals
    # (same convention as the "KOMPAUN PELBAGAI" dropdown options in
    # daftar_kompaun_page.py) -- the Title Case text() matches here
    # never matched anything, which is why is_hantar_screen_displayed()
    # always reported the Hantar screen as not displayed even when it
    # very clearly was. The "BELUM HANTAR" tab's real text/content-desc
    # also has a trailing space ("BELUM HANTAR "), so textContains is
    # used instead of an exact text() match to not depend on that.
    TAB_BELUM_HANTAR = (AppiumBy.ANDROID_UIAUTOMATOR,
                        'new UiSelector().textContains("BELUM HANTAR")')
    TAB_DATA_RALAT = (AppiumBy.ANDROID_UIAUTOMATOR,
                      'new UiSelector().textContains("DATA RALAT")')

    # ---- Belum Hantar tab ----
    BUTTON_HANTAR_DATA = (AppiumBy.ANDROID_UIAUTOMATOR,
                          'new UiSelector().textContains("HANTAR DATA")')
    BUTTON_HANTAR_GAMBAR = (AppiumBy.ANDROID_UIAUTOMATOR,
                            'new UiSelector().textContains("HANTAR GAMBAR")')
    # Popup that appears after clicking Hantar Gambar
    BUTTON_SEMUA = (AppiumBy.ANDROID_UIAUTOMATOR,
                    'new UiSelector().textContains("SEMUA")')

    # ---- Data Ralat tab ----
    BUTTON_HANTAR_SEMULA = (AppiumBy.ANDROID_UIAUTOMATOR,
                            'new UiSelector().textContains("HANTAR SEMULA")')

    # Error popup that can appear after Hantar Data/Hantar Gambar if the
    # upload partially fails (e.g. "RALAT / BEBERAPA GAMBAR TIDAK
    # BERJAYA DI MUATNAIK." -- confirmed via live UI dump). It sits on
    # top of the Data Ralat tab and blocks it from being tapped if left
    # open, so it must be dismissed before navigating further. Matched
    # on "TIDAK BERJAYA" (not "RALAT" alone, which is also a substring
    # of the "DATA RALAT" tab label and would give a false positive).
    POPUP_RALAT = (AppiumBy.ANDROID_UIAUTOMATOR,
                   'new UiSelector().textContains("TIDAK BERJAYA")')

    # ========================================================================
    # Actions
    # ========================================================================

    def is_hantar_screen_displayed(self):
        """Verify we are on the Hantar screen (Belum Hantar tab default)."""
        return self.is_element_present(self.TAB_BELUM_HANTAR, timeout=10)

    def _wait_and_dismiss_result(self, context, wait_timeout=30):
        """Wait for the native result alert a send operation ends with
        and dismiss it (plus anything queued behind it).

        The old version only looked for the RALAT ("TIDAK BERJAYA")
        variant with a 3s sleep -- confirmed via live run that a
        SUCCESS alert (same native "BERJAYA" dialog the Selaras syncs
        use, per debug_menu_selaras_close.xml) appears after the upload
        finishes, which can be well past 3s, and then sits there
        blocking the DATA RALAT tab from ever being tapped."""
        found = self.dismiss_native_alerts(first_timeout=wait_timeout,
                                           context=context)
        if not found:
            print(f"  [HANTAR] No result popup for {context} within "
                  f"{wait_timeout}s -- continuing")

    def click_hantar_data(self):
        """Click Hantar Data and wait for it to finish."""
        print("  [HANTAR] Clicking Hantar Data...")
        self.wait_and_click(self.BUTTON_HANTAR_DATA)
        self._wait_and_dismiss_result("Hantar Data", wait_timeout=30)
        print("  [HANTAR] Hantar Data done")

    def click_hantar_gambar(self):
        """Click Hantar Gambar, then confirm via the 'Semua' popup option."""
        print("  [HANTAR] Clicking Hantar Gambar...")
        self.wait_and_click(self.BUTTON_HANTAR_GAMBAR)

        print("  [HANTAR] Confirming with 'Semua'...")
        if self.is_element_present(self.BUTTON_SEMUA, timeout=5):
            self.wait_and_click(self.BUTTON_SEMUA)

        # Photo uploads are the slow path -- allow more time.
        self._wait_and_dismiss_result("Hantar Gambar", wait_timeout=60)
        print("  [HANTAR] Hantar Gambar done")

    def switch_to_data_ralat_tab(self):
        """Switch to the Data Ralat tab."""
        print("  [HANTAR] Switching to Data Ralat tab...")
        self.wait_and_click(self.TAB_DATA_RALAT)

    def click_hantar_semula(self):
        """Click Hantar Semula and wait for it to finish, if the button
        is present (there may be nothing to resend)."""
        if self.is_element_present(self.BUTTON_HANTAR_SEMULA, timeout=5):
            print("  [HANTAR] Clicking Hantar Semula...")
            self.wait_and_click(self.BUTTON_HANTAR_SEMULA)
            import time
            time.sleep(3)
            print("  [HANTAR] Hantar Semula done")
        else:
            print("  [HANTAR] No error records to resend — skipping")

    def sync_all(self):
        """Complete full sync flow: Hantar Data -> Hantar Gambar ->
        Data Ralat tab -> Hantar Semula."""
        self.click_hantar_data()
        self.click_hantar_gambar()
        self.switch_to_data_ralat_tab()
        self.click_hantar_semula()
        return True

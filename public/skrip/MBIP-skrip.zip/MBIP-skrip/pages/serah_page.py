"""
Serah / Lampiran (clip-icon attachment) page — Page Object Model.

Covers MBIP-TC-N/P/K/L/S-003: "Verify if that the user can attach
picture (lampiran)" — "Click on the clip icon for take picture";
expected: the application accepts the attachment.

FLOW — fully confirmed live (2026-07-17, location provided by the user,
locators from ui_dumps/lampiran_popup_bottom.xml, acceptance evidence
from ui_dumps/lampiran_cam_postsnap.*):
  1. Senarai -> tap the jenis' record row -> "KEMASKINI DATA" popup.
  2. The LAMPIRAN row sits below the popup's fold (past KADAR/GAMBAR/
     MAKLUMAT PENGUATKUASA/TANDA TANGAN, just above the pinned
     KEMASKINI/CETAK buttons). This popup's content is TextViews, so
     PLAIN swipes scroll it (unlike the EditText-heavy notice popup).
  3. The paperclip is a clickable ViewGroup with content-desc U+F0C6
     right after the "LAMPIRAN" label.
  4. Tapping it opens the in-app camera (FLASH OFF indicator, shutter
     U+F1BA — same component as the form camera) which AUTO-CLOSES
     after the capture settles; no tick-confirm exists in this variant
     (U+F1FD is absent; U+F353 is the gallery option).
  5. Acceptance evidence: back on the popup, the LAMPIRAN row gains a
     photo-thumbnail — a new clickable ViewGroup following the
     LAMPIRAN label (count increases by one).
"""

from appium.webdriver.common.appiumby import AppiumBy
from selenium.common.exceptions import TimeoutException
from pages.base_page import BasePage
from pages.daftar_kompaun_page import DaftarKompaunPage

_CLIP = ""


class SerahPage(BasePage):
    """Record-popup lampiran (clip-icon) attachment flow."""

    LAMPIRAN_LABEL = (AppiumBy.ANDROID_UIAUTOMATOR,
                      'new UiSelector().text("LAMPIRAN")')
    CLIP_ICON = (AppiumBy.ACCESSIBILITY_ID, _CLIP)
    POPUP_TITLE = (AppiumBy.ANDROID_UIAUTOMATOR,
                   'new UiSelector().text("KEMASKINI DATA")')
    POPUP_X = (AppiumBy.ACCESSIBILITY_ID, "✕")
    # Photo thumbnails are clickable ViewGroups with an EMPTY
    # content-desc (all other popup clickables carry one: X, the clip
    # glyph, KEMASKINI, CETAK). NOTE: XPath `following::` queries return
    # nothing on this driver (confirmed live), hence UiSelector.
    DESCLESS_CLICKABLES = (AppiumBy.ANDROID_UIAUTOMATOR,
                           'new UiSelector().className('
                           '"android.view.ViewGroup").clickable(true)'
                           '.descriptionMatches("^$")')

    def _dump(self, name):
        try:
            import os
            os.makedirs("ui_dumps", exist_ok=True)
            path = os.path.join("ui_dumps", name)
            with open(path, "w", encoding="utf-8") as f:
                f.write(self.driver.page_source)
            print(f"  [SERAH] DEBUG: page source dumped to {path}")
            return path
        except Exception:
            return "(dump failed)"

    def _scroll_popup_to_lampiran(self):
        """Swipe the popup content down until the LAMPIRAN row is FULLY
        in view (content rows are TextViews, so plain swipes are not
        swallowed). Merely present is not enough -- confirmed live: the
        label can first appear as a ~26px sliver at the viewport edge,
        making every row measurement useless."""
        import time

        def _fully_visible():
            try:
                r = self.driver.find_element(*self.LAMPIRAN_LABEL).rect
                return r["height"] >= 60 and (r["y"] + r["height"]) < 2020
            except Exception:
                return False

        for _ in range(12):
            if self.is_element_present(self.LAMPIRAN_LABEL, timeout=2) \
                    and _fully_visible():
                return True
            try:
                self.driver.swipe(540, 1750, 540, 600, 700)
                time.sleep(0.8)
            except Exception:
                break
        return self.is_element_present(self.LAMPIRAN_LABEL, timeout=2)

    def _lampiran_state(self):
        """(thumbnails-in-row count, LAMPIRAN label height). Thumbnails
        = descless clickable ViewGroups whose bounds vertically
        intersect the LAMPIRAN label's row -- a GLOBAL descless count is
        viewport-dependent (the record's GAMBAR photo box drifts in and
        out of the rendered tree between measurements; bit us live).
        Both metrics grow when an attachment lands (label 76->390px on
        the first photo; +1 thumbnail every time)."""
        height = 0
        y0 = y1 = None
        try:
            r = self.driver.find_element(*self.LAMPIRAN_LABEL).rect
            height = r["height"]
            y0, y1 = r["y"], r["y"] + r["height"]
        except Exception:
            pass
        count = 0
        thumb_hash = None
        if y0 is not None:
            try:
                for el in self.driver.find_elements(
                        *self.DESCLESS_CLICKABLES):
                    er = el.rect
                    ey0, ey1 = er["y"], er["y"] + er["height"]
                    if ey0 < y1 and ey1 > y0:  # vertical overlap
                        count += 1
                        if thumb_hash is None:
                            # The row holds exactly ONE photo -- a new
                            # attachment REPLACES the previous one
                            # (confirmed live: count/height flat on an
                            # already-attached record). The thumbnail's
                            # PIXELS are the only change then.
                            try:
                                import hashlib
                                png = el.screenshot_as_base64
                                thumb_hash = hashlib.md5(
                                    png.encode()).hexdigest()
                            except Exception:
                                pass
            except Exception:
                pass
        return count, height, thumb_hash

    def attach_lampiran(self, jenis_letter):
        """On the already-open KEMASKINI DATA popup: scroll to the
        LAMPIRAN row, tap the paperclip, take a photo, and assert the
        attachment registered (thumbnail added). Closes the popup on
        success."""
        import time
        assert self.is_element_present(self.POPUP_TITLE, timeout=8), \
            "KEMASKINI DATA popup not open"

        if not self._scroll_popup_to_lampiran():
            path = self._dump(f"serah_{jenis_letter}_no_lampiran_row.xml")
            raise TimeoutException(
                f"LAMPIRAN row never rendered in the record popup; "
                f"see {path}")
        print("  [SERAH] LAMPIRAN row visible")

        before_count, before_height, before_hash = self._lampiran_state()
        print(f"  [SERAH] baseline: thumbnails={before_count}, row "
              f"height={before_height}, thumb hash={before_hash}")

        # Tap the paperclip (verified: the in-app camera must open).
        opened = False
        for attempt in range(3):
            el = self.find_element(self.CLIP_ICON, timeout=5)
            self.tap_element(el)
            time.sleep(2)
            if self.is_element_present(
                    DaftarKompaunPage.CAMERA_OPEN_INDICATOR, timeout=4):
                opened = True
                break
            print(f"  [SERAH] camera didn't open (attempt "
                  f"{attempt + 1}/3) -- re-tapping the clip...")
        if not opened:
            path = self._dump(f"serah_{jenis_letter}_camera_never_opened.xml")
            raise TimeoutException(
                f"camera never opened after tapping the paperclip; "
                f"see {path}")
        print("  [SERAH] camera open — snapping...")

        # One shutter tap; THIS camera variant auto-closes once the
        # capture settles (confirmed live: no tick-confirm exists).
        self.wait_and_click(DaftarKompaunPage.BUTTON_SNAP)
        deadline = time.monotonic() + 20
        while time.monotonic() < deadline:
            if not self.is_element_present(
                    DaftarKompaunPage.CAMERA_OPEN_INDICATOR, timeout=2):
                break
            time.sleep(1)
        else:
            # Shouldn't happen per recon; close via the camera's X as a
            # last resort so the run isn't stranded inside the camera.
            print("  [SERAH] WARNING: camera did not auto-close -- "
                  "closing via its X")
            try:
                x = (AppiumBy.ANDROID_UIAUTOMATOR,
                     'new UiSelector().description("✕")')
                el = self.find_element(x, timeout=4)
                self.tap_element(el)
            except Exception:
                self.press_back()
            time.sleep(1)
        print("  [SERAH] camera closed")

        self.dismiss_native_alerts(first_timeout=3, context="lampiran")
        time.sleep(1)

        # Acceptance: the LAMPIRAN row must have gained a thumbnail.
        assert self.is_element_present(self.POPUP_TITLE, timeout=8), \
            "record popup did not come back after the camera"
        if not self.is_element_present(self.LAMPIRAN_LABEL, timeout=3):
            self._scroll_popup_to_lampiran()
        after_count, after_height, after_hash = self._lampiran_state()
        print(f"  [SERAH] after: thumbnails={after_count}, row "
              f"height={after_height}, thumb hash={after_hash}")
        replaced = (before_hash is not None and after_hash is not None
                    and after_hash != before_hash)
        if not (after_count > before_count
                or after_height > before_height + 40
                or replaced):
            path = self._dump(f"serah_{jenis_letter}_not_registered.xml")
            raise AssertionError(
                f"attachment did not register: thumbnails "
                f"{before_count}->{after_count}, row height "
                f"{before_height}->{after_height}, thumbnail pixels "
                f"unchanged; see {path}")
        evidence = ("new thumbnail" if after_count > before_count
                    or after_height > before_height + 40
                    else "thumbnail replaced (pixels changed)")
        print(f"  [SERAH] Attachment accepted ({evidence}) — PASS")

        # Close the popup cleanly.
        try:
            el = self.find_element(self.POPUP_X, timeout=4)
            self.tap_element(el)
        except Exception:
            self.press_back()
        return True

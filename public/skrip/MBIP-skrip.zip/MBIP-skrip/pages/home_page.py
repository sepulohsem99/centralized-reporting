"""
Home / Main Menu page — Page Object Model.
Shows a grid of module buttons after login.
"""

from appium.webdriver.common.appiumby import AppiumBy
from pages.base_page import BasePage


class HomePage(BasePage):
    """Home screen (main menu grid) locators and actions."""

    # ---- Locators ----
    MODULE_NOTIS_AMARAN = (AppiumBy.ACCESSIBILITY_ID, "NOTIS AMARAN")
    MODULE_DAFTAR_KOMPAUN = (AppiumBy.ACCESSIBILITY_ID, "DAFTAR KOMPAUN")
    MODULE_NOTIS_KOMPAUN = (AppiumBy.ACCESSIBILITY_ID, "NOTIS KOMPAUN")
    MODULE_SENARAI = (AppiumBy.ACCESSIBILITY_ID, "SENARAI")
    MODULE_HANTAR = (AppiumBy.ACCESSIBILITY_ID, "HANTAR")

    MENU_ITEM_LOG_OUT = (AppiumBy.ANDROID_UIAUTOMATOR,
                         'new UiSelector().text("Log Out")')

    # ---- Actions ----

    def is_home_screen_displayed(self):
        """Verify home screen by checking for a home-grid module button.

        Confirmed via live UI dump that the hamburger icon (previously
        used here) also renders on the login screen's app bar, so it
        can't distinguish "logged in, on home" from "logged out, on
        login" -- NOTIS AMARAN only exists on the actual home grid.

        Drains native alerts before giving up: a late Selaras result
        alert (Selaras Pengguna Apps' sync in particular can finish
        minutes after its own wait timed out) can be covering the home
        grid, and while a native alert is up UiAutomator only sees the
        dialog window -- everything behind it is invisible, so the grid
        looks 'not displayed' even though login succeeded.
        """
        if self.is_element_present(self.HOME_SCREEN_INDICATOR, timeout=10):
            return True
        if self.dismiss_native_alerts(first_timeout=3,
                                      context="home-screen check"):
            return self.is_element_present(self.HOME_SCREEN_INDICATOR,
                                           timeout=10)
        return False

    # >>> 2026-09-05 00:47 (run penuh --bersih, N-002 & K-003): dump
    # clickfail_1788544046.xml BUKTI skrin masih HOME (grid modul) selepas
    # "[HOME] Opening Senarai module..." -- wait_and_click (el.click() =
    # ACTION_CLICK) silent no-op pada butang modul (kelas bug RN Pressable
    # #1 CLAUDE.md), terutamanya sejurus selepas alert printer dilayan.
    # Ujian seterusnya (ensure_records_listed) lalu mencari kalendar pada
    # skrin HOME -> gagal. Tampal: tap koordinat + SAHKAN grid HOME hilang
    # (penunjuk HOME tiada lagi) + ulang 3x -- "setiap tap kritikal mesti
    # disahkan". <<<
    def _buka_modul(self, locator, nama):
        import time
        print(f"  [HOME] Opening {nama} module...")
        # >>> Fix #21b (2026-09-05 K-002 rerun, dump clickfail_1788570286
        # .xml): selepas aliran sambung printer Bluetooth dalam app
        # ('Unable to connect device' -> connect flow), grid HOME tulen
        # (tiada modal) tetapi 3 tap berturut-turut TIDAK diproses --
        # benang JS RN sibuk/beku sementara sambungan BT. Tap seterusnya
        # dalam TC berikutnya berjaya, jadi ini soal MASA. Tunggu
        # progresif antara cubaan (sampai ~75s), selang-seli saluran tap
        # koordinat / el.click(), dan RAISE dgn dump kalau semua gagal
        # (kod lama pulang False senyap -> TC gagal di tempat lain). <<<
        from selenium.common.exceptions import TimeoutException
        jeda = (1.2, 3, 6, 10, 15, 20, 20)
        for cubaan, tunggu in enumerate(jeda):
            if cubaan == 4:
                # >>> Fix #21c (2026-09-05 P-005 rerun): selepas alert
                # 'Unable to connect device' semasa pelancaran, grid HOME
                # kekal beku >20s (7 cubaan / 75s pun gagal). Home
                # recovery conftest membuktikan RELAUNCH SEJUK + login
                # memulihkan responsif. Lakukan di sini selepas ~20s
                # menunggu, kemudian teruskan cubaan tap. <<<
                print(f"  [HOME] {nama}: grid beku ~20s (kemungkinan "
                      f"selepas alert printer) -- relaunch sejuk + login "
                      f"semula, kemudian cuba lagi")
                try:
                    from config import TEST_CREDENTIALS
                    from pages.login_page import LoginPage
                    lp = LoginPage(self.driver)
                    lp._force_relaunch_to_login()
                    lp.login(TEST_CREDENTIALS["username"],
                             TEST_CREDENTIALS["password"])
                    self.drain_printer_alert()
                except Exception as e:                       # noqa: BLE001
                    print(f"  [HOME] relaunch/login gagal "
                          f"({type(e).__name__}) -- teruskan cubaan tap")
            self.dismiss_native_alerts(first_timeout=1,
                                       context=f"buka modul {nama}")
            if cubaan % 2 == 1:
                # saluran ganti: klik aksesibiliti (ACTION_CLICK)
                try:
                    self.find_clickable(locator, timeout=10).click()
                except Exception:                            # noqa: BLE001
                    self.wait_and_tap(locator, timeout=10)
            else:
                self.wait_and_tap(locator, timeout=10)
            time.sleep(tunggu)
            # grid HOME hilang = modul terbuka (butang modul tiada lagi)
            if not self.is_element_present(locator, timeout=2):
                if cubaan:
                    print(f"  [HOME] {nama}: terbuka pada cubaan "
                          f"{cubaan + 1} (selepas tunggu {tunggu}s)")
                return True
            print(f"  [HOME] {nama}: grid HOME masih kelihatan selepas tap "
                  f"(cubaan {cubaan + 1}/{len(jeda)}) -- tunggu & tap "
                  f"semula...")
        path = self._dump_source(f"home_modul_{nama.lower().replace(' ', '_')}"
                                 f"_tak_terbuka.xml")
        raise TimeoutException(
            f"Modul {nama} tidak terbuka selepas {len(jeda)} tap (grid HOME "
            f"kekal; app mungkin beku selepas aliran printer); lihat {path}")

    def _dump_source(self, name):
        try:
            import os
            os.makedirs("ui_dumps", exist_ok=True)
            path = os.path.join("ui_dumps", name)
            with open(path, "w", encoding="utf-8") as f:
                f.write(self.driver.page_source)
            return path
        except Exception:                                    # noqa: BLE001
            return "(dump gagal)"

    def open_notis_amaran(self):
        """Tap Notis Amaran module on the home grid (verified)."""
        return self._buka_modul(self.MODULE_NOTIS_AMARAN, "Notis Amaran")

    def open_daftar_kompaun(self):
        """Tap Daftar Kompaun module on the home grid (verified)."""
        return self._buka_modul(self.MODULE_DAFTAR_KOMPAUN, "Daftar Kompaun")

    def open_notis_kompaun(self):
        """Tap Notis Kompaun module on the home grid (verified)."""
        return self._buka_modul(self.MODULE_NOTIS_KOMPAUN, "Notis Kompaun")

    def open_senarai(self):
        """Tap Senarai module on the home grid (verified)."""
        return self._buka_modul(self.MODULE_SENARAI, "Senarai")

    def open_hantar(self):
        """Tap Hantar module on the home grid (verified)."""
        return self._buka_modul(self.MODULE_HANTAR, "Hantar")

    def open_hamburger_menu(self):
        """Open the hamburger menu modal."""
        print("  [HOME] Opening hamburger menu...")
        self.wait_and_click(self.HAMBURGER)

    def log_out(self):
        """Log out via hamburger menu."""
        self.open_hamburger_menu()
        print("  [HOME] Clicking Log Out...")
        self.wait_and_click(self.MENU_ITEM_LOG_OUT)
        if self.is_element_present(self.BUTTON_YA, timeout=3):
            self.wait_and_click(self.BUTTON_YA)
        print("  [HOME] Logged out — PASS")

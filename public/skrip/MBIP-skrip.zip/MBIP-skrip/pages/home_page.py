"""
Home / Main Menu page — Page Object Model.
Shows a grid of module buttons after login.
"""

from appium.webdriver.common.appiumby import AppiumBy
from pages.base_page import BasePage


class HomePage(BasePage):
    """Home screen (main menu grid) locators and actions."""

    # ---- Locators ----
    MODULE_NOTIS_AMARAN = (AppiumBy.ACCESSIBILITY_ID, "NOTIS AMARAN")
    MODULE_DAFTAR_KOMPAUN = (AppiumBy.ACCESSIBILITY_ID, "DAFTAR KOMPAUN")
    MODULE_NOTIS_KOMPAUN = (AppiumBy.ACCESSIBILITY_ID, "NOTIS KOMPAUN")
    MODULE_SENARAI = (AppiumBy.ACCESSIBILITY_ID, "SENARAI")
    MODULE_HANTAR = (AppiumBy.ACCESSIBILITY_ID, "HANTAR")

    MENU_ITEM_LOG_OUT = (AppiumBy.ANDROID_UIAUTOMATOR,
                         'new UiSelector().text("Log Out")')

    # ---- Actions ----

    def is_home_screen_displayed(self):
        """Verify home screen by checking for a home-grid module button.

        Confirmed via live UI dump that the hamburger icon (previously
        used here) also renders on the login screen's app bar, so it
        can't distinguish "logged in, on home" from "logged out, on
        login" -- NOTIS AMARAN only exists on the actual home grid.

        Drains native alerts before giving up: a late Selaras result
        alert (Selaras Pengguna Apps' sync in particular can finish
        minutes after its own wait timed out) can be covering the home
        grid, and while a native alert is up UiAutomator only sees the
        dialog window -- everything behind it is invisible, so the grid
        looks 'not displayed' even though login succeeded.
        """
        if self.is_element_present(self.HOME_SCREEN_INDICATOR, timeout=10):
            return True
        if self.dismiss_native_alerts(first_timeout=3,
                                      context="home-screen check"):
            return self.is_element_present(self.HOME_SCREEN_INDICATOR,
                                           timeout=10)
        return False

    def open_notis_amaran(self):
        """Click Notis Amaran module on the home grid."""
        print("  [HOME] Opening Notis Amaran module...")
        self.wait_and_click(self.MODULE_NOTIS_AMARAN)

    def open_daftar_kompaun(self):
        """Click Daftar Kompaun module on the home grid."""
        print("  [HOME] Opening Daftar Kompaun module...")
        self.wait_and_click(self.MODULE_DAFTAR_KOMPAUN)

    def open_notis_kompaun(self):
        """Click Notis Kompaun module on the home grid."""
        print("  [HOME] Opening Notis Kompaun module...")
        self.wait_and_click(self.MODULE_NOTIS_KOMPAUN)

    def open_senarai(self):
        """Click Senarai module on the home grid."""
        print("  [HOME] Opening Senarai module...")
        self.wait_and_click(self.MODULE_SENARAI)

    def open_hantar(self):
        """Click Hantar module on the home grid."""
        print("  [HOME] Opening Hantar module...")
        self.wait_and_click(self.MODULE_HANTAR)

    def open_hamburger_menu(self):
        """Open the hamburger menu modal."""
        print("  [HOME] Opening hamburger menu...")
        self.wait_and_click(self.HAMBURGER)

    def log_out(self):
        """Log out via hamburger menu."""
        self.open_hamburger_menu()
        print("  [HOME] Clicking Log Out...")
        self.wait_and_click(self.MENU_ITEM_LOG_OUT)
        if self.is_element_present(self.BUTTON_YA, timeout=3):
            self.wait_and_click(self.BUTTON_YA)
        print("  [HOME] Logged out — PASS")

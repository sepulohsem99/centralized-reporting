"""
Notis Amaran (Warning Notice) page — Page Object Model.
Flow: Tab Pesalah -> Tab Notis -> Tab Penerima -> Confirmation -> Submit

Rebuilt from the user's step-by-step manual (not just live UI dumps), so
field order and autocomplete/dropdown behaviour matches the real app flow.
"""

from appium.webdriver.common.appiumby import AppiumBy
from pages.base_page import BasePage


class NotisAmaranPage(BasePage):
    """Notis Amaran screen — 3-tab form (Pesalah / Notis / Penerima)."""

    # ---- Screen title (appbar) ----
    SCREEN_TITLE = (AppiumBy.ANDROID_UIAUTOMATOR,
                    'new UiSelector().text("NOTIS AMARAN")')

    # ---- Tab identifiers ----
    TAB_PESALAH = (AppiumBy.ACCESSIBILITY_ID, "PESALAH")
    TAB_NOTIS = (AppiumBy.ACCESSIBILITY_ID, "NOTIS")
    TAB_PENERIMA = (AppiumBy.ACCESSIBILITY_ID, "PENERIMA")

    # ---- Pesalah tab field labels ----
    LABEL_NAMA_PESALAH = "NAMA PESALAH"
    LABEL_NO_KP_SSM_KERETA = "NO KP/ SSM/ NO KERETA"
    LABEL_PESALAH_JALAN = "MAKLUMAT JALAN"
    LABEL_PESALAH_TAMAN = "MAKLUMAT TAMAN"
    LABEL_PESALAH_POSKOD = "MAKLUMAT POSKOD"
    LABEL_PESALAH_BANDAR = "MAKLUMAT BANDAR"
    LABEL_PESALAH_NEGERI = "MAKLUMAT NEGERI"

    # ---- Notis tab field labels ----
    LABEL_NOTIS_JALAN = "Maklumat Jalan"
    LABEL_NOTIS_TAMAN = "Maklumat Taman"
    LABEL_NOTIS_POSKOD = "Maklumat Poskod"
    LABEL_NOTIS_BANDAR = "Maklumat Bandar"
    LABEL_NOTIS_NEGERI = "Maklumat Negeri"
    LABEL_LOKASI_KESALAHAN = "LOKASI KESALAHAN"
    LABEL_BUTIRAN_KESALAHAN = "BUTIRAN KESALAHAN"
    LABEL_TEMPOH_NOTIS = "MAKLUMAT KOMPAUN"  # on-screen label for tempoh (days)

    # ---- Kompaun code dropdowns (placeholder text shown before selection) ----
    PLACEHOLDER_PILIH_KOMPAUN = "PILIH KOMPAUN"
    PLACEHOLDER_PILIH_AKTA = "PILIH AKTA"
    PLACEHOLDER_PILIH_KESALAHAN = "PILIH KESALAHAN"

    # ---- Camera ----
    BUTTON_OPEN_CAMERA = (AppiumBy.ANDROID_UIAUTOMATOR,
                          'new UiSelector().text("OPEN CAMERA")')
    # Confirmed via live UI dump: these are icon-font glyphs, not the
    # literal words "Snap"/"Tick" -- same convention as HAMBURGER in
    # base_page.py.
    BUTTON_SNAP = (AppiumBy.ACCESSIBILITY_ID, "")
    BUTTON_TICK_CONFIRM = (AppiumBy.ACCESSIBILITY_ID, "")

    # ---- Penerima tab field labels ----
    LABEL_ARAHAN_TINDAKAN = "ARAHAN TINDAKAN"
    LABEL_NAMA_PENERIMA = "NAMA PENERIMA"
    LABEL_NO_IC_PENERIMA = "NO IC PENERIMA"
    FIELD_OPEN_SIGNATURE = (AppiumBy.ANDROID_UIAUTOMATOR,
                            'new UiSelector().text("OPEN SIGNATURE")')

    # ---- Confirmation / result popups ----
    POPUP_SIMPAN_MAKLUMAT = (AppiumBy.ANDROID_UIAUTOMATOR,
                             'new UiSelector().textContains("Simpan maklumat")')
    POPUP_CETAK_NOTIS_AMARAN = (AppiumBy.ANDROID_UIAUTOMATOR,
                                'new UiSelector().textContains("Cetak Notis Amaran")')

    # ========================================================================
    # Actions
    # ========================================================================

    def is_notis_amaran_screen_displayed(self):
        """Verify we are on the Notis Amaran screen."""
        return self.is_element_present(self.SCREEN_TITLE, timeout=10)

    # ---- Pesalah tab ----

    def fill_pesalah_tab(self, data):
        """Fill in the Pesalah tab fields.
        data must contain: nama_pesalah, no_kp_ssm_kereta, jalan,
        taman, poskod, bandar, negeri
        """
        import time
        print("\n  [NOTIS AMARAN] Filling Pesalah tab...")
        self.wait_and_click(self.TAB_PESALAH)

        fields = [
            (self.LABEL_NAMA_PESALAH, data["nama_pesalah"]),
            (self.LABEL_NO_KP_SSM_KERETA, data["no_kp_ssm_kereta"]),
            (self.LABEL_PESALAH_JALAN, data["jalan"]),
            # Taman is a live-search autocomplete field, but waiting on
            # its suggestion dropdown was a dead end -- typing a short
            # partial (e.g. "T") never renders any suggestions, so the
            # field (and poskod/bandar/negeri, meant to be auto-filled
            # from picking one) ended up stuck waiting ~20s and then
            # left blank every run. Type the full value directly
            # instead -- plain send_keys() sets the value without
            # firing the live-search, so no dropdown appears to wait
            # on or dismiss.
            (self.LABEL_PESALAH_TAMAN, data["taman"]),
            (self.LABEL_PESALAH_POSKOD, data["poskod"]),
            (self.LABEL_PESALAH_BANDAR, data["bandar"]),
            (self.LABEL_PESALAH_NEGERI, data["negeri"]),
        ]
        # Confirmed via live run: Negeri (the last field) alone took ~27s
        # to fill, ~9x every other field -- find_element wastes its full
        # 15s presence-wait before ever trying to scroll, and by the time
        # we reach Negeri the keyboard (still up from typing Bandar) has
        # pushed it out of the rendered viewport, so that dead wait
        # always happens. Scroll proactively right before it so it's
        # already rendered and the normal presence-wait succeeds fast.
        scroll_before = {self.LABEL_PESALAH_NEGERI}
        # v3: fill_field_by_label_or_instance, not fill_field_by_label --
        # this form KEEPS a pesalah draft across reopenings ("MAKLUMAT
        # PESALAH TELAH DI SIMPAN", confirmed live), so the placeholder
        # text can be gone before the run ever touches the field; the
        # instance index is the field's position among the tab's
        # EditTexts (same three-tier pattern as the Tetapan screens).
        for idx, (label, value) in enumerate(fields):
            if label in scroll_before:
                self._scroll_down()
            t0 = time.time()
            self.fill_field_by_label_or_instance(label, value, instance=idx)
            print(f"  [TIMING] '{label}' filled in {time.time() - t0:.2f}s")

        print("  [NOTIS AMARAN] Pesalah tab filled — PASS")

    def click_seterusnya_from_pesalah(self):
        """Click Seterusnya on Pesalah tab to go to Notis tab."""
        print("  [NOTIS AMARAN] Clicking Seterusnya to go to Notis tab...")
        self.wait_and_click(self.BUTTON_SETERUSNYA)

    # ---- Notis tab ----

    def fill_notis_tab(self, data):
        """Fill in the Notis tab fields.
        data must contain: notis_jalan_partial, notis_jalan_suggestion,
        notis_taman, notis_poskod, notis_bandar, notis_negeri,
        lokasi_kesalahan, butiran_kesalahan, tempoh_notis,
        keterangan_kod_kompaun, kod_akta, kesalahan_kompaun
        """
        print("\n  [NOTIS AMARAN] Filling Notis tab...")
        # TAB_NOTIS is unreliable (confirmed via live run: this screen
        # was correctly displayed, with LABEL_NOTIS_JALAN etc. all
        # present, yet the TAB_NOTIS accessibility id still wasn't found
        # -- same phantom-tab issue as TAB_PENERIMA in fill_penerima_tab
        # below). Check for a field that's actually on this screen.
        notis_jalan_locator = (
            AppiumBy.ANDROID_UIAUTOMATOR,
            f'new UiSelector().text("{self.LABEL_NOTIS_JALAN}")')
        assert self.is_element_present(notis_jalan_locator, timeout=5), \
            "Notis screen not visible after clicking Seterusnya"

        self.type_and_select_suggestion(
            self.LABEL_NOTIS_JALAN,
            data["notis_jalan_partial"],
            data["notis_jalan_suggestion"],
        )

        # The Taman/Bandar/Negeri auto-fill triggered by the Jalan
        # selection above happens asynchronously -- give it a moment to
        # land before checking those fields below, or the guard can race
        # it (StaleElementReferenceException / not-found handled there
        # either way, but this cuts how often that race fires at all).
        import time
        time.sleep(1.5)

        # Confirmed via live run: unlike the Pesalah tab, a successful tap
        # on this tab's Jalan suggestion DOES auto-fill Taman/Bandar/Negeri
        # as a side effect -- so their placeholder text is already gone by
        # the time we get here, and a plain fill_field_by_label would wait
        # out its timeout and raise. Use the _if_blank guard: fill only
        # if the placeholder is still showing (i.e. the Jalan selection
        # didn't auto-populate it), skip instantly otherwise. Poskod is
        # NOT auto-filled by the Jalan selection, so it's always filled.
        self.fill_field_by_label_if_blank(self.LABEL_NOTIS_TAMAN, data["notis_taman"])
        self.fill_field_by_label(self.LABEL_NOTIS_POSKOD, data["notis_poskod"])
        self.fill_field_by_label_if_blank(self.LABEL_NOTIS_BANDAR, data["notis_bandar"])
        self.fill_field_by_label_if_blank(self.LABEL_NOTIS_NEGERI, data["notis_negeri"])
        self.fill_field_by_label(self.LABEL_LOKASI_KESALAHAN, data["lokasi_kesalahan"])
        self.fill_field_by_label(self.LABEL_BUTIRAN_KESALAHAN, data["butiran_kesalahan"])

        # Tempoh (MAKLUMAT KOMPAUN section) — locate the real EditText
        # (hint "TEMPOH NOTIS"), NOT the section-header TextView the
        # "MAKLUMAT KOMPAUN" label matches; force-clear + set + read-back
        # with a 0-21 range assertion. See base_page._set_tempoh_verified.
        self._set_tempoh_verified(data["tempoh_notis"])

        print("  [NOTIS AMARAN] Notis tab filled — PASS")

    def fill_kompaun_code_fields(self, data):
        """Select the three kompaun code dropdowns.

        Each selection is verified via the element that only shows once
        the option list has closed again (the next tier's placeholder;
        OPEN CAMERA after the last tier) -- confirmed via live run that
        an option-row tap can silently fail to register, leaving the
        list open and the next tier's placeholder unreachable."""
        print("  [NOTIS AMARAN] Selecting kompaun code dropdowns...")
        pilih_akta = (AppiumBy.ANDROID_UIAUTOMATOR,
                      f'new UiSelector().text("{self.PLACEHOLDER_PILIH_AKTA}")')
        pilih_kesalahan = (AppiumBy.ANDROID_UIAUTOMATOR,
                           f'new UiSelector().text("{self.PLACEHOLDER_PILIH_KESALAHAN}")')
        self.select_dropdown_option_and_confirm(
            self.PLACEHOLDER_PILIH_KOMPAUN, data["keterangan_kod_kompaun"],
            confirm_locator=pilih_akta)
        self.select_dropdown_option_and_confirm(
            self.PLACEHOLDER_PILIH_AKTA, data["kod_akta"],
            confirm_locator=pilih_kesalahan)
        # CASCADE 2026-08-27: akta (Excel atau ganti) boleh jadi jalan
        # mati — tier kesalahan 'Tiada rekod' untuk semua huruf. Patah
        # balik: pilih akta baris lain, cuba kesalahan semula (2x).
        from selenium.common.exceptions import TimeoutException
        for _cuba in range(3):
            try:
                self.select_dropdown_option_and_confirm(
                    self.PLACEHOLDER_PILIH_KESALAHAN,
                    data["kesalahan_kompaun"],
                    confirm_locator=self.BUTTON_OPEN_CAMERA)
                break
            except TimeoutException as e:
                if "SENARAI-KOSONG" not in str(e) or _cuba == 2:
                    raise
                print(f"  [NOTIS AMARAN] kesalahan KOSONG di bawah akta "
                      f"semasa — cascade ke akta lain "
                      f"(cubaan {_cuba + 1}/2)")
                if not self.cuba_akta_ganti_lain(_cuba + 1):
                    raise
        print("  [NOTIS AMARAN] Kompaun code dropdowns selected — PASS")

    def take_photos(self, count=3):
        """Open the in-app camera, snap `count` photos, then confirm with
        the tick icon."""
        print(f"  [NOTIS AMARAN] Opening camera for {count} photo(s)...")
        self.wait_and_click(self.BUTTON_OPEN_CAMERA)
        import time
        time.sleep(1)

        for i in range(count):
            print(f"  [NOTIS AMARAN]   Snapping photo {i+1}/{count}")
            self.wait_and_click(self.BUTTON_SNAP)
            time.sleep(1)

        print("  [NOTIS AMARAN] Confirming photos with tick icon...")
        self.wait_and_click(self.BUTTON_TICK_CONFIRM)
        print("  [NOTIS AMARAN] Photos taken — PASS")

    def click_seterusnya_from_notis(self):
        """Click Seterusnya on Notis tab to go to Penerima tab."""
        print("  [NOTIS AMARAN] Clicking Seterusnya to go to Penerima tab...")
        self.wait_and_click(self.BUTTON_SETERUSNYA)

    # ---- Penerima tab ----

    def fill_penerima_tab(self, data):
        """Fill in the Penerima tab fields and draw signature.
        data must contain: arahan_tindakan, nama_penerima, no_ic_penerima
        """
        print("\n  [NOTIS AMARAN] Filling Penerima tab...")
        # Confirmed via live UI dump that clicking Seterusnya here pushes
        # a whole new screen ("PAPARAN PENERIMA") rather than switching a
        # same-screen tab -- there's no "PENERIMA" accessibility id on
        # it, so TAB_PENERIMA never matches. Check for a field that's
        # actually on this screen instead.
        arahan_tindakan_locator = (
            AppiumBy.ANDROID_UIAUTOMATOR,
            f'new UiSelector().text("{self.LABEL_ARAHAN_TINDAKAN}")')
        assert self.is_element_present(arahan_tindakan_locator, timeout=5), \
            "Penerima screen not visible after clicking Seterusnya"

        self.fill_field_by_label(self.LABEL_ARAHAN_TINDAKAN, data["arahan_tindakan"])

        print("  [NOTIS AMARAN] Opening signature pad...")
        self.wait_and_click(self.FIELD_OPEN_SIGNATURE)
        import time
        time.sleep(1)

        self._draw_signature()

        print("  [NOTIS AMARAN] Closing signature popup...")
        closed = self.close_popup_by_icon(timeout=3)
        if not closed:
            print("  [NOTIS AMARAN] Close icon not found, tapping outside...")
            self.driver.tap([(540, 300)])
        time.sleep(1)

        # Lihat nota penuh dalam daftar_kompaun_page._fill_penerima.
        self._fill_penerima(self.LABEL_NAMA_PENERIMA,
                            data.get("nama_penerima"), "NAMA PENERIMA",
                            "nama_penerima")
        self._fill_penerima(self.LABEL_NO_IC_PENERIMA,
                            data.get("no_ic_penerima"), "NO IC PENERIMA",
                            "no_ic_penerima")

        print("  [NOTIS AMARAN] Penerima tab filled — PASS")

    def _fill_penerima(self, label, value, nama_papar, medan):
        """Isi medan penerima; kalau nilainya penanda (BLANK_MARKER teks
        atau BLANK_MARKER_IC berangka bagi medan dalam MEDAN_BERANGKA),
        log + BACA SEMULA medan selepas taip untuk laporkan nilai SEBENAR
        yang masuk. Medan berangka (no_ic_penerima) sudah dapat penanda
        berangka dari excel_data; read-back di sini mengesahkan ia benar
        masuk (bukan senyap kosong)."""
        from testdata.excel_data import ialah_penanda, penanda_untuk
        is_marker = ialah_penanda(value)
        expected = penanda_untuk(medan) if is_marker else value
        if is_marker:
            print(f"  [NOTIS AMARAN] {nama_papar}: menaip penanda "
                  f"{expected!r} — Excel tidak membekalkan nilai")
        el = self.fill_field_by_label(label, value)
        got = self._safe_text(el)
        print(f"  [NOTIS AMARAN] {nama_papar}: medan = {got!r} selepas taip "
              f"(sepatutnya {expected!r})")
        if is_marker and self._norm(got) != self._norm(expected):
            print(f"  [NOTIS AMARAN] WARNING: {nama_papar} tidak menerima "
                  f"penanda {expected!r} — nilai sebenar {got!r}")

    def _draw_signature(self):
        """Draw a simple smiley-like signature using W3C Actions."""
        print("  [NOTIS AMARAN] Drawing signature...")
        from selenium.webdriver.common.action_chains import ActionChains
        from selenium.webdriver.common.actions import interaction
        from selenium.webdriver.common.actions.action_builder import ActionBuilder
        from selenium.webdriver.common.actions.pointer_input import PointerInput

        actions = ActionChains(self.driver)
        pointer = PointerInput(interaction.POINTER_TOUCH, "finger")
        actions.w3c_actions = ActionBuilder(self.driver, mouse=pointer)
        actions.w3c_actions.pointer_action.move_to_location(400, 1200)
        actions.w3c_actions.pointer_action.pointer_down()
        actions.w3c_actions.pointer_action.move_to_location(500, 1150)
        actions.w3c_actions.pointer_action.move_to_location(600, 1250)
        actions.w3c_actions.pointer_action.move_to_location(700, 1180)
        actions.w3c_actions.pointer_action.move_to_location(800, 1220)
        actions.w3c_actions.pointer_action.release()
        actions.perform()

    def click_menyerahkan(self):
        """Click the Menyerahkan button.

        Confirmed via live run: MENYERAHKAN sits right after the last
        typed field (NO IC PENERIMA), so the on-screen keyboard is still
        covering it at this point -- computing a raw coordinate tap from
        the element's rect() lands on the keyboard, not the button.
        Explicitly hide the keyboard first, then use tap_element (raw
        coordinate tap) rather than wait_and_click/el.click() -- same
        reasoning as the dropdown/suggestion rows elsewhere in this
        file, since this app's custom Pressables silently no-op on the
        accessibility ACTION_CLICK a plain el.click() sends.
        """
        print("  [NOTIS AMARAN] Clicking Menyerahkan...")
        try:
            if self.driver.is_keyboard_shown():
                self.driver.hide_keyboard()
                import time
                time.sleep(0.5)
        except Exception:
            pass
        el = self.find_clickable(self.BUTTON_MENYERAHKAN)
        self.tap_element(el)

    def confirm_and_submit(self):
        """Handle 'Simpan maklumat ini?' popup and click Hantar."""
        print("\n  [NOTIS AMARAN] Confirmation popup...")
        assert self.is_element_present(self.POPUP_SIMPAN_MAKLUMAT, timeout=10), \
            "Confirmation popup ('Simpan maklumat ini?') not displayed"
        print("  [NOTIS AMARAN] Confirmation popup visible — PASS")

        print("  [NOTIS AMARAN] Clicking Hantar...")
        # tap_element, not wait_and_click -- same custom-Pressable
        # no-op issue as MENYERAHKAN above.
        el = self.find_clickable(self.BUTTON_HANTAR)
        self.tap_element(el)

    def is_submission_successful(self):
        """Wait for progress bar to finish, then check for the
        'Cetak Notis Amaran?' success popup."""
        if self.is_element_present(self.POPUP_CETAK_NOTIS_AMARAN, timeout=30):
            print("  [NOTIS AMARAN] Submission successful — receipt popup visible — PASS")
            self.read_record_number()  # capture no_notis before closing
            self.close_success_popup()
            return True

        if self.is_text_visible("Berjaya", timeout=5):
            print("  [NOTIS AMARAN] Submission successful — success message visible — PASS")
            return True

        print("  [NOTIS AMARAN] WARNING: Could not confirm submission success")
        return False

    def close_success_popup(self):
        """Close the 'Cetak Notis Amaran?' popup via the red close icon."""
        print("  [NOTIS AMARAN] Closing success popup...")
        closed = self.close_popup_by_icon(timeout=3)
        if not closed:
            print("  [NOTIS AMARAN] No close icon found, pressing Back...")
            self.press_back()

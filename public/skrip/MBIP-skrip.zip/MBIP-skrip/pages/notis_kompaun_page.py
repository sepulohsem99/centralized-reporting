"""
Notis Kompaun (Compound Notice List) page — Page Object Model.
Flow: Click Tarik Notis -> enter ID Penguatkuasa -> click Tarik ->
records for that ID are displayed.

NOTE: per the real manual flow, this form has only ONE input field
(ID Penguatkuasa) — not two. A previous version of this file incorrectly
defined a second "no notis" field using the same locator as ID Penguatkuasa;
that has been removed here.
"""

from appium.webdriver.common.appiumby import AppiumBy
from selenium.common.exceptions import TimeoutException
from pages.base_page import BasePage


class NotisKompaunPage(BasePage):
    """Notis Kompaun screen — listing and Tarik Notis functionality."""

    # ---- Screen title ----
    SCREEN_TITLE = (AppiumBy.ANDROID_UIAUTOMATOR,
                    'new UiSelector().textContains("NOTIS KOMPAUN")')

    # ---- Tarik Notis button ----
    BUTTON_TARIK_NOTIS = (AppiumBy.ANDROID_UIAUTOMATOR,
                          'new UiSelector().textContains("Tarik Notis")')

    # ---- Tarik Notis popup (single field) ----
    LABEL_ID_PENGUATKUASA = "ID PENGUATKUASA"
    # Confirmed via live page-source dump: the popup is titled "TARIK
    # NOTIS TAMAT TEMPOH" and its button is 'TARIK' (upper-case, in
    # both text and content-desc) -- the original text("Tarik") guess
    # could never match. Full-string match, so this can't collide with
    # the "Tarik Notis" button that opens this popup.
    POPUP_TARIK_TITLE = (AppiumBy.ANDROID_UIAUTOMATOR,
                         'new UiSelector().textContains("TARIK NOTIS TAMAT TEMPOH")')
    TARIK_LOCATORS = [
        (AppiumBy.ANDROID_UIAUTOMATOR,
         'new UiSelector().textMatches("(?i)\\s*tarik\\s*")'),
        (AppiumBy.ANDROID_UIAUTOMATOR,
         'new UiSelector().descriptionMatches("(?i)\\s*tarik\\s*")'),
    ]

    # ========================================================================
    # Actions
    # ========================================================================

    def is_notis_kompaun_screen_displayed(self):
        """Verify we are on the Notis Kompaun screen."""
        return self.is_element_present(self.SCREEN_TITLE, timeout=10)

    def click_tarik_notis(self):
        """Click the Tarik Notis button to open the pull form."""
        print("  [NOTIS KOMPAUN] Clicking Tarik Notis...")
        self.wait_and_click(self.BUTTON_TARIK_NOTIS)

    def enter_id_penguatkuasa(self, id_penguatkuasa):
        """Enter the enforcement officer ID -- and VERIFY the popup is
        still open afterwards.

        >>> 2026-09-04 22:05 -- BUKTI SCREENSHOT Appium (diagnostik
        test_zz_diag_tarik_notis: diagt_2_popup.png = popup terbuka dgn
        medan "ID Penguatkuasa" + "No Notis" + TARIK; diagt_3_selepas_
        taip.png = popup HILANG, skrin Notis Kompaun kosong). Proses isi
        (click/clear/send_keys) menutup modal RN ini walaupun
        keep_keyboard=True -- dan click_tarik() lama anggap "popup dah
        tiada = TARIK berjaya" lalu TARIK TAK PERNAH ditekan -> jadual
        kosong -> "No records displayed" (punca TN-001/002 & NK-001/002
        GAP sejak run penuh, BUKAN data/akaun msc). Fix: selepas isi,
        kalau popup hilang, buka semula dan taip dgn mobile:type TANPA
        click/clear; sahkan popup masih ada sebelum pulang. <<<"""
        import time
        print(f"  [NOTIS KOMPAUN] Entering ID penguatkuasa: {id_penguatkuasa}")
        self.fill_field_by_label(self.LABEL_ID_PENGUATKUASA, id_penguatkuasa,
                                 keep_keyboard=True)
        time.sleep(0.8)
        if self.is_element_present(self.POPUP_TARIK_TITLE, timeout=2):
            return
        for cubaan in range(3):
            print(f"  [NOTIS KOMPAUN] popup Tarik Notis HILANG selepas isi "
                  f"(cubaan {cubaan + 1}/3) -- buka semula & taip tanpa "
                  f"clear...")
            self.dismiss_native_alerts(first_timeout=1,
                                       context="tarik notis popup hilang")
            self.click_tarik_notis()
            time.sleep(1.5)
            if not self.is_element_present(self.POPUP_TARIK_TITLE, timeout=5):
                continue
            # 2026-09-04 22:23 (dump tarik_popup_hilang.xml): selepas buka
            # semula, medan ID SUDAH memegang "msc" (state modal RN kekal)
            # -- locator placeholder tak padan lagi. Kalau EditText pertama
            # dah = ID, jangan taip lagi; terus TARIK.
            try:
                edits = self.driver.find_elements(
                    AppiumBy.CLASS_NAME, "android.widget.EditText")
                first = edits[0] if edits else None
                if first is not None and (first.text or "").strip() == \
                        id_penguatkuasa:
                    print("  [NOTIS KOMPAUN] medan ID sudah berisi "
                          f"'{id_penguatkuasa}' -- tak perlu taip semula")
                else:
                    el = first if first is not None else self.find_element(
                        self._ci_label_locator(self.LABEL_ID_PENGUATKUASA),
                        timeout=5)
                    self.tap_element(el)
                    time.sleep(0.6)
                    self.driver.execute_script('mobile: type',
                                               {'text': id_penguatkuasa})
                    time.sleep(0.8)
            except Exception as e:                           # noqa: BLE001
                print(f"  [NOTIS KOMPAUN] taip semula gagal: "
                      f"{type(e).__name__}")
                continue
            if self.is_element_present(self.POPUP_TARIK_TITLE, timeout=2):
                print("  [NOTIS KOMPAUN] popup kekal terbuka selepas taip "
                      "semula -- OK")
                return
        path = self._dump("tarik_popup_hilang.xml")
        raise TimeoutException(
            f"Popup Tarik Notis hilang selepas isi ID (3 percubaan); "
            f"lihat {path}")

    def click_tarik(self):
        """Click the TARIK button and VERIFY the popup actually closed.

        Confirmed via live dump: the raw coordinate tap on TARIK can
        silently no-op (same flake as the suggestion/option rows),
        leaving the popup open on top of the record table -- which then
        reads as 'no records displayed' even though the tap 'worked'.
        Re-taps up to 3 times, checking the popup title each round.

        Deliberately does NOT hide the keyboard up front: on this
        dismissible RN modal, hide_keyboard can act like a Back press
        and close the entire popup (confirmed via an earlier live
        dump); it's only used as a fallback when the button can't be
        found at all (possibly covered by the keyboard)."""
        print("  [NOTIS KOMPAUN] Clicking Tarik...")
        import time
        # 2026-09-04: popup MESTI terbuka di sini -- kalau tiada, TARIK tak
        # pernah ditekan; jangan anggap berjaya (lihat enter_id_penguatkuasa).
        if not self.is_element_present(self.POPUP_TARIK_TITLE, timeout=3):
            path = self._dump("tarik_popup_tiada_sebelum_tarik.xml")
            raise TimeoutException(
                f"Popup Tarik Notis tiada sebelum TARIK ditekan; lihat {path}")
        ditekan = False
        for attempt in range(3):
            el = None
            for loc in self.TARIK_LOCATORS:
                if self.is_element_present(loc, timeout=5):
                    el = self.find_element(loc, timeout=5)
                    break
            if el is None:
                self._hide_keyboard_if_shown()
                time.sleep(0.5)
                continue
            self.tap_element(el)
            ditekan = True
            time.sleep(1)
            if not self.is_element_present(self.POPUP_TARIK_TITLE,
                                           timeout=5):
                print("  [NOTIS KOMPAUN] TARIK ditekan -- popup tertutup")
                return
            print(f"  [NOTIS KOMPAUN] Tarik popup still open after tap "
                  f"(attempt {attempt + 1}/3) -- re-tapping...")

        if ditekan and not self.is_element_present(self.POPUP_TARIK_TITLE,
                                                   timeout=2):
            return
        dump_path = "debug_tarik_page_source.xml"
        try:
            with open(dump_path, "w", encoding="utf-8") as f:
                f.write(self.driver.page_source)
            print(f"  [NOTIS KOMPAUN] DEBUG: page source dumped to "
                  f"{dump_path}")
        except Exception:
            pass
        raise TimeoutException(
            "TARIK tidak berjaya ditekan / popup tidak tutup selepas 3 "
            "percubaan; see debug_tarik_page_source.xml")

    def is_record_displayed(self, timeout=10):
        """Check if any record row is displayed after Tarik.

        Confirmed via live page-source dump (debug_notis_kompaun_
        records.xml): this screen has NO RecyclerView at all (the old
        check's class), just a table whose row cells carry their
        content in content-desc -- and unlike Senarai's YYYY-MM-DD,
        the dates here render as DD-MM-YYYY (e.g. "PANDU KERETA LAJU,
        24-06-2026"). Matches either date shape. Dumps the page source
        when nothing is found, so 'no records' vs 'wrong locator' can
        be told apart offline."""
        row_locator = (
            AppiumBy.ANDROID_UIAUTOMATOR,
            'new UiSelector().className("android.view.ViewGroup")'
            '.descriptionMatches(".*(\\d{4}-\\d{2}-\\d{2}|\\d{2}-\\d{2}-\\d{4}).*")')
        found = self.is_element_present(row_locator, timeout=timeout)
        if found:
            print("  [NOTIS KOMPAUN] Record(s) displayed — PASS")
        else:
            print("  [NOTIS KOMPAUN] WARNING: No records displayed")
            try:
                dump_path = "debug_notis_kompaun_records.xml"
                with open(dump_path, "w", encoding="utf-8") as f:
                    f.write(self.driver.page_source)
                print(f"  [NOTIS KOMPAUN] DEBUG: page source dumped to "
                      f"{dump_path}")
            except Exception:
                pass
        return found

    # ------------------------------------------------------------------
    # v3 Phase 3 additions (all popup facts confirmed via live recon
    # 2026-07-16: the TARIK NOTIS popup has BOTH 'ID Penguatkuasa' and
    # 'No Notis' fields; a pulled-notice row tap opens a popup with
    # NO NOTIS + pesalah details + KOMPAUN/PATUH buttons + an ulasan
    # field; tapping PATUH with it empty alerts "ULASAN WAJIB DIISI.")
    # ------------------------------------------------------------------

    LABEL_NO_NOTIS = "No Notis"
    NOTICE_POPUP = (AppiumBy.ANDROID_UIAUTOMATOR,
                    'new UiSelector().textContains("NO NOTIS")')
    BUTTON_NK_KOMPAUN = (AppiumBy.ANDROID_UIAUTOMATOR,
                         'new UiSelector().text("KOMPAUN")')
    BUTTON_NK_PATUH = (AppiumBy.ANDROID_UIAUTOMATOR,
                       'new UiSelector().text("PATUH")')
    NK_FORM_TITLE = (AppiumBy.ANDROID_UIAUTOMATOR,
                     'new UiSelector().textContains("NOTIS TO KOMPAUN")')

    def _dump(self, name):
        try:
            import os
            os.makedirs("ui_dumps", exist_ok=True)
            path = os.path.join("ui_dumps", name)
            with open(path, "w", encoding="utf-8") as f:
                f.write(self.driver.page_source)
            print(f"  [NOTIS KOMPAUN] DEBUG: page source dumped to {path}")
            return path
        except Exception:
            return "(dump failed)"

    def get_pulled_notice_numbers(self):
        """Notice numbers (IPA...) visible in the pulled table, in row
        order (each is a cell whose text is the number)."""
        loc = (AppiumBy.ANDROID_UIAUTOMATOR,
               'new UiSelector().textMatches("IPA\\w+")')
        numbers = []
        try:
            for el in self.driver.find_elements(*loc):
                t = el.text
                if t:
                    numbers.append(t)
        except Exception:
            pass
        return numbers

    def tarik_by_no_notis(self, no_notis):
        """MBIP-TC-TN-002: pull a single notice by its number via the
        popup's 'No Notis' field, then verify that notice is displayed."""
        self.click_tarik_notis()
        print(f"  [NOTIS KOMPAUN] Entering No Notis: {no_notis}")
        # keep_keyboard=True -- dismissible RN modal (same lesson as the
        # ID field). use_mobile_type=True -- confirmed live: plain
        # send_keys throws InvalidElementStateException on this field
        # (same masked/validated-input behavior as the IP and tempoh
        # fields).
        self.fill_field_by_label(self.LABEL_NO_NOTIS, no_notis,
                                 keep_keyboard=True, use_mobile_type=True)
        self.click_tarik()
        self.dismiss_native_alerts(first_timeout=15,
                                   context="Tarik by No Notis")
        loc = (AppiumBy.ANDROID_UIAUTOMATOR,
               f'new UiSelector().textContains("{no_notis}")')
        found = self.is_element_present(loc, timeout=10)
        if not found:
            self._dump("tn002_notice_not_listed.xml")
        return found

    def open_notice_popup(self, index=0):
        """Tap a pulled-notice row and verify its popup opened. Returns
        the popup's NO NOTIS value (or None)."""
        import time
        row = (AppiumBy.ANDROID_UIAUTOMATOR,
               'new UiSelector().className("android.view.ViewGroup")'
               '.descriptionMatches(".*\\d{2}-\\d{2}-\\d{4}.*")')
        els = self.driver.find_elements(*row)
        if not els:
            raise TimeoutException("no pulled-notice rows on screen")
        el = els[min(index, len(els) - 1)]
        print(f"  [NOTIS KOMPAUN] Opening notice row: "
              f"{el.get_attribute('content-desc')!r}")
        for attempt in range(3):
            self.tap_element(el)
            time.sleep(1.5)
            if self.is_element_present(self.NOTICE_POPUP, timeout=4):
                break
            print(f"  [NOTIS KOMPAUN] notice popup didn't open (attempt "
                  f"{attempt + 1}/3) -- re-tapping...")
        else:
            self._dump("nk_notice_popup_never_opened.xml")
            raise TimeoutException("notice popup never opened; see "
                                   "ui_dumps/nk_notice_popup_never_opened"
                                   ".xml")
        try:
            t = self.driver.find_element(*self.NOTICE_POPUP).text
            print(f"  [NOTIS KOMPAUN] popup: {t}")
            return t.split(":")[-1].strip()
        except Exception:
            return None

    def _scroll_popup_to(self, target_locator, rounds=8):
        """Scroll the notice popup's content toward target_locator. The
        drag MUST start on a LABEL TextView -- a drag starting on one of
        the popup's EditTexts is swallowed by the TextInput (confirmed
        live). Returns True when the target is present."""
        import time
        if self.is_element_present(target_locator, timeout=2):
            return True
        label_row = (AppiumBy.ANDROID_UIAUTOMATOR,
                     'new UiSelector().className("android.widget.TextView")'
                     '.textMatches(".* :$")')
        for _ in range(rounds):
            try:
                labels = self.driver.find_elements(*label_row)
                if not labels:
                    return self.is_element_present(target_locator,
                                                   timeout=2)
                r = labels[-1].rect
                x = r["x"] + r["width"] // 2
                y = r["y"] + r["height"] // 2
                self.driver.swipe(x, y, x, max(y - 1300, 400), 800)
                time.sleep(0.8)
            except Exception:
                break
            if self.is_element_present(target_locator, timeout=2):
                return True
        return self.is_element_present(target_locator, timeout=2)

    def patuh(self, ulasan):
        """MBIP-TC-NK-002: on the open notice popup, fill the ulasan
        field and tap PATUH. Success = popup closes without a RALAT
        alert (messages returned for the log)."""
        import time
        self._dump("nk_popup_before_patuh.xml")
        # The visible popup fields are the NOTICE DATA (nama/KP/alamat
        # -- confirmed live; a blind 'last EditText' write corrupted
        # ALAMAT 1). The ULASAN field is NOT in the initial tree; the
        # popup's content area scrolls -- hunt for an ULASAN label and
        # take the EditText right after it.
        ulasan_label = (AppiumBy.ANDROID_UIAUTOMATOR,
                        'new UiSelector().textMatches("(?i).*ulasan.*")')
        ulasan_field = (AppiumBy.XPATH,
                        '//android.widget.TextView[contains(translate('
                        '@text, "ulasan", "ULASAN"), "ULASAN")]'
                        '/following-sibling::android.widget.EditText[1]')
        found = self._scroll_popup_to(ulasan_label, rounds=10)
        if not found:
            path = self._dump("nk_ulasan_field_missing.xml")
            raise TimeoutException(
                f"no ULASAN field found in the notice popup (initial "
                f"view holds only the notice's data fields); see {path}")
        el = self.find_element(ulasan_field, timeout=5)
        el.click()
        el.clear()
        self.driver.execute_script('mobile: type', {'text': ulasan})

        # A photo is REQUIRED for Patuh too -- confirmed live: PATUH
        # bounced with "SILA AMBIL GAMBAR.". The popup carries its own
        # OPEN CAMERA near the ulasan field.
        from pages.daftar_kompaun_page import DaftarKompaunPage
        camera = (AppiumBy.ANDROID_UIAUTOMATOR,
                  'new UiSelector().text("OPEN CAMERA")')
        try:
            # The open keyboard hides the popup's lower section
            # (confirmed live: OPEN CAMERA sits right below the ULASAN
            # field per the popup-bottom probe, yet was 'not found'
            # while the keyboard was up). With an IME open, a single
            # device Back closes ONLY the keyboard.
            try:
                if self.driver.is_keyboard_shown():
                    self.press_back()
                    time.sleep(1)
            except Exception:
                pass
            if not self.is_element_present(self.NOTICE_POPUP, timeout=3):
                raise TimeoutException(
                    "notice popup dismissed while closing the keyboard")
            if not self.is_element_present(camera, timeout=3):
                self._scroll_popup_to(camera, rounds=6)
            el2 = self.find_element(camera, timeout=5)
            self.tap_element(el2)
            time.sleep(2)
            self.wait_and_click(DaftarKompaunPage.BUTTON_SNAP)
            time.sleep(3)
            for _ in range(3):
                el2 = self.find_clickable(
                    DaftarKompaunPage.BUTTON_TICK_CONFIRM)
                self.tap_element(el2)
                time.sleep(2)
                if not self.is_element_present(
                        DaftarKompaunPage.CAMERA_OPEN_INDICATOR,
                        timeout=3):
                    print("  [NOTIS KOMPAUN] patuh photo taken")
                    break
        except Exception as e:
            print(f"  [NOTIS KOMPAUN] WARNING: patuh camera step failed "
                  f"({type(e).__name__}) -- PATUH may reject")
        time.sleep(0.5)
        # The open keyboard unmounts/covers the popup's PATUH button
        # (confirmed live: 'PATUH' not found right after typing), and a
        # device Back dismisses the WHOLE RN modal, not just the
        # keyboard (also confirmed live). Close the keyboard with the
        # IME action key (ENTER) instead, then a neutral tap on the
        # popup title as fallback; verify the popup survived.
        if not self.is_element_present(self.BUTTON_NK_PATUH, timeout=3):
            self.driver.press_keycode(66)  # IME done/enter
            time.sleep(1)
        if not self.is_element_present(self.BUTTON_NK_PATUH, timeout=3):
            try:
                el = self.driver.find_element(*self.NOTICE_POPUP)
                self.tap_element(el)
                time.sleep(1)
            except Exception:
                pass
        if not self.is_element_present(self.NOTICE_POPUP, timeout=3):
            raise TimeoutException(
                "notice popup got dismissed while closing the keyboard "
                "before PATUH")
        messages = []
        for attempt in range(3):
            btn = self.find_element(self.BUTTON_NK_PATUH, timeout=5)
            self.tap_element(btn)
            time.sleep(1.5)
            # result alert?
            if self.is_element_present(self.NATIVE_ALERT_OK, timeout=5):
                try:
                    msg = self.driver.find_element(
                        *self.NATIVE_ALERT_MESSAGE).text
                    messages.append(msg)
                    print(f"  [NOTIS KOMPAUN] PATUH result: {msg}")
                except Exception:
                    pass
                self.dismiss_native_alerts(first_timeout=2, context="patuh")
            if not self.is_element_present(self.NOTICE_POPUP, timeout=3):
                return messages
            print(f"  [NOTIS KOMPAUN] popup still open after PATUH "
                  f"(attempt {attempt + 1}/3)")
        self._dump("nk_patuh_popup_stuck.xml")
        return messages

    def kompaun_action(self, amaun):
        """MBIP-TC-NK-001: on the open notice popup, tap KOMPAUN -- a
        'NOTIS TO KOMPAUN FORM' screen opens (confirmed via recon).
        Drive it to submission: fill the amount if reachable, then the
        generic SETERUSNYA/MENYERAHKAN/HANTAR ladder, draining result
        alerts. Success = the form closed."""
        import time
        print("  [NOTIS KOMPAUN] Tapping KOMPAUN on the notice popup...")
        for attempt in range(3):
            btn = self.find_element(self.BUTTON_NK_KOMPAUN, timeout=5)
            self.tap_element(btn)
            time.sleep(2)
            if self.is_element_present(self.NK_FORM_TITLE, timeout=5):
                break
            print(f"  [NOTIS KOMPAUN] NOTIS TO KOMPAUN FORM didn't open "
                  f"(attempt {attempt + 1}/3)")
        else:
            self._dump("nk001_form_never_opened.xml")
            raise TimeoutException(
                "NOTIS TO KOMPAUN FORM never opened; see "
                "ui_dumps/nk001_form_never_opened.xml")
        print("  [NOTIS KOMPAUN] NOTIS TO KOMPAUN FORM open")
        self._dump("nk001_form_top.xml")

        # This form is the same unscrollable RN record-form family as
        # Kemaskini/HantarSemula (confirmed live: fields below the fold
        # are absent from the tree and every gesture no-ops) -- each
        # field is revealed via focus traversal before acting.
        amaun_loc = (AppiumBy.XPATH,
                     '//android.widget.EditText[@hint="ENTER AMAUN"]')
        if self.reveal_below_fold(amaun_loc):
            el = self.find_element(amaun_loc, timeout=5)
            el.click()
            el.clear()
            self.driver.execute_script('mobile: type', {'text': amaun})
            self._hide_keyboard_if_shown()
            print(f"  [NOTIS KOMPAUN] amount entered: {amaun}")
        else:
            print("  [NOTIS KOMPAUN] WARNING: ENTER AMAUN field never "
                  "rendered -- continuing (may be preset)")

        # MAKLUMAT PEGAWAI: NO PEMBANTU PENGUATKUASA is required
        # (confirmed live: submit alert bounced without it).
        pembantu_loc = self._ci_label_locator("NO PEMBANTU PENGUATKUASA")
        if self.reveal_below_fold(pembantu_loc):
            self.fill_field_by_label("NO PEMBANTU PENGUATKUASA", "2",
                                     timeout=5)
            print("  [NOTIS KOMPAUN] pembantu penguatkuasa filled")
        else:
            print("  [NOTIS KOMPAUN] pembantu placeholder not rendered "
                  "(likely already holds a value) -- continuing")

        # Photos are MANDATORY on this form -- confirmed live: the
        # submit alert says "GAMBAR MESTI DIAMBIL.". Reuse the hardened
        # camera routine (pacing + verified tick) via the shared
        # constants, one photo suffices.
        from pages.daftar_kompaun_page import DaftarKompaunPage
        try:
            camera = (AppiumBy.ANDROID_UIAUTOMATOR,
                      'new UiSelector().text("OPEN CAMERA")')
            if not self.reveal_below_fold(camera):
                raise TimeoutException("OPEN CAMERA never rendered")
            el = self.find_element(camera, timeout=5)
            self.tap_element(el)
            time.sleep(2)
            self.wait_and_click(DaftarKompaunPage.BUTTON_SNAP)
            time.sleep(3)
            for attempt in range(3):
                el = self.find_clickable(
                    DaftarKompaunPage.BUTTON_TICK_CONFIRM)
                self.tap_element(el)
                time.sleep(2)
                if not self.is_element_present(
                        DaftarKompaunPage.CAMERA_OPEN_INDICATOR,
                        timeout=3):
                    print("  [NOTIS KOMPAUN] photo taken and confirmed")
                    break
        except Exception as e:
            print(f"  [NOTIS KOMPAUN] WARNING: camera step failed "
                  f"({type(e).__name__}: {e}) -- submit may reject")

        # drive to submission (reveal MENYERAHKAN first -- same
        # unscrollable-form reason as the fields above)
        self.reveal_below_fold(self.BUTTON_MENYERAHKAN)
        seterusnya = (AppiumBy.ACCESSIBILITY_ID, "SETERUSNYA")
        simpan_popup = (AppiumBy.ANDROID_UIAUTOMATOR,
                        'new UiSelector().textContains("Simpan maklumat")')
        for _ in range(5):
            if self.is_element_present(simpan_popup, timeout=3):
                el = self.find_clickable(self.BUTTON_HANTAR)
                self.tap_element(el)
                time.sleep(2)
                continue
            if self.is_element_present(self.BUTTON_MENYERAHKAN, timeout=3):
                self._hide_keyboard_if_shown()
                el = self.find_clickable(self.BUTTON_MENYERAHKAN)
                self.tap_element(el)
                time.sleep(2)
                continue
            if self.is_element_present(seterusnya, timeout=3):
                el = self.find_element(seterusnya, timeout=3)
                self.tap_element(el)
                time.sleep(2)
                continue
            break
        self.dismiss_native_alerts(first_timeout=20,
                                   context="notis-ke-kompaun submit")
        time.sleep(1)
        closed = not self.is_element_present(self.NK_FORM_TITLE, timeout=4)
        if not closed:
            self._dump("nk001_form_still_open.xml")
        return closed

    def tarik_notis(self, id_penguatkuasa):
        """Complete Tarik Notis flow: open form, enter ID, tarik, check
        that records are displayed."""
        self.click_tarik_notis()
        self.enter_id_penguatkuasa(id_penguatkuasa)
        self.click_tarik()

        # The pull runs against the server and reports its result via
        # the same native alert the sync/upload flows use -- while one
        # is up, UiAutomator can't see the table behind it. Wait for
        # it and dismiss (also logs how many notices were pulled).
        self.dismiss_native_alerts(first_timeout=15, context="Tarik Notis")

        assert self.is_record_displayed(), \
            f"FAIL: No records displayed for id_penguatkuasa={id_penguatkuasa}"
        print("  [NOTIS KOMPAUN] Tarik Notis completed successfully")
        return True

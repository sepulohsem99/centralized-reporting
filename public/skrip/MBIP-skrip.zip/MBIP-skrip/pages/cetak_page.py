"""
Cetak (Print) page — Page Object Model.

Covers MBIP-TC-N/P/K/L/S-002: "Verify that 'Cetak' button can generate and
print out" — sync the record, tap 'Cetak', expected: user can print to a
connected printer.

ENTRY POINT (confirmed via ui_dumps/serah_N_record_view.xml)
------------------------------------------------------------
Print is reached from the record-view popup — the SAME "KEMASKINI DATA"
popup the Serah (-003) flow opens: Senarai -> open the jenis' newest
record -> the popup's pinned footer holds two clickable ViewGroups,
content-desc="KEMASKINI" (left) and content-desc="CETAK" (right). Tapping
CETAK prints the open record.

WHAT THE FIRST LIVE RUN TAUGHT US (2026-07-28, MBIP staging)
------------------------------------------------------------
Confirmed live: tapping CETAK **dismisses the record popup** and the app
navigates back out (Senarai -> Home; see ui_dumps/cetak_N_no_popup.xml is
the HOME grid). So a retry CANNOT assume the KEMASKINI DATA popup is still
underneath an alert — it is gone. Every print attempt must therefore
RE-NAVIGATE from Home: Senarai -> open the record -> tap CETAK. That is the
central fix over the first version, which tapped a stale popup and looped
to a false "printer unreachable" skip.

The print result is reported by the app; capture its message BEFORE
dismissing it (the first version dumped after dismissing and lost the
text), so classification can be tuned to whatever the app actually says.

PRINTER AUTO-OFF
----------------
The Bluetooth thermal printer auto-sleeps after ~10 min. When an attempt
comes back "unreachable", we do NOT skip immediately: printer_utils
.wait_for_printer beeps + banners the operator and re-attempts every 5s for
up to 5 min, resuming on its own the moment a print succeeds. Only after
5 min does the test skip("printer tidak dihidupkan").

Techniques per CLAUDE.md: tap_element (raw coord tap, not el.click()),
verify-and-retry on every critical tap, dismiss_native_alerts before new
interactions, dump page source on any unrecognized screen.
"""

import os
import time

from appium.webdriver.common.appiumby import AppiumBy
from selenium.common.exceptions import TimeoutException

from pages.base_page import BasePage
import printer_utils


class CetakPage(BasePage):
    """Record-popup CETAK (print) flow, re-navigated per attempt."""

    POPUP_TITLE = (AppiumBy.ANDROID_UIAUTOMATOR,
                   'new UiSelector().text("KEMASKINI DATA")')
    CETAK_BUTTON = (AppiumBy.ACCESSIBILITY_ID, "CETAK")
    POPUP_X = (AppiumBy.ACCESSIBILITY_ID, "✕")

    # Optional confirm step ("Cetak resit? / Ya") between CETAK and the
    # actual print on some builds — handled if present, ignored if not.
    CONFIRM_YA = (AppiumBy.ANDROID_UIAUTOMATOR,
                  'new UiSelector().textMatches("(?i)^(YA|OK|CETAK|PRINT)$")')

    # An RN (non-native) success popup this app is known to raise elsewhere
    # after a save/print ("Cetak Notis Amaran?" etc. — see
    # notis_amaran_page.POPUP_CETAK_NOTIS_AMARAN). Used as a secondary
    # success signal when there is no native alert.
    RN_SUCCESS_TEXT = (AppiumBy.ANDROID_UIAUTOMATOR,
                       'new UiSelector().textMatches('
                       '"(?i).*(berjaya|dicetak|cetak notis|cetak kompaun|'
                       'cetak sitaan).*")')

    def _dump(self, name):
        try:
            os.makedirs("ui_dumps", exist_ok=True)
            path = os.path.join("ui_dumps", name)
            with open(path, "w", encoding="utf-8") as f:
                f.write(self.driver.page_source)
            print(f"  [CETAK] DEBUG: page source dumped to {path}")
            return path
        except Exception:                                    # noqa: BLE001
            return "(dump failed)"

    def is_record_popup_open(self, timeout=5):
        return self.is_element_present(self.POPUP_TITLE, timeout=timeout)

    # ------------------------------------------------------------------
    # Native result-alert helpers — READ before dismissing (the app
    # reports operation results via native BERJAYA/RALAT alerts).
    # ------------------------------------------------------------------

    def _peek_alert_message(self, timeout):
        """If a native alert is up within `timeout`s, return its message
        text WITHOUT dismissing it (empty string if the alert has no
        message element). Return None if no alert appeared."""
        if not self.is_element_present(self.NATIVE_ALERT_OK, timeout=timeout):
            return None
        try:
            return self.driver.find_element(*self.NATIVE_ALERT_MESSAGE).text
        except Exception:                                    # noqa: BLE001
            return ""

    def _dismiss_alert(self):
        """Dismiss the current native alert and any queued behind it."""
        for _ in range(6):
            try:
                self.driver.find_element(*self.NATIVE_ALERT_OK).click()
            except Exception:                                # noqa: BLE001
                break
            time.sleep(0.5)
            if not self.is_element_present(self.NATIVE_ALERT_OK, timeout=2):
                break

    # ------------------------------------------------------------------
    # Navigation
    # ------------------------------------------------------------------

    def _ensure_home(self, pages):
        """Get back to the home grid from wherever a previous attempt
        ended (record popup, Senarai, a stray alert)."""
        pages.home.dismiss_native_alerts(first_timeout=1, context="cetak home")
        for _ in range(6):
            if pages.home.is_element_present(
                    pages.home.HOME_SCREEN_INDICATOR, timeout=2):
                return True
            # Close a record popup via its X if that's what's covering us.
            if self.is_record_popup_open(timeout=1):
                try:
                    el = self.find_element(self.POPUP_X, timeout=2)
                    self.tap_element(el)
                    time.sleep(1)
                    continue
                except Exception:                            # noqa: BLE001
                    pass
            pages.home.press_back()
            time.sleep(1)
        return pages.home.is_element_present(
            pages.home.HOME_SCREEN_INDICATOR, timeout=3)

    # ------------------------------------------------------------------
    # One print attempt = navigate to the record + tap CETAK + classify.
    # ------------------------------------------------------------------

    def _navigate_and_print(self, jenis_letter, pages, no_rekod):
        """Perform ONE full print attempt from a clean Home state, printing
        the record whose NO KOMPAUN/NOTIS is `no_rekod`.
        Returns (status, detail):
          'printed'             — a success result was shown.
          'printed_unconfirmed' — CETAK registered, no error, but success
                                  couldn't be positively confirmed
                                  (dumped for review).
          'record_error'        — the record `no_rekod` was not found, or the
                                  opened record showed a different number.
                                  TERMINAL: this is NOT a printer wait, it is
                                  a hard failure (the create claimed this
                                  number). wait_for_printer stops immediately.
          'unreachable'         — printer/connection error, or CETAK
                                  produced no reaction (printer not ready).
          'unknown'             — unrecognized result alert (dumped, with
                                  its message text in `detail`).
        """
        if not self._ensure_home(pages):
            return "unreachable", "could not return to Home to start attempt"

        pages.home.open_senarai()
        if not pages.senarai.is_senarai_screen_displayed():
            return "unreachable", "Senarai screen did not open"
        if not pages.senarai.ensure_records_listed():
            return "unreachable", "no records listed in Senarai"

        # Select the record BY NUMBER (not which='last'). Positional
        # selection printed whatever stale record sat last in the list, so
        # Cetak passed even when this run's create failed. No fallback: a
        # missing number is a hard fail, never "print something else".
        if not pages.senarai.open_record_by_number(no_rekod):
            self._dump(f"cetak_{jenis_letter}_record_not_found.xml")
            return "record_error", (f"rekod {no_rekod} tidak dijumpai dalam "
                                    f"Senarai (create dakwa cipta {no_rekod})")
        if not self.is_record_popup_open(timeout=8):
            self._dump(f"cetak_{jenis_letter}_no_popup_after_open.xml")
            return "unreachable", "record popup did not open after row tap"
        # Confirm the OPEN record is the one we created before printing it.
        if not pages.senarai.record_popup_shows_number(no_rekod):
            self._dump(f"cetak_{jenis_letter}_wrong_record.xml")
            return "record_error", (f"popup rekod tidak memaparkan {no_rekod} "
                                    f"— rekod salah dibuka, tidak dicetak")

        return self._tap_cetak_and_classify(jenis_letter)

    def _tap_cetak_and_classify(self, jenis_letter):
        """On the open KEMASKINI DATA popup: tap CETAK (verify-and-retry),
        then read + classify the print result, capturing page source
        BEFORE dismissing so the real message is never lost."""
        # Tap CETAK. A registered tap changes the top state: an alert
        # rises, the popup closes, or a confirm dialog opens.
        tapped = False
        for attempt in range(3):
            try:
                el = self.find_element(self.CETAK_BUTTON, timeout=6)
            except TimeoutException:
                break
            self.tap_element(el)
            time.sleep(1.5)
            if self.is_element_present(self.NATIVE_ALERT_OK, timeout=2) \
                    or not self.is_record_popup_open(timeout=1) \
                    or self.is_element_present(self.CONFIRM_YA, timeout=1):
                tapped = True
                break
            print(f"  [CETAK] CETAK tap didn't register "
                  f"(attempt {attempt + 1}/3) — re-tapping...")
        if not tapped and self.is_record_popup_open(timeout=1):
            self._dump(f"cetak_{jenis_letter}_cetak_no_reaction.xml")
            return "unreachable", "CETAK tap produced no reaction"

        # Optional confirm step ("Cetak resit? Ya").
        if self.is_element_present(self.CONFIRM_YA, timeout=2):
            try:
                el = self.find_element(self.CONFIRM_YA, timeout=3)
                print("  [CETAK] Confirm dialog — tapping proceed")
                self.tap_element(el)
                time.sleep(1)
            except Exception:                                # noqa: BLE001
                pass

        # Read the native result alert BEFORE dismissing it.
        msg = self._peek_alert_message(timeout=18)
        if msg is not None:
            # Capture the whole screen (alert included) for the record.
            self._dump(f"cetak_{jenis_letter}_result.xml")
            status, norm = printer_utils.classify_message(msg)
            print(f"  [CETAK] result alert: {norm!r} -> {status}")
            self._dismiss_alert()
            return status, (norm or "(empty alert message)")

        # No native alert. Check for an RN success popup/toast.
        if self.is_element_present(self.RN_SUCCESS_TEXT, timeout=3):
            self._dump(f"cetak_{jenis_letter}_rn_success.xml")
            print("  [CETAK] RN success popup detected")
            return "printed", "RN success popup"

        # Nothing recognizable. If the popup closed with no error at all,
        # the print most likely went through silently — record it as an
        # unconfirmed success (dumped) rather than asserting either way.
        if not self.is_record_popup_open(timeout=2):
            self._dump(f"cetak_{jenis_letter}_no_alert_popup_closed.xml")
            return ("printed_unconfirmed",
                    "no result alert; record popup closed cleanly")
        return "unreachable", "no result alert; record popup still open"

    # ------------------------------------------------------------------
    # Public entry: keep trying to print until success or 5 min elapse.
    # ------------------------------------------------------------------

    def print_record(self, jenis_letter, tc_label, pages, no_rekod):
        """Full print flow with printer auto-off tolerance. Prints the record
        whose NO KOMPAUN/NOTIS is `no_rekod` (from this run's create), NOT the
        last positional record. `pages` is the session Pages bundle (needed to
        re-navigate Senarai->record on every retry, since CETAK closes the
        popup). Returns the printer_utils.wait_for_printer result dict; the
        test decides PASS / FAIL / skip from it:
          result['record_error']  -> the record wasn't found/didn't match:
                                      FAIL (do not skip, do not print stale).
          result['printed'] False  -> printer never responded: skip.
        Leaves the app on Home."""
        # First: make sure the app is connected to the printer (the app can
        # re-connect itself -- see printer_connect_page). Icon green -> connected,
        # so the print attempt below succeeds first-try and NO operator wait
        # happens. Only when it truly can't connect does the wait_for_printer
        # loop below act as the (now short) operator fallback.
        try:
            connected = pages.printer.ensure_printer_connected(pages)
            print(f"  [CETAK] {tc_label}: printer connected = {connected}")
        except Exception as e:                               # noqa: BLE001
            print(f"  [CETAK] {tc_label}: printer-connect check failed "
                  f"({e}) -- continuing to print attempt")

        # During the Cetak flow the "Unable to connect device" alert is the
        # GENUINE printer-unreachable signal that drives the operator recall
        # (beep + banner). Turn the global printer-alert drain OFF here, or
        # find_element/find_clickable would silently swallow exactly the
        # evidence this flow depends on (directive: do not silence it in Cetak).
        prev = BasePage._drain_printer_enabled
        BasePage._drain_printer_enabled = False
        # Operator-wait: now just a fallback for a truly-dead printer (the app
        # normally self-connects above), so the default is a short 60s.
        #   MBIP_PRINTER_TIMEOUT=<secs>  override the wait
        #   MBIP_PRINTER_NOBEEP=1        operator-absent mode (no beep/banner)
        wait_timeout = int(os.environ.get("MBIP_PRINTER_TIMEOUT", "60"))
        beep_iv = None if os.environ.get("MBIP_PRINTER_NOBEEP") else 15
        try:
            result = printer_utils.wait_for_printer(
                attempt=lambda: self._navigate_and_print(
                    jenis_letter, pages, no_rekod),
                tc_label=tc_label,
                timeout=wait_timeout,
                beep_interval=beep_iv,
            )
        finally:
            BasePage._drain_printer_enabled = prev
        # A record-selection failure is terminal, NOT a printer wait -- surface
        # it so the test FAILs (never a stale-record PASS or a printer skip).
        if result.get("record_error"):
            self._ensure_home(pages)
            return result
        if not result.get("printed"):
            reason = (f"printer tidak dihidupkan (menunggu "
                      f"{result['waited_seconds']:.0f}s, "
                      f"{result['poll_count']} percubaan)")
            if beep_iv is None:
                reason += " — operator tiada"
            result["skip_reason"] = reason
        self._ensure_home(pages)
        return result

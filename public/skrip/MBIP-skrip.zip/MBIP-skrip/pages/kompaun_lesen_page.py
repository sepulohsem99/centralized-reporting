"""
Daftar Kompaun (Kompaun Lesen) page — Page Object Model. v3-new (Phase 2).

Subclasses DaftarKompaunPage: the Kompaun/Penerima tabs, kompaun-code
tiers, kadar denda, camera and submission handling are identical in
approach to the Pelbagai flow; only the jenis selection and the Pesalah
tab differ (extra "No Akuan Lesen" field, per sheet MBIP-TC-L-001).

The Lesen Pesalah tab has NOT been recon'd -- field labels are tried via
candidate ladders (exact label variants from the sheet's wording), with
a page-source dump on entry and on any miss (never guess silently).
"""

from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
from pages.daftar_kompaun_page import DaftarKompaunPage


class KompaunLesenPage(DaftarKompaunPage):
    """Daftar Kompaun — jenis KOMPAUN LESEN."""

    OPTION_KOMPAUN_LESEN = (AppiumBy.ANDROID_UIAUTOMATOR,
                            'new UiSelector().text("KOMPAUN LESEN")')

    def _dump(self, name):
        try:
            import os
            os.makedirs("ui_dumps", exist_ok=True)
            path = os.path.join("ui_dumps", name)
            with open(path, "w", encoding="utf-8") as f:
                f.write(self.driver.page_source)
            print(f"  [LESEN] DEBUG: page source dumped to {path}")
            return path
        except Exception:
            return "(dump failed)"

    def select_jenis_kompaun_lesen(self):
        """Select KOMPAUN LESEN from the jenis popup (option text
        confirmed present via earlier live recon of the popup), with the
        same verified-tap protection as the Trafik variant."""
        print("\n  [LESEN] Selecting jenis: Kompaun Lesen...")
        nama_label = self._ci_label_locator(self.LABEL_NAMA_PESALAH)
        for attempt in range(3):
            self.wait_and_tap(self.OPTION_KOMPAUN_LESEN)
            import time
            time.sleep(1)
            if not self.is_element_present(self.OPTION_KOMPAUN_LESEN,
                                           timeout=3):
                print("  [LESEN] Jenis Lesen selected — PASS")
                self._dump("lesen_pesalah_tab.xml")
                return
            print(f"  [LESEN] Jenis popup still open after tap "
                  f"(attempt {attempt + 1}/3) -- re-tapping...")
        del nama_label
        self._dump("lesen_jenis_popup_stuck.xml")
        raise TimeoutException(
            "KOMPAUN LESEN option never registered a tap; see "
            "ui_dumps/lesen_jenis_popup_stuck.xml")

    def _fill_first_matching(self, candidates, value, optional=False,
                             use_mobile_type=False, _drained=False):
        """Fill the first field whose placeholder matches any candidate
        label (each tried with a short bounded lookup). Dump + raise on
        total miss unless optional.

        On a total miss, drains any native alert once and retries: this
        app raises alerts asynchronously (confirmed live on the Sitaan
        pesalah tab -- an "Error: Unable to connect device" alert pops
        ~1s after the form renders and covers every field, so the label
        lookups below find nothing). Draining reveals the form, per
        CLAUDE.md's dismiss-before-interaction rule."""
        for label in candidates:
            locator = self._ci_label_locator(label)
            try:
                el = WebDriverWait(self.driver, 3).until(
                    EC.presence_of_element_located(locator))
            except TimeoutException:
                continue
            el.click()
            el.clear()
            if use_mobile_type:
                self.driver.execute_script('mobile: type', {'text': value})
            else:
                el.send_keys(value)
            self._hide_keyboard_if_shown()
            print(f"  [LESEN] '{label}' filled")
            return el
        if not _drained and self.drain_printer_alert():
            import time
            time.sleep(0.5)
            return self._fill_first_matching(candidates, value, optional,
                                             use_mobile_type, _drained=True)
        # >>> 2026-08-24 (lesen_field_not_found.xml run penuh #2): bila
        # borang dibuka semula dalam sesi sama (ujian -005 selepas -001),
        # app memulihkan DRAF — semua field sudah BERISI nilai dari test
        # -001, placeholder hilang, jadi TIADA label yang padan. Itu
        # bukan kegagalan: nilai draf ialah data yang sama kita isi tadi.
        # Kesan keadaan ini (ada EditText berisi teks bukan-placeholder)
        # dan skip dengan nota, bukannya raise. <<<
        try:
            for et in self.driver.find_elements(
                    AppiumBy.CLASS_NAME, "android.widget.EditText"):
                t = (self._safe_text(et) or "").strip()
                if t and not any(self._norm(t) == self._norm(c)
                                 for c in candidates):
                    print(f"  [LESEN] borang sudah pra-isi (draf app; "
                          f"contoh nilai {t!r}) — {candidates[0]!r} "
                          f"dianggap sudah diisi, skip")
                    return None
        except Exception:                                    # noqa: BLE001
            pass
        if optional:
            print(f"  [LESEN] WARNING: none of {candidates} found -- "
                  f"skipping (treated as optional)")
            return None
        path = self._dump("lesen_field_not_found.xml")
        raise TimeoutException(
            f"No field matched any of {candidates}; see {path}")

    def fill_pesalah_tab_lesen(self, data):
        """Fill the Lesen Pesalah tab per sheet MBIP-TC-L-001: nama,
        no K/P / SSM, no akuan lesen, then the address block (typed
        directly, same technique as the Pelbagai Pesalah tab)."""
        import time
        print("\n  [LESEN] Filling Pesalah tab (Lesen)...")
        time.sleep(1)
        # Drain the async "Unable to connect device" printer alert that
        # covers the Sitaan pesalah tab ~1s after it loads (counted globally
        # via drain_printer_alert; also handled centrally in find_element).
        self.drain_printer_alert()

        self._fill_first_matching(
            ["NAMA PESALAH", "NAMA PEMILIK/SYARIKAT",
             "NAMA PEMILIK / SYARIKAT", "NAMA PESALAH/SYARIKAT"],
            data["nama_pesalah"])
        # Nama may be an autocomplete (sheet step 1: "Type and select
        # Nama Pemilik/Syarikat from the dropdown") -- if a suggestion
        # row rendered, pick the matching one; if none, typed text stays.
        row = (AppiumBy.ANDROID_UIAUTOMATOR,
               f'new UiSelector().className("android.widget.TextView")'
               f'.textContains("{data["nama_pesalah"]}")')
        if self.is_element_present(row, timeout=3):
            try:
                el = self.find_element(row, timeout=3)
                self.tap_element(el)
                print("  [LESEN] Picked nama suggestion row")
                time.sleep(1)
            except Exception:
                pass

        self._fill_first_matching(
            ["NO KP/ SSM/ NO KERETA", "NO K/P / SSM", "NO KP/SSM",
             "NO KP/ SSM"],
            data["no_kp_ssm"])
        self._fill_first_matching(
            # "NO AKAUN LESEN" (AKAUN, not AKUAN) is the on-screen label
            # confirmed via live recon of the Sitaan pesalah tab.
            ["NO AKAUN LESEN", "NO AKUAN LESEN", "NO. AKUAN LESEN",
             "NO LESEN"],
            data["no_akuan_lesen"], optional=True)

        for label, key in ((self.LABEL_PESALAH_JALAN, "jalan"),
                           (self.LABEL_PESALAH_TAMAN, "taman"),
                           (self.LABEL_PESALAH_POSKOD, "poskod"),
                           (self.LABEL_PESALAH_BANDAR, "bandar"),
                           (self.LABEL_PESALAH_NEGERI, "negeri")):
            if label == self.LABEL_PESALAH_NEGERI:
                self._scroll_down()
            self.fill_field_by_label(label, data[key])

        print("  [LESEN] Pesalah tab (Lesen) filled — PASS")

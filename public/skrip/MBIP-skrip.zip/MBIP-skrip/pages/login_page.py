"""
Login page — Page Object Model.
Includes the licensing/IP setup sub-flow (hamburger -> Tetapan Alamat IP ->
Tetapan Pelbagai -> device ID -> 'Lesen sama' popup -> relogin), used only
when a fresh login does not reach the home screen.
"""

from appium.webdriver.common.appiumby import AppiumBy
from pages.base_page import BasePage


class LoginPage(BasePage):
    """Login screen locators and actions."""

    # ---- Locators ----
    USERNAME_FIELD = (AppiumBy.ANDROID_UIAUTOMATOR,
                      'new UiSelector().className("android.widget.EditText").instance(0)')
    PASSWORD_FIELD = (AppiumBy.ANDROID_UIAUTOMATOR,
                      'new UiSelector().className("android.widget.EditText").instance(1)')
    TOGGLE_PASSWORD = (AppiumBy.ACCESSIBILITY_ID, "\uf070")
    REMEMBER_ME_CHECKBOX = (AppiumBy.ANDROID_UIAUTOMATOR,
                            'new UiSelector().text("REMEMBER ME")')
    LOGIN_BUTTON = (AppiumBy.ACCESSIBILITY_ID, "LOGIN")
    APP_TITLE = (AppiumBy.ANDROID_UIAUTOMATOR,
                 'new UiSelector().text("APLIKASI KOMPAUN e-PBT")')
    VERSION_TEXT = (AppiumBy.ANDROID_UIAUTOMATOR,
                    'new UiSelector().textContains("Version")')

    # ---- Licensing / IP setup sub-flow ----
    # ASSUMPTION: exact menu item text — verify against real screen if this
    # sub-flow does not trigger during your run.
    MENU_TETAPAN_ALAMAT_IP = (AppiumBy.ANDROID_UIAUTOMATOR,
                              'new UiSelector().textContains("Tetapan Alamat IP")')
    MENU_TETAPAN_PELBAGAI = (AppiumBy.ANDROID_UIAUTOMATOR,
                             'new UiSelector().textContains("Tetapan Pelbagai")')
    # ASSUMPTION: exact field labels for internal/external IP inputs
    FIELD_INTERNAL_IP_LABEL = "INTERNAL IP ADDRESS"
    FIELD_EXTERNAL_IP_LABEL = "EXTERNAL IP ADDRESS"
    BUTTON_SIMPAN = (AppiumBy.ANDROID_UIAUTOMATOR,
                     'new UiSelector().text("Simpan")')
    # ASSUMPTION: exact field label on the Tetapan Pelbagai screen
    FIELD_DEVICE_ID_LABEL = "DEVICE ID"
    POPUP_LESEN_SAMA = (AppiumBy.ANDROID_UIAUTOMATOR,
                        'new UiSelector().textContains("Lesen sama")')

    # v3 (T-012): the real toggle is the CheckBox widget itself --
    # confirmed via live recon dump (recon_pelesen_60s.xml): a clickable
    # android.widget.CheckBox sits next to the "REMEMBER ME" TextView.
    REMEMBER_ME_TOGGLE = (AppiumBy.ANDROID_UIAUTOMATOR,
                          'new UiSelector().className('
                          '"android.widget.CheckBox")')

    # >>> 2026-08-24 (build 2.1.17 hotfix): TIADA android.widget.CheckBox
    # pada skrin login — dump forensik debug_tetapan_pelbagai menunjukkan
    # toggle Remember Me dirender sebagai TextView ikon Material Design
    # Icons: U+F0131 (checkbox-blank-outline) / U+F0132 (checkbox-marked).
    # Kegagalan T-012 "CheckBox not found" pada 3 run berturut ialah
    # perubahan build, bukan flake. Fallback ikon di bawah. <<<
    REMEMBER_ME_IKON_KOSONG = "\U000f0131"
    REMEMBER_ME_IKON_TANDA = "\U000f0132"

    def _cari_toggle_remember_me(self):
        """Susunan carian: CheckBox klasik -> ikon MDI kosong/bertanda
        (text ATAU content-desc). Pulangkan (elemen, jenis).

        >>> 2026-09-03: bukti ui_dumps/t012_toggle_missing.xml daripada
        run BERSIH menunjukkan punca sebenar kegagalan T-012 kali ini
        BUKAN perubahan UI toggle — page_source yang di-dump semasa
        "tidak ditemui" ialah alert ASLI Android 'APLIKASI IN TELAH
        DIKEMAS KINI' (android:id/alertTitle + android:id/button1)
        MENUTUP SELURUH skrin login. Alert ini tiba tidak segerak
        (nota sedia ada CLAUDE.md: "Panggil dismiss_native_alerts()
        sebelum sebarang interaksi baharu") — carian toggle di sini
        tidak pernah memanggilnya, jadi ia carian buta terhadap modal
        yang menutup skrin, bukan toggle yang benar-benar hilang.
        dismiss_native_alerts() sebelum DAN selepas tier carian utama
        supaya alert yang tiba lewat (mid-search) turut ditangani
        sebelum kita benar-benar mengalah. <<<"""
        from selenium.common.exceptions import TimeoutException as _TE

        def _cuba_semua_tier():
            try:
                return (self.find_element(self.REMEMBER_ME_TOGGLE,
                                          timeout=3), "checkbox")
            except _TE:
                pass
            for ikon in (self.REMEMBER_ME_IKON_KOSONG,
                         self.REMEMBER_ME_IKON_TANDA):
                for loc in (
                    (AppiumBy.ANDROID_UIAUTOMATOR,
                     f'new UiSelector().text("{ikon}")'),
                    (AppiumBy.ANDROID_UIAUTOMATOR,
                     f'new UiSelector().description("{ikon}")'),
                ):
                    try:
                        return (self.find_element(loc, timeout=2), "ikon")
                    except _TE:
                        continue
            # >>> 2026-08-24 run penuh #2: UiSelector.text() dengan aksara
            # PUA supplementari (U+F0131) TIDAK memadankan pada peranti ini
            # walaupun ikon wujud (dump forensik menunjukkannya sebagai
            # TextView). Tier GEOMETRI: TextView berteks pendek (ikon) pada
            # BARIS yang sama dengan label 'REMEMBER ME', di KIRI label —
            # cara yang sama yang menyelesaikan field lesen. <<<
            return (self._ikon_geometri_remember_me(), "ikon")

        self.dismiss_native_alerts(first_timeout=1,
                                   context="remember-me toggle")
        el, jenis = _cuba_semua_tier()
        if el is not None:
            return (el, jenis)

        # Alert mungkin tiba LEPAS carian pertama (queue tak segerak) —
        # satu lagi cubaan defensif sebelum benar-benar mengalah.
        if self.dismiss_native_alerts(first_timeout=2,
                                      context="remember-me toggle retry"):
            el, jenis = _cuba_semua_tier()
            if el is not None:
                return (el, jenis)

        # bukti untuk pusingan seterusnya — apa sebenarnya ada di skrin
        try:
            import os as _os
            _os.makedirs("ui_dumps", exist_ok=True)
            with open(_os.path.join("ui_dumps",
                                    "t012_toggle_missing.xml"),
                      "w", encoding="utf-8") as f:
                f.write(self.driver.page_source)
            print("  [LOGIN] bukti: ui_dumps\\t012_toggle_missing.xml")
        except Exception:                                    # noqa: BLE001
            pass
        raise AssertionError(
            "FAIL: toggle Remember Me tidak ditemui — bukan CheckBox, "
            "bukan ikon MDI (U+F0131/U+F0132), tiada ikon geometri di "
            "kiri label REMEMBER ME, dan tiada alert asli menutup skrin")

    def _ikon_geometri_remember_me(self):
        """TextView ikon (teks 1-2 aksara) se-baris dan di kiri label
        REMEMBER ME; None jika tiada. Lihat nota tier geometri di
        _cari_toggle_remember_me."""
        try:
            label = self.find_element(
                (AppiumBy.ANDROID_UIAUTOMATOR,
                 'new UiSelector().text("REMEMBER ME")'), timeout=5)
            lr = label.rect
        except Exception:                                    # noqa: BLE001
            return None
        cy = lr["y"] + lr["height"] / 2.0
        calon = []
        for tv in self.driver.find_elements(
                AppiumBy.CLASS_NAME, "android.widget.TextView"):
            try:
                t = tv.text or ""
                r = tv.rect
            except Exception:                                # noqa: BLE001
                continue
            if (0 < len(t) <= 2
                    and abs((r["y"] + r["height"] / 2.0) - cy)
                    <= lr["height"]
                    and r["x"] < lr["x"]):
                calon.append((lr["x"] - r["x"], tv))
        if not calon:
            return None
        calon.sort(key=lambda c: c[0])
        return calon[0][1]

    def _remember_me_bertanda(self, el, jenis):
        if jenis == "checkbox":
            return (el.get_attribute("checked") or "").lower() == "true"
        t = (self._safe_text(el) or "") + (el.get_attribute("content-desc")
                                           or "")
        return self.REMEMBER_ME_IKON_TANDA in t

    def enable_remember_me(self):
        """v3 (T-012): tick the Remember Me toggle, verifying the
        checked state actually flipped (raw tap + retry -- same silent
        no-op protection as everywhere else in this app). 2026-08-24:
        menyokong kedua-dua CheckBox (build lama) dan ikon MDI (2.1.17
        hotfix) — lihat nota REMEMBER_ME_IKON_*."""
        import time
        el, jenis = self._cari_toggle_remember_me()
        awal = self._safe_text(el) or ""
        if self._remember_me_bertanda(el, jenis):
            print("  [LOGIN] Remember Me already checked")
            return True
        for attempt in range(3):
            self.tap_element(el)
            time.sleep(0.7)
            el, jenis = self._cari_toggle_remember_me()
            if self._remember_me_bertanda(el, jenis):
                print(f"  [LOGIN] Remember Me checked ({jenis}) — PASS")
                return True
            # Ikon geometri: aksara BERUBAH selepas tap = toggle
            # bertindak balas (aksara 'bertanda' build ini mungkin
            # bukan U+F0132). Fungsi sebenar Remember Me tetap
            # disahkan kemudian oleh get_login_field_values selepas
            # relaunch, jadi ini bukan pass buta.
            kini = self._safe_text(el) or ""
            if jenis == "ikon" and kini and kini != awal:
                print(f"  [LOGIN] Remember Me ikon berubah "
                      f"({awal!r} -> {kini!r}) — dianggap DITANDA; "
                      f"pengesahan sebenar oleh semakan relaunch")
                return True
            print(f"  [LOGIN] Remember Me still unchecked (attempt "
                  f"{attempt + 1}/3) -- re-tapping...")
            # >>> 2026-09-04 23:13 (run penuh, T-012 selepas T-011 Semak
            # Kemaskini): modal 'APLIKASI TELAH DIKEMASKINI' MUNCUL SEMULA
            # selepas SETIAP tap toggle (log "[VERSI] ... tekan OK" x3) --
            # OK berjaya tutup, tapi sentuhan seterusnya pada skrin login
            # mencetuskannya lagi (keadaan "semakan kemaskini" melekat
            # selepas T-011). T-012 LULUS bila jalan sendirian (state
            # segar). Tampal: selepas percubaan pertama gagal, relaunch
            # app sekali (state segar, modal muncul sekali sahaja & ditutup
            # oleh _force_relaunch_to_login) lalu cuba semula. <<<
            if attempt == 0:
                print("  [LOGIN] relaunch app (modal versi berulang selepas "
                      "Semak Kemaskini) sebelum cuba semula...")
                try:
                    self._force_relaunch_to_login()
                except Exception as e:                       # noqa: BLE001
                    print(f"  [LOGIN] relaunch gagal: {type(e).__name__}")
                el, jenis = self._cari_toggle_remember_me()
                awal = self._safe_text(el) or ""
                if self._remember_me_bertanda(el, jenis):
                    print("  [LOGIN] Remember Me already checked selepas "
                          "relaunch")
                    return True
        print("  [LOGIN] WARNING: Remember Me toggle never reported "
              "checked")
        return False

    def get_login_field_values(self):
        """v3 (T-012): read the current username/password field values
        (post-relaunch, to verify Remember Me retained them)."""
        u = self.find_element(self.USERNAME_FIELD, timeout=10).text or ""
        p = self.find_element(self.PASSWORD_FIELD, timeout=10).text or ""
        return u, p

    # ---- Actions ----

    def is_login_screen_displayed(self):
        """Check if login screen is visible by looking for title."""
        return self.is_element_present(self.APP_TITLE, timeout=10)

    def enter_username(self, username):
        """Type into the username field."""
        print(f"  [LOGIN] Entering username: {username}")
        el = self.wait_and_send_keys(self.USERNAME_FIELD, username)
        return el

    def enter_password(self, password):
        """Type into the password field."""
        print(f"  [LOGIN] Entering password: {'*' * len(password)}")
        el = self.wait_and_send_keys(self.PASSWORD_FIELD, password)
        return el

    def click_login(self):
        """Tap the LOGIN button. Hides the keyboard first (still up from
        typing the password) so the button isn't covered."""
        print("  [LOGIN] Clicking LOGIN button")
        self._hide_keyboard_if_shown()
        self.wait_and_click(self.LOGIN_BUTTON)

    def is_home_reached(self, timeout=15):
        """Check (without asserting) whether home screen was reached.

        Checks HOME_SCREEN_INDICATOR (a home-grid module button), NOT
        the hamburger icon -- confirmed via live run that the hamburger
        also exists on the login screen's app bar, so the old check
        reported 'login successful' while the app was still sitting on
        the login screen (the LOGIN tap had silently no-opped)."""
        return self.is_element_present(self.HOME_SCREEN_INDICATOR,
                                       timeout=timeout)

    def _pulih_skrin_login(self):
        """Pemulihan bila skrin login TIDAK kelihatan pada permulaan login.

        >>> DIBINA 2026-08-24. Konteks: run penuh pertama selepas lesen
        pulih — pelarasan 10/10 LULUS tetapi kesemua 36 TC ERROR 'Login
        screen not displayed'; CEO juga pernah melihat RN red-screen
        (TypeError, hermes) pada build ini. assert lama gagal terus tanpa
        cuba pulih dan tanpa bukti apa yang berada di skrin. Aliran:
        (1) dump XML sebagai bukti; (2) kesan RN red-screen -> log
        sebagai BUG APP + tekan ESC (dismiss); (3) salir native alert
        tertangguh; (4) relaunch bersih (yang sudah assert skrin login
        muncul semula). <<<
        """
        import os as _os
        import time as _time
        print("  [LOGIN] Skrin login TIDAK kelihatan -- forensik + "
              "pemulihan...")
        src = ""
        try:
            src = self.driver.page_source or ""
            _os.makedirs("ui_dumps", exist_ok=True)
            nama = _os.path.join(
                "ui_dumps", f"login_missing_{int(_time.time())}.xml")
            with open(nama, "w", encoding="utf-8") as f:
                f.write(src)
            print(f"  [LOGIN] bukti skrin disimpan: {nama}")
        except Exception:                                    # noqa: BLE001
            pass
        if ("TypeError" in src or "RedBox" in src
                or ("DISMISS" in src and "RELOAD" in src)):
            print("  [LOGIN] !! RN RED-SCREEN dikesan (crash JS dalam "
                  "app — BUG APP, laporkan kepada developer). Menekan "
                  "ESC untuk dismiss...")
            try:
                self.driver.press_keycode(111)               # ESC
                _time.sleep(1.5)
            except Exception:                                # noqa: BLE001
                pass
        try:
            self.dismiss_native_alerts(first_timeout=2,
                                       context="pulih-login")
        except Exception:                                    # noqa: BLE001
            pass
        if self.is_login_screen_displayed():
            print("  [LOGIN] Skrin login pulih tanpa relaunch")
            return
        print("  [LOGIN] Masih tiada skrin login -- relaunch bersih...")
        self._force_relaunch_to_login()

    def _tutup_prompt_kemaskini(self):
        """Tutup prompt kemaskini versi jika ia menutup skrin.

        >>> 2026-09-03 (run penuh 48TC): server kini menawarkan versi
        BARU, jadi RN modal 'versi terkini tersedia' (butang KEMUDIAN)
        muncul SENDIRI pada pelancaran app — bukan hanya dalam T-011.
        Ia RN modal, dismiss_native_alerts tidak nampak; tanpa handler
        ini setiap login selepasnya beku (CEO nampak popup di skrin).
        Kini mewakilkan ke base.tutup_prompt_versi yang menutup KEDUA
        varian (KEMUDIAN / 'TELAH DIKEMASKINI' OK). <<<"""
        return self.tutup_prompt_versi(context="login")

    def _force_relaunch_to_login(self):
        """Cold-restart the app and wait for the login screen."""
        from config import APP_PACKAGE
        import time
        self.driver.terminate_app(APP_PACKAGE)
        time.sleep(1)
        self.driver.activate_app(APP_PACKAGE)
        self._tutup_prompt_kemaskini()
        if not self.is_element_present(self.APP_TITLE, timeout=30):
            # prompt kemaskini mungkin baru render selepas splash
            self._tutup_prompt_kemaskini()
        assert self.is_element_present(self.APP_TITLE, timeout=15), \
            "FAIL: Login screen not reached after app relaunch"

    def login(self, username, password, _allow_relaunch_retry=True,
              _cuba_berjeda=3, _jeda_s=30):
        """Complete login flow: enter credentials and tap login.
        Raises AssertionError if home screen is not reached.

        Confirmed via live runs: when login happens right after the
        Menu Selaras popup was closed in-place (no app relaunch), the
        LOGIN tap can silently no-op -- most plausibly a leftover RN
        modal backdrop still swallowing touches -- while the exact same
        flow works every time from a cold start. Recovery ladder:
        drain any covering native alert, re-tap LOGIN with a raw
        coordinate tap, and finally relaunch the app (clean login
        screen guaranteed) and run the whole login once more.

        >>> RETRY BERJEDA — DIPORT DARI MBPG (2026-08-20). <<<
        Bukti MBPG run 7/8: selepas pm clear, app offline-first menolak
        kredensial SAH dengan 'Log Masuk Gagal | Nama pengguna atau
        kata laluan tidak sah' sehingga sync pengguna siap / keadaan
        pulih — dan MASA yang menyembuhkannya (login manual lulus minit
        kemudian). Bila dialog penolakan DILIHAT: tunggu `_jeda_s`,
        relaunch bersih, cuba semula sehingga `_cuba_berjeda` kali.
        Pakej app MBIP sama, jadi mekanisme sama diguna terus."""
        print("\n=== LOGIN FLOW ===")
        self._tutup_prompt_kemaskini()      # modal versi baru menutup skrin
        if not self.is_login_screen_displayed():
            self._pulih_skrin_login()
        print("  [LOGIN] Login screen is displayed — PASS")

        self.enter_username(username)
        self.enter_password(password)
        self.click_login()

        print("  [LOGIN] Waiting for home screen after login...")
        if not self.is_home_reached(timeout=20):
            # A native alert (late Selaras sync result, or a login error
            # popup) may be covering the screen -- while one is up,
            # UiAutomator only sees the dialog window. Drain (logging
            # what the alert said, which also surfaces genuine login
            # errors) and re-check.
            teks_alert = self.dismiss_native_alerts(
                first_timeout=3, context="login", kumpul=True)
            import re as _re
            ditolak = any(
                _re.search(r"log\s*masuk\s*gagal|kata\s*laluan\s*tidak"
                           r"\s*sah", t, _re.I)
                for t in (teks_alert or []) if isinstance(t, str))
            if ditolak:
                if _cuba_berjeda > 0:
                    import time as _t
                    print(f"  [LOGIN] kredensial DITOLAK — transien "
                          f"pasca-clear yang diketahui (bukti MBPG); "
                          f"tunggu {_jeda_s}s, relaunch, cuba semula "
                          f"({_cuba_berjeda} percubaan berjeda tinggal)...")
                    _t.sleep(_jeda_s)
                    self._force_relaunch_to_login()
                    return self.login(
                        username, password,
                        _allow_relaunch_retry=_allow_relaunch_retry,
                        _cuba_berjeda=_cuba_berjeda - 1,
                        _jeda_s=_jeda_s)
                raise AssertionError(
                    "FAIL: kredensial DITOLAK pada SETIAP percubaan "
                    "berjeda. Semak: (a) kata laluan di server, (b) sama "
                    "ada Selaras Pengguna Apps perlu berjaya dahulu "
                    "(jadual pengguna lokal kosong selepas clear).")
            if not self.is_home_reached(timeout=5):
                print("  [LOGIN] Home not reached -- re-tapping LOGIN "
                      "with a raw coordinate tap...")
                self._hide_keyboard_if_shown()
                try:
                    self.wait_and_tap(self.LOGIN_BUTTON, timeout=5)
                except Exception:
                    pass
                if not self.is_home_reached(timeout=15):
                    assert _allow_relaunch_retry, (
                        "FAIL: Home screen did not appear after login "
                        "(even after re-tap and a clean relaunch attempt)"
                    )
                    print("  [LOGIN] Still no home screen -- relaunching "
                          "the app for one clean login attempt...")
                    self._force_relaunch_to_login()
                    return self.login(username, password,
                                      _allow_relaunch_retry=False)
        print("  [LOGIN] Login successful — home screen reached — PASS")

    def handle_license_mismatch(self, internal_ip, external_ip, device_id,
                                 username, password):
        """Run the licensing/IP setup sub-flow, then relogin.
        Only needed if a normal login() does not reach the home screen.
        """
        print("\n=== LICENSE MISMATCH FLOW ===")

        print("  [LICENSE] Opening hamburger menu...")
        self.wait_and_click(self.HAMBURGER)

        print("  [LICENSE] Opening Tetapan Alamat IP...")
        self.wait_and_click(self.MENU_TETAPAN_ALAMAT_IP)

        print(f"  [LICENSE] Setting internal IP: {internal_ip}")
        self.fill_field_by_label(self.FIELD_INTERNAL_IP_LABEL, internal_ip)

        print(f"  [LICENSE] Setting external IP: {external_ip}")
        self.fill_field_by_label(self.FIELD_EXTERNAL_IP_LABEL, external_ip)

        print("  [LICENSE] Clicking Simpan...")
        self.wait_and_click(self.BUTTON_SIMPAN)

        print("  [LICENSE] Opening Tetapan Pelbagai...")
        self.wait_and_click(self.MENU_TETAPAN_PELBAGAI)

        print(f"  [LICENSE] Setting device ID: {device_id}")
        self.fill_field_by_label(self.FIELD_DEVICE_ID_LABEL, device_id)

        print("  [LICENSE] Clicking Simpan...")
        self.wait_and_click(self.BUTTON_SIMPAN)

        print("  [LICENSE] Waiting for 'Lesen sama' popup...")
        assert self.is_element_present(self.POPUP_LESEN_SAMA, timeout=10), \
            "FAIL: 'Lesen sama' popup did not appear"
        print("  [LICENSE] Popup visible — clicking OK...")
        self.wait_and_click(self.BUTTON_OK)

        print("  [LICENSE] Tapping outside popup to return to login...")
        # ASSUMPTION: tapping the app title area dismisses the popup context
        self.driver.tap([(540, 200)])
        import time
        time.sleep(1)

        print("  [LICENSE] Re-attempting login...")
        self.login(username, password)

    def login_with_license_fallback(self, username, password,
                                     internal_ip=None, external_ip=None,
                                     device_id=None):
        """Try a normal login first; if it fails, run the license setup
        sub-flow and retry. If internal_ip/external_ip/device_id are not
        provided, this will simply re-raise the original login failure.
        """
        try:
            self.login(username, password)
        except AssertionError as e:
            print(f"  [LOGIN] Initial login failed ({e})")
            if internal_ip and external_ip and device_id:
                self.handle_license_mismatch(
                    internal_ip, external_ip, device_id, username, password
                )
            else:
                raise

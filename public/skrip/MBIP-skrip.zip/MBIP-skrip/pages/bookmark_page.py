"""
Bookmark (Pilihan Kegemaran) flow — Page Object Model. v3-new (Phase 2).

Per the -005 sheets: on a kompaun form with the Kompaun section filled,
tap the book icon, name the bookmark, SIMPAN; then reopen the Pilihan
Kegemaran list, select the saved bookmark, and verify the fields
repopulate.

The book icon glyph is Material Icons U+E866 ("bookmark") -- confirmed
via live recon of the create form's Notis tab (recon_notistab_0.xml).
The bookmark popup itself has NOT been recon'd: this flow dumps page
source at each unknown step (same discipline as everywhere else).
"""

from appium.webdriver.common.appiumby import AppiumBy
from selenium.common.exceptions import TimeoutException
from pages.base_page import BasePage

_BOOK = ""


class BookmarkPage(BasePage):
    """Book icon -> save/select bookmark on a kompaun form."""

    ICON_CANDIDATES = [
        (AppiumBy.ACCESSIBILITY_ID, _BOOK),
        (AppiumBy.ANDROID_UIAUTOMATOR,
         f'new UiSelector().description("{_BOOK}")'),
        (AppiumBy.ANDROID_UIAUTOMATOR,
         f'new UiSelector().text("{_BOOK}")'),
    ]
    SIMPAN_LOCATORS = [
        (AppiumBy.ANDROID_UIAUTOMATOR,
         'new UiSelector().textMatches("(?i)\\s*simpan\\s*")'),
        (AppiumBy.ANDROID_UIAUTOMATOR,
         'new UiSelector().descriptionMatches("(?i)\\s*simpan\\s*")'),
    ]

    def _dump(self, name):
        try:
            import os
            os.makedirs("ui_dumps", exist_ok=True)
            path = os.path.join("ui_dumps", name)
            with open(path, "w", encoding="utf-8") as f:
                f.write(self.driver.page_source)
            print(f"  [BOOKMARK] DEBUG: page source dumped to {path}")
            return path
        except Exception:
            return "(dump failed)"

    def _scroll_up(self):
        """Scroll the form content UP (back toward the top). The book
        icon sits at the TOP of the Notis/Kompaun tab (confirmed via
        recon_notistab_0.xml), and after filling the kompaun codes the
        viewport is at the bottom -- confirmed live: the icon was
        'not found' until scrolling back up."""
        try:
            self._hide_keyboard_if_shown()
            size = self.driver.get_window_size()
            self.driver.execute_script('mobile: scrollGesture', {
                'left': int(size['width'] * 0.1),
                'top': int(size['height'] * 0.25),
                'width': int(size['width'] * 0.8),
                'height': int(size['height'] * 0.5),
                'direction': 'up',
                'percent': 0.8,
            })
            import time
            time.sleep(0.4)
            return True
        except Exception:
            return False

    def open_bookmark_popup(self):
        """Tap the book icon (verified: popup evidence = a new EditText
        count or a SIMPAN control appearing). Scrolls back to the top of
        the tab first if the icon isn't visible."""
        import time
        print("  [BOOKMARK] Opening the bookmark (book icon) popup...")
        icon = None
        for round_ in range(6):
            for loc in self.ICON_CANDIDATES:
                if self.is_element_present(loc, timeout=2):
                    icon = loc
                    break
            if icon is not None:
                break
            if not self._scroll_up():
                break
        if icon is None:
            path = self._dump("bookmark_icon_not_found.xml")
            raise TimeoutException(
                f"book icon (U+E866) not found on this form; see {path}")
        # Popup-open evidence: the PILIHAN KEGEMARAN title (confirmed
        # via live recon -- the popup is the bookmark LIST with PILIH/
        # HAPUS buttons; the previous SIMPAN-based check re-tapped
        # straight through the modal's full-screen backdrop).
        popup_title = (AppiumBy.ANDROID_UIAUTOMATOR,
                       'new UiSelector().text("PILIHAN KEGEMARAN")')
        for attempt in range(3):
            el = self.find_element(icon, timeout=5)
            self.tap_element(el)
            time.sleep(1.5)
            if self.is_element_present(popup_title, timeout=3):
                print("  [BOOKMARK] Pilihan Kegemaran popup open — PASS")
                self._dump("bookmark_popup.xml")
                return
            print(f"  [BOOKMARK] popup didn't open (attempt "
                  f"{attempt + 1}/3) -- re-tapping...")
        path = self._dump("bookmark_popup_never_opened.xml")
        raise TimeoutException(
            f"bookmark popup never opened after 3 taps; see {path}")

    def save_bookmark(self, name):
        """Type the bookmark name into the popup's name field and SIMPAN.

        KNOWN BUILD LIMITATION (confirmed via 3 live recon rounds,
        2026-07-16, dumps bm2_tap_popup/bookmark_popup_never_opened):
        on this build the PILIHAN KEGEMARAN popup offers ONLY a list
        with PILIH/HAPUS -- no name field and no SIMPAN, with or
        without the Kompaun section filled, and a long-press on the
        ribbon does nothing. The manual script's step 3 ("enter
        bookmark name in the provided field and click SIMPAN") cannot
        be performed; this raises with that diagnosis. (The tester's
        own P-005/K-005 'Actual Results' already note the retrieve not
        working, so the feature appears partially broken in-app.)"""
        import time
        print(f"  [BOOKMARK] Saving bookmark: {name}")
        target = None
        try:
            edits = self.driver.find_elements(
                AppiumBy.CLASS_NAME, "android.widget.EditText")
            for el in reversed(edits):
                t = el.text or ""
                # placeholder-ish or empty field = the name input
                if not t or "nama" in t.lower() or "name" in t.lower():
                    target = el
                    break
        except Exception:
            pass
        if target is None:
            path = self._dump("bookmark_name_field_missing.xml")
            raise AssertionError(
                f"bookmark save UI not available: the Pilihan Kegemaran "
                f"popup has no name field/SIMPAN on this build (only "
                f"PILIH/HAPUS) -- the manual script's save step cannot "
                f"be performed; see {path}")
        target.click()
        target.clear()
        self.driver.execute_script('mobile: type', {'text': name})
        # keep_keyboard semantics: this is a dismissible RN modal --
        # hide_keyboard can act like Back and close it (same lesson as
        # the Tarik Notis popup), so the keyboard stays up and SIMPAN is
        # tapped via raw coordinates.
        time.sleep(0.5)
        for simpan in self.SIMPAN_LOCATORS:
            if self.is_element_present(simpan, timeout=3):
                el = self.find_element(simpan, timeout=3)
                self.tap_element(el)
                time.sleep(1.5)
                self.dismiss_native_alerts(first_timeout=3,
                                           context="bookmark save")
                print("  [BOOKMARK] SIMPAN tapped")
                return
        path = self._dump("bookmark_simpan_missing.xml")
        raise TimeoutException(f"SIMPAN not found in the bookmark popup; "
                               f"see {path}")

    def select_bookmark(self, name):
        """Reopen the Pilihan Kegemaran list via the book icon and tap
        the saved bookmark row (verified tap: the row/popup must leave
        the screen)."""
        import time
        print(f"  [BOOKMARK] Reopening list and selecting: {name}")
        self.open_bookmark_popup()
        row = (AppiumBy.ANDROID_UIAUTOMATOR,
               f'new UiSelector().textContains("{name}")')
        if not self.is_element_present(row, timeout=5):
            path = self._dump("bookmark_row_missing.xml")
            raise TimeoutException(
                f"saved bookmark {name!r} not listed; see {path}")
        for attempt in range(3):
            try:
                el = self.find_element(row, timeout=3)
            except TimeoutException:
                return  # row gone -> selection registered
            self.tap_element(el)
            time.sleep(1.5)
            if not self.is_element_present(row, timeout=2):
                print("  [BOOKMARK] Bookmark selected — PASS")
                return
            print(f"  [BOOKMARK] row still showing (attempt "
                  f"{attempt + 1}/3) -- re-tapping...")
        # The list may keep the row visible while still applying the
        # selection -- close the popup and let the caller verify fields.
        print("  [BOOKMARK] WARNING: row still visible after taps -- "
              "closing popup and relying on field verification")
        if not self.close_popup_by_icon(timeout=3):
            self.press_back()

    def verify_fields_repopulated(self, expected_texts):
        """Assert each expected value is visible on the form again
        (find_element's scroll fallback handles values below the fold)."""
        import time
        time.sleep(1.5)
        missing = []
        for t in expected_texts:
            loc = (AppiumBy.ANDROID_UIAUTOMATOR,
                   f'new UiSelector().textContains("{t}")')
            try:
                self.find_element(loc, timeout=5)
            except TimeoutException:
                missing.append(t)
        if missing:
            path = self._dump("bookmark_fields_missing.xml")
            raise AssertionError(
                f"fields not repopulated from the bookmark: {missing}; "
                f"see {path}")
        print("  [BOOKMARK] All bookmarked fields repopulated — PASS")

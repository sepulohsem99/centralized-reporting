"""
Daftar Kompaun (Register Compound) page — Page Object Model.
Flow: Select jenis (popup) -> Tab Pesalah -> Tab Kompaun -> Tab Penerima ->
Confirmation -> Submit

Rebuilt from the user's step-by-step manual. Note: Penerima tab here uses
"No Pembantu Penguatkuasa" instead of Notis Amaran's "Arahan Tindakan".
"""

from appium.webdriver.common.appiumby import AppiumBy
from selenium.common.exceptions import TimeoutException
from pages.base_page import BasePage


class DaftarKompaunPage(BasePage):
    """Daftar Kompaun screen — jenis selection + 3-tab form."""

    # ---- Jenis Kompaun selection popup (appears right after opening menu) ----
    # Confirmed via live dump (recon 2026-07-15): the popup is titled
    # "PILIH KOMPAUN" and lists KOMPAUN PELBAGAI / KOMPAUN TRAFIK /
    # KOMPAUN LESEN / SITAAN (all caps).
    OPTION_KOMPAUN_PELBAGAI = (AppiumBy.ANDROID_UIAUTOMATOR,
                               'new UiSelector().textContains("Kompaun Pelbagai")')
    OPTION_KOMPAUN_TRAFIK = (AppiumBy.ANDROID_UIAUTOMATOR,
                             'new UiSelector().text("KOMPAUN TRAFIK")')

    # ---- Screen title (after jenis selected) ----
    SCREEN_TITLE = (AppiumBy.ANDROID_UIAUTOMATOR,
                    'new UiSelector().textContains("Pelbagai")')
    TRAFIK_SCREEN_TITLE = (AppiumBy.ANDROID_UIAUTOMATOR,
                           'new UiSelector().text("TRAFIK")')

    # ---- Kompaun Trafik: Pesalah tab (all confirmed via live recon
    # dumps, 2026-07-15) ----
    # Field placeholders/hints on this tab: NAMA PESALAH, NO K/P/SSM,
    # NO. KERETA, NO. CUKAI JALAN, JENIS KERETA, WARNA KERETA,
    # NO. PETAK, NO. KUPON. Below NO. KERETA sit two lookup buttons
    # side by side: an "ePBT" Button and an image-only clickable
    # ViewGroup wrapping the screen's sole ImageView -- that image IS
    # the MySIKAP lookup. A successful MySIKAP lookup populates NAMA
    # PESALAH + NO K/P/SSM and INSERTS a populated MAKLUMAT JALAN/
    # TAMAN/POSKOD/BANDAR/NEGERI block into the form (those address
    # fields don't exist in the layout before the lookup), pushing the
    # manual vehicle fields further down. The ePBT button must NOT be
    # tapped after MySIKAP: confirmed live that it wipes the populated
    # name/IC and even the typed plate.
    LABEL_TRAFIK_NO_KERETA = "NO. KERETA"
    LABEL_TRAFIK_WARNA_KERETA = "WARNA KERETA"
    BUTTON_MYSIKAP_IMAGE = (AppiumBy.ANDROID_UIAUTOMATOR,
                            'new UiSelector().className("android.widget.ImageView")'
                            '.instance(0)')
    FIELD_TRAFIK_NAMA_PESALAH = (AppiumBy.XPATH,
                                 '//android.widget.EditText[@hint="NAMA PESALAH"]')

    # ---- Kompaun Trafik: Kompaun tab quirks (confirmed via adb dumps
    # of the live form, 2026-07-15) ----
    # The tempoh field is PRE-FILLED with "21" on this form, so its
    # "MAKLUMAT KOMPAUN" placeholder never shows -- a label-text lookup
    # matches the section-header TextView instead, and the typed value
    # then lands in whatever field still has focus (observed live:
    # butiran ended up as "PANDU KERETA LAJU0"). Locate the EditText
    # positionally, as the header's next sibling.
    FIELD_TRAFIK_TEMPOH = (AppiumBy.XPATH,
                           '//android.widget.TextView[@text="MAKLUMAT KOMPAUN"]'
                           '/following-sibling::android.widget.EditText[1]')
    # Tier 1 (Keterangan Kod Kompaun) is PRE-SELECTED on the Trafik
    # form: the field already holds "PERINTAH LALULINTAS JALAN
    # (PERINTAH 39 )" (sic -- note the space before the paren) and no
    # "PILIH KOMPAUN" placeholder exists anywhere on the screen.
    TRAFIK_TIER1_PRESELECTED = (AppiumBy.ANDROID_UIAUTOMATOR,
                                'new UiSelector().className("android.widget.EditText")'
                                '.textContains("PERINTAH 39")')

    # ---- Tabs ----
    TAB_PESALAH = (AppiumBy.ACCESSIBILITY_ID, "PESALAH")
    TAB_KOMPAUN = (AppiumBy.ACCESSIBILITY_ID, "KOMPAUN")
    TAB_PENERIMA = (AppiumBy.ACCESSIBILITY_ID, "PENERIMA")

    # ---- Pesalah tab field labels ----
    LABEL_NAMA_PESALAH = "NAMA PESALAH"
    LABEL_NO_KP_SSM_KERETA = "NO KP/ SSM/ NO KERETA"
    LABEL_PESALAH_JALAN = "MAKLUMAT JALAN"
    LABEL_PESALAH_TAMAN = "MAKLUMAT TAMAN"
    LABEL_PESALAH_POSKOD = "MAKLUMAT POSKOD"
    LABEL_PESALAH_BANDAR = "MAKLUMAT BANDAR"
    LABEL_PESALAH_NEGERI = "MAKLUMAT NEGERI"

    # ---- Kompaun tab field labels ----
    LABEL_KOMPAUN_JALAN = "Maklumat Jalan"
    LABEL_KOMPAUN_TAMAN = "Maklumat Taman"
    LABEL_KOMPAUN_POSKOD = "Maklumat Poskod"
    LABEL_KOMPAUN_BANDAR = "Maklumat Bandar"
    LABEL_KOMPAUN_NEGERI = "Maklumat Negeri"
    LABEL_LOKASI_KESALAHAN = "LOKASI KESALAHAN"
    LABEL_BUTIRAN_KESALAHAN = "BUTIRAN KESALAHAN"
    LABEL_TEMPOH_NOTIS = "MAKLUMAT KOMPAUN"

    # ---- Kompaun code dropdowns ----
    PLACEHOLDER_PILIH_KOMPAUN = "PILIH KOMPAUN"
    PLACEHOLDER_PILIH_AKTA = "PILIH AKTA"
    PLACEHOLDER_PILIH_KESALAHAN = "PILIH KESALAHAN"

    # ---- Kadar Denda (amount) ----
    # Confirmed via live page-source dump (run 17, captured right after
    # the Kesalahan tier): despite the real test script listing this
    # alongside the dropdown tiers, "PILIH KADAR DENDA (RM):" is a
    # plain non-clickable TextView LABEL -- the actual input is the
    # numeric EditText directly under it (hint "ENTER AMAUN", preset to
    # "0", with MIN:/MAX: range hints tied to the picked Kesalahan).
    # Located via its hint (exact from the dump) -- UiSelector can't
    # match hints, XPath can.
    FIELD_KADAR_DENDA = (AppiumBy.XPATH,
                         '//android.widget.EditText[@hint="ENTER AMAUN"]')

    # ---- Camera ----
    BUTTON_OPEN_CAMERA = (AppiumBy.ANDROID_UIAUTOMATOR,
                          'new UiSelector().text("OPEN CAMERA")')
    # Confirmed via live UI dump: these are icon-font glyphs, not the
    # literal words "Snap"/"Tick" -- same convention as HAMBURGER in
    # base_page.py.  is the round shutter button,  is the
    # checkmark/confirm button.
    BUTTON_SNAP = (AppiumBy.ACCESSIBILITY_ID, "")
    BUTTON_TICK_CONFIRM = (AppiumBy.ACCESSIBILITY_ID, "")

    # ---- Penerima tab field labels ----
    LABEL_NO_PEMBANTU_PENGUATKUASA = "NO PEMBANTU PENGUATKUASA"
    LABEL_NAMA_PENERIMA = "NAMA PENERIMA"
    LABEL_NO_IC_PENERIMA = "NO IC PENERIMA"
    FIELD_OPEN_SIGNATURE = (AppiumBy.ANDROID_UIAUTOMATOR,
                            'new UiSelector().text("OPEN SIGNATURE")')

    # ---- Confirmation / result popups ----
    POPUP_SIMPAN_MAKLUMAT = (AppiumBy.ANDROID_UIAUTOMATOR,
                             'new UiSelector().textContains("Simpan maklumat")')
    POPUP_CETAK_KOMPAUN_PELBAGAI = (AppiumBy.ANDROID_UIAUTOMATOR,
                                    'new UiSelector().textContains("Cetak Kompaun Pelbagai")')

    # ========================================================================
    # Actions
    # ========================================================================

    def select_jenis_kompaun(self, jenis="Kompaun Pelbagai"):
        """Select the jenis kompaun from the popup shown right after
        opening the Daftar Kompaun menu."""
        print(f"\n  [DAFTAR KOMPAUN] Selecting jenis: {jenis}...")
        self.wait_and_click(self.OPTION_KOMPAUN_PELBAGAI)
        print("  [DAFTAR KOMPAUN] Jenis selected — PASS")

    def is_daftar_kompaun_screen_displayed(self):
        """Verify we are on the Daftar Kompaun (Pelbagai) screen."""
        return self.is_element_present(self.SCREEN_TITLE, timeout=10)

    # ---- Kompaun Trafik variant ----

    def select_jenis_kompaun_trafik(self):
        """Select KOMPAUN TRAFIK from the jenis popup, verifying the
        Trafik screen actually opened (raw tap + one retry -- same
        silent-no-op-tap protection as everywhere else)."""
        print("\n  [DAFTAR KOMPAUN] Selecting jenis: Kompaun Trafik...")
        self.wait_and_tap(self.OPTION_KOMPAUN_TRAFIK)
        if self.is_element_present(self.TRAFIK_SCREEN_TITLE, timeout=5):
            print("  [DAFTAR KOMPAUN] Jenis Trafik selected — PASS")
            return
        print("  [DAFTAR KOMPAUN] Trafik screen didn't open -- re-tapping...")
        self.wait_and_tap(self.OPTION_KOMPAUN_TRAFIK)
        assert self.is_element_present(self.TRAFIK_SCREEN_TITLE, timeout=10), \
            "FAIL: Kompaun Trafik screen did not open from the jenis popup"
        print("  [DAFTAR KOMPAUN] Jenis Trafik selected — PASS")

    def is_daftar_kompaun_trafik_screen_displayed(self):
        """Verify we are on the Daftar Kompaun (Trafik) screen."""
        return self.is_element_present(self.TRAFIK_SCREEN_TITLE, timeout=10)

    def _mysikap_populated(self, plate):
        """True once the MySIKAP lookup has filled NAMA PESALAH with an
        actual owner name -- not the placeholder, and not an echo of
        the typed plate (observed live: a mid-populate read returned
        the plate itself where the owner name landed moments later).
        While a native alert is up (e.g. a lookup-failure popup), the
        field isn't visible to UiAutomator at all -- that reads as
        'not populated', which is handled by the caller's
        drain-and-retry."""
        try:
            t = self.driver.find_element(*self.FIELD_TRAFIK_NAMA_PESALAH).text
            return (bool(t) and t != "NAMA PESALAH"
                    and t.replace(" ", "").upper()
                    != plate.replace(" ", "").upper())
        except Exception:
            return False

    def fill_pesalah_tab_trafik(self, data):
        """Fill the Kompaun Trafik Pesalah tab.
        data must contain: no_kereta, warna_kereta.

        Flow (per real test case MBIP-TC-K-001, layout confirmed via
        live recon dumps): type NO. KERETA -> tap the MySIKAP image
        button -> wait for the server lookup to populate NAMA PESALAH /
        NO K/P/SSM and insert the populated address block -> fill
        WARNA KERETA manually. NO. CUKAI JALAN / NO. PETAK / NO. KUPON
        are deliberately left blank ('-' placeholders in the real test
        data, i.e. optional)."""
        import time
        print("\n  [DAFTAR KOMPAUN] Filling Pesalah tab (Trafik)...")
        self.wait_and_click(self.TAB_PESALAH)

        print(f"  [DAFTAR KOMPAUN] Entering No. Kereta: {data['no_kereta']}")
        self.fill_field_by_label(self.LABEL_TRAFIK_NO_KERETA,
                                 data["no_kereta"])

        # WARNA KERETA is filled BEFORE the MySIKAP lookup, not after
        # as the test-script step order implies: the populate inserts
        # the address block and pushes this field below the fold, where
        # this form resists the standard scroll gesture (confirmed via
        # live run + adb swipe experiments). Pre-populate it's right on
        # screen. It's not a required field (no '*' marker), so even if
        # the populate re-render were to reset it, submission isn't
        # blocked -- and a best-effort verify/refill runs after the
        # populate anyway.
        print(f"  [DAFTAR KOMPAUN] Entering Warna Kereta: "
              f"{data['warna_kereta']}")
        self.fill_field_by_label(self.LABEL_TRAFIK_WARNA_KERETA,
                                 data["warna_kereta"])

        populated = False
        for attempt in range(3):
            print("  [DAFTAR KOMPAUN] Tapping MySIKAP (image button)...")
            img = self.find_element(self.BUTTON_MYSIKAP_IMAGE, timeout=10)
            self.tap_element(img)

            print("  [DAFTAR KOMPAUN] Waiting for MySIKAP auto-populate...")
            deadline = time.monotonic() + 25
            while time.monotonic() < deadline:
                if self._mysikap_populated(data["no_kereta"]):
                    populated = True
                    break
                time.sleep(1)
            if populated:
                break
            # A lookup-failure alert may be covering the form; drain it
            # (logging its message) before re-tapping.
            self.dismiss_native_alerts(first_timeout=2, context="MySIKAP")
            print(f"  [DAFTAR KOMPAUN] MySIKAP did not populate "
                  f"(attempt {attempt + 1}/3) -- retrying...")

        if not populated:
            dump_path = "debug_mysikap_populate.xml"
            try:
                with open(dump_path, "w", encoding="utf-8") as f:
                    f.write(self.driver.page_source)
                print(f"  [DAFTAR KOMPAUN] DEBUG: page source dumped to "
                      f"{dump_path}")
            except Exception:
                pass
            raise TimeoutException(
                f"MySIKAP lookup never populated NAMA PESALAH for plate "
                f"{data['no_kereta']}; see {dump_path}")

        nama = self.driver.find_element(*self.FIELD_TRAFIK_NAMA_PESALAH).text
        print(f"  [DAFTAR KOMPAUN] MySIKAP populated — owner: {nama} — PASS")

        # Best-effort: verify the pre-populate WARNA KERETA value
        # survived the populate re-render, refilling if it was reset.
        # Non-fatal if unreachable -- the populate pushes it below the
        # fold and this form resists the standard scroll gesture; the
        # only swipe shape observed to move it (via adb experiments)
        # is a slow low-start one, tried here once.
        import time as _time
        try:
            self.driver.swipe(540, 2200, 540, 800, 600)
            _time.sleep(0.5)
            warna_el = self.driver.find_element(
                AppiumBy.XPATH,
                '//android.widget.EditText[@hint="WARNA KERETA"]')
            if warna_el.text in ("", "WARNA KERETA"):
                print("  [DAFTAR KOMPAUN] Warna Kereta was reset by the "
                      "populate -- refilling...")
                warna_el.click()
                warna_el.clear()
                self.driver.execute_script(
                    'mobile: type', {'text': data["warna_kereta"]})
                self._hide_keyboard_if_shown()
            else:
                print(f"  [DAFTAR KOMPAUN] Warna Kereta survived the "
                      f"populate: '{warna_el.text}' — PASS")
        except Exception:
            print("  [DAFTAR KOMPAUN] WARNING: could not re-verify Warna "
                  "Kereta after the populate (field below the fold) -- "
                  "continuing; the field is optional (no '*' marker)")

        print("  [DAFTAR KOMPAUN] Pesalah tab (Trafik) filled — PASS")

    def _fill_and_pick_suggestion(self, label, value):
        """Type into an autocomplete field whose value MUST be picked
        from its suggestion list (free-typed text is rejected by form
        validation), then tap the matching suggestion row.

        The rows are plain TextViews (distinct from the EditText that
        holds the typed value, so the row locator can't accidentally
        match the field itself). Matched via textContains: the row can
        be longer than the typed value (observed live: typing "JOHOR"
        offers "JOHOR DARUL TAKZIM"). Tap verified with re-taps, same
        as every pick in this suite."""
        self.fill_field_by_label(label, value)
        row = (AppiumBy.ANDROID_UIAUTOMATOR,
               f'new UiSelector().className("android.widget.TextView")'
               f'.textContains("{value}")')
        import time
        if not self.is_element_present(row, timeout=5):
            print(f"  [DAFTAR KOMPAUN] WARNING: no suggestion row appeared "
                  f"for '{label}' -- leaving typed value as-is")
            return
        for attempt in range(3):
            try:
                el = self.find_element(row, timeout=3)
            except Exception:
                return  # row vanished -> pick registered
            picked = el.text
            self.tap_element(el)
            time.sleep(0.7)
            if not self.is_element_present(row, timeout=2):
                print(f"  [DAFTAR KOMPAUN] Picked suggestion '{picked}' "
                      f"for {label} — PASS")
                return
            print(f"  [DAFTAR KOMPAUN] Suggestion row still showing after "
                  f"tap (attempt {attempt + 1}/3) -- re-tapping...")
        print(f"  [DAFTAR KOMPAUN] WARNING: suggestion pick for '{label}' "
              f"never registered -- continuing (validation may reject)")

    def fill_kompaun_tab_direct(self, data):
        """Fill the Kompaun tab by typing full values directly into
        every field (no autocomplete interaction).

        Unlike the Pelbagai flow's partial-type-and-pick-suggestion,
        the Trafik test case (MBIP-TC-K-001) specifies exact literal
        values for the whole address block, so plain send_keys typing
        is both sufficient and deterministic -- it sets the value
        without firing the RN live-search, so no suggestion dropdown
        ever renders to interfere (same technique as the Pesalah tab's
        Taman field in the Pelbagai flow).
        data must contain: kompaun_jalan, kompaun_taman, kompaun_poskod,
        kompaun_bandar, kompaun_negeri, lokasi_kesalahan,
        butiran_kesalahan, tempoh_notis."""
        print("\n  [DAFTAR KOMPAUN] Filling Kompaun tab (direct values)...")
        jalan_locator = self._ci_label_locator(self.LABEL_KOMPAUN_JALAN)
        assert self.is_element_present(jalan_locator, timeout=10), \
            "Kompaun screen not visible after clicking Seterusnya"

        self.fill_field_by_label(self.LABEL_KOMPAUN_JALAN, data["kompaun_jalan"])
        # >>> 2026-08-27 (wave #1, K-001 FAIL): build hotfix membuang
        # sebahagian medan alamat tab-2 TRAFIK ('Maklumat Taman' tiada
        # — timeout 15s + skrol). Semua medan blok alamat kini
        # OPTIONAL-jika-tiada (presedan skip JENIS/WARNA di pesalah);
        # medan yang wujud tetap diisi seperti biasa. <<<
        def _isi_jika_ada(label, nilai, suggestion=False):
            loc = self._ci_label_locator(label)
            if not self.is_element_present(loc, timeout=4):
                print(f"  [DAFTAR KOMPAUN] '{label}' tiada dalam build "
                      f"ini — dilangkau (hotfix trafik)")
                return False
            if suggestion:
                self._fill_and_pick_suggestion(label, nilai)
            else:
                self.fill_field_by_label(label, nilai)
            return True

        _isi_jika_ada(self.LABEL_KOMPAUN_TAMAN, data["kompaun_taman"])
        # Bandar and Negeri REQUIRE picking from their suggestion list
        # -- confirmed via live validation alert on Seterusnya ("RALAT /
        # SILA PILIH BANDAR DARIPADA SENARAI.") after free-typing, and
        # via dump that typing fires their live-search (suggestion rows
        # render). Poskod is filled AFTER them in case a pick
        # auto-fills/overwrites it.
        _isi_jika_ada(self.LABEL_KOMPAUN_BANDAR, data["kompaun_bandar"],
                      suggestion=True)
        # Picking Bandar auto-fills Negeri (confirmed live: its
        # placeholder was gone immediately after the SKUDAI pick --
        # same side-effect as the Jalan pick on the Pelbagai tab) and
        # possibly Poskod. Only fill them if still blank.
        negeri_ph = self._ci_label_locator(self.LABEL_KOMPAUN_NEGERI)
        if self.is_element_present(negeri_ph, timeout=3):
            self._fill_and_pick_suggestion(self.LABEL_KOMPAUN_NEGERI,
                                           data["kompaun_negeri"])
        else:
            print("  [DAFTAR KOMPAUN] Maklumat Negeri auto-filled by the "
                  "Bandar pick -- skipping")
        if self.is_element_present(
                self._ci_label_locator(self.LABEL_KOMPAUN_POSKOD),
                timeout=3):
            self.fill_field_by_label_if_blank(self.LABEL_KOMPAUN_POSKOD,
                                              data["kompaun_poskod"])
        else:
            print("  [DAFTAR KOMPAUN] 'Maklumat Poskod' tiada — "
                  "dilangkau (hotfix trafik)")
        _isi_jika_ada(self.LABEL_LOKASI_KESALAHAN,
                      data["lokasi_kesalahan"])
        _isi_jika_ada(self.LABEL_BUTIRAN_KESALAHAN,
                      data["butiran_kesalahan"])

        # Tempoh: force-clear + verify + 0-21 range-check (see
        # _set_tempoh_verified) -- NOT a plain fill_field_by_label, whose
        # label lookup matches the "MAKLUMAT KOMPAUN" section-header on
        # this form and corrupts butiran.
        try:
            self._set_tempoh_verified(data["tempoh_notis"])
        except Exception as e:                               # noqa: BLE001
            print(f"  [DAFTAR KOMPAUN] tempoh dilangkau "
                  f"({type(e).__name__}) — hotfix trafik")

        print("  [DAFTAR KOMPAUN] Kompaun tab (direct) filled — PASS")

    # _locate_tempoh_el / _set_tempoh_verified now live in base_page (shared
    # by the Notis and Kompaun forms -- both use the "MAKLUMAT KOMPAUN"
    # header + sibling EditText). Callers here inherit them unchanged.

    def fill_kompaun_code_fields_trafik(self, data):
        """Kompaun code tiers on the TRAFIK form.

        Confirmed via adb dump of the live form: tier 1 (Keterangan Kod
        Kompaun) is pre-selected with the PERINTAH 39 perintah and has
        no PILIH KOMPAUN placeholder, so only Kod Akta and Kesalahan
        Kompaun are actually selectable, followed by the same Kadar
        Denda amount field as Pelbagai."""
        print("  [DAFTAR KOMPAUN] Selecting kompaun code dropdowns (Trafik)...")

        assert self.is_element_present(self.TRAFIK_TIER1_PRESELECTED,
                                       timeout=10), \
            ("FAIL: Keterangan Kod Kompaun is not pre-selected with the "
             "PERINTAH 39 perintah on the Trafik form")
        print("  [DAFTAR KOMPAUN] Tier 1 pre-selected (PERINTAH 39) — PASS")

        pilih_kesalahan = (AppiumBy.ANDROID_UIAUTOMATOR,
                           f'new UiSelector().text("{self.PLACEHOLDER_PILIH_KESALAHAN}")')
        self.select_dropdown_option_and_confirm(
            self.PLACEHOLDER_PILIH_AKTA, data["kod_akta"],
            confirm_locator=pilih_kesalahan)
        self.select_dropdown_option_and_confirm(
            self.PLACEHOLDER_PILIH_KESALAHAN, data["kesalahan_kompaun"],
            confirm_locator=self.BUTTON_OPEN_CAMERA)
        self.fill_kadar_denda(data["kadar_denda"])
        print("  [DAFTAR KOMPAUN] Kompaun code dropdowns (Trafik) selected — PASS")

    def is_submission_successful_trafik(self):
        """Judge the post-HANTAR outcome on the Trafik flow.

        The Cetak Kompaun (print receipt) step is SKIPPED for Kompaun
        Trafik -- confirmed by the user: the post-submit native alert
        'Ralat / No data found for the provided parameters.' is the
        cetak/receipt lookup coming up empty, NOT the submission
        failing. So: take the receipt popup if some environment does
        show it, otherwise dismiss whatever alert follows HANTAR
        (logging its message) and judge success by the submission form
        actually having closed (MENYERAHKAN gone)."""
        cetak = (AppiumBy.ANDROID_UIAUTOMATOR,
                 'new UiSelector().textMatches("(?i).*cetak kompaun.*")')
        if self.is_element_present(cetak, timeout=15):
            print("  [DAFTAR KOMPAUN] Trafik submission successful — "
                  "receipt popup visible — PASS")
            self.read_record_number()  # capture no_kompaun before closing
            self.close_success_popup()
            return True

        # Expected Trafik path: dismiss the post-submit alert (cetak
        # lookup error) and any queued behind it.
        self.dismiss_native_alerts(first_timeout=20,
                                   context="Trafik submission result")
        import time
        time.sleep(1)

        if not self.is_element_present(self.BUTTON_MENYERAHKAN, timeout=5):
            print("  [DAFTAR KOMPAUN] Trafik submission successful — form "
                  "closed (cetak receipt skipped by design) — PASS")
            return True

        try:
            with open("debug_trafik_submit.xml", "w", encoding="utf-8") as f:
                f.write(self.driver.page_source)
            print("  [DAFTAR KOMPAUN] DEBUG: page source dumped to "
                  "debug_trafik_submit.xml")
        except Exception:
            pass
        print("  [DAFTAR KOMPAUN] WARNING: submission form still open "
              "after HANTAR -- submission did not go through")
        return False

    # =====================================================================
    # KOMPAUN TRAFIK — build hotfix 2026-08-20 (v2)
    # =====================================================================
    # Sumber kebenaran: source APK `ies_react_v1_source_20260820mbip
    # hotfix kompaun pelbagai ft kompaun trafik`, disemak baris demi
    # baris pada 2026-08-21 (bukan recon device — server production
    # down, jadi kod dibina dari sumber dan disahkan pada run pertama).
    #
    # Apa yang HOTFIX ubah pada borang Trafik:
    #   * Tier-1 (Keterangan Kod Kompaun) TIDAK lagi terkunci pada
    #     PERINTAH 39. Query kini `WHERE jeniskod IN ('K','P')` — senarai
    #     kod Letak Kereta + PELBAGAI — dan komponen AUTO-PILIH item
    #     PERTAMA (ikut abjad keterangan) lalu auto-fetch akta.
    #     (kompaunDropdownLetakKereta.js:99-137)
    #   * Kadar denda: selepas kesalahan dipilih, medan AUTO-ISI dengan
    #     amounmax; teks "MIN: x" / "MAX: y" dirender; validasi onBlur
    #     memaparkan toast "RALAT ! KADAR KOMPAUN MESTI MELEBIHI/KURANG
    #     DARI ..." dan app sendiri clamp nilai. (:270-310, :385-405)
    #   * Data ujian CEO 2026-08-21 (reports/DATA-UJIAN-KOMPAUN-TRAFIK-
    #     MBIP.md): tier1="Akta Jalan Parit dan Bangunan ( Akta 13)",
    #     akta="62- Akta jalan parit dan bangunan", kesalahan=PILIH
    #     BARIS PERTAMA (2 pilihan dijangka), kadar sasaran 200 clamp
    #     ke julat.

    def _medan_ikut_hint(self, hint, timeout=5, skrol=False):
        """EditText dropdown/medan dikesan melalui hint (XPath sahaja
        boleh padan hint). Pulangkan elemen atau None.

        >>> 2026-08-27 (dump clickfail validasi #6): medan BAWAH FOLD
        borang Trafik (JENIS/WARNA/PETAK/KUPON) tidak dirender oleh RN
        sehingga diskrol — XPath hanya nampak nod yang dirender, jadi
        lookup pulang None secara senyap dan WARNA KERETA (WAJIB)
        tertinggal kosong -> modal 'MAKLUMAT TIDAK LENGKAP' menyekat
        SETERUSNYA. skrol=True menambah swipe-retry; JANGAN guna
        semasa senarai dropdown sedang terbuka. <<<"""
        loc = (AppiumBy.XPATH,
               f'//android.widget.EditText[@hint="{hint}"]')
        if self.is_element_present(loc, timeout=timeout):
            return self.driver.find_element(*loc)
        if skrol:
            for _ in range(4):
                if not self._swipe_atas_sebenar():
                    break
                if self.is_element_present(loc, timeout=2):
                    return self.driver.find_element(*loc)
        return None

    def isi_alamat_trafik_v2(self, data):
        """Blok alamat tab-2 TRAFIK build hotfix — ikut HINT, dan JALAN
        WAJIB dipilih dari senarai.

        >>> 2026-08-27 (rerun #3 K-001 + dump trafik_tab2_rehat):
        1. Build hotfix MEMBUANG label TextView blok alamat — medan
           hanya dikenal pasti melalui @hint ('Maklumat Jalan' dll),
           jadi SEMUA lookup _ci_label_locator gagal (AssertionError
           run #2/#3). Blok ini di ATAS tab-2 (y 477-1407), nampak
           tanpa skrol.
        2. Medan datang PRA-ISI ('6 LORONG RIA'/'KAMPUNG MELAYU
           MAJIDI'/'JOHOR BAHRU') tetapi nilai itu TIADA dalam
           local_ekpn_jalan — kod bandar dalaman kekal kosong dan
           Seterusnya ditolak: 'SILA PILIH BANDAR DARIPADA SENARAI.'
        3. Bundle Hermes: lookup jalan JOIN taman JOIN bandar — memilih
           baris jalan men-set kod taman+bandar+poskod sekali gus.
           'JALAN JAYA 1' (Excel K-001) DISAHKAN wujud dalam DB
           peranti -> TAMAN JAYA / SKUDAI ([PENEMUAN-DATA]: Excel
           kata TAMAN JAYA 1; DB kata TAMAN JAYA — auto-isi DB yang
           dipakai). <<<"""
        import time
        print("\n  [DAFTAR KOMPAUN] Blok alamat TRAFIK (ikut hint)...")
        jalan = self._medan_ikut_hint("Maklumat Jalan", timeout=8,
                                      skrol=True)
        assert jalan is not None, \
            "medan hint 'Maklumat Jalan' tidak dijumpai di tab-2"
        sasaran = data["kompaun_jalan"]
        pra = (jalan.text or "").strip()
        print(f"  [TRAFIK-V2] Jalan pra-isi: '{pra}' -> taip+pilih: "
              f"'{sasaran}'")
        jalan.click()          # el.click() MEMFOKUS EditText (terbukti)
        time.sleep(0.5)
        try:
            jalan.clear()
        except Exception:                                    # noqa: BLE001
            pass
        if (jalan.text or "").strip() not in ("", "Maklumat Jalan"):
            for _ in range(40):          # padam manual kalau clear gagal
                self.driver.press_keycode(67)                # DEL
            time.sleep(0.4)
        jalan.send_keys(sasaran)
        time.sleep(1.0)

        # Baris cadangan: TextView (bukan EditText — elak padan medan
        # sendiri) ATAU baris content-desc panjang (corak tier). Baris
        # mungkin render LEWAT — poll, cuba hide-keyboard pertengahan
        # (senarai inline notis terbukti selamat daripada hide-kb).
        from appium.webdriver.common.appiumby import AppiumBy
        calon_loc = [
            (AppiumBy.ANDROID_UIAUTOMATOR,
             f'new UiSelector().className("android.widget.TextView")'
             f'.textContains("{sasaran}")'),
            (AppiumBy.ANDROID_UIAUTOMATOR,
             f'new UiSelector().descriptionContains("{sasaran}")'),
        ]
        dipilih = False
        for pusingan in range(8):
            for loc in calon_loc:
                if not self.is_element_present(loc, timeout=1):
                    continue
                el = self.driver.find_element(*loc)
                desc = (el.get_attribute("content-desc") or el.text
                        or "")
                if desc.upper().endswith(", BACK"):
                    continue
                print(f"  [TRAFIK-V2] baris jalan: '{desc[:60]}' — tap")
                self.tap_element(el)
                time.sleep(1.0)
                dipilih = True
                break
            if dipilih:
                break
            if pusingan == 3:
                print("  [TRAFIK-V2] baris belum render — "
                      "hide keyboard dan poll lagi")
                self._hide_keyboard_if_shown()
            time.sleep(0.8)
        assert dipilih, (f"tiada baris cadangan jalan untuk "
                         f"'{sasaran}' — kod bandar tidak akan di-set")

        # Bukti pick berdaftar: taman/bandar auto-berubah (JOIN DB:
        # JALAN JAYA 1 -> TAMAN JAYA / SKUDAI). Kemaskini paparan RN
        # boleh LEWAT — poll sehingga ~6s; kalau kekal nilai lama,
        # cuba tap baris SEKALI lagi (tap mungkin tidak berdaftar).
        def _baca(hint):
            el = self._medan_ikut_hint(hint, timeout=3)
            return (el.text or "").strip() if el else "<tiada>"

        for cubaan in range(2):
            berubah = False
            for _ in range(6):
                time.sleep(1.0)
                if "SKUDAI" in _baca("Maklumat Bandar").upper() or \
                        "TAMAN JAYA" in _baca("Maklumat Taman").upper():
                    berubah = True
                    break
            if berubah:
                break
            if cubaan == 0:
                print("  [TRAFIK-V2] taman/bandar belum berubah — "
                      "tap baris jalan SEKALI lagi")
                for loc in calon_loc:
                    if self.is_element_present(loc, timeout=2):
                        self.tap_element(self.driver.find_element(*loc))
                        time.sleep(1.0)
                        break
        for hint in ("Maklumat Taman", "Maklumat Bandar",
                     "Maklumat Poskod", "Maklumat Negeri"):
            print(f"  [TRAFIK-V2] {hint}: '{_baca(hint)}'"
                  f" (selepas pick jalan)")
        if not berubah:
            print("  [TRAFIK-V2] WARNING: paparan taman/bandar tidak "
                  "berubah — kod bandar mungkin masih kosong; gate "
                  "Seterusnya akan jadi oracle")
        self._hide_keyboard_if_shown()

        # LOKASI + BUTIRAN + TEMPOH — semua ikut hint, taip terus.
        for hint, kunci in (("LOKASI KESALAHAN", "lokasi_kesalahan"),
                            ("BUTIRAN KESALAHAN", "butiran_kesalahan")):
            # Keyboard dari medan sebelumnya menutup medan bawah —
            # RN tidak render nod belakang keyboard (run #4: BUTIRAN
            # 'tiada' sejurus selepas taip LOKASI). Sorok dahulu.
            self._hide_keyboard_if_shown()
            el = self._medan_ikut_hint(hint, timeout=5, skrol=True)
            if el is None:
                print(f"  [TRAFIK-V2] medan hint '{hint}' tiada — "
                      f"dilangkau")
                continue
            el.click()
            time.sleep(0.3)
            try:
                el.clear()
            except Exception:                                # noqa: BLE001
                pass
            el.send_keys(data[kunci])
            print(f"  [TRAFIK-V2] {hint} = '{data[kunci][:50]}'")
        self._hide_keyboard_if_shown()
        tempoh = self._medan_ikut_hint("TEMPOH KOMPAUN", timeout=5,
                                       skrol=True)
        if tempoh is not None:
            nilai = str(data.get("tempoh_kompaun",
                                 data.get("tempoh_notis", "2")))
            tempoh.click()
            time.sleep(0.3)
            try:
                tempoh.clear()
            except Exception:                                # noqa: BLE001
                pass
            if (tempoh.text or "").strip() not in ("", "TEMPOH KOMPAUN"):
                for _ in range(6):
                    self.driver.press_keycode(67)
            tempoh.send_keys(nilai)
            print(f"  [TRAFIK-V2] TEMPOH KOMPAUN pra-isi diganti -> "
                  f"'{nilai}'")
        self._hide_keyboard_if_shown()
        print("  [DAFTAR KOMPAUN] Blok alamat TRAFIK selesai — PASS")

    def pilih_tier_ikut_hint(self, hint, sasaran, confirm_locator=None):
        """Pilih nilai pada dropdown autocomplete yang medannya MUNGKIN
        sudah berisi (auto-select build baru) — hint kekal walaupun teks
        berubah, jadi kesan ikut hint, kosongkan, taip prefix, tap baris
        ikut content-desc ends-with (mekanisme terbukti
        select_dropdown_option), baca-balik."""
        import re
        import time
        el = self._medan_ikut_hint(hint, timeout=8, skrol=True)
        if el is None:
            raise TimeoutException(
                f"medan dropdown hint '{hint}' tidak dijumpai")
        semasa = (el.text or "").strip()
        print(f"  [TRAFIK-V2] '{hint}' semasa: '{semasa[:50]}' -> "
              f"sasaran: '{sasaran[:50]}'")
        if sasaran.upper() in semasa.upper() and semasa:
            print("  [TRAFIK-V2] nilai semasa sudah padan — tiada tulis")
            return semasa
        self.tap_element(el)
        time.sleep(0.4)
        try:
            el.clear()
        except Exception:                                    # noqa: BLE001
            pass
        self.driver.execute_script('mobile: type', {'text': sasaran[:25]})
        time.sleep(0.8)
        esc = re.escape(sasaran[:25].upper())
        for row in ((AppiumBy.ANDROID_UIAUTOMATOR,
                     f'new UiSelector().descriptionMatches("(?i).*{esc}.*")'),
                    (AppiumBy.ANDROID_UIAUTOMATOR,
                     f'new UiSelector().className("android.widget.TextView")'
                     f'.textMatches("(?i).*{esc}.*")')):
            if self.is_element_present(row, timeout=4):
                self.tap_element(self.driver.find_element(*row))
                break
        else:
            # >>> 2026-08-27 (dump trafik_kesalahan_kosong #14):
            # "auto-select" run #13 = FALSE POSITIVE — baris cadangan
            # 'AKTA JALAN/PARIT/BANGUNAN' masih TERBUKA di [135,795]
            # dalam dump; medan cuma memegang teks yang KITA taip dan
            # pemilihan tidak pernah didaftar (akta anak dapat 'Tiada
            # rekod'). Baris render LEWAT/selepas hide-keyboard — jadi:
            # hide keyboard, POLL baris semula, dan TAP kalau muncul.
            # Hanya terima "terdaftar" jika baris benar-benar tiada. <<<
            self._hide_keyboard_if_shown()
            time.sleep(0.8)
            baris_lewat = None
            for _p in range(3):
                for row in ((AppiumBy.ANDROID_UIAUTOMATOR,
                             f'new UiSelector().descriptionMatches('
                             f'"(?i).*{esc}.*")'),
                            (AppiumBy.ANDROID_UIAUTOMATOR,
                             f'new UiSelector().className('
                             f'"android.widget.TextView")'
                             f'.textMatches("(?i).*{esc}.*")')):
                    if self.is_element_present(row, timeout=2):
                        baris_lewat = row
                        break
                if baris_lewat:
                    break
                time.sleep(1.0)
            if baris_lewat:
                print(f"  [TRAFIK-V2] baris render LEWAT — tap "
                      f"sekarang: '{sasaran[:40]}'")
                self.tap_element(self.driver.find_element(*baris_lewat))
                self._hide_keyboard_if_shown()
                time.sleep(0.5)
                el2y = self._medan_ikut_hint(hint, timeout=5)
                terpilih_y = (el2y.text or "").strip() if el2y else ""
                print(f"  [TRAFIK-V2] '{hint}' = '{terpilih_y[:60]}' "
                      f"(tap baris lewat)")
                return terpilih_y
            el2x = self._medan_ikut_hint(hint, timeout=3)
            terpilih_x = (el2x.text or "").strip() if el2x else ""
            if terpilih_x and sasaran[:25].upper() in terpilih_x.upper():
                print(f"  [TRAFIK-V2] '{hint}' nilai TERDAFTAR SENDIRI "
                      f"(auto-select): '{terpilih_x[:60]}'")
                return terpilih_x
            raise TimeoutException(
                f"baris '{sasaran[:40]}' tidak muncul dalam senarai "
                f"'{hint}' (medan semasa: '{terpilih_x[:40]}')")
        self._hide_keyboard_if_shown()
        time.sleep(0.5)
        el2 = self._medan_ikut_hint(hint, timeout=5)
        terpilih = (el2.text or "").strip() if el2 else ""
        print(f"  [TRAFIK-V2] '{hint}' = '{terpilih[:60]}' "
              f"(disahkan baca-balik)")
        if confirm_locator and not self.is_element_present(
                confirm_locator, timeout=6):
            self._scroll_down()
        return terpilih

    def pilih_kesalahan_pertama(self):
        """KEPUTUSAN CEO 2026-08-21: dropdown kesalahan dijangka keluar
        2 pilihan — 'pilih yang atas'. Buka senarai TANPA menaip penapis,
        tap BARIS PERTAMA (ViewGroup ber-content-desc — input EditText
        desc kosong, jadi mustahil tersasar), baca-balik dan REKOD teks
        sebenar sebagai bukti."""
        import time
        el = self._medan_ikut_hint(self.PLACEHOLDER_PILIH_KESALAHAN,
                                   timeout=8)
        if el is None:
            raise TimeoutException("medan PILIH KESALAHAN tidak dijumpai")
        self.tap_element(el)
        time.sleep(1.0)

        # >>> 2026-08-27 (trafik #10): 'MainLetakKereta, back' (butang
        # back bar atas) pernah TERPILIH sebagai "baris pertama" —
        # menekan BACK keluar borang. Tapis ', back' + tab/butang +
        # hadkan kepada baris DI/BAWAH medan kesalahan. <<<
        try:
            _y_medan = el.rect["y"]
        except Exception:                                    # noqa: BLE001
            _y_medan = None
        buang = {"PESALAH", "KOMPAUN", "PENERIMA", "SETERUSNYA",
                 "OPEN CAMERA", "MENYERAHKAN"}

        def _calon():
            keep = []
            for r in self.driver.find_elements(
                    AppiumBy.ANDROID_UIAUTOMATOR,
                    'new UiSelector().descriptionMatches("(?s).{5}.*")'):
                try:
                    d = (r.get_attribute("content-desc") or "").strip()
                    du = d.upper()
                    if du in buang or ", BACK" in du:
                        continue
                    if _y_medan is not None and \
                            r.rect["y"] < _y_medan - 60:
                        continue
                    keep.append(r)
                except Exception:                            # noqa: BLE001
                    continue
            return keep

        # >>> 2026-08-27 (log #13): run #10 menemui 2 baris DENGAN
        # keyboard terbuka; run #12-13 (selepas hide-keyboard
        # ditambah) 0 baris — pada dropdown trafik ini hide_keyboard
        # bertindak seperti BACK yang MENUTUP senarai (amaran modal RN
        # CLAUDE.md; berbeza dgn senarai inline notis dd_07/dd_23).
        # Jangan andai: cuba (1) keyboard terbuka, (2) hide keyboard,
        # (3) taip 'A' + poll, (4) hide + poll — berhenti pada mana-
        # mana yang menghasilkan baris. <<<
        calon = []
        for _poll in range(4):                    # (1) keyboard terbuka
            calon = _calon()
            if calon:
                break
            time.sleep(1.0)
        if not calon:                             # (2) hide keyboard
            self._hide_keyboard_if_shown()
            time.sleep(0.8)
            for _poll in range(3):
                calon = _calon()
                if calon:
                    break
                time.sleep(1.0)
        if not calon:                             # (3) taip 'A'
            try:
                self.tap_element(el)
                time.sleep(0.5)
                self.driver.execute_script('mobile: type', {'text': 'A'})
                time.sleep(0.8)
            except Exception:                                # noqa: BLE001
                pass
            for _poll in range(3):
                calon = _calon()
                if calon:
                    break
                time.sleep(1.0)
        if not calon:                             # (4) hide + poll
            self._hide_keyboard_if_shown()
            time.sleep(0.8)
            for _poll in range(3):
                calon = _calon()
                if calon:
                    break
                time.sleep(1.0)
        if not calon:
            # Bukti untuk pusingan seterusnya.
            try:
                import os as _os3
                _os3.makedirs("ui_dumps", exist_ok=True)
                _p3 = _os3.path.join("ui_dumps",
                                     "trafik_kesalahan_kosong.xml")
                with open(_p3, "w", encoding="utf-8") as _f3:
                    _f3.write(self.driver.page_source)
                print(f"  [TRAFIK-V2] dump -> {_p3}")
            except Exception:                                # noqa: BLE001
                pass
            raise TimeoutException(
                "senarai kesalahan tidak merender sebarang baris")
        pertama = calon[0]
        teks = (pertama.get_attribute("content-desc") or "").strip()
        print(f"  [TRAFIK-V2] kesalahan: {len(calon)} baris — pilih "
              f"ATAS (keputusan CEO): '{teks[:70]}'")
        self.tap_element(pertama)
        self._hide_keyboard_if_shown()
        time.sleep(0.5)
        el2 = self._medan_ikut_hint(self.PLACEHOLDER_PILIH_KESALAHAN,
                                    timeout=5)
        terpilih = (el2.text or "").strip() if el2 else teks
        print(f"  [TRAFIK-V2] kesalahan terpilih = '{terpilih[:70]}'")
        return terpilih

    def isi_kadar_denda_julat(self, sasaran=200):
        """Kadar denda dengan kesedaran julat (build hotfix).

        Sumber: selepas kesalahan dipilih app AUTO-ISI medan dengan
        amounmax dan merender teks 'MIN: x' / 'MAX: y'. Logik (advice
        diterima CEO): baca julat -> clamp sasaran ke [min,max] ->
        taip -> blur -> BACA-BALIK (validasi onBlur app boleh clamp
        sendiri; nilai akhir medan ialah kebenaran). Rekod semuanya."""
        import re
        import time
        jmin = jmax = None
        for lbl, nama in (("MIN:", "min"), ("MAX:", "max")):
            loc = (AppiumBy.ANDROID_UIAUTOMATOR,
                   f'new UiSelector().textStartsWith("{lbl}")')
            if self.is_element_present(loc, timeout=4):
                t = self.driver.find_element(*loc).text
                m = re.search(r"(\d+)", t or "")
                if m:
                    if nama == "min":
                        jmin = int(m.group(1))
                    else:
                        jmax = int(m.group(1))
        nilai = int(sasaran)
        if jmin is not None and nilai < jmin:
            nilai = jmin
        if jmax is not None and nilai > jmax:
            nilai = jmax
        if nilai != int(sasaran):
            print(f"  [TRAFIK-V2] kadar denda {sasaran} LUAR julat "
                  f"[{jmin},{jmax}] -> clamp ke {nilai}")
        else:
            print(f"  [TRAFIK-V2] kadar denda {nilai} dalam julat "
                  f"[{jmin},{jmax}]")
        el = self._medan_ikut_hint("ENTER AMAUN", timeout=6)
        if el is None:
            raise TimeoutException("medan ENTER AMAUN tidak dijumpai")
        self.tap_element(el)
        try:
            el.clear()
        except Exception:                                    # noqa: BLE001
            pass
        self.driver.execute_script('mobile: type', {'text': str(nilai)})
        self._hide_keyboard_if_shown()   # blur -> cetuskan validasi app
        time.sleep(0.8)
        el2 = self._medan_ikut_hint("ENTER AMAUN", timeout=4)
        akhir = (el2.text or "").strip() if el2 else "?"
        print(f"  [TRAFIK-V2] kadar denda AKHIR (selepas validasi app) "
              f"= '{akhir}' (julat MIN={jmin} MAX={jmax})")
        return {"sasaran": sasaran, "ditaip": nilai, "akhir": akhir,
                "min": jmin, "max": jmax}

    def baca_suis_operasi(self):
        """Suis OPERASI (SwitchButton, pegawaiForm.js:830) — BIAR
        DEFAULT, baca & rekod sahaja (keputusan CEO 2026-08-21)."""
        for loc in ((AppiumBy.CLASS_NAME, "android.widget.Switch"),
                    (AppiumBy.ANDROID_UIAUTOMATOR,
                     'new UiSelector().textContains("OPERASI")')):
            if self.is_element_present(loc, timeout=3):
                el = self.driver.find_element(*loc)
                keadaan = el.get_attribute("checked")
                print(f"  [TRAFIK-V2] suis OPERASI: checked={keadaan} "
                      f"(TIDAK diubah)")
                return keadaan
        print("  [TRAFIK-V2] suis OPERASI tidak kelihatan pada viewport "
              "— direkod sebagai tidak-kelihatan, tidak diubah")
        return None

    def fill_pesalah_tab_trafik_v2(self, data):
        """Tab MAKLUMAT PESALAH borang TRAFIK — build hotfix, data CEO
        2026-08-21 (reports/DATA-UJIAN-KOMPAUN-TRAFIK-MBIP.md).

        Urutan butang KRITIKAL (recon live 2026-07-15, masih terpakai):
        ePBT MEMADAM data yang JPJ/MySIKAP isi — termasuk plat yang
        ditaip. Maka: taip plat -> ePBT DULU -> JPJ KEMUDIAN ->
        baca-balik -> baru taip/override medan lain. Butang JPJ ialah
        TouchableOpacity membalut IMEJ logo mySIKAP (component-
        getBtnJpj.js) — locator BUTTON_MYSIKAP_IMAGE lama masih sah.
        JPJ memanggil api.ovrs.com.my TERUS (bukan server PBT)."""
        import time
        print("\n  [DAFTAR KOMPAUN] Tab Pesalah TRAFIK (build hotfix)...")
        self.wait_and_click(self.TAB_PESALAH)

        def taip_ikut_hint(hint, nilai, wajib=True, skrol=True):
            el = self._medan_ikut_hint(hint, timeout=6, skrol=skrol)
            if el is None:
                msg = f"medan hint '{hint}' tidak dijumpai"
                if wajib:
                    raise TimeoutException(msg)
                print(f"  [TRAFIK-V2] {msg} — dilangkau (tidak wajib)")
                return None
            self.tap_element(el)
            try:
                el.clear()
            except Exception:                                # noqa: BLE001
                pass
            self.driver.execute_script('mobile: type', {'text': str(nilai)})
            self._hide_keyboard_if_shown()
            el2 = self._medan_ikut_hint(hint, timeout=3)
            baca = (el2.text or "").strip() if el2 else "?"
            print(f"  [TRAFIK-V2] {hint} = '{baca[:40]}'")
            return baca

        taip_ikut_hint("NO. KERETA", data["no_kereta"])

        # ePBT dahulu (padam apa sahaja auto-isi), JPJ selepasnya.
        epbt = (AppiumBy.ANDROID_UIAUTOMATOR,
                'new UiSelector().text("ePBT")')
        if self.is_element_present(epbt, timeout=4):
            print("  [TRAFIK-V2] tekan ePBT (dahulu — ia memadam "
                  "auto-isi)...")
            self.tap_element(self.driver.find_element(*epbt))
            time.sleep(3)
            self.dismiss_native_alerts(first_timeout=2, context="ePBT")
        print("  [TRAFIK-V2] tekan JPJ (imej logo mySIKAP)...")
        img = self.find_element(self.BUTTON_MYSIKAP_IMAGE, timeout=8)
        self.tap_element(img)
        deadline = time.monotonic() + 25
        populated = False
        while time.monotonic() < deadline:
            if self._mysikap_populated(data["no_kereta"]):
                populated = True
                break
            time.sleep(1)
        nota_jpj = ("BERJAYA" if populated
                    else "TIDAK kelihatan — medan akan diisi manual "
                         "(non-fatal)")
        print(f"  [TRAFIK-V2] auto-isi JPJ: {nota_jpj}")
        self.dismiss_native_alerts(first_timeout=2, context="JPJ")

        # Override / isi manual ikut data CEO — SELEPAS lookup supaya
        # nilai kekal (baca-balik setiap satu).
        taip_ikut_hint("NAMA PESALAH", data["nama_pesalah"])
        taip_ikut_hint("NO K/P/SSM", data["no_kp_ssm"])
        taip_ikut_hint("NO. CUKAI JALAN", data.get("no_cukai_jalan", ""),
                       wajib=False)

        # Checkbox alamat premis sama seperti pesalah — TICK.
        cb = (AppiumBy.CLASS_NAME, "android.widget.CheckBox")
        if self.is_element_present(cb, timeout=3):
            el = self.driver.find_element(*cb)
            if (el.get_attribute("checked") or "false") == "false":
                self.tap_element(el)
                print("  [TRAFIK-V2] checkbox ALAMAT PREMIS SAMA: TICK")
        else:
            teks_cb = (AppiumBy.ANDROID_UIAUTOMATOR,
                       'new UiSelector().textContains("TICK JIKA ALAMAT")')
            if self.is_element_present(teks_cb, timeout=2):
                self.tap_element(self.driver.find_element(*teks_cb))
                print("  [TRAFIK-V2] checkbox di-tap melalui teks label")

        # >>> 2026-08-27 (dump trafik_pesalah_form.xml): build semasa
        # TIDAK mempunyai medan JENIS/WARNA/PETAK/KUPON pada tab
        # Pesalah lagi (JPJ auto-isi alamat penuh). Lookup dikekalkan
        # ringan (skrol=False — swipe terbukti NO-OP pada borang ini)
        # untuk keserasian build lama. <<<
        taip_ikut_hint("JENIS KERETA", data["jenis_kereta"], wajib=False,
                       skrol=False)
        taip_ikut_hint("WARNA KERETA", data["warna_kereta"], wajib=False,
                       skrol=False)
        taip_ikut_hint("NO. PETAK", data.get("no_petak", ""), wajib=False,
                       skrol=False)
        taip_ikut_hint("NO. KUPON", data.get("no_kupon", ""), wajib=False,
                       skrol=False)

        # >>> Kandungan BAWAH FOLD (medan NEGERI terpotong tepat di
        # 2316; swipe no-op — corak 'borang tidak boleh di-skrol').
        # Guna reveal_below_fold (traversal TAB/DPAD) untuk mencapai
        # checkbox alamat premis + SETERUSNYA, tick semua checkbox yang
        # belum, dan dump untuk bukti. <<<
        cb_loc = (AppiumBy.CLASS_NAME, "android.widget.CheckBox")
        self.reveal_below_fold(cb_loc, max_tabs=10)
        try:
            for _cb in self.driver.find_elements(*cb_loc):
                if (_cb.get_attribute("checked") or "false") == "false":
                    self.tap_element(_cb)
                    time.sleep(0.5)
                    print("  [TRAFIK-V2] checkbox bawah fold: TICK")
        except Exception:                                    # noqa: BLE001
            pass
        try:
            import os as _os2
            _os2.makedirs("ui_dumps", exist_ok=True)
            _p2 = _os2.path.join("ui_dumps", "trafik_pesalah_bawah.xml")
            with open(_p2, "w", encoding="utf-8") as _f2:
                _f2.write(self.driver.page_source)
            print(f"  [TRAFIK-V2] dump bawah -> {_p2}")
        except Exception:                                    # noqa: BLE001
            pass
        # >>> 2026-08-27: dump borang SEBELUM Seterusnya — 4 medan bawah
        # (JENIS/WARNA/PETAK/KUPON) tidak dijumpai walaupun dengan
        # skrol-retry; kita perlukan struktur sebenar borang (nama
        # hint/teks) dan bukan tekaan. Fail kecil, sentiasa ditulis. <<<
        try:
            import os as _os
            _os.makedirs("ui_dumps", exist_ok=True)
            _p = _os.path.join("ui_dumps", "trafik_pesalah_form.xml")
            with open(_p, "w", encoding="utf-8") as _f:
                _f.write(self.driver.page_source)
            print(f"  [TRAFIK-V2] dump borang -> {_p}")
        except Exception:                                    # noqa: BLE001
            pass
        # SETERUSNYA juga bawah fold pada borang tanpa-skrol ini —
        # dedahkan dengan traversal fokus sebelum pemanggil menekannya.
        self.reveal_below_fold(self.BUTTON_SETERUSNYA, max_tabs=10)
        print("  [DAFTAR KOMPAUN] Tab Pesalah TRAFIK (hotfix) selesai "
              "— PASS")

    def fill_kompaun_code_fields_trafik_v2(self, data):
        """Tier dropdown borang TRAFIK pada build hotfix — GANTIAN
        kepada fill_kompaun_code_fields_trafik (yang menganggap tier-1
        terkunci PERINTAH 39, andaian build lama).

        Adaptif dua build: kalau medan hint 'PILIH KOMPAUN' wujud
        (build hotfix — boleh pilih), pandu ketiga-tiga tier ikut data
        CEO; kalau tidak, jatuh balik ke laluan lama (tier-1 preselect).
        """
        print("  [DAFTAR KOMPAUN] Tier dropdown TRAFIK (build hotfix)...")
        if self._medan_ikut_hint(self.PLACEHOLDER_PILIH_KOMPAUN,
                                 timeout=6) is None:
            print("  [TRAFIK-V2] medan hint PILIH KOMPAUN tiada — jatuh "
                  "balik ke laluan build lama (tier-1 preselect)")
            return self.fill_kompaun_code_fields_trafik(data)

        keputusan = {}
        akta_sasaran = data["kod_akta"]
        try:
            keputusan["tier1"] = self.pilih_tier_ikut_hint(
                self.PLACEHOLDER_PILIH_KOMPAUN,
                data["keterangan_kod_kompaun"])
        except TimeoutException:
            # >>> 2026-08-27: jpb (jeniskod P) mungkin tidak disenarai
            # pada borang Trafik (jeniskod K). Fallback ke rantaian
            # LENGKAP DB: KPD 'PERINTAH LALULINTAS JALAN (PERINTAH 39)'
            # -> akta 37 -> 16 kesalahan. Log kuat sebagai penemuan. <<<
            print(f"  [TRAFIK-V2] [PENEMUAN-DATA] tier-1 "
                  f"'{data['keterangan_kod_kompaun'][:40]}' TIADA dalam "
                  f"senarai borang Trafik — fallback KPD (PERINTAH 39) "
                  f"+ akta 37 (rantaian lengkap DB)")
            keputusan["tier1"] = self.pilih_tier_ikut_hint(
                self.PLACEHOLDER_PILIH_KOMPAUN,
                "PERINTAH LALULINTAS JALAN")
            akta_sasaran = "37"
        keputusan["akta"] = self.pilih_tier_ikut_hint(
            self.PLACEHOLDER_PILIH_AKTA, akta_sasaran)
        if data.get("kesalahan_kompaun"):
            keputusan["kesalahan"] = self.pilih_tier_ikut_hint(
                self.PLACEHOLDER_PILIH_KESALAHAN,
                data["kesalahan_kompaun"])
        else:
            keputusan["kesalahan"] = self.pilih_kesalahan_pertama()
        keputusan["kadar"] = self.isi_kadar_denda_julat(
            int(data.get("kadar_denda") or 200))
        print("  [DAFTAR KOMPAUN] Tier dropdown TRAFIK (hotfix) selesai "
              "— PASS")
        return keputusan

    # ---- Pesalah tab ----

    def fill_pesalah_tab(self, data):
        """Fill in the Pesalah tab fields.
        data must contain: nama_pesalah, no_kp_ssm_kereta, jalan,
        taman, poskod, bandar, negeri
        """
        import time
        print("\n  [DAFTAR KOMPAUN] Filling Pesalah tab...")
        self.wait_and_click(self.TAB_PESALAH)

        fields = [
            (self.LABEL_NAMA_PESALAH, data["nama_pesalah"]),
            (self.LABEL_NO_KP_SSM_KERETA, data["no_kp_ssm_kereta"]),
            (self.LABEL_PESALAH_JALAN, data["jalan"]),
            # Taman is a live-search autocomplete field, but waiting on
            # its suggestion dropdown was a dead end -- typing a short
            # partial (e.g. "T") never renders any suggestions, so the
            # field (and poskod/bandar/negeri, meant to be auto-filled
            # from picking one) ended up stuck waiting ~20s and then
            # left blank every run. Type the full value directly
            # instead -- plain send_keys() sets the value without
            # firing the live-search, so no dropdown appears to wait
            # on or dismiss.
            (self.LABEL_PESALAH_TAMAN, data["taman"]),
            (self.LABEL_PESALAH_POSKOD, data["poskod"]),
            (self.LABEL_PESALAH_BANDAR, data["bandar"]),
            (self.LABEL_PESALAH_NEGERI, data["negeri"]),
        ]
        # Confirmed via live run: Negeri (the last field) alone took ~27s
        # to fill, ~9x every other field -- find_element wastes its full
        # 15s presence-wait before ever trying to scroll, and by the time
        # we reach Negeri the keyboard (still up from typing Bandar) has
        # pushed it out of the rendered viewport, so that dead wait
        # always happens. Scroll proactively right before it so it's
        # already rendered and the normal presence-wait succeeds fast.
        scroll_before = {self.LABEL_PESALAH_NEGERI}
        # v3: fill_field_by_label_or_instance -- this form keeps a
        # pesalah draft across reopenings (same behavior confirmed on
        # the Notis Amaran form), so placeholders can already be gone.
        for idx, (label, value) in enumerate(fields):
            if label in scroll_before:
                self._scroll_down()
            t0 = time.time()
            self.fill_field_by_label_or_instance(label, value, instance=idx)
            print(f"  [TIMING] '{label}' filled in {time.time() - t0:.2f}s")

        print("  [DAFTAR KOMPAUN] Pesalah tab filled — PASS")

    def click_seterusnya_from_pesalah(self):
        """Click Seterusnya on Pesalah tab to go to Kompaun tab."""
        print("  [DAFTAR KOMPAUN] Clicking Seterusnya to go to Kompaun tab...")
        self.wait_and_click(self.BUTTON_SETERUSNYA)

    # ---- Kompaun tab ----

    def fill_kompaun_tab(self, data):
        """Fill in the Kompaun tab fields.
        data must contain: kompaun_jalan_partial, kompaun_jalan_suggestion,
        kompaun_taman, kompaun_poskod, kompaun_bandar, kompaun_negeri,
        lokasi_kesalahan, butiran_kesalahan, tempoh_notis
        """
        print("\n  [DAFTAR KOMPAUN] Filling Kompaun tab...")
        # TAB_KOMPAUN is unreliable -- same phantom-tab issue confirmed
        # for TAB_NOTIS/TAB_PENERIMA in notis_amaran_page.py. Check for
        # a field that's actually on this screen instead.
        kompaun_jalan_locator = (
            AppiumBy.ANDROID_UIAUTOMATOR,
            f'new UiSelector().text("{self.LABEL_KOMPAUN_JALAN}")')
        assert self.is_element_present(kompaun_jalan_locator, timeout=5), \
            "Kompaun screen not visible after clicking Seterusnya"

        self.type_and_select_suggestion(
            self.LABEL_KOMPAUN_JALAN,
            data["kompaun_jalan_partial"],
            data["kompaun_jalan_suggestion"],
        )

        # The Taman/Bandar/Negeri auto-fill triggered by the Jalan
        # selection above happens asynchronously -- give it a moment to
        # land before checking those fields below, or the guard can race
        # it (StaleElementReferenceException / not-found handled there
        # either way, but this cuts how often that race fires at all).
        import time
        time.sleep(1.5)

        # Confirmed via live run: unlike the Pesalah tab, a successful tap
        # on this tab's Jalan suggestion DOES auto-fill Taman/Bandar/Negeri
        # as a side effect -- so their placeholder text is already gone by
        # the time we get here, and a plain fill_field_by_label would wait
        # out its timeout and raise. Use the _if_blank guard: fill only
        # if the placeholder is still showing (i.e. the Jalan selection
        # didn't auto-populate it), skip instantly otherwise. Poskod is
        # NOT auto-filled by the Jalan selection, so it's always filled.
        self.fill_field_by_label_if_blank(self.LABEL_KOMPAUN_TAMAN, data["kompaun_taman"])
        self.fill_field_by_label(self.LABEL_KOMPAUN_POSKOD, data["kompaun_poskod"])
        self.fill_field_by_label_if_blank(self.LABEL_KOMPAUN_BANDAR, data["kompaun_bandar"])
        self.fill_field_by_label_if_blank(self.LABEL_KOMPAUN_NEGERI, data["kompaun_negeri"])
        self.fill_field_by_label(self.LABEL_LOKASI_KESALAHAN, data["lokasi_kesalahan"])
        self.fill_field_by_label(self.LABEL_BUTIRAN_KESALAHAN, data["butiran_kesalahan"])
        # Tempoh: force-clear + verify + 0-21 range-check. A stale
        # pre-filled value surviving el.clear() (e.g. '90') would trip the
        # field's own validation and silently block SETERUSNYA -- the root
        # cause of the 17-min Sitaan hang. See _set_tempoh_verified.
        self._set_tempoh_verified(data["tempoh_notis"])

        print("  [DAFTAR KOMPAUN] Kompaun tab filled — PASS")

    def fill_kompaun_code_fields(self, data):
        """Select the three kompaun code dropdowns.

        Each selection is verified via the element that only shows once
        the option list has closed again -- same silent no-op-tap
        protection as notis_amaran_page.fill_kompaun_code_fields."""
        print("  [DAFTAR KOMPAUN] Selecting kompaun code dropdowns...")
        pilih_akta = (AppiumBy.ANDROID_UIAUTOMATOR,
                      f'new UiSelector().text("{self.PLACEHOLDER_PILIH_AKTA}")')
        pilih_kesalahan = (AppiumBy.ANDROID_UIAUTOMATOR,
                           f'new UiSelector().text("{self.PLACEHOLDER_PILIH_KESALAHAN}")')
        self.select_dropdown_option_and_confirm(
            self.PLACEHOLDER_PILIH_KOMPAUN, data["keterangan_kod_kompaun"],
            confirm_locator=pilih_akta)
        self.select_dropdown_option_and_confirm(
            self.PLACEHOLDER_PILIH_AKTA, data["kod_akta"],
            confirm_locator=pilih_kesalahan)
        # CASCADE 2026-08-27 (validasi #4): akta ganti '57' terbukti
        # jalan mati — kesalahan 'Tiada rekod' untuk SEMUA huruf. Patah
        # balik: pilih akta baris lain, cuba kesalahan semula (2x).
        from selenium.common.exceptions import TimeoutException
        for _cuba in range(3):
            try:
                self.select_dropdown_option_and_confirm(
                    self.PLACEHOLDER_PILIH_KESALAHAN,
                    data["kesalahan_kompaun"],
                    confirm_locator=self.TIER3_CONFIRM)
                break
            except TimeoutException as e:
                if "SENARAI-KOSONG" not in str(e) or _cuba == 2:
                    raise
                print(f"  [DAFTAR KOMPAUN] kesalahan KOSONG di bawah "
                      f"akta semasa — cascade ke akta lain "
                      f"(cubaan {_cuba + 1}/2)")
                if not self.cuba_akta_ganti_lain(_cuba + 1):
                    raise
        self.fill_kadar_denda(data["kadar_denda"])
        print("  [DAFTAR KOMPAUN] Kompaun code dropdowns selected — PASS")

    # The element proving the tier-3 option list closed. OPEN CAMERA on
    # the Pelbagai/Lesen forms; the Sitaan form (whose camera sits
    # further down, past the Barang section) overrides this with the
    # kadar amount field, which renders right below the dropdowns
    # (confirmed live: OPEN CAMERA never rendered there in time).
    TIER3_CONFIRM = BUTTON_OPEN_CAMERA

    def _find_kadar_denda_el(self, expected=None):
        """Locate the Kadar Denda amount EditText: by its ENTER AMAUN
        hint first, positionally (label-sibling) as fallback in case a
        form variant gives the field a different hint. The hint
        attribute persists regardless of the field's current text, so
        this works before and after typing."""
        try:
            return self.find_element(self.FIELD_KADAR_DENDA, timeout=8)
        except Exception:
            print("  [DAFTAR KOMPAUN] ENTER AMAUN hint not found -- "
                  "falling back to the label-sibling EditText")
            # following:: (any following node), NOT following-sibling --
            # on the Sitaan form the amount EditText is nested inside a
            # sibling container, so the sibling axis misses it
            # (confirmed live: label at y999, EditText '0' at y1071,
            # sibling lookup empty).
            fallback = (AppiumBy.XPATH,
                        '//android.widget.TextView[starts-with(@text,'
                        '"PILIH KADAR DENDA")]'
                        '/following::android.widget.EditText[1]')
            try:
                return self.find_element(fallback, timeout=10)
            except Exception:
                # Last tier (Sitaan): the label can sit ABOVE the
                # current viewport where find_element's downward scroll
                # never returns; the amount field itself is the one
                # EditText preset to exactly "0" on this screen
                # (confirmed via debug_dropdown_confirm.xml).
                print("  [DAFTAR KOMPAUN] falling back to the preset-'0' "
                      "EditText for Kadar Denda")
                values = ["0"] + ([expected] if expected else [])
                pattern = "|".join(values)
                zero = (AppiumBy.ANDROID_UIAUTOMATOR,
                        f'new UiSelector().className('
                        f'"android.widget.EditText")'
                        f'.textMatches("^({pattern})$")')
                return self.find_element(zero, timeout=10)

    def fill_kadar_denda(self, kadar_denda):
        """Fill the Kadar Denda amount field (see FIELD_KADAR_DENDA:
        a numeric EditText, not a dropdown, despite its 'PILIH' label).

        Strips a leading 'RM' from the test-script value ("RM2000") --
        the currency unit is already part of the on-screen label
        "(RM)" and the field is an amount input. Uses mobile: type like
        the app's other numeric fields, which reject plain send_keys().

        Type-verify-retry: confirmed via live adb dump that a typed
        amount can silently fail to stick (the clear() registered but
        the field was back to its ENTER AMAUN placeholder afterwards --
        the RN re-render triggered by clear() can swallow the
        keystrokes that race it). Read the value back after typing and
        retype if it didn't land."""
        amount = kadar_denda.strip()
        if amount.upper().startswith("RM"):
            amount = amount[2:].strip()
        print(f"  [DAFTAR KOMPAUN] Entering Kadar Denda: {amount}")
        import time
        # v3 (Sitaan): the amount field can be entirely BELOW the fold
        # and unrendered on the gesture-resistant form variants (all
        # three locators missed live) -- reveal it via focus traversal
        # first.
        zero_probe = (AppiumBy.ANDROID_UIAUTOMATOR,
                      f'new UiSelector().className('
                      f'"android.widget.EditText")'
                      f'.textMatches("^(0|{amount})$")')
        if (not self.is_element_present(self.FIELD_KADAR_DENDA, timeout=3)
                and not self.is_element_present(zero_probe, timeout=2)):
            print("  [DAFTAR KOMPAUN] Kadar field below the fold -- "
                  "focus-traversal reveal...")
            self.reveal_below_fold(zero_probe)
        last = None
        for attempt in range(3):
            el = self._find_kadar_denda_el(expected=amount)
            el.click()
            el.clear()
            time.sleep(0.3)
            self.driver.execute_script('mobile: type', {'text': amount})
            self._hide_keyboard_if_shown()
            try:
                last = self._find_kadar_denda_el(expected=amount).text
            except Exception:
                last = None
            if last is not None and amount in last:
                print(f"  [DAFTAR KOMPAUN] Kadar Denda verified: "
                      f"'{last}' — PASS")
                return
            print(f"  [DAFTAR KOMPAUN] Kadar Denda didn't stick (field "
                  f"shows {last!r}, attempt {attempt + 1}/3) -- retrying...")
        raise TimeoutException(
            f"Kadar Denda '{amount}' never stuck after 3 attempts "
            f"(field shows {last!r})")

    # The in-app camera's mode label -- present the whole time the
    # camera is open, gone once it closes back to the form. Used to
    # verify the tick-confirm tap actually registered (confirmed via
    # live dump: the tick tap can silently no-op, leaving the camera
    # open on top of the form -- every later step then fails while
    # take_photos had already reported success).
    CAMERA_OPEN_INDICATOR = (AppiumBy.ANDROID_UIAUTOMATOR,
                             'new UiSelector().text("FLASH OFF")')

    def take_photos(self, count=3):
        """Open the in-app camera, snap `count` photos, confirm with the
        tick, and verify the camera closed.

        Pacing is load-bearing -- confirmed via live adb experiments:
        each capture takes a couple of seconds during which the camera
        silently DROPS every tap, so 1s pacing lost some snaps and
        always lost the tick (which only registers once the last
        capture has settled; with a fresh settled capture it closes the
        camera reliably). Also confirmed: photos from a session exited
        via the close (X) icon show in the form's counter but do NOT
        satisfy the Trafik form's GAMBAR MESTI DIAMBIL validation --
        only a tick-closed session does, so the X-exit is strictly a
        last resort. The form's 'GAMBAR TELAH DIAMBIL: N/6' counter is
        read back afterwards as ground truth."""
        print(f"  [DAFTAR KOMPAUN] Opening camera for {count} photo(s)...")
        self.wait_and_click(self.BUTTON_OPEN_CAMERA)
        import time
        time.sleep(2)

        # >>> 2026-08-27 (K rerun #3+#5): kamera borang TRAFIK jauh
        # lebih PERLAHAN — pacing 3s menjatuhkan sebahagian snap
        # (kaunter 1/6 dan 2/6 selepas "3 snap") dan tick tidak pernah
        # berdaftar dalam 3 cubaan -> keluar ikut X -> validasi app
        # 'GAMBAR MESTI DIAMBIL.' menyekat Seterusnya. Pacing dinaikkan
        # 3s->5s, settle 4s sebelum tick, cubaan tick 3->6 dengan
        # elemen SEGAR setiap kali, dan kalau semua gagal: snap SATU
        # lagi + tick semula (mekanisme terbukti: tick daftar dengan
        # capture segar yang settled). <<<
        for i in range(count):
            print(f"  [DAFTAR KOMPAUN]   Snapping photo {i+1}/{count}")
            self.wait_and_click(self.BUTTON_SNAP)
            time.sleep(5)

        print("  [DAFTAR KOMPAUN] Confirming photos with tick icon...")
        time.sleep(4)      # settle capture terakhir sebelum tick pertama

        def _cuba_tick(berapa, label):
            for attempt in range(berapa):
                el = self.find_clickable(self.BUTTON_TICK_CONFIRM)
                self.tap_element(el)
                time.sleep(3)
                if not self.is_element_present(self.CAMERA_OPEN_INDICATOR,
                                               timeout=3):
                    return True
                print(f"  [DAFTAR KOMPAUN] Camera still open after tick "
                      f"tap ({label} {attempt + 1}/{berapa}) -- "
                      f"re-tapping...")
            return False

        closed = _cuba_tick(6, "attempt")
        if not closed:
            # Capture segar + settle + tick semula.
            print("  [DAFTAR KOMPAUN] tick degil -- snap SATU capture "
                  "segar dan cuba tick semula...")
            try:
                self.wait_and_click(self.BUTTON_SNAP)
                time.sleep(6)
                closed = _cuba_tick(3, "fresh-snap attempt")
            except Exception as e:                           # noqa: BLE001
                print(f"  [DAFTAR KOMPAUN] snap segar gagal "
                      f"({type(e).__name__}) -- teruskan ke fallback X")
        if closed:
            self._log_gambar_counter()
            print("  [DAFTAR KOMPAUN] Photos taken — camera closed — PASS")
            return
        # Bukti untuk analisis: dump tree kamera (mungkin jarang tetapi
        # tick/snap ada di dalamnya — locator glyph ditemui dari dump).
        try:
            p = "ui_dumps/kamera_tick_fail.xml"
            with open(p, "w", encoding="utf-8") as f:
                f.write(self.driver.page_source)
            print(f"  [DAFTAR KOMPAUN] dump kamera -> {p}")
        except Exception:                                    # noqa: BLE001
            pass

        # ASCII-only print text: the camera's close glyph (U+2715) is
        # not representable in the Windows cp1252 console -- printing
        # it raises UnicodeEncodeError and aborts this method (bit us
        # live: the fallback below never ran and the camera stayed
        # open). The glyph only appears inside locator strings, which
        # go over the wire, never to the console.
        print("  [DAFTAR KOMPAUN] WARNING: tick never registered -- "
              "closing the camera via its close (X) icon and continuing "
              "without confirmed photos")
        x_locator = (AppiumBy.ANDROID_UIAUTOMATOR,
                     'new UiSelector().description("✕")')
        try:
            el = self.find_element(x_locator, timeout=5)
            self.tap_element(el)
        except Exception:
            print("  [DAFTAR KOMPAUN] Close icon not found -- pressing "
                  "device Back")
            self.press_back()
        time.sleep(1)
        self._log_gambar_counter()

    def _log_gambar_counter(self):
        """Log the form's 'GAMBAR TELAH DIAMBIL: N/6' counter -- the
        only readable ground truth for how many photos actually got
        attached (the camera's own UI is a static native surface that
        reflects nothing in the accessibility tree)."""
        counter = (AppiumBy.ANDROID_UIAUTOMATOR,
                   'new UiSelector().textContains("GAMBAR TELAH DIAMBIL")')
        try:
            txt = self.find_element(counter, timeout=5).text
            print(f"  [DAFTAR KOMPAUN] Photo counter: {txt}")
        except Exception:
            print("  [DAFTAR KOMPAUN] WARNING: photo counter not readable")

    def click_seterusnya_from_kompaun(self):
        """Click Seterusnya on Kompaun tab to go to Penerima tab.

        Fallback for the Trafik form (never reached on Pelbagai, which
        succeeds on the primary path): confirmed via live run + adb
        experiments that this form resists the standard scroll gesture
        -- only a slow low-start swipe moves it -- and its SETERUSNYA
        can render as a plain TextView (text), not just the
        accessibility id used everywhere else."""
        print("  [DAFTAR KOMPAUN] Clicking Seterusnya to go to Penerima tab...")
        try:
            self.wait_and_click(self.BUTTON_SETERUSNYA)
            return
        except TimeoutException:
            print("  [DAFTAR KOMPAUN] SETERUSNYA not reachable via the "
                  "standard path -- trying slow low-start swipes...")
        import time
        candidates = [
            self.BUTTON_SETERUSNYA,
            (AppiumBy.ANDROID_UIAUTOMATOR,
             'new UiSelector().text("SETERUSNYA")'),
        ]
        for _ in range(6):
            for loc in candidates:
                if self.is_element_present(loc, timeout=2):
                    el = self.find_element(loc, timeout=3)
                    self.tap_element(el)
                    return
            self.driver.swipe(540, 2200, 540, 800, 600)
            time.sleep(0.5)
        dump_path = "debug_seterusnya_kompaun.xml"
        try:
            with open(dump_path, "w", encoding="utf-8") as f:
                f.write(self.driver.page_source)
            print(f"  [DAFTAR KOMPAUN] DEBUG: page source dumped to "
                  f"{dump_path}")
        except Exception:
            pass
        raise TimeoutException(
            f"SETERUSNYA not found on the Kompaun tab by accessibility id "
            f"or text, even after slow swipes; see {dump_path}")

    # ---- Penerima tab ----

    def fill_penerima_tab(self, data):
        """Fill in the Penerima tab fields and draw signature.
        data must contain: no_pembantu_penguatkuasa, nama_penerima,
        no_ic_penerima
        """
        print("\n  [DAFTAR KOMPAUN] Filling Penerima tab...")
        # Same issue confirmed in notis_amaran_page.py: Seterusnya here
        # pushes a new screen with no "PENERIMA" accessibility id, so
        # TAB_PENERIMA never matches. Check for a field that's actually
        # on this screen instead.
        pembantu_locator = (
            AppiumBy.ANDROID_UIAUTOMATOR,
            f'new UiSelector().text("{self.LABEL_NO_PEMBANTU_PENGUATKUASA}")')
        if not self.is_element_present(pembantu_locator, timeout=5):
            # Seterusnya may have been rejected by form validation --
            # the app reports that via a native alert (e.g. "RALAT /
            # SILA PILIH BANDAR DARIPADA SENARAI."). Drain it so the
            # actual reason lands in the log instead of a bare
            # "screen not visible".
            if self.dismiss_native_alerts(first_timeout=3,
                                          context="Penerima arrival"):
                raise AssertionError(
                    "Penerima screen not visible after clicking "
                    "Seterusnya -- a validation alert was shown (its "
                    "message is logged above); the Kompaun tab rejected "
                    "a field value")
            raise AssertionError(
                "Penerima screen not visible after clicking Seterusnya")

        self.fill_field_by_label(self.LABEL_NO_PEMBANTU_PENGUATKUASA,
                                  data["no_pembantu_penguatkuasa"])

        print("  [DAFTAR KOMPAUN] Opening signature pad...")
        self.wait_and_click(self.FIELD_OPEN_SIGNATURE)
        import time
        time.sleep(1)
        self._draw_signature()

        print("  [DAFTAR KOMPAUN] Closing signature popup...")
        closed = self.close_popup_by_icon(timeout=3)
        if not closed:
            self.driver.tap([(540, 300)])
        time.sleep(1)

        self._fill_penerima(self.LABEL_NAMA_PENERIMA,
                            data.get("nama_penerima"), "NAMA PENERIMA",
                            "nama_penerima")
        self._fill_penerima(self.LABEL_NO_IC_PENERIMA,
                            data.get("no_ic_penerima"), "NO IC PENERIMA",
                            "no_ic_penerima")

        print("  [DAFTAR KOMPAUN] Penerima tab filled — PASS")

    def _fill_penerima(self, label, value, nama_papar, medan):
        """Isi medan penerima, dan log bila nilainya penanda.

        Medan yang skrip Excel tidak bekalkan diisi dengan penanda
        (excel_data.BLANK_MARKER teks / BLANK_MARKER_IC berangka bagi
        MEDAN_BERANGKA), bukan dibiarkan kosong. Penanda keluar pada
        kertas cetak, jadi sesiapa yang memegang cetakan nampak terus
        bahawa nilainya tiada asas dalam Excel. Medan kosong sebenar tak
        dapat dibezakan daripada medan gagal diisi -- itulah sebabnya
        nilai rekaan seperti "Buruh En Saiful" boleh bertahan berbulan.
        Read-back di bawah mengesahkan penanda benar masuk."""
        from testdata.excel_data import ialah_penanda, penanda_untuk
        is_marker = ialah_penanda(value)
        expected = penanda_untuk(medan) if is_marker else value
        if is_marker:
            print(f"  [DAFTAR KOMPAUN] {nama_papar}: menaip penanda "
                  f"{expected!r} — Excel tidak membekalkan nilai")
        el = self.fill_field_by_label(label, value)
        got = self._safe_text(el)
        print(f"  [DAFTAR KOMPAUN] {nama_papar}: medan = {got!r} selepas "
              f"taip (sepatutnya {expected!r})")
        if is_marker and self._norm(got) != self._norm(expected):
            print(f"  [DAFTAR KOMPAUN] WARNING: {nama_papar} tidak menerima "
                  f"penanda {expected!r} — nilai sebenar {got!r}")

    def _draw_signature(self):
        """Draw a simple signature using W3C Actions."""
        print("  [DAFTAR KOMPAUN] Drawing signature...")
        from selenium.webdriver.common.action_chains import ActionChains
        from selenium.webdriver.common.actions import interaction
        from selenium.webdriver.common.actions.action_builder import ActionBuilder
        from selenium.webdriver.common.actions.pointer_input import PointerInput

        actions = ActionChains(self.driver)
        pointer = PointerInput(interaction.POINTER_TOUCH, "finger")
        actions.w3c_actions = ActionBuilder(self.driver, mouse=pointer)
        actions.w3c_actions.pointer_action.move_to_location(400, 1200)
        actions.w3c_actions.pointer_action.pointer_down()
        actions.w3c_actions.pointer_action.move_to_location(500, 1150)
        actions.w3c_actions.pointer_action.move_to_location(600, 1250)
        actions.w3c_actions.pointer_action.move_to_location(700, 1180)
        actions.w3c_actions.pointer_action.move_to_location(800, 1220)
        actions.w3c_actions.pointer_action.release()
        actions.perform()

    def click_menyerahkan(self):
        """Click the Menyerahkan button.

        Confirmed via live run (Notis Amaran flow): MENYERAHKAN sits
        right after the last typed field (NO IC PENERIMA), so the
        on-screen keyboard is still covering it at this point --
        computing a raw coordinate tap from the element's rect() lands
        on the keyboard, not the button. Explicitly hide the keyboard
        first, then use tap_element (raw coordinate tap) rather than
        wait_and_click/el.click() -- same reasoning as the dropdown/
        suggestion rows elsewhere in this file, since this app's custom
        Pressables silently no-op on the accessibility ACTION_CLICK a
        plain el.click() sends.
        """
        print("  [DAFTAR KOMPAUN] Clicking Menyerahkan...")
        try:
            if self.driver.is_keyboard_shown():
                self.driver.hide_keyboard()
                import time
                time.sleep(0.5)
        except Exception:
            pass
        el = self.find_clickable(self.BUTTON_MENYERAHKAN)
        self.tap_element(el)

    def confirm_and_submit(self):
        """Handle 'Simpan maklumat ini?' popup and click Hantar."""
        print("\n  [DAFTAR KOMPAUN] Confirmation popup...")
        assert self.is_element_present(self.POPUP_SIMPAN_MAKLUMAT, timeout=10), \
            "Confirmation popup not displayed"
        print("  [DAFTAR KOMPAUN] Confirmation popup visible — PASS")
        print("  [DAFTAR KOMPAUN] Clicking Hantar...")
        # tap_element, not wait_and_click -- same custom-Pressable
        # no-op issue as MENYERAHKAN above.
        el = self.find_clickable(self.BUTTON_HANTAR)
        self.tap_element(el)

    def is_submission_successful(self):
        """Wait for success popup after submission."""
        if self.is_element_present(self.POPUP_CETAK_KOMPAUN_PELBAGAI, timeout=30):
            print("  [DAFTAR KOMPAUN] Submission successful — receipt popup visible — PASS")
            self.read_record_number()  # capture no_kompaun before closing
            self.close_success_popup()
            return True
        if self.is_text_visible("Berjaya", timeout=5):
            print("  [DAFTAR KOMPAUN] Submission successful — PASS")
            return True
        print("  [DAFTAR KOMPAUN] WARNING: Could not confirm submission success")
        return False

    def close_success_popup(self):
        """Close the success/receipt popup."""
        print("  [DAFTAR KOMPAUN] Closing success popup...")
        closed = self.close_popup_by_icon(timeout=3)
        if not closed:
            print("  [DAFTAR KOMPAUN] No close icon found, pressing Back...")
            self.press_back()

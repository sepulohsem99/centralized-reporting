"""
Printer connect page — the app can re-connect the Bluetooth printer itself.

Discovered 2026-07-29 (owner) and recon'd live (ui_dumps/home_topbar.png,
home_printer_recon.xml, printer_popup.xml/.png):

TOP-BAR PRINTER ICON
--------------------
Home screen top bar has 3 clickable icon-buttons (resource-id "icon-button"):
refresh, PRINTER (middle), logout. The printer icon is the middle one; its
glyph is U+F02AA (chr(984106)) inside a "cross-fade-icon-current" TextView.
Colour = state: GREEN connected, RED not connected. Colour is NOT in the
accessibility tree, so we read it from the icon's own screenshot (mean of the
coloured pixels: G > R -> green).

CONNECT FLOW (when RED)
----------------------
Tap the icon -> "Bluetooth Active" popup. Under "Printer connected to the
device:" each paired device is a row (name TextView + a clickable ViewGroup
content-desc="Connect"). Tap Connect on the printer's row -> password popup
-> "0000" -> OK -> icon turns green.

DEVICE PREFIX
-------------
CLAUDE.md / the owner note says the entry starts with "SPR", but the LIVE
device is **SPP-R410_110095** (Bixolon SPP series) -- verified via
printer_popup.xml, not guessed. Match the static model prefix "SPP"
(overridable via MBIP_PRINTER_PREFIX); only the "_NNNNNN" suffix varies per
team member, so NEVER hardcode the full id.

Techniques per CLAUDE.md: tap_element (raw coord) for RN pressables,
verify-and-retry, dismiss_native_alerts, dump on any unrecognized screen.
"""

import io
import os
import time

from appium.webdriver.common.appiumby import AppiumBy
from selenium.common.exceptions import TimeoutException

from pages.base_page import BasePage


class PrinterConnectPage(BasePage):

    PRINTER_GLYPH = chr(984106)  # U+F02AA, the top-bar printer icon
    ICON = (AppiumBy.XPATH,
            '//android.widget.Button[.//android.widget.TextView'
            f'[@text="{chr(984106)}"]]')
    POPUP_TITLE = (AppiumBy.ANDROID_UIAUTOMATOR,
                   'new UiSelector().textContains("Bluetooth")')
    CLOSE_MODAL = (AppiumBy.ACCESSIBILITY_ID, "Close modal")

    def _default_prefix(self):
        return (os.environ.get("MBIP_PRINTER_PREFIX") or "SPP").upper()

    def _dump(self, name):
        try:
            os.makedirs("ui_dumps", exist_ok=True)
            path = os.path.join("ui_dumps", name)
            with open(path, "w", encoding="utf-8") as f:
                f.write(self.driver.page_source)
            print(f"  [PRINTER-CONNECT] dumped {path}")
        except Exception:                                    # noqa: BLE001
            pass

    def _icon_el(self):
        try:
            return self.find_element(self.ICON, timeout=6)
        except TimeoutException:
            return None

    def _icon_is_green(self, icon_el):
        """True=green(connected), False=red(not connected), None=undecided.
        Reads the icon's OWN screenshot and compares the mean of the coloured
        (non-grey) pixels: green icon -> G channel dominates, red -> R."""
        try:
            from PIL import Image
        except Exception:                                    # noqa: BLE001
            return None
        try:
            png = icon_el.screenshot_as_png
        except Exception:                                    # noqa: BLE001
            return None
        try:
            im = Image.open(io.BytesIO(png)).convert("RGB")
        except Exception:                                    # noqa: BLE001
            return None
        rs = gs = n = 0
        for (r, g, b) in im.getdata():
            if max(r, g, b) - min(r, g, b) < 25:  # grey/white -> ignore
                continue
            rs += r
            gs += g
            n += 1
        if n == 0:
            return None
        return gs > rs

    def is_connected(self):
        """Colour of the top-bar printer icon: True/False/None(undecided).
        None if the icon can't be found (e.g. not on the home screen)."""
        el = self._icon_el()
        if el is None:
            return None
        return self._icon_is_green(el)

    def ensure_printer_connected(self, pages, prefix=None):
        """Make sure the app's Bluetooth printer is connected. Returns True
        if it ends up connected (icon green), else False.

        - Icon already GREEN -> return True immediately, touch nothing.
        - RED/undecided -> run the in-app connect flow (tap icon -> Connect
          the SPP device -> password 0000 -> OK) and verify the icon went
          green before returning True.

        Leaves the app on the home screen (popup closed)."""
        prefix = (prefix or self._default_prefix()).upper()

        # The icon lives on the home screen; recover there if needed.
        if self._icon_el() is None:
            try:
                pages.home.dismiss_native_alerts(first_timeout=1,
                                                 context="printer-connect")
                pages.home.go_back_to_home()
            except Exception:                                # noqa: BLE001
                pass
        el = self._icon_el()
        if el is None:
            print("  [PRINTER-CONNECT] printer icon not found (not on home?) "
                  "-- cannot check; treating as not connected")
            return False

        green = self._icon_is_green(el)
        if green is True:
            print("  [PRINTER-CONNECT] icon GREEN — printer already "
                  "connected")
            return True
        state = "RED" if green is False else "undecided"
        print(f"  [PRINTER-CONNECT] icon {state} — running in-app connect "
              f"flow")
        return self._connect_flow(prefix)

    def _open_popup(self):
        for attempt in range(3):
            el = self._icon_el()
            if el is None:
                return False
            self.tap_element(el)
            time.sleep(1.5)
            if self.is_element_present(self.POPUP_TITLE, timeout=4):
                return True
            print(f"  [PRINTER-CONNECT] popup not open (attempt "
                  f"{attempt + 1}/3) -- re-tapping icon")
        return False

    def _close_popup(self):
        if self.is_element_present(self.CLOSE_MODAL, timeout=2):
            try:
                self.tap_element(self.find_element(self.CLOSE_MODAL, timeout=3))
                time.sleep(1)
                return
            except Exception:                                # noqa: BLE001
                pass
        self.press_back()
        time.sleep(1)

    def _tap_connect_for(self, prefix):
        """Tap the 'Connect' in the row of the device whose name starts with
        `prefix`. Matches Connect-to-SPP-row by vertical overlap, so it never
        hits the SHUKURENAI row or the (already-connected) Disconnect."""
        name_loc = (AppiumBy.ANDROID_UIAUTOMATOR,
                    f'new UiSelector().textStartsWith("{prefix}")')
        # 'Connect' is a clickable ViewGroup (content-desc) wrapping a
        # TextView; match either.
        connect_locs = [
            (AppiumBy.ANDROID_UIAUTOMATOR,
             'new UiSelector().description("Connect")'),
            (AppiumBy.ANDROID_UIAUTOMATOR,
             'new UiSelector().text("Connect")'),
        ]
        names = self.driver.find_elements(*name_loc)
        connects = []
        for loc in connect_locs:
            try:
                connects.extend(self.driver.find_elements(*loc))
            except Exception:                                # noqa: BLE001
                pass
        if not names or not connects:
            return False

        def cy(e):
            r = e.rect
            return r["y"] + r["height"] // 2

        for nm in names:
            ny = cy(nm)
            for c in connects:
                if abs(cy(c) - ny) < 70:  # same row
                    self.tap_element(c)
                    print(f"  [PRINTER-CONNECT] tapped Connect for a "
                          f"'{prefix}...' device")
                    return True
        return False

    def _enter_password(self, pw="0000"):
        """Type the pairing password into the popup's field and confirm.
        The password popup wasn't captured live (printer was already
        connected during recon), so this is built to the owner's spec
        (0000 -> OK) and is defensive: dumps if it can't find the field."""
        field = (AppiumBy.CLASS_NAME, "android.widget.EditText")
        if not self.is_element_present(field, timeout=6):
            # No password prompt appeared -- some devices connect without one.
            print("  [PRINTER-CONNECT] no password field appeared "
                  "(connected without prompt?)")
            return
        try:
            el = self.find_element(field, timeout=4)
            el.click()
            el.clear()
            self.driver.execute_script('mobile: type', {'text': pw})
            self._hide_keyboard_if_shown()
        except Exception as e:                               # noqa: BLE001
            print(f"  [PRINTER-CONNECT] password entry issue ({e})")
        for ok in ((AppiumBy.ANDROID_UIAUTOMATOR,
                    'new UiSelector().textMatches("(?i)^(OK|SAMBUNG|CONNECT)$")'),
                   self.NATIVE_ALERT_OK):
            if self.is_element_present(ok, timeout=2):
                try:
                    self.tap_element(self.find_element(ok, timeout=2))
                    break
                except Exception:                            # noqa: BLE001
                    pass
        time.sleep(1.5)

    def _connect_flow(self, prefix):
        if not self._open_popup():
            self._dump("printer_popup_not_open.xml")
            print("  [PRINTER-CONNECT] popup never opened")
            return False

        # Already app-connected? (icon colour was undecided but the popup
        # shows a Disconnect for our device) -> nothing to do.
        if self.is_element_present(
                (AppiumBy.ANDROID_UIAUTOMATOR,
                 'new UiSelector().description("Disconnect")'), timeout=2) \
                and self.is_element_present(
                    (AppiumBy.ANDROID_UIAUTOMATOR,
                     f'new UiSelector().textStartsWith("{prefix}")'), timeout=2):
            # Verify it's the app section (Disconnect present) -> connected.
            print("  [PRINTER-CONNECT] popup shows Disconnect for the "
                  "printer — already connected")
            self._close_popup()
            return self.is_connected() is True

        if not self._tap_connect_for(prefix):
            self._dump("printer_no_connect_row.xml")
            print(f"  [PRINTER-CONNECT] no 'Connect' row for a '{prefix}...' "
                  f"device found")
            self._close_popup()
            return False
        time.sleep(1.5)
        self._enter_password("0000")

        # Popup may auto-close on success; close it otherwise.
        if self.is_element_present(self.POPUP_TITLE, timeout=2):
            self._close_popup()

        # Verify the icon actually turned green.
        time.sleep(2)
        ok = self.is_connected() is True
        print(f"  [PRINTER-CONNECT] after connect flow: icon "
              f"{'GREEN — connected' if ok else 'still not green'}")
        return ok

"""
Senarai (List) page — Page Object Model.
Flow: Open calendar -> tap start day -> tap end day (picker auto-closes) ->
click Semak -> records displayed.

NOTE: per the real manual flow, the date picker is a calendar you tap days
on (not text fields to type dates into). The previous version of this file
incorrectly used send_keys() on non-existent date text fields.

NOTE: "Hantar" (Hantar Data / Hantar Gambar / Data Ralat / Hantar Semula)
is its own separate menu — see hantar_page.py. It has been removed from
this file.
"""

from appium.webdriver.common.appiumby import AppiumBy
from selenium.common.exceptions import TimeoutException
from pages.base_page import BasePage


class SenaraiPage(BasePage):
    """Senarai screen — record listing with calendar date filter."""

    # ---- Page title ----
    PAGE_TITLE = (AppiumBy.ANDROID_UIAUTOMATOR,
                  'new UiSelector().textContains("Senarai")')

    # ---- Calendar icon ----
    # Confirmed via live UI dump: this is an icon-font glyph, not the
    # literal word "Kalendar" -- same convention as HAMBURGER in
    # base_page.py and BUTTON_SNAP/BUTTON_TICK_CONFIRM in
    # daftar_kompaun_page.py. The plain XML dump renders this as
    # content-desc="" (the private-use glyph doesn't serialize into the
    # dump), but get_attribute('content-desc') on the live element
    # confirms the real value is "".
    ICON_KALENDAR = (AppiumBy.ACCESSIBILITY_ID, "")

    # ---- Semak button ----
    # Confirmed via live UI dump: this element's actual text is empty
    # ("") -- the visible "SEMAK" label lives in content-desc instead
    # (and is upper-case, not "Semak").
    BUTTON_SEMAK = (AppiumBy.ACCESSIBILITY_ID, "SEMAK")

    # ========================================================================
    # Actions
    # ========================================================================

    def is_senarai_screen_displayed(self):
        """Verify we are on the Senarai screen."""
        return self.is_element_present(self.PAGE_TITLE, timeout=10)

    # Mana-mana sel hari dalam kalendar (resource-id "undefined.day_YYYY-MM-DD",
    # lihat select_day) -- bukti kalendar BENAR-BENAR terbuka.
    ANY_DAY_CELL = (AppiumBy.ANDROID_UIAUTOMATOR,
                    'new UiSelector().resourceIdMatches('
                    '".*day_\\d{4}-\\d{2}-\\d{2}$")')

    def open_calendar(self):
        """Tap the calendar icon to open the date picker -- VERIFIED
        (a day cell must appear), retried up to 3x.

        >>> 2026-09-04: run verify (fix #1-6) buktikan refresh_list()
        gagal DI SINI: log "Opening calendar date picker..." ->
        "Selecting day: 2026-09-01" -> find_clickable gagal. Dump
        clickfail_1788505743.xml: SIFAR elemen ".day_" -- kalendar TAK
        terbuka langsung, skrin masih senarai. wait_and_click() lama
        guna el.click() = ACTION_CLICK aksesibiliti, yang RN Pressable
        app ni abaikan secara senyap (peraturan #1 CLAUDE.md "Penemuan
        tentang aplikasi ini"). click() lapor berjaya, tiada apa
        berlaku, select_day pula yang tumbang. Tampal: wait_and_tap()
        (tap koordinat mentah) + sahkan sel hari muncul + cuba semula,
        ikut peraturan "setiap tap kritikal mesti disahkan". <<<
        """
        import time
        for cubaan in range(3):
            suffix = "" if cubaan == 0 else f" (cubaan {cubaan + 1}/3)"
            print(f"  [SENARAI] Opening calendar date picker...{suffix}")
            self.wait_and_tap(self.ICON_KALENDAR)
            time.sleep(1.0)
            if self.is_element_present(self.ANY_DAY_CELL, timeout=4):
                return
            self.dismiss_native_alerts(first_timeout=1,
                                       context="Senarai buka kalendar")
        raise TimeoutException(
            "Kalendar tidak terbuka selepas 3 tap pada ICON_KALENDAR "
            "(tiada sel hari muncul)")

    def select_day(self, day_number, year=None, month=None, role=None):
        """Tap a day number inside the open calendar picker.
        role="start"/"end" verifies the calendar's own "period" marker
        on that cell (with retry); None = plain tap, legacy behaviour.

        Confirmed via live UI dump: matching on the bare day-number text
        (e.g. "30") is ambiguous -- the calendar renders the leading/
        trailing days of adjacent months with the same number (e.g. the
        June view's trailing placeholder cell shows "1" for July 1, and
        its leading cell shows "30" for June 30 sitting right next to
        the real July 30), and a plain text() match can silently
        resolve to the wrong month's day, snapping the whole picker to
        the wrong month.

        Each day Button instead has a unique resource-id in the form
        "undefined.day_YYYY-MM-DD" (e.g. "undefined.day_2026-06-30") --
        match on that instead. Defaults to today's year/month since the
        calendar always opens on the current month.
        """
        import datetime
        today = datetime.date.today()
        y = year or today.year
        m = month or today.month
        date_str = f"{y:04d}-{m:02d}-{int(day_number):02d}"
        print(f"  [SENARAI] Selecting day: {date_str}")
        day_locator = (AppiumBy.ANDROID_UIAUTOMATOR,
                       f'new UiSelector().resourceId("undefined.day_{date_str}")')
        # >>> 2026-09-04: dump clickfail_1788507286.xml (P-004, kod lama)
        # buktikan tap hari AKHIR boleh silent no-op: hari 1 bertanda
        # content-desc "... period start " tapi hari 4 ("today ...")
        # TIADA tanda "period" -- julat tak lengkap, kalendar TAK
        # auto-tutup (35 sel hari + "Close Calendar" masih ada), SEMAK
        # tertutup di bawahnya -> find_clickable(SEMAK) gagal. Tampal:
        # tap mentah (wait_and_tap) + SAHKAN tanda "period" pada sel hari
        # tu sendiri (label aksesibiliti kalendar) + cuba semula. Untuk
        # hari AKHIR, kalendar yang dah hilang (auto-tutup) pun dikira
        # berjaya. role=None kekal tingkah laku lama (tap tanpa sahkan). <<<
        import time
        if role is None:
            self.wait_and_tap(day_locator, timeout=10)
            return
        marked = (AppiumBy.ANDROID_UIAUTOMATOR,
                  f'new UiSelector().resourceId("undefined.day_{date_str}")'
                  '.descriptionContains("period")')
        for cubaan in range(3):
            self.wait_and_tap(day_locator, timeout=10)
            time.sleep(0.8)
            if role == "end" and not self.is_element_present(
                    self.ANY_DAY_CELL, timeout=1):
                return  # kalendar auto-tutup = julat lengkap
            if self.is_element_present(marked, timeout=2):
                return
            print(f"  [SENARAI] hari {date_str} tak bertanda 'period' "
                  f"(cubaan {cubaan + 1}/3) -- tap semula...")
        raise TimeoutException(
            f"Hari {date_str} ({role}) tidak berjaya dipilih selepas 3 tap")

    CALENDAR_CLOSE = (AppiumBy.ANDROID_UIAUTOMATOR,
                      'new UiSelector().text("Close Calendar")')

    def _tutup_kalendar_jika_masih_buka(self):
        """Selepas julat dipilih, kalendar sepatutnya auto-tutup. Kalau
        masih terbuka (sel hari masih ada), tap 'Close Calendar' supaya
        butang SEMAK tak tertutup di bawahnya."""
        import time
        if self.is_element_present(self.ANY_DAY_CELL, timeout=2):
            print("  [SENARAI] kalendar masih terbuka selepas julat -- "
                  "tap 'Close Calendar'")
            try:
                self.wait_and_tap(self.CALENDAR_CLOSE, timeout=5)
            except Exception:                                # noqa: BLE001
                self.driver.back()
            time.sleep(1)

    def click_semak(self):
        """Tap the Semak (Check) button to filter records."""
        print("  [SENARAI] Clicking Semak...")
        # 2026-09-04: wait_and_tap ganti wait_and_click (RN Pressable,
        # lihat nota open_calendar). Caller sahkan ROW_LOCATOR selepas.
        self._tutup_kalendar_jika_masih_buka()
        self.wait_and_tap(self.BUTTON_SEMAK)

    def is_records_displayed(self, timeout=10):
        """Check if any record row is displayed after filtering.

        Confirmed via live UI dump: there's no RecyclerView on this
        screen at all -- rows are plain android.view.ViewGroup elements
        inside a HorizontalScrollView, each with a content-desc summary
        like "P, 2026-07-01, 10:35, M, A, msc" (record type, date, time,
        etc., comma-separated). Match on that shape (a content-desc
        containing a YYYY-MM-DD date) rather than a nonexistent class,
        which meant this check always reported "no records" even when
        the table clearly had rows on screen.
        """
        found = self.is_element_present(
            (AppiumBy.ANDROID_UIAUTOMATOR,
             'new UiSelector().className("android.view.ViewGroup")'
             '.descriptionMatches(".*\\d{4}-\\d{2}-\\d{2}.*")'),
            timeout=timeout,
        )
        if found:
            print("  [SENARAI] Records displayed — PASS")
        else:
            print("  [SENARAI] WARNING: No records displayed")
        return found

    # ------------------------------------------------------------------
    # v3 additions: row inspection / record opening (SK-001, Serah, H-*)
    # ------------------------------------------------------------------

    ROW_LOCATOR = (AppiumBy.ANDROID_UIAUTOMATOR,
                   'new UiSelector().className("android.view.ViewGroup")'
                   '.descriptionMatches(".*\\d{4}-\\d{2}-\\d{2}.*")')

    def ensure_records_listed(self, start_day=1, end_day=30):
        """Make sure the record table has rows: if none are showing yet,
        run the calendar date filter (v2-proven interaction). Returns
        True if rows are visible afterwards."""
        if self.is_element_present(self.ROW_LOCATOR, timeout=5):
            print("  [SENARAI] Records already listed")
            return True
        print("  [SENARAI] No records listed yet -- applying date filter...")
        self.open_calendar()
        self.select_day(start_day, role="start")
        self.select_day(end_day, role="end")
        self.click_semak()
        # The filter query can end with a native result alert on top.
        self.dismiss_native_alerts(first_timeout=3, context="Senarai filter")
        return self.is_element_present(self.ROW_LOCATOR, timeout=10)

    def get_row_descriptions(self):
        """Return the content-desc of every visible record row.

        Row shape confirmed live in v2 (see is_records_displayed):
        plain ViewGroups whose content-desc is a comma-separated summary
        like "P, 2026-07-01, 10:35, M, A, msc" -- first token is the
        record-type letter (P/N/K/L/S, matching the No Kompaun/Notis
        prefixes in the SENARAI KOMPAUN sheet), and the M/H token is the
        STATUS HANTAR column."""
        descs = []
        try:
            for el in self.driver.find_elements(*self.ROW_LOCATOR):
                d = el.get_attribute("content-desc")
                if d:
                    descs.append(d)
        except Exception as e:
            print(f"  [SENARAI] WARNING: could not read row descriptions "
                  f"({e})")
        return descs

    def get_no_akaun_list(self):
        """Read the NO AKAUN column top-to-bottom. Confirmed via live
        recon dump (ui_dumps/recon_senarai_table.xml): each cell is a
        clickable ViewGroup whose content-desc is the record number
        (e.g. "IPA3K260716031"), in row order."""
        loc = (AppiumBy.ANDROID_UIAUTOMATOR,
               'new UiSelector().descriptionMatches("IPA\\w+")')
        numbers = []
        try:
            for el in self.driver.find_elements(*loc):
                d = el.get_attribute("content-desc")
                if d:
                    numbers.append(d)
        except Exception as e:
            print(f"  [SENARAI] WARNING: could not read NO AKAUN cells "
                  f"({e})")
        return numbers

    def rows_for_jenis(self, jenis_letter):
        """Rows whose summary starts with the given record-type letter."""
        prefix = f"{jenis_letter.upper()},"
        return [d for d in self.get_row_descriptions()
                if d.upper().startswith(prefix)]

    def open_record_by_jenis(self, jenis_letter, dump_name=None,
                             which="first"):
        """Tap a record row of the given jenis and dump the page source
        of whatever opens. which="last" picks the newest record (highest
        row = latest No Kompaun -- needed by the Kemaskini flows, since
        an update issues a NEW record number per the tester's SENARAI
        sheet). Returns the tapped row's desc.

        Raises TimeoutException if no row of that jenis is on screen."""
        loc = (AppiumBy.ANDROID_UIAUTOMATOR,
               'new UiSelector().className("android.view.ViewGroup")'
               f'.descriptionMatches("^{jenis_letter.upper()},.*'
               '\\d{4}-\\d{2}-\\d{2}.*")')
        el = self.find_element(loc, timeout=10)
        if which == "last":
            try:
                els = self.driver.find_elements(*loc)
                if els:
                    el = els[-1]
            except Exception:
                pass
        desc = el.get_attribute("content-desc")
        print(f"  [SENARAI] Opening record row: {desc}")
        self.tap_element(el)
        import time
        time.sleep(2)
        if dump_name:
            try:
                import os
                os.makedirs("ui_dumps", exist_ok=True)
                path = os.path.join("ui_dumps", dump_name)
                with open(path, "w", encoding="utf-8") as f:
                    f.write(self.driver.page_source)
                print(f"  [SENARAI] Record view page source dumped to {path}")
            except Exception:
                pass
        return desc

    RECORD_POPUP_TITLE = (AppiumBy.ANDROID_UIAUTOMATOR,
                          'new UiSelector().text("KEMASKINI DATA")')

    def _scroll_senarai_down(self):
        """Swipe the record table up to reveal lower rows. Returns True if
        the list actually moved (page source changed), False at the end."""
        import time
        try:
            before = len(self.driver.page_source)
        except Exception:                                    # noqa: BLE001
            before = -1
        try:
            self.driver.swipe(540, 1650, 540, 650, 600)
            time.sleep(0.6)
        except Exception:                                    # noqa: BLE001
            return False
        try:
            return len(self.driver.page_source) != before
        except Exception:                                    # noqa: BLE001
            return True

    def refresh_list(self, start_day=1, end_day=None):
        """Force a fresh date-filter query (calendar -> Semak) so the
        record table reflects the latest data, instead of whatever was
        already on screen from an earlier navigation into Senarai.

        >>> 2026-09-04: run verify (tanpa-bersih, jambatan_log3, fix
        #1-5 semua aktif) buktikan N-004/P-004/K-004 (dan malah N-004
        pun kali ni gagal LEBIH AWAL, masa BUKA rekod baru sahaja utk
        edit) FAIL dengan corak sama: "Record ... NOT found after 2
        scroll(s)" / verify_updated punya open_record_by_jenis timeout
        -- WALAUPUN [ARTIFACT] record number read mengesahkan submit
        BERJAYA saat-saat sebelum tu. Punca: ensure_records_listed()
        punya jalan pintas "Records already listed" (ROW_LOCATOR dah
        ada dari navigasi SEBELUM ini, sebab no_reset=True/app state
        kekal) langkau terus filter tarikh -- jadual yang discroll
        ialah RENDER LAMA, bukan query baharu yang termasuk rekod yang
        baru sahaja dicipta/dikemaskini saat lepas. Method ni bagi
        caller cara paksa refresh eksplisit sebelum give up. <<<
        """
        import calendar
        import datetime
        import time
        if end_day is None:
            # Hari AKHIR bulan (bukan hari ini): kalau penapis app guna
            # "tarikh <= end 00:00", rekod yang dicipta petang ini akan
            # terkecuali. ensure_records_listed() yang terbukti (v2) pun
            # guna end_day=30 -- ikut corak sama, tapi betul utk Feb/31.
            today = datetime.date.today()
            end_day = calendar.monthrange(today.year, today.month)[1]
        print("  [SENARAI] Forcing fresh date-filter refresh...")
        self.open_calendar()
        self.select_day(start_day, role="start")
        self.select_day(end_day, role="end")
        self.click_semak()
        self.dismiss_native_alerts(first_timeout=3,
                                   context="Senarai refresh")
        time.sleep(1)

    # ------------------------------------------------------------------
    # Pagination (react-native-paper DataTable.Pagination)
    # ------------------------------------------------------------------
    # >>> 2026-09-04: ROOT CAUSE sebenar "Record ... NOT found even after
    # refresh" utk N-004/P-004/K-004. Diagnostik (test_zz_diag_senarai_
    # dump, dump diag_senarai_1..4.xml) buktikan senarai SENTIASA papar
    # 10 baris yang SAMA (rekod kompaun paling LAMA hari ini, 02:59 ->
    # 14:10) sebelum/selepas refresh julat 1..30 & selepas tatal --
    # penapis tarikh memang bertukar (04..05 -> 01..30) tapi baris tak.
    # Di bawah baris ke-10 ada ViewGroup content-desc
    # "pagination-container": jadual ini DIPAGINASI 10 baris/halaman.
    # Rekon lama (recon_senarai_table_hscroll.xml, recon_hantar_*.xml)
    # tunjuk isi container tu = label "Rows per page"
    # (desc "selectPageDropdownLabel") + Button desc "10" (saiz halaman)
    # + ikon -- iaitu komponen react-native-paper DataTable.Pagination,
    # yang butang seterusnya/sebelumnya ber-accessibilityLabel
    # "page-next"/"page-previous" (dan "page-first"/"page-last"). Isi
    # container tiada dalam dump hari ini kerana jadual berada dalam
    # HorizontalScrollView -- kawalan itu di luar skrin ke kanan, jadi
    # UiAutomator tak senaraikannya. Garis masa padan sempurna: rekod
    # dijumpai selagi rekod hari ini <= 10 (02:14-04:40 UTC), gagal lepas
    # tu -- rekod baharu (termasuk SEMUA rekod N) duduk di halaman 2+.
    # Tatal menegak tak pernah tukar halaman. Fix: selepas satu halaman
    # habis ditatal, tekan page-next (dedahkan dulu dgn UiScrollable
    # mendatar / swipe kiri pada baris pagination), tatal ke atas,
    # cari semula; ulang hingga jumpa atau page-next tidak aktif. <<<
    # >>> 2026-09-04 (diag v2, dump diag_senarai_5_pagination.xml, selepas
    # dedah mendatar): label SEBENAR build ini -- butang seterusnya =
    # "chevron-right", sebelumnya = "chevron-left" (versi react-native-
    # paper ini label ikut nama ikon, bukan "page-next"); "page-first" &
    # "page-last" wujud; label kiraan "1-10 of 21" (desc "label"); Button
    # desc "10" = saiz halaman. Guna descriptionMatches supaya kedua-dua
    # nama (versi lama/baru) padan. <<<
    PAGINATION_CONTAINER = (AppiumBy.ACCESSIBILITY_ID, "pagination-container")
    PAGE_NEXT = (AppiumBy.ANDROID_UIAUTOMATOR,
                 'new UiSelector().descriptionMatches("chevron-right|page-next")')
    PAGE_PREV = (AppiumBy.ANDROID_UIAUTOMATOR,
                 'new UiSelector().descriptionMatches("chevron-left|page-previous")')
    PAGE_FIRST = (AppiumBy.ACCESSIBILITY_ID, "page-first")
    PAGE_LAST = (AppiumBy.ACCESSIBILITY_ID, "page-last")
    PAGE_LABEL = (AppiumBy.ACCESSIBILITY_ID, "label")   # "1-10 of 21"

    def _dedah_kawalan_pagination(self, desc):
        """Bring a pagination button into view: direct check, then
        horizontal UiScrollable scrollIntoView, then a manual swipe-left
        along the pagination row. `desc` may be a regex alternation
        (e.g. "chevron-right|page-next"). Returns True if visible."""
        import time
        from config import IMPLICIT_WAIT
        loc = (AppiumBy.ANDROID_UIAUTOMATOR,
               f'new UiSelector().descriptionMatches("{desc}")')
        if self.is_element_present(loc, timeout=2):
            return True
        for inst in (0, 1, 2):
            expr = ('new UiScrollable(new UiSelector().scrollable(true)'
                    f'.instance({inst})).setAsHorizontalList()'
                    '.scrollIntoView(new UiSelector()'
                    f'.descriptionMatches("{desc}"))')
            self.driver.implicitly_wait(0)
            try:
                self.driver.find_element(AppiumBy.ANDROID_UIAUTOMATOR, expr)
                print(f"  [SENARAI] '{desc}' didedahkan oleh UiScrollable "
                      f"mendatar instance({inst})")
                return True
            except Exception:                                # noqa: BLE001
                continue
            finally:
                self.driver.implicitly_wait(IMPLICIT_WAIT)
        try:
            cont = self.find_element(self.PAGINATION_CONTAINER, timeout=2)
            r = cont.rect
            y = r["y"] + r["height"] // 2
            for _ in range(3):
                self.driver.swipe(950, y, 120, y, 500)
                time.sleep(0.6)
                if self.is_element_present(loc, timeout=1):
                    print(f"  [SENARAI] '{desc}' didedahkan oleh swipe "
                          f"mendatar pada baris pagination")
                    return True
        except Exception:                                    # noqa: BLE001
            pass
        return self.is_element_present(loc, timeout=1)

    def _scroll_senarai_to_left(self):
        """Swipe right (finger left->right) along a table row until the
        NO AKAUN column is visible again. Needed after any horizontal
        reveal of the pagination controls (diag v2: selepas tap
        chevron-right, get_no_akaun_list() pulang [] kerana lajur NO
        AKAUN terkeluar skrin ke KIRI -- jadual dalam HorizontalScrollView
        kekal pada kedudukan mendatar yang ditatal)."""
        import time
        no_akaun = (AppiumBy.ANDROID_UIAUTOMATOR,
                    'new UiSelector().descriptionMatches("IPA\\w+|NO AKAUN")')
        for _ in range(4):
            if self.is_element_present(no_akaun, timeout=1):
                return True
            try:
                self.driver.swipe(150, 1000, 1000, 1000, 400)
                time.sleep(0.5)
            except Exception:                                # noqa: BLE001
                break
        return self.is_element_present(no_akaun, timeout=1)

    def _scroll_senarai_to_top(self):
        """Swipe down until the page source stops changing (top)."""
        import time
        for _ in range(6):
            try:
                before = len(self.driver.page_source)
                self.driver.swipe(540, 700, 540, 1700, 500)
                time.sleep(0.5)
                if len(self.driver.page_source) == before:
                    break
            except Exception:                                # noqa: BLE001
                break

    def next_page(self):
        """Tap 'page-next' if present and enabled. Returns True only if
        the visible NO AKAUN set actually changed (a real new page)."""
        import time
        # Baca set NO AKAUN SEBELUM sebarang tatal mendatar (selepas
        # dedah chevron, lajur NO AKAUN terkeluar skrin & senarai kosong).
        self._scroll_senarai_to_left()
        before = self.get_no_akaun_list()
        # pagination-container duduk DI BAWAH baris ke-10 -- pastikan
        # senarai ditatal ke bawah dahulu supaya ia dalam viewport.
        for _ in range(5):
            if not self._scroll_senarai_down():
                break
        if not self._dedah_kawalan_pagination("chevron-right|page-next"):
            print("  [SENARAI] tiada kawalan seterusnya (chevron-right) "
                  "kelihatan")
            self._scroll_senarai_to_left()
            return False
        # 2026-09-04 18:46 (N-004 verify): UiScrollable mendatar lapor
        # "didedahkan" tapi find_element chevron-right timeout 3s -- lapor
        # palsu (instance(0) mungkin senarai menegak). Cuba semula dgn
        # swipe mendatar manual pada baris pagination sebelum mengalah.
        el = None
        for _cuba in range(3):
            try:
                el = self.find_element(self.PAGE_NEXT, timeout=3)
                break
            except TimeoutException:
                try:
                    cont = self.find_element(self.PAGINATION_CONTAINER,
                                             timeout=2)
                    r = cont.rect
                    y = r["y"] + r["height"] // 2
                    self.driver.swipe(950, y, 120, y, 500)
                except Exception:                            # noqa: BLE001
                    self._scroll_senarai_down()
                time.sleep(0.8)
        if el is None:
            print("  [SENARAI] chevron-right tidak dapat dicapai selepas "
                  "3 percubaan")
            self._scroll_senarai_to_left()
            return False
        if str(el.get_attribute("enabled")).lower() == "false":
            print("  [SENARAI] chevron-right tidak aktif -- halaman terakhir")
            self._scroll_senarai_to_left()
            return False
        try:
            lbl = self.find_element(self.PAGE_LABEL, timeout=1).text
            print(f"  [SENARAI] pagination sebelum: {lbl}")
        except Exception:                                    # noqa: BLE001
            pass
        self.tap_element(el)
        time.sleep(1.5)
        self._scroll_senarai_to_left()
        self._scroll_senarai_to_top()
        after = self.get_no_akaun_list()
        moved = bool(after) and after != before
        print(f"  [SENARAI] page-next -> "
              f"{'halaman baharu' if moved else 'senarai TAK berubah'}: "
              f"{after[:3]}{'...' if len(after) > 3 else ''}")
        return moved

    def open_record_by_number(self, no_rekod, max_scrolls=20):
        """Open the record whose NO KOMPAUN/NOTIS is `no_rekod` (e.g.
        IPA3N260728054) -- select by NUMBER, not by position. Scrolls the
        Senarai to find it (the staging list is long now). Returns True if
        the record view opened; False if the number is never found.

        NEVER falls back to another row -- opening the wrong record is worse
        than an honest miss. This replaces the which='first'/'last'
        positional pick, which silently printed/updated STALE records and
        made Cetak/Serah/Kemaskini pass even when the create failed.

        Tries twice: once against whatever is already listed, and -- only
        if that misses -- once more after refresh_list() forces a fresh
        query (see refresh_list's 2026-09-04 note for why the first pass
        alone can miss a record created/updated moments earlier)."""
        import time
        if not no_rekod:
            return False
        cell = (AppiumBy.ANDROID_UIAUTOMATOR,
                f'new UiSelector().descriptionContains("{no_rekod}")')

        def _cari_dalam_halaman():
            """Scroll the CURRENT page top-to-bottom looking for the cell.
            Returns True (opened), False (found but view didn't open --
            caller must stop), or None (not on this page)."""
            for _ in range(max_scrolls):
                if self.is_element_present(cell, timeout=1):
                    el = self.find_element(cell, timeout=3)
                    self.tap_element(el)
                    time.sleep(2)
                    if self.is_element_present(self.RECORD_POPUP_TITLE,
                                               timeout=3):
                        print(f"  [SENARAI] Opened record {no_rekod} by "
                              f"number")
                        return True
                    # The number cell may not itself open the popup on
                    # every build -- tap the full-width summary row in
                    # the same y-band.
                    try:
                        r = el.rect
                        cy = r["y"] + r["height"] // 2
                        for row in self.driver.find_elements(
                                *self.ROW_LOCATOR):
                            rr = row.rect
                            if rr["y"] <= cy <= rr["y"] + rr["height"]:
                                self.tap_element(row)
                                time.sleep(2)
                                if self.is_element_present(
                                        self.RECORD_POPUP_TITLE, timeout=3):
                                    print(f"  [SENARAI] Opened record "
                                          f"{no_rekod} by number (via row)")
                                    return True
                                break
                    except Exception:                        # noqa: BLE001
                        pass
                    print(f"  [SENARAI] Found {no_rekod} but the record "
                          f"view did not open")
                    return False
                if not self._scroll_senarai_down():
                    return None  # end of this page
            return None

        # 2 pusingan: (0) senarai sedia ada, (1) selepas refresh_list().
        # Dalam setiap pusingan, jelajah SEMUA halaman pagination
        # (lihat nota PAGINATION di atas -- rekod baharu duduk di
        # halaman 2+, tatal menegak sahaja tak pernah sampai).
        for pusingan in range(2):
            self._scroll_senarai_to_left()
            self._scroll_senarai_to_top()
            for halaman in range(1, 16):
                hasil = _cari_dalam_halaman()
                if hasil is not None:
                    return hasil
                print(f"  [SENARAI] {no_rekod} tiada di halaman {halaman} "
                      f"-- cuba halaman seterusnya...")
                if not self.next_page():
                    break
            if pusingan == 0:
                print(f"  [SENARAI] Record {no_rekod} not found on any "
                      f"page -- forcing refresh and retrying once...")
                self.refresh_list()
        print(f"  [SENARAI] Record {no_rekod} NOT found even after "
              f"refresh + semua halaman -- refusing to open any other row")
        return False

    def record_popup_shows_number(self, no_rekod):
        """True if the OPEN record view displays `no_rekod` (its
        'NO KOMPAUN/NOTIS: IPA3...' line) -- confirms we opened the right
        record before acting on it (Cetak/Serah/Kemaskini)."""
        if not no_rekod:
            return False
        return self.is_element_present(
            (AppiumBy.ANDROID_UIAUTOMATOR,
             f'new UiSelector().textContains("{no_rekod}")'), timeout=3)

    def filter_by_day_range(self, start_day, end_day):
        """Complete date range filter flow: open calendar, tap start day,
        tap end day (picker auto-dissolves), click Semak, verify records.
        """
        self.open_calendar()
        self.select_day(start_day, role="start")
        self.select_day(end_day, role="end")
        # Calendar auto-closes after selecting the end day — no explicit
        # close action needed here.
        self.click_semak()
        assert self.is_records_displayed(), \
            "FAIL: No records displayed after date filter"
        return True

"""
Senarai (List) page — Page Object Model.
Flow: Open calendar -> tap start day -> tap end day (picker auto-closes) ->
click Semak -> records displayed.

NOTE: per the real manual flow, the date picker is a calendar you tap days
on (not text fields to type dates into). The previous version of this file
incorrectly used send_keys() on non-existent date text fields.

NOTE: "Hantar" (Hantar Data / Hantar Gambar / Data Ralat / Hantar Semula)
is its own separate menu — see hantar_page.py. It has been removed from
this file.
"""

from appium.webdriver.common.appiumby import AppiumBy
from pages.base_page import BasePage


class SenaraiPage(BasePage):
    """Senarai screen — record listing with calendar date filter."""

    # ---- Page title ----
    PAGE_TITLE = (AppiumBy.ANDROID_UIAUTOMATOR,
                  'new UiSelector().textContains("Senarai")')

    # ---- Calendar icon ----
    # Confirmed via live UI dump: this is an icon-font glyph, not the
    # literal word "Kalendar" -- same convention as HAMBURGER in
    # base_page.py and BUTTON_SNAP/BUTTON_TICK_CONFIRM in
    # daftar_kompaun_page.py. The plain XML dump renders this as
    # content-desc="" (the private-use glyph doesn't serialize into the
    # dump), but get_attribute('content-desc') on the live element
    # confirms the real value is "".
    ICON_KALENDAR = (AppiumBy.ACCESSIBILITY_ID, "")

    # ---- Semak button ----
    # Confirmed via live UI dump: this element's actual text is empty
    # ("") -- the visible "SEMAK" label lives in content-desc instead
    # (and is upper-case, not "Semak").
    BUTTON_SEMAK = (AppiumBy.ACCESSIBILITY_ID, "SEMAK")

    # ========================================================================
    # Actions
    # ========================================================================

    def is_senarai_screen_displayed(self):
        """Verify we are on the Senarai screen."""
        return self.is_element_present(self.PAGE_TITLE, timeout=10)

    def open_calendar(self):
        """Tap the calendar icon to open the date picker."""
        print("  [SENARAI] Opening calendar date picker...")
        self.wait_and_click(self.ICON_KALENDAR)

    def select_day(self, day_number, year=None, month=None):
        """Tap a day number inside the open calendar picker.

        Confirmed via live UI dump: matching on the bare day-number text
        (e.g. "30") is ambiguous -- the calendar renders the leading/
        trailing days of adjacent months with the same number (e.g. the
        June view's trailing placeholder cell shows "1" for July 1, and
        its leading cell shows "30" for June 30 sitting right next to
        the real July 30), and a plain text() match can silently
        resolve to the wrong month's day, snapping the whole picker to
        the wrong month.

        Each day Button instead has a unique resource-id in the form
        "undefined.day_YYYY-MM-DD" (e.g. "undefined.day_2026-06-30") --
        match on that instead. Defaults to today's year/month since the
        calendar always opens on the current month.
        """
        import datetime
        today = datetime.date.today()
        y = year or today.year
        m = month or today.month
        date_str = f"{y:04d}-{m:02d}-{int(day_number):02d}"
        print(f"  [SENARAI] Selecting day: {date_str}")
        day_locator = (AppiumBy.ANDROID_UIAUTOMATOR,
                       f'new UiSelector().resourceId("undefined.day_{date_str}")')
        self.wait_and_click(day_locator, timeout=10)

    def click_semak(self):
        """Click the Semak (Check) button to filter records."""
        print("  [SENARAI] Clicking Semak...")
        self.wait_and_click(self.BUTTON_SEMAK)

    def is_records_displayed(self, timeout=10):
        """Check if any record row is displayed after filtering.

        Confirmed via live UI dump: there's no RecyclerView on this
        screen at all -- rows are plain android.view.ViewGroup elements
        inside a HorizontalScrollView, each with a content-desc summary
        like "P, 2026-07-01, 10:35, M, A, msc" (record type, date, time,
        etc., comma-separated). Match on that shape (a content-desc
        containing a YYYY-MM-DD date) rather than a nonexistent class,
        which meant this check always reported "no records" even when
        the table clearly had rows on screen.
        """
        found = self.is_element_present(
            (AppiumBy.ANDROID_UIAUTOMATOR,
             'new UiSelector().className("android.view.ViewGroup")'
             '.descriptionMatches(".*\\d{4}-\\d{2}-\\d{2}.*")'),
            timeout=timeout,
        )
        if found:
            print("  [SENARAI] Records displayed — PASS")
        else:
            print("  [SENARAI] WARNING: No records displayed")
        return found

    # ------------------------------------------------------------------
    # v3 additions: row inspection / record opening (SK-001, Serah, H-*)
    # ------------------------------------------------------------------

    ROW_LOCATOR = (AppiumBy.ANDROID_UIAUTOMATOR,
                   'new UiSelector().className("android.view.ViewGroup")'
                   '.descriptionMatches(".*\\d{4}-\\d{2}-\\d{2}.*")')

    def ensure_records_listed(self, start_day=1, end_day=30):
        """Make sure the record table has rows: if none are showing yet,
        run the calendar date filter (v2-proven interaction). Returns
        True if rows are visible afterwards."""
        if self.is_element_present(self.ROW_LOCATOR, timeout=5):
            print("  [SENARAI] Records already listed")
            return True
        print("  [SENARAI] No records listed yet -- applying date filter...")
        self.open_calendar()
        self.select_day(start_day)
        self.select_day(end_day)
        self.click_semak()
        # The filter query can end with a native result alert on top.
        self.dismiss_native_alerts(first_timeout=3, context="Senarai filter")
        return self.is_element_present(self.ROW_LOCATOR, timeout=10)

    def get_row_descriptions(self):
        """Return the content-desc of every visible record row.

        Row shape confirmed live in v2 (see is_records_displayed):
        plain ViewGroups whose content-desc is a comma-separated summary
        like "P, 2026-07-01, 10:35, M, A, msc" -- first token is the
        record-type letter (P/N/K/L/S, matching the No Kompaun/Notis
        prefixes in the SENARAI KOMPAUN sheet), and the M/H token is the
        STATUS HANTAR column."""
        descs = []
        try:
            for el in self.driver.find_elements(*self.ROW_LOCATOR):
                d = el.get_attribute("content-desc")
                if d:
                    descs.append(d)
        except Exception as e:
            print(f"  [SENARAI] WARNING: could not read row descriptions "
                  f"({e})")
        return descs

    def get_no_akaun_list(self):
        """Read the NO AKAUN column top-to-bottom. Confirmed via live
        recon dump (ui_dumps/recon_senarai_table.xml): each cell is a
        clickable ViewGroup whose content-desc is the record number
        (e.g. "IPA3K260716031"), in row order."""
        loc = (AppiumBy.ANDROID_UIAUTOMATOR,
               'new UiSelector().descriptionMatches("IPA\\w+")')
        numbers = []
        try:
            for el in self.driver.find_elements(*loc):
                d = el.get_attribute("content-desc")
                if d:
                    numbers.append(d)
        except Exception as e:
            print(f"  [SENARAI] WARNING: could not read NO AKAUN cells "
                  f"({e})")
        return numbers

    def rows_for_jenis(self, jenis_letter):
        """Rows whose summary starts with the given record-type letter."""
        prefix = f"{jenis_letter.upper()},"
        return [d for d in self.get_row_descriptions()
                if d.upper().startswith(prefix)]

    def open_record_by_jenis(self, jenis_letter, dump_name=None,
                             which="first"):
        """Tap a record row of the given jenis and dump the page source
        of whatever opens. which="last" picks the newest record (highest
        row = latest No Kompaun -- needed by the Kemaskini flows, since
        an update issues a NEW record number per the tester's SENARAI
        sheet). Returns the tapped row's desc.

        Raises TimeoutException if no row of that jenis is on screen."""
        loc = (AppiumBy.ANDROID_UIAUTOMATOR,
               'new UiSelector().className("android.view.ViewGroup")'
               f'.descriptionMatches("^{jenis_letter.upper()},.*'
               '\\d{4}-\\d{2}-\\d{2}.*")')
        el = self.find_element(loc, timeout=10)
        if which == "last":
            try:
                els = self.driver.find_elements(*loc)
                if els:
                    el = els[-1]
            except Exception:
                pass
        desc = el.get_attribute("content-desc")
        print(f"  [SENARAI] Opening record row: {desc}")
        self.tap_element(el)
        import time
        time.sleep(2)
        if dump_name:
            try:
                import os
                os.makedirs("ui_dumps", exist_ok=True)
                path = os.path.join("ui_dumps", dump_name)
                with open(path, "w", encoding="utf-8") as f:
                    f.write(self.driver.page_source)
                print(f"  [SENARAI] Record view page source dumped to {path}")
            except Exception:
                pass
        return desc

    RECORD_POPUP_TITLE = (AppiumBy.ANDROID_UIAUTOMATOR,
                          'new UiSelector().text("KEMASKINI DATA")')

    def _scroll_senarai_down(self):
        """Swipe the record table up to reveal lower rows. Returns True if
        the list actually moved (page source changed), False at the end."""
        import time
        try:
            before = len(self.driver.page_source)
        except Exception:                                    # noqa: BLE001
            before = -1
        try:
            self.driver.swipe(540, 1650, 540, 650, 600)
            time.sleep(0.6)
        except Exception:                                    # noqa: BLE001
            return False
        try:
            return len(self.driver.page_source) != before
        except Exception:                                    # noqa: BLE001
            return True

    def open_record_by_number(self, no_rekod, max_scrolls=20):
        """Open the record whose NO KOMPAUN/NOTIS is `no_rekod` (e.g.
        IPA3N260728054) -- select by NUMBER, not by position. Scrolls the
        Senarai to find it (the staging list is long now). Returns True if
        the record view opened; False if the number is never found.

        NEVER falls back to another row -- opening the wrong record is worse
        than an honest miss. This replaces the which='first'/'last'
        positional pick, which silently printed/updated STALE records and
        made Cetak/Serah/Kemaskini pass even when the create failed."""
        import time
        if not no_rekod:
            return False
        cell = (AppiumBy.ANDROID_UIAUTOMATOR,
                f'new UiSelector().descriptionContains("{no_rekod}")')
        i = 0
        for i in range(max_scrolls):
            if self.is_element_present(cell, timeout=1):
                el = self.find_element(cell, timeout=3)
                self.tap_element(el)
                time.sleep(2)
                if self.is_element_present(self.RECORD_POPUP_TITLE, timeout=3):
                    print(f"  [SENARAI] Opened record {no_rekod} by number")
                    return True
                # The number cell may not itself open the popup on every
                # build -- tap the full-width summary row in the same y-band.
                try:
                    r = el.rect
                    cy = r["y"] + r["height"] // 2
                    for row in self.driver.find_elements(*self.ROW_LOCATOR):
                        rr = row.rect
                        if rr["y"] <= cy <= rr["y"] + rr["height"]:
                            self.tap_element(row)
                            time.sleep(2)
                            if self.is_element_present(
                                    self.RECORD_POPUP_TITLE, timeout=3):
                                print(f"  [SENARAI] Opened record {no_rekod} "
                                      f"by number (via row)")
                                return True
                            break
                except Exception:                            # noqa: BLE001
                    pass
                print(f"  [SENARAI] Found {no_rekod} but the record view did "
                      f"not open")
                return False
            if not self._scroll_senarai_down():
                break  # list stopped moving -- reached the end
        print(f"  [SENARAI] Record {no_rekod} NOT found after {i + 1} "
              f"scroll(s) -- refusing to open any other row")
        return False

    def record_popup_shows_number(self, no_rekod):
        """True if the OPEN record view displays `no_rekod` (its
        'NO KOMPAUN/NOTIS: IPA3...' line) -- confirms we opened the right
        record before acting on it (Cetak/Serah/Kemaskini)."""
        if not no_rekod:
            return False
        return self.is_element_present(
            (AppiumBy.ANDROID_UIAUTOMATOR,
             f'new UiSelector().textContains("{no_rekod}")'), timeout=3)

    def filter_by_day_range(self, start_day, end_day):
        """Complete date range filter flow: open calendar, tap start day,
        tap end day (picker auto-dissolves), click Semak, verify records.
        """
        self.open_calendar()
        self.select_day(start_day)
        self.select_day(end_day)
        # Calendar auto-closes after selecting the end day — no explicit
        # close action needed here.
        self.click_semak()
        assert self.is_records_displayed(), \
            "FAIL: No records displayed after date filter"
        return True

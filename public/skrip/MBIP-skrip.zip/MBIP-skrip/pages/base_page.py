"""
Base Page — shared methods for all Page Objects.
Provides common locator strategies and wait utilities.
"""

from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import (
    TimeoutException,
    NoSuchElementException,
    StaleElementReferenceException,
)


class BasePage:
    """Base class with common element interaction methods."""

    # Common locators that may be needed across pages
    BUTTON_BACK = (AppiumBy.ACCESSIBILITY_ID, "Back")
    BUTTON_YA = (AppiumBy.ANDROID_UIAUTOMATOR,
                  'new UiSelector().text("Ya")')
    BUTTON_TIDAK = (AppiumBy.ANDROID_UIAUTOMATOR,
                    'new UiSelector().text("Tidak")')
    BUTTON_OK = (AppiumBy.ANDROID_UIAUTOMATOR,
                 'new UiSelector().text("OK")')
    BUTTON_CLOSE = (AppiumBy.ANDROID_UIAUTOMATOR,
                    'new UiSelector().description("Close")')
    HAMBURGER = (AppiumBy.ACCESSIBILITY_ID, "\uf0c9")
    # Confirmed via live UI dump: the hamburger icon is NOT unique to
    # the home screen -- it's also present on the login screen's app
    # bar, so checking for it alone can falsely report "home reached"
    # after a submission flow's back-navigation lands somewhere other
    # than home (even logged out). NOTIS AMARAN (a home-grid module
    # button) only exists on the actual home screen.
    HOME_SCREEN_INDICATOR = (AppiumBy.ACCESSIBILITY_ID, "NOTIS AMARAN")

    # Navigation
    BUTTON_SETERUSNYA = (AppiumBy.ACCESSIBILITY_ID, "SETERUSNYA")
    BUTTON_MENYERAHKAN = (AppiumBy.ANDROID_UIAUTOMATOR,
                          'new UiSelector().text("MENYERAHKAN")')
    # Confirmed via live UI dump: the "Simpan maklumat ini?" popup's
    # button renders as "HANTAR" (all caps), not "Hantar".
    BUTTON_HANTAR = (AppiumBy.ANDROID_UIAUTOMATOR,
                     'new UiSelector().text("HANTAR")')

    # ---- Printer-connection alert (auto-off Bluetooth printer) ----
    # The paired BT thermal printer sleeps after ~10 min; the app's connect
    # attempt then fails and pops a MODAL native alert ("Error: Unable to
    # connect device") that covers everything behind it. It appears on many
    # screens, not one -- so recovery lives here, in the shared retry paths
    # (find_element / find_clickable / wait_and_tap / dropdown picks), drained
    # ONCE before each retry. Counted globally and reported at end of run: a
    # high count means the real fix is keeping the printer awake, not draining
    # in code. MUST stay enabled everywhere EXCEPT the Cetak flow, where this
    # same alert is the genuine "printer unreachable" signal that recalls the
    # operator (cetak_page toggles _drain_printer_enabled off around printing).
    PRINTER_ALERT_TEXT = "Unable to connect device"
    _printer_alert_count = 0
    _drain_printer_enabled = True

    # ---- Tempoh (MAKLUMAT KOMPAUN section) numeric field, validity 0-21 ----
    # The on-screen SECTION LABEL "MAKLUMAT KOMPAUN" is a NON-editable
    # TextView; the real EditText is that header's next sibling and carries
    # hint="TEMPOH NOTIS" (confirmed ui_dumps/recon_notistab_0.xml line 70,
    # holding a preset "21"). So it MUST be located positionally / by hint,
    # NEVER by the "MAKLUMAT KOMPAUN" label -- that matches the header and
    # silently no-ops, leaving whatever value was already in the field (the
    # Notis tempoh was never actually set by automation, it just rode the
    # field's default, and a stale out-of-range value like "90" would then
    # block SETERUSNYA -- the bug-2 symptom / 17-min Sitaan hang).
    TEMPOH_SIBLING = (AppiumBy.XPATH,
                      '//android.widget.TextView[@text="MAKLUMAT KOMPAUN"]'
                      '/following-sibling::android.widget.EditText[1]')
    TEMPOH_BY_HINT = (AppiumBy.XPATH,
                      '//android.widget.EditText[@hint="TEMPOH NOTIS"]')

    def __init__(self, driver):
        self.driver = driver
        # Default explicit wait timeout
        self.timeout = 15
        # Last created record number read off a success/receipt screen
        # (e.g. IPA3N260728054); consumed by the -001 tests for the DB
        # trace ledger. None until a create succeeds and it's read.
        self.last_record_number = None

    # ------------------------------------------------------------------
    # Element helpers
    # ------------------------------------------------------------------

    def _scroll_down(self):
        """Swipe the main content area down by a small increment.
        Hides the keyboard first -- with the keyboard shown, a swipe
        starting low on the screen lands on keyboard keys instead of the
        form, and never scrolls anything.

        Uses a small percent (confirmed via live run: a full-height
        scrollGesture reliably overshot past the target field between
        find_element's retry checks on longer forms -- same overshoot
        failure mode diagnosed for the dropdown-list scrolling in
        select_dropdown_option, fixed there by switching to small
        controlled steps).
        """
        try:
            if self.driver.is_keyboard_shown():
                self.driver.hide_keyboard()
                import time
                time.sleep(0.3)
        except Exception:
            pass

        try:
            size = self.driver.get_window_size()
            self.driver.execute_script('mobile: scrollGesture', {
                'left': int(size['width'] * 0.1),
                'top': int(size['height'] * 0.25),
                'width': int(size['width'] * 0.8),
                'height': int(size['height'] * 0.5),
                'direction': 'down',
                'percent': 0.3,
            })
            import time
            time.sleep(0.3)
            return True
        except Exception:
            return False

    def _scroll_into_view_uiscrollable(self, locator):
        """Skrol elemen ke paparan dengan UiScrollable scrollIntoView —
        satu-satunya mekanisme skrol yang berkesan pada borang RN app
        ini (lihat nota 2026-08-24 dalam find_element). Hanya untuk
        locator ANDROID_UIAUTOMATOR; pulangkan elemen atau None."""
        if locator[0] == AppiumBy.ACCESSIBILITY_ID:
            # 2026-08-25: petakan accessibility-id kepada description()
            # supaya butang seperti SETERUSNYA turut boleh diskrol.
            locator = (AppiumBy.ANDROID_UIAUTOMATOR,
                       f'new UiSelector().description("{locator[1]}")')
        if locator[0] != AppiumBy.ANDROID_UIAUTOMATOR:
            return None
        try:
            if self.driver.is_keyboard_shown():
                self.driver.hide_keyboard()
                import time
                time.sleep(0.3)
        except Exception:                                    # noqa: BLE001
            pass
        sel = locator[1].strip().rstrip(";")
        for inst in (0, 1):
            cmd = (f"new UiScrollable(new UiSelector().scrollable(true)"
                   f".instance({inst})).scrollIntoView({sel});")
            try:
                return self.driver.find_element(
                    AppiumBy.ANDROID_UIAUTOMATOR, cmd)
            except Exception:                                # noqa: BLE001
                continue
        return None

    def find_element(self, locator, timeout=None):
        """Wait for element presence and return it.

        This app's form screens use a ScrollView that only renders
        fields once they've been scrolled into view -- fields below the
        fold are completely absent from the view hierarchy, not just
        off-screen, so a plain wait never finds them. If the element
        isn't present right away, swipe the content up a few times and
        retry before giving up.
        """
        t = timeout or self.timeout
        try:
            return WebDriverWait(self.driver, t).until(
                EC.presence_of_element_located(locator)
            )
        except TimeoutException:
            pass

        # A printer-connection alert may be covering the element -- drain it
        # once and retry before the (slower) scroll loop.
        if self.drain_printer_alert():
            try:
                return WebDriverWait(self.driver, 3).until(
                    EC.presence_of_element_located(locator)
                )
            except TimeoutException:
                pass

        # >>> 2026-08-25 (run #4): susunan DITUKAR SEMULA — gelung lama
        # (hide_keyboard + tunggu) DAHULU, kerana hide_keyboard-nya juga
        # menutup overlay autocomplete/suggestion yang menutup field
        # (regresi L/S-001 'MAKLUMAT TAMAN' bila UiScrollable dicuba
        # dahulu dan menskrol borang merata). UiScrollable scrollIntoView
        # kini fallback TERAKHIR — masih menyelamatkan kes bawah-fold
        # sebenar (LOKASI KESALAHAN, run #3). <<<
        # 2026-08-25 (run #6): UiScrollable pertengahan gelung DIBUANG —
        # ia menskrol borang merata dan mematahkan pemulihan lama
        # (regresi L/S 'MAKLUMAT TAMAN'). Gelung lama berjalan PENUH
        # dahulu; UiScrollable hanya selepas ia habis.
        for _ in range(10):
            if not self._scroll_down():
                break
            try:
                return WebDriverWait(self.driver, 5).until(
                    EC.presence_of_element_located(locator)
                )
            except TimeoutException:
                continue

        el = self._scroll_into_view_uiscrollable(locator)
        if el is not None:
            return el

        raise TimeoutException(
            f"Element not found after {t}s (incl. scroll attempts): {locator}"
        )

    def _swipe_atas_sebenar(self, kali=1):
        """Swipe SENTUHAN SEBENAR ke atas (driver.swipe) — berbeza dari
        'mobile: scrollGesture' yang terbukti no-op pada borang RN app
        ini. Diperlukan untuk mengangkat senarai dropdown dalaman yang
        tersepit di dasar viewport (dump SEKSYEN18B: ScrollView senarai
        hanya 32px kelihatan). Pulangkan True jika swipe dihantar."""
        import time
        try:
            size = self.driver.get_window_size()
            for _ in range(kali):
                self.driver.swipe(size["width"] // 2,
                                  int(size["height"] * 0.62),
                                  size["width"] // 2,
                                  int(size["height"] * 0.30), 500)
                time.sleep(0.4)
            return True
        except Exception:                                    # noqa: BLE001
            return False

    def _swipe_bawah_sebenar(self, kali=1):
        """Terbalik _swipe_atas_sebenar — skrol kandungan KEMBALI ke atas.
        AUDIT 2026-08-25: _scroll_inner_to_option instance(0) ialah
        ScrollView LUAR; bila baris sasaran memang tiada (kes data-drift),
        scrollIntoView menskrol borang habis ke bawah dan medan penapis
        dropdown hilang dari hierarki. Swipe terbalik memulihkannya."""
        import time
        try:
            size = self.driver.get_window_size()
            for _ in range(kali):
                self.driver.swipe(size["width"] // 2,
                                  int(size["height"] * 0.30),
                                  size["width"] // 2,
                                  int(size["height"] * 0.62), 500)
                time.sleep(0.4)
            return True
        except Exception:                                    # noqa: BLE001
            return False

    def find_clickable(self, locator, timeout=None):
        """Wait for element to be clickable and return it.

        Retries on StaleElementReferenceException by re-resolving the
        locator fresh, not just on TimeoutException. Confirmed via live
        run: the SENARAI menu button can go stale between being located
        and being clicked if the home screen is still settling right
        after go_back_to_home() -- WebDriverWait's own polling doesn't
        recover from a staleness exception on its own, it just propagates
        it, so without this the whole test aborts on what's really just
        a transient timing issue, not a real locator problem.
        """
        t = timeout or self.timeout
        end_time = __import__('time').monotonic() + t
        while True:
            try:
                return WebDriverWait(self.driver, t).until(
                    EC.element_to_be_clickable(locator)
                )
            except StaleElementReferenceException:
                if __import__('time').monotonic() >= end_time:
                    break
                continue
            except TimeoutException:
                break

        # A printer-connection alert may be covering the target -- drain it
        # once and retry before the keyboard/scroll fallbacks.
        if self.drain_printer_alert():
            try:
                return WebDriverWait(self.driver, 3).until(
                    EC.element_to_be_clickable(locator)
                )
            except (TimeoutException, StaleElementReferenceException):
                pass

        # The on-screen keyboard from a preceding type action can
        # cover buttons like SETERUSNYA (especially on smaller
        # screens or after the last field in a tab). Try dismissing
        # it and retrying once before giving up.
        try:
            if self.driver.is_keyboard_shown():
                print("  [INFO] Keyboard is covering the screen, "
                      "hiding it and retrying...")
                self.driver.hide_keyboard()
                import time
                time.sleep(0.5)
                return WebDriverWait(self.driver, t).until(
                    EC.element_to_be_clickable(locator)
                )
        except Exception:
            pass

        # Same lazy-render issue as find_element -- the target may
        # simply not exist in the hierarchy yet because it's below
        # the fold. Scroll and retry before giving up.
        for _ in range(10):
            if not self._scroll_down():
                break
            try:
                return WebDriverWait(self.driver, 5).until(
                    EC.element_to_be_clickable(locator)
                )
            except (TimeoutException, StaleElementReferenceException):
                continue

        # 2026-08-25: UiScrollable scrollIntoView sebagai fallback
        # PALING AKHIR sahaja — run #6 membuktikan meletakkannya awal
        # menskrol borang merata dan mematahkan fallback lama yang
        # terbukti (regresi K SETERUSNYA).
        el = self._scroll_into_view_uiscrollable(locator)
        if el is not None:
            try:
                return WebDriverWait(self.driver, 3).until(
                    EC.element_to_be_clickable(locator)
                )
            except (TimeoutException, StaleElementReferenceException):
                pass

        # 2026-08-27: dump bukti sebelum raise — kegagalan SETERUSNYA
        # trafik (validasi #5) tiada evidence; ini murah dan universal.
        try:
            import os as _os
            import time as _tm
            _os.makedirs("ui_dumps", exist_ok=True)
            _p = _os.path.join(
                "ui_dumps", f"clickfail_{int(_tm.time())}.xml")
            with open(_p, "w", encoding="utf-8") as _f:
                _f.write(self.driver.page_source)
            print(f"  [DEBUG] find_clickable gagal -- dump: {_p}")
        except Exception:                                    # noqa: BLE001
            pass
        raise TimeoutException(
            f"Element not clickable after {t}s (incl. scroll attempts): {locator}"
        )

    def tap_element(self, el):
        """Tap the center of an element using a raw coordinate touch
        gesture instead of el.click() (which sends an accessibility
        ACTION_CLICK). Several custom RN Touchables/Pressables in this
        app don't wire up a real onClick accessibility action -- Appium
        finds them fine and click() reports success, but nothing happens
        in the app (confirmed via screen recording: the Jalan suggestion
        dropdown stayed open indefinitely across a full click() call).
        A genuine touch-down/up at the element's coordinates works where
        click() silently no-ops.
        """
        rect = el.rect
        x = rect['x'] + rect['width'] // 2
        y = rect['y'] + rect['height'] // 2
        self.driver.tap([(x, y)])

    def is_element_present(self, locator, timeout=5):
        """Check if an element is present without throwing."""
        try:
            WebDriverWait(self.driver, timeout).until(
                EC.presence_of_element_located(locator)
            )
            return True
        except (TimeoutException, NoSuchElementException):
            return False

    def is_text_visible(self, text, timeout=5):
        """Check if text is visible on screen."""
        locator = (AppiumBy.ANDROID_UIAUTOMATOR,
                   f'new UiSelector().textContains("{text}")')
        return self.is_element_present(locator, timeout)

    def wait_and_click(self, locator, timeout=None):
        """Wait for element and click it."""
        el = self.find_clickable(locator, timeout)
        el.click()
        return el

    def wait_and_tap(self, locator, timeout=None):
        """Wait for element and tap it with a raw coordinate touch.
        Use instead of wait_and_click for this app's custom RN
        Pressables, which silently no-op on the accessibility
        ACTION_CLICK that el.click() sends (see tap_element).

        Re-resolves the locator on StaleElementReferenceException --
        confirmed via live run: a just-opened RN popup (Menu Selaras)
        can still be re-rendering when find_clickable returns, so the
        element handle dies in the gap before tap_element reads its
        rect. Same transient-staleness pattern already handled inside
        find_clickable itself, which can't help here because the
        staleness fires after it has already returned."""
        import time
        last_exc = None
        for _ in range(3):
            el = self.find_clickable(locator, timeout)
            try:
                self.tap_element(el)
                return el
            except StaleElementReferenceException as e:
                last_exc = e
                time.sleep(0.5)
        raise last_exc

    def wait_and_send_keys(self, locator, text, timeout=None):
        """Wait for element, clear, and type text."""
        el = self.find_element(locator, timeout)
        el.clear()
        if text:
            el.send_keys(text)
        return el

    def wait_for_text(self, text, timeout=None):
        """Wait for a text element to appear."""
        locator = (AppiumBy.ANDROID_UIAUTOMATOR,
                   f'new UiSelector().textContains("{text}")')
        return self.find_element(locator, timeout)

    def _ci_label_locator(self, label_text):
        """Build a case-insensitive UiAutomator locator for a field label.

        This app renders the same conceptual label in inconsistent casing
        depending on which screen it's on (e.g. Pesalah tab's fields are
        ALL CAPS, the Notis/Kompaun tab's Jalan/Taman/etc. are Title Case,
        and ID PENGUATKUASA on Notis Kompaun turned out to not match the
        assumed all-caps guess either). Rather than keep discovering this
        one field at a time, match case-insensitively via a regex so the
        actual on-screen casing never matters.
        """
        import re
        escaped = re.escape(label_text)
        return (AppiumBy.ANDROID_UIAUTOMATOR,
                f'new UiSelector().textMatches("(?i)^{escaped}$")')

    def _hide_keyboard_if_shown(self):
        """Proactively dismiss the keyboard, if present.

        Confirmed via live run: waiting for a keyboard-covered button to
        time out before checking for/hiding the keyboard (the old
        reactive pattern still used as a last-resort fallback in
        find_clickable) costs a real ~15-20s stall every time it happens
        -- most noticeably right after filling the last field in a tab
        (e.g. Maklumat Negeri) and immediately clicking Seterusnya.
        Hiding it right after typing avoids ever hitting that stall in
        the first place, for the common case where a fill really is the
        last interaction before a click.
        """
        try:
            if self.driver.is_keyboard_shown():
                self.driver.hide_keyboard()
        except Exception:
            pass

    @staticmethod
    def _norm(s):
        """Normalize a field value for comparison (strip + upper)."""
        return (s or "").strip().upper()

    def _safe_text(self, el):
        """Read el.text without throwing (stale/detached -> None)."""
        try:
            return el.text
        except Exception:                                    # noqa: BLE001
            return None

    def _emit_text(self, el, value, use_mobile_type):
        """Type `value` into an already-focused field."""
        if use_mobile_type:
            self.driver.execute_script('mobile: type', {'text': value})
        else:
            try:
                el.send_keys(value)
            except Exception:                                # noqa: BLE001
                # Some masked/numeric fields reject send_keys with
                # InvalidElementStateException -- fall back to mobile:type.
                self.driver.execute_script('mobile: type', {'text': value})

    def _force_clear(self, el):
        """Truly empty an RN EditText. el.clear() is frequently ignored
        here -- the SAME accessibility-action no-op that makes el.click()
        do nothing (why this suite taps by coordinate) -- so with
        no_reset=True a previous run's value survives and new text lands
        appended/prepended (observed: tempoh '90' where '1' was sent,
        which then trips the field's own 0-21 validation). After the cheap
        el.clear(), force it via hardware key events, which DO reach the
        input: select-all (Ctrl+A) + forward-delete, then a backspace
        sweep from end as a backstop."""
        try:
            el.click()
        except Exception:                                    # noqa: BLE001
            try:
                self.tap_element(el)
            except Exception:                                # noqa: BLE001
                pass
        try:
            el.clear()
        except Exception:                                    # noqa: BLE001
            pass
        try:
            self.driver.press_keycode(29, 4096)   # KEYCODE_A + META_CTRL_ON
            self.driver.press_keycode(112)        # KEYCODE_FORWARD_DEL
        except Exception:                                    # noqa: BLE001
            pass
        try:
            self.driver.press_keycode(123)        # KEYCODE_MOVE_END
            for _ in range(30):
                self.driver.press_keycode(67)     # KEYCODE_DEL (backspace)
        except Exception:                                    # noqa: BLE001
            pass

    def fill_field_by_label(self, label_text, value, timeout=None,
                             use_mobile_type=False, keep_keyboard=False,
                             verify=True):
        """Find any EditText whose current text/placeholder matches
        label_text (case-insensitive), click it, clear it, and type value.

        Set use_mobile_type=True for fields that reject plain send_keys()
        (e.g. numeric/masked inputs that throw 'invalid element state').

        Set keep_keyboard=True for fields inside dismissible RN modals
        (e.g. the Tarik Notis popup): hide_keyboard can behave like a
        Back press, which closes the whole modal -- confirmed via live
        dump that the Tarik Notis popup was gone immediately after its
        ID field was filled.

        verify=True (default): after typing, read the field back and, if
        it doesn't hold `value`, FORCE-clear (el.clear() is silently
        ignored by this app's RN inputs -- see _force_clear) and retype,
        up to 3x. NON-fatal -- if it still can't confirm it logs a WARNING
        and returns, so fields that legitimately reformat their input
        (autocomplete, masks) don't fail the run; the field's own
        validation surfaces anything that truly matters downstream. Pass
        verify=False to skip (e.g. before an autocomplete pick changes the
        text out from under the check).
        """
        locator = self._ci_label_locator(label_text)
        el = self.find_element(locator, timeout)

        el.click()
        try:
            el.clear()
        except Exception:                                    # noqa: BLE001
            pass
        self._emit_text(el, value, use_mobile_type)

        if verify:
            # OPPORTUNISTIC verify: act only on a value we can actually READ
            # and that is clearly WRONG (e.g. a stale '90' that survived a
            # failed clear). If the field can't be read back -- el.text
            # returns None because an RN live-search re-render staled the
            # handle, and the placeholder locator no longer matches now the
            # field holds a value -- assume the type landed and move on.
            # Force-clearing an UNREADABLE field would risk corrupting a
            # value that is actually fine (this bit the MAKLUMAT JALAN
            # autocomplete field). The 0-21-validated Tempoh field has its
            # own re-resolving verifier (_set_tempoh_verified) for the case
            # a stale value must be caught even when the handle goes stale.
            def _read_back():
                got = self._safe_text(el)
                if got is None:
                    try:
                        return self._safe_text(
                            self.find_element(locator, timeout=2))
                    except Exception:                        # noqa: BLE001
                        return None
                return got

            got = _read_back()
            if got is not None and self._norm(got) == self._norm(label_text):
                # Read-back equals the label/placeholder: the field still
                # shows its placeholder -- it's empty (the type didn't land)
                # OR we matched a label element, NOT a wrong value.
                # Force-clearing + retyping via the same locator won't help
                # and just churns keycodes (this stormed on the "MAKLUMAT
                # KOMPAUN" tempoh header, which is why tempoh now has its own
                # EditText-scoped setter). Log once and move on; a DIFFERENT
                # non-empty value (a stale '90') is the real bug-2 case and
                # still gets force-cleared below.
                print(f"  [FILL] NOTE: '{label_text}' still shows its "
                      f"placeholder after typing (field empty or the label "
                      f"matched a non-field element) -- not force-clearing")
            elif got is not None and self._norm(got) != self._norm(value):
                for attempt in range(3):
                    print(f"  [FILL] '{label_text}' shows {got!r}, expected "
                          f"{value!r} (attempt {attempt + 1}/3) -- "
                          f"force-clear + retype")
                    self._force_clear(el)
                    self._emit_text(el, value, use_mobile_type)
                    got = _read_back()
                    if got is None or self._norm(got) == self._norm(value):
                        break
                if got is not None and self._norm(got) != self._norm(value):
                    print(f"  [FILL] WARNING: '{label_text}' still shows "
                          f"{got!r} after retries (expected {value!r}) -- "
                          f"continuing; downstream validation will surface "
                          f"it if it matters")

        if not keep_keyboard:
            self._hide_keyboard_if_shown()
        return el

    def fill_field_by_label_if_blank(self, label_text, value, timeout=3,
                                      use_mobile_type=False):
        """Same as fill_field_by_label, but a no-op if the field no longer
        shows label_text as its placeholder.

        Some fields in this app (e.g. Taman/Bandar/Negeri on the Notis/
        Kompaun tabs) get auto-filled as a side effect of picking an
        autocomplete suggestion on a sibling field (Jalan). When that
        auto-fill already happened, the placeholder text is gone and a
        plain fill_field_by_label would wait out the full timeout and
        raise TimeoutException.

        Confirmed via live run: doing this as a separate
        is_element_present() check followed by a second find_element()
        call is a race -- the auto-fill can land in the gap between the
        two lookups, so the first check sees the placeholder (not yet
        auto-filled) but the second lookup for the same locator then
        finds nothing and raises anyway. Use a single bounded lookup
        instead (not find_element, which falls back to a multi-round
        scroll-and-retry loop on timeout -- fine when a field is
        expected to exist, but here "not found" usually just means
        it's genuinely already filled, and scrolling around hunting for
        placeholder text that will never reappear would turn a fast
        skip into a ~60s wait).

        Confirmed via live run: even a single lookup isn't quite enough
        -- the auto-fill can also land in the gap between resolving the
        element and acting on it, raising StaleElementReferenceException
        out of el.click() instead of the presence check ever failing.
        Treat that the same as "already filled": it can only mean the
        DOM node we just found got replaced by the auto-fill an instant
        later, not any other kind of failure on a freshly-resolved
        element.
        """
        locator = self._ci_label_locator(label_text)
        try:
            el = WebDriverWait(self.driver, timeout).until(
                EC.presence_of_element_located(locator)
            )
        except TimeoutException:
            print(f"  [INFO] '{label_text}' already has a value "
                  f"(likely auto-filled) -- skipping")
            return None
        try:
            el.click()
            el.clear()
            if use_mobile_type:
                self.driver.execute_script('mobile: type', {'text': value})
            else:
                el.send_keys(value)
            self._hide_keyboard_if_shown()
            return el
        except StaleElementReferenceException:
            print(f"  [INFO] '{label_text}' got auto-filled while we were "
                  f"about to type into it -- skipping")
            return None

    def fill_field_by_label_or_instance(self, label_text, value, instance=0,
                                         use_mobile_type=False,
                                         label_timeout=4):
        """Fill a field normally located by its placeholder text, with
        fallbacks for when the placeholder is gone because the field
        already holds a previously-saved value.

        Needed for the settings screens (Tetapan Alamat IP / Tetapan
        Pelbagai): with no_reset=True their fields keep whatever value
        the last run saved, so the placeholder text (which is how
        fill_field_by_label finds fields in this app) only ever exists
        on the very first run against a fresh install. Confirmed via
        live run: the run right after the first successful IP save
        failed with 'INTERNAL IP ADDRESS' not found after 15s.

        Tiers:
        1. Placeholder text still showing (fresh install) -> normal fill.
        2. An EditText already holding exactly `value` (the common case:
           last run saved the same value we're about to type) -> skip
           typing entirely, nothing to change.
        3. EditText by class + instance index (field holds some OTHER
           stale/partial value) -> clear it and type. Least precise
           tier, so it's last; `instance` is the field's position among
           the screen's EditTexts (document per call site).
        """
        # Tier 1: placeholder (bounded single lookup -- find_element's
        # scroll-retry loop would burn ~60s on these short screens).
        #
        # Retry on staleness: this app restores a saved "MAKLUMAT PESALAH
        # TELAH DI SIMPAN" draft and re-renders the Pesalah form a beat
        # after it first appears, so a field found the instant the tab
        # opens can go stale between the lookup and send_keys -- confirmed
        # live on a cold start (two consecutive P-001 runs died here). The
        # old `except TimeoutException` let that staleness propagate and
        # fail the whole create. Re-resolve and retry before falling
        # through to tiers 2/3.
        import time as _t
        locator = self._ci_label_locator(label_text)
        for _attempt in range(3):
            try:
                el = WebDriverWait(self.driver, label_timeout).until(
                    EC.presence_of_element_located(locator)
                )
                el.click()
                el.clear()
                if use_mobile_type:
                    self.driver.execute_script('mobile: type', {'text': value})
                else:
                    el.send_keys(value)
                self._hide_keyboard_if_shown()
                return el
            except TimeoutException:
                break
            except (StaleElementReferenceException,
                    NoSuchElementException):
                # 2026-08-26 (debug_pilih #3): uiautomator2 me-resolve
                # semula selector KETIKA aksi (el.clear) — bila draf
                # re-render menukar borang antara jumpa dan clear, ia
                # melontar NoSuchElement (bukan Stale) dan retry lama
                # tidak menangkapnya. Layan kedua-duanya sama.
                print(f"  [INFO] '{label_text}' went stale mid-fill (form "
                      f"re-render) -- re-resolving (attempt {_attempt + 1}/3)")
                _t.sleep(0.6)

        # Tier 2: field already holds the target value.
        value_locator = (
            AppiumBy.ANDROID_UIAUTOMATOR,
            f'new UiSelector().className("android.widget.EditText")'
            f'.text("{value}").instance({instance})')
        try:
            el = WebDriverWait(self.driver, 3).until(
                EC.presence_of_element_located(value_locator)
            )
            print(f"  [INFO] '{label_text}' already holds '{value}' "
                  f"(saved by a previous run) -- leaving as-is")
            return el
        except TimeoutException:
            pass

        # Tier 3: positional fallback.
        print(f"  [INFO] '{label_text}' placeholder gone and current value "
              f"differs from target -- falling back to EditText "
              f"instance({instance}) and retyping")
        fallback_locator = (
            AppiumBy.ANDROID_UIAUTOMATOR,
            f'new UiSelector().className("android.widget.EditText")'
            f'.instance({instance})')
        el = self.find_element(fallback_locator, timeout=10)
        el.click()
        el.clear()
        if use_mobile_type:
            self.driver.execute_script('mobile: type', {'text': value})
        else:
            el.send_keys(value)
        self._hide_keyboard_if_shown()
        return el

    def type_and_select_suggestion(self, label_text, partial_text,
                                    suggestion_text=None, timeout=None):
        """Tap a field by its current label/placeholder text, type a
        partial value to trigger an autocomplete dropdown, then tap a
        suggestion row that appears.

        Uses 'mobile: type' instead of send_keys() for the partial text.
        These autocomplete fields are React Native controlled inputs
        wired to an onChangeText lookup, same as the Tempoh Notis field —
        plain send_keys() sets the value without firing real key events,
        so the app's live-search never triggers and no suggestion list
        renders (this was the actual cause of suggestions "not appearing").

        If suggestion_text is given, taps that exact row with
        verify-and-retry (same silent-no-op-tap protection as the menu
        items, kompaun-code dropdowns, and TARIK): after each tap it
        checks the row actually left the screen, re-tapping up to 3
        times. If the row appeared but never registers a tap, this
        RAISES rather than silently substituting a different suggestion
        into the test data. The generic first-row fallback is used ONLY
        when the exact suggestion never rendered at all (or when no
        suggestion_text was provided) — matches the observed "X | Y"
        suggestion format, useful when the exact value doesn't matter.

        Example: type_and_select_suggestion(
            "MAKLUMAT TAMAN", "T", "TIDAK DINYATAKAN | SEKITAR MASAI"
        )
        """
        field_locator = self._ci_label_locator(label_text)
        el = self.find_element(field_locator, timeout)
        el.click()
        el.clear()
        self.driver.execute_script('mobile: type', {'text': partial_text})

        generic_suggestion_locator = (
            AppiumBy.ANDROID_UIAUTOMATOR,
            'new UiSelector().className("android.widget.TextView")'
            '.textContains("|").instance(0)'
        )

        import time

        if suggestion_text:
            exact_locator = (AppiumBy.ANDROID_UIAUTOMATOR,
                              f'new UiSelector().text("{suggestion_text}")')
            try:
                target_el = self.find_clickable(exact_locator, timeout=10)
            except TimeoutException:
                print(f"  [WARN] Exact suggestion '{suggestion_text}' not "
                      f"found within timeout, trying first available "
                      f"suggestion row")
                target_el = None

            if target_el is not None:
                # Raw coordinate tap, not el.click() -- confirmed via
                # screen recording that el.click() (accessibility
                # ACTION_CLICK) silently no-ops on these custom rows.
                # The raw tap ALSO flakes (confirmed via live runs:
                # the row stayed on screen after a 'successful' tap),
                # so verify the row actually left the screen and re-tap
                # up to 3 times, same as every other verified tap in
                # this suite.
                for attempt in range(3):
                    self.tap_element(target_el)
                    time.sleep(0.5)
                    if not self.is_element_present(exact_locator,
                                                   timeout=2):
                        return el
                    print(f"  [WARN] Exact suggestion "
                          f"'{suggestion_text}' still showing after tap "
                          f"(attempt {attempt + 1}/3) -- re-tapping...")
                    try:
                        target_el = self.find_clickable(exact_locator,
                                                        timeout=5)
                    except TimeoutException:
                        # Row vanished between the presence check and
                        # the re-find -- the tap registered after all.
                        return el

                # The exact row rendered but no tap ever registered.
                # Raising (not falling back) is deliberate: silently
                # picking whichever row is first would substitute a
                # different address into the test data.
                dump_path = "debug_suggestion_tap.xml"
                try:
                    with open(dump_path, "w", encoding="utf-8") as f:
                        f.write(self.driver.page_source)
                    print(f"  [DEBUG] page source dumped to {dump_path}")
                except Exception:
                    pass
                raise TimeoutException(
                    f"Exact suggestion '{suggestion_text}' was visible "
                    f"but 3 taps never registered a selection; refusing "
                    f"to substitute a different suggestion. See "
                    f"{dump_path}")

        try:
            target_el = self.find_clickable(generic_suggestion_locator,
                                             timeout=10)
            self.tap_element(target_el)
        except TimeoutException:
            # No dropdown appeared at all (not a text-mismatch issue —
            # nothing rendered). Since this is a CRUD smoke test, don't
            # fail the run over it: leave the typed partial_text sitting
            # in the field as-is and move on. NOTE: this means any other
            # field that this app would normally auto-fill from the
            # selection (e.g. poskod/bandar/negeri) stays blank — if a
            # later step fails because of that, it's a sign the app
            # actually requires a real selection here, not just typed text.
            print(f"  [WARN] No suggestion dropdown appeared for "
                  f"'{label_text}' after typing '{partial_text}'. "
                  f"Leaving typed value as-is and continuing.")
        return el

    def select_dropdown_option(self, placeholder_text, option_text,
                                timeout=None):
        """Tap a dropdown showing placeholder_text, type option_text to
        filter, then pick the matching option ROW -- verifying the pick
        actually registered and RAISING clearly if it never does.

        WHY THE ROW IS MATCHED BY content-desc, NOT text
        ------------------------------------------------
        Confirmed via ui_dumps/bmrecon_form_codes.xml: an open list's
        option ROWS are clickable android.view.ViewGroup nodes carrying
        content-desc="<OPTION>" (with a child TextView), while the search
        INPUT is an android.widget.EditText matched on `text` with an
        EMPTY content-desc. The old locator
            new UiSelector().text("<OPTION>")
        matched BOTH -- and element_to_be_clickable returned the EditText
        we'd just typed into first, so tap_element landed on the
        already-focused field (a no-op) and the method returned a FALSE
        success while the app never received a selection. Matching the row
        by DESCRIPTION makes hitting the input field impossible (its
        content-desc is empty).

        The searchable field renders its list only after focus in some
        variants (PILIH KOMPAUN) but with the keyboard up in others (KOD
        AKTA) -- so we look, then hide the keyboard and look again.

        Verification: after the row tap the list must CLOSE (the row's
        content-desc is gone) -- the same silent-no-op-tap guard used for
        every other pick in this suite. Retries up to 3x; on total failure
        it dumps page source and raises "pemilihan dropdown ... tidak
        didaftarkan" rather than continuing as if the field were set.
        """
        import re
        import time
        placeholder_locator = (AppiumBy.ANDROID_UIAUTOMATOR,
                               f'new UiSelector().text("{placeholder_text}")')
        option_upper = option_text.upper()
        esc = re.escape(option_upper)

        # Option ROWS can carry a code PREFIX in their content-desc --
        # confirmed via ui_dumps/dropdown_UUK7UNDANGUNDANG_fail.xml: KOD AKTA
        # renders content-desc "39 - UUK 7 UNDANG-UNDANG..." while the test
        # data is just the description "UUK 7 UNDANG-UNDANG...". So match a
        # row whose content-desc ENDS WITH the option. Ends-with (not
        # contains) still excludes a longer sibling like "KOMPAUN PELBAGAI
        # TRAFIK" when selecting "KOMPAUN PELBAGAI" (that ends with TRAFIK),
        # and (not exact) tolerates the prefix.
        row_by_desc = (AppiumBy.ANDROID_UIAUTOMATOR,
                       f'new UiSelector().descriptionMatches("(?i).*{esc}$")')
        # Fallback row: a TextView (NEVER the EditText input) whose text ends
        # with the option, for any variant that renders rows without a
        # content-desc.
        row_by_text = (AppiumBy.ANDROID_UIAUTOMATOR,
                       f'new UiSelector().className("android.widget.TextView")'
                       f'.textMatches("(?i).*{esc}$")')

        # Type only a distinctive PREFIX of the option to filter, not the
        # whole string: a very long value (the ~100-char KESALAHAN
        # descriptions) fed to the RN live-search returned "Tiada rekod
        # dijumpai" (confirmed via dropdown_MEMOTONGMENGALIH_fail.xml),
        # filtering the target row OUT entirely. A short prefix narrows the
        # list while still rendering the row, which is then matched exactly
        # by the ends-with locators below.
        filter_text = option_text[:25]

        # Kedudukan medan dropdown (dirakam semasa buka) + senarai SEMUA
        # nilai yang KITA taip — untuk _semak_terdaftar_sendiri.
        medan_rect = [None]
        taipan_semua = [filter_text]

        def _open_and_filter():
            el = self.find_clickable(placeholder_locator, timeout)
            try:
                medan_rect[0] = el.rect
            except Exception:                                # noqa: BLE001
                pass
            self.tap_element(el)
            time.sleep(0.5)
            self.driver.execute_script('mobile: type', {'text': filter_text})
            # >>> 2026-08-25 (run #6): taipan selepas tap koordinat
            # boleh TIDAK MELEKAT (field kekal placeholder — disahkan
            # 'retry kata1 tidak dapat menaip'). Debug v2 membuktikan
            # el.click() (API elemen, fokus sebenar) + taip semula
            # BERJAYA. Sahkan taipan melekat; kalau tidak, click elemen
            # dan taip semula sehingga 3 kali. <<<
            landed_loc = (
                AppiumBy.ANDROID_UIAUTOMATOR,
                f'new UiSelector().className("android.widget.EditText")'
                f'.textContains("{filter_text[:12]}")')
            for _cuba in range(3):
                time.sleep(0.5)
                if self.is_element_present(landed_loc, timeout=2):
                    break
                print(f"  [DROPDOWN] penapis tidak melekat (cubaan "
                      f"{_cuba + 1}/3) -- el.click() + taip semula...")
                # AUDIT 2026-08-25: carian TANPA-SKROL. find_element di
                # sini pernah menskrol borang 10x bila placeholder sudah
                # hilang (taipan separa melekat) — memusnahkan borang.
                el2 = None
                for _loc in (placeholder_locator,
                             (AppiumBy.ANDROID_UIAUTOMATOR,
                              'new UiSelector().className('
                              '"android.widget.EditText").focused(true)')):
                    try:
                        el2 = WebDriverWait(self.driver, 2).until(
                            EC.presence_of_element_located(_loc))
                        break
                    except Exception:                        # noqa: BLE001
                        continue
                if el2 is None:
                    continue
                try:
                    el2.click()
                    time.sleep(0.3)
                    # Taipan separa mungkin sudah dalam field — kosongkan
                    # dahulu supaya taip semula tidak TERTAMPAL berganda.
                    self._force_clear(el2)
                    time.sleep(0.2)
                    self.driver.execute_script('mobile: type',
                                               {'text': filter_text})
                except Exception:                            # noqa: BLE001
                    pass
            # >>> 2026-08-25 (debug_dropdown v3, DISAHKAN LIVE): field
            # tier yang duduk di DASAR viewport (KESALAHAN) tidak dapat
            # merender senarai keputusan selagi keyboard terbuka —
            # viewport tamat tepat di bahagian bawah field. Selepas
            # hide_keyboard, viewport mengembang dan baris muncul
            # (penapis 'M' -> 1 baris; dengan keyboard -> 0 baris pada
            # SEMUA percubaan). Senarai inline ini TERBUKTI kekal
            # terbuka selepas hide_keyboard (dd_07/dd_23). <<<
            time.sleep(0.5)
            try:
                if self.driver.is_keyboard_shown():
                    self.driver.hide_keyboard()
                    time.sleep(0.6)
            except Exception:                                # noqa: BLE001
                pass

        # >>> AUDIT 2026-08-25: lookup @hint XPath DIBUANG — atribut
        # @hint tidak wujud dalam app ini (placeholder dilapor sebagai
        # text), jadi carian itu BUKAN sahaja gagal senyap: ia memasuki
        # find_element yang menskrol borang 10x + UiScrollable pada
        # SETIAP kegagalan dropdown, memusnahkan kedudukan borang
        # sebelum semua fallback berikutnya. Semua carian medan dalam
        # fungsi ini kini TANPA-SKROL (WebDriverWait presence sahaja). <<<
        def _cari_medan_taip(nilai):
            """Cari EditText penapis TANPA sebarang skrol: (1) ikut teks
            yang kita taip, (2) placeholder asal, (3) EditText fokus."""
            calon = [
                (AppiumBy.ANDROID_UIAUTOMATOR,
                 f'new UiSelector().className("android.widget.EditText")'
                 f'.textContains("{nilai[:12]}")') if nilai else None,
                placeholder_locator,
                (AppiumBy.ANDROID_UIAUTOMATOR,
                 'new UiSelector().className("android.widget.EditText")'
                 '.focused(true)'),
            ]
            for loc in calon:
                if loc is None:
                    continue
                try:
                    return WebDriverWait(self.driver, 2).until(
                        EC.presence_of_element_located(loc))
                except Exception:                            # noqa: BLE001
                    continue
            return None

        def _clear_filter():
            el = _cari_medan_taip(filter_text)
            if el is None:
                return
            try:
                self._force_clear(el)
                time.sleep(0.4)
            except Exception:                                # noqa: BLE001
                pass

        via_text = [False]  # was the row found via the content-desc-less
                            # TEXT fallback (not by content-desc)?

        def _look():
            for loc in (row_by_desc, row_by_text):
                if self.is_element_present(loc, timeout=2):
                    try:
                        el = self.find_element(loc, timeout=3)
                        via_text[0] = (loc is row_by_text)
                        return el
                    except Exception:                        # noqa: BLE001
                        pass
            return None

        def _find_row():
            for _ in range(2):
                found = _look()
                if found is not None:
                    return found
                # Some lists (PILIH KOMPAUN) only render once focus is lost.
                try:
                    if self.driver.is_keyboard_shown():
                        self.driver.hide_keyboard()
                        time.sleep(0.3)
                except Exception:                            # noqa: BLE001
                    pass
            # The typed prefix may have filtered the row OUT -- confirmed for
            # the KESALAHAN options, whose live-search returns "Tiada rekod
            # dijumpai" for a description substring (it matches the "(UUK
            # X) -"-prefixed string, not the description). Clear the filter
            # and scroll the FULL list to the row instead.
            _clear_filter()
            _scroll_inner_to_option()
            found = _look()
            if found is not None:
                return found
            # >>> 2026-08-24 (dump SEKSYEN18B): senarai TERBUKA tetapi
            # viewport dalamannya tersepit 32px di dasar skrin — baris
            # sasaran wujud tapi tidak dirender. scrollIntoView dalam
            # viewport sekecil itu tidak berdaya; SWIPE SENTUHAN
            # SEBENAR pada halaman mengangkat senarai ke pandangan
            # (scrollGesture no-op, driver.swipe = sentuhan mentah). <<<
            for _ in range(4):
                if not self._swipe_atas_sebenar():
                    break
                _scroll_inner_to_option()
                found = _look()
                if found is not None:
                    return found
            return None

        def _option_row_present():
            # The clickable option ROW (content-desc) exists only while the
            # list is OPEN. After a registered selection it is gone and the
            # value lives in the field's EditText (text, no content-desc) --
            # so for normal content-desc dropdowns this alone tells
            # open-vs-closed WITHOUT the false-negative of the old check
            # (which also matched a displayed TextView value and so reported
            # "not registered" even after a real selection).
            if self.is_element_present(row_by_desc, timeout=1):
                return True
            # BUT if the row was found via the content-desc-LESS text fallback
            # (a desc-less dropdown variant), row_by_desc is never present, so
            # a coord-tap that no-ops would leave this False and the FIRST tap
            # be reported SELECTED though nothing was picked (false success).
            # For that case, also verify close via row_by_text.
            if via_text[0] and self.is_element_present(row_by_text, timeout=1):
                return True
            return False

        def _scroll_inner_to_option():
            # Scroll the dropdown's OWN nested list, never ONLY the
            # outer page ScrollView -- confirmed live that scrolling the
            # page destroys form progress. 2026-08-24: cuba instance 1,
            # 2 DAN 0 — pada borang Pelbagai/Notis, senarai dalaman
            # boleh jadi scrollable ke-2 atau ke-3 bergantung keadaan
            # keyboard (dump SEKSYEN18B: outer=instance 0, senarai=1).
            for inst in (1, 2, 0):
                scroll = (
                    f'new UiScrollable(new UiSelector().scrollable(true)'
                    f'.instance({inst})).scrollIntoView(new UiSelector()'
                    f'.descriptionMatches("(?i).*{esc}$"));')
                try:
                    self.driver.find_element(
                        AppiumBy.ANDROID_UIAUTOMATOR, scroll)
                    return
                except Exception:                            # noqa: BLE001
                    continue

        safe = "".join(c for c in option_upper if c.isalnum())[:16] or "opt"

        def _dump_dd(tag):
            try:
                import os
                os.makedirs("ui_dumps", exist_ok=True)
                p = os.path.join("ui_dumps", f"dropdown_{safe}_{tag}.xml")
                with open(p, "w", encoding="utf-8") as f:
                    f.write(self.driver.page_source)
                print(f"  [DROPDOWN] state dumped -> {p}")
            except Exception:                                # noqa: BLE001
                pass

        import re as _re

        def _semak_terdaftar_sendiri(tag=""):
            """>>> AUDIT 2026-08-25 (dump SEKSYEN18B kedua): medan KOD
            AKTA didapati SUDAH berisi 'ACT2025000002 - GAGAL...' pada
            saat kod melaporkan GAGAL — satu pemilihan TERDAFTAR semasa
            fallback tetapi kod buta terhadapnya. Semak medan pada
            kedudukan yang dirakam: kalau ia memegang nilai yang BUKAN
            placeholder dan BUKAN apa yang kita taip, pemilihan sudah
            berdaftar — terima. Toleransi-y 120px SAHAJA (medan tier
            berjarak ~250px; lebih longgar akan terbaca nilai tier
            sebelah). <<<"""
            r = medan_rect[0]
            if r is None:
                return False
            try:
                els = self.driver.find_elements(
                    AppiumBy.CLASS_NAME, "android.widget.EditText")
            except Exception:                                # noqa: BLE001
                return False
            for e in els:
                try:
                    er = e.rect
                    if abs(er["y"] - r["y"]) > 120:
                        continue
                    t = (e.get_attribute("text") or "").strip()
                except Exception:                            # noqa: BLE001
                    continue
                if len(t) < 13:
                    continue
                tu = t.upper()
                if tu == placeholder_text.upper():
                    continue
                if any(tu == s.upper() for s in taipan_semua):
                    continue
                if len(t) > len(filter_text) or " - " in t:
                    print(f"  [DROPDOWN] {tag}nilai TERDAFTAR SENDIRI "
                          f"dikesan dalam medan: '{t[:70]}' — pemilihan "
                          f"diterima (registered)")
                    if tu.endswith(option_upper[-min(len(option_upper),
                                                     20):]):
                        return True
                    print(f"  [DROPDOWN] [PENEMUAN-DATA] nilai medan "
                          f"BERBEZA dari Excel '{option_text[:60]}' — "
                          f"diterima sebagai GANTI (arahan CEO)")
                    return True
            return False

        def _cari_baris_ringan():
            """Cari baris pilihan TANPA sebarang clear/skrol destruktif
            — hanya lihat, hide keyboard, lihat lagi. AUDIT 2026-08-25:
            laluan lama (_clear_filter + scrollIntoView instance(0) + 4
            swipe) memusnahkan kedudukan borang SEBELUM kata1/GANTI
            sempat mencuba; ia kini last-resort sahaja."""
            for _ in range(2):
                f = _look()
                if f is not None:
                    return f
                try:
                    if self.driver.is_keyboard_shown():
                        self.driver.hide_keyboard()
                        time.sleep(0.3)
                except Exception:                            # noqa: BLE001
                    pass
                time.sleep(0.4)
            return None

        def _medan_penapis(nilai):
            for loc in (
                (AppiumBy.ANDROID_UIAUTOMATOR,
                 f'new UiSelector().className("android.widget.EditText")'
                 f'.textMatches("(?i)^{_re.escape(nilai)}$")'),
                (AppiumBy.ANDROID_UIAUTOMATOR,
                 f'new UiSelector().className("android.widget.EditText")'
                 f'.textContains("{nilai[:15]}")'),
            ):
                try:
                    return WebDriverWait(self.driver, 2).until(
                        EC.presence_of_element_located(loc))
                except Exception:                            # noqa: BLE001
                    continue
            return None

        # Bukan baris pilihan walaupun desc panjang — jangan sesekali
        # tap: butang back bar atas ('MainPelbagai, back' = 18 aksara
        # lepas tapis lama!), butang aliran borang.
        _BUKAN_BARIS = ("OPEN CAMERA", "SETERUSNYA", "SIMPAN", "HANTAR",
                        "BATAL", "MENYERAHKAN")
        ganti_sudah = [False]  # MOD GANTI dijalankan sekali sahaja

        def _baris_sedia_ada():
            # >>> AUDIT 2026-08-26 (dump MEMOTONG fail #3): baris
            # '[UUK 7] - MELETAKKAN...' DIRENDER pada [110,1474][971,1701]
            # semasa GANTI melapor 0 baris — node itu container
            # SCROLLABLE yang membawa content-desc, BUKAN ViewGroup
            # clickable. Penapis lama (ViewGroup.clickable sahaja) buta
            # terhadapnya. Kini padankan APA-APA kelas dengan desc >= 16
            # aksara, digabung dengan carian ViewGroup lama. <<<
            # >>> AUDIT 2026-08-27 (dump ganti_A): baris '[UUK 7]...'
            # DIRENDER di [110,1614] semasa matcher lapor 0 — regex
            # '.{16,}' mengandungi KOMA yang boleh memecahkan parser
            # selector UiAutomator (gagal SENYAP, ditelan except).
            # Regex tanpa koma + XPath string-length sebagai jaring. <<<
            els = []
            for by, q in (
                (AppiumBy.ANDROID_UIAUTOMATOR,
                 'new UiSelector().className("android.view.ViewGroup")'
                 '.clickable(true)'),
                (AppiumBy.ANDROID_UIAUTOMATOR,
                 'new UiSelector().descriptionMatches("(?s).{16}.*")'),
                (AppiumBy.XPATH,
                 '//*[string-length(@content-desc) > 15]'),
            ):
                try:
                    els.extend(self.driver.find_elements(by, q))
                except Exception:                            # noqa: BLE001
                    pass
            r = medan_rect[0]
            keep, dilihat = [], set()
            for e in els:
                try:
                    d = (e.get_attribute("content-desc") or "").strip()
                except Exception:                            # noqa: BLE001
                    continue
                if len(d) <= 15:
                    continue
                du = d.upper()
                if ", BACK" in du or du in _BUKAN_BARIS:
                    continue
                try:
                    er = e.rect
                except Exception:                            # noqa: BLE001
                    er = None
                if r is not None and er is not None:
                    # Baris pilihan render DI/BAWAH medan — apa-apa
                    # jauh di atasnya (bar tajuk dsb.) bukan baris.
                    if er["y"] < r["y"] - 60:
                        continue
                kunci = (du, er["y"] if er else -1)
                if kunci in dilihat:
                    continue
                dilihat.add(kunci)
                keep.append(e)
            return keep

        def _mod_ganti(prev):
            """MOD GANTI — ARAHAN CEO 2026-08-25: 'kalau data dari excel
            tak wujud, pilih mana-mana data yang boleh bagi lulus/lepas'.
            Taip huruf tunggal sehingga senarai tunjuk pilihan, pilih
            BARIS PERTAMA, log kuat sebagai [PENEMUAN-DATA]. Pulangkan
            Pulangan: True = pemilihan berdaftar; "KOSONG" = senarai
            BERFUNGSI tetapi 'Tiada rekod' untuk SEMUA huruf (jawapan
            muktamad server — tier sebelumnya jalan mati, jangan buang
            masa pada last-resort destruktif); False = lain-lain."""
            if ganti_sudah[0]:
                return False
            ganti_sudah[0] = True
            huruf_dicuba = [0]
            huruf_tiada = [0]
            dump_sudah = [False]
            for huruf in ("A", "E", "M", "K", "S", "T", "P", "B", "D",
                          "G", "L", "N", "I", "U"):
                el = _medan_penapis(prev) or _cari_medan_taip(prev)
                if el is None:
                    # Borang mungkin teranjak — cuba pulih DUA-DUA arah
                    # (dump notis: tersekat di ATAS, medan bawah fold;
                    # dump seksyen lama: tersekat di bawah).
                    for _arah in (self._swipe_bawah_sebenar,
                                  self._swipe_atas_sebenar,
                                  self._swipe_atas_sebenar):
                        _arah()
                        el = (_medan_penapis(prev)
                              or _cari_medan_taip(prev))
                        if el is not None:
                            break
                if el is None:
                    if _semak_terdaftar_sendiri("(ganti) "):
                        return True
                    continue
                try:
                    el.click()
                    self._force_clear(el)
                    self.driver.execute_script('mobile: type',
                                               {'text': huruf})
                    taipan_semua.append(huruf)
                    prev = huruf
                    time.sleep(0.4)
                    # Sahkan huruf MELEKAT (pengajaran _open_and_filter:
                    # taipan selepas tap boleh tidak melekat).
                    try:
                        t = (el.get_attribute("text") or "").strip()
                        if t.upper() != huruf:
                            el.click()
                            time.sleep(0.3)
                            self.driver.execute_script(
                                'mobile: type', {'text': huruf})
                    except Exception:                        # noqa: BLE001
                        pass
                    try:
                        if self.driver.is_keyboard_shown():
                            self.driver.hide_keyboard()
                            time.sleep(0.6)
                    except Exception:                        # noqa: BLE001
                        pass
                except Exception:                            # noqa: BLE001
                    continue
                # >>> 2026-08-26 (debug_pilih #3, log per-huruf): huruf
                # S/G menunjukkan 'Tiada rekod dijumpai' tetapi huruf
                # lain 0 baris TANPA teks itu — live-search tier-3
                # query ke SERVER dan hasilnya render LEWAT (semakan 1s
                # terlalu awal; debug v3 yang menunggu lebih lama jumpa
                # baris untuk penapis 'M'). POLL sehingga ~7s. <<<
                baris = []
                tiada_rekod = False
                _tiada_berturut = 0
                for _poll in range(6):
                    baris = _baris_sedia_ada()
                    if baris:
                        break
                    tiada_rekod = self.is_element_present(
                        (AppiumBy.ANDROID_UIAUTOMATOR,
                         'new UiSelector().textContains("Tiada rekod")'),
                        timeout=1)
                    # 'Tiada rekod' stabil 2 poll berturut = jawapan
                    # muktamad server — jangan bazir baki poll.
                    _tiada_berturut = _tiada_berturut + 1 if tiada_rekod \
                        else 0
                    if _tiada_berturut >= 2:
                        break
                    time.sleep(0.2)
                print(f"  [GANTI] huruf '{huruf}': {len(baris)} baris"
                      f"{' (Tiada rekod dijumpai)' if tiada_rekod else ''}")
                huruf_dicuba[0] += 1
                if tiada_rekod:
                    huruf_tiada[0] += 1
                if not baris:
                    # Kes misteri (notis): 0 baris TANPA 'Tiada rekod'
                    # — dump SEKALI untuk bukti in-situ run ini.
                    if not tiada_rekod and not dump_sudah[0]:
                        dump_sudah[0] = True
                        _dump_dd(f"ganti_{huruf}")
                    if _semak_terdaftar_sendiri("(ganti) "):
                        return True
                    continue
                ganti = baris[0]
                desc = ganti.get_attribute("content-desc") or ""
                print(f"  [DROPDOWN] [PENEMUAN-DATA] nilai Excel "
                      f"'{option_text[:60]}' TIADA dalam data server — "
                      f"GANTI (arahan CEO) dengan: '{desc[:80]}'")
                for cubaan in range(3):
                    try:
                        if cubaan == 1:
                            ganti.click()
                        else:
                            self.tap_element(ganti)
                    except Exception:                        # noqa: BLE001
                        pass
                    time.sleep(1.0)
                    masih = [e for e in _baris_sedia_ada()
                             if (e.get_attribute("content-desc") or "")
                             == desc]
                    if not masih:
                        print(f"  [DROPDOWN] SELECTED (GANTI) "
                              f"'{desc[:60]}' — senarai tutup, "
                              f"pemilihan didaftar")
                        return True
                    try:
                        ganti = masih[0]
                    except Exception:                        # noqa: BLE001
                        break
                print("  [DROPDOWN] mod GANTI: tap baris ganti tidak "
                      "didaftar — meneruskan ke huruf seterusnya...")
            print("  [DROPDOWN] mod GANTI: TIADA sebarang pilihan "
                  "ditemui untuk semua huruf")
            # >>> 2026-08-27 (validasi #4, pelbagai tier-3): SEMUA huruf
            # 'Tiada rekod dijumpai' = senarai berfungsi tapi memang
            # kosong (akta ganti '57' tiada kesalahan berkait). Ini
            # isyarat CASCADE jalan-mati, bukan kegagalan mekanisme —
            # dan last-resort destruktif selepasnya membakar 10+ min
            # lalu crash uiautomator2. Pulangkan isyarat khusus. <<<
            if huruf_dicuba[0] >= 5 and huruf_tiada[0] == huruf_dicuba[0]:
                return "KOSONG"
            return False

        # ================= ALIRAN UTAMA =================
        # AUDIT 2026-08-25: susunan BARU — laluan TANPA-MUSNAH dahulu
        # (penapis tepat -> kata1 -> GANTI huruf), clear+skrol destruktif
        # hanya LAST RESORT. Validasi 62-minit membuktikan laluan lama
        # (_find_row destruktif sebelum kata1/GANTI) menskrol borang
        # sehingga medan hilang dari hierarki.
        _open_and_filter()
        row = _cari_baris_ringan()
        ganti_prev = filter_text
        if row is None:
            # >>> 2026-08-24 (dropdown_MEMOTONGMENGALIH_fail.xml, run
            # penuh #2): prefix 25-aksara dengan koma/titik menapis
            # KELUAR semua rekod KESALAHAN dan senarai tertutup terus —
            # clear+scroll pun tak memulihkan. Cuba semula dari kosong
            # dengan penapis PERKATAAN PERTAMA sahaja (tanpa tanda
            # baca), yang cukup sempit tetapi sepadan dengan mana-mana
            # bentuk padanan live-search. <<<
            kata1 = "".join(c for c in option_text.split()[0]
                            if c.isalnum())[:12]
            if kata1 and kata1.lower() != filter_text.lower():
                print(f"  [DROPDOWN] retry dengan penapis perkataan "
                      f"pertama: {kata1!r}")
                # 2026-08-25: XPath @hint TIDAK wujud pada EditText app
                # ini (dump: placeholder dilapor sebagai text) — carian
                # field_by_hint gagal SENYAP dan retry tak pernah
                # menaip. Cari field ikut TEKS penapis semasa (nilai
                # yang kita sendiri taip tadi) — deterministik.
                # AUDIT 2026-08-25: find_element di sini menskrol borang
                # 10x bila field tak jumpa (run #6: 'retry kata1 tidak
                # dapat menaip (TimeoutException)') — selepas itu borang
                # terskrol jauh dan MOD GANTI jumpa kosong. Ganti dengan
                # carian TANPA-SKROL bertingkat.
                try:
                    el = _cari_medan_taip(filter_text)
                    if el is None:
                        raise TimeoutException("medan penapis tiada "
                                               "(tanpa-skrol)")
                    el.click()
                    self._force_clear(el)
                    self.driver.execute_script('mobile: type',
                                               {'text': kata1})
                    taipan_semua.append(kata1)
                    ganti_prev = kata1
                    time.sleep(0.5)
                    try:
                        if self.driver.is_keyboard_shown():
                            self.driver.hide_keyboard()
                            time.sleep(0.6)
                    except Exception:                        # noqa: BLE001
                        pass
                except Exception as e:                       # noqa: BLE001
                    print(f"  [DROPDOWN] retry kata1 tidak dapat menaip "
                          f"({type(e).__name__})")
                row = _cari_baris_ringan()

        # Nilai Excel tiada dalam senarai? GANTI (arahan CEO) SEBELUM
        # sebarang clear/skrol destruktif — borang masih dalam keadaan
        # baik di sini, medan penapis masih boleh dijumpai.
        if row is None:
            if _semak_terdaftar_sendiri():
                return
            hasil_ganti = _mod_ganti(ganti_prev)
            if hasil_ganti is True:
                return
            if hasil_ganti == "KOSONG":
                _dump_dd("kosong")
                raise TimeoutException(
                    f"SENARAI-KOSONG: senarai '{placeholder_text}' "
                    f"berfungsi tetapi 'Tiada rekod dijumpai' untuk "
                    f"SEMUA huruf — kemungkinan pilihan tier sebelumnya "
                    f"(akta) tiada rekod berkait. Nilai Excel: "
                    f"'{option_text[:60]}'")

        # LAST RESORT destruktif (varian dropdown lama yang perlukan
        # clear + skrol senarai penuh) — hanya selepas semua laluan
        # tanpa-musnah gagal.
        if row is None:
            print("  [DROPDOWN] last resort: clear + skrol senarai "
                  "penuh (destruktif)...")
            row = _find_row()
            if row is None:
                _scroll_inner_to_option()
                row = _find_row()

        if row is not None:
            # Tap the option ROW, trying successively different methods until
            # the list closes. These rows carry a REAL content-desc, so
            # el.click() (accessibility ACTION_CLICK) may register where a raw
            # coordinate tap no-ops -- the opposite of the desc-less RN
            # pressables elsewhere in this app, hence worth trying explicitly.
            for attempt in range(3):
                for method in ("coord", "click", "child"):
                    try:
                        if method == "coord":
                            self.tap_element(row)
                        elif method == "click":
                            row.click()
                        else:
                            child = row.find_element(
                                AppiumBy.CLASS_NAME,
                                "android.widget.TextView")
                            self.tap_element(child)
                    except Exception:                        # noqa: BLE001
                        pass
                    # Poll up to ~2s for the option list to close (RN close
                    # animation can lag a fast check). Row gone == the
                    # selection registered.
                    closed = False
                    for _ in range(4):
                        time.sleep(0.5)
                        if not _option_row_present():
                            closed = True
                            break
                    if closed:
                        print(f"  [DROPDOWN] SELECTED '{option_upper}' via "
                              f"{method}-tap on the option ROW (content-desc)"
                              f" — option list CLOSED (registered, not typed)")
                        return
                    # Still open -- re-resolve the row (it may have gone
                    # stale under us) and try the next tap method.
                    try:
                        row = self.find_element(row_by_desc, timeout=2)
                    except Exception:                        # noqa: BLE001
                        if not _option_row_present():
                            continue
                print(f"  [DROPDOWN] '{option_text}' pick not registered "
                      f"(attempt {attempt + 1}/3 -- tried coord/click/child)")
                _dump_dd(f"notreg{attempt + 1}")
        else:
            print(f"  [DROPDOWN] option row '{option_upper}' never rendered")

        # Baris jumpa tapi tap tak berdaftar, ATAU last resort pun gagal
        # — peluang terakhir: nilai mungkin sudah berdaftar sendiri,
        # atau GANTI (kalau belum dicuba selepas last resort).
        if _semak_terdaftar_sendiri("(akhir) "):
            return
        hasil_akhir = _mod_ganti(ganti_prev)
        if hasil_akhir is True:
            return
        if hasil_akhir == "KOSONG":
            _dump_dd("kosong")
            raise TimeoutException(
                f"SENARAI-KOSONG: senarai '{placeholder_text}' berfungsi "
                f"tetapi 'Tiada rekod dijumpai' untuk SEMUA huruf — "
                f"kemungkinan pilihan tier sebelumnya (akta) tiada rekod "
                f"berkait. Nilai Excel: '{option_text[:60]}'")

        _dump_dd("fail")
        raise TimeoutException(
            f"Pemilihan dropdown '{option_text}' daripada "
            f"'{placeholder_text}' tidak didaftarkan (baris pilihan tidak "
            f"dijumpai, atau tap tidak mendaftar selepas cuba coord/click/"
            f"child); lihat ui_dumps/dropdown_{safe}_*.xml")

    # Native AlertDialog pieces -- confirmed via live page-source dump
    # (debug_menu_selaras_close.xml): this app reports sync/upload
    # results through standard Android alerts (title "BERJAYA"/"RALAT",
    # message like "DATA JENIS KENDERAAN SAVED SUCCESSFULLY!", one OK
    # button with resource-id android:id/button1). These alerts arrive
    # asynchronously when the underlying operation finishes, and they
    # queue: a leftover alert blocks every element behind it.
    NATIVE_ALERT_OK = (AppiumBy.ANDROID_UIAUTOMATOR,
                       'new UiSelector().resourceId("android:id/button1")')
    NATIVE_ALERT_MESSAGE = (AppiumBy.ANDROID_UIAUTOMATOR,
                            'new UiSelector().resourceId("android:id/message")')

    def dismiss_native_alerts(self, first_timeout=5, context="",
                              kumpul=False):
        """Wait up to first_timeout for a native result alert, then
        dismiss it and any alerts queued behind it. Logs each alert's
        actual message text (ground truth for locator debugging).

        Nilai pulangan (kontrak sama seperti MBPG base_page):
          * kumpul=False (LALAI) — bool, True kalau sekurang-kurangnya
            satu alert ditolak. Kelakuan lama, tidak berubah.
          * kumpul=True — list[str] teks setiap alert IKUT URUTAN.
            Untuk pemanggil yang perlu tahu APA yang dikatakan (cth
            login() mengesan dialog penolakan kredensial).

        el.click() is fine here (real android.widget.Button, not one of
        this app's RN Pressables)."""
        import time
        teks = []
        if not self.is_element_present(self.NATIVE_ALERT_OK,
                                       timeout=first_timeout):
            return teks if kumpul else False
        dismissed = False
        for _ in range(6):
            try:
                msg = self.driver.find_element(*self.NATIVE_ALERT_MESSAGE).text
                teks.append(msg)
                print(f"  [ALERT] {context}: popup says: {msg}")
            except Exception:
                pass
            try:
                self.driver.find_element(*self.NATIVE_ALERT_OK).click()
                dismissed = True
            except Exception:
                break
            time.sleep(0.5)
            if not self.is_element_present(self.NATIVE_ALERT_OK, timeout=2):
                break
        return teks if kumpul else dismissed

    def drain_printer_alert(self):
        """Drain the app's "Error: Unable to connect device" modal alert and
        return True if one was present. See the PRINTER_ALERT_TEXT class note.

        Disabled (returns False, drains nothing) while the Cetak flow runs --
        there the alert is the real "printer unreachable" signal, not noise.
        Kept cheap enough to sit in the retry paths: it's only ever called
        AFTER a lookup/tap already failed, never on the happy path."""
        if not BasePage._drain_printer_enabled:
            return False
        msg_loc = (AppiumBy.ANDROID_UIAUTOMATOR,
                   f'new UiSelector().textContains("{self.PRINTER_ALERT_TEXT}")')
        if not self.is_element_present(msg_loc, timeout=1):
            return False
        BasePage._printer_alert_count += 1
        print(f"  [PRINTER-ALERT] 'Unable to connect device' detected -- "
              f"draining and retrying (#{BasePage._printer_alert_count})")
        # OK button is a real android.widget.Button (android:id/button1);
        # el.click() is fine. Fall back to the generic drain if the layout
        # differs.
        try:
            self.driver.find_element(*self.NATIVE_ALERT_OK).click()
            import time
            time.sleep(0.4)
        except Exception:                                    # noqa: BLE001
            self.dismiss_native_alerts(first_timeout=1,
                                       context="printer alert")
        return True

    @classmethod
    def printer_alert_count(cls):
        """How many times the printer-connection alert was drained this run."""
        return cls._printer_alert_count

    def read_record_number(self):
        """Read the created record's number (e.g. IPA3N260728054) off the
        CURRENT screen -- the success/receipt popup shows it as
        "NO KOMPAUN: IPA3...". Returns the IPA... token, or None if it
        can't be read. NEVER fabricates: None means "not readable", so the
        ledger stays empty rather than pointing at a record that may not
        exist. Call it BEFORE the popup is closed."""
        import re
        loc = (AppiumBy.ANDROID_UIAUTOMATOR,
               'new UiSelector().textMatches(".*IPA\\w{6,}.*")')
        try:
            for el in self.driver.find_elements(*loc):
                m = re.search(r'IPA\w{6,}', el.get_attribute('text') or '')
                if m:
                    num = m.group(0)
                    print(f"  [ARTIFACT] record number read: {num}")
                    self.last_record_number = num
                    return num
        except Exception:                                    # noqa: BLE001
            pass
        print("  [ARTIFACT] record number not readable on this screen "
              "(leaving ledger empty -- not fabricating)")
        return None

    def _locate_tempoh_el(self):
        """Locate the Tempoh (MAKLUMAT KOMPAUN section) EditText -- the
        header's sibling, or by its hint. NEVER the "MAKLUMAT KOMPAUN"
        header TextView (see TEMPOH_SIBLING). Returns None if absent."""
        for loc in (self.TEMPOH_SIBLING, self.TEMPOH_BY_HINT):
            try:
                return self.find_element(loc, timeout=4)
            except TimeoutException:
                continue
        return None

    def _set_tempoh_verified(self, value):
        """Set the Tempoh field to exactly `value` and assert it lands in
        the field's own 0-21 validity range before the form advances.

        Force-clear (RN silently ignores el.clear()) + retype + read-back,
        up to 3x. If the final value is wrong or out of range, RAISE -- an
        automation failure to report, not a stuck form to keep waiting on.
        Prints the read-back as explicit gate evidence. Shared by the Notis
        and Kompaun forms (same "MAKLUMAT KOMPAUN" header + sibling
        EditText)."""
        value = str(value).strip()
        last = None
        for attempt in range(3):
            el = self._locate_tempoh_el()
            if el is None:
                print("  [TEMPOH] field not locatable on this variant -- "
                      "leaving as-is")
                return
            self._force_clear(el)
            self.driver.execute_script('mobile: type', {'text': value})
            self._hide_keyboard_if_shown()
            el2 = self._locate_tempoh_el()
            last = self._safe_text(el2) if el2 is not None else None
            if last is not None and last.strip() == value:
                try:
                    n = int(last.strip())
                except ValueError:
                    n = None
                if n is not None and 0 <= n <= 21:
                    print(f"  [TEMPOH] set & read back = {last!r} "
                          f"(in range 0-21) — PASS")
                    return
            print(f"  [TEMPOH] read back {last!r}, wanted {value!r} "
                  f"(attempt {attempt + 1}/3) -- force-clear + retry")
        n = None
        try:
            n = int((last or "").strip())
        except (ValueError, TypeError):
            pass
        out_of_range = n is not None and not (0 <= n <= 21)
        raise TimeoutException(
            f"Tempoh Kompaun tidak dapat ditetapkan kepada '{value}' "
            f"(medan menunjukkan {last!r}"
            + (", DI LUAR julat sah 0-21" if out_of_range else "")
            + ") selepas 3 percubaan -- kegagalan automation (medan tidak "
            "dikosongkan betul / label salah padan), bukan bug aplikasi")

    def select_dropdown_option_and_confirm(self, placeholder_text,
                                            option_text, confirm_locator,
                                            timeout=None):
        """select_dropdown_option (which now self-verifies the pick
        registered and raises if it didn't), then VERIFY the form advanced
        via confirm_locator -- an element that only renders once the
        option list has closed (e.g. the next tier's placeholder, or the
        OPEN CAMERA button after the last tier).

        The old ambiguous re-tap (by text(), which also matched the input
        EditText) is gone: select_dropdown_option now taps the option ROW
        by content-desc and confirms the list closed, so reaching here
        means the pick registered. If confirm_locator still doesn't show,
        that's a genuine form-advance failure to surface, not a missed
        tap to paper over.
        """
        self.select_dropdown_option(placeholder_text, option_text, timeout)
        self._hide_keyboard_if_shown()

        if self.is_element_present(confirm_locator, timeout=8):
            return
        # Cheap below-the-fold safety: the next control may be unrendered.
        self._scroll_down()
        if self.is_element_present(confirm_locator, timeout=3):
            return

        dump_path = "debug_dropdown_confirm.xml"
        try:
            with open(dump_path, "w", encoding="utf-8") as f:
                f.write(self.driver.page_source)
            print(f"  [DEBUG] Form never came back after dropdown "
                  f"selection -- page source dumped to {dump_path}")
        except Exception:
            pass
        raise TimeoutException(
            f"Form did not come back after selecting '{option_text}' from "
            f"'{placeholder_text}' (confirm element {confirm_locator} not "
            f"found); see {dump_path}")

    def cuba_akta_ganti_lain(self, indeks):
        """CASCADE BACKTRACK (2026-08-27, validasi #4): akta ganti
        baris[0] boleh jadi jalan mati — tier kesalahan di bawahnya
        'Tiada rekod dijumpai' untuk semua huruf. Buka semula combobox
        AKTA (medan yang memegang nilai berformat 'KOD - TEKS'), taip
        'A', dan pilih baris ke-`indeks` pula. Pulangkan True jika
        pemilihan baharu didaftarkan.

        Medan akta dikenal pasti sebagai EditText yang teksnya
        mengandungi ' - ' (nilai terpilih seperti '57 - GAGAL PATUHI
        NOTIS HENTI NIAGA') — medan tier lain tidak berformat begitu
        (disahkan dump dropdown_SEKSYEN18BTIDAKM/IDAKMEMATUHIPERU)."""
        import time
        print(f"  [CASCADE] cuba akta ganti lain (baris ke-{indeks})...")
        loc = (AppiumBy.ANDROID_UIAUTOMATOR,
               'new UiSelector().className("android.widget.EditText")'
               '.textContains(" - ")')
        try:
            el = WebDriverWait(self.driver, 4).until(
                EC.presence_of_element_located(loc))
        except Exception:                                    # noqa: BLE001
            print("  [CASCADE] medan akta (teks 'KOD - ...') tidak "
                  "dijumpai — batal")
            return False
        try:
            rect = el.rect
            el.click()
            time.sleep(0.5)
            self._force_clear(el)
            self.driver.execute_script('mobile: type', {'text': 'A'})
            time.sleep(0.4)
            if self.driver.is_keyboard_shown():
                self.driver.hide_keyboard()
                time.sleep(0.6)
        except Exception as e:                               # noqa: BLE001
            print(f"  [CASCADE] gagal buka semula medan akta "
                  f"({type(e).__name__})")
            return False

        def _baris():
            # Sama seperti _baris_sedia_ada: regex tanpa koma + XPath
            # string-length (parser UiAutomator pecah pada '{16,}').
            els = []
            for by, q in (
                (AppiumBy.ANDROID_UIAUTOMATOR,
                 'new UiSelector().className("android.view.ViewGroup")'
                 '.clickable(true)'),
                (AppiumBy.ANDROID_UIAUTOMATOR,
                 'new UiSelector().descriptionMatches("(?s).{16}.*")'),
                (AppiumBy.XPATH,
                 '//*[string-length(@content-desc) > 15]'),
            ):
                try:
                    els.extend(self.driver.find_elements(by, q))
                except Exception:                            # noqa: BLE001
                    pass
            keep, dilihat = [], set()
            for e in els:
                try:
                    d = (e.get_attribute("content-desc") or "").strip()
                    er = e.rect
                except Exception:                            # noqa: BLE001
                    continue
                if len(d) <= 15 or ", BACK" in d.upper():
                    continue
                if er["y"] < rect["y"] - 60:
                    continue
                kunci = (d.upper(), er["y"])
                if kunci in dilihat:
                    continue
                dilihat.add(kunci)
                keep.append(e)
            return keep

        baris = []
        for _ in range(6):
            baris = _baris()
            if baris:
                break
            time.sleep(1.2)
        print(f"  [CASCADE] {len(baris)} baris akta tersedia")
        if not baris:
            return False
        pilih = baris[min(indeks, len(baris) - 1)]
        desc = pilih.get_attribute("content-desc") or ""
        print(f"  [CASCADE] [PENEMUAN-DATA] akta ganti baharu: "
              f"'{desc[:80]}'")
        for cubaan in range(3):
            try:
                if cubaan == 1:
                    pilih.click()
                else:
                    self.tap_element(pilih)
            except Exception:                                # noqa: BLE001
                pass
            time.sleep(1.0)
            masih = [e for e in _baris()
                     if (e.get_attribute("content-desc") or "") == desc]
            if not masih:
                print(f"  [CASCADE] akta baharu DIDAFTAR: '{desc[:60]}'")
                return True
            pilih = masih[0]
        print("  [CASCADE] tap akta baharu tidak didaftar")
        return False

    def close_popup_by_icon(self, timeout=3):
        """Close a popup using a close (X) icon. Tries a few common
        locator strategies since icon-only buttons vary by screen.

        Confirmed via live UI dump that the signature/"Simpan maklumat
        ini?" popup's close button has content-desc plain "X" (Latin
        capital letter), and the in-app camera's close button uses "✕"
        (U+2715) -- neither matched the original "Close"/"Tutup"
        variants, which silently sent every caller down to their
        fragile hardcoded-coordinate tap-outside fallback instead.
        """
        close_locators = [
            (AppiumBy.ACCESSIBILITY_ID, "X"),
            (AppiumBy.ACCESSIBILITY_ID, "✕"),
            (AppiumBy.ACCESSIBILITY_ID, "Close"),
            (AppiumBy.ANDROID_UIAUTOMATOR, 'new UiSelector().description("Close")'),
            (AppiumBy.ANDROID_UIAUTOMATOR, 'new UiSelector().descriptionContains("close")'),
            (AppiumBy.ANDROID_UIAUTOMATOR, 'new UiSelector().descriptionContains("Tutup")'),
        ]
        for loc in close_locators:
            if self.is_element_present(loc, timeout=timeout):
                self.wait_and_click(loc, timeout=timeout)
                return True
        return False

    def reveal_below_fold(self, target_locator, max_tabs=8):
        """v3: focus-traversal 'scrolling' for the RN record forms that
        resist every scroll gesture (Kemaskini / HantarSemula / Notis-
        to-Kompaun -- all confirmed live). Phase 1: TAB (keycode 61)
        cycles the text inputs, dragging the viewport with the focus.
        Phase 2: DPAD_DOWN (keycode 20) continues through non-text
        widgets once TAB stalls. Returns True when target_locator is
        present (keyboard hidden).

        max_tabs lowered 25->8 (perf): on a form where the target never
        renders (a genuinely blocked TC), 25 tabs x 2 keycodes x per-tab
        probes was ~minutes of dead traversal before giving up. The
        owner's call is to keep these TCs running, just fail faster."""
        import time

        def _found():
            if self.is_element_present(target_locator, timeout=0.5):
                self._hide_keyboard_if_shown()
                return self.is_element_present(target_locator, timeout=2)
            return False

        if _found():
            return True
        try:
            edits = self.driver.find_elements(
                AppiumBy.CLASS_NAME, "android.widget.EditText")
            if edits:
                edits[-1].click()
                time.sleep(0.5)
        except Exception:
            pass

        for keycode in (61, 20):
            last_src_len = 0
            stall = 0
            for _ in range(max_tabs):
                if _found():
                    return True
                self.driver.press_keycode(keycode)
                time.sleep(0.5)
                try:
                    n = len(self.driver.page_source)
                except Exception:
                    n = 0
                if n == last_src_len:
                    stall += 1
                    if stall >= 5:
                        break
                else:
                    stall = 0
                    last_src_len = n
        self._hide_keyboard_if_shown()
        return self.is_element_present(target_locator, timeout=3)

    # ------------------------------------------------------------------
    # Navigation helpers
    # ------------------------------------------------------------------

    def press_back(self):
        """Press the device back button."""
        print("  [NAV] Pressing device back button")
        self.driver.back()

    def go_back_to_home(self):
        """Navigate back to the home screen by pressing Back repeatedly.

        Checks HOME_SCREEN_INDICATOR (a home-grid module button), not
        HAMBURGER -- confirmed via live run that the hamburger icon is
        also present on the login screen, so relying on it alone let
        this falsely report "home reached" after only one back-press
        while actually already logged out.
        """
        print("  [NAV] Navigating back to home screen...")
        for i in range(5):
            if self.is_element_present(self.HOME_SCREEN_INDICATOR, timeout=2):
                print("  [NAV] Home screen reached")
                return True
            self.press_back()
            import time
            time.sleep(1)

        print("  [NAV] WARNING: May not have reached home screen")
        return False

    def take_screenshot(self, name="screenshot"):
        """Capture a screenshot for debugging."""
        path = f"screenshots/{name}.png"
        self.driver.save_screenshot(path)
        print(f"  [SCREENSHOT] Saved: {path}")
        return path

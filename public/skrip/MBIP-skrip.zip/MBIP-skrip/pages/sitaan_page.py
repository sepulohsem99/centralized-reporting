"""
Daftar Sitaan page — Page Object Model. v3-new (Phase 3).

Subclasses KompaunLesenPage: the Sitaan Pesalah tab was confirmed via
live recon (p3_sitaan_pesalah_top.xml) to carry the same fields as the
Lesen form (NAMA PEMILIK/SYARIKAT, NO K/P / SSM, NO AKAUN LESEN, address
block, plus a "TICK JIKA ALAMAT PREMIS SAMA..." checkbox that is left
untouched). The Kompaun tab and submission reuse the shared machinery.

The Barang-barang (seized items) section required by sheet MBIP-TC-S-001
has NOT been recon'd -- fill_barang_items is recon-first: it dumps the
form and tries candidate controls, logging clearly (non-fatally) when
the section can't be found so the create itself still completes and any
validation rejection surfaces honestly at submit.
"""

from appium.webdriver.common.appiumby import AppiumBy
from selenium.common.exceptions import TimeoutException
from pages.kompaun_lesen_page import KompaunLesenPage


class SitaanPage(KompaunLesenPage):
    """Daftar Kompaun — jenis SITAAN."""

    OPTION_SITAAN = (AppiumBy.ANDROID_UIAUTOMATOR,
                     'new UiSelector().text("SITAAN")')
    # Tier-3 close-evidence: the PILIH KADAR DENDA label, not OPEN
    # CAMERA -- confirmed via debug_dropdown_confirm.xml: on this form
    # the camera sits below the Barang section, and the amount field
    # carries no ENTER AMAUN hint (it renders holding "0").
    TIER3_CONFIRM = (AppiumBy.ANDROID_UIAUTOMATOR,
                     'new UiSelector().textStartsWith("PILIH KADAR DENDA")')

    def select_jenis_sitaan(self):
        """Select SITAAN from the jenis popup (option confirmed present
        via live recon), verified-tap like the other jenis variants."""
        print("\n  [SITAAN] Selecting jenis: Sitaan...")
        import time
        # Open-evidence must NOT be "SITAAN text gone": the Sitaan
        # screen's own title is also "SITAAN" (bit us live). Use the
        # pesalah field appearing / another popup option vanishing.
        pesalah_field = (AppiumBy.ANDROID_UIAUTOMATOR,
                         'new UiSelector().text("NAMA PEMILIK/SYARIKAT")')
        other_option = (AppiumBy.ANDROID_UIAUTOMATOR,
                        'new UiSelector().text("KOMPAUN TRAFIK")')
        for attempt in range(3):
            self.wait_and_tap(self.OPTION_SITAAN)
            time.sleep(1.5)
            if (self.is_element_present(pesalah_field, timeout=4)
                    or not self.is_element_present(other_option,
                                                   timeout=2)):
                print("  [SITAAN] Jenis Sitaan selected — PASS")
                self._dump("sitaan_pesalah_tab.xml")
                return
            print(f"  [SITAAN] Jenis popup still open after tap "
                  f"(attempt {attempt + 1}/3) -- re-tapping...")
        self._dump("sitaan_jenis_popup_stuck.xml")
        raise TimeoutException(
            "SITAAN option never registered a tap; see "
            "ui_dumps/sitaan_jenis_popup_stuck.xml")

    def fill_barang_items(self, items):
        """Add the seized items (sheet MBIP-TC-S-001: MEJA 2 UNIT,
        KERUSI 4 UNIT). Recon-first: the section's controls are searched
        via candidates; a page-source dump is written either way.

        NON-FATAL by design: if the section isn't found, the create
        proceeds and any validation rejection is reported at submit."""
        import time
        print(f"  [SITAAN] Adding barang items: {items}")
        self._dump("sitaan_barang_area.xml")

        section = (AppiumBy.ANDROID_UIAUTOMATOR,
                   'new UiSelector().textContains("BARANG-BARANG")')
        try:
            self.find_element(section, timeout=8)
        except TimeoutException:
            print("  [SITAAN] WARNING: no 'BARANG-BARANG' section found "
                  "on this screen -- items not added (see "
                  "ui_dumps/sitaan_barang_area.xml); continuing")
            return False

        # The section header carries a toggle icon (U+F102, confirmed
        # via debug_dropdown_confirm.xml) that expands the add-item UI
        # ("TIADA BARANG DITAMBAH" shows while the list is empty).
        toggle = (AppiumBy.ANDROID_UIAUTOMATOR,
                  'new UiSelector().description("")')
        if self.is_element_present(toggle, timeout=3):
            el = self.find_element(toggle, timeout=3)
            self.tap_element(el)
            import time as _t
            _t.sleep(1.5)
            self._dump("sitaan_barang_expanded.xml")

        added = 0
        for name, qty in items:
            # candidate name/qty inputs: try label-based fills first
            filled_name = self._fill_first_matching(
                ["NAMA BARANG", "BARANG", "ITEM"], name, optional=True)
            filled_qty = self._fill_first_matching(
                ["KUANTITI", "UNIT", "BILANGAN", "QTY"], qty,
                optional=True, use_mobile_type=True)
            if filled_name is None and filled_qty is None:
                print(f"  [SITAAN] WARNING: no input fields for barang "
                      f"{name!r} -- stopping item entry")
                self._dump("sitaan_barang_inputs_missing.xml")
                break
            # add/confirm row button
            tambah = (AppiumBy.ANDROID_UIAUTOMATOR,
                      'new UiSelector().textMatches("(?i)\\s*(tambah|'
                      'add|\\+)\\s*")')
            if self.is_element_present(tambah, timeout=3):
                el = self.find_element(tambah, timeout=3)
                self.tap_element(el)
                import time as _t
                _t.sleep(1)
            added += 1
            print(f"  [SITAAN] barang added: {name} x {qty}")
        self._dump("sitaan_barang_after.xml")
        return added == len(items)

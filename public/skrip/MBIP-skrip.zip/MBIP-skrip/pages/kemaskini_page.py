"""
Kemaskini (record update) flow — Page Object Model. v3-new (Phase 2).

Flow confirmed via live recon (2026-07-16, dumps in ui_dumps/):
  Senarai row tap -> "KEMASKINI DATA" popup (record fields as TextViews,
  X close = content-desc U+2715, KEMASKINI + CETAK buttons, all
  content-desc) -> KEMASKINI -> "SILA ISI KETERANGAN" popup (EditText
  'ISI KEMASKINI KETERANGAN' + SETERUSNYA) -> full-screen
  "KEMASKINI <jenis>" edit form with the old data pre-filled in
  EditTexts.

KNOWN LIMITATION (confirmed via recon rounds 4/5 and the dedicated
scroll-crack recon): the edit form does not respond to ANY scroll
gesture (raw swipes, mobile: scroll/swipeGesture -- element-anchored or
not -- W3C slow drags, UiScrollable). The only technique that moves its
viewport is keyboard-focus traversal (tap an EditText, then TAB /
keycode 61), and that stalls after the Kesalahan address block. So this
flow updates the fields it can genuinely reach -- the Kesalahan address
block, which is exactly what the Kemaskini sheets change most -- and
logs clearly when a below-the-fold field (lokasi/butiran/tempoh/kod
dropdowns) could not be reached.
"""

from appium.webdriver.common.appiumby import AppiumBy
from selenium.common.exceptions import TimeoutException
from pages.base_page import BasePage


class KemaskiniPage(BasePage):
    """Record popup + kemaskini edit-form flow (reached from Senarai)."""

    POPUP_TITLE = (AppiumBy.ANDROID_UIAUTOMATOR,
                   'new UiSelector().text("KEMASKINI DATA")')
    BUTTON_KEMASKINI = (AppiumBy.ACCESSIBILITY_ID, "KEMASKINI")
    POPUP_X = (AppiumBy.ACCESSIBILITY_ID, "✕")
    KETERANGAN_FIELD = (AppiumBy.ANDROID_UIAUTOMATOR,
                        'new UiSelector().textContains("ISI KEMASKINI")')
    BUTTON_SETERUSNYA_ACC = (AppiumBy.ACCESSIBILITY_ID, "SETERUSNYA")

    def _dump(self, name):
        try:
            import os
            os.makedirs("ui_dumps", exist_ok=True)
            path = os.path.join("ui_dumps", name)
            with open(path, "w", encoding="utf-8") as f:
                f.write(self.driver.page_source)
            print(f"  [KEMASKINI] DEBUG: page source dumped to {path}")
            return path
        except Exception:
            return "(dump failed)"

    # ------------------------------------------------------------------
    # Step 1: verify old data on the record popup
    # ------------------------------------------------------------------

    def verify_record_popup(self, old_values):
        """On the just-opened KEMASKINI DATA popup, assert each expected
        old value is displayed (sheet step 1: 'Verify that all existing
        data displayed matches the previously saved information')."""
        assert self.is_element_present(self.POPUP_TITLE, timeout=10), \
            "KEMASKINI DATA popup not displayed after tapping the record"
        missing = []
        for key, value in old_values.items():
            loc = (AppiumBy.ANDROID_UIAUTOMATOR,
                   f'new UiSelector().textContains("{value}")')
            if self.is_element_present(loc, timeout=3):
                print(f"  [KEMASKINI] old {key} '{value}' displayed — PASS")
            else:
                missing.append((key, value))
        if missing:
            path = self._dump("kemaskini_old_data_missing.xml")
            raise AssertionError(
                f"Old data not displayed on the record popup: {missing}; "
                f"see {path}")

    # ------------------------------------------------------------------
    # Step 2: KEMASKINI -> keterangan popup -> edit form
    # ------------------------------------------------------------------

    def start_kemaskini(self, keterangan="KEMASKINI VIA AUTOMATION"):
        """Tap KEMASKINI (verified), fill the SILA ISI KETERANGAN popup,
        SETERUSNYA to the edit form."""
        import time
        print("  [KEMASKINI] Tapping KEMASKINI...")
        for attempt in range(3):
            el = self.find_element(self.BUTTON_KEMASKINI, timeout=10)
            self.tap_element(el)
            time.sleep(1.5)
            if self.is_element_present(self.KETERANGAN_FIELD, timeout=5):
                break
            print(f"  [KEMASKINI] Keterangan popup didn't open "
                  f"(attempt {attempt + 1}/3) -- re-tapping...")
        else:
            path = self._dump("kemaskini_keterangan_missing.xml")
            raise TimeoutException(
                f"SILA ISI KETERANGAN popup never opened; see {path}")

        print(f"  [KEMASKINI] Entering keterangan: {keterangan}")
        el = self.find_element(self.KETERANGAN_FIELD, timeout=5)
        el.click()
        el.clear()
        self.driver.execute_script('mobile: type', {'text': keterangan})
        # keep_keyboard semantics: this is a dismissible RN modal --
        # hide_keyboard can act like Back and close the whole popup
        # (bit us live: SETERUSNYA 'not found' because the popup was
        # gone). Only hide as a fallback if the button can't be seen.
        time.sleep(0.5)

        print("  [KEMASKINI] Tapping SETERUSNYA...")
        try:
            el = self.find_element(self.BUTTON_SETERUSNYA_ACC, timeout=5)
        except TimeoutException:
            self._hide_keyboard_if_shown()
            time.sleep(0.5)
            if not self.is_element_present(self.KETERANGAN_FIELD,
                                           timeout=2):
                # the popup got dismissed -- reopen and retry once
                print("  [KEMASKINI] keterangan popup got dismissed -- "
                      "reopening...")
                el = self.find_element(self.BUTTON_KEMASKINI, timeout=10)
                self.tap_element(el)
                time.sleep(1.5)
                el = self.find_element(self.KETERANGAN_FIELD, timeout=5)
                el.click()
                el.clear()
                self.driver.execute_script('mobile: type',
                                           {'text': keterangan})
                time.sleep(0.5)
            el = self.find_element(self.BUTTON_SETERUSNYA_ACC, timeout=5)
        self.tap_element(el)
        time.sleep(2.5)

    def is_edit_form_open(self, jenis_title_fragment):
        """The edit form's appbar title is 'KEMASKINI <jenis>' (confirmed
        for Notis Amaran via recon)."""
        loc = (AppiumBy.ANDROID_UIAUTOMATOR,
               f'new UiSelector().textContains("KEMASKINI")'
               f'.textContains("{jenis_title_fragment}")')
        # UiSelector chains textContains AND-style only on one call each;
        # fall back to just KEMASKINI-prefix title check.
        if self.is_element_present(loc, timeout=5):
            return True
        loc2 = (AppiumBy.ANDROID_UIAUTOMATOR,
                'new UiSelector().textStartsWith("KEMASKINI ")')
        return self.is_element_present(loc2, timeout=5)

    # ------------------------------------------------------------------
    # Step 3: update fields on the edit form
    # ------------------------------------------------------------------

    def _edit_field_holding(self, old_text, new_text, label):
        """Find the EditText currently holding old_text, clear it, type
        new_text, and verify the value landed. Returns True on success."""
        loc = (AppiumBy.ANDROID_UIAUTOMATOR,
               f'new UiSelector().className("android.widget.EditText")'
               f'.text("{old_text}")')
        try:
            el = self.find_element(loc, timeout=6)
        except TimeoutException:
            print(f"  [KEMASKINI] WARNING: no EditText holding "
                  f"{old_text!r} for {label} -- skipping")
            return False
        el.click()
        el.clear()
        self.driver.execute_script('mobile: type', {'text': new_text})
        self._hide_keyboard_if_shown()
        import time
        time.sleep(0.5)
        check = (AppiumBy.ANDROID_UIAUTOMATOR,
                 f'new UiSelector().className("android.widget.EditText")'
                 f'.textContains("{new_text}")')
        ok = self.is_element_present(check, timeout=3)
        print(f"  [KEMASKINI] {label}: {old_text!r} -> {new_text!r} "
              f"{'— PASS' if ok else '(could not verify)'}")
        return True

    def update_kesalahan_address(self, old_jalan, data):
        """Update the reachable Kesalahan address block: jalan (located
        by its old value from the create), then taman/poskod right under
        it (located positionally as the following EditTexts -- their old
        values can be auto-fill artifacts, so position beats text here).

        The jalan field on this form may be an autocomplete like the
        create form's: if a suggestion list renders after typing, the
        matching row is picked."""
        import time
        self._dump("kemaskini_edit_form_before.xml")

        changed = self._edit_field_holding(old_jalan,
                                           data["kesalahan_jalan"],
                                           "kesalahan jalan")
        if changed:
            row = (AppiumBy.ANDROID_UIAUTOMATOR,
                   f'new UiSelector().className("android.widget.TextView")'
                   f'.textContains("{data["kesalahan_jalan"]}")')
            if self.is_element_present(row, timeout=4):
                try:
                    el = self.find_element(row, timeout=3)
                    self.tap_element(el)
                    print("  [KEMASKINI] Picked jalan suggestion row")
                    time.sleep(1.5)
                except Exception:
                    pass

        # taman/poskod: the two EditTexts following the (now updated)
        # jalan field under the MAKLUMAT KESALAHAN header.
        xpath = ('//android.widget.TextView[@text="MAKLUMAT KESALAHAN"]'
                 '/following-sibling::android.widget.EditText')
        try:
            els = self.driver.find_elements(AppiumBy.XPATH, xpath)
        except Exception:
            els = []
        if len(els) >= 2:
            for idx, key in ((1, "kesalahan_taman"), (2, "kesalahan_poskod")):
                if idx >= len(els):
                    break
                # type-verify-retry: confirmed live (v3 shakedown) that
                # a typed value can silently fail to stick on this form
                # (the RN re-render triggered by clear() swallows the
                # keystrokes racing it -- same failure mode as Kadar
                # Denda on the create form).
                for attempt in range(3):
                    try:
                        els = self.driver.find_elements(AppiumBy.XPATH,
                                                        xpath)
                        el = els[idx]
                        current = el.text
                        if current == data[key]:
                            print(f"  [KEMASKINI] {key} holds "
                                  f"'{data[key]}' — PASS")
                            break
                        el.click()
                        el.clear()
                        time.sleep(0.3)
                        self.driver.execute_script('mobile: type',
                                                   {'text': data[key]})
                        self._hide_keyboard_if_shown()
                        time.sleep(0.5)
                    except Exception as e:
                        print(f"  [KEMASKINI] WARNING: {key} update "
                              f"attempt {attempt + 1} failed "
                              f"({type(e).__name__})")
                else:
                    print(f"  [KEMASKINI] WARNING: {key} never verified "
                          f"as {data[key]!r}")
        else:
            print("  [KEMASKINI] WARNING: MAKLUMAT KESALAHAN sibling "
                  "EditTexts not found -- taman/poskod left as-is")

        self._dump("kemaskini_edit_form_after.xml")

    # ------------------------------------------------------------------
    # Step 4: proceed (Seterusnya) and submit
    # ------------------------------------------------------------------

    def _reveal_below_fold(self, target_locator, max_tabs=25):
        """Focus traversal (see BasePage.reveal_below_fold -- promoted
        there in Phase 3 since the Notis-to-Kompaun form needs it too)."""
        return self.reveal_below_fold(target_locator, max_tabs=max_tabs)

    def _dedah_uiscrollable(self):
        """>>> DIPORT DARI MBPG (2026-08-20) — laluan tatal TERBUKTI. <<<

        Borang edit app ini menolak SEMUA saluran gesture: driver.swipe
        anjakan 0px, `mobile: scrollGesture` selesai bersih TANPA
        menggerakkan apa-apa (bukti dump MBPG run 12:52), dan focus
        traversal tersekat. Mekanisme yang TERBUKTI menggerakkan borang
        RN app ini ialah UiScrollable scrollIntoView — enjin UiAutomator
        menatal DAN mencari serentak (bukti: pemulihan dropdown K MBPG
        "baca-balik LULUS selepas menatal kembali"). instance(0) dan (1)
        kedua-duanya dicuba kerana ScrollView dalam (blok alamat) boleh
        mendahului dalam urutan pokok.

        Pulangkan "SETERUSNYA" / "MENYERAHKAN" / None."""
        from appium.webdriver.common.appiumby import AppiumBy
        from config import IMPLICIT_WAIT
        sasaran = (
            ('new UiSelector().textMatches("(?i)\\s*MENYERAHKAN\\s*")',
             "MENYERAHKAN"),
            ('new UiSelector().descriptionContains("SETERUSNYA")',
             "SETERUSNYA"),
            ('new UiSelector().textMatches("(?i)\\s*SETERUSNYA\\s*")',
             "SETERUSNYA"),
        )
        for inst in (0, 1):
            for sel, nama in sasaran:
                expr = ('new UiScrollable(new UiSelector()'
                        f'.scrollable(true).instance({inst}))'
                        f'.scrollIntoView({sel})')
                self.driver.implicitly_wait(0)
                try:
                    self.driver.find_element(
                        AppiumBy.ANDROID_UIAUTOMATOR, expr)
                except Exception:                            # noqa: BLE001
                    continue
                finally:
                    self.driver.implicitly_wait(IMPLICIT_WAIT)
                print(f"  [KEMASKINI] {nama} didedahkan oleh UiScrollable "
                      f"scrollIntoView instance({inst})")
                return nama
        return None

    def proceed_and_submit(self):
        """Find SETERUSNYA (may be below the fold -> focus traversal),
        tap it, then drive whatever follows to submission: any further
        SETERUSNYA screens, MENYERAHKAN, the 'Simpan maklumat' HANTAR
        popup, and result alerts. Dump-driven at each unknown."""
        import time
        if not self.is_element_present(self.BUTTON_SETERUSNYA_ACC,
                                       timeout=3):
            print("  [KEMASKINI] SETERUSNYA below the fold -- "
                  "UiScrollable dahulu (laluan terbukti MBPG), "
                  "focus traversal sebagai sandaran...")
            hasil = self._dedah_uiscrollable()
            if hasil is None and not self._reveal_below_fold(
                    self.BUTTON_SETERUSNYA_ACC, max_tabs=10):
                path = self._dump("kemaskini_no_seterusnya.xml")
                raise TimeoutException(
                    f"SETERUSNYA not reachable on the edit form (form "
                    f"resists scrolling; UiScrollable + focus traversal "
                    f"stalled); see {path}")
        el = self.find_element(self.BUTTON_SETERUSNYA_ACC, timeout=5)
        self.tap_element(el)
        print("  [KEMASKINI] SETERUSNYA tapped")
        time.sleep(2.5)
        self._dump("kemaskini_after_seterusnya.xml")

        # Drive to submission, tolerating flow-shape differences.
        menyerahkan = self.BUTTON_MENYERAHKAN
        for _ in range(4):
            if self.is_element_present(self.POPUP_SIMPAN_MAKLUMAT_LOC,
                                       timeout=3):
                print("  [KEMASKINI] 'Simpan maklumat' popup -- HANTAR")
                el = self.find_clickable(self.BUTTON_HANTAR)
                self.tap_element(el)
                break
            if self.is_element_present(menyerahkan, timeout=3):
                print("  [KEMASKINI] MENYERAHKAN visible -- tapping")
                self._hide_keyboard_if_shown()
                el = self.find_clickable(menyerahkan)
                self.tap_element(el)
                time.sleep(2)
                continue
            if self.is_element_present(self.BUTTON_SETERUSNYA_ACC,
                                       timeout=3):
                print("  [KEMASKINI] another SETERUSNYA -- tapping")
                el = self.find_element(self.BUTTON_SETERUSNYA_ACC,
                                       timeout=3)
                self.tap_element(el)
                time.sleep(2)
                continue
            break

        found = self.dismiss_native_alerts(first_timeout=20,
                                           context="kemaskini submit")
        if found:
            print("  [KEMASKINI] Submission result alert dismissed")
        time.sleep(1)

    POPUP_SIMPAN_MAKLUMAT_LOC = (AppiumBy.ANDROID_UIAUTOMATOR,
                                 'new UiSelector().textContains('
                                 '"Simpan maklumat")')

    # ------------------------------------------------------------------
    # Step 5: verify the update landed
    # ------------------------------------------------------------------

    def verify_updated(self, senarai_page, jenis_letter, new_value):
        """Re-open the jenis' record popup from Senarai and assert the
        new value is displayed."""
        import time
        time.sleep(1)
        senarai_page.open_record_by_jenis(jenis_letter)
        assert self.is_element_present(self.POPUP_TITLE, timeout=10), \
            "record popup did not reopen for post-update verification"
        loc = (AppiumBy.ANDROID_UIAUTOMATOR,
               f'new UiSelector().textContains("{new_value}")')
        ok = self.is_element_present(loc, timeout=5)
        if not ok:
            path = self._dump("kemaskini_verify_failed.xml")
            # close the popup before failing so recovery is trivial
            try:
                el = self.find_element(self.POPUP_X, timeout=3)
                self.tap_element(el)
            except Exception:
                pass
            raise AssertionError(
                f"updated value {new_value!r} not displayed on the "
                f"record popup after kemaskini; see {path}")
        print(f"  [KEMASKINI] updated value {new_value!r} displayed — PASS")
        try:
            el = self.find_element(self.POPUP_X, timeout=3)
            self.tap_element(el)
        except Exception:
            pass

"""
Kemaskini (record update) flow — Page Object Model. v3-new (Phase 2).

Flow confirmed via live recon (2026-07-16, dumps in ui_dumps/):
  Senarai row tap -> "KEMASKINI DATA" popup (record fields as TextViews,
  X close = content-desc U+2715, KEMASKINI + CETAK buttons, all
  content-desc) -> KEMASKINI -> "SILA ISI KETERANGAN" popup (EditText
  'ISI KEMASKINI KETERANGAN' + SETERUSNYA) -> full-screen
  "KEMASKINI <jenis>" edit form with the old data pre-filled in
  EditTexts.

KNOWN LIMITATION (confirmed via recon rounds 4/5 and the dedicated
scroll-crack recon): the edit form does not respond to ANY scroll
gesture (raw swipes, mobile: scroll/swipeGesture -- element-anchored or
not -- W3C slow drags, UiScrollable). The only technique that moves its
viewport is keyboard-focus traversal (tap an EditText, then TAB /
keycode 61), and that stalls after the Kesalahan address block. So this
flow updates the fields it can genuinely reach -- the Kesalahan address
block, which is exactly what the Kemaskini sheets change most -- and
logs clearly when a below-the-fold field (lokasi/butiran/tempoh/kod
dropdowns) could not be reached.
"""

from appium.webdriver.common.appiumby import AppiumBy
from selenium.common.exceptions import TimeoutException
from pages.base_page import BasePage


class KemaskiniPage(BasePage):
    """Record popup + kemaskini edit-form flow (reached from Senarai)."""

    POPUP_TITLE = (AppiumBy.ANDROID_UIAUTOMATOR,
                   'new UiSelector().text("KEMASKINI DATA")')
    BUTTON_KEMASKINI = (AppiumBy.ACCESSIBILITY_ID, "KEMASKINI")
    POPUP_X = (AppiumBy.ACCESSIBILITY_ID, "✕")
    KETERANGAN_FIELD = (AppiumBy.ANDROID_UIAUTOMATOR,
                        'new UiSelector().textContains("ISI KEMASKINI")')
    # >>> 2026-09-04: run verify (tanpa-bersih, jambatan_log3) buktikan
    # P-004 crash kerana KETERANGAN_FIELD (locator atas, textContains
    # placeholder "ISI KEMASKINI") gagal padan bila popup dibuka KALI
    # KEDUA dalam sesi yang sama (no_reset=True) -- medan EditText
    # mengekalkan teks keterangan LAMA dari kemaskini sebelumnya (cth.
    # "KEMASKINI VIA AUTOMATION V3" dari N-004), bukan placeholder
    # kosong, jadi textContains("ISI KEMASKINI") tak padan langsung.
    # Dump kemaskini_keterangan_missing.xml BUKTI popup SEBENARNYA
    # terbuka (tajuk "SILA ISI KETERANGAN" + SETERUSNYA + ✕ semua
    # hadir, 1 EditText dgn teks lama) -- kod salah anggap "popup tak
    # terbuka" dan tap semula BUTTON_KEMASKINI yang dah tertutup oleh
    # popup, punca "BUTTON_KEMASKINI not found" percubaan 2/3. Locator
    # baharu di bawah stabil tanpa mengira kandungan medan. <<<
    KETERANGAN_POPUP_TITLE = (AppiumBy.ANDROID_UIAUTOMATOR,
                              'new UiSelector().textContains('
                              '"SILA ISI KETERANGAN")')
    KETERANGAN_INPUT = (AppiumBy.ANDROID_UIAUTOMATOR,
                        'new UiSelector().className('
                        '"android.widget.EditText")')
    BUTTON_SETERUSNYA_ACC = (AppiumBy.ACCESSIBILITY_ID, "SETERUSNYA")

    def _dump(self, name):
        try:
            import os
            os.makedirs("ui_dumps", exist_ok=True)
            path = os.path.join("ui_dumps", name)
            with open(path, "w", encoding="utf-8") as f:
                f.write(self.driver.page_source)
            print(f"  [KEMASKINI] DEBUG: page source dumped to {path}")
            return path
        except Exception:
            return "(dump failed)"

    # ------------------------------------------------------------------
    # Step 1: verify old data on the record popup
    # ------------------------------------------------------------------

    def verify_record_popup(self, old_values):
        """On the just-opened KEMASKINI DATA popup, assert each expected
        old value is displayed (sheet step 1: 'Verify that all existing
        data displayed matches the previously saved information')."""
        assert self.is_element_present(self.POPUP_TITLE, timeout=10), \
            "KEMASKINI DATA popup not displayed after tapping the record"
        missing = []
        for key, value in old_values.items():
            loc = (AppiumBy.ANDROID_UIAUTOMATOR,
                   f'new UiSelector().textContains("{value}")')
            if self.is_element_present(loc, timeout=3):
                print(f"  [KEMASKINI] old {key} '{value}' displayed — PASS")
            else:
                missing.append((key, value))
        if missing:
            path = self._dump("kemaskini_old_data_missing.xml")
            raise AssertionError(
                f"Old data not displayed on the record popup: {missing}; "
                f"see {path}")

    # ------------------------------------------------------------------
    # Step 2: KEMASKINI -> keterangan popup -> edit form
    # ------------------------------------------------------------------

    def start_kemaskini(self, keterangan="KEMASKINI VIA AUTOMATION"):
        """Tap KEMASKINI (verified), fill the SILA ISI KETERANGAN popup,
        SETERUSNYA to the edit form."""
        import time
        print("  [KEMASKINI] Tapping KEMASKINI...")
        # >>> 2026-09-04: run verify (tanpa-bersih, jambatan log2) buktikan
        # P-004/K-004 crash DI SINI -- bukan "SILA ISI KETERANGAN popup
        # never opened" (mesej else asal), sebaliknya TimeoutException
        # MENTAH dari find_element(BUTTON_KEMASKINI) pada percubaan ke-2:
        # log K-004 tunjuk alert asli ("RALAT BERLAKU. DATA KEKAL DI
        # SIMPANAN LOKAL.") tiba tak segerak SEBELUM langkah ini --
        # corak SAMA seperti T-012 (alert tak dilayan sebelum carian
        # elemen). Sebelum ini find_element(BUTTON_KEMASKINI) pada
        # percubaan ulang tidak dilindungi try/except, jadi timeout pada
        # percubaan ke-2/3 terus tumbang keluar loop tanpa sempat cuba
        # dismiss_native_alerts() atau percubaan ke-3. Tampal dismiss
        # sebelum setiap percubaan + bungkus find_element supaya loop
        # sentiasa habiskan 3 percubaan sebelum mengalah. <<<
        for attempt in range(3):
            self.dismiss_native_alerts(first_timeout=1,
                                       context="kemaskini tap KEMASKINI")
            try:
                el = self.find_element(self.BUTTON_KEMASKINI, timeout=10)
            except TimeoutException:
                print(f"  [KEMASKINI] BUTTON_KEMASKINI not found "
                      f"(attempt {attempt + 1}/3) -- alert dismiss + "
                      f"retry...")
                continue
            self.tap_element(el)
            time.sleep(1.5)
            if self.is_element_present(self.KETERANGAN_POPUP_TITLE,
                                       timeout=5):
                break
            print(f"  [KEMASKINI] Keterangan popup didn't open "
                  f"(attempt {attempt + 1}/3) -- re-tapping...")
        else:
            path = self._dump("kemaskini_keterangan_missing.xml")
            raise TimeoutException(
                f"SILA ISI KETERANGAN popup never opened; see {path}")

        print(f"  [KEMASKINI] Entering keterangan: {keterangan}")
        el = self.find_element(self.KETERANGAN_INPUT, timeout=5)
        el.click()
        el.clear()
        self.driver.execute_script('mobile: type', {'text': keterangan})
        # keep_keyboard semantics: this is a dismissible RN modal --
        # hide_keyboard can act like Back and close the whole popup
        # (bit us live: SETERUSNYA 'not found' because the popup was
        # gone). Only hide as a fallback if the button can't be seen.
        time.sleep(0.5)

        print("  [KEMASKINI] Tapping SETERUSNYA...")
        try:
            el = self.find_element(self.BUTTON_SETERUSNYA_ACC, timeout=5)
        except TimeoutException:
            self._hide_keyboard_if_shown()
            time.sleep(0.5)
            if not self.is_element_present(self.KETERANGAN_POPUP_TITLE,
                                           timeout=2):
                # the popup got dismissed -- reopen and retry once
                print("  [KEMASKINI] keterangan popup got dismissed -- "
                      "reopening...")
                el = self.find_element(self.BUTTON_KEMASKINI, timeout=10)
                self.tap_element(el)
                time.sleep(1.5)
                el = self.find_element(self.KETERANGAN_INPUT, timeout=5)
                el.click()
                el.clear()
                self.driver.execute_script('mobile: type',
                                           {'text': keterangan})
                time.sleep(0.5)
            el = self.find_element(self.BUTTON_SETERUSNYA_ACC, timeout=5)
        self.tap_element(el)
        time.sleep(2.5)

        # >>> 2026-09-03: SETERUSNYA tap di sini TIDAK PERNAH disahkan --
        # melanggar peraturan CLAUDE.md sendiri ("Setiap tap kritikal...
        # mesti disahkan"). Bukti run BERSIH: kemaskini_edit_form_before/
        # after.xml (dump dari update_kesalahan_address selepas fungsi
        # ini) hanya ada 2 EditText & skrin masih papar 'SILA ISI
        # KETERANGAN' + 'SETERUSNYA' -- iaitu popup keterangan yang
        # SAMA, bukan borang edit penuh (recon borang sebenar ada >10
        # EditText). Tap silently no-op (kelas kegagalan yang sama
        # seperti "Tap boleh gagal didaftarkan secara senyap" dalam
        # CLAUDE.md), jadi caller (update_kesalahan_address) menyangka
        # ia di borang edit sedangkan ia masih di popup -- punca sebenar
        # beberapa kegagalan K-004/N-004/P-004 yang disangka "borang
        # tidak render", bukan halangan app. Sahkan popup keterangan
        # benar-benar tertutup; cuba semula tap kalau tidak. <<<
        for cubaan in range(3):
            if not self.is_element_present(self.KETERANGAN_POPUP_TITLE,
                                           timeout=2):
                break
            print(f"  [KEMASKINI] SETERUSNYA no-op -- popup keterangan "
                  f"masih ada (cubaan {cubaan + 1}/3) -- tap semula...")
            self.dismiss_native_alerts(first_timeout=1,
                                       context="kemaskini seterusnya")
            try:
                el = self.find_element(self.BUTTON_SETERUSNYA_ACC,
                                       timeout=3)
                self.tap_element(el)
            except TimeoutException:
                pass
            time.sleep(2.0)
        else:
            path = self._dump("kemaskini_seterusnya_stuck_on_popup.xml")
            raise TimeoutException(
                f"SETERUSNYA tap tidak berkesan -- masih di popup "
                f"keterangan selepas 3 percubaan (bukan borang edit); "
                f"lihat {path}")

    def is_edit_form_open(self, jenis_title_fragment):
        """The edit form's appbar title is 'KEMASKINI <jenis>' (confirmed
        for Notis Amaran via recon)."""
        loc = (AppiumBy.ANDROID_UIAUTOMATOR,
               f'new UiSelector().textContains("KEMASKINI")'
               f'.textContains("{jenis_title_fragment}")')
        # UiSelector chains textContains AND-style only on one call each;
        # fall back to just KEMASKINI-prefix title check.
        if self.is_element_present(loc, timeout=5):
            return True
        loc2 = (AppiumBy.ANDROID_UIAUTOMATOR,
                'new UiSelector().textStartsWith("KEMASKINI ")')
        return self.is_element_present(loc2, timeout=5)

    # ------------------------------------------------------------------
    # Step 3: update fields on the edit form
    # ------------------------------------------------------------------

    def _edit_field_holding(self, old_text, new_text, label,
                            hide_keyboard=True):
        """Find the EditText currently holding old_text, clear it, type
        new_text, and verify the value landed. Returns True on success.

        hide_keyboard=False: JANGAN tutup papan kekunci selepas taip --
        2026-09-04: medan jalan ialah autocomplete; hide_keyboard()
        bertindak macam Back (CLAUDE.md) dan MENUTUP senarai cadangan
        sebelum sempat dipilih -> "Picked jalan suggestion row" tak
        pernah muncul dalam run yang gagal -> bandar tak auto-isi -> app
        tolak "SILA PILIH BANDAR DARIPADA SENARAI". Caller yang perlu
        pilih cadangan tutup papan kekunci SELEPAS memilih."""
        loc = (AppiumBy.ANDROID_UIAUTOMATOR,
               f'new UiSelector().className("android.widget.EditText")'
               f'.text("{old_text}")')
        try:
            el = self.find_element(loc, timeout=6)
        except TimeoutException:
            print(f"  [KEMASKINI] WARNING: no EditText holding "
                  f"{old_text!r} for {label} -- skipping")
            return False
        el.click()
        el.clear()
        self.driver.execute_script('mobile: type', {'text': new_text})
        if hide_keyboard:
            self._hide_keyboard_if_shown()
        import time
        time.sleep(0.5)
        check = (AppiumBy.ANDROID_UIAUTOMATOR,
                 f'new UiSelector().className("android.widget.EditText")'
                 f'.textContains("{new_text}")')
        ok = self.is_element_present(check, timeout=3)
        print(f"  [KEMASKINI] {label}: {old_text!r} -> {new_text!r} "
              f"{'— PASS' if ok else '(could not verify)'}")
        return True

    def update_kesalahan_address(self, old_jalan, data):
        """Update the reachable Kesalahan address block: jalan (located
        by its old value from the create), then taman/poskod right under
        it (located positionally as the following EditTexts -- their old
        values can be auto-fill artifacts, so position beats text here).

        The jalan field on this form may be an autocomplete like the
        create form's: if a suggestion list renders after typing, the
        matching row is picked."""
        import time
        self._dump("kemaskini_edit_form_before.xml")

        # >>> 2026-09-04 18:33 -- BUKTI SCREENSHOT Appium (diagnostik
        # test_zz_diag_kemaskini_bandar, ui_dumps/diagb_4_penuh.png &
        # diagb_5_tab2.png): dropdown cadangan jalan MEMANG render selepas
        # taip (baris "JALAN MELAWATI 1 | TAMAN MELAWATI | SKUDAI"), tetapi
        # ia dilukis TERUS DI BAWAH medan jalan dan TERLINDUNG DI BAWAH
        # PAPAN KEKUNCI -- di luar viewport, jadi tiada dalam pokok
        # aksesibiliti (sebab semua carian baris sebelum ni gagal, dan
        # sebab 04:40 kebetulan berjaya: layout ketika itu lain). Human
        # tester nampak senarai selepas skrin anjak sedikit. TAB (keycode
        # 61) SEKALI anjak viewport ~300px TANPA ubah nilai medan (disahkan
        # dump: nilai kekal, baris muncul) -- ikut cara human: taip penuh,
        # TAB, tunggu baris TEPAT (textStartsWith "<jalan> |" -- elak
        # "MELAWATI 10"), tap dgn sahkan hilang, ulang 3x. <<<
        sasaran = data["kesalahan_jalan"]
        changed = self._edit_field_holding(old_jalan, sasaran,
                                           "kesalahan jalan",
                                           hide_keyboard=False)
        if changed:
            row = (AppiumBy.ANDROID_UIAUTOMATOR,
                   'new UiSelector().className("android.widget.TextView")'
                   f'.textStartsWith("{sasaran} |")')
            row_any = (AppiumBy.ANDROID_UIAUTOMATOR,
                       'new UiSelector().className("android.widget.TextView")'
                       '.textContains("|")')
            dipilih = False
            for cubaan in range(3):
                if not self.is_element_present(row, timeout=2):
                    # anjak viewport supaya dropdown keluar dari bawah
                    # papan kekunci (TAB = focus traversal, nilai kekal)
                    try:
                        self.driver.press_keycode(61)
                    except Exception:                        # noqa: BLE001
                        pass
                    time.sleep(1.2)
                if not self.is_element_present(row, timeout=6):
                    print(f"  [KEMASKINI] baris cadangan tepat '{sasaran} |' "
                          f"belum kelihatan (cubaan {cubaan + 1}/3); "
                          f"ada baris lain: "
                          f"{self.is_element_present(row_any, timeout=1)}")
                    continue
                try:
                    el = self.find_element(row, timeout=3)
                    teks = el.text
                    self.tap_element(el)
                    time.sleep(1.5)
                except Exception:                            # noqa: BLE001
                    continue
                if not self.is_element_present(row, timeout=2):
                    print(f"  [KEMASKINI] Picked jalan suggestion row "
                          f"{teks!r} -- senarai cadangan tertutup")
                    dipilih = True
                    break
                print(f"  [KEMASKINI] cadangan jalan masih tunjuk selepas "
                      f"tap (cubaan {cubaan + 1}/3) -- tap semula...")
            if not dipilih:
                self._dump("kemaskini_cadangan_jalan_tak_dipilih.xml")
            # papan kekunci ditutup SELEPAS pilihan cadangan (bukan
            # sebelum -- lihat nota _edit_field_holding).
            self._hide_keyboard_if_shown()
            time.sleep(0.5)

        # taman/poskod: the two EditTexts following the (now updated)
        # jalan field under the MAKLUMAT KESALAHAN header.
        xpath = ('//android.widget.TextView[@text="MAKLUMAT KESALAHAN"]'
                 '/following-sibling::android.widget.EditText')
        try:
            els = self.driver.find_elements(AppiumBy.XPATH, xpath)
        except Exception:
            els = []
        if len(els) >= 2:
            for idx, key in ((1, "kesalahan_taman"), (2, "kesalahan_poskod")):
                if idx >= len(els):
                    break
                # type-verify-retry: confirmed live (v3 shakedown) that
                # a typed value can silently fail to stick on this form
                # (the RN re-render triggered by clear() swallows the
                # keystrokes racing it -- same failure mode as Kadar
                # Denda on the create form).
                for attempt in range(3):
                    try:
                        els = self.driver.find_elements(AppiumBy.XPATH,
                                                        xpath)
                        el = els[idx]
                        current = el.text
                        if current == data[key]:
                            print(f"  [KEMASKINI] {key} holds "
                                  f"'{data[key]}' — PASS")
                            break
                        el.click()
                        el.clear()
                        time.sleep(0.3)
                        self.driver.execute_script('mobile: type',
                                                   {'text': data[key]})
                        self._hide_keyboard_if_shown()
                        time.sleep(0.5)
                    except Exception as e:
                        print(f"  [KEMASKINI] WARNING: {key} update "
                              f"attempt {attempt + 1} failed "
                              f"({type(e).__name__})")
                else:
                    print(f"  [KEMASKINI] WARNING: {key} never verified "
                          f"as {data[key]!r}")
        else:
            print("  [KEMASKINI] WARNING: MAKLUMAT KESALAHAN sibling "
                  "EditTexts not found -- taman/poskod left as-is")

        self._dump("kemaskini_edit_form_after.xml")

    # ------------------------------------------------------------------
    # Step 4: proceed (Seterusnya) and submit
    # ------------------------------------------------------------------

    def _reveal_below_fold(self, target_locator, max_tabs=25):
        """Focus traversal (see BasePage.reveal_below_fold -- promoted
        there in Phase 3 since the Notis-to-Kompaun form needs it too)."""
        return self.reveal_below_fold(target_locator, max_tabs=max_tabs)

    def _dedah_uiscrollable(self):
        """>>> DIPORT DARI MBPG (2026-08-20) — laluan tatal TERBUKTI. <<<

        Borang edit app ini menolak SEMUA saluran gesture: driver.swipe
        anjakan 0px, `mobile: scrollGesture` selesai bersih TANPA
        menggerakkan apa-apa (bukti dump MBPG run 12:52), dan focus
        traversal tersekat. Mekanisme yang TERBUKTI menggerakkan borang
        RN app ini ialah UiScrollable scrollIntoView — enjin UiAutomator
        menatal DAN mencari serentak (bukti: pemulihan dropdown K MBPG
        "baca-balik LULUS selepas menatal kembali"). instance(0) dan (1)
        kedua-duanya dicuba kerana ScrollView dalam (blok alamat) boleh
        mendahului dalam urutan pokok.

        Pulangkan "SETERUSNYA" / "MENYERAHKAN" / None."""
        from appium.webdriver.common.appiumby import AppiumBy
        from config import IMPLICIT_WAIT
        sasaran = (
            ('new UiSelector().textMatches("(?i)\\s*MENYERAHKAN\\s*")',
             "MENYERAHKAN"),
            ('new UiSelector().descriptionContains("SETERUSNYA")',
             "SETERUSNYA"),
            ('new UiSelector().textMatches("(?i)\\s*SETERUSNYA\\s*")',
             "SETERUSNYA"),
        )
        for inst in (0, 1):
            for sel, nama in sasaran:
                expr = ('new UiScrollable(new UiSelector()'
                        f'.scrollable(true).instance({inst}))'
                        f'.scrollIntoView({sel})')
                self.driver.implicitly_wait(0)
                try:
                    self.driver.find_element(
                        AppiumBy.ANDROID_UIAUTOMATOR, expr)
                except Exception:                            # noqa: BLE001
                    continue
                finally:
                    self.driver.implicitly_wait(IMPLICIT_WAIT)
                print(f"  [KEMASKINI] {nama} didedahkan oleh UiScrollable "
                      f"scrollIntoView instance({inst})")
                return nama
        return None

    # Fix #22 helpers ---------------------------------------------------
    def _swipe_atas_papan_kekunci(self):
        """Swipe ke atas bermula di KAWASAN ATAS skrin (y 1300 -> 450)
        supaya gesture tak jatuh pada tetingkap IME kalau papan kekunci
        masih terbuka. Cuba `mobile: swipeGesture` dahulu (UiAutomator2
        gesture API), sandaran driver.swipe mentah."""
        try:
            self.driver.execute_script("mobile: swipeGesture", {
                "left": 100, "top": 450, "width": 880, "height": 850,
                "direction": "up", "percent": 0.9, "speed": 2500})
            return True
        except Exception:                                    # noqa: BLE001
            pass
        try:
            self.driver.swipe(540, 1300, 540, 450, 400)
            return True
        except Exception:                                    # noqa: BLE001
            return False

    def _dedah_swipe_manual(self, maks=8):
        """Sandaran Fix #22: paksa tutup papan kekunci (kalau terbuka),
        swipe berulang di kawasan atas papan kekunci, periksa MENYERAHKAN
        / SETERUSNYA selepas setiap swipe. Pulangkan nama butang / None."""
        import time
        try:
            if self.driver.is_keyboard_shown():
                print("  [KEMASKINI] Fix #22: papan kekunci masih terbuka "
                      "-- tutup dahulu")
                self.driver.hide_keyboard()
                time.sleep(0.8)
        except Exception:                                    # noqa: BLE001
            pass
        for i in range(1, maks + 1):
            if self.is_element_present(self.BUTTON_MENYERAHKAN, timeout=0.5):
                print(f"  [KEMASKINI] Fix #22: MENYERAHKAN nampak selepas "
                      f"{i - 1} swipe manual")
                return "MENYERAHKAN"
            if self.is_element_present(self.BUTTON_SETERUSNYA_ACC,
                                       timeout=0.5):
                print(f"  [KEMASKINI] Fix #22: SETERUSNYA nampak selepas "
                      f"{i - 1} swipe manual")
                return "SETERUSNYA"
            if not self._swipe_atas_papan_kekunci():
                break
            time.sleep(0.9)
        # satu percubaan UiScrollable terakhir selepas viewport dah anjak
        hasil = self._dedah_uiscrollable()
        if hasil is None:
            print(f"  [KEMASKINI] Fix #22: {maks} swipe manual + UiScrollable "
                  "masih tak jumpa butang -- fallback focus traversal")
        return hasil

    def proceed_and_submit(self):
        """Find SETERUSNYA (may be below the fold -> focus traversal),
        tap it, then drive whatever follows to submission: any further
        SETERUSNYA screens, MENYERAHKAN, the 'Simpan maklumat' HANTAR
        popup, and result alerts. Dump-driven at each unknown."""
        import time
        # >>> 2026-09-04: run verify (tanpa-bersih, jambatan_log3, PAGI
        # lepas fix #1/#2) buktikan N-004 gagal DI SINI SEKARANG --
        # _dedah_uiscrollable() dedahkan "MENYERAHKAN" terus (bukan
        # "SETERUSNYA") sebab borang kemaskini ni memang tak ada
        # SETERUSNYA lagi selepas blok alamat Kesalahan -- ia terus ke
        # MENYERAHKAN. Kod lama ABAIKAN nilai `hasil` dan cuba
        # find_element(BUTTON_SETERUSNYA_ACC) SELEPAS UiScrollable tanpa
        # syarat, jadi walaupun UiScrollable jumpa & tatal ke MENYERAHKAN
        # dgn betul, langkah seterusnya tetap cari SETERUSNYA (yg
        # mungkin dah tak dlm viewport lepas tatal, atau memang tak
        # wujud) -> TimeoutException. Tampal: kalau hasil == "MENYERAHKAN",
        # tap MENYERAHKAN terus di sini (bukan SETERUSNYA), skip terus ke
        # gelung submit di bawah. <<<
        tapped_menyerahkan_early = False
        if not self.is_element_present(self.BUTTON_SETERUSNYA_ACC,
                                       timeout=3):
            print("  [KEMASKINI] SETERUSNYA below the fold -- "
                  "UiScrollable dahulu (laluan terbukti MBPG), "
                  "focus traversal sebagai sandaran...")
            # 2026-09-04 (N-004 09:08, dump kemaskini_no_seterusnya.xml,
            # 3 scrollable, medan jalan DAH dikemaskini): UiScrollable
            # gagal 2x + focus traversal gagal -- flake berulang selepas
            # pilih baris cadangan jalan (papan kekunci/dropdown mungkin
            # masih terbuka & menghalang tatal). Tutup papan kekunci +
            # layan alert dahulu, baru cuba.
            self._hide_keyboard_if_shown()
            self.dismiss_native_alerts(first_timeout=1,
                                       context="kemaskini sebelum tatal")
            time.sleep(0.8)
            hasil = self._dedah_uiscrollable()
            if hasil is None:
                # >>> 2026-09-04: run verify (P-004, fix #1/2/3 aktif)
                # buktikan _dedah_uiscrollable() kadang PULANG None
                # (gagal jumpa MENYERAHKAN/SETERUSNYA langsung) pada
                # percubaan pertama utk borang Kompaun Pelbagai --
                # kemaskini_no_seterusnya.xml dump BUKTI borang MASIH
                # ada kandungan lanjut (blok kod akta/kesalahan + gambar
                # lampiran, 3 elemen scrollable) yg belum ditatal --
                # kemungkinan besar timing race dgn RN re-render (sama
                # kelas isu macam field taman/poskod yg kadang hilang).
                # Tampal: cuba SEKALI LAGI sebelum fallback ke focus
                # traversal -- murah & alamat flakiness ni terus. <<<
                for pusingan in (2, 3):
                    print(f"  [KEMASKINI] UiScrollable pusingan "
                          f"{pusingan - 1} tak jumpa apa-apa -- cuba "
                          f"lagi (pusingan {pusingan}/3)...")
                    self._hide_keyboard_if_shown()
                    # >>> Fix #22 (2026-09-05 K-004 run penuh): swipe lama
                    # bermula y=1800 -- kawasan papan kekunci IME kalau ia
                    # masih terbuka (skrin 2460px) -> gesture jatuh pada
                    # IME, ScrollView tak bergerak. Mula lebih atas
                    # (y=1300 -> 450), sentiasa di atas papan kekunci. <<<
                    self._swipe_atas_papan_kekunci()
                    time.sleep(1.5)
                    hasil = self._dedah_uiscrollable()
                    if hasil is not None:
                        break
                if hasil is None:
                    # >>> Fix #22 (2026-09-05, K-004 run penuh, dump
                    # kemaskini_no_seterusnya.xml): borang Trafik, 1
                    # ScrollView sahaja, UiScrollable 3x tak jumpa
                    # MENYERAHKAN & focus traversal (TAB tak sampai butang)
                    # gagal -- sedangkan K-004 LULUS 2x sebelum ini dgn
                    # laluan sama (flake selepas tap-semula baris cadangan
                    # jalan; kemungkinan papan kekunci muncul semula & IME
                    # telan gesture UiScrollable). Sandaran murah sebelum
                    # traversal: paksa tutup papan kekunci, swipe berulang
                    # di kawasan ATAS papan kekunci sambil periksa butang. <<<
                    hasil = self._dedah_swipe_manual()
            if hasil == "MENYERAHKAN":
                print("  [KEMASKINI] MENYERAHKAN didedahkan terus (borang "
                      "ni tiada SETERUSNYA lagi) -- tap MENYERAHKAN terus")
                el = self.find_clickable(self.BUTTON_MENYERAHKAN)
                self.tap_element(el)
                time.sleep(2)
                tapped_menyerahkan_early = True
            elif hasil is None:
                # >>> 2026-09-04 20:34 (K-004, dump kemaskini_no_seterusnya
                # .xml): borang Trafik lebih panjang, UiScrollable gagal
                # 3x, dan focus traversal lama cari SETERUSNYA -- yang
                # TIDAK WUJUD pada borang kemaskini (butang komit ialah
                # MENYERAHKAN). Traversal mungkin dah sampai butang tapi
                # tak "jumpa". Cari MENYERAHKAN ATAU SETERUSNYA, dengan
                # lebih banyak TAB (borang Trafik ada lebih banyak medan). <<<
                mana2 = (AppiumBy.ANDROID_UIAUTOMATOR,
                         'new UiSelector().textMatches('
                         '"(?i)\\s*(MENYERAHKAN|SETERUSNYA)\\s*")')
                if not self._reveal_below_fold(mana2, max_tabs=25):
                    path = self._dump("kemaskini_no_seterusnya.xml")
                    raise TimeoutException(
                        f"MENYERAHKAN/SETERUSNYA not reachable on the edit "
                        f"form (UiScrollable + focus traversal stalled); "
                        f"see {path}")
                if self.is_element_present(self.BUTTON_MENYERAHKAN,
                                           timeout=2):
                    print("  [KEMASKINI] MENYERAHKAN didedahkan oleh focus "
                          "traversal -- tap MENYERAHKAN terus")
                    self._hide_keyboard_if_shown()
                    el = self.find_clickable(self.BUTTON_MENYERAHKAN)
                    self.tap_element(el)
                    time.sleep(2)
                    tapped_menyerahkan_early = True
        if not tapped_menyerahkan_early:
            el = self.find_element(self.BUTTON_SETERUSNYA_ACC, timeout=5)
            self.tap_element(el)
            print("  [KEMASKINI] SETERUSNYA tapped")
            time.sleep(2.5)
        self._dump("kemaskini_after_seterusnya.xml")

        # Drive to submission, tolerating flow-shape differences.
        menyerahkan = self.BUTTON_MENYERAHKAN
        for _ in range(4):
            if self.is_element_present(self.POPUP_SIMPAN_MAKLUMAT_LOC,
                                       timeout=3):
                print("  [KEMASKINI] 'Simpan maklumat' popup -- HANTAR")
                el = self.find_clickable(self.BUTTON_HANTAR)
                self.tap_element(el)
                break
            if self.is_element_present(menyerahkan, timeout=3):
                print("  [KEMASKINI] MENYERAHKAN visible -- tapping")
                self._hide_keyboard_if_shown()
                el = self.find_clickable(menyerahkan)
                self.tap_element(el)
                time.sleep(2)
                continue
            if self.is_element_present(self.BUTTON_SETERUSNYA_ACC,
                                       timeout=3):
                print("  [KEMASKINI] another SETERUSNYA -- tapping")
                el = self.find_element(self.BUTTON_SETERUSNYA_ACC,
                                       timeout=3)
                self.tap_element(el)
                time.sleep(2)
                continue
            # >>> 2026-09-04: run verify (tanpa-bersih, jambatan_log3)
            # buktikan N-004/P-004/K-004 gagal SELEPAS SETERUSNYA
            # terakhir di sini -- kemaskini_after_seterusnya.xml
            # (dump selepas tap) tunjuk skrin ringkasan (field lama
            # dipaparkan) TANPA sebarang butang MENYERAHKAN/SETERUSNYA/
            # HANTAR kelihatan (hanya butang back "SENARAI KOMPAUN,
            # back" wujud dalam 11 elemen clickable). Punca: borang ini
            # menolak SEMUA scroll biasa (dokumentasi di atas fail ini),
            # dan gelung ini TIDAK PERNAH cuba UiScrollable
            # (_dedah_uiscrollable, laluan terbukti MBPG) untuk dedahkan
            # butang commit yang mungkin di bawah lipatan -- ia hanya
            # semak is_element_present tanpa tatal, jadi butang di bawah
            # lipatan tak pernah dijumpai dan gelung give up serta-merta
            # (verify_updated pun gagal sebab rekod tak pernah disimpan).
            # Tampal: sebelum give up, cuba _dedah_uiscrollable() sekali;
            # kalau ia jumpa MENYERAHKAN/SETERUSNYA, teruskan gelung
            # supaya cabang yang betul di atas boleh tap ia. <<<
            hasil = self._dedah_uiscrollable()
            if hasil is not None:
                print(f"  [KEMASKINI] {hasil} didedahkan via UiScrollable "
                      f"selepas SETERUSNYA terakhir -- cuba lagi...")
                continue
            break

        found = self.dismiss_native_alerts(first_timeout=20,
                                           context="kemaskini submit")
        if found:
            print("  [KEMASKINI] Submission result alert dismissed")
        time.sleep(1)

        # >>> 2026-09-04: run verify (fix #1/#2/#3 semua aktif) buktikan
        # N-004 submission SEBENAR berjaya kali PERTAMA (Simpan maklumat
        # -> HANTAR tercapai) tapi verify_updated MASIH gagal -- dump
        # kemaskini_verify_row_not_found.xml BUKTI skrin lepas HANTAR
        # ialah popup APP-LEVEL "CETAK NOTIS AMARAN ?" (modal RN,
        # BUKAN native Android alert, jadi dismiss_native_alerts() di
        # atas TAK detect/tutup ia -- ia reka utk alert native sahaja)
        # dengan butang CETAK + X. Popup ni still on-screen menghalang
        # verify_updated cari baris dalam Senarai. Tampal: tutup popup
        # CETAK dengan X (JANGAN CETAK -- ini ujian data, bukan TC
        # Cetak berasingan) guna close_popup_by_icon() sedia ada
        # (base_page.py, confirmed content-desc "X" utk popup jenis
        # ni) sebelum verify_updated dipanggil oleh caller. <<<
        cetak_loc = (AppiumBy.ANDROID_UIAUTOMATOR,
                    'new UiSelector().textContains("CETAK")')
        self.no_rekod_baharu = None
        if self.is_element_present(cetak_loc, timeout=3):
            print("  [KEMASKINI] popup 'CETAK ... ?' muncul selepas "
                  "HANTAR -- tutup dengan X (bukan cetak)")
            # >>> 2026-09-04 (pre-empt, dari bukti dump): popup CETAK
            # papar "NO NOTIS: IPA3N260904005" bila rekod yg diedit
            # ialah ...004 -- kemaskini MENGELUARKAN NOMBOR REKOD BAHARU
            # (selari dgn docstring senarai_page.open_record_by_jenis:
            # "an update issues a NEW record number per the tester's
            # SENARAI sheet"). Tangkap nombor tu DI SINI sebelum tutup
            # popup, supaya verify_updated boleh cari ikut NOMBOR
            # (open_record_by_number, mekanisme terbukti sepanjang malam)
            # dan bukan ikut huruf jenis -- dump clickfail_1788505743.xml
            # buktikan baris rekod K pun ber-content-desc "P, ..." jadi
            # padanan "^K," tak akan jumpa apa-apa, dan senarai disusun
            # LAMA->BARU jadi baris "first" ialah rekod paling lama. <<<
            try:
                no_loc = (AppiumBy.ANDROID_UIAUTOMATOR,
                          'new UiSelector().textMatches(".*IPA3\\w+.*")')
                import re as _re
                for _el in self.driver.find_elements(*no_loc):
                    _m = _re.search(r"IPA3\w+", _el.text or "")
                    if _m:
                        self.no_rekod_baharu = _m.group(0)
                        break
            except Exception:                                # noqa: BLE001
                pass
            print(f"  [KEMASKINI] nombor rekod baharu selepas kemaskini: "
                  f"{self.no_rekod_baharu or '(tak dapat dibaca)'}")
            self.close_popup_by_icon(timeout=3)
            time.sleep(1)
        else:
            # Tiada popup CETAK = simpan mungkin DITOLAK oleh validasi app
            # (2026-09-04 N-004: alert "SILA PILIH BANDAR DARIPADA
            # SENARAI." lalu kekal di borang edit). Laporkan sebab
            # sebenar di sini, bukan gagal secara mengelirukan di
            # verify_updated ("updated value not displayed").
            masih_borang = (AppiumBy.ANDROID_UIAUTOMATOR,
                            'new UiSelector().textStartsWith("KEMASKINI ")')
            if self.is_element_present(masih_borang, timeout=2):
                path = self._dump("kemaskini_submit_ditolak.xml")
                raise AssertionError(
                    "Kemaskini TIDAK disimpan -- app masih di borang edit "
                    "selepas MENYERAHKAN/HANTAR (kemungkinan alert validasi "
                    "app, lihat baris [ALERT] kemaskini submit dalam log); "
                    f"lihat {path}")

    POPUP_SIMPAN_MAKLUMAT_LOC = (AppiumBy.ANDROID_UIAUTOMATOR,
                                 'new UiSelector().textContains('
                                 '"Simpan maklumat")')

    # ------------------------------------------------------------------
    # Step 5: verify the update landed
    # ------------------------------------------------------------------

    def _pastikan_di_senarai(self, senarai_page, max_back=4):
        """Selepas HANTAR + tutup popup CETAK: buka Senarai SEGAR dari HOME.

        >>> 2026-09-04 19:15 (N-004 & P-004, kemaskini DITERIMA app,
        rekod baharu ...009 / ...016): verify gagal kerana paging tak
        berfungsi pada senarai "sisa" selepas submit (chevron-right lapor
        palsu, dump clickfail kosong -- skrin dalam keadaan peralihan).
        Paging berjaya setiap kali pada senarai yang baru dibuka dari
        HOME. Jadi: tekan Back sehingga HOME (penunjuk NOTIS AMARAN),
        buka semula modul Senarai, pastikan baris ada -- senarai bersih
        di halaman 1, kedudukan kiri/atas. <<<"""
        import time
        from pages.home_page import HomePage
        home = HomePage(self.driver)
        for _ in range(max_back + 1):
            self.dismiss_native_alerts(first_timeout=1,
                                       context="kemaskini balik HOME")
            if self.is_element_present(self.HOME_SCREEN_INDICATOR, timeout=3):
                break
            try:
                self.driver.back()
            except Exception:                                # noqa: BLE001
                pass
            time.sleep(1.5)
        else:
            print("  [KEMASKINI] HOME tidak dicapai selepas Back berulang")
            return False
        print("  [KEMASKINI] di HOME -- buka Senarai segar utk verify")
        home.open_senarai()
        time.sleep(2)
        try:
            self.driver.get_screenshot_as_file(
                "ui_dumps/kemaskini_verify_mula.png")
        except Exception:                                    # noqa: BLE001
            pass
        return senarai_page.ensure_records_listed()

    def verify_updated(self, senarai_page, jenis_letter, new_value):
        """Re-open the jenis' record popup from Senarai and assert the
        new value is displayed."""
        import time
        time.sleep(1)
        # >>> 2026-09-04: run verify (tanpa-bersih) buktikan N-004 gagal
        # DI SINI -- open_record_by_jenis timeout 10s cari baris "N,...
        # <tarikh>...", tiada dump sebab TimeoutException mentah dari
        # find_element tumbang terus (tiada except di sini sebelum ini).
        # Punca belum disahkan (skrin mungkin balik ke HOME lepas submit
        # bukan kekal di Senarai, ATAU senarai belum refresh dgn rekod
        # terbaru) -- kod lama tiada cara nak bezakan sebab tiada dump.
        # Tampal: dismiss alert + dump + SATU percubaan ulang dengan
        # timeout lagi panjang, supaya (a) andaian "senarai belum
        # refresh" diuji secara adil, dan (b) kalau masih gagal, dump
        # sebenar ada untuk siasat root cause tepat esok -- jangan tumbang
        # senyap macam sebelum ini. <<<
        # >>> 2026-09-04 (pre-empt, dari bukti dump clickfail_1788505743
        # .xml + docstring open_record_by_jenis): (a) selepas HANTAR +
        # tutup popup CETAK, skrin mungkin BUKAN senarai (dump awal
        # tunjuk paparan butiran dgn butang "SENARAI KOMPAUN, back") --
        # pastikan balik ke senarai dulu; (b) kemaskini keluarkan NOMBOR
        # REKOD BAHARU (ditangkap dlm proceed_and_submit ->
        # self.no_rekod_baharu) -- cari ikut NOMBOR (open_record_by_number,
        # sudah ada refresh+retry fix #6/#7, terbukti sepanjang malam);
        # (c) fallback huruf jenis guna which="last" sebab senarai disusun
        # LAMA->BARU (baris "first" = rekod paling lama, bukan yang baru
        # dikemaskini) -- dan nota: baris K pun ber-desc "P, ..." jadi
        # fallback ni lemah utk K, sebab tu laluan nombor diutamakan. <<<
        self._pastikan_di_senarai(senarai_page)
        dibuka = False
        no_baru = getattr(self, "no_rekod_baharu", None)
        if no_baru:
            print(f"  [KEMASKINI] verify_updated: cari ikut nombor baharu "
                  f"{no_baru}...")
            dibuka = senarai_page.open_record_by_number(no_baru)
        if not dibuka:
            try:
                senarai_page.open_record_by_jenis(jenis_letter, which="last")
                dibuka = True
            except TimeoutException:
                print("  [KEMASKINI] verify_updated: row not found on first "
                      "look -- dismiss alert + dump + refresh + retry")
                self.dismiss_native_alerts(first_timeout=2,
                                           context="kemaskini verify_updated")
                self._dump("kemaskini_verify_row_not_found.xml")
                # >>> 2026-09-04: run verify (fix #1-5) buktikan SUBMIT
                # SEBENAR berjaya tapi retry locator sama MASIH gagal --
                # jadual yang discroll ialah render LAMA (ensure_records_
                # listed() "already listed" langkau filter tarikh). Tampal:
                # paksa senarai_page.refresh_list() sebelum retry. <<<
                senarai_page.refresh_list()
                if no_baru and senarai_page.open_record_by_number(no_baru):
                    dibuka = True
                else:
                    loc = (AppiumBy.ANDROID_UIAUTOMATOR,
                           'new UiSelector().className("android.view.ViewGroup")'
                           f'.descriptionMatches("^{jenis_letter.upper()},.*'
                           '\\d{4}-\\d{2}-\\d{2}.*")')
                    els = self.driver.find_elements(*loc)
                    if not els:
                        el = self.find_element(loc, timeout=20)
                        els = self.driver.find_elements(*loc) or [el]
                    el = els[-1]          # paling BARU (senarai LAMA->BARU)
                    desc = el.get_attribute("content-desc")
                    print(f"  [SENARAI] Opening record row (retry, last): "
                          f"{desc}")
                    self.tap_element(el)
                    time.sleep(2)
        assert self.is_element_present(self.POPUP_TITLE, timeout=10), \
            "record popup did not reopen for post-update verification"
        loc = (AppiumBy.ANDROID_UIAUTOMATOR,
               f'new UiSelector().textContains("{new_value}")')
        ok = self.is_element_present(loc, timeout=5)
        if not ok:
            path = self._dump("kemaskini_verify_failed.xml")
            # close the popup before failing so recovery is trivial
            try:
                el = self.find_element(self.POPUP_X, timeout=3)
                self.tap_element(el)
            except Exception:
                pass
            raise AssertionError(
                f"updated value {new_value!r} not displayed on the "
                f"record popup after kemaskini; see {path}")
        print(f"  [KEMASKINI] updated value {new_value!r} displayed — PASS")
        try:
            el = self.find_element(self.POPUP_X, timeout=3)
            self.tap_element(el)
        except Exception:
            pass

"""
Profil PBT — pemuat tetapan per-majlis dan per-environment.

KENAPA WUJUD
------------
APK ini dibina untuk banyak PBT, dan setiap PBT ada staging + production
sendiri. Nilai yang berbeza antara mereka (alamat server, lesen, akaun
login, nama pakej APK) dahulunya bertaburan sebagai pemalar hardcoded
dalam config.py dan testdata/excel_data.py — bermakna menguji PBT kedua
memerlukan seseorang mengedit fail Python, iaitu perkara yang suite ini
sengaja elakkan sejak Fasa 0.

Sekarang setiap gabungan PBT×environment ialah SATU fail JSON dalam
profiles/. Tambah PBT baharu = tambah satu fail. Tiada kod berubah.

CARA PROFIL DIPILIH (ikut keutamaan)
-------------------------------------
  1. Pembolehubah persekitaran MBIP_PROFILE (contoh: mbip-production)
     -- digunakan oleh menu dalam run_and_report.bat, dan oleh sesiapa
     yang mahu automasi tanpa menu.
  2. Jika hanya SATU profil wujud, ia digunakan terus tanpa soal.
  3. Selain itu: ralat yang menyenaraikan pilihan yang ada.

Tiada nilai default yang diam-diam dipilih apabila ada lebih daripada
satu profil. Menjalankan ujian terhadap server production sedangkan
staging yang dimaksudkan adalah kesilapan yang mahal, jadi ketaksaan
mesti berhenti serta-merta, bukan diteka.
"""

import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))
PROFILES_DIR = os.path.join(HERE, "profiles")

# Medan yang mesti ada nilai sebenar sebelum sebarang ujian dijalankan.
REQUIRED = [
    "pbt", "env", "app_package", "internal_ip", "external_ip",
    "lesen_aplikasi", "username", "password",
]

# Penanda dalam fail templat yang bermaksud "belum diisi".
PLACEHOLDER = "ISI-SINI"


class ProfileError(RuntimeError):
    """Profil tiada, tak sah, atau taksa — mesej menerangkan tindakan."""


def available():
    """Nama semua profil yang ada, mengikut abjad."""
    if not os.path.isdir(PROFILES_DIR):
        return []
    return sorted(
        os.path.splitext(f)[0]
        for f in os.listdir(PROFILES_DIR)
        if f.endswith(".json")
    )


def _load_file(name):
    path = os.path.join(PROFILES_DIR, f"{name}.json")
    if not os.path.isfile(path):
        raise ProfileError(
            f"Profil '{name}' tidak wujud.\n"
            f"  Profil yang ada: {', '.join(available()) or '(tiada)'}"
        )
    try:
        with open(path, encoding="utf-8") as fh:
            data = json.load(fh)
    except json.JSONDecodeError as e:
        raise ProfileError(
            f"Profil '{name}' rosak (bukan JSON sah): {e}\n"
            f"  Fail: {path}"
        )
    data["_name"] = name
    data["_path"] = path
    return data


def _validate(p):
    """Tolak profil yang belum lengkap, dengan menamakan medan yang kosong.

    Sengaja gagal awal: kalau internal_ip masih 'ISI-SINI', ujian akan
    tetap berjalan selama dua jam sebelum gagal dengan sebab yang
    mengelirukan.
    """
    kosong = [k for k in REQUIRED
              if not str(p.get(k, "")).strip()
              or str(p.get(k)).strip() == PLACEHOLDER]
    if kosong:
        raise ProfileError(
            f"Profil '{p['_name']}' belum lengkap.\n"
            f"  Medan yang belum diisi: {', '.join(kosong)}\n"
            f"  Isi nilai sebenar dalam: {p['_path']}"
        )
    return p


def resolve_name():
    """Nama profil yang patut digunakan — lihat docstring modul."""
    env = os.environ.get("MBIP_PROFILE", "").strip()
    if env:
        return env

    names = available()
    if not names:
        raise ProfileError(
            "Tiada profil dijumpai dalam profiles/.\n"
            "  Setiap PBT×environment perlukan satu fail JSON di situ."
        )
    if len(names) == 1:
        return names[0]

    senarai = "\n".join(f"    set MBIP_PROFILE={n}" for n in names)
    raise ProfileError(
        "Lebih daripada satu profil wujud — pilih satu secara jelas.\n"
        "  Menjalankan ujian terhadap PBT atau environment yang salah "
        "boleh merosakkan data sebenar, jadi tiada yang dipilih "
        "automatik.\n"
        "  Pilih dengan salah satu daripada:\n" + senarai + "\n"
        "  Atau jalankan tests\\run_and_report.bat dan pilih dari menu."
    )


_CACHE = {}


def load(name=None):
    """Profil aktif sebagai dict. Di-cache untuk satu proses."""
    name = name or resolve_name()
    if name not in _CACHE:
        _CACHE[name] = _validate(_load_file(name))
    return _CACHE[name]


def label(p=None):
    """Label mesra manusia, contoh: 'MBIP — production'."""
    p = p or load()
    return f"{p.get('pbt', '?')} — {p.get('env', '?')}"


def describe(p=None):
    """Ringkasan satu blok untuk dicetak pada permulaan run."""
    p = p or load()
    return (
        f"  Profil    : {p['_name']}  ({label(p)})\n"
        f"  Server    : {p['internal_ip']} / {p['external_ip']}\n"
        f"  Pakej APK : {p['app_package']}\n"
        f"  Akaun     : {p['username']}"
    )


if __name__ == "__main__":
    import sys
    if "--list" in sys.argv:
        # Digunakan oleh menu dalam run_and_report.bat.
        for n in available():
            try:
                p = _load_file(n)
                siap = "" if not [
                    k for k in REQUIRED
                    if not str(p.get(k, "")).strip()
                    or str(p.get(k)).strip() == PLACEHOLDER
                ] else "  [BELUM LENGKAP]"
                print(f"{n}|{p.get('pbt','?')} — {p.get('env','?')}{siap}")
            except ProfileError:
                print(f"{n}|(rosak)")
        sys.exit(0)
    try:
        print(describe())
    except ProfileError as e:
        print(e)
        sys.exit(1)

"""
LOG REKOD SEBENAR — arahan pemilik 2026-08-17, bahagian 3.4.

    reports/REKOD-SEBENAR-DICIPTA-<tarikh>.md

Ini fail yang PM gunakan untuk memadam. Dua sifat yang menjadikannya
berguna, dan kedua-duanya adalah keputusan reka bentuk dan bukan
kebetulan:

1.  DITULIS SERTA-MERTA, bukan pada akhir larian.
    Arahan pemilik menyebut ini secara eksplisit. Sebabnya sudah
    berlaku sekali dalam projek ini: pada 2026-08-13 satu proses dibunuh
    had-masa alat semasa mengisi borang, SELEPAS nombor siri 005
    diperuntukkan. Nombor itu hilang daripada setiap log dan hanya
    ditemui kemudian dengan membaca DB peranti. Log yang ditulis pada
    akhir larian ialah log yang tiada apabila ia paling diperlukan.
    Setiap baris di-`flush()` dan di-`fsync()`.

2.  SATU KITARAN BOLEH JANA LEBIH DARIPADA SATU REKOD.
    Arahan pemilik: cipta -> NK convert = rekod ke-2 -> Kemaskini =
    rekod ke-3 gantian. `log_rekod()` dipanggil sekali bagi SETIAP
    nombor, dengan `jenis` dan `asal` yang menerangkan dari mana ia
    datang. Tiada panggilan 'kemas kini baris sebelumnya' — baris lama
    kekal, kerana nombor lama itu WUJUD pada production walaupun
    statusnya kemudian bertukar kepada dibatalkan.

Nombor yang GAGAL ditangkap turut dilog, dengan `no_rekod=None` dan
sebab. Jurang dalam penomboran rasmi ialah dapatan (D-07), bukan
sesuatu untuk disembunyikan.
"""

import datetime
import json
import os

AKAR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DIR_REPORTS = os.path.join(AKAR, "reports")

TAJUK = "# REKOD SEBENAR DICIPTA — production MBIP"

LAJUR = ("No. rekod", "TC", "Borang", "Masa", "Jenis", "Status", "Asal")

MUKADIMAH = """
> Setiap nombor di bawah ialah rekod **HIDUP** pada production MBIP
> (113.211.155.174). Ia dicipta oleh automasi ujian di bawah
> `MBIP_MOD_SEBENAR=1`, atas kelulusan pemilik 2026-08-17.
>
> **Untuk PM:** semua rekod ini data ujian. Nama pesalah bermula dengan
> `UJIAN AUTOMASI E2E`, dan medan catatan membawa `AUTOMASI-CLEANUP-PM`.
> Pembatalan melalui portal ePBT oleh pihak berautoriti — automasi
> TIDAK memadam apa-apa.
>
> Satu kitaran boleh menjana LEBIH DARIPADA SATU nombor (cipta -> NK
> convert -> kemaskini). Baris lama TIDAK dipadam apabila rekod
> digantikan: nombor itu tetap wujud pada production.
"""


def laluan_log(tarikh=None):
    t = tarikh or datetime.date.today().isoformat()
    return os.path.join(DIR_REPORTS, f"REKOD-SEBENAR-DICIPTA-{t}.md")


def _pastikan_kepala(laluan):
    if os.path.exists(laluan) and os.path.getsize(laluan) > 0:
        return
    os.makedirs(os.path.dirname(laluan), exist_ok=True)
    with open(laluan, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(f"{TAJUK}\n{MUKADIMAH}\n")
        fh.write("| " + " | ".join(LAJUR) + " |\n")
        fh.write("|" + "|".join(["---"] * len(LAJUR)) + "|\n")
        fh.flush()
        os.fsync(fh.fileno())


def _sel(nilai):
    """Selamatkan satu nilai untuk sel jadual markdown."""
    t = "-" if nilai in (None, "") else str(nilai)
    return t.replace("|", "\\|").replace("\n", " ")


def log_rekod(no_rekod, tc, borang, jenis, status, asal="", masa=None,
              tarikh=None, nota=""):
    """Tulis SATU baris, serta-merta.

    no_rekod  nombor rasmi (PGP02...), atau None kalau tidak tertangkap
    tc        TC yang menghasilkannya, cth 'N-001'
    borang    'N' | 'P' | 'K'
    jenis     'Notis' | 'Kompaun'
    status    'baru' | 'hasil-kemaskini' | 'hasil-NK-convert' | ...
    asal      nombor rekod yang digantikan/ditukar, kalau ada
    nota      apa-apa yang pembaca perlu tahu (cth sebab None)

    Memulangkan laluan fail supaya pemanggil boleh melaporkannya.
    """
    laluan = laluan_log(tarikh)
    _pastikan_kepala(laluan)
    cap = masa or datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    sel_rekod = f"`{no_rekod}`" if no_rekod else "**(TIDAK TERTANGKAP)**"
    baris = "| " + " | ".join([
        sel_rekod, _sel(tc), _sel(borang), _sel(cap), _sel(jenis),
        _sel(status), _sel(asal or nota),
    ]) + " |"
    with open(laluan, "a", encoding="utf-8", newline="\n") as fh:
        fh.write(baris + "\n")
        fh.flush()
        os.fsync(fh.fileno())

    # Salinan mesin-boleh-baca. Jadual markdown untuk PM; JSONL untuk
    # kami, kerana menghuraikan semula markdown untuk mengira apa yang
    # dicipta ialah cara mudah untuk tersilap kira.
    jsonl = os.path.join(DIR_REPORTS, "REKOD-SEBENAR.jsonl")
    with open(jsonl, "a", encoding="utf-8") as fh:
        fh.write(json.dumps({
            "no_rekod": no_rekod, "tc": tc, "borang": borang,
            "masa": cap, "jenis": jenis, "status": status,
            "asal": asal, "nota": nota,
        }, ensure_ascii=False) + "\n")
        fh.flush()
        os.fsync(fh.fileno())
    return laluan


def _hhmmss(saat):
    saat = int(max(0, saat))
    return f"{saat // 3600:02d}:{(saat % 3600) // 60:02d}:{saat % 60:02d}"


def tulis_jadual_masa(jejak, mula_sesi, tamat_sesi, tarikh=None):
    """Jadual masa gabungan untuk SEMUA borang dalam satu sesi.

    Arahan pemilik 2026-08-17 (Prompt 8 #6): timestamp mula/setiap
    peringkat/tamat untuk SETIAP borang berasingan, PLUS jumlah masa
    keseluruhan sesi.

    Ditulis pada AKHIR sesi dan bukan setiap peringkat — tidak seperti
    nombor rekod, masa bukan sesuatu yang hilang secara kekal kalau
    proses mati. `jejak` sudah membawa cap masa setiap peringkat, jadi
    kalau sesi terbunuh, jadual ini boleh dibina semula daripada
    keluaran terminal.
    """
    if not jejak:
        return None
    laluan = laluan_log(tarikh)
    _pastikan_kepala(laluan)

    ikut_borang = {}
    for j in jejak:
        ikut_borang.setdefault(j.get("tag", "?"), []).append(j)

    baris = ["", "## Jadual masa sesi", "",
             "| Borang | Peringkat | Mula | Tamat | Tempoh | Status |",
             "|---|---|---|---|---|---|"]
    for tag, langkah in ikut_borang.items():
        for j in langkah:
            baris.append(
                f"| {_sel(tag)} | {_sel(j.get('peringkat'))} "
                f"| {_sel(j.get('mula'))} | {_sel(j.get('tamat'))} "
                f"| {_sel(_hhmmss(j.get('tempoh_s') or 0))} "
                f"| {_sel(j.get('status'))} |")
        awal = langkah[0].get("mula") or "-"
        akhir = langkah[-1].get("tamat") or "-"
        jum = sum(j.get("tempoh_s") or 0 for j in langkah)
        baris.append(f"| **{_sel(tag)}** | **JUMLAH BORANG** | {_sel(awal)} "
                     f"| {_sel(akhir)} | **{_hhmmss(jum)}** | |")

    baris += [
        "",
        f"**Sesi bermula:** {mula_sesi}  ",
        f"**Sesi tamat:** {tamat_sesi}  ",
        f"**Jumlah masa sesi:** {_hhmmss(_delta(mula_sesi, tamat_sesi))}",
        "",
        "> Jumlah masa sesi diukur dari command pertama sampai borang",
        "> terakhir habis, jadi ia termasuk masa antara borang (relaunch",
        "> app, login semula) yang tidak dikira dalam mana-mana peringkat.",
        "",
    ]
    with open(laluan, "a", encoding="utf-8", newline="\n") as fh:
        fh.write("\n".join(baris) + "\n")
        fh.flush()
        os.fsync(fh.fileno())
    return laluan


def _delta(mula, tamat):
    try:
        a = datetime.datetime.strptime(mula, "%Y-%m-%d %H:%M:%S")
        b = datetime.datetime.strptime(tamat, "%Y-%m-%d %H:%M:%S")
        return (b - a).total_seconds()
    except (ValueError, TypeError):
        return 0


def baca_semua(tarikh=None):
    """Setiap baris JSONL untuk tarikh berkenaan — untuk ringkasan
    akhir larian dan untuk laporan."""
    jsonl = os.path.join(DIR_REPORTS, "REKOD-SEBENAR.jsonl")
    if not os.path.exists(jsonl):
        return []
    keluar = []
    with open(jsonl, encoding="utf-8") as fh:
        for baris in fh:
            baris = baris.strip()
            if not baris:
                continue
            try:
                d = json.loads(baris)
            except ValueError:
                continue
            if tarikh and not str(d.get("masa", "")).startswith(tarikh):
                continue
            keluar.append(d)
    return keluar

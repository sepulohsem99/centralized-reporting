"""Utiliti DB peranti MBIP — tarik salinan baca-sahaja DB app.

Diport dari MBPG devtools/smoke_tangga.tarik_db (terbukti pada belasan
run sebenar). `exec-out run-as cat` kerana adb pull tidak boleh membaca
direktori peribadi app.
"""
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
AKAR = os.path.dirname(HERE)
sys.path.insert(0, AKAR)

from config import APP_PACKAGE                              # noqa: E402

DB_DEV = f"/data/data/{APP_PACKAGE}/files/SQLite/e_kompaunV1.db"


def tarik_db(serial, ke):
    """Salin DB tempatan app ke fail lokal. BACA-SAHAJA."""
    os.makedirs(os.path.dirname(ke), exist_ok=True)
    with open(ke, "wb") as fh:
        p = subprocess.run(
            ["adb", "-s", serial, "exec-out",
             f"run-as {APP_PACKAGE} cat {DB_DEV}"],
            stdout=fh, stderr=subprocess.PIPE)
    if p.returncode != 0 or os.path.getsize(ke) == 0:
        raise RuntimeError(
            "tidak dapat menarik DB: "
            + p.stderr.decode(errors="replace")[:200])
    return ke

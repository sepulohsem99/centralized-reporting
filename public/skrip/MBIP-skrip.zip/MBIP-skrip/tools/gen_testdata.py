"""
Jana testdata/pbt/<pbt>.py daripada Excel setiap PBT.

KENAPA
------
Data ujian berbeza antara PBT kerana setiap majlis hanya ada jalan dan
taman kawasannya sendiri dalam pangkalan data. Menaip semula 47 TC untuk
setiap PBT tidak boleh diskalakan.

TIDAK MENGGANTI DATA MBIP
-------------------------
testdata/excel_data.py dibina tangan, sudah terbukti pada peranti sebenar
melalui berpuluh run. Ia KEKAL sebagai sumber untuk MBIP. Penjana ini
menulis fail berasingan untuk PBT lain, dan output MBIP-nya digunakan
semata-mata untuk pengesahan — kalau penjana boleh menghasilkan semula
data yang sudah terbukti, barulah outputnya untuk PBT lain boleh
dipercayai.

GUNA
    python tools/gen_testdata.py --check          # bandingkan vs MBIP
    python tools/gen_testdata.py --write          # tulis semua PBT lain
"""

import argparse
import glob
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
sys.path.insert(0, ROOT)

from parse_testdata import parse, apply_inheritance      # noqa: E402

OUT_DIR = os.path.join(ROOT, "testdata", "pbt")
DEFAULT_SHARED = os.environ.get(
    "MBIP_SHARED_DIR",
    r"C:\Users\mrsai\Desktop\IES Dev 2.0 Shared Folder-local desktop")

# Jenis kompaun -> awalan medan alamat kesalahan yang digunakan lapisan
# pages. Notis Amaran memakai "notis_", selebihnya "kompaun_".
PREFIX = {"N": "notis_", "P": "kompaun_", "K": "kompaun_",
          "L": "kompaun_", "S": "kompaun_"}

# Jenis yang memakai "no_kp_ssm" (bukan "no_kp_ssm_kereta") kerana
# borangnya melabelkan medan itu berbeza.
KP_SSM_ONLY = {"L", "S"}


def version_key(name):
    m = re.findall(r"(\d+)\.(\d+)\.(\d+)", os.path.basename(name))
    return tuple(map(int, m[0])) if m else (0, 0, 0)


def latest_script(root, pbt):
    pat = os.path.join(root, f"*{pbt} Testing Report", "**", "*.xlsx")
    c = [f for f in glob.glob(pat, recursive=True)
         if "Testing Script" in os.path.basename(f)]
    return sorted(c, key=version_key)[-1] if c else None


def read_sheets(path):
    """{TC ternormal: (id penuh, huraian Test Data)}"""
    import openpyxl
    wb = openpyxl.load_workbook(path, data_only=True, read_only=True)
    out, names = {}, {}
    try:
        for sn in wb.sheetnames:
            s = sn.strip()
            if not re.match(r"^[A-Z]+-TC-", s):
                continue
            d = {}
            for r in wb[sn].iter_rows(min_row=1, max_row=18, max_col=3,
                                      values_only=True):
                if r and r[1]:
                    d[str(r[1]).strip().rstrip(":")] = r[2]
            key = re.sub(r"^[A-Z]+-TC-", "TC-", s)
            out[key] = parse(d.get("Test Data"))
            names[key] = (s, str(d.get("Test Case Description") or "").strip())
    finally:
        wb.close()
    return apply_inheritance(out), names


def _suggestion(sec):
    """Baris autocomplete yang dijangka untuk medan jalan.

    Aplikasi memaparkan cadangan sebagai "JALAN | TAMAN | BANDAR"
    (disahkan terhadap data MBIP yang dibina tangan), jadi ia boleh
    diterbitkan daripada tiga medan itu dan tidak perlu ditaip semula.
    """
    j, t, b = sec.get("jalan"), sec.get("taman"), sec.get("bandar")
    return f"{j} | {t} | {b}" if j and t and b else None


def build_tc(tc_id, parsed, parent=None):
    """Huraian ternormal -> dict TC_DATA dengan nama medan lapisan pages.

    `parent` ialah huraian TC '-001' jenis yang sama. TC Kemaskini dan
    Bookmark merujuk rekod yang dicipta oleh -001, jadi nilai yang tidak
    diulang dalam sheet mereka diambil dari situ — itulah juga cara
    excel_data.py yang dibina tangan melakukannya.
    """
    m = re.match(r"^TC-([A-Z]+)-(\d+)$", tc_id)
    if not m:
        return {}
    fam, num = m.group(1), m.group(2)

    # Gabung seksyen yang kosong daripada -001. apply_inheritance() hanya
    # mengisi TC yang KOSONG SEPENUHNYA; sheet Bookmark selalunya ada
    # sedikit data pesalah tetapi tiada kod kompaun, jadi ia terlepas.
    if parent and num in ("003", "004", "005"):
        parsed = {k: (dict(v) if isinstance(v, dict) else list(v))
                  for k, v in parsed.items() if not k.startswith("_")}
        for sec in ("pesalah", "kesalahan", "kompaun", "penerima"):
            for k, v in (parent.get(sec) or {}).items():
                parsed[sec].setdefault(k, v)
        if not parsed["barang"]:
            parsed["barang"] = list(parent.get("barang") or [])
    pes, kes, kom = parsed["pesalah"], parsed["kesalahan"], parsed["kompaun"]
    pen, barang = parsed["penerima"], parsed["barang"]
    d = {}

    # --- H: hanya perlu tahu jenis rekod yang hendak dihantar semula ---
    if fam == "H":
        idx = {"001": "N", "002": "P", "003": "K", "004": "L", "005": "S"}
        if num in idx:
            d["jenis_letter"] = idx[num]
        return d

    if fam in PREFIX:
        pre = PREFIX[fam]

        # --- Kemaskini (-004): borang edit memakai awalan "kesalahan_" ---
        if num == "004":
            d["jenis_letter"] = fam
            for k in ("jalan", "taman", "poskod", "bandar", "negeri"):
                if kes.get(k):
                    d[f"kesalahan_{k}"] = kes[k]
            for k in ("lokasi_kesalahan", "butiran_kesalahan"):
                if kes.get(k):
                    d[k] = kes[k]
            if kom.get("tempoh"):
                d["tempoh_notis"] = kom["tempoh"]
            for k in ("keterangan_kod_kompaun", "kod_akta",
                      "kesalahan_kompaun", "kadar_denda"):
                if kom.get(k):
                    d[k] = kom[k]
            # "old" = nilai yang PATUT sudah ada pada rekod sebelum
            # dikemas kini, iaitu apa yang -001 masukkan. Ujian mengesahkan
            # nilai lama ini dipaparkan sebelum menukarnya.
            if parent:
                old = {}
                # Trafik (K) dikecualikan: nama pesalahnya diisi oleh
                # carian MySIKAP, bukan ditaip, jadi ia bukan "nilai lama"
                # yang ujian patut sahkan telah dimasukkan sebelum ini.
                if fam != "K" and (parent.get("pesalah") or {}).get("nama"):
                    old["nama"] = parent["pesalah"]["nama"]
                if (parent.get("kesalahan") or {}).get("jalan"):
                    old["jalan"] = parent["kesalahan"]["jalan"]
                if old:
                    d["old"] = old
            return d

        # --- Daftar (-001), Serah (-003), Bookmark (-005) ---
        d["jenis_letter"] = fam
        if pes.get("nama"):
            d["nama_pesalah"] = pes["nama"]
        if pes.get("no_kp"):
            d["no_kp_ssm" if fam in KP_SSM_ONLY else "no_kp_ssm_kereta"] = \
                pes["no_kp"]
        for k in ("no_akuan_lesen", "no_kereta", "warna_kereta"):
            if pes.get(k):
                d[k] = pes[k]
        for k in ("jalan", "taman", "poskod", "bandar", "negeri"):
            if pes.get(k):
                d[k] = pes[k]

        if kes.get("jalan"):
            d[f"{pre}jalan_partial"] = kes["jalan"]
            sug = _suggestion(kes)
            if sug:
                d[f"{pre}jalan_suggestion"] = sug
        for k in ("taman", "poskod", "bandar", "negeri"):
            if kes.get(k):
                d[f"{pre}{k}"] = kes[k]
        for k in ("lokasi_kesalahan", "butiran_kesalahan"):
            if kes.get(k):
                d[k] = kes[k]

        if kom.get("tempoh"):
            d["tempoh_notis"] = kom["tempoh"]
        for k in ("keterangan_kod_kompaun", "kod_akta", "kesalahan_kompaun",
                  "kadar_denda"):
            if kom.get(k):
                d[k] = kom[k]

        if barang:
            d["barang"] = barang
        # Penerima biasanya sama dengan pesalah melainkan dinyatakan.
        d["nama_penerima"] = pen.get("nama_penerima") or pes.get("nama")
        d["no_ic_penerima"] = pen.get("no_ic_penerima") or pes.get("no_kp")
        d = {k: v for k, v in d.items() if v is not None}

        if num == "005":
            d["bookmark_name"] = f"V3 BOOKMARK {fam}"
        return d

    return d


def generate(pbt, root):
    path = latest_script(root, pbt)
    if not path:
        return None, None, None
    parsed, names = read_sheets(path)
    data = {}
    for tc in sorted(parsed):
        m = re.match(r'^(TC-[A-Z]+)-\d+$', tc)
        parent = parsed.get(f'{m.group(1)}-001') if m else None
        built = build_tc(tc, parsed[tc], parent)
        if built:
            data[tc] = built
    return data, names, os.path.basename(path)


def render_module(pbt, data, names, src):
    import datetime
    L = ['"""',
         f"Data ujian {pbt} — DIJANA AUTOMATIK. Jangan edit dengan tangan.",
         "",
         f"Sumber : {src}",
         f"Dijana : {datetime.datetime.now().isoformat(timespec='seconds')}",
         "         oleh tools/gen_testdata.py",
         "",
         "Untuk menjana semula selepas Excel dikemas kini:",
         "    python tools/gen_testdata.py --write",
         "",
         "Medan yang Excel tidak boleh bekalkan (akaun log masuk, nombor",
         "pembantu penguatkuasa, nombor plate yang hanya tersebut dalam Test",
         "Steps) tidak ada di sini — ia datang dari testdata/overrides.py.",
         '"""',
         "",
         "TC_DATA = {"]
    for tc in sorted(data):
        full = names.get(tc, (tc, ""))[0]
        # Huraian TC kadang mengandungi baris baharu; kalau dibiarkan ia
        # memecahkan komen dan baki teks menjadi kod yang tidak sah.
        desc = re.sub(r"\s+", " ", names.get(tc, ("", ""))[1]).strip()[:70]
        L.append(f'    # {full}  {desc}')
        L.append(f'    "{tc}": {{')
        for k, v in sorted(data[tc].items()):
            L.append(f"        {k!r}: {v!r},")
        L.append("    },")
    L.append("}")
    return "\n".join(L) + "\n"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--shared", default=DEFAULT_SHARED)
    ap.add_argument("--check", action="store_true",
                    help="bandingkan output MBIP dengan excel_data.py")
    ap.add_argument("--write", action="store_true",
                    help="tulis testdata/pbt/<pbt>.py")
    a = ap.parse_args()

    root = a.shared
    inner = os.path.join(root, "IES Dev 2.0 Shared Folder")
    if os.path.isdir(inner):
        root = inner

    pbts = sorted({re.sub(r"^\d+\.\s*", "", os.path.basename(d))
                   .replace(" Testing Report", "").strip()
                   for d in glob.glob(os.path.join(root, "*Testing Report"))})

    if a.check:
        from testdata.excel_data import TC_DATA as REF
        data, _, src = generate("MBIP", root)
        print(f"Bandingkan output penjana dengan excel_data.py  ({src})\n")
        same = diff = only_ref = 0
        rows = []
        for full, want in sorted(REF.items()):
            key = re.sub(r"^[A-Z]+-TC-", "TC-", full)
            got = data.get(key, {})
            if not isinstance(want, dict):
                continue
            for k, v in want.items():
                if k not in got:
                    only_ref += 1
                    rows.append((full, k, str(v)[:34], "(tiada)"))
                elif str(got[k]).strip().upper() != str(v).strip().upper():
                    diff += 1
                    rows.append((full, k, str(v)[:34], str(got[k])[:34]))
                else:
                    same += 1
        print(f"  padan {same} | berbeza {diff} | tiada dalam output {only_ref}")
        tot = same + diff + only_ref
        print(f"  ketepatan: {same/tot*100:.0f}%\n")
        for full, k, w, g in rows[:28]:
            print(f"  {full:<16} {k:<26} jangka={w!r}  dapat={g!r}")
        if len(rows) > 28:
            print(f"  ... {len(rows)-28} lagi")
        return

    if a.write:
        os.makedirs(OUT_DIR, exist_ok=True)
        init = os.path.join(OUT_DIR, "__init__.py")
        if not os.path.exists(init):
            open(init, "w").close()
        for pbt in pbts:
            if pbt.upper() == "DEMO":
                continue
            data, names, src = generate(pbt, root)
            if not data:
                print(f"  {pbt}: (tiada test script)")
                continue
            out = os.path.join(OUT_DIR, f"{pbt.lower()}.py")
            with open(out, "w", encoding="utf-8") as fh:
                fh.write(render_module(pbt, data, names, src))
            print(f"  {pbt}: {len(data)} TC -> {os.path.relpath(out, ROOT)}")
        return

    ap.print_help()


if __name__ == "__main__":
    main()

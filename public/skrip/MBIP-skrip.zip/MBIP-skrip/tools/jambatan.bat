@echo off
REM JAMBATAN PROMETHEUS - start SEKALI (double-click), biarkan window terbuka.
REM prometheus menulis ui_dumps\arahan.bat dari jauh; jambatan menjalankannya
REM dan menyimpan output ke ui_dumps\jambatan_log.txt untuk dibaca sendiri.
cd /d "%~dp0.."
echo [JAMBATAN] sedia di %CD%
echo [JAMBATAN] menunggu arahan dari prometheus...
:loop
if exist "ui_dumps\arahan.bat" (
  echo [JAMBATAN] arahan diterima:
  type "ui_dumps\arahan.bat"
  move /y "ui_dumps\arahan.bat" "ui_dumps\arahan_jalan.bat" >nul
  if exist "ui_dumps\arahan_siap.txt" del /q "ui_dumps\arahan_siap.txt"
  call "ui_dumps\arahan_jalan.bat" > "ui_dumps\jambatan_log.txt" 2>&1
  echo %ERRORLEVEL% > "ui_dumps\arahan_siap.txt"
  echo [JAMBATAN] siap - menunggu arahan seterusnya...
)
timeout /t 5 /nobreak >nul
goto loop

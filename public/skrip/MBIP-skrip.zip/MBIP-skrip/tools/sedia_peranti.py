#!/usr/bin/env python3
"""Sedia peranti MBIP sebelum run e2e: clear data + grant permission.

>>> DIPORT DARI MBPG-testing/tools/sedia_peranti.py (terbukti run 9-14
MBPG, 2026-08-20) — pakej app SAMA (com.anonymous.react_ies_v1), DB sama
(e_kompaunV1.db), maka logik identik. <<<

Menggantikan langkah manual CEO (long-press ikon -> App info -> Storage ->
Clear cache/storage -> Permissions -> Allow satu persatu) dengan laluan
adb rasmi yang deterministik:

    pm clear <pkg>              = Clear storage + Clear cache (satu langkah,
                                  kesan SAMA seperti butang App info)
    pm grant <pkg> <permission> = Allow. Untuk lokasi, grant FINE/COARSE
                                  = "Allow only while using the app"
                                  (background TIDAK diberi — itu permission
                                  berasingan yang sengaja TIDAK disentuh).

Kenapa bukan automasi UI App info: skrin Settings berbeza ikut vendor/
versi Android dan locator-nya rapuh; pm ialah API rasmi yang sama pada
setiap peranti. Hasil disahkan melalui dumpsys (granted=true), bukan
dipercayai membuta.

Guna:
    python tools\\sedia_peranti.py              # clear + grant + sahkan
    python tools\\sedia_peranti.py --tanpa-clear
    python tools\\sedia_peranti.py --tanpa-grant
    python tools\\sedia_peranti.py --semak      # sahkan sahaja, tiada tulis

Atau sebagai sebahagian run penuh:
    python tools\\run_penuh_mbip.py --bersih
"""
import argparse
import os
import re
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
AKAR = os.path.dirname(HERE)
sys.path.insert(0, AKAR)

from config import APP_PACKAGE, APP_ACTIVITY                    # noqa: E402

DB_DEV = f"/data/data/{APP_PACKAGE}/files/SQLite/e_kompaunV1.db"

# Kategori skrin Permissions CEO -> permission Android sebenar.
# Hanya yang DIMINTA oleh app akan digrant (semak dumpsys dahulu) —
# pm grant pada permission yang tidak diminta akan gagal.
KATEGORI = [
    ("Location",          ["android.permission.ACCESS_FINE_LOCATION",
                           "android.permission.ACCESS_COARSE_LOCATION"]),
    ("Nearby devices",    ["android.permission.BLUETOOTH_CONNECT",
                           "android.permission.BLUETOOTH_SCAN"]),
    ("Camera",            ["android.permission.CAMERA"]),
    ("Microphone",        ["android.permission.RECORD_AUDIO"]),
    ("Music and audio",   ["android.permission.READ_MEDIA_AUDIO"]),
    ("Phone",             ["android.permission.READ_PHONE_STATE"]),
    ("Photos and videos", ["android.permission.READ_MEDIA_IMAGES",
                           "android.permission.READ_MEDIA_VIDEO"]),
    # Android 13+: tanpa ini, notifikasi app disekat senyap.
    ("Notifications",     ["android.permission.POST_NOTIFICATIONS"]),
    # Warisan Android lama (kalau app minta, grant juga):
    ("Storage (lama)",    ["android.permission.READ_EXTERNAL_STORAGE",
                           "android.permission.WRITE_EXTERNAL_STORAGE"]),
]


def adb(serial, *hujah, semak=False):
    cmd = ["adb", "-s", serial] + list(hujah)
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
    if semak and r.returncode != 0:
        raise RuntimeError(f"{' '.join(cmd)} -> {r.returncode}: "
                           f"{(r.stderr or r.stdout).strip()[:200]}")
    return (r.stdout or "") + (r.stderr or "")


def serial_peranti():
    out = subprocess.run(["adb", "devices"], capture_output=True,
                         text=True, timeout=30).stdout
    baris = [l.split()[0] for l in out.splitlines()[1:]
             if l.strip() and "\tdevice" in l]
    if not baris:
        raise SystemExit("HENTI: tiada peranti adb (semak USB / "
                         "'adb reconnect offline').")
    if len(baris) > 1:
        print(f"  [PERANTI] {len(baris)} peranti — guna yang pertama.")
    return baris[0]


def diminta(serial):
    """Set permission yang app MINTA (dari dumpsys package)."""
    out = adb(serial, "shell", "dumpsys", "package", APP_PACKAGE)
    m = re.search(r"requested permissions:\s*(.*?)(?:\n\s*\n|install permissions:)",
                  out, re.S)
    blok = m.group(1) if m else out
    return set(re.findall(r"(android\.permission\.[A-Z_0-9]+)", blok))


def granted_kini(serial):
    """{permission: True/False} untuk permission runtime app ini."""
    out = adb(serial, "shell", "dumpsys", "package", APP_PACKAGE)
    hasil = {}
    for p, g in re.findall(
            r"(android\.permission\.[A-Z_0-9]+):\s*granted=(true|false)",
            out):
        hasil[p] = (g == "true")
    return hasil


def clear_data(serial):
    print(f"  [BERSIH] pm clear {APP_PACKAGE} (= Clear storage + cache)...")
    out = adb(serial, "shell", "pm", "clear", APP_PACKAGE)
    if "Success" not in out:
        raise RuntimeError(f"pm clear GAGAL: {out.strip()[:200]}")
    print("  [BERSIH] Success — data + cache dipadam.")


def grant_semua(serial):
    minta = diminta(serial)
    sedia = granted_kini(serial)
    keputusan = []
    for nama, perms in KATEGORI:
        for p in perms:
            if p not in minta:
                continue          # app tidak minta — jangan sentuh
            if sedia.get(p) is True:
                keputusan.append((nama, p, "SUDAH"))
                continue
            out = adb(serial, "shell", "pm", "grant", APP_PACKAGE, p)
            ralat = out.strip()
            keputusan.append((nama, p, "DIGRANT" if not ralat else
                              f"GAGAL: {ralat[:80]}"))
    return keputusan


def sahkan(serial):
    """Senarai (kategori, permission, granted?) untuk yang diminta app."""
    minta = diminta(serial)
    sedia = granted_kini(serial)
    baris = []
    for nama, perms in KATEGORI:
        for p in perms:
            if p in minta:
                baris.append((nama, p, sedia.get(p)))
    return baris


def lancar_dan_tunggu_db(serial, timeout_s=90):
    """Lancarkan app dan TUNGGU sehingga DB SQLite wujud.

    >>> PUNCA RUN 5 (2026-08-20) — DIBAIKI. <<<
    `pm clear` memadam SELURUH data app termasuk e_kompaunV1.db. DB itu
    dicipta semula oleh APP pada boot pertama — bukan oleh adb. Run 5
    mati di peringkat_1 dengan `sqlite3.DatabaseError: file is not a
    database` kerana ia menarik DB yang belum wujud. Maka: lancar app,
    poll sehingga fail DB muncul, beri masa tambahan untuk skema siap.
    """
    import time as _t
    print("  [BERSIH] melancarkan app supaya DB dicipta semula...")
    adb(serial, "shell", "am", "start", "-n",
        f"{APP_PACKAGE}/{APP_ACTIVITY}")
    tamat = _t.time() + timeout_s
    while _t.time() < tamat:
        out = adb(serial, "shell", "run-as", APP_PACKAGE, "ls",
                  f"/data/data/{APP_PACKAGE}/files/SQLite")
        if "e_kompaunV1.db" in out:
            _t.sleep(5)   # beri masa skema/jadual siap ditulis
            # sahkan boleh dibaca sebagai sqlite (header 'SQLite format 3')
            kepala = adb(serial, "exec-out", "run-as", APP_PACKAGE,
                         "sh", "-c", f"head -c 16 {DB_DEV}")
            if "SQLite" in kepala:
                print("  [BERSIH] DB dicipta + disahkan sqlite — sedia.")
                return True
        _t.sleep(3)
    raise RuntimeError(
        f"DB app tidak muncul dalam {timeout_s}s selepas lancar — buka "
        f"app secara manual sekali kemudian ulang run.")


def sedia(serial=None, clear=True, grant=True):
    """API untuk run_penuh (--bersih). Pulangkan (ok, ringkasan)."""
    serial = serial or serial_peranti()
    if clear:
        clear_data(serial)
    if grant:
        for nama, p, status in grant_semua(serial):
            print(f"  [PERMIT] {nama:<18} {p.split('.')[-1]:<24} {status}")
    if clear:
        lancar_dan_tunggu_db(serial)
    semakan = sahkan(serial)
    gagal = [(n, p) for n, p, g in semakan if g is not True]
    ok = not gagal
    ringkas = (f"{len(semakan) - len(gagal)}/{len(semakan)} permission "
               f"granted" + ("" if ok else f"; GAGAL: "
               f"{[p.split('.')[-1] for _, p in gagal]}"))
    print(f"  [SEDIA] {ringkas}")
    return ok, ringkas


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tanpa-clear", action="store_true")
    ap.add_argument("--tanpa-grant", action="store_true")
    ap.add_argument("--semak", action="store_true",
                    help="sahkan sahaja — tiada clear, tiada grant")
    a = ap.parse_args()
    serial = serial_peranti()
    print(f"  [PERANTI] {serial} · pakej {APP_PACKAGE}")
    if a.semak:
        for nama, p, g in sahkan(serial):
            print(f"  {'OK ' if g else '!! '}{nama:<18} "
                  f"{p.split('.')[-1]:<24} granted={g}")
        return 0
    ok, _ = sedia(serial, clear=not a.tanpa_clear,
                  grant=not a.tanpa_grant)
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())

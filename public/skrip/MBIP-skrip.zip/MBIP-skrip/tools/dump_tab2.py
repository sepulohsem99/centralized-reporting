#!/usr/bin/env python3
"""DUMP TAB-2 TRAFIK — bukti medan alamat/BANDAR pada build hotfix.

>>> DIBINA 2026-08-27 selepas rerun #3 K-001: app menolak Seterusnya
tab-2 dengan 'SILA PILIH BANDAR DARIPADA SENARAI.' — bermakna medan
BANDAR WUJUD dan WAJIB, tetapi _ci_label_locator('Maklumat Jalan')
timeout (AssertionError). Tool ini buka semula draf trafik (no_reset),
dump XML keadaan rehat, kemudian traversal TAB/DPAD untuk paksa render
medan bawah fold, dump lagi, dan senaraikan SEMUA text/hint/desc.
TIADA HANTAR, TIADA perubahan data — baca sahaja. <<<

Guna:
    python tools\\dump_tab2.py --profil mbip-production
"""
import argparse
import os
import re
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
AKAR = os.path.dirname(HERE)
sys.path.insert(0, AKAR)
os.chdir(AKAR)


class _Tee:
    def __init__(self, *aliran):
        self.aliran = aliran

    def write(self, s):
        for a in self.aliran:
            try:
                a.write(s)
                a.flush()
            except Exception:                                # noqa: BLE001
                pass

    def flush(self):
        for a in self.aliran:
            try:
                a.flush()
            except Exception:                                # noqa: BLE001
                pass


def _cerna(xml):
    """Pulangkan set (jenis, nilai) menarik dari page_source."""
    hasil = set()
    for attr in ("text", "content-desc", "hint"):
        for m in re.finditer(rf'{attr}="([^"]+)"', xml):
            v = m.group(1).strip()
            if v and len(v) < 120:
                hasil.add((attr, v))
    return hasil


def main(argv=None):
    os.makedirs("ui_dumps", exist_ok=True)
    _log = open(os.path.join("ui_dumps", "pilih_log.txt"), "w",
                encoding="utf-8", errors="replace")
    sys.stdout = _Tee(sys.__stdout__, _log)
    sys.stderr = _Tee(sys.__stderr__, _log)
    ap = argparse.ArgumentParser()
    ap.add_argument("--profil", default="mbip-production")
    args = ap.parse_args(argv)
    os.environ["MBIP_PROFILE"] = args.profil

    from appium import webdriver
    from appium.options.android import UiAutomator2Options
    from appium.webdriver.common.appiumby import AppiumBy
    from config import (APPIUM_URL, APP_PACKAGE, APP_ACTIVITY, DEVICE_NAME,
                        PLATFORM_NAME, AUTOMATION_NAME, IMPLICIT_WAIT,
                        USERNAME, PASSWORD)
    from device_utils import resolve_udid
    from pages.login_page import LoginPage
    from pages.home_page import HomePage
    from pages.daftar_kompaun_page import DaftarKompaunPage
    from testdata.excel_data import TC_DATA
    from testdata.trafik_v2 import TRAFIK_V2

    udid = resolve_udid(APP_PACKAGE)
    options = UiAutomator2Options()
    options.device_name = DEVICE_NAME
    options.set_capability("udid", udid)
    options.platform_name = PLATFORM_NAME
    options.app_package = APP_PACKAGE
    options.app_activity = APP_ACTIVITY
    options.no_reset = True
    options.full_reset = False
    options.automation_name = AUTOMATION_NAME
    options.set_capability("disableAndroidWatchers", True)
    driver = webdriver.Remote(APPIUM_URL, options=options)
    driver.implicitly_wait(IMPLICIT_WAIT)

    try:
        login = LoginPage(driver)
        home = HomePage(driver)
        daftar = DaftarKompaunPage(driver)

        login._force_relaunch_to_login()
        login.login(USERNAME, PASSWORD)
        home.open_daftar_kompaun()
        daftar.select_jenis_kompaun_trafik()
        time.sleep(2)

        # Tutup modal tertinggal (cth. 'LENGKAPKAN TAB PESALAH DAHULU')
        ok_loc = (AppiumBy.ANDROID_UIAUTOMATOR,
                  'new UiSelector().text("OK")')
        if daftar.is_element_present(ok_loc, timeout=2):
            daftar.tap_element(driver.find_element(*ok_loc))
            time.sleep(1)

        data = dict(TC_DATA["MBIP-TC-K-001"])
        data.update(TRAFIK_V2)

        # Draf sepatutnya buka terus di tab-2 (tier terisi) — kalau
        # tidak (run #4: draf dibuang oleh recovery), isi pesalah dulu
        # dengan laluan terbukti dan tekan Seterusnya.
        _tab2 = any(daftar.is_element_present(
            (AppiumBy.ANDROID_UIAUTOMATOR,
             f'new UiSelector().textContains("{t}")'), timeout=4)
            for t in ("KETERANGAN KOD KOMPAUN", "PILIH AKTA",
                      "MAKLUMAT KOMPAUN"))
        if not _tab2:
            print("[TAB2] draf TIDAK dikesan — isi tab Pesalah dahulu "
                  "(laluan terbukti run #3)...")
            daftar.fill_pesalah_tab_trafik_v2(data)
            daftar.click_seterusnya_from_pesalah()
            time.sleep(2)
            login.dismiss_native_alerts(first_timeout=2,
                                        context="dump-tab2")

        semua = set()

        xml = driver.page_source
        with open(os.path.join("ui_dumps", "trafik_tab2_rehat.xml"),
                  "w", encoding="utf-8") as f:
            f.write(xml)
        semua |= _cerna(xml)
        print(f"[TAB2] dump rehat -> trafik_tab2_rehat.xml "
              f"({len(xml):,} aksara)")

        # Cuba skrol biasa dahulu (tab-2 mungkin scrollable walaupun
        # pesalah tidak) — 3 leret, dump selepas setiap satu.
        saiz = driver.get_window_size()
        for i in range(3):
            driver.swipe(saiz["width"] // 2, int(saiz["height"] * 0.75),
                         saiz["width"] // 2, int(saiz["height"] * 0.30),
                         600)
            time.sleep(1.2)
            xml = driver.page_source
            baru = _cerna(xml) - semua
            semua |= baru
            if baru:
                print(f"[TAB2] leret #{i + 1}: {len(baru)} item BARU:")
                for jenis, v in sorted(baru):
                    print(f"          {jenis:12s} {v!r}")
        with open(os.path.join("ui_dumps", "trafik_tab2_leret.xml"),
                  "w", encoding="utf-8") as f:
            f.write(xml)

        # Traversal fokus TAB (keycode 61) — paksa RN render/skrol ke
        # medan bawah fold walaupun borang "tidak boleh skrol".
        for i in range(18):
            driver.press_keycode(61)
            time.sleep(0.6)
            if i % 3 == 2:
                xml = driver.page_source
                baru = _cerna(xml) - semua
                semua |= baru
                if baru:
                    print(f"[TAB2] TAB x{i + 1}: {len(baru)} item BARU:")
                    for jenis, v in sorted(baru):
                        print(f"          {jenis:12s} {v!r}")
        xml = driver.page_source
        with open(os.path.join("ui_dumps", "trafik_tab2_bawah2.xml"),
                  "w", encoding="utf-8") as f:
            f.write(xml)
        print("[TAB2] dump akhir -> trafik_tab2_bawah2.xml")

        # ---- FASA 2: isi tier (laluan sebenar) dan dump SEMULA ----
        # Blok alamat mungkin render DINAMIK selepas tier/kesalahan
        # dipilih — keadaan tepat di mana run #3 kena tolak BANDAR.
        try:
            print("\n[TAB2] fasa 2: isi tier sebenar kemudian dump "
                  "semula...")
            daftar.fill_kompaun_code_fields_trafik_v2(data)
            time.sleep(2)
            xml = driver.page_source
            with open(os.path.join("ui_dumps",
                                   "trafik_tab2_selepas_tier.xml"),
                      "w", encoding="utf-8") as f:
                f.write(xml)
            baru = _cerna(xml) - semua
            semua |= baru
            print(f"[TAB2] selepas tier: {len(baru)} item BARU:")
            for jenis, v in sorted(baru):
                print(f"          {jenis:12s} {v!r}")
            for i in range(18):
                driver.press_keycode(61)
                time.sleep(0.6)
                if i % 3 == 2:
                    xml = driver.page_source
                    baru = _cerna(xml) - semua
                    semua |= baru
                    if baru:
                        print(f"[TAB2] fasa2 TAB x{i + 1}: "
                              f"{len(baru)} item BARU:")
                        for jenis, v in sorted(baru):
                            print(f"          {jenis:12s} {v!r}")
            xml = driver.page_source
            with open(os.path.join("ui_dumps",
                                   "trafik_tab2_tier_bawah.xml"),
                      "w", encoding="utf-8") as f:
                f.write(xml)
            print("[TAB2] dump fasa2 -> trafik_tab2_tier_bawah.xml")
        except Exception as e:                               # noqa: BLE001
            print(f"[TAB2] fasa 2 gagal ({type(e).__name__}: {e}) — "
                  f"dump fasa 1 masih sah")

        print("\n[TAB2] ===== SEMUA ITEM UNIK (rehat+leret+tab) =====")
        for jenis, v in sorted(semua):
            print(f"  {jenis:12s} {v!r}")
        kunci = [v for _, v in semua if re.search(
            r"(?i)jalan|taman|bandar|poskod|negeri|lokasi|butiran", v)]
        print(f"\n[TAB2] calon medan alamat: {kunci}")
        return 0
    finally:
        try:
            driver.quit()
        except Exception:                                    # noqa: BLE001
            pass


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
"""Semak DB staging MBIP TERUS — senaraikan lesen/peranti/pengguna sah.

Kredensial dari dokumen staging rasmi (CEO 2026-08-21):
    hos 219.93.38.103 : 3306, nk_user / nk@2026

Guna (di PC yang boleh capai staging):
    pip install pymysql
    python tools\\semak_db_staging.py

BACA-SAHAJA: SELECT sahaja, tiada tulisan.
"""
import sys

try:
    import pymysql
except ImportError:
    print("pymysql tiada — jalankan dahulu:  pip install pymysql")
    sys.exit(1)

HOS, PORT, USER, PW = "219.93.38.103", 3306, "nk_user", "nk@2026"


def main():
    print(f"  sambung {HOS}:{PORT} sebagai {USER}...")
    con = pymysql.connect(host=HOS, port=PORT, user=USER, password=PW,
                          connect_timeout=10)
    cur = con.cursor()
    cur.execute("SHOW DATABASES")
    dbs = [r[0] for r in cur.fetchall()
           if r[0] not in ("information_schema", "mysql",
                           "performance_schema", "sys")]
    print("  pangkalan data:", dbs)
    for db in dbs:
        cur.execute(f"SHOW TABLES FROM `{db}`")
        jadual = [r[0] for r in cur.fetchall()]
        # jadual berkaitan lesen / peranti / pengguna sahaja
        menarik = [j for j in jadual if any(
            k in j.lower() for k in ("lesen", "license", "peranti",
                                     "device", "user", "pengguna"))]
        if not menarik:
            continue
        print(f"\n== DB `{db}` — jadual berkaitan: {menarik}")
        for j in menarik:
            try:
                cur.execute(f"SELECT * FROM `{db}`.`{j}` LIMIT 10")
                kolum = [d[0] for d in cur.description]
                print(f"\n  -- {j} ({', '.join(kolum)}):")
                for baris in cur.fetchall():
                    print("    ", baris)
            except Exception as e:                          # noqa: BLE001
                print(f"  -- {j}: tidak dapat dibaca ({e})")
    con.close()
    print("\n  Selesai. Cari: lesen mana dipadankan dgn ID peranti apa, "
          "dan ID peranti Armor 27 kau ada dalam senarai atau tidak.")


if __name__ == "__main__":
    main()

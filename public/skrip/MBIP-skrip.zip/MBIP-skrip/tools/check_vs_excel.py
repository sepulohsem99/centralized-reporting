"""
Bandingkan nilai dalam testdata/ dengan sel Excel yang mendakwa menjadi
sumbernya.

KENAPA SKRIP INI WUJUD
----------------------
Pada 2026-07-29 pemilik membaca kertas kompaun yang baru dicetak dan
perasan nama penerima "Buruh En Saiful" — nama yang tidak pernah wujud
dalam skrip ujian Excel. Ia nilai warisan suite v2 yang ditampal ke medan
yang Excel biarkan kosong, dan ia bertahan berbulan tanpa disedari.

Sapuan susulan menemui lima penyimpangan seumpamanya. Tiada satu pun
menggagalkan mana-mana ujian — itulah masalahnya. Data yang salah tetap
menghasilkan run hijau; ia cuma menguji perkara yang salah, secara
senyap. Satu-satunya isyarat ialah mata manusia pada kertas.

Dua corak yang ditemui:

  1. MEDAN DIREKA — Excel senyap, kod menampal nilai "yang munasabah".
     (nama_penerima pada N-001, K-001, L-001, S-001)

  2. KOMEN TERSALAH SALIN — komen mendakwa C9 berkata X, C9 sebenarnya
     berkata Y, dan nilai kod mengikut komen. (tempoh_notis N-001 dan
     K-001: komen tulis "1 HARI", C9 tulis "0 HARI")

Corak kedua paling merbahaya kerana komen itu sendiri kelihatan seperti
bukti. Sebab itu skrip ini membaca semula workbook dan tidak sekali-kali
mempercayai komen.

GUNA
----
    python tools/check_vs_excel.py

Keluar dengan kod 1 kalau ada percanggahan, supaya ia boleh dijadikan
gate dalam check_env.bat kemudian.

Medan yang sengaja menyimpang mesti didaftarkan — jangan senyapkan
amaran dengan mengubah skrip ini:
  - excel_data.BLANK_BY_DESIGN  -> medan yang sengaja dibiar kosong
  - DIBENARKAN di bawah         -> override persekitaran yang diluluskan
"""

import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

XLSX = os.path.join(ROOT, "docs",
                    "IES-MBIP Testing Script V2.1.14_PRODUCTION.xlsx")

# Penyimpangan yang DILULUSKAN, dengan sebabnya. Setiap satu ialah
# keputusan pemilik yang direkodkan, bukan kelonggaran umum.
DIBENARKAN = {
    ("*", "lesen_aplikasi"): "lesen Excel terikat IMEI peranti tester lain",
    ("*", "username"): "akaun Excel (user4) tidak disahkan; msc terbukti",
    ("*", "password"): "lihat username",
    ("*", "internal_ip"): "IP bergantung environment (staging vs production)",
    ("*", "external_ip"): "lihat internal_ip",
    ("MBIP-TC-K-001", "no_kereta"):
        "plat JYX6605 diminta pemilik supaya kekal; C9 hanya menyenaraikan "
        "HASIL auto-populate MySIKAP, bukan plat yang ditaip",
}

# Sheet Kemaskini (-004) dan Bookmark (-005) hanya menerangkan PERUBAHAN,
# bukan mengulang rekod asas. Contoh S-004 C9 penuhnya berbunyi
# "Jalan Keruing 11 change to Jalan Harimau Telap" — ia mengandaikan
# pembaca sudah tahu rekod itu dicipta oleh S-001.
#
# Jadi medan yang "hilang" pada sheet ini bukan medan yang direka: ia
# diwarisi daripada sheet -001 yang sepadan. Ini berbeza sepenuhnya
# daripada kes nama_penerima, di mana sheet -001 sendiri senyap dan tiada
# apa untuk diwarisi.
#
# Kalau nilai pada -004/-005 TIDAK sepadan dengan -001 yang sepadan,
# itu tetap dilaporkan — lihat _warisan_konsisten().
SUFIKS_MEWARISI = ("-004", "-005")

# Medan yang diperiksa, dan corak mencarinya dalam sel C9.
MEDAN = {
    "nama_penerima": r'(?i)nama\s*penerima\s*:\s*(.+)',
    "no_ic_penerima": r'(?i)no\.?\s*ic\s*penerima\s*:\s*(.+)',
    "tempoh_notis": r'(?i)(?:maklumat|tempoh)\s*kompaun\s*:\s*(\d+)',
    "kadar_denda": r'(?i)kadar\s*denda[^:]*:\s*(?:RM)?\s*(\d+)',
    "lokasi_kesalahan": r'(?i)lokasi\s*kesalahan\s*:\s*(.+)',
    "butiran_kesalahan": r'(?i)butiran(?:\s*kesalahan)?\s*:\s*(.+)',
}


def _norm(v):
    """Banding tanpa terpengaruh huruf besar/kecil, ruang, atau 'RM'."""
    s = str(v or "").strip().upper()
    s = re.sub(r'^RM\s*', '', s)
    s = re.sub(r'\s+', ' ', s)
    return s


def main():
    try:
        import openpyxl
    except ImportError:
        print("openpyxl tiada — pip install openpyxl")
        return 2
    if not os.path.exists(XLSX):
        print(f"Workbook tidak dijumpai:\n  {XLSX}")
        return 2

    os.environ.setdefault("MBIP_PROFILE", "mbip-staging")
    from testdata.excel_data import (TC_DATA, BLANK_BY_DESIGN, BLANK_MARKER,
                                     penanda_untuk)
    globals()["BLANK_MARKER"] = BLANK_MARKER
    globals()["penanda_untuk"] = penanda_untuk

    wb = openpyxl.load_workbook(XLSX, data_only=True)
    sheets = {n.strip().upper(): n for n in wb.sheetnames}

    masalah = []
    diperiksa = 0

    for tc in sorted(TC_DATA):
        sn = sheets.get(tc)
        if not sn:
            continue
        c9 = str(wb[sn]["C9"].value or "")
        blanks = BLANK_BY_DESIGN.get(tc) or {}

        for medan, corak in MEDAN.items():
            if medan not in TC_DATA[tc]:
                continue
            if (tc, medan) in DIBENARKAN or ("*", medan) in DIBENARKAN:
                continue

            kod = TC_DATA[tc][medan]
            m = re.search(corak, c9)
            excel = m.group(1).strip() if m else None
            diperiksa += 1

            if excel is None:
                # Sheet -004/-005 hanya menerangkan perubahan; nilai
                # selebihnya diwarisi dari sheet -001. Periksa warisan itu
                # konsisten dan bukan nilai yang direka berasingan.
                if tc.endswith(SUFIKS_MEWARISI):
                    asas = re.sub(r'-0\d\d$', '-001', tc)
                    nilai_asas = (TC_DATA.get(asas) or {}).get(medan)
                    if nilai_asas is None:
                        masalah.append(
                            (tc, medan, f"(diwarisi dari {asas})", kod,
                             f"{asas} sendiri tiada medan ini — warisan "
                             f"tidak dapat disahkan"))
                    elif _norm(nilai_asas) != _norm(kod):
                        masalah.append(
                            (tc, medan, f"{asas} = {nilai_asas}", kod,
                             "menyimpang dari rekod asas yang diwarisi"))
                    continue

                # Excel senyap. Kod mesti mengandungi BLANK_MARKER DAN
                # medan itu mesti didaftarkan — supaya penanda tidak
                # boleh dikelirukan dengan data sebenar, dan sebaliknya.
                if medan in blanks:
                    jangkaan = penanda_untuk(medan)
                    if _norm(kod) != _norm(jangkaan):
                        masalah.append(
                            (tc, medan, f"(Excel senyap -> {jangkaan})",
                             kod, "didaftar dalam BLANK_BY_DESIGN tetapi "
                                  "tidak mengandungi penanda yang betul"))
                else:
                    masalah.append(
                        (tc, medan, "(Excel senyap)", kod,
                         "kod menampal nilai yang Excel tidak bekalkan — "
                         "daftarkan dalam BLANK_BY_DESIGN supaya ia diisi "
                         "dengan penanda"))
            elif _norm(kod) != _norm(excel):
                masalah.append(
                    (tc, medan, excel, kod, "tidak sepadan dengan C9"))

    print(f"Diperiksa {diperiksa} medan merentas {len(TC_DATA)} TC.\n")
    if not masalah:
        print("Tiada percanggahan — testdata sepadan dengan Excel.")
        return 0

    print(f"{len(masalah)} PERCANGGAHAN:\n")
    for tc, medan, excel, kod, sebab in masalah:
        print(f"  {tc} . {medan}")
        print(f"      Excel : {excel}")
        print(f"      Kod   : {kod}")
        print(f"      -> {sebab}\n")
    print("Betulkan kod supaya ikut Excel, ATAU daftarkan penyimpangan\n"
          "dalam BLANK_BY_DESIGN / DIBENARKAN dengan sebabnya.")
    return 1


if __name__ == "__main__":
    sys.exit(main())

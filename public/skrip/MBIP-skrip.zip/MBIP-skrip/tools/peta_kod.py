#!/usr/bin/env python3
"""PETA KOD — cetak pokok kombo kompaun/akta/kesalahan SAH dari DB app.

>>> DIBINA 2026-08-27 atas arahan CEO ("cari satu persatu mana satu
yang boleh guna untuk ketiga-tiga N/P/K... need to expedite"). Ganti
pencarian UI 25-min dengan bacaan DB tempatan app (~30 saat): app
sync semua kod ke SQLite peranti semasa selaras; kita tarik salinan
baca-sahaja via adb (laluan terbukti MBPG "pokok kombo sah" 19 Aug)
dan cetak rantaian yang LENGKAP (kompaun -> akta -> kesalahan wujud).
TIADA Appium diperlukan, TIADA rekod dicipta, TIADA tulisan ke DB. <<<

Guna:
    python tools\\peta_kod.py --profil mbip-production
"""
import argparse
import os
import re
import sqlite3
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
AKAR = os.path.dirname(HERE)
sys.path.insert(0, AKAR)
os.chdir(AKAR)


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--profil", default="mbip-production")
    ap.add_argument("--semua-jadual", action="store_true",
                    help="senarai SEMUA jadual, bukan padanan sahaja")
    args = ap.parse_args(argv)
    os.environ["MBIP_PROFILE"] = args.profil

    from config import APP_PACKAGE
    from device_utils import resolve_udid
    from tools.db_peranti import tarik_db

    serial = resolve_udid(APP_PACKAGE)
    ke = os.path.join("ui_dumps", "peta_kod_snapshot.db")
    print(f"[PETA] menarik DB dari {serial}...")
    tarik_db(serial, ke)
    print(f"[PETA] DB: {ke} ({os.path.getsize(ke):,} bait)")

    con = sqlite3.connect(f"file:{ke}?mode=ro", uri=True)
    con.row_factory = sqlite3.Row
    cur = con.cursor()
    cur.execute("SELECT name FROM sqlite_master WHERE type='table' "
                "ORDER BY name")
    semua = [r[0] for r in cur.fetchall()]
    pat = re.compile(r"kompaun|akta|kesalahan|kod|act", re.I)
    padan = semua if args.semua_jadual else [t for t in semua
                                            if pat.search(t)]
    print(f"\n[PETA] {len(semua)} jadual; berkaitan: {padan}")

    info = {}
    for t in padan:
        try:
            cur.execute(f"PRAGMA table_info('{t}')")
            kol = [r[1] for r in cur.fetchall()]
            cur.execute(f"SELECT COUNT(*) FROM '{t}'")
            n = cur.fetchone()[0]
        except Exception as e:                               # noqa: BLE001
            print(f"  [PETA] {t}: ralat {e}")
            continue
        info[t] = (kol, n)
        print(f"\n===== {t} ({n} baris) =====")
        print(f"  kolum: {kol}")
        if n == 0:
            print("  (KOSONG)")
            continue
        cur.execute(f"SELECT * FROM '{t}' LIMIT 300")
        for r in cur.fetchall():
            vals = []
            for k in kol:
                v = r[k]
                s = str(v) if v is not None else ""
                if len(s) > 70:
                    s = s[:70] + "…"
                vals.append(f"{k}={s!r}")
            print("   ", " | ".join(vals))

    # ---- Analisis rantaian: kesalahan dikelompok ikut kolum FK ----
    print("\n[PETA] ===== ANALISIS RANTAIAN =====")
    for t, (kol, n) in info.items():
        if not re.search(r"kesalahan", t, re.I) or n == 0:
            continue
        fk = [k for k in kol if re.search(r"akta|parent|kod", k, re.I)
              and not re.search(r"kesalahan", k, re.I)]
        for k in fk:
            try:
                cur.execute(
                    f"SELECT \"{k}\", COUNT(*) c FROM '{t}' "
                    f"GROUP BY \"{k}\" ORDER BY c DESC")
                rows = cur.fetchall()
                print(f"  {t}: kumpulan ikut '{k}':")
                for r in rows:
                    print(f"    {k}={r[0]!r} -> {r[1]} kesalahan")
            except Exception:                                # noqa: BLE001
                continue
    print("\n[PETA] SELESAI — pilih rantaian yang LENGKAP dari output "
          "di atas.")
    con.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
"""FORENSIK skrin TETAPAN PELBAGAI — kenapa manual lulus tapi script gagal.

>>> DIBINA 2026-08-24. Konteks: CEO sahkan lesen ...9401 DITERIMA bila
ditaip MANUAL ('Lesen sama'), tetapi aliran automatik jatuh ke tier-3
fallback (EditText instance(0)) dan server jawab 'LESEN TIDAK SAMA.'
untuk kedua-dua lesen. Hipotesis:
  (a) el.clear() senyap gagal pada RN input -> mobile:type APPEND pada
      nilai sedia ada -> lesen hantar = gabungan dua nombor.
  (b) susunan EditText berubah dalam build hotfix -> instance(0) bukan
      field Lesen Aplikasi.
Tool ini membuktikan yang mana satu TANPA menekan Simpan (tidak
mengubah apa-apa tetapan). <<<

Guna:
    python tools\\debug_tetapan_pelbagai.py --profil mbip-production
"""
import argparse
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
AKAR = os.path.dirname(HERE)
sys.path.insert(0, AKAR)
os.chdir(AKAR)


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--profil", default="mbip-production")
    args = ap.parse_args(argv)
    os.environ["MBIP_PROFILE"] = args.profil

    from appium import webdriver
    from appium.options.android import UiAutomator2Options
    from appium.webdriver.common.appiumby import AppiumBy
    from config import (APPIUM_URL, APP_PACKAGE, APP_ACTIVITY, DEVICE_NAME,
                        PLATFORM_NAME, AUTOMATION_NAME, IMPLICIT_WAIT,
                        LICENSE_SETTINGS)
    from device_utils import resolve_udid
    from pages.pelarasan_page import PelarasanPage

    udid = resolve_udid(APP_PACKAGE)
    options = UiAutomator2Options()
    options.device_name = DEVICE_NAME
    options.set_capability("udid", udid)
    options.platform_name = PLATFORM_NAME
    options.app_package = APP_PACKAGE
    options.app_activity = APP_ACTIVITY
    options.no_reset = True
    options.full_reset = False
    options.automation_name = AUTOMATION_NAME
    options.set_capability("disableAndroidWatchers", True)
    driver = webdriver.Remote(APPIUM_URL, options=options)
    driver.implicitly_wait(IMPLICIT_WAIT)

    lesen = str(LICENSE_SETTINGS.get("lesen_aplikasi", ""))

    try:
        pel = PelarasanPage(driver)
        pel.ensure_on_login_screen()
        pel.open_menu_selaras()
        pel._open_tetapan_item(pel.MENU_TETAPAN_PELBAGAI, "Tetapan Pelbagai")

        os.makedirs("ui_dumps", exist_ok=True)
        xml = driver.page_source
        with open(os.path.join("ui_dumps", "debug_tetapan_pelbagai.xml"),
                  "w", encoding="utf-8") as f:
            f.write(xml)
        print("\n  [DUMP] ui_dumps\\debug_tetapan_pelbagai.xml disimpan")

        # ---- senarai SEMUA EditText + label TextView ------------------
        print("\n" + "=" * 66)
        print("  EDITTEXT PADA SKRIN TETAPAN PELBAGAI")
        print("=" * 66)
        ets = driver.find_elements(AppiumBy.CLASS_NAME,
                                   "android.widget.EditText")
        for i, et in enumerate(ets):
            try:
                teks = et.text
            except Exception:                                # noqa: BLE001
                teks = "<tak boleh baca>"
            try:
                pw = et.get_attribute("password")
            except Exception:                                # noqa: BLE001
                pw = "?"
            try:
                desc = et.get_attribute("content-desc")
            except Exception:                                # noqa: BLE001
                desc = ""
            print(f"  instance({i}): text={teks!r}  password={pw}  "
                  f"desc={desc!r}  bounds={et.rect}")

        print("\n  TEXTVIEW (label) pada skrin:")
        tvs = driver.find_elements(AppiumBy.CLASS_NAME,
                                   "android.widget.TextView")
        for tv in tvs[:20]:
            try:
                t = tv.text
                if t and t.strip():
                    print(f"    - {t!r}")
            except Exception:                                # noqa: BLE001
                pass

        if not ets:
            print("\n  !! TIADA EditText — skrin berbeza dari jangkaan. "
                  "Semak XML dump.")
            return 1

        # ---- eksperimen clear() pada instance(0) ----------------------
        print("\n" + "=" * 66)
        print("  EKSPERIMEN: clear() + mobile:type pada instance(0)")
        print("  (TIDAK akan tekan Simpan — tiada apa disimpan)")
        print("=" * 66)
        et0 = driver.find_elements(AppiumBy.CLASS_NAME,
                                   "android.widget.EditText")[0]
        sebelum = et0.text
        print(f"  1. nilai SEBELUM        : {sebelum!r}")
        et0.click()
        try:
            et0.clear()
        except Exception as e:                               # noqa: BLE001
            print(f"     clear() melontar: {e}")
        selepas_clear = et0.text
        print(f"  2. nilai SELEPAS clear(): {selepas_clear!r}")
        if lesen:
            driver.execute_script("mobile: type", {"text": lesen})
            selepas_type = et0.text
            print(f"  3. selepas type lesen   : {selepas_type!r}")
            print(f"     sasaran              : {lesen!r}")
            if selepas_type == lesen:
                print("     >> PADAN — taip berfungsi; masalah di tempat "
                      "lain (mungkin field salah / server).")
            elif lesen in (selepas_type or ""):
                print("     >> APPEND DIKESAN — clear() tidak berkesan; "
                      "nilai lama + baru bercantum. INI PUNCANYA.")
            else:
                print("     >> nilai TIDAK padan dan bukan append — "
                      "kemungkinan instance(0) BUKAN field lesen.")

        # jangan simpan: tekan Back untuk keluar tanpa Simpan
        print("\n  [KELUAR] Tekan Back (tanpa Simpan)...")
        driver.back()
        return 0
    finally:
        driver.quit()


if __name__ == "__main__":
    sys.exit(main())

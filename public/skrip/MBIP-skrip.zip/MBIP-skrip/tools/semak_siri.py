"""
GERBANG KAUNTER SIRI — halang nombor rekod bertembung.

>>> KENAPA MODUL INI WUJUD (2026-08-18). <<<
Pemasangan APK 2.1.23 memadam semua data app, termasuk
`local_system_control`. Kedua-dua kaunter jatuh 9 -> 1:

    local_ekpn_notis_amaran      nonotis      9 -> 1
    local_ekpn_tawaran_kompaun   nokompaun    9 -> 1

Nombor rekod berbentuk

    PGP02 + <jenis> + <YYMMDD tarikh cipta> + <NNN kaunter>

jadi ia unik hanya selagi pasangan (tarikh, kaunter) tidak berulang.
Rekod production `PGP02P260818003` hingga `...008` sudah wujud dari
sesi pagi 2026-08-18. Selepas reset, kaunter kompaun berdiri pada 3 —
maka larian SETERUSNYA pada hari yang SAMA akan mengeluarkan semula
`PGP02P260818003`.

Apa yang server buat dengan nombor berulang tidak diketahui: tolak,
timpa, atau terima menjadi dua rekod berkongsi satu nombor. Ketiga-tiga
kemungkinan buruk, dan yang ketiga paling buruk kerana ia senyap.

Larian 2026-08-18 petang terlepas hanya kerana ia mengeluarkan 001 dan
002, yang kebetulan bebas. Tarikh kemudian berputar ke 19hb dan
menghapuskan bahaya itu. Itu NASIB, bukan reka bentuk — dan nasib
bukan kawalan.

HAD YANG MESTI DIFAHAMI
-----------------------
Gerbang ini hanya tahu nombor yang KITA rekodkan: `rekod_log` dan DB
tempatan. Pemasangan bersih memadam DB, jadi log ialah satu-satunya
sumber yang tinggal untuk rekod lama. Rekod yang dicipta oleh peranti
atau pengguna LAIN pada production tidak kelihatan langsung.

Maka: TIADA pertembungan dikesan bermakna "tiada pertembungan dengan
apa yang kita tahu", bukan "nombor ini pasti bebas". Gerbang ini
menangkap kes yang sudah berlaku kepada kita; ia tidak boleh menjamin
keunikan di seluruh production.

SEMAKAN baca-sahaja; PEMBAIKAN ialah tulisan yang DILULUSKAN PEMILIK.
Versi asal modul ini baca-sahaja sepenuhnya ("membetulkan kaunter ialah
keputusan pemilik, bukan keputusan skrip"). Pada 2026-08-20 pemilik
MEMBUAT keputusan itu (MCQ): aliran kerja rasmi ialah `pm clear` sebelum
SETIAP run, jadi kaunter reset SETIAP run dan pertembungan hari-sama
menjadi kepastian, bukan kemalangan. `majukan()` menulis kaunter DEVICE
melebihi nombor hari ini yang diketahui — tulisan ke CONFIG LOKAL device
(kelas sama seperti bootstrap IP/lesen), bukan ke rekod production.
HAD yang sama kekal: ia hanya tahu nombor yang KITA rekodkan.
"""

import os
import sqlite3
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
AKAR = os.path.dirname(HERE)
sys.path.insert(0, AKAR)

# >>> MBIP: awalan TIDAK dihardcode. <<<
# MBPG guna "PGP02"; awalan MBIP belum pernah disahkan pada build baru.
# derive_awalan() membacanya dari nombor rekod sebenar (log + DB) —
# corak: <AWALAN><jenis N/P/K/S><YYMMDD><NNN>. Tiada nombor diketahui =
# tiada semakan pertembungan boleh dibuat (gerbang lulus dengan nota).
AWALAN = None


def derive_awalan(diketahui):
    """Awalan terpanjang yang konsisten merentas nombor diketahui."""
    import re as _re
    calon = set()
    for n in diketahui:
        m = _re.match(r"^([A-Z0-9]{3,8})([NPKSL])(\d{6})(\d{3})$", str(n))
        if m:
            calon.add(m.group(1))
    return sorted(calon, key=len)[-1] if calon else None

# Satu kaunter bagi notis; SATU kaunter dikongsi oleh P dan K.
# Perkongsian itu penting: rekod K menaikkan kaunter yang rekod P
# gunakan, jadi menyemak satu sahaja terlepas separuh daripada risiko.
KAUNTER = {
    "local_ekpn_notis_amaran": ("N",),
    "local_ekpn_tawaran_kompaun": ("P", "K"),
}

JADUAL_NOMBOR = (
    ("local_ekpn_tawaran_kompaun", "nokompaun"),
    ("local_ekpn_notis_amaran", "noNotis"),
)


def cap_tarikh(hari_ini=None):
    """YYMMDD seperti yang app benamkan ke dalam nombor rekod."""
    return hari_ini or time.strftime("%y%m%d")


def baca_kaunter(db):
    """{tablename: newserial}. Kosong kalau jadual tiada."""
    keluar = {}
    c = sqlite3.connect(db)
    try:
        for jad, siri in c.execute(
                "SELECT tablename, newserial FROM local_system_control"):
            keluar[jad] = siri
    except sqlite3.Error:
        pass
    finally:
        c.close()
    return keluar


def nombor_diketahui(db=None):
    """Setiap nombor rekod yang kita tahu wujud pada production.

    Gabungan DUA sumber, dan kedua-duanya perlu: DB tempatan dipadam
    oleh pemasangan bersih, manakala log tidak merangkumi rekod yang
    dicipta sebelum log itu wujud (2026-08-17).
    """
    keluar = set()
    try:
        from tools import rekod_log
        for d in rekod_log.baca_semua():
            if d.get("no_rekod"):
                keluar.add(str(d["no_rekod"]))
    except Exception:                                       # noqa: BLE001
        pass
    if db and os.path.exists(db):
        c = sqlite3.connect(db)
        for jad, lajur in JADUAL_NOMBOR:
            try:
                for (no,) in c.execute("SELECT %s FROM %s" % (lajur, jad)):
                    if no:
                        keluar.add(str(no))
            except sqlite3.Error:
                pass
        c.close()
    return keluar


def calon_seterusnya(kaunter, tarikh, awalan=None):
    """[(jenis, nombor)] yang akan dikeluarkan seterusnya."""
    keluar = []
    for jad, jenis_jenis in KAUNTER.items():
        siri = kaunter.get(jad)
        if siri is None:
            continue
        for jenis in jenis_jenis:
            keluar.append(
                (jenis, "%s%s%s%03d" % (awalan or AWALAN or "?", jenis,
                                        tarikh, int(siri))))
    return keluar


def kesan(kaunter, diketahui, tarikh, awalan=None):
    """[(jenis, nombor)] yang akan BERTEMBUNG dengan rekod sedia ada."""
    awalan = awalan or derive_awalan(diketahui)
    return [(j, n) for j, n in calon_seterusnya(kaunter, tarikh, awalan)
            if n in diketahui]


def lapor(db, tarikh=None, senyap=False):
    """Cetak keadaan kaunter. Pulangkan senarai pertembungan."""
    tarikh = cap_tarikh(tarikh)
    kaunter = baca_kaunter(db)
    diketahui = nombor_diketahui(db)
    awalan = derive_awalan(diketahui)
    if awalan is None:
        print("  [SIRI] AMARAN: tiada nombor rekod diketahui — awalan "
              "MBIP tidak dapat diterbitkan; semakan pertembungan "
              "dilangkau (tiada apa untuk dilanggar).")
        return []
    print(f"  [SIRI] awalan diterbitkan dari rekod sebenar: {awalan}")
    calon = calon_seterusnya(kaunter, tarikh, awalan)
    bertembung = kesan(kaunter, diketahui, tarikh, awalan)

    if not senyap:
        print("")
        print("  [SIRI] kaunter peranti: %s"
              % {k.replace("local_ekpn_", ""): v
                 for k, v in sorted(kaunter.items())})
        print("  [SIRI] %d nombor diketahui dari log + DB" % len(diketahui))
        for jenis, nombor in calon:
            tanda = ">>> BERTEMBUNG <<<" if nombor in diketahui else "bebas"
            print("  [SIRI] seterusnya %s -> %s  %s"
                  % (jenis, nombor, tanda))
    return bertembung


def kira_sasaran_kaunter(kaunter, diketahui, tarikh, awalan=None):
    """{tablename: newserial_baru} untuk kaunter yang PERLU dimajukan.

    Sasaran = seq TERTINGGI nombor hari ini yang diketahui bagi jenis
    kaunter itu + 1. Kaunter yang sudah >= sasaran tidak disentuh."""
    awalan = awalan or derive_awalan(diketahui)
    if awalan is None:
        return {}
    sasaran = {}
    for jad, jenis_jenis in KAUNTER.items():
        maks = 0
        for n in diketahui:
            for jenis in jenis_jenis:
                pre = awalan + jenis + tarikh
                if str(n).startswith(pre):
                    try:
                        maks = max(maks, int(str(n)[len(pre):]))
                    except ValueError:
                        pass
        semasa = kaunter.get(jad)
        if semasa is not None and maks + 1 > int(semasa):
            sasaran[jad] = maks + 1
    return sasaran


def majukan(serial, tarikh=None):
    """Majukan kaunter siri DEVICE melebihi nombor hari ini yang diketahui.

    >>> KEPUTUSAN PEMILIK 2026-08-20 (MCQ, run 10). <<<
    Aliran kerja rasmi = pm clear sebelum SETIAP run, maka kaunter reset
    SETIAP run; run kedua pada hari yang sama PASTI bertembung dengan
    rekod run pertama (run 10 disekat gerbang pada PGP02N260820001,
    rekod run 9 pagi yang sama). Pemilik meluluskan automasi: tulis
    `local_system_control.newserial` ke seq_maks_hari_ini + 1.

    Prosedur tulis (selamat terhadap WAL):
      force-stop app -> tarik DB (selepas stop = checkpoint bersih) ->
      UPDATE tempatan -> push ke /data/local/tmp -> run-as cp + padam
      -wal/-shm -> lancar semula app -> tarik semula dan SAHKAN nilai.
    """
    import time as _t
    from tools.db_peranti import tarik_db
    from tools.sedia_peranti import adb, lancar_dan_tunggu_db, DB_DEV
    from config import APP_PACKAGE, APP_ACTIVITY

    tarikh = cap_tarikh(tarikh)
    print("  [SIRI] memajukan kaunter (kelulusan pemilik 2026-08-20)...")
    adb(serial, "shell", "am", "force-stop", APP_PACKAGE)
    _t.sleep(2)
    db = tarik_db(serial, os.path.join(AKAR, "data", "tmp",
                                       "siri_majukan.db"))
    kaunter = baca_kaunter(db)
    diketahui = nombor_diketahui(db)
    sasaran = kira_sasaran_kaunter(kaunter, diketahui, tarikh)
    if not sasaran:
        print("  [SIRI] kaunter sudah selamat — tiada tulisan diperlukan")
        adb(serial, "shell", "am", "start", "-n",
            f"{APP_PACKAGE}/{APP_ACTIVITY}")
        return {}
    c = sqlite3.connect(db)
    try:
        for jad, nilai in sasaran.items():
            c.execute("UPDATE local_system_control SET newserial=? "
                      "WHERE tablename=?", (int(nilai), jad))
            print(f"  [SIRI] {jad.replace('local_ekpn_', '')}: "
                  f"{kaunter.get(jad)} -> {nilai}")
        c.commit()
    finally:
        c.close()
    adb(serial, "push", db, "/data/local/tmp/siri_fix.db", semak=True)
    # >>> KUOTA SHELL — run 11 (2026-08-20). <<<
    # `adb shell` mencantumkan argv berasingan dengan space TANPA
    # mengekalkan kuota, jadi `... "sh", "-c", "cp a b && rm ..."`
    # sampai ke shell device sebagai `sh -c cp a b && rm ...` — `-c`
    # hanya menerima perkataan `cp` dan mati dengan "cp: Needs 1
    # argument". Penyelesaian: hantar KESELURUHAN perintah sebagai SATU
    # argumen shell berkuota — adb menghantarnya verbatim dan shell
    # device yang menghurai kuota.
    adb(serial, "shell",
        f"run-as {APP_PACKAGE} sh -c "
        f"'cp /data/local/tmp/siri_fix.db {DB_DEV} && "
        f"rm -f {DB_DEV}-wal {DB_DEV}-shm'", semak=True)
    adb(serial, "shell", "rm", "-f", "/data/local/tmp/siri_fix.db")
    lancar_dan_tunggu_db(serial, timeout_s=60)
    # SAHKAN dari bacaan semula — bukan mempercayai push.
    db2 = tarik_db(serial, os.path.join(AKAR, "data", "tmp",
                                        "siri_sahkan.db"))
    kaunter2 = baca_kaunter(db2)
    gagal = {j: (kaunter2.get(j), n) for j, n in sasaran.items()
             if int(kaunter2.get(j) or -1) != int(n)}
    if gagal:
        raise RuntimeError(
            f"kaunter TIDAK melekat selepas tulis+relaunch: {gagal} — "
            f"app mungkin menimpa DB pada boot. JANGAN teruskan.")
    print(f"  [SIRI] kaunter DISAHKAN dari bacaan semula: "
          f"{ {k.replace('local_ekpn_', ''): v for k, v in sorted(kaunter2.items())} }")
    return sasaran


def gerbang(serial, tarikh=None, baiki=False):
    """Peringkat pra-terbang. Membangkitkan kalau nombor akan berulang.

    Berhenti adalah betul di sini, tidak seperti kebanyakan kegagalan
    peringkat: kerosakan berlaku pada SAAT rekod dicipta, dan tiada
    pemulihan selepas itu. Menghalangnya lebih murah daripada
    membetulkan rekod production yang berkongsi nombor.

    `baiki=True` (kelulusan pemilik 2026-08-20): pertembungan tidak
    lagi maut serta-merta — majukan() dipanggil sekali, kemudian gerbang
    disemak SEMULA dari bacaan device yang baru. Masih bertembung
    selepas pembaikan = raise seperti dahulu.
    """
    from tools.db_peranti import tarik_db
    db = tarik_db(serial, os.path.join(AKAR, "data", "tmp", "siri.db"))
    bertembung = lapor(db, tarikh)
    if bertembung and baiki:
        majukan(serial, tarikh)
        db = tarik_db(serial, os.path.join(AKAR, "data", "tmp", "siri.db"))
        bertembung = lapor(db, tarikh)
    if bertembung:
        senarai = ", ".join(n for _, n in bertembung)
        raise RuntimeError(
            "KAUNTER SIRI AKAN MENGELUARKAN SEMULA NOMBOR SEDIA ADA: %s. "
            "Pemasangan APK bersih mengosongkan local_system_control, "
            "jadi kaunter bermula semula sedangkan rekod lama masih "
            "hidup pada production. Larian DIHENTIKAN sebelum apa-apa "
            "dicipta." % senarai)
    return "kaunter selamat (%d nombor diketahui)" % len(nombor_diketahui(db))


def main():
    import argparse
    ap = argparse.ArgumentParser(
        description="Semak kaunter siri (baca-sahaja).")
    ap.add_argument("--db", help="snapshot DB; lalai tarik dari peranti")
    ap.add_argument("--tarikh", help="YYMMDD untuk diuji (lalai: hari ini)")
    args = ap.parse_args()
    db = args.db
    if not db:
        from config import APP_PACKAGE
        from device_utils import resolve_udid
        from tools.db_peranti import tarik_db
        db = tarik_db(resolve_udid(APP_PACKAGE, verbose=False),
                      os.path.join(AKAR, "data", "tmp", "siri.db"))
    return 1 if lapor(db, args.tarikh) else 0


if __name__ == "__main__":
    sys.exit(main())

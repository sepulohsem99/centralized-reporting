#!/usr/bin/env python3
"""VALIDASI dropdown tier — panggil fungsi SEBENAR, bukan salinan.

>>> DIBINA 2026-08-25 selepas audit penuh select_dropdown_option.
Tujuan: sahkan fix dropdown dalam ~12 minit TANPA run penuh 1.5 jam.
Tool ini login, isi tab Pesalah dengan helper terbukti, tekan
SETERUSNYA, kemudian panggil fill_kompaun_code_fields SEBENAR (laluan
kod yang sama run penuh guna — select_dropdown_option_and_confirm →
select_dropdown_option, termasuk MOD GANTI). TIADA gambar, TIADA
tandatangan, TIADA HANTAR — sifar rekod dicipta.

Liputan (arahan CEO 2026-08-26: "npk all la, mbpg buat all kan"):
  notis    — tier1 KOMPAUN PELBAGAI, tier2 UUK 7 (drift: ACT2025),
             tier3 MEMOTONG... (drift: [UUK 7] - MELETAKKAN...)
  pelbagai — tier2 SEKSYEN 18(B)... (drift), tier3 IDAK MEMATUHI...
  trafik   — data KUNCI CEO (TRAFIK_V2): tier1 Akta Jalan Parit dan
             Bangunan, akta 62, kesalahan = PILIH BARIS PERTAMA
             ("pilih yang atas"), kadar denda RM200

Kejayaan = setiap tier mencetak sama ada:
  [DROPDOWN] SELECTED '...'            (nilai Excel masih wujud)
  [DROPDOWN] SELECTED (GANTI) '...'    (MOD GANTI — [PENEMUAN-DATA])

Guna:
    python tools\\debug_pilih.py --profil mbip-production
    python tools\\debug_pilih.py --profil mbip-production --jenis notis
"""
import argparse
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
AKAR = os.path.dirname(HERE)
sys.path.insert(0, AKAR)
os.chdir(AKAR)


class _Tee:
    """Salin stdout ke fail — CEO tak perlu copy-paste console lagi;
    orchestrator baca ui_dumps/pilih_log.txt sendiri (2026-08-27)."""

    def __init__(self, *aliran):
        self.aliran = aliran

    def write(self, s):
        for a in self.aliran:
            try:
                a.write(s)
                a.flush()
            except Exception:                                # noqa: BLE001
                pass

    def flush(self):
        for a in self.aliran:
            try:
                a.flush()
            except Exception:                                # noqa: BLE001
                pass


def main(argv=None):
    os.makedirs("ui_dumps", exist_ok=True)
    _log = open(os.path.join("ui_dumps", "pilih_log.txt"), "w",
                encoding="utf-8", errors="replace")
    sys.stdout = _Tee(sys.__stdout__, _log)
    sys.stderr = _Tee(sys.__stderr__, _log)
    ap = argparse.ArgumentParser()
    ap.add_argument("--profil", default="mbip-production")
    ap.add_argument("--jenis", default="semua",
                    choices=["notis", "pelbagai", "trafik", "kedua",
                             "semua"])
    args = ap.parse_args(argv)
    os.environ["MBIP_PROFILE"] = args.profil

    from appium import webdriver
    from appium.options.android import UiAutomator2Options
    from config import (APPIUM_URL, APP_PACKAGE, APP_ACTIVITY, DEVICE_NAME,
                        PLATFORM_NAME, AUTOMATION_NAME, IMPLICIT_WAIT,
                        USERNAME, PASSWORD)
    from device_utils import resolve_udid
    from pages.login_page import LoginPage
    from pages.home_page import HomePage
    from pages.daftar_kompaun_page import DaftarKompaunPage
    from pages.notis_amaran_page import NotisAmaranPage
    from testdata.excel_data import TC_DATA
    from testdata.trafik_v2 import TRAFIK_V2

    udid = resolve_udid(APP_PACKAGE)
    options = UiAutomator2Options()
    options.device_name = DEVICE_NAME
    options.set_capability("udid", udid)
    options.platform_name = PLATFORM_NAME
    options.app_package = APP_PACKAGE
    options.app_activity = APP_ACTIVITY
    options.no_reset = True
    options.full_reset = False
    options.automation_name = AUTOMATION_NAME
    options.set_capability("disableAndroidWatchers", True)
    driver = webdriver.Remote(APPIUM_URL, options=options)
    driver.implicitly_wait(IMPLICIT_WAIT)

    keputusan = {}

    try:
        login = LoginPage(driver)
        home = HomePage(driver)
        daftar = DaftarKompaunPage(driver)
        notis = NotisAmaranPage(driver)

        def _sesi_baru():
            login._force_relaunch_to_login()
            login.login(USERNAME, PASSWORD)

        mula_semua = time.monotonic()

        # ---------- FASA NOTIS ----------
        if args.jenis in ("notis", "kedua", "semua"):
            print("\n[PILIH] ===== FASA NOTIS (N-001, 3 tier) =====")
            t0 = time.monotonic()
            try:
                _sesi_baru()
                data = TC_DATA["MBIP-TC-N-001"]
                home.open_notis_amaran()
                notis.fill_pesalah_tab(data)
                notis.click_seterusnya_from_pesalah()
                time.sleep(2)
                login.dismiss_native_alerts(first_timeout=2,
                                            context="pilih-notis")
                # PANGGILAN SEBENAR — laluan sama seperti run penuh.
                notis.fill_kompaun_code_fields(data)
                keputusan["notis"] = "LULUS"
            except Exception as e:                           # noqa: BLE001
                keputusan["notis"] = f"GAGAL: {type(e).__name__}: {e}"
            print(f"[PILIH] fasa notis: {keputusan['notis']} "
                  f"({time.monotonic() - t0:.0f}s)")

        # ---------- FASA PELBAGAI ----------
        if args.jenis in ("pelbagai", "kedua", "semua"):
            print("\n[PILIH] ===== FASA PELBAGAI (P-001, 3 tier) =====")
            t0 = time.monotonic()
            try:
                _sesi_baru()
                data = TC_DATA["MBIP-TC-P-001"]
                home.open_daftar_kompaun()
                daftar.select_jenis_kompaun("Kompaun Pelbagai")
                daftar.fill_pesalah_tab(data)
                daftar.click_seterusnya_from_pesalah()
                time.sleep(2)
                login.dismiss_native_alerts(first_timeout=2,
                                            context="pilih-pelbagai")
                # PANGGILAN SEBENAR — laluan sama seperti run penuh.
                daftar.fill_kompaun_code_fields(data)
                keputusan["pelbagai"] = "LULUS"
            except Exception as e:                           # noqa: BLE001
                keputusan["pelbagai"] = f"GAGAL: {type(e).__name__}: {e}"
            print(f"[PILIH] fasa pelbagai: {keputusan['pelbagai']} "
                  f"({time.monotonic() - t0:.0f}s)")

        # ---------- FASA TRAFIK (letak kereta) ----------
        # Data KUNCI CEO (TRAFIK_V2 — DATA-UJIAN-KOMPAUN-TRAFIK-MBIP.md):
        # JYX6605, tier1 'Akta Jalan Parit dan Bangunan', akta 62,
        # kesalahan=None -> PILIH BARIS PERTAMA ("pilih yang atas"),
        # kadar denda RM200. Laluan SEBENAR yang sama K-001 guna.
        if args.jenis in ("trafik", "semua"):
            print("\n[PILIH] ===== FASA TRAFIK (K-001, data kunci CEO) "
                  "=====")
            t0 = time.monotonic()
            try:
                _sesi_baru()
                data = dict(TC_DATA["MBIP-TC-K-001"])
                data.update(TRAFIK_V2)
                home.open_daftar_kompaun()
                daftar.select_jenis_kompaun_trafik()
                # >>> 2026-08-27 (log #12): no_reset=True — app buka
                # semula DRAF run sebelum (kadang terus di tab-2).
                # Kesan draf: kalau penanda tab-2 kelihatan, SKIP
                # pesalah (corak K-005) dan terus ke tier. <<<
                from appium.webdriver.common.appiumby import \
                    AppiumBy as _AB2
                _tab2 = any(daftar.is_element_present(
                    (_AB2.ANDROID_UIAUTOMATOR,
                     f'new UiSelector().textContains("{t}")'), timeout=3)
                    for t in ("KETERANGAN KOD KOMPAUN", "PILIH AKTA"))
                if _tab2:
                    print("[PILIH] draf tab-2 dikesan — skip pesalah "
                          "(no_reset)")
                else:
                    daftar.fill_pesalah_tab_trafik_v2(data)
                try:
                    if not _tab2:
                        daftar.click_seterusnya_from_pesalah()
                except Exception:
                    # Modal 'MAKLUMAT TIDAK LENGKAP' menyekat — tekan
                    # OK, dump keadaan borang selepas modal ditutup
                    # (bukti medan mana kosong), dan naikkan semula.
                    from appium.webdriver.common.appiumby import \
                        AppiumBy as _AB
                    ok = (_AB.ANDROID_UIAUTOMATOR,
                          'new UiSelector().text("OK")')
                    if daftar.is_element_present(ok, timeout=3):
                        daftar.tap_element(
                            driver.find_element(*ok))
                        time.sleep(1)
                        p = os.path.join("ui_dumps",
                                         "trafik_selepas_modal.xml")
                        with open(p, "w", encoding="utf-8") as f:
                            f.write(driver.page_source)
                        print(f"[PILIH] modal ditutup; dump -> {p}")
                    raise
                time.sleep(2)
                login.dismiss_native_alerts(first_timeout=2,
                                            context="pilih-trafik")
                # PANGGILAN SEBENAR — laluan sama seperti run penuh.
                daftar.fill_kompaun_code_fields_trafik_v2(data)
                keputusan["trafik"] = "LULUS"
            except Exception as e:                           # noqa: BLE001
                keputusan["trafik"] = f"GAGAL: {type(e).__name__}: {e}"
            print(f"[PILIH] fasa trafik: {keputusan['trafik']} "
                  f"({time.monotonic() - t0:.0f}s)")

        # ---------- RUMUSAN ----------
        print("\n[PILIH] ===== RUMUSAN VALIDASI =====")
        for nama, hasil in keputusan.items():
            print(f"[PILIH]   {nama:9s} -> {hasil}")
        print(f"[PILIH] jumlah masa: "
              f"{(time.monotonic() - mula_semua) / 60:.1f} minit")
        print("[PILIH] TIADA rekod dicipta (tiada HANTAR ditekan).")
        semua_lulus = keputusan and all(
            h == "LULUS" for h in keputusan.values())
        print(f"[PILIH] STATUS AKHIR: "
              f"{'SEMUA LULUS — fix disahkan' if semua_lulus else 'ADA GAGAL — lihat log + ui_dumps'}")
        return 0 if semua_lulus else 1
    finally:
        try:
            driver.quit()
        except Exception:                                    # noqa: BLE001
            pass


if __name__ == "__main__":
    sys.exit(main())

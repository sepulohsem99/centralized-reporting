#!/usr/bin/env python3
"""DEBUG INTERAKTIF dropdown KESALAHAN (N-001) — langkah demi langkah.

>>> DIBINA 2026-08-25. Konteks: tier-1 (PILIH KOMPAUN) dan tier-2
(PILIH AKTA) berjaya dipilih, tetapi tier-3 (PILIH KESALAHAN) gagal 4
run berturut — dump selepas-gagal sentiasa menunjukkan senarai TERTUTUP.
Tool ini sampai ke tier-3, kemudian melakukan SATU aksi pada satu masa
(buka, taip, hide keyboard, swipe, scrollIntoView) dan mengambil
snapshot XML + kiraan baris SELEPAS SETIAP AKSI — supaya kita nampak
aksi mana yang menutup/menghilangkan senarai. TIADA Simpan/Hantar. <<<

Guna:
    python tools\\debug_dropdown.py --profil mbip-production
"""
import argparse
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
AKAR = os.path.dirname(HERE)
sys.path.insert(0, AKAR)
os.chdir(AKAR)


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--profil", default="mbip-production")
    args = ap.parse_args(argv)
    os.environ["MBIP_PROFILE"] = args.profil

    from appium import webdriver
    from appium.options.android import UiAutomator2Options
    from appium.webdriver.common.appiumby import AppiumBy
    from config import (APPIUM_URL, APP_PACKAGE, APP_ACTIVITY, DEVICE_NAME,
                        PLATFORM_NAME, AUTOMATION_NAME, IMPLICIT_WAIT,
                        USERNAME, PASSWORD)
    from device_utils import resolve_udid
    from pages.login_page import LoginPage
    from pages.home_page import HomePage
    from pages.notis_amaran_page import NotisAmaranPage
    from testdata.excel_data import TC_DATA

    udid = resolve_udid(APP_PACKAGE)
    options = UiAutomator2Options()
    options.device_name = DEVICE_NAME
    options.set_capability("udid", udid)
    options.platform_name = PLATFORM_NAME
    options.app_package = APP_PACKAGE
    options.app_activity = APP_ACTIVITY
    options.no_reset = True
    options.full_reset = False
    options.automation_name = AUTOMATION_NAME
    options.set_capability("disableAndroidWatchers", True)
    driver = webdriver.Remote(APPIUM_URL, options=options)
    driver.implicitly_wait(IMPLICIT_WAIT)
    os.makedirs("ui_dumps", exist_ok=True)

    SASARAN = "MEMOTONG"    # perkataan pertama kesalahan N-001

    def snapshot(tag):
        """Dump XML + kiraan pantas keadaan senarai."""
        p = os.path.join("ui_dumps", f"dd_{tag}.xml")
        src = driver.page_source
        with open(p, "w", encoding="utf-8") as f:
            f.write(src)
        baris = driver.find_elements(
            AppiumBy.ANDROID_UIAUTOMATOR,
            'new UiSelector().className("android.view.ViewGroup")'
            '.clickable(true)')
        baris_desc = [b for b in baris
                      if len((b.get_attribute("content-desc") or "")) > 15]
        sasar = driver.find_elements(
            AppiumBy.ANDROID_UIAUTOMATOR,
            f'new UiSelector().descriptionMatches("(?i).*{SASARAN}.*")')
        skrol = driver.find_elements(
            AppiumBy.ANDROID_UIAUTOMATOR,
            'new UiSelector().scrollable(true)')
        try:
            kb = driver.is_keyboard_shown()
        except Exception:                                    # noqa: BLE001
            kb = "?"
        print(f"  [SNAP {tag}] baris-desc={len(baris_desc)} "
              f"sasaranMEMOTONG={len(sasar)} scrollable={len(skrol)} "
              f"keyboard={kb} -> {p}")
        for b in baris_desc[:5]:
            print(f"      baris: {(b.get_attribute('content-desc') or '')[:70]!r}")
        return len(sasar)

    try:
        login = LoginPage(driver)
        home = HomePage(driver)
        notis = NotisAmaranPage(driver)
        data = TC_DATA["MBIP-TC-N-001"]

        login._force_relaunch_to_login()
        login.login(USERNAME, PASSWORD)
        home.open_notis_amaran()
        notis.fill_pesalah_tab(data)
        notis.click_seterusnya_from_pesalah()
        notis.fill_notis_tab(data)

        # tier-1 & tier-2 — laluan terbukti
        pilih_akta = (AppiumBy.ANDROID_UIAUTOMATOR,
                      f'new UiSelector().text("{notis.PLACEHOLDER_PILIH_AKTA}")')
        pilih_kesalahan = (AppiumBy.ANDROID_UIAUTOMATOR,
                           f'new UiSelector().text('
                           f'"{notis.PLACEHOLDER_PILIH_KESALAHAN}")')
        notis.select_dropdown_option_and_confirm(
            notis.PLACEHOLDER_PILIH_KOMPAUN, data["keterangan_kod_kompaun"],
            confirm_locator=pilih_akta)
        notis.select_dropdown_option_and_confirm(
            notis.PLACEHOLDER_PILIH_AKTA, data["kod_akta"],
            confirm_locator=pilih_kesalahan)
        print("\n" + "=" * 66)
        print("  TIER-3 (PILIH KESALAHAN) — EKSPERIMEN LANGKAH DEMI LANGKAH")
        print("=" * 66)

        snapshot("00_sebelum_buka")

        # >>> v2 2026-08-25: eksperimen v1 membuktikan (a) swipe semasa
        # keyboard terbuka MENAIP hurufan ('t5 t5 t5') merosakkan
        # penapis, dan (b) senarai kesalahan hanya render baris SELEPAS
        # penapis ditaip. v2: taip penapis BERSIH satu demi satu dan
        # CETAK semua baris yang muncul — untuk tahu sama ada data
        # kesalahan UUK 7 wujud dan dengan perkataan apa. <<<
        medan = notis.find_clickable(pilih_kesalahan, timeout=10)
        notis.tap_element(medan)
        time.sleep(1.2)
        n = snapshot("01_selepas_buka")

        def medan_kesalahan():
            # selepas taip, teks field berubah — cari EditText di bawah
            # label KESALAHAN KOMPAUN secara geometri
            lab = driver.find_element(
                AppiumBy.ANDROID_UIAUTOMATOR,
                'new UiSelector().textContains("KESALAHAN KOMPAUN")')
            ly = lab.rect["y"]
            calon = [e for e in driver.find_elements(
                        AppiumBy.CLASS_NAME, "android.widget.EditText")
                     if e.rect["y"] >= ly]
            calon.sort(key=lambda e: e.rect["y"] - ly)
            return calon[0]

        def cuba_penapis(teks, tag):
            el = medan_kesalahan()
            el.click()
            notis._force_clear(el)
            time.sleep(0.4)
            driver.execute_script("mobile: type", {"text": teks})
            time.sleep(1.2)
            baca = el.text
            rows = driver.find_elements(
                AppiumBy.ANDROID_UIAUTOMATOR,
                'new UiSelector().className("android.view.ViewGroup")'
                '.clickable(true)')
            senarai = [(r.get_attribute("content-desc") or "")
                       for r in rows]
            senarai = [s for s in senarai if len(s) > 15]
            tiada = driver.find_elements(
                AppiumBy.ANDROID_UIAUTOMATOR,
                'new UiSelector().textContains("Tiada rekod")')
            print(f"  [PENAPIS {teks!r}] field={baca!r} baris="
                  f"{len(senarai)} tiada_rekod={'YA' if tiada else 'tidak'}")
            for s in senarai[:8]:
                print(f"      >> {s[:90]!r}")
            snapshot(tag)
            return senarai

        # >>> v3 2026-08-25: v2 membuktikan field kesalahan di DASAR
        # viewport — dengan keyboard terbuka (viewport tamat 1596),
        # senarai keputusan TIADA ruang untuk render. dd_07 v1
        # membuktikan selepas hide_keyboard viewport mengembang ke 2316
        # dan area senarai muncul. Urutan betul: taip -> HIDE KEYBOARD
        # -> baca senarai. <<<
        def hide_kb():
            try:
                if driver.is_keyboard_shown():
                    driver.hide_keyboard()
                    time.sleep(0.8)
            except Exception:                                # noqa: BLE001
                pass

        def cuba_penapis_v3(teks, tag):
            senarai = cuba_penapis(teks, tag + "_kb")
            hide_kb()
            rows = driver.find_elements(
                AppiumBy.ANDROID_UIAUTOMATOR,
                'new UiSelector().className("android.view.ViewGroup")'
                '.clickable(true)')
            senarai = [(r.get_attribute("content-desc") or "")
                       for r in rows]
            senarai = [s for s in senarai if len(s) > 15]
            print(f"  [PENAPIS-v3 {teks!r}] SELEPAS hide_keyboard: "
                  f"baris={len(senarai)}")
            for s in senarai[:8]:
                print(f"      >> {s[:90]!r}")
            snapshot(tag)
            return senarai

        r2 = cuba_penapis_v3("MEMOTONG", "21_MEMOTONG_nokb")
        if any("MEMOTONG" in s.upper() for s in r2):
            print("\n  >> BARIS SASARAN DITEMUI — mencuba TAP...")
            row = driver.find_element(
                AppiumBy.ANDROID_UIAUTOMATOR,
                'new UiSelector().descriptionMatches("(?i).*MEMOTONG.*")')
            notis.tap_element(row)
            time.sleep(1.2)
            snapshot("22_selepas_tap")
            masih = driver.find_elements(
                AppiumBy.ANDROID_UIAUTOMATOR,
                'new UiSelector().textContains("PILIH KESALAHAN")')
            kamera = driver.find_elements(
                AppiumBy.ACCESSIBILITY_ID, "OPEN CAMERA")
            print(f"  [TAP] placeholder PILIH KESALAHAN masih ada: "
                  f"{'YA' if masih else 'TIDAK'} | OPEN CAMERA kelihatan: "
                  f"{'YA' if kamera else 'tidak'}")
            print("\n  >> URUTAN MENANG: taip perkataan pertama -> hide "
                  "keyboard -> tap baris. Sedia diport ke suite.")
            return 0
        r1 = cuba_penapis_v3("M", "23_M_nokb")
        r3 = cuba_penapis_v3("BUNGA", "24_BUNGA_nokb")
        r4 = []
        if r2 or r3 or r4:
            print("\n  >> BARIS WUJUD dengan penapis bersih — masalah "
                  "run sebenar = penapis 25-aksara/koma. Fix mudah.")
        elif r1:
            print("\n  >> Baris wujud untuk 'M' tetapi bukan perkataan "
                  "kesalahan kita — DATA kesalahan UUK 7 berbeza dari "
                  "Excel. Senarai di atas = pilihan sebenar.")
        else:
            print("\n  >> TIADA baris untuk semua penapis — senarai "
                  "kesalahan akta ini KOSONG dalam data server "
                  "(isu app/data, bukan script).")
        return 0
        n = snapshot("01_selepas_buka_x")

        # LANGKAH 2: swipe sebenar x1 (TANPA taip, TANPA hide keyboard)
        size = driver.get_window_size()
        driver.swipe(size["width"] // 2, int(size["height"] * 0.75),
                     size["width"] // 2, int(size["height"] * 0.35), 600)
        time.sleep(0.8)
        n = snapshot("02_selepas_swipe1")

        # LANGKAH 3: swipe x2 lagi
        for i in range(2):
            driver.swipe(size["width"] // 2, int(size["height"] * 0.75),
                         size["width"] // 2, int(size["height"] * 0.35), 600)
            time.sleep(0.6)
        n = snapshot("03_selepas_swipe3")

        if n:
            print("\n  >> SASARAN KELIHATAN selepas swipe — mekanisme "
                  "betul: buka + swipe TANPA taip/hide_keyboard. Cuba "
                  "tap terus...")
            row = driver.find_element(
                AppiumBy.ANDROID_UIAUTOMATOR,
                f'new UiSelector().descriptionMatches("(?i).*{SASARAN}.*")')
            notis.tap_element(row)
            time.sleep(1)
            snapshot("04_selepas_tap_baris")
            return 0

        # LANGKAH 4: scrollIntoView pada setiap scrollable instance
        for inst in (1, 2, 0):
            cmd = (f'new UiScrollable(new UiSelector().scrollable(true)'
                   f'.instance({inst})).scrollIntoView(new UiSelector()'
                   f'.descriptionMatches("(?i).*{SASARAN}.*"));')
            try:
                driver.find_element(AppiumBy.ANDROID_UIAUTOMATOR, cmd)
                print(f"  scrollIntoView instance({inst}) BERJAYA")
                break
            except Exception as e:                           # noqa: BLE001
                print(f"  scrollIntoView instance({inst}): "
                      f"{type(e).__name__}")
        n = snapshot("05_selepas_scrollintoview")

        # LANGKAH 5: taip penapis (kali PERTAMA dalam eksperimen)
        driver.execute_script("mobile: type", {"text": SASARAN})
        time.sleep(1)
        n = snapshot("06_selepas_taip")

        # LANGKAH 6: hide keyboard — SUSPEK menutup senarai
        try:
            if driver.is_keyboard_shown():
                driver.hide_keyboard()
                time.sleep(0.8)
        except Exception:                                    # noqa: BLE001
            pass
        snapshot("07_selepas_hide_keyboard")

        print("\n[DD] SELESAI — hantar semua output console + "
              "ui_dumps\\dd_*.xml kepada prometheus")
        return 0
    finally:
        driver.quit()


if __name__ == "__main__":
    sys.exit(main())

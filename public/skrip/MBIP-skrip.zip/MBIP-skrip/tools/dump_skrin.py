#!/usr/bin/env python3
"""Dump skrin semasa app (via Appium) — siasatan popup versi."""
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
AKAR = os.path.dirname(HERE)
sys.path.insert(0, AKAR)
os.chdir(AKAR)
os.environ["MBIP_PROFILE"] = "mbip-production"

from appium import webdriver
from appium.options.android import UiAutomator2Options
from config import (APPIUM_URL, APP_PACKAGE, APP_ACTIVITY, DEVICE_NAME,
                    PLATFORM_NAME, AUTOMATION_NAME)
from device_utils import resolve_udid

udid = resolve_udid(APP_PACKAGE)
o = UiAutomator2Options()
o.device_name = DEVICE_NAME
o.set_capability("udid", udid)
o.platform_name = PLATFORM_NAME
o.app_package = APP_PACKAGE
o.app_activity = APP_ACTIVITY
o.no_reset = True
o.automation_name = AUTOMATION_NAME
d = webdriver.Remote(APPIUM_URL, options=o)
try:
    time.sleep(10)
    xml = d.page_source
    with open("ui_dumps/versi_dump.xml", "w", encoding="utf-8") as f:
        f.write(xml)
    import re
    teks = sorted(set(re.findall(r'text="([^"]+)"', xml)))
    print("[DUMP] teks di skrin:")
    for t in teks:
        print("   ", t[:90])
finally:
    d.quit()

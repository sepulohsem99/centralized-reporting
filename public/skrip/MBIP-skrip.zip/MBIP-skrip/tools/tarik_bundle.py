#!/usr/bin/env python3
"""TARIK BUNDLE — keluarkan bundle JS React Native dari APK di telefon.

>>> DIBINA 2026-08-27 atas arahan CEO ("masuk terus dalam apk tu dan
belek satu persatu"). Folder source yang di-mount kosong; sumber
kebenaran yang pasti ada ialah APK yang TERPASANG di telefon. Tool ini:
  1. adb shell pm path <pkg>  -> lokasi APK
  2. adb pull APK -> ui_dumps/app.apk
  3. unzip assets/index.android.bundle -> ui_dumps/bundle.js
Bundle mengandungi SEMUA skrin/validasi/nama medan app — dianalisis
offline tanpa sebarang run Appium lagi. BACA-SAHAJA, tiada tulisan
ke telefon. <<<

Guna:
    python tools\\tarik_bundle.py --profil mbip-production
"""
import argparse
import os
import subprocess
import sys
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
AKAR = os.path.dirname(HERE)
sys.path.insert(0, AKAR)
os.chdir(AKAR)


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--profil", default="mbip-production")
    args = ap.parse_args(argv)
    os.environ["MBIP_PROFILE"] = args.profil

    from config import APP_PACKAGE
    from device_utils import resolve_udid

    serial = resolve_udid(APP_PACKAGE)
    os.makedirs("ui_dumps", exist_ok=True)

    p = subprocess.run(["adb", "-s", serial, "shell", "pm", "path",
                        APP_PACKAGE], capture_output=True, text=True)
    laluan = [ln.split(":", 1)[1].strip() for ln in p.stdout.splitlines()
              if ln.startswith("package:")]
    if not laluan:
        print("[BUNDLE] GAGAL: pm path kosong:", p.stderr[:200])
        return 1
    apk_dev = laluan[0]
    print(f"[BUNDLE] APK di telefon: {apk_dev}")

    apk_lokal = os.path.join("ui_dumps", "app.apk")
    p = subprocess.run(["adb", "-s", serial, "pull", apk_dev, apk_lokal],
                       capture_output=True, text=True)
    if p.returncode != 0 or not os.path.exists(apk_lokal):
        print("[BUNDLE] GAGAL pull:", (p.stderr or p.stdout)[:300])
        return 1
    print(f"[BUNDLE] APK ditarik: {apk_lokal} "
          f"({os.path.getsize(apk_lokal):,} bait)")

    with zipfile.ZipFile(apk_lokal) as z:
        nama = [n for n in z.namelist() if n.endswith(".bundle")
                or "index.android" in n]
        print(f"[BUNDLE] calon bundle dalam APK: {nama[:5]}")
        if not nama:
            print("[BUNDLE] GAGAL: tiada .bundle dalam APK "
                  "(mungkin Hermes .hbc — senarai assets/):")
            print([n for n in z.namelist()
                   if n.startswith("assets/")][:20])
            return 1
        sasar = nama[0]
        ke = os.path.join("ui_dumps", "bundle.js")
        with z.open(sasar) as fin, open(ke, "wb") as fout:
            fout.write(fin.read())
        print(f"[BUNDLE] SIAP: {sasar} -> {ke} "
              f"({os.path.getsize(ke):,} bait)")
    return 0


if __name__ == "__main__":
    sys.exit(main())

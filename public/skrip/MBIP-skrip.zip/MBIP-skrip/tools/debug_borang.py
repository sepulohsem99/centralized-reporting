#!/usr/bin/env python3
"""RECON borang build 2.1.17 hotfix — dump XML tab KOMPAUN/NOTIS.

>>> DIBINA 2026-08-24 selepas run penuh #2 (10P/22F/16S): kesemua
kegagalan create (P/K/L/S-001) berpunca dari label tab Kompaun yang
berubah dalam build hotfix ('LOKASI KESALAHAN', 'Maklumat Taman' tiada
lagi). Tool ini login sekali, buka SETIAP jenis borang, isi TIADA APA,
tap terus header tab kedua (PESALAH -> KOMPAUN/NOTIS), dan dump XML —
bukti untuk membetulkan locator dengan tepat. TIADA rekod dicipta. <<<

Guna:
    python tools\\debug_borang.py --profil mbip-production
"""
import argparse
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
AKAR = os.path.dirname(HERE)
sys.path.insert(0, AKAR)
os.chdir(AKAR)


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--profil", default="mbip-production")
    args = ap.parse_args(argv)
    os.environ["MBIP_PROFILE"] = args.profil

    from appium import webdriver
    from appium.options.android import UiAutomator2Options
    from appium.webdriver.common.appiumby import AppiumBy
    from config import (APPIUM_URL, APP_PACKAGE, APP_ACTIVITY, DEVICE_NAME,
                        PLATFORM_NAME, AUTOMATION_NAME, IMPLICIT_WAIT,
                        USERNAME, PASSWORD)
    from device_utils import resolve_udid
    from pages.login_page import LoginPage
    from pages.home_page import HomePage
    from pages.daftar_kompaun_page import DaftarKompaunPage
    from pages.kompaun_lesen_page import KompaunLesenPage
    from pages.sitaan_page import SitaanPage
    from pages.notis_amaran_page import NotisAmaranPage
    from testdata.excel_data import TC_DATA
    from testdata.trafik_v2 import TRAFIK_V2

    udid = resolve_udid(APP_PACKAGE)
    options = UiAutomator2Options()
    options.device_name = DEVICE_NAME
    options.set_capability("udid", udid)
    options.platform_name = PLATFORM_NAME
    options.app_package = APP_PACKAGE
    options.app_activity = APP_ACTIVITY
    options.no_reset = True
    options.full_reset = False
    options.automation_name = AUTOMATION_NAME
    options.set_capability("disableAndroidWatchers", True)
    driver = webdriver.Remote(APPIUM_URL, options=options)
    driver.implicitly_wait(IMPLICIT_WAIT)

    os.makedirs("ui_dumps", exist_ok=True)

    def dump(nama):
        p = os.path.join("ui_dumps", nama)
        with open(p, "w", encoding="utf-8") as f:
            f.write(driver.page_source)
        print(f"  [RECON] dump -> {p}")

    def tap_teks(page, teks, timeout=6):
        loc = (AppiumBy.ANDROID_UIAUTOMATOR,
               f'new UiSelector().text("{teks}")')
        try:
            page.tap_element(page.find_element(loc, timeout=timeout))
            time.sleep(1.5)
            return True
        except Exception as e:                               # noqa: BLE001
            print(f"  [RECON] tap '{teks}' gagal: {type(e).__name__}")
            return False

    try:
        login = LoginPage(driver)
        home = HomePage(driver)
        daftar = DaftarKompaunPage(driver)
        lesen = KompaunLesenPage(driver)
        sitaan = SitaanPage(driver)
        notis = NotisAmaranPage(driver)

        login._force_relaunch_to_login()
        login.login(USERNAME, PASSWORD)

        # v2 2026-08-24: tab kedua DISEKAT validation ("SILA LENGKAPKAN
        # MAKLUMAT DI TAB PESALAH DAHULU") — recon kini mengisi tab
        # Pesalah dengan helper SAMA yang terbukti dalam run penuh #2,
        # tekan SETERUSNYA, baru dump tab kedua. Tiada HANTAR ditekan —
        # tiada rekod dicipta.
        data_k = dict(TC_DATA["MBIP-TC-K-001"])
        data_k.update(TRAFIK_V2)
        borang = [
            ("pelbagai",
             lambda: (home.open_daftar_kompaun(),
                      daftar.select_jenis_kompaun("Kompaun Pelbagai"),
                      daftar.fill_pesalah_tab(TC_DATA["MBIP-TC-P-001"]),
                      daftar.click_seterusnya_from_pesalah())),
            ("trafik",
             lambda: (home.open_daftar_kompaun(),
                      daftar.select_jenis_kompaun_trafik(),
                      daftar.fill_pesalah_tab_trafik_v2(data_k),
                      daftar.click_seterusnya_from_pesalah())),
            ("lesen",
             lambda: (home.open_daftar_kompaun(),
                      lesen.select_jenis_kompaun_lesen(),
                      lesen.fill_pesalah_tab_lesen(
                          TC_DATA["MBIP-TC-L-001"]),
                      lesen.click_seterusnya_from_pesalah())),
            ("sitaan",
             lambda: (home.open_daftar_kompaun(),
                      sitaan.select_jenis_sitaan(),
                      sitaan.fill_pesalah_tab_lesen(
                          TC_DATA["MBIP-TC-S-001"]),
                      sitaan.click_seterusnya_from_pesalah())),
            ("notis",
             lambda: (home.open_notis_amaran(),
                      notis.fill_pesalah_tab(TC_DATA["MBIP-TC-N-001"]),
                      notis.click_seterusnya_from_pesalah())),
        ]
        for nama, buka in borang:
            print(f"\n[RECON] === borang {nama.upper()} ===")
            try:
                buka()
                time.sleep(2)
                login.dismiss_native_alerts(first_timeout=2,
                                            context=f"recon-{nama}")
                dump(f"recon_{nama}_tab2.xml")
            except Exception as e:                           # noqa: BLE001
                print(f"  [RECON] borang {nama} gagal: "
                      f"{type(e).__name__}: {e}")
                dump(f"recon_{nama}_gagal.xml")
            # balik ke home: relaunch bersih + login semula (paling pasti)
            try:
                login._force_relaunch_to_login()
                login.login(USERNAME, PASSWORD)
            except Exception as e:                           # noqa: BLE001
                print(f"  [RECON] relogin gagal: {type(e).__name__} — "
                      f"berhenti")
                break
        print("\n[RECON] SELESAI — semua dump dalam ui_dumps\\recon_*.xml")
        return 0
    finally:
        driver.quit()


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
"""Orkestrator run penuh MBIP — aliran kerja sama seperti MBPG.

>>> DIBINA 2026-08-21 (server production down) — diport daripada
tools/run_penuh.py MBPG yang terbukti pada run 9-14. <<<

Aliran (keputusan CEO: "Workflow MBIP (nak)" = macam MBPG):

    1. --bersih : pm clear + pm grant semua permission + lancar app
                  & tunggu DB dicipta        (tools/sedia_peranti.py)
    2. gerbang siri: halang nombor rekod bertembung selepas clear;
                  auto-majukan kaunter (kelulusan pemilik 2026-08-20,
                  awalan MBIP diterbitkan dari rekod sebenar)
                                             (tools/semak_siri.py)
    3. pytest tests/ — suite 48 TC v3 penuh. conftest v3 sudah
       menjalankan Menu Selaras (termasuk Selaras Pengguna Apps)
       SEBELUM login, jadi keadaan pasca-clear selamat; login_page
       pula ada retry berjeda untuk penolakan kredensial transien.
    4. Hasil: reports/results.json + reports/history/*.json (dashboard)
       + jadual ringkasan pytest. Nombor rekod dicipta dilog oleh
       record_artifact + tools/rekod_log (untuk PM cancel).

Guna:
    python tools\\run_penuh_mbip.py --bersih                 # penuh
    python tools\\run_penuh_mbip.py --bersih -k "k_001"      # satu TC
    python tools\\run_penuh_mbip.py --tanpa-bersih           # tanpa clear
"""
import argparse
import os
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
AKAR = os.path.dirname(HERE)
sys.path.insert(0, AKAR)
os.chdir(AKAR)


def main(argv=None):
    ap = argparse.ArgumentParser(description="Run penuh MBIP (e2e macam MBPG)")
    g = ap.add_mutually_exclusive_group()
    g.add_argument("--bersih", action="store_true", default=True,
                   help="clear data + grant permission dahulu (LALAI — "
                        "aliran kerja rasmi CEO)")
    g.add_argument("--tanpa-bersih", dest="bersih", action="store_false",
                   help="langkau clear/grant (guna keadaan sedia ada)")
    ap.add_argument("--profil", default="mbip-production",
                    help="profil dalam profiles/ (lalai: mbip-production)")
    ap.add_argument("-k", dest="penapis", default=None,
                    help="penapis pytest -k (cth 'k_001')")
    ap.add_argument("--terus", action="store_true",
                    help="langkau pengesahan YA")
    args = ap.parse_args(argv)

    os.environ["MBIP_PROFILE"] = args.profil

    print("=" * 70)
    print("== RUN PENUH MBIP — e2e aliran kerja MBPG")
    print("=" * 70)
    print(f"  profil        : {args.profil}")
    print(f"  sedia peranti : "
          f"{'CLEAR DATA + GRANT PERMISSION dahulu' if args.bersih else 'TIDAK (tanpa-bersih)'}")
    print(f"  penapis       : {args.penapis or '(semua 48 TC)'}")
    if "production" in args.profil:
        print("  !! PRODUCTION — rekod SEBENAR akan dicipta. PM boleh "
              "cancel (kelulusan CEO 2026-08-21).")
    if not args.terus:
        if input("  Taip YA untuk teruskan: ").strip().upper() != "YA":
            print("  Dibatalkan.")
            return 1

    from device_utils import resolve_udid
    from config import APP_PACKAGE
    serial = resolve_udid(APP_PACKAGE)

    # ---- (1) sedia peranti --------------------------------------------
    if args.bersih:
        from tools import sedia_peranti
        t0 = time.time()
        ok_sp, nota_sp = sedia_peranti.sedia(serial)
        print(f"[{'OK ' if ok_sp else '!! '}] sedia peranti: "
              f"{'LULUS' if ok_sp else 'GAGAL'} "
              f"({time.time() - t0:.1f}s) — {nota_sp}")
        if not ok_sp:
            print("HENTI: permission tidak lengkap selepas grant.")
            return 2

    # ---- (2) gerbang siri ---------------------------------------------
    from tools import semak_siri
    try:
        nota_siri = semak_siri.gerbang(serial, baiki=True)
        print(f"[OK ] gerbang siri: {nota_siri}")
    except Exception as e:                                  # noqa: BLE001
        print("!" * 70)
        print(f"HENTI (gerbang siri): {e}")
        print("!" * 70)
        return 2

    # ---- (3) pytest ----------------------------------------------------
    cmd = [sys.executable, "-m", "pytest", "tests/", "-v", "-s",
           "--tb=short"]
    if args.penapis:
        cmd += ["-k", args.penapis]
    print(f"\n  pytest: {' '.join(cmd)}\n")
    rc = subprocess.call(cmd)

    print("\n" + "=" * 70)
    print("== SELESAI — hasil:")
    print("     reports\\results.json          (dashboard)")
    print("     reports\\history\\*.json        (sejarah run)")
    print("     reports\\REKOD-SEBENAR-*.md    (log rekod untuk PM)")
    print("=" * 70)
    return rc


if __name__ == "__main__":
    sys.exit(main())

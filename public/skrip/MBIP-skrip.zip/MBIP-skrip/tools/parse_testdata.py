"""
Hurai sel "Test Data" Excel menjadi struktur bernama.

KENAPA
------
Data ujian berbeza antara PBT — bukan sekadar nama, tetapi alamat. Setiap
majlis hanya ada jalan dan taman kawasannya sendiri dalam pangkalan data,
jadi borang MBIP yang diisi dengan alamat Pasir Gudang akan gagal pada
autocomplete. Disahkan: 23 daripada 47 TC berbeza Test Data antara MBIP
dan MBPG.

Menaip semula data itu untuk setiap PBT secara manual tidak boleh
diskalakan (4 PBT hari ini, lagi banyak kemudian), jadi ia dihurai terus
dari Excel setiap PBT.

FORMAT SUMBER
-------------
Sel Test Data ialah teks separa berstruktur:

    PESALAH - Maklumat Pesalah
    Nama Pesalah: ALI
    No KP: 010123456789
    Maklumat Jalan: JALAN DANGA SUTERA 12/3
    ...
    KOMPAUN - Maklumat Kesalahan
    Maklumat Jalan: JALAN BARAU 1
    ...
    - Maklumat Kompaun
    Tempoh Kompaun: 1
    Kod Akta: ...

Tajuk seksyen menentukan MAKSUD medan: "Maklumat Jalan" di bawah PESALAH
ialah alamat pesalah, tetapi di bawah KOMPAUN ia alamat tempat kesalahan
berlaku. Dua nilai berbeza, label sama — jadi penghurai mesti mengesan
seksyen, bukan sekadar mengumpul pasangan kunci:nilai.

Nama kunci tidak konsisten merentasi sheet dan PBT ("No KP" / "No K/P /
SSM", "Butiran" / "Butiran Kesalahan", "Pilin Kadar Denda" — typo untuk
"Pilih"), jadi setiap satu dinormalkan melalui jadual alias.
"""

import re

# --- Tajuk seksyen -> nama seksyen dalaman -------------------------------
SECTIONS = [
    (re.compile(r"^\s*PESALAH\b", re.I), "pesalah"),
    (re.compile(r"^\s*KOMPAUN\s*-\s*Maklumat\s+Kesalahan", re.I), "kesalahan"),
    (re.compile(r"^\s*-?\s*Maklumat\s+Kompaun\b", re.I), "kompaun"),
    (re.compile(r"^\s*Barang", re.I), "barang"),
    (re.compile(r"^\s*PENERIMA\b", re.I), "penerima"),
]

# --- Alias kunci -> nama medan kanonik -----------------------------------
# Kekunci dinormalkan (huruf kecil, tanda baca dibuang) sebelum dicari.
ALIASES = {
    "nama pesalah": "nama",
    "nama penerima": "nama_penerima",
    "no kp": "no_kp",
    "no k p ssm": "no_kp",
    "no kp ssm": "no_kp",
    "no ic penerima": "no_ic_penerima",
    "no ic": "no_kp",
    "no akuan lesen": "no_akuan_lesen",
    "no kenderaan": "no_kereta",
    "no plate": "no_kereta",
    "warna kenderaan": "warna_kereta",
    "warna kereta": "warna_kereta",
    "maklumat jalan": "jalan",
    "jalan": "jalan",
    "maklumat taman": "taman",
    "taman": "taman",
    "maklumat poskod": "poskod",
    "poskod": "poskod",
    "maklumat bandar": "bandar",
    "bandar": "bandar",
    "maklumat negeri": "negeri",
    "negeri": "negeri",
    "lokasi kesalahan": "lokasi_kesalahan",
    "butiran": "butiran_kesalahan",
    "butiran kesalahan": "butiran_kesalahan",
    "tempoh kompaun": "tempoh",
    "tempoh notis": "tempoh",
    "maklumat kompaun": "tempoh",
    "keterangan kod kompaun": "keterangan_kod_kompaun",
    "kod akta": "kod_akta",
    "kesalahan kompaun": "kesalahan_kompaun",
    "pilih kadar denda": "kadar_denda",
    "pilin kadar denda": "kadar_denda",        # typo dalam Excel sebenar
    "kadar denda": "kadar_denda",
    "amaun": "amaun",
    "ulasan": "ulasan",
    "username": "username",
    "password": "password",
    "id penguatkuasa": "id_penguatkuasa",
    "no pembantu penguatkuasa": "no_pembantu_penguatkuasa",
    "arahan tindakan": "arahan_tindakan",
}

_KEY_RE = re.compile(r"^\s*([^:]{2,60}?)\s*:\s*(.*)$")
_ITEM_RE = re.compile(r"^\s*\d+[.)]\s*(.+?)\s*[-–]\s*(\d+)\s*UNIT", re.I)


def _normalise_value(field, val):
    """Selaraskan nilai kepada bentuk yang lapisan pages jangkakan.

    Excel tidak konsisten merentasi sheet, dan borang aplikasi pula
    mahukan satu bentuk sahaja:
      - Kadar denda ditulis "RM2000" pada satu sheet, "2000" pada sheet
        lain (label "(RM)" membawa unitnya). Borang mahu "RM2000".
      - Tempoh ditulis "1 HARI"; medan borang menerima nombor sahaja.
    """
    if field == "kadar_denda":
        v = val.upper().replace(" ", "")
        if not v.startswith("RM"):
            v = "RM" + v
        return v
    if field == "tempoh":
        m = re.match(r"\s*(\d+)", val)
        return m.group(1) if m else val
    return val


def _norm_key(k):
    k = k.strip().lower()
    k = re.sub(r"\(.*?\)", " ", k)          # buang "(RM)", "(MDJBT)" dll
    k = re.sub(r"[^a-z0-9]+", " ", k)
    return re.sub(r"\s+", " ", k).strip()


def parse(cell):
    """Sel Test Data -> {seksyen: {medan: nilai}}, plus 'barang': [...].

    Baris tanpa ':' diabaikan kecuali dalam seksyen Barang, di mana ia
    membawa item "1. MEJA - 2 UNIT".
    """
    out = {"pesalah": {}, "kesalahan": {}, "kompaun": {},
           "penerima": {}, "barang": []}
    if not cell:
        return out

    section = "pesalah"          # sheet ringkas kadang terus mula tanpa tajuk
    for raw in str(cell).splitlines():
        line = raw.strip()
        if not line:
            continue

        hit = next((name for rx, name in SECTIONS if rx.match(line)), None)
        if hit:
            section = hit
            # Tajuk boleh membawa nilai pada baris yang sama, cth
            # "Maklumat Kompaun: 1 HARI" -- jangan buang.
            m = _KEY_RE.match(line)
            if not (m and _norm_key(m.group(1)) in ALIASES and m.group(2).strip()):
                continue

        if section == "barang":
            m = _ITEM_RE.match(line)
            if m:
                # Tuple, bukan dict: itu bentuk yang lapisan pages
                # sudah terima dalam excel_data.py sedia ada.
                out["barang"].append((m.group(1).strip().upper(),
                                      m.group(2)))
                continue

        m = _KEY_RE.match(line)
        if not m:
            continue
        field = ALIASES.get(_norm_key(m.group(1)))
        val = m.group(2).strip()
        if not field or not val:
            continue
        # Nilai pertama menang: sheet kadang mengulang label yang sama
        # dalam nota di bawah, dan yang di atas ialah data sebenar.
        out[section].setdefault(field, _normalise_value(field, val))

    return out


def is_empty(parsed):
    """Adakah huraian ini benar-benar tiada data?"""
    return not any(parsed[s] for s in ("pesalah", "kesalahan", "kompaun",
                                       "penerima")) and not parsed["barang"]


# TC dengan Test Data "N/A" atau kosong bukan bermakna tiada data — ia
# bermakna "guna data yang sama seperti TC daftar bagi jenis ini".
# Disahkan dalam Excel MBIP: K-005 tertulis "N/A", S-005 kosong, dan
# excel_data.py yang dibina tangan memang menyalin nilai dari -001.
# Corak ini dikodkan supaya penjana tidak perlu meneka.
def apply_inheritance(by_tc):
    """Isi TC yang kosong daripada TC '-001' jenis yang sama.

    Kunci ialah ID ternormal (TC-K-005 -> mewarisi TC-K-001).
    """
    filled = dict(by_tc)
    for tc, data in by_tc.items():
        if not is_empty(data):
            continue
        m = re.match(r"^(TC-[A-Z]+)-(\d+)$", tc)
        if not m or m.group(2) == "001":
            continue
        parent = f"{m.group(1)}-001"
        if parent in by_tc and not is_empty(by_tc[parent]):
            # Salinan cetek memadai: nilai ialah rentetan tak berubah.
            filled[tc] = {k: (dict(v) if isinstance(v, dict) else list(v))
                          for k, v in by_tc[parent].items()}
            filled[tc]["_diwarisi_dari"] = parent
    return filled


def parse_sheet_rows(rows):
    """Bantu: {label lajur B: nilai lajur C} dari baris atas satu sheet."""
    d = {}
    for r in rows:
        if r and len(r) > 2 and r[1]:
            d[str(r[1]).strip().rstrip(":")] = r[2]
    return d

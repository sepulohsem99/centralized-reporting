"""
Ekstrak keadaan pipeline dari folder shared IES Dev 2.0.

MASALAH YANG DISELESAIKAN
-------------------------
Folder shared (APK + test script setiap PBT) duduk di Desktop, bukan
dalam repo. Vercel tidak boleh membacanya, dan menyalin folder itu masuk
repo bukan pilihan — fail APK sahaja ratusan MB.

Jadi skrip ini membaca folder tersebut dan menulis SATU fail JSON kecil
ke dalam repo: reports/pipeline.json. Itu sahaja yang perlu di-commit.

Jalankan semula bila-bila folder shared dikemas kini.

GUNA
----
    python tools/extract_pipeline.py
    python tools/extract_pipeline.py --shared "D:\\lain\\folder"
    python tools/extract_pipeline.py --profiles     # jana stub profil

Lokasi folder shared boleh juga ditetapkan melalui MBIP_SHARED_DIR.

KEBERGANTUNGAN
--------------
Perlukan openpyxl (pip install openpyxl). Ia BUKAN kebergantungan untuk
menjalankan ujian — hanya alat ini. Sengaja diasingkan supaya ahli team
yang cuma mahu run test tidak perlu memasangnya.
"""

import argparse
import glob
import json
import os
import re
import sys
from collections import Counter

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
OUT_JSON = os.path.join(ROOT, "reports", "pipeline.json")
PROFILES_DIR = os.path.join(ROOT, "profiles")

DEFAULT_SHARED = os.environ.get(
    "MBIP_SHARED_DIR",
    r"C:\Users\mrsai\Desktop\IES Dev 2.0 Shared Folder-local desktop",
)

# Medan yang dibaca dari setiap sheet TC (lajur B = label, C = nilai).
FIELD_MAX_ROW = 18


def version_key(name):
    """(major, minor, patch) dari nama fail; (0,0,0) kalau tiada."""
    m = re.findall(r"(\d+)\.(\d+)\.(\d+)", os.path.basename(name))
    return tuple(map(int, m[0])) if m else (0, 0, 0)


def version_str(name):
    k = version_key(name)
    return ".".join(map(str, k)) if k != (0, 0, 0) else "?"


def find_shared_root(base):
    """Folder shared kadang dibungkus satu lapis lagi di dalam dirinya."""
    if not os.path.isdir(base):
        return None
    inner = os.path.join(base, "IES Dev 2.0 Shared Folder")
    return inner if os.path.isdir(inner) else base


def scan_apks(root):
    """{PBT: {ENV: [nama fail terurut lama->baru]}}"""
    out = {}
    for d in sorted(glob.glob(os.path.join(root, "*APK*"))):
        pbt = re.sub(r"^\d+\.\s*", "", os.path.basename(d))
        pbt = pbt.replace(" APK Files", "").replace(" APK", "").strip()
        envs = {}
        for dirpath, _, files in os.walk(d):
            apks = [f for f in files if f.lower().endswith(".apk")]
            if not apks:
                continue
            rel = os.path.relpath(dirpath, d)
            env = "unknown" if rel == "." else rel.split(os.sep)[0].lower()
            envs.setdefault(env, []).extend(sorted(apks, key=version_key))
        if envs:
            out[pbt] = envs
    return out


def apk_package(path):
    """Nama pakej dari AndroidManifest.xml dalam APK.

    Manifest dalam APK ialah XML binari, tetapi rentetannya masih
    tersimpan sebagai UTF-16 yang boleh dibaca — cukup untuk mengecam
    nama pakej tanpa memerlukan aapt atau androguard.

    DISAHKAN pada 8 APK merentasi 4 PBT: semuanya menggunakan pakej yang
    SAMA (com.anonymous.react_ies_v1). Ini bermakna satu peranti hanya
    boleh memasang satu PBT pada satu masa, dan auto-detect peranti TIDAK
    boleh membezakan PBT mana yang sedang dipasang. Fungsi ini kekal
    membaca nilai sebenar (bukan menetapkannya secara keras) supaya PBT
    masa depan yang menukar nama pakej akan dikesan sendiri.
    """
    import zipfile
    try:
        with zipfile.ZipFile(path) as z:
            raw = z.read("AndroidManifest.xml")
    except Exception:                                   # noqa: BLE001
        return None
    txt = raw.decode("utf-16-le", "ignore")
    cands = re.findall(r"com\.[a-z0-9_]+\.[a-z0-9_]+", txt)
    skip = ("com.google", "com.android", "com.facebook", "com.canhub")
    for c in cands:
        if not c.startswith(skip):
            return c
    return None


def latest_script(root, pbt):
    """Fail Excel test script terbaharu bagi satu PBT."""
    pat = os.path.join(root, f"*{pbt} Testing Report", "**", "*.xlsx")
    cands = [f for f in glob.glob(pat, recursive=True)
             if "Testing Script" in os.path.basename(f)]
    return sorted(cands, key=version_key)[-1] if cands else None


def parse_script(path):
    """TC, tetapan, dan taburan status dari satu fail test script."""
    import openpyxl

    wb = openpyxl.load_workbook(path, data_only=True, read_only=True)
    tcs, status, ips, lesen, akaun = [], Counter(), set(), set(), set()
    per_tc = {}
    try:
        for sn in wb.sheetnames:
            name = sn.strip()
            if not re.match(r"^[A-Z]+-TC-", name):
                continue
            tcs.append(name)
            d = {}
            for r in wb[sn].iter_rows(min_row=1, max_row=FIELD_MAX_ROW,
                                      max_col=3, values_only=True):
                if r and r[1]:
                    d[str(r[1]).strip().rstrip(":")] = r[2]

            st = str(d.get("Status") or "").strip()
            status[st or "(kosong)"] += 1

            # Status per-TC, dikunci pada ID yang dinormalkan (awalan PBT
            # dibuang) supaya laporan boleh memadankannya dengan hasil
            # automation walaupun setiap PBT memakai awalan sendiri:
            # MBIP-TC-T-001 dan MBPG-TC-T-001 -> TC-T-001.
            key = re.sub(r"^[A-Z]+-TC-", "TC-", name)
            per_tc[key] = {
                "status": st,
                "remarks": re.sub(r"\s+", " ",
                                  str(d.get("Remarks") or "")).strip()[:300],
                "actual": re.sub(r"\s+", " ",
                                 str(d.get("Actual Results") or "")).strip()[:300],
            }

            if d.get("IP Address"):
                ips.add(str(d["IP Address"]).strip())

            td = str(d.get("Test Data") or "")
            m = re.search(r"Licen[sc]e\s*:?\s*([0-9]{10,})", td, re.I)
            if m:
                lesen.add(m.group(1))
            m = re.search(r"Username\s*:?\s*(\S+)\s*[\n\s]+Password\s*:?\s*(\S+)",
                          td, re.I)
            if m:
                akaun.add((m.group(1), m.group(2)))
    finally:
        wb.close()

    return {
        "file": os.path.basename(path),
        "version": version_str(path),
        "tc_count": len(tcs),
        "tc_ids": sorted(tcs),
        "status_manual": dict(status),
        "status_per_tc": per_tc,
        "alamat_server": sorted(ips),
        "lesen": sorted(lesen),
        "akaun": [{"username": u, "password": p} for u, p in sorted(akaun)],
    }


def build(shared_dir, verbose=True):
    root = find_shared_root(shared_dir)
    if not root:
        raise SystemExit(
            f"Folder shared tidak dijumpai: {shared_dir}\n"
            f"  Tetapkan dengan --shared, atau env MBIP_SHARED_DIR."
        )

    apks = scan_apks(root)
    pbts = {}
    for pbt in sorted(set(apks) | {
            re.sub(r"^\d+\.\s*", "", os.path.basename(d)).replace(
                " Testing Report", "").strip()
            for d in glob.glob(os.path.join(root, "*Testing Report"))}):
        if pbt.upper() == "DEMO":
            continue                       # bukan PBT sebenar
        entry = {"pbt": pbt, "apk": {}, "script": None}
        for env, files in (apks.get(pbt) or {}).items():
            newest = files[-1]
            full = None
            for dp, _, fs in os.walk(os.path.join(root, f"*")):
                if newest in fs:
                    full = os.path.join(dp, newest)
                    break
            if full is None:
                hits = glob.glob(os.path.join(root, "**", newest),
                                 recursive=True)
                full = hits[0] if hits else None
            entry["apk"][env] = {
                "terkini": newest,
                "versi": version_str(newest),
                "bilangan": len(files),
                "package": apk_package(full) if full else None,
            }
        sp = latest_script(root, pbt)
        if sp:
            if verbose:
                print(f"  membaca {os.path.basename(sp)} ...", flush=True)
            entry["script"] = parse_script(sp)
        pbts[pbt] = entry

    import datetime
    data = {
        "dijana": datetime.datetime.now().isoformat(timespec="seconds"),
        "sumber": root,
        "pbt": pbts,
    }
    os.makedirs(os.path.dirname(OUT_JSON), exist_ok=True)
    with open(OUT_JSON, "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2, ensure_ascii=False)
    return data


def write_profile_stubs(data):
    """Jana profil untuk PBT yang belum ada — nilai diisi dari Excel.

    Tidak menimpa profil sedia ada: nilai yang sudah disahkan berfungsi
    pada peranti sebenar lebih dipercayai daripada apa yang tertulis
    dalam Excel (contoh: lesen MBIP dalam Excel berbeza daripada yang
    terbukti jalan).
    """
    os.makedirs(PROFILES_DIR, exist_ok=True)
    dibuat = []
    for pbt, e in data["pbt"].items():
        sc = e.get("script") or {}
        addrs = sc.get("alamat_server") or []
        lesen = (sc.get("lesen") or ["ISI-SINI"])[0]
        akaun = (sc.get("akaun") or [{"username": "ISI-SINI",
                                      "password": "ISI-SINI"}])[0]
        for env in ("production", "staging"):
            name = f"{pbt.lower()}-{env}"
            path = os.path.join(PROFILES_DIR, f"{name}.json")
            if os.path.exists(path):
                continue
            # Ambil pakej dari APK env yang sepadan; kalau env itu tiada
            # APK, guna mana-mana yang ada bagi PBT sama.
            pkg = ((e["apk"].get(env) or {}).get("package")
                   or next((v.get("package") for v in e["apk"].values()
                            if v.get("package")), None)
                   or "ISI-SINI")
            prof = {
                "_comment": (
                    f"Dijana automatik dari {sc.get('file', 'test script')} "
                    f"oleh tools/extract_pipeline.py. SAHKAN setiap nilai "
                    f"pada peranti sebenar sebelum bergantung padanya — "
                    f"Excel tidak semestinya sepadan dengan server yang "
                    f"hidup."
                ),
                "pbt": pbt,
                "env": env,
                "app_package": pkg,
                "app_activity": ".MainActivity",
                "internal_ip": addrs[0] if addrs else "ISI-SINI",
                "external_ip": (addrs[1] if len(addrs) > 1
                                else (addrs[0] if addrs else "ISI-SINI")),
                "lesen_aplikasi": lesen,
                "username": akaun["username"],
                "password": akaun["password"],
            }
            with open(path, "w", encoding="utf-8") as fh:
                json.dump(prof, fh, indent=2, ensure_ascii=False)
            dibuat.append(name)
    return dibuat


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--shared", default=DEFAULT_SHARED,
                    help="laluan folder shared IES Dev 2.0")
    ap.add_argument("--profiles", action="store_true",
                    help="jana stub profil untuk PBT yang belum ada")
    args = ap.parse_args()

    try:
        import openpyxl                                  # noqa: F401
    except ImportError:
        raise SystemExit(
            "openpyxl belum dipasang.\n"
            "  Pasang dengan:  pip install openpyxl\n"
            "  (hanya diperlukan oleh alat ini, bukan untuk run test)"
        )

    print(f"[pipeline] membaca: {args.shared}")
    data = build(args.shared)

    print(f"\n[pipeline] ditulis: {OUT_JSON}\n")
    print(f"  {'PBT':<8}{'Excel':<10}{'TC':<5}{'Manual (P/F)':<15}APK")
    print("  " + "-" * 62)
    for pbt, e in data["pbt"].items():
        sc = e.get("script") or {}
        st = sc.get("status_manual", {})
        pf = f"{st.get('Pass', 0)}/{st.get('Fail', 0)}"
        apk = ", ".join(f"{k}:{v['versi']}" for k, v in e["apk"].items()) or "-"
        print(f"  {pbt:<8}{sc.get('version','-'):<10}"
              f"{sc.get('tc_count','-'):<5}{pf:<15}{apk}")

    if args.profiles:
        dibuat = write_profile_stubs(data)
        print(f"\n[pipeline] profil baharu: {', '.join(dibuat) or '(tiada)'}")
        # Lapor hanya profil yang BETUL-BETUL masih berlubang, bukan
        # amaran umum yang cepat menjadi tidak tepat.
        belum = []
        for name in dibuat:
            with open(os.path.join(PROFILES_DIR, f"{name}.json"),
                      encoding="utf-8") as fh:
                p = json.load(fh)
            kosong = [k for k, v in p.items()
                      if not k.startswith("_") and str(v).strip() == "ISI-SINI"]
            if kosong:
                belum.append(f"{name} ({', '.join(kosong)})")
        if belum:
            print("           Perlu diisi manual:")
            for b in belum:
                print(f"             - {b}")
        elif dibuat:
            print("           Semua medan terisi dari Excel + APK. "
                  "SAHKAN pada peranti sebelum bergantung padanya.")


if __name__ == "__main__":
    sys.exit(main())

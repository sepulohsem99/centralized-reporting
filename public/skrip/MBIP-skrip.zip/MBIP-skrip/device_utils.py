"""
Device resolution + environment diagnostics.

WHY THIS EXISTS
---------------
v3 is packaged as a zip and handed to a team where every member has their
own Android device, and nobody is expected (or allowed) to edit any .py
file. The suite previously carried a hardcoded `DEVICE_UDID` in config.py
-- correct while it only ever ran on one machine, fatal on anyone else's:
Appium fails to find the device and all 48 TCs die at session setup.

So the device is resolved at RUNTIME instead:

  1. `MBIP_UDID` environment variable, if set -- manual override, for the
     rare case where auto-detect can't decide (or for CI).
  2. Auto-detect: of the devices `adb devices` reports as online, pick the
     one that actually has APP_PACKAGE installed. This also subsumes the
     original reason the udid was pinned at all (two devices attached to
     this machine, only one carrying the MBIP app).

Anything ambiguous raises a clear, actionable message in BM+BI rather than
letting Appium fail later with a cryptic proxy error.

This module is also the single source of truth for the preflight check --
`python device_utils.py --check` runs the device half of check_env.bat, so
the preflight and the actual run can never disagree about which device
would be driven.

Stdlib only: no new dependency, and it must keep working even when the
test dependencies aren't installed yet (that's exactly when preflight runs).
"""

import getpass
import os
import re
import subprocess
import sys


# ---------------------------------------------------------------------------
# adb plumbing
# ---------------------------------------------------------------------------

class AdbError(RuntimeError):
    """adb is missing, or a device query could not be completed."""


def _adb(args, timeout=20):
    """Run an adb command, return stdout as text.

    Raises AdbError with an actionable message if adb isn't on PATH --
    the single most common setup miss on a fresh machine.
    """
    try:
        proc = subprocess.run(
            ["adb"] + list(args),
            capture_output=True, text=True, timeout=timeout,
        )
    except FileNotFoundError:
        raise AdbError(
            "adb tidak dijumpai dalam PATH / adb not found on PATH.\n"
            "  Install Android SDK platform-tools, kemudian tambah folder "
            "dia ke PATH.\n"
            "  Muat turun: "
            "https://developer.android.com/tools/releases/platform-tools"
        )
    except subprocess.TimeoutExpired:
        raise AdbError(
            f"adb {' '.join(args)} tidak respond dalam {timeout}s. "
            f"Cuba: adb kill-server, kemudian cuba semula."
        )
    return proc.stdout or ""


def list_devices():
    """Every device adb knows about, as (serial, state) pairs.

    States other than "device" matter to the caller: "unauthorized" means
    the USB-debugging prompt wasn't accepted on the phone, "offline" means
    the connection dropped -- both need a different fix than "no device".
    """
    out = _adb(["devices"])
    devices = []
    for line in out.splitlines()[1:]:          # line 0 is the header
        line = line.strip()
        if not line:
            continue
        parts = line.split()
        if len(parts) >= 2:
            devices.append((parts[0], parts[1]))
    return devices


def online_devices():
    """Serials of devices actually usable right now."""
    return [serial for serial, state in list_devices() if state == "device"]


def has_package(serial, package):
    """Is `package` installed on this device?

    `pm list packages <pkg>` does a substring match, so the exact name is
    re-checked against the returned lines rather than trusting a non-empty
    result (e.g. "com.foo.bar" would also match "com.foo.bar.debug").
    """
    out = _adb(["-s", serial, "shell", "pm", "list", "packages", package])
    for line in out.splitlines():
        if line.strip() == f"package:{package}":
            return True
    return False


def app_version(serial, package):
    """versionName of the installed app, or None.

    Parsed in Python rather than piping through findstr/grep so this works
    identically on any shell.
    """
    try:
        out = _adb(["-s", serial, "shell", "dumpsys", "package", package],
                   timeout=30)
    except AdbError:
        return None
    m = re.search(r"versionName=(\S+)", out)
    return m.group(1) if m else None


def device_model(serial):
    """Human-readable model, for logs -- purely cosmetic."""
    try:
        return _adb(["-s", serial, "shell", "getprop",
                     "ro.product.model"]).strip() or None
    except AdbError:
        return None


# ---------------------------------------------------------------------------
# Resolution
# ---------------------------------------------------------------------------

class DeviceResolutionError(RuntimeError):
    """No single obvious device to drive -- message explains what to do."""


def resolve_udid(package, verbose=True):
    """The serial Appium should drive. See module docstring for the order.

    Never guesses when the answer is ambiguous: two devices both carrying
    the app is a real fork in the road, and silently picking one would
    make a run's results untrustworthy.
    """
    override = os.environ.get("MBIP_UDID", "").strip()
    if override:
        if verbose:
            print(f"  [DEVICE] MBIP_UDID diset -- guna serial: {override}")
        return override

    devices = list_devices()
    if not devices:
        raise DeviceResolutionError(
            "Tiada device tersambung / no device attached.\n"
            "  1. Sambung telefon Android via USB.\n"
            "  2. Aktifkan Developer options + USB debugging.\n"
            "  3. Sahkan dengan: adb devices"
        )

    online = [s for s, state in devices if state == "device"]
    if not online:
        detail = "\n".join(f"    {s}  ->  {state}" for s, state in devices)
        raise DeviceResolutionError(
            "Device tersambung tetapi belum sedia / attached but not "
            "ready:\n" + detail + "\n"
            "  'unauthorized' = tekan 'Allow USB debugging' pada telefon.\n"
            "  'offline'      = cabut & sambung semula USB, atau "
            "adb kill-server."
        )

    with_app = [s for s in online if has_package(s, package)]

    if len(with_app) == 1:
        serial = with_app[0]
        if verbose:
            model = device_model(serial)
            ver = app_version(serial, package)
            label = f" ({model})" if model else ""
            vlabel = f", app build {ver}" if ver else ""
            print(f"  [DEVICE] Auto-detect: {serial}{label}{vlabel}")
        return serial

    if not with_app:
        listed = "\n".join(f"    {s}" for s in online)
        raise DeviceResolutionError(
            f"Device dijumpai, tetapi tiada yang ada app '{package}' "
            f"dipasang.\n" + listed + "\n"
            "  Pasang APK MBIP pada device tu dahulu, kemudian cuba "
            "semula.\n"
            "  Sahkan dengan: adb -s <serial> shell pm list packages "
            f"{package}"
        )

    listed = "\n".join(f"    {s}" for s in with_app)
    raise DeviceResolutionError(
        "Lebih dari satu device ada app MBIP -- tak boleh pilih sendiri "
        "(pilihan salah = keputusan test tak sah).\n" + listed + "\n"
        "  Pilih satu dengan set environment variable dahulu, contoh:\n"
        f"    set MBIP_UDID={with_app[0]}\n"
        "  ...kemudian jalankan semula."
    )


def tester_name():
    """Who is running this. Used to attribute runs in the dashboard's run
    history, so one team member's run can't be mistaken for another's.

    Windows username by default -- zero setup. `MBIP_TESTER` overrides it
    for anyone whose account name isn't recognisable to the team.
    """
    override = os.environ.get("MBIP_TESTER", "").strip()
    if override:
        return override
    try:
        return getpass.getuser()
    except Exception:                                   # noqa: BLE001
        return os.environ.get("USERNAME") or "unknown"


# ---------------------------------------------------------------------------
# Preflight (`python device_utils.py --check`)
# ---------------------------------------------------------------------------

def _appium_server_up(url="http://127.0.0.1:4723/status", timeout=4):
    import urllib.request
    try:
        with urllib.request.urlopen(url, timeout=timeout) as resp:
            return resp.status == 200
    except Exception:                                   # noqa: BLE001
        return False


def _check():
    """Device-side preflight. Returns a process exit code."""
    try:
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        from config import APP_PACKAGE
    except Exception as e:                              # noqa: BLE001
        print(f"[GAGAL] Tak dapat baca config.py ({e})")
        return 1

    failed = 0

    # --- devices ---
    try:
        devices = list_devices()
    except AdbError as e:
        print(f"[GAGAL] {e}")
        return 1

    if not devices:
        print("[GAGAL] Tiada device tersambung.")
        print("        Sambung telefon via USB + aktifkan USB debugging.")
        failed += 1
    else:
        print(f"[OK]    {len(devices)} device dikesan oleh adb:")
        for serial, state in devices:
            mark = "  " if state == "device" else "  <-- "
            note = "" if state == "device" else f"TIDAK SEDIA ({state})"
            print(f"          {serial}{mark}{note}")
            if state != "device":
                failed += 1

    # --- app + resolved target ---
    try:
        serial = resolve_udid(APP_PACKAGE, verbose=False)
        model = device_model(serial)
        ver = app_version(serial, APP_PACKAGE)
        print(f"[OK]    Device sasaran : {serial}"
              f"{f' ({model})' if model else ''}")
        print(f"[OK]    App dipasang   : {APP_PACKAGE}")
        print(f"[OK]    App build      : {ver or 'tidak dapat dibaca'}")
    except (DeviceResolutionError, AdbError) as e:
        print(f"[GAGAL] {e}")
        failed += 1

    # --- Appium server ---
    if _appium_server_up():
        print("[OK]    Appium server hidup di 127.0.0.1:4723")
    else:
        print("[GAGAL] Appium server TIDAK hidup di 127.0.0.1:4723")
        print("        Buka terminal lain, taip:  appium")
        print("        Biarkan terminal tu terbuka sepanjang test berjalan.")
        failed += 1

    print(f"[INFO]  Tester         : {tester_name()}")
    return 1 if failed else 0


if __name__ == "__main__":
    if "--check" in sys.argv:
        sys.exit(_check())
    # Bare invocation: print the resolved device, handy for debugging.
    try:
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        from config import APP_PACKAGE
        print(resolve_udid(APP_PACKAGE))
    except Exception as e:                              # noqa: BLE001
        print(e)
        sys.exit(1)

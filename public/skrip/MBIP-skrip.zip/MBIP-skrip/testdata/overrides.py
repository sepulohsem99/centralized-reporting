"""
Nilai yang Excel tidak boleh bekalkan.

Penjana (tools/gen_testdata.py) menghasilkan semula 89% medan data ujian
terus dari Excel. Baki 11% tidak wujud dalam mana-mana sel Excel, dan
tiada penghurai yang lebih pintar boleh menemuinya. Ia terbahagi kepada
tiga sebab:

1. NILAI PERSEKITARAN — bergantung pada akaun yang log masuk, bukan pada
   kes ujian. Contoh: `id_penguatkuasa` ialah nama pengguna profil aktif.
   Ini diisi automatik, tidak perlu ditulis di bawah.

2. DITEMUI SEMASA RECON PERANTI — nilai yang hanya diketahui selepas
   melihat borang sebenar. Contoh: `no_pembantu_penguatkuasa` ialah
   pilihan dropdown yang berbeza mengikut PBT.

3. ADA DALAM TEST STEPS, BUKAN TEST DATA — penulis skrip meletakkannya
   dalam ayat arahan. Contoh: nombor plate `JYX6605` bagi TC Trafik.

Nilai MBIP di bawah diambil daripada testdata/excel_data.py yang dibina
tangan dan sudah terbukti pada peranti sebenar.

PBT LAIN: kosong buat masa ini. Nilai sebenar hanya boleh disahkan dengan
melihat borang PBT berkenaan. Biarkan kosong sehingga disahkan — meneka
akan menghasilkan kegagalan ujian yang kelihatan seperti bug aplikasi,
iaitu keadaan paling buruk.
"""

# {PBT: {ID TC ternormal: {medan: nilai}}}
OVERRIDES = {
    "MBIP": {
        "TC-N-001": {
            # Dropdown "Arahan Tindakan" pada tab Penerima.
            "arahan_tindakan": "1",
        },
        "TC-P-001": {
            "no_pembantu_penguatkuasa": "1180460",
        },
        "TC-K-001": {
            # Trafik: nombor plate ada dalam Test Steps, dan carian
            # MySIKAP yang mengisi nama/IC pesalah.
            "no_kereta": "JYX6605",
            "warna_kereta": "PUTIH",
            "kompaun_jalan": "JALAN JAYA 1",
            "no_pembantu_penguatkuasa": "2",
            # nama_penerima / no_ic_penerima SENGAJA TIADA di sini.
            #
            # Dahulunya "Buruh En Saiful" / "540323115589" — nilai warisan
            # suite v2 yang tiada asas dalam Excel. Ia tercetak pada
            # kertas sebenar dan disedari pemilik pada 2026-07-29.
            # C9 tidak menyebut kedua-dua medan; C10 langkah 5 menanda
            # ia optional. Ikut Excel = biarkan kosong.
            # Lihat excel_data.BLANK_BY_DESIGN.
        },
        "TC-L-001": {
            "no_pembantu_penguatkuasa": "2",
        },
        "TC-S-001": {
            "no_pembantu_penguatkuasa": "2",
        },
        "TC-S-004": {
            # Test Data sheet ini ayat bebas: "Jalan Keruing 11 change to
            # Jalan Harimau Telap" — nilai sasaran diambil daripadanya.
            "kesalahan_jalan": "JALAN HARIMAU TELAP",
        },
        "TC-SK-001": {
            # Julat penapis tarikh pada skrin Senarai — pilihan ujian,
            # bukan data dari Excel.
            "start_day": "1",
            "end_day": "30",
        },
        "TC-N-005": {
            # Sheet Bookmark tidak mengulang kod kompaun, dan tester
            # memilih kesalahan yang BERBEZA daripada N-001 semasa
            # menguji simpan-bookmark. Tidak boleh diterbitkan — nilai ini
            # disalin terus daripada excel_data.py yang terbukti.
            "kesalahan_kompaun": "MELETAKKAN ATAU MENYEBAB DILETAKKAN "
                                 "KENDERAAN BERMOTOR TANPA KEBENARAN MPJBT.",
        },
        "TC-L-005": {
            "kesalahan_kompaun": "MELETAKKAN ATAU MELONGGOKKAN APA-APA BARANG "
                                 "ATAU BENDA DI ATAS TEMPAT AWAM DARIPADA "
                                 "MANA-MANA BANGUNAN ATAU TANAH.",
        },
        "TC-NK-001": {
            "amaun": "50",
        },
        "TC-NK-002": {
            "ulasan": "PATUH - DISAHKAN OLEH AUTOMASI V3",
        },
    },

    # Belum disahkan pada peranti. Lihat nota di atas sebelum mengisi.
    "MBJB": {},
    "MBPG": {},
    "MDKT": {},
}

# Medan yang diterbitkan daripada profil aktif, sama untuk setiap PBT.
# Disenaraikan di sini supaya jelas ia sengaja tidak ada dalam OVERRIDES.
DARI_PROFIL = {
    "id_penguatkuasa": "username",      # akaun log masuk profil
    "username": "username",
    "password": "password",
}


def apply(pbt, tc_data, profil=None):
    """Gabungkan overrides + nilai daripada profil ke dalam TC_DATA.

    Tidak mengubah `tc_data` asal — mengembalikan salinan.
    """
    out = {tc: dict(fields) for tc, fields in tc_data.items()}

    for tc, fields in (OVERRIDES.get(pbt) or {}).items():
        out.setdefault(tc, {}).update(fields)

    if profil:
        for tc in ("TC-T-012", "TC-TN-001", "TC-TN-002", "TC-TN-003"):
            out.setdefault(tc, {})
        for tc in list(out):
            for field, sumber in DARI_PROFIL.items():
                if field in out[tc] or not profil.get(sumber):
                    continue
                # Hanya TC yang memang memerlukannya; menambah nama
                # pengguna kepada setiap TC hanya akan mengelirukan.
                if field == "id_penguatkuasa" and not tc.startswith(
                        ("TC-TN-", "TC-NK-")):
                    continue
                if field in ("username", "password") and tc != "TC-T-012":
                    continue
                out[tc][field] = profil[sumber]
    return out

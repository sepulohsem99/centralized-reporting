"""
Test data extracted from the real test script:
    docs/IES-MBIP Testing Script V2.1.14_PRODUCTION.xlsx
(source file: "IES-MBIP Testing Script V2.1.14(1)_PRODUCTION.xlsx")

Extracted ONCE by parsing the workbook (openpyxl) and hard-coded here with
per-entry citations -- the xlsx is NOT parsed at runtime. Sheet-name quirks
found in the workbook and normalized here:
  - List to Test row 12 carries the ID "MBIP-TC-T012" (missing dash) ->
    normalized to MBIP-TC-T-012.
  - Several sheets have trailing spaces in their names ('MBIP-TC-P-002 ',
    'MBIP-TC-K-002 ', 'MBIP-TC-K-004 ', 'MBIP-TC-L-002 ', 'MBIP-TC-L-004 ',
    'MBIP-TC-P-003 ', 'MBIP-TC-P-004 ', 'MBIP-TC-S-002 ', 'MBIP-TC-S-004 ',
    'MBIP-TC-SK-001 ') -> stripped.
  - Some sheets carry a wrong "Test Case ID" cell inside (e.g. sheet
    MBIP-TC-T-008 says T-007 in C3, P-005/L-005 say N-005, S-005 says
    K-005, NK-002 says NK-001). The SHEET NAME / List-to-Test row is the
    authority, not the C3 cell.
  - NOTE: this workbook has 47 test cases, not 48 -- there is no TN-003
    ("Tarik Notis by Tarikh") sheet or List-to-Test row in V2.1.14.

ENVIRONMENT-SPECIFIC OVERRIDES (deliberate, per the user -- the Excel value
is tied to the manual tester's device/account, not this one):
  - Lesen Aplikasi = 352405067769401 (Excel MBIP-TC-T-002 says
    353466110955149, but that license is bound to the tester's IMEI
    352938641422857; this device's proven license is 352405067769401).
  - Login = msc / Pass1 (Excel MBIP-TC-T-012 lists user4/Pass1, unverified
    on this device; msc/Pass1 is the proven working account).
  - K-001 MySIKAP plate = JYX6605 (the Excel sheet only lists the
    auto-populate RESULT for an unknown plate; JYX6605 is proven to
    trigger a successful MySIKAP populate on this environment).
"""

# ============================================================================
# List to Test (sheet "List to Test", rows 3-49) -- canonical ID + name +
# order. This drives collection order and the final summary table.
# The 5 "> Cetak" cases are skipped in v3 (physical printer required).
# ============================================================================

TC_LIST = [
    # (tc_id, name from "List to Test" column C, stripped)
    ("MBIP-TC-T-001", "Tetapan Alamat IP"),
    ("MBIP-TC-T-002", "Tetapan Pelbagai"),
    ("MBIP-TC-T-003", "Selaras Pengguna Apps"),
    ("MBIP-TC-T-004", "Selaras Maklumat Alamat"),
    ("MBIP-TC-T-005", "Selaras Maklumat Kompaun"),
    ("MBIP-TC-T-006", "Selaras Maklumat Jenis Kenderaan"),
    ("MBIP-TC-T-007", "Selaras Maklumat Warna"),
    ("MBIP-TC-T-008", "Selaras Maklumat Pelesen"),
    ("MBIP-TC-T-009", "Selaras Maklumat Barang Sita"),
    ("MBIP-TC-T-010", "Tetapan Skrin Utama"),
    ("MBIP-TC-T-011", "Semak Kemaskini"),
    ("MBIP-TC-T-012", "Remember Me Functions"),  # listed as "MBIP-TC-T012"
    ("MBIP-TC-N-001", "Daftar Notis Amaran"),
    ("MBIP-TC-N-002", "Daftar Notis Amaran > Cetak"),
    ("MBIP-TC-N-003", "Serah Notis Amaran"),
    ("MBIP-TC-N-004", "Kemaskini Notis Amaran"),
    ("MBIP-TC-N-005", "Kompaun Form Notis Amaran - Bookmark"),
    ("MBIP-TC-P-001", "Daftar Kompaun Pelbagai"),
    ("MBIP-TC-P-002", "Daftar Kompaun Pelbagai > Cetak"),
    ("MBIP-TC-P-003", "Serah Kompaun Pelbagai"),
    ("MBIP-TC-P-004", "Kemaskini Kompaun Pelbagai"),
    ("MBIP-TC-P-005", "Kompaun Form Pelbagai - Bookmark"),
    ("MBIP-TC-K-001", "Daftar Kompaun Letak Kereta"),
    ("MBIP-TC-K-002", "Daftar Kompaun Letak Kereta > Cetak"),
    ("MBIP-TC-K-003", "Serah Kompaun Letak Kereta"),
    ("MBIP-TC-K-004", "Kemaskini Kompaun Letak Kereta"),
    ("MBIP-TC-K-005", "Kompaun Form Letak Kereta - Bookmark"),
    ("MBIP-TC-L-001", "Daftar Kompaun Lesen"),
    ("MBIP-TC-L-002", "Daftar Kompaun Lesen > Cetak"),
    ("MBIP-TC-L-003", "Serah Kompaun Lesen"),
    ("MBIP-TC-L-004", "Kemaskini Kompaun Lesen"),
    ("MBIP-TC-L-005", "Kompaun Form Lesen - Bookmark"),
    ("MBIP-TC-S-001", "Daftar Sitaan"),
    ("MBIP-TC-S-002", "Daftar Sitaan > Cetak"),
    ("MBIP-TC-S-003", "Serah Sitaan"),
    ("MBIP-TC-S-004", "Kemaskini Sitaan"),
    ("MBIP-TC-S-005", "Kompaun Form Sitaan - Bookmark"),
    ("MBIP-TC-SK-001", "Senarai Kompaun"),
    ("MBIP-TC-H-001", "Hantar Semula Data & Gambar Notis Amaran"),
    ("MBIP-TC-H-002", "Hantar Semula Data & Gambar Kompaun Pelbagai"),
    ("MBIP-TC-H-003", "Hantar Semula Data & Gambar Kompaun Letak Kereta"),
    ("MBIP-TC-H-004", "Hantar Semula Data & Gambar Kompaun Lesen"),
    ("MBIP-TC-H-005", "Hantar Semula Data & Gambar Kompaun Sitaan"),
    ("MBIP-TC-TN-001", "Tarik Notis by Penguatkuasa"),
    ("MBIP-TC-TN-002", "Tarik Notis by No.Notis"),
    # TN-003 does NOT exist in the V2.1.14 workbook (47 TCs) -- added on
    # the user's explicit decision (2026-07-16, "Build it anyway").
    ("MBIP-TC-TN-003", "Tarik Notis by Tarikh (v3-added)"),
    ("MBIP-TC-NK-001", "Notis ke Kompaun > Kompaun"),
    ("MBIP-TC-NK-002", "Notis ke Kompaun > Patuh"),
]

TC_ORDER = {tc_id: i for i, (tc_id, _name) in enumerate(TC_LIST)}
TC_NAMES = dict(TC_LIST)

# The 5 printer tests, skipped by user decision (no physical printer).
PRINTER_SKIP_REASON = "requires physical printer — excluded from v3 for now"

# ============================================================================
# Shared environment settings
# ============================================================================

# Sheet MBIP-TC-T-001 Test Data (C9): "58.27.54.105"
LICENSE_SETTINGS = {
    "internal_ip": "58.27.54.105",
    "external_ip": "58.27.54.105",
    # ENVIRONMENT OVERRIDE (see module docstring): sheet MBIP-TC-T-002
    # C9 says "License: 353466110955149", but that license is bound to
    # the tester's IMEI (352938641422857, cell C6); this device's proven
    # license is:
    "lesen_aplikasi": "352405067769401",
}

# ENVIRONMENT OVERRIDE (see module docstring): sheet MBIP-TC-T-012 C9 says
# "Username:user4  Password:Pass1" -- unverified on this device; msc/Pass1
# is the proven working account (also cited by MBIP-TC-TN-001 C9:
# "ID Penguatkuasa: msc").
TEST_CREDENTIALS = {
    "username": "msc",
    "password": "Pass1",
}

# ============================================================================
# Per-TC test data, keyed by normalized TC ID.
# Keys inside each entry match the v2/v3 pages-layer fill_* signatures.
# ============================================================================

TC_DATA = {}

# ---------------------------------------------------------------------------
# MBIP-TC-N-001 "Daftar Notis Amaran" -- sheet MBIP-TC-N-001, Test Data (C9)
# ---------------------------------------------------------------------------
TC_DATA["MBIP-TC-N-001"] = {
    # PESALAH - Maklumat Pesalah (C9)
    "nama_pesalah": "ALI",
    "no_kp_ssm_kereta": "010123456789",
    "jalan": "JALAN DANGA SUTERA 12/3",
    "taman": "TAMAN DANGA SUTERA",
    "poskod": "81300",
    "bandar": "SKUDAI",
    "negeri": "JOHOR DARUL TAKZIM",
    # KOMPAUN - Maklumat Kesalahan (C9). The Notis-tab Jalan is a
    # live-search autocomplete whose suggestion rows render as
    # "JALAN | TAMAN | BANDAR" (format confirmed live in v2); the exact
    # row is constructed from the sheet's Jalan/Taman/Bandar values. If
    # that exact row doesn't render, the pages layer falls back to the
    # first suggestion row and logs a [WARN] (per the v3 data rules).
    "notis_jalan_partial": "JALAN BARAU 1",
    "notis_jalan_suggestion": "JALAN BARAU 1 | KAMPUNG BARU SKUDAI | SKUDAI",
    "notis_taman": "KAMPUNG BARU SKUDAI",
    "notis_poskod": "81000",
    "notis_bandar": "SKUDAI",
    "notis_negeri": "JOHOR DARUL TAKZIM",
    "lokasi_kesalahan": "DEPAN KEDAI",
    "butiran_kesalahan": "SALAH PARKING KERETA",
    # "- Maklumat Kompaun / Tempoh Kompaun: 1" (C9)
    # DISAHKAN SEMULA 2026-07-29 terhadap docs/…V2.1.14_PRODUCTION.xlsx:
    # nilai 1 memang betul. (Satu salinan LAIN workbook yang bernama sama
    # menulis 0 di sini — lihat nota "dua workbook" dalam CLAUDE.md.
    # Salinan docs/ ialah yang kod ini dibina daripadanya.)
    "tempoh_notis": "1",
    "keterangan_kod_kompaun": "KOMPAUN PELBAGAI",
    "kod_akta": "UUK 7 UNDANG-UNDANG KECIL TAMAN (MDJBT) 1987",
    # >>> [PENEMUAN-DATA] 2026-08-27 (peta_kod, DB peranti
    # local_ekpn_kesalahan_kompaun selepas selaras production): nilai
    # Excel V2.1.17 'MEMOTONG, MENGALIH, ...' TIDAK lagi wujud di bawah
    # akta 39 (UUK 7) — dalam DB semasa ia berpindah ke akta 4 dan
    # ejaannya berubah (tiada space selepas koma, tiada noktah). Satu-
    # satunya kesalahan di bawah akta 39 kini ialah kod 70 di bawah —
    # rantaian kt->39->70 juga terbukti dalam rekod notis sebenar lama
    # (IPA3N260710004 dll). Diganti atas arahan CEO ("pilih mana-mana
    # data yang boleh bagi lulus"); teks disalin VERBATIM dari DB
    # (tiada noktah hujung — noktah akan mematahkan padanan hujung). <<<
    "kesalahan_kompaun": "MELETAKKAN ATAU MENYEBAB DILETAKKAN KENDERAAN "
                         "BERMOTOR TANPA KEBENARAN MPJBT",
    # PEGAWAI: C10 langkah 4 menyebut "Nama Penerima with No IC
    # Penerima. (Optional)" tetapi C9 TIDAK memberi nilai untuk N-001.
    # Nilai lama "ALI" / "010123456789" hanyalah nama pesalah disalin
    # semula mengikut "konvensyen" — bukan dari Excel. Dikosongkan
    # 2026-07-29; lihat BLANK_BY_DESIGN.
    # arahan_tindakan dikekalkan: ia datang dari overrides.py dan
    # merupakan pilihan dropdown yang wajib, bukan medan teks optional.
    "arahan_tindakan": "1",
    "nama_penerima": "",
    "no_ic_penerima": "",
}

# ---------------------------------------------------------------------------
# MBIP-TC-P-001 "Daftar Kompaun Pelbagai" -- sheet MBIP-TC-P-001, C9
# ---------------------------------------------------------------------------
TC_DATA["MBIP-TC-P-001"] = {
    # PESALAH - Maklumat Pesalah (C9)
    "nama_pesalah": "ABU",
    "no_kp_ssm_kereta": "010987654321",
    "jalan": "JALAN JAYA 3",
    "taman": "TAMAN JAYA",
    "poskod": "81100",
    "bandar": "SKUDAI",
    "negeri": "JOHOR DARUL TAKZIM",
    # KOMPAUN - Maklumat Kesalahan (C9); suggestion row constructed from
    # the sheet's Jalan/Taman/Bandar (same fallback rule as N-001).
    "kompaun_jalan_partial": "JALAN HULUBALANG 1",
    "kompaun_jalan_suggestion":
        "JALAN HULUBALANG 1 | TAMAN UNGKU TUN AMINAH | SKUDAI",
    "kompaun_taman": "TAMAN UNGKU TUN AMINAH",
    "kompaun_poskod": "81100",
    "kompaun_bandar": "SKUDAI",
    "kompaun_negeri": "JOHOR DARUL TAKZIM",
    "lokasi_kesalahan": "DEPAN SEKOLAH",
    # "PANDU KERETA KAJU" is genuinely what C9 says (sic).
    "butiran_kesalahan": "PANDU KERETA KAJU",
    # "- Maklumat Kompaun / Tempoh Kompaun: 1" (C9)
    "tempoh_notis": "1",
    "keterangan_kod_kompaun": "KOMPAUN PELBAGAI",
    # >>> [PENEMUAN-DATA] 2026-08-27 (peta_kod, DB peranti): rantaian
    # oracle P-001 MASIH WUJUD (kt -> akta 34 -> kesalahan 45) tetapi
    # Excel V2.1.17 mengeja 'PERUNTUKKAN' (dua K) manakala server
    # 'PERUNTUKAN' (satu K) — typo satu huruf ini mematahkan padanan
    # hujung-string selamanya. 'IDAK' (typo tester) juga tiada di
    # server; teks penuh DB: 'tidak mematuhi peruntukan uuk kerja
    # tanah' (padanan tak peka huruf). Nilai di bawah disalin VERBATIM
    # dari DB (arahan CEO expedite 2026-08-27). <<<
    "kod_akta": "SEKSYEN 18(B) TIDAK MEMATUHI PERUNTUKAN UUK KERJA TANAH",
    "kesalahan_kompaun": "TIDAK MEMATUHI PERUNTUKAN UUK KERJA TANAH",
    # "PILIH KADAR DENDA: RM2000" (C9)
    "kadar_denda": "RM2000",
    # PEGAWAI (C9): "Arahan Tindakan: 1 / Nama Penerima: ABU / No IC
    # Penerima: 010987654321". The on-screen Pelbagai Penerima tab's
    # first field is "NO PEMBANTU PENGUATKUASA" (not Arahan Tindakan);
    # the sheet gives no pembantu number, so the v2-proven value stays:
    "no_pembantu_penguatkuasa": "1180460",
    "nama_penerima": "ABU",
    "no_ic_penerima": "010987654321",
}

# ---------------------------------------------------------------------------
# MBIP-TC-K-001 "Daftar Kompaun Letak Kereta" -- sheet MBIP-TC-K-001, C9.
# On-screen jenis option is literally "KOMPAUN TRAFIK" (confirmed live).
# ---------------------------------------------------------------------------
TC_DATA["MBIP-TC-K-001"] = {
    # ENVIRONMENT OVERRIDE (see module docstring): C9's pesalah block
    # (VIMALA DEVI A/P MARAN etc.) is the auto-populate RESULT of the
    # tester's plate, which the sheet never lists. JYX6605 is proven to
    # trigger a successful MySIKAP populate on this environment.
    "no_kereta": "JYX6605",
    # Warna Kereta: not given in C9 ("-"); any reasonable value.
    "warna_kereta": "PUTIH",
    # KOMPAUN - Maklumat Kesalahan (C9)
    "kompaun_jalan": "JALAN JAYA 1",
    "kompaun_taman": "TAMAN JAYA 1",
    "kompaun_bandar": "SKUDAI",
    "kompaun_poskod": "81000",
    "kompaun_negeri": "JOHOR",
    "lokasi_kesalahan": "DEPAN SEKOLAH",
    "butiran_kesalahan": "PANDU KERETA LAJU",
    # "Maklumat Kompaun: 1 HARI" (C9)
    # DISAHKAN SEMULA 2026-07-29 terhadap docs/…V2.1.14_PRODUCTION.xlsx:
    # nilai 1 memang betul. (Salinan lain workbook yang bernama sama
    # menulis "0 HARI" — lihat nota "dua workbook" dalam CLAUDE.md.)
    "tempoh_notis": "1",
    # Tier 1 is pre-selected on the Trafik form (PERINTAH 39) --
    # asserted, not selected. C9: "Keterangan Kod Kompaun: PERINTAH
    # LALULINTAS JALAN (PERINTAH 39)".
    "keterangan_kod_kompaun": "PERINTAH LALULINTAS JALAN (PERINTAH 39)",
    "kod_akta": "PERINTAH LALULINTAS JALAN (PERUNTUKAN TEMPAT LETAK KERETA)",
    # Trailing period genuine in C9.
    "kesalahan_kompaun": "MEMPAMERKAN KUPON LETAK KERETA TANPA MEMBUAT "
                         "PENANDAAN YANG BETUL.",
    # "Pilin Kadar Denda (RM): 30" (C9)
    "kadar_denda": "RM30",
    # "Pegawai - Maklumat Pegawai / No pembantu penguatkuasa: 2" (C9)
    "no_pembantu_penguatkuasa": "2",
    # KOSONG DENGAN SENGAJA. C9 tidak menyebut Nama Penerima atau No IC
    # Penerima langsung, dan C10 langkah 5 menanda kedua-duanya
    # "(optional)". Nilai lama "Buruh En Saiful" / "540323115589"
    # diwarisi dari suite v2 dan bukan dari Excel -- ia muncul pada
    # kertas cetak sebenar dan disedari oleh pemilik pada 2026-07-29.
    #
    # Ikut Excel bermakna tidak mengisi langsung. Lihat BLANK_BY_DESIGN
    # di bawah: laporan akan menanda medan ini sebagai
    # "(blank dari test script)" supaya kekosongan ini kelihatan
    # disengajakan, bukan seperti data yang tercicir.
    "nama_penerima": "",
    "no_ic_penerima": "",
}

# ---------------------------------------------------------------------------
# Serah / lampiran (clip icon) tests -- sheets MBIP-TC-N-003, MBIP-TC-P-003,
# MBIP-TC-K-003. Test Data (C9) is just "Picture"; steps (C10): "Click on
# the clip icon for take picture". The jenis letter maps to the record-row
# prefix in the Senarai table (confirmed live in v2: row content-desc is
# e.g. "P, 2026-07-01, 10:35, M, A, msc").
# ---------------------------------------------------------------------------
TC_DATA["MBIP-TC-N-003"] = {"jenis_letter": "N"}
TC_DATA["MBIP-TC-P-003"] = {"jenis_letter": "P"}
TC_DATA["MBIP-TC-K-003"] = {"jenis_letter": "K"}

# ---------------------------------------------------------------------------
# MBIP-TC-SK-001 "Senarai Kompaun" -- sheet MBIP-TC-SK-001 (trailing-space
# sheet name). Test Data: N/A; steps: navigate to Senarai, choose date,
# observe the list; expected: No Kompaun displayed in sequential order.
# Day range = whole current month (v2-proven calendar interaction).
# ---------------------------------------------------------------------------
TC_DATA["MBIP-TC-SK-001"] = {"start_day": 1, "end_day": 30}

# ---------------------------------------------------------------------------
# Hantar Semula tests -- sheets MBIP-TC-H-001..H-005. Steps (C10):
# "Navigate to 'Hantar' section and click on the 'Hantar Data' & 'Hantar
# Semula' buttons". The H sheets' C9 data blocks (APIK/JAMIL/AMAR forms)
# describe the record the manual tester created to resend; v3 instead
# relies on the records created earlier in the same run by N-001 / P-001 /
# K-001 (their jenis letters below), which satisfies the precondition (C8)
# "The records of data and images exist in the system".
# ---------------------------------------------------------------------------
TC_DATA["MBIP-TC-H-001"] = {"jenis_letter": "N"}
TC_DATA["MBIP-TC-H-002"] = {"jenis_letter": "P"}
TC_DATA["MBIP-TC-H-003"] = {"jenis_letter": "K"}

# ---------------------------------------------------------------------------
# MBIP-TC-TN-001 "Tarik Notis by Penguatkuasa" -- sheet MBIP-TC-TN-001,
# C9: "ID Penguatkuasa: msc".
# ---------------------------------------------------------------------------
TC_DATA["MBIP-TC-TN-001"] = {"id_penguatkuasa": "msc"}

# ===========================================================================
# Phase 2
# ===========================================================================

# ---------------------------------------------------------------------------
# MBIP-TC-T-012 "Remember Me Functions" -- sheet MBIP-TC-T-012 (listed as
# "MBIP-TC-T012" in the List to Test). C9: "Username:user4 Password:Pass1"
# -- ENVIRONMENT OVERRIDE to msc/Pass1 (user4 unverified on this device);
# see TEST_CREDENTIALS. Steps (C10): login with the Remember Me checkbox,
# close the application, relaunch, verify credentials remain saved.
# ---------------------------------------------------------------------------
TC_DATA["MBIP-TC-T-012"] = dict(TEST_CREDENTIALS)

# ---------------------------------------------------------------------------
# MBIP-TC-N-004 "Kemaskini Notis Amaran" -- sheet MBIP-TC-N-004, C9
# ("Change the information as shown below"). Pesalah block == N-001's
# (unchanged); the changed values are the KOMPAUN kesalahan block + codes.
# ---------------------------------------------------------------------------
TC_DATA["MBIP-TC-N-004"] = {
    "jenis_letter": "N",
    # KOMPAUN - Maklumat Kesalahan (C9)
    "kesalahan_jalan": "JALAN MELAWATI 1",
    "kesalahan_taman": "TAMAN MELAWATI",
    "kesalahan_poskod": "81000",
    "kesalahan_bandar": "SKUDAI",
    "kesalahan_negeri": "JOHOR DARUL TAKZIM",
    "lokasi_kesalahan": "DEPAN KEDAI",
    "butiran_kesalahan": "SALAH PARKING KERETA",
    "tempoh_notis": "1",
    # "- Maklumat Kompaun" (C9)
    "keterangan_kod_kompaun": "AKTA JALAN/PARIT/BANGUNAN",
    "kod_akta": "KEMUNGKIRAN MEMATUHI NOTIS",
    "kesalahan_kompaun": "TIDAK MEMATUHI NOTIS",
    # Old data to verify on the record popup before updating (from the
    # N-001 create in the same run):
    "old": {
        "nama": "ALI",
        "jalan": "JALAN BARAU 1",
    },
}

# ---------------------------------------------------------------------------
# MBIP-TC-N-005 "Kompaun Form Notis Amaran - Bookmark" -- sheet
# MBIP-TC-N-005, C9: the kompaun-code combo to bookmark. Bookmark NAME is
# not specified in the sheet; a distinct value is used.
# ---------------------------------------------------------------------------
TC_DATA["MBIP-TC-N-005"] = {
    "keterangan_kod_kompaun": "KOMPAUN PELBAGAI",
    "kod_akta": "UUK 7 UNDANG-UNDANG KECIL TAMAN (MDJBT) 1987",
    # Trailing period genuine (C9).
    "kesalahan_kompaun": "MELETAKKAN ATAU MENYEBAB DILETAKKAN KENDERAAN "
                         "BERMOTOR TANPA KEBENARAN MPJBT.",
    "bookmark_name": "V3 BOOKMARK N",
}

# ---------------------------------------------------------------------------
# MBIP-TC-P-004 "Kemaskini Kompaun Pelbagai" -- sheet 'MBIP-TC-P-004 '
# (trailing-space name), C9. Pesalah block == P-001's (unchanged).
# ---------------------------------------------------------------------------
TC_DATA["MBIP-TC-P-004"] = {
    "jenis_letter": "P",
    "kesalahan_jalan": "JALAN RONGGENG 1",
    # "Maklumat Taman: SKUDAI" is genuinely what C9 says.
    "kesalahan_taman": "SKUDAI",
    "kesalahan_poskod": "81100",
    "kesalahan_bandar": "SKUDAI",
    "kesalahan_negeri": "JOHOR DARUL TAKZIM",
    "lokasi_kesalahan": "DEPAN SEKOLAH",
    "butiran_kesalahan": "PANDU KERETA KAJU",
    "tempoh_notis": "1",
    "keterangan_kod_kompaun": "KOMPAUN PELBAGAI",
    "kod_akta": "UNDANG-UNDANG KECIL PENJAJA (MBIP) 2020",
    "kesalahan_kompaun": "(UUK3) - MENJAJA TANPA LESEN MPJBT",
    "kadar_denda": "RM2000",
    "old": {
        "nama": "ABU",
        "jalan": "JALAN HULUBALANG 1",
    },
}

# ---------------------------------------------------------------------------
# MBIP-TC-P-005 "Kompaun Form Pelbagai - Bookmark" -- sheet MBIP-TC-P-005
# (its C3 cell mislabels itself N-005), C9.
# ---------------------------------------------------------------------------
TC_DATA["MBIP-TC-P-005"] = {
    "keterangan_kod_kompaun": "KOMPAUN PELBAGAI",
    "kod_akta": "SEKSYEN 18(B) TIDAK MEMATUHI PERUNTUKKAN UUK KERJA TANAH",
    "kesalahan_kompaun": "IDAK MEMATUHI PERUNTUKKAN UUK KERJA TANAH",
    "kadar_denda": "RM2000",
    "bookmark_name": "V3 BOOKMARK P",
}

# ---------------------------------------------------------------------------
# MBIP-TC-K-004 "Kemaskini Kompaun Letak Kereta" -- sheet 'MBIP-TC-K-004 '
# (trailing-space name), C9. Pesalah block: the sheet lists the MySIKAP
# populate result; this environment's K-001 record was populated from
# plate JYX6605 instead (see the K-001 override).
# ---------------------------------------------------------------------------
TC_DATA["MBIP-TC-K-004"] = {
    "jenis_letter": "K",
    "kesalahan_jalan": "JALAN MELAWATI 2",
    "kesalahan_taman": "TAMAN MELAWATI",
    "kesalahan_poskod": "81300",
    "kesalahan_bandar": "SKUDAI",
    "kesalahan_negeri": "JOHOR DARUL TAKZIM",
    "lokasi_kesalahan": "DEPAN RUMAH",
    "butiran_kesalahan": "PARKING KERETA",
    "tempoh_notis": "1",
    "keterangan_kod_kompaun": "PERINTAH LALULINTAS JALAN (PERINTAH 39)",
    "kod_akta": "PERINTAH LALULINTAS JALAN (PERUNTUKAN TEMPAT LETAK KERETA)",
    "kesalahan_kompaun": "MENGHALANG PETAK LETAK KERETA",
    "kadar_denda": "RM30",
    "old": {
        "jalan": "JALAN JAYA 1",
    },
}

# ---------------------------------------------------------------------------
# MBIP-TC-K-005 "Kompaun Form Letak Kereta - Bookmark" -- sheet
# MBIP-TC-K-005. Test Data (C9) is N/A; the K-001 kompaun-code combo is
# used (tier 1 is pre-selected PERINTAH 39 on the Trafik form).
# ---------------------------------------------------------------------------
TC_DATA["MBIP-TC-K-005"] = {
    "kod_akta": "PERINTAH LALULINTAS JALAN (PERUNTUKAN TEMPAT LETAK KERETA)",
    "kesalahan_kompaun": "MEMPAMERKAN KUPON LETAK KERETA TANPA MEMBUAT "
                         "PENANDAAN YANG BETUL.",
    "kadar_denda": "RM30",
    "bookmark_name": "V3 BOOKMARK K",
}

# ---------------------------------------------------------------------------
# MBIP-TC-L-001 "Daftar Kompaun Lesen" -- sheet MBIP-TC-L-001, C9.
# ---------------------------------------------------------------------------
TC_DATA["MBIP-TC-L-001"] = {
    # PESALAH - Maklumat Pesalah (C9)
    "nama_pesalah": "RAMLI",
    "no_kp_ssm": "010741852963",
    "no_akuan_lesen": "ABC123456",
    "jalan": "JALAN JAYA 3",
    # "TAMANJAYA" (no space) is genuinely what C9 says.
    "taman": "TAMANJAYA",
    "poskod": "81000",
    "bandar": "SKUDAI",
    "negeri": "JOHOR DARUL TAKZIM",
    # KOMPAUN - Maklumat Kesalahan (C9)
    "kompaun_jalan_partial": "JALAN KOSA 3",
    "kompaun_jalan_suggestion": "JALAN KOSA 3 | TAMAN PERLING | SKUDAI",
    "kompaun_taman": "TAMAN PERLING",
    "kompaun_poskod": "81000",
    "kompaun_bandar": "SKUDAI",
    "kompaun_negeri": "JOHOR DARUL TAKZIM",
    "lokasi_kesalahan": "DEPAN KEDAI",
    "butiran_kesalahan": "TIDAK PAPAR LESEN",
    # "Maklumat Kompaun: 0 HARI" (C9)
    "tempoh_notis": "0",
    "keterangan_kod_kompaun": "KOMPAUN MENCEGAH KEKOTORAN",
    "kod_akta": "UNDANG-UNDANG KECIL MENCEGAH KEKOTORAN (MDJBT) 1982",
    # Trailing period genuine (C9).
    "kesalahan_kompaun": "(UUK 6 (II)) - MELETAKKAN ATAU MELONGGOKKAN "
                         "APA-APA BARANG ATAU BENDA DI ATAS TEMPAT AWAM "
                         "DARIPADA MANA-MANA BANGUNAN ATAU TANAH.",
    # "Pilin Kadar Denda (RM): 500" (C9)
    "kadar_denda": "RM500",
    # C9 langsung tidak menyebut Pegawai/Penerima bagi L-001.
    # no_pembantu_penguatkuasa dikekalkan kerana ia WAJIB pada borang
    # (borang menolak Seterusnya tanpanya) — nilai "2" datang dari
    # overrides.py, ditemui semasa recon peranti.
    "no_pembantu_penguatkuasa": "2",
    # Nilai lama "RAMLI" / "010741852963" direka mengikut konvensyen v2.
    # Dikosongkan 2026-07-29; lihat BLANK_BY_DESIGN.
    "nama_penerima": "",
    "no_ic_penerima": "",
}

# ---------------------------------------------------------------------------
# MBIP-TC-L-004 "Kemaskini Kompaun Lesen" -- sheet 'MBIP-TC-L-004 '
# (trailing-space name), C9. NOTE the tester's last manual round FAILED
# this TC ("kod akta tidak papar apa2 maklumat" on the kemaskini form) --
# history, not an oracle; this run decides fresh.
# ---------------------------------------------------------------------------
TC_DATA["MBIP-TC-L-004"] = {
    "jenis_letter": "L",
    "kesalahan_jalan": "JALAN PAHLAWAN 1",
    "kesalahan_taman": "TAMAN JAYA",
    "kesalahan_poskod": "81000",
    "kesalahan_bandar": "SKUDAI",
    "kesalahan_negeri": "JOHOR DARUL TAKZIM",
    "lokasi_kesalahan": "DEPAN KEDAI",
    "butiran_kesalahan": "TIDAK PAPAR LESEN",
    "tempoh_notis": "1",
    "keterangan_kod_kompaun": "KOMPAUN MENCEGAH KEKOTORAN",
    "kod_akta": "UNDANG-UNDANG KECIL MENCEGAH KEKOTORAN (MDJBT) 1982",
    # C9 lists it WITHOUT the "(UUK 6 (II)) -" prefix here, with trailing
    # period.
    "kesalahan_kompaun": "MELETAKKAN ATAU MELONGGOKKAN APA-APA BARANG "
                         "ATAU BENDA DI ATAS TEMPAT AWAM DARIPADA "
                         "MANA-MANA BANGUNAN ATAU TANAH.",
    "kadar_denda": "RM500",
    "old": {
        "nama": "RAMLI",
        "jalan": "JALAN KOSA 3",
    },
}

# ---------------------------------------------------------------------------
# MBIP-TC-L-005 "Kompaun Form Lesen - Bookmark" -- sheet MBIP-TC-L-005
# (its C3 cell mislabels itself N-005), C9.
# ---------------------------------------------------------------------------
TC_DATA["MBIP-TC-L-005"] = {
    "keterangan_kod_kompaun": "KOMPAUN MENCEGAH KEKOTORAN",
    "kod_akta": "UNDANG-UNDANG KECIL MENCEGAH KEKOTORAN (MDJBT) 1982",
    "kesalahan_kompaun": "MELETAKKAN ATAU MELONGGOKKAN APA-APA BARANG "
                         "ATAU BENDA DI ATAS TEMPAT AWAM DARIPADA "
                         "MANA-MANA BANGUNAN ATAU TANAH.",
    "kadar_denda": "RM500",
    "bookmark_name": "V3 BOOKMARK L",
}

# ---------------------------------------------------------------------------
# MBIP-TC-H-004 "Hantar Semula Data & Gambar Kompaun Lesen" -- sheet
# MBIP-TC-H-004. Same design as H-001..003: relies on the L-001 record
# created earlier in the run.
# ---------------------------------------------------------------------------
TC_DATA["MBIP-TC-H-004"] = {"jenis_letter": "L"}

# ===========================================================================
# Phase 3
# ===========================================================================

# ---------------------------------------------------------------------------
# MBIP-TC-S-001 "Daftar Sitaan" -- sheet MBIP-TC-S-001, C9. On-screen the
# jenis option is "SITAAN" (confirmed in the jenis popup via live recon).
# NOTE the tester's last manual round FAILED this TC (record ended up
# STATUS HANTAR M / STATUS A) -- history, not an oracle.
# ---------------------------------------------------------------------------
TC_DATA["MBIP-TC-S-001"] = {
    # PESALAH - Maklumat Pesalah (C9)
    "nama_pesalah": "KEDAI PERABOT",
    "no_kp_ssm": "ABC123456",
    "no_akuan_lesen": "123456",
    "jalan": "JALAN BARAU 2",
    "taman": "KAMPUNG BARU SKUDAI",
    "poskod": "81000",
    "bandar": "SKUDAI",
    "negeri": "JOHOR DARUL TAKZIM",
    # KOMPAUN - Maklumat Kesalahan (C9)
    "kompaun_jalan_partial": "JALAN GANGSA 2",
    "kompaun_jalan_suggestion": "JALAN GANGSA 2 | TAMAN SRI PUTRI | SKUDAI",
    "kompaun_taman": "TAMAN SRI PUTRI",
    "kompaun_poskod": "81000",
    "kompaun_bandar": "SKUDAI",
    "kompaun_negeri": "JOHOR DARUL TAKZIM",
    "lokasi_kesalahan": "DEPAN SEKOLAH",
    "butiran_kesalahan": "TIDAK ADA LESEN PERNIAGAAN",
    # "Maklumat Kompaun: 1 HARI" (C9)
    "tempoh_notis": "1",
    "keterangan_kod_kompaun": "KOMPAUN PELBAGAI",
    # Trailing period genuine (C9).
    "kod_akta": "UNDANG-UNDANG KECIL PERLESENAN TRED, PERNIAGAAN, "
                "PERINDUSTRIAN DAN PROFESYEN (MDJBT) 1982.",
    "kesalahan_kompaun": "(UUK 3) - MENJALANKAN PERNIAGAAN TANPA LESEN "
                         "MPJBT.",
    # "Pilin Kadar Denda (RM): 500" (C9)
    "kadar_denda": "RM500",
    # "Barang-barang: 1. MEJA - 2 UNIT / 2. KERUSI - 4 UNIT" (C9)
    "barang": [("MEJA", "2"), ("KERUSI", "4")],
    # C9 langsung tidak menyebut Pegawai/Penerima bagi S-001.
    # no_pembantu_penguatkuasa dikekalkan kerana ia wajib pada borang.
    "no_pembantu_penguatkuasa": "2",
    # Nilai lama "KEDAI PERABOT" / "ABC123456" direka mengikut konvensyen
    # v2. Dikosongkan 2026-07-29; lihat BLANK_BY_DESIGN.
    "nama_penerima": "",
    "no_ic_penerima": "",
}

# ---------------------------------------------------------------------------
# MBIP-TC-S-004 "Kemaskini Sitaan" -- sheet 'MBIP-TC-S-004 ' (trailing-
# space name). C9: "Jalan Keruing 11 change to Jalan Harimau Telap" (the
# tester's record held Jalan Keruing 11; this environment's S-001 record
# holds JALAN GANGSA 2, so that is the old value verified/changed here).
# ---------------------------------------------------------------------------
TC_DATA["MBIP-TC-S-004"] = {
    "jenis_letter": "S",
    "kesalahan_jalan": "JALAN HARIMAU TELAP",
    "kesalahan_taman": "TAMAN SRI PUTRI",
    "kesalahan_poskod": "81000",
    "kesalahan_bandar": "SKUDAI",
    "kesalahan_negeri": "JOHOR DARUL TAKZIM",
    "lokasi_kesalahan": "DEPAN SEKOLAH",
    "butiran_kesalahan": "TIDAK ADA LESEN PERNIAGAAN",
    "tempoh_notis": "1",
    "keterangan_kod_kompaun": "KOMPAUN PELBAGAI",
    "kod_akta": "UNDANG-UNDANG KECIL PERLESENAN TRED, PERNIAGAAN, "
                "PERINDUSTRIAN DAN PROFESYEN (MDJBT) 1982.",
    "kesalahan_kompaun": "(UUK 3) - MENJALANKAN PERNIAGAAN TANPA LESEN "
                         "MPJBT.",
    "kadar_denda": "RM500",
    "old": {
        "nama": "KEDAI PERABOT",
        "jalan": "JALAN GANGSA 2",
    },
}

# ---------------------------------------------------------------------------
# MBIP-TC-S-005 "Kompaun Form Sitaan - Bookmark" -- sheet MBIP-TC-S-005
# (its C3 cell mislabels itself K-005). Test Data (C9) is blank; the
# S-001 code combo is used.
# ---------------------------------------------------------------------------
TC_DATA["MBIP-TC-S-005"] = {
    "keterangan_kod_kompaun": "KOMPAUN PELBAGAI",
    "kod_akta": "UNDANG-UNDANG KECIL PERLESENAN TRED, PERNIAGAAN, "
                "PERINDUSTRIAN DAN PROFESYEN (MDJBT) 1982.",
    "kesalahan_kompaun": "(UUK 3) - MENJALANKAN PERNIAGAAN TANPA LESEN "
                         "MPJBT.",
    "kadar_denda": "RM500",
    "bookmark_name": "V3 BOOKMARK S",
}

# ---------------------------------------------------------------------------
# MBIP-TC-H-005 "Hantar Semula Data & Gambar Kompaun Sitaan" -- sheet
# MBIP-TC-H-005. NOTE the tester's round FAILED this ("Tidak berjaya
# hantar semula kompaun sitaan ... STATUS HANTAR - M dan STATUS - A").
# ---------------------------------------------------------------------------
TC_DATA["MBIP-TC-H-005"] = {"jenis_letter": "S"}

# ---------------------------------------------------------------------------
# MBIP-TC-TN-002 "Tarik Notis by No.Notis" -- sheet MBIP-TC-TN-002. Test
# Data (C9) is blank; the notice number is taken at runtime from the
# TN-001 pull (the sheet's steps text is a copy-paste of the Patuh flow;
# the NAME "by No.Notis" is the actual requirement). The tester's round
# FAILED this ("Cannot tarik notis by No.Notis").
# ---------------------------------------------------------------------------
TC_DATA["MBIP-TC-TN-002"] = {"id_penguatkuasa": "msc"}

# ---------------------------------------------------------------------------
# MBIP-TC-TN-003 "Tarik Notis by Tarikh" -- NO SHEET EXISTS in V2.1.14
# (the workbook has 47 TCs). Built anyway per the user's explicit
# decision (2026-07-16): pull notices filtered by date, expected to
# display the matching records. Date = today at runtime.
# ---------------------------------------------------------------------------
TC_DATA["MBIP-TC-TN-003"] = {"id_penguatkuasa": "msc"}

# ---------------------------------------------------------------------------
# MBIP-TC-NK-001 "Notis ke Kompaun > Kompaun" -- sheet MBIP-TC-NK-001.
# C9 cites the tester's notice IPA01N260619002 (environment-specific);
# v3 uses the first notice pulled by ID msc at runtime. Amount for the
# kompaun: not specified in the sheet; RM50 used. The tester's round
# FAILED this (kod kompaun mismatch after conversion).
# ---------------------------------------------------------------------------
TC_DATA["MBIP-TC-NK-001"] = {"id_penguatkuasa": "msc", "amaun": "50"}

# ---------------------------------------------------------------------------
# MBIP-TC-NK-002 "Notis ke Kompaun > Patuh" -- sheet MBIP-TC-NK-002 (its
# C3 cell mislabels itself NK-001). C9 cites the tester's notice
# IPA01N260619005; v3 uses a pulled notice at runtime. Ulasan text per
# the steps ("enter the field of Ulasan and click on the Patuh button").
# ---------------------------------------------------------------------------
TC_DATA["MBIP-TC-NK-002"] = {"id_penguatkuasa": "msc",
                             "ulasan": "PATUH - DISAHKAN OLEH AUTOMASI V3"}


# ===========================================================================
# Pemilihan data ikut PBT
# ===========================================================================
# TC_DATA di atas dibina tangan daripada Excel MBIP dan sudah terbukti pada
# peranti sebenar melalui berpuluh run. Ia KEKAL sebagai sumber untuk MBIP —
# tiada sebab menukar sesuatu yang berfungsi kepada output penjana, walaupun
# penjana itu menghasilkan semula nilainya 100% tepat.
#
# Untuk PBT LAIN, data datang daripada testdata/pbt/<pbt>.py (dijana oleh
# tools/gen_testdata.py) digabung dengan testdata/overrides.py.
#
# NOTA SKOP: kunci kekal dalam bentuk "MBIP-TC-*" walaupun untuk PBT lain,
# kerana 48 fail ujian dinamakan mengikut penomboran MBIP dan merekalah
# rangka ujian. Yang bertukar ialah DATA, bukan senarai ujian. TC yang wujud
# hanya pada PBT lain (contoh P-006 dan TN-003 pada MBPG) belum diliputi —
# ia perlukan fail ujian baharu, bukan sekadar data.

def _pilih_data_pbt():
    import os
    import re
    try:
        import profile as _profile
        p = _profile.load()
    except Exception:                                   # noqa: BLE001
        return None                                     # tiada profil -> MBIP
    pbt = (p.get("pbt") or "").upper()
    if pbt in ("", "MBIP"):
        return None

    try:
        mod = __import__(f"testdata.pbt.{pbt.lower()}", fromlist=["TC_DATA"])
        from testdata import overrides
    except ImportError as e:
        raise ImportError(
            f"Data ujian untuk {pbt} tidak dijumpai ({e}).\n"
            f"  Jana dengan: python tools/gen_testdata.py --write"
        )

    data = overrides.apply(pbt, mod.TC_DATA, p)
    # Tukar "TC-N-001" -> "MBIP-TC-N-001" supaya fail ujian sedia ada
    # boleh mencarinya tanpa diubah.
    return {re.sub(r"^TC-", "MBIP-TC-", k): v for k, v in data.items()}


_lain = _pilih_data_pbt()
_IS_MBIP = _lain is None
if _lain:
    TC_DATA = _lain


# ---------------------------------------------------------------------------
# Medan yang skrip Excel tidak bekalkan
# ---------------------------------------------------------------------------
# Medan ini DIISI dengan BLANK_MARKER — bukan dibiarkan kosong.
#
# Kenapa menaip penanda dan bukan membiarkan kosong: medan kosong pada
# kertas cetak tidak dapat dibezakan daripada medan yang tercicir atau
# gagal diisi. Penanda ini muncul pada kertas sebenar, jadi sesiapa yang
# memegang cetakan itu nampak terus bahawa nilainya datang dari
# ketiadaan data Excel — bukan dari pangkalan data, dan bukan tercicir.
#
# Ia menggantikan nilai rekaan seperti "Buruh En Saiful" yang kelihatan
# seperti data sah dan kerana itu bertahan berbulan tanpa disedari.
# Penanda ini mustahil disangka data sebenar.
BLANK_MARKER = "blank dari test script"

# Medan berangka tidak boleh menerima penanda huruf. NO IC PENERIMA
# hampir pasti menolak huruf secara SENYAP (medan menapis input, bukan
# melontar ralat) — yang bermakna penanda huruf akan menghasilkan medan
# kosong, iaitu keadaan yang penanda ini wujud untuk mengelakkannya.
#
# Nilai ditetapkan pemilik pada 2026-07-29. Ambil perhatian ia SAH dari
# segi format IC Malaysia (990323 = 23 Mac 1999, 11 = kod tempat lahir),
# jadi ia tidak kelihatan palsu dengan sendirinya. Itu diterima kerana
# NAMA PENERIMA di sebelahnya tetap membawa penanda huruf — kertas cetak
# masih menunjukkan rekod itu datang dari skrip ujian.
#
# Jangan tukar tanpa memberitahu pemilik: nilai ini akan masuk ke DB
# staging sebenar dan digunakan untuk trace balik.
BLANK_MARKER_IC = "990323112289"

# Medan yang mesti menerima penanda BERANGKA, bukan penanda huruf.
MEDAN_BERANGKA = {"no_ic_penerima"}

_SEBAB_C10 = "C9 tidak menyebutnya; C10 menanda medan ini optional"
_SEBAB_TIADA = "C9 langsung tidak menyebut Pegawai/Penerima"

BLANK_BY_DESIGN = {
    "MBIP-TC-N-001": {
        "nama_penerima": _SEBAB_C10,       # dahulunya "ALI"
        "no_ic_penerima": _SEBAB_C10,
    },
    "MBIP-TC-K-001": {
        "nama_penerima": _SEBAB_C10,       # dahulunya "Buruh En Saiful"
        "no_ic_penerima": _SEBAB_C10,
    },
    "MBIP-TC-L-001": {
        "nama_penerima": _SEBAB_TIADA,     # dahulunya "RAMLI"
        "no_ic_penerima": _SEBAB_TIADA,
    },
    "MBIP-TC-S-001": {
        "nama_penerima": _SEBAB_TIADA,     # dahulunya "KEDAI PERABOT"
        "no_ic_penerima": _SEBAB_TIADA,
    },
}

# P-001 SENGAJA TIADA dalam senarai ini: C9-nya memang menulis
# "Nama Penerima: ABU / No IC Penerima: 010987654321", jadi kod
# mengisinya seperti biasa. Ia satu-satunya TC yang Excel benar-benar
# membekalkan penerima — kekalkan begitu.


def blank_note(tc_id, field):
    """Pulangkan sebab medan diisi penanda, atau None kalau bukan."""
    return (BLANK_BY_DESIGN.get(tc_id) or {}).get(field)


def blanks_for(tc_id):
    """Senarai medan yang diisi penanda bagi satu TC — untuk laporan."""
    return sorted((BLANK_BY_DESIGN.get(tc_id) or {}).keys())


def _pasang_penanda():
    """Tulis BLANK_MARKER ke setiap medan yang didaftarkan di atas.

    Dilakukan di sini dan bukan ditulis terus dalam setiap blok TC_DATA
    supaya BLANK_BY_DESIGN kekal satu-satunya senarai. Kalau nilai
    ditaip dua kali, suatu hari satu daripadanya akan terlepas dikemas
    kini dan medan itu kembali menjadi data yang kelihatan sah.

    Hanya untuk MBIP: PBT lain ada Excel sendiri yang mungkin MEMANG
    membekalkan medan ini, jadi menampal penanda ke sana akan menimpa
    data sebenar mereka.
    """
    if not _IS_MBIP:
        return
    for tc, medan in BLANK_BY_DESIGN.items():
        if tc not in TC_DATA:
            continue
        for nama in medan:
            TC_DATA[tc][nama] = (BLANK_MARKER_IC if nama in MEDAN_BERANGKA
                                 else BLANK_MARKER)


def penanda_untuk(medan):
    """Penanda yang sepatutnya berada dalam medan ini."""
    return BLANK_MARKER_IC if medan in MEDAN_BERANGKA else BLANK_MARKER


def ialah_penanda(nilai):
    """True kalau nilai ini salah satu penanda — untuk log dan pemeriksa."""
    return str(nilai) in (BLANK_MARKER, BLANK_MARKER_IC)


_pasang_penanda()


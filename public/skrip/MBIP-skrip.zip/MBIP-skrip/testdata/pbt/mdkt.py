"""
Data ujian MDKT — DIJANA AUTOMATIK. Jangan edit dengan tangan.

Sumber : IES-MDKT Testing Script V2.1.10.xlsx
Dijana : 2026-07-27T16:31:56
         oleh tools/gen_testdata.py

Untuk menjana semula selepas Excel dikemas kini:
    python tools/gen_testdata.py --write

Medan yang Excel tidak boleh bekalkan (akaun log masuk, nombor
pembantu penguatkuasa, nombor plate yang hanya tersebut dalam Test
Steps) tidak ada di sini — ia datang dari testdata/overrides.py.
"""

TC_DATA = {
    # MDKT-TC-K-001  Verify that postcode, Taman and Bandar display correctly based on stre
    "TC-K-001": {
        'jenis_letter': 'K',
    },
    # MDKT-TC-K-002  Verify existing information is displayed correctly and the postcode, T
    "TC-K-002": {
        'jenis_letter': 'K',
    },
    # MDKT-TC-N-001  Verify that postcode, Taman and Bandar display correctly based on stre
    "TC-N-001": {
        'jenis_letter': 'N',
    },
    # MDKT-TC-N-002  Verify existing information is displayed correctly and the postcode, T
    "TC-N-002": {
        'jenis_letter': 'N',
    },
    # MDKT-TC-P-001  Verify that postcode, Taman and Bandar display correctly based on stre
    "TC-P-001": {
        'jenis_letter': 'P',
    },
    # MDKT-TC-P-002  Verify existing information is displayed correctly and the postcode, T
    "TC-P-002": {
        'jenis_letter': 'P',
    },
}

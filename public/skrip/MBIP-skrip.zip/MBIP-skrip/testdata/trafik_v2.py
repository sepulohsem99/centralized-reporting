"""Data ujian KOMPAUN TRAFIK — build hotfix 2026-08-20 MBIP.

>>> SUMBER: keputusan CEO 2026-08-21, direkod verbatim dalam
CENTRALIZED REPORTING AI CENTRIC TESTING/reports/
DATA-UJIAN-KOMPAUN-TRAFIK-MBIP.md. <<<

Ini BUKAN dari Excel (build baru mendahului Excel V2.1.17 pada field
kadar denda/cukai jalan/petak/kupon). Bila Excel baru mengesahkan nilai
berbeza, kemaskini di SINI sahaja dan catat sumbernya — jangan reka.
Padanan dropdown: contains, tak peka huruf; baca-balik sentiasa direkod.
"""

TRAFIK_V2 = {
    # --- Tab 1: MAKLUMAT PESALAH ---
    "nama_pesalah": "Saifullah Muhamad",
    "no_kp_ssm": "1111111111111",
    "no_kereta": "JYX6605",
    "no_cukai_jalan": "1111111111111",
    "jenis_kereta": "toyota corolla 1.5x",
    "warna_kereta": "silver",
    "no_petak": "10",
    "no_kupon": "10",

    # --- Tab 2: MAKLUMAT KESALAHAN / KOMPAUN ---
    "lokasi_kesalahan": "HADAPAN KEDAI NO 10 - UJIAN AUTOMASI",
    "butiran_kesalahan": ("LETAK KERETA DALAM PETAK KUNING - "
                          "UJIAN AUTOMASI E2E CLEANUP-PM"),
    "tempoh_kompaun": "2",
    "tempoh_notis": "2",      # alias — fill_kompaun_tab_direct membacanya
    # >>> [PENEMUAN-DATA] 2026-08-27 (peta_kod DB peranti): niat CEO
    # 'Akta Jalan Parit dan Bangunan' — display sebenar dalam DB ialah
    # 'AKTA JALAN/PARIT/BANGUNAN' (kod 'jpb', dengan slash tanpa
    # 'dan'); penapis live-search memerlukan teks VERBATIM. Rantaian
    # jpb -> akta 62 -> 2 kesalahan disahkan LENGKAP dalam DB. Kalau
    # jpb tidak muncul dalam senarai borang Trafik (jeniskod P vs K),
    # kod fallback ke KPD/PERINTAH 39 -> akta 37 secara automatik. <<<
    "keterangan_kod_kompaun": "AKTA JALAN/PARIT/BANGUNAN",
    # 2026-08-27 (dump #14): penapis '62' -> 'Tiada rekod dijumpai' —
    # live-search akta mencari TEKS keterangan, bukan kod. Guna
    # keterangan VERBATIM DB akta kod 62.
    "kod_akta": "AKTA JALAN PARIT DAN BANGUNAN (AKTA 133)",
    # None = PILIH BARIS PERTAMA (keputusan CEO: "pilih yang atas")
    "kesalahan_kompaun": None,
    "kadar_denda": 200,          # clamp ke julat MIN/MAX skrin

    # --- Tab 3: MAKLUMAT PEGAWAI ---
    "no_pembantu_penguatkuasa": "1180460",
    "nama_penerima": "saifullah muhamad",
    "no_ic_penerima": "990423115579",
    # OPERASI: suis — BIAR DEFAULT, baca sahaja
}


# MBIP v3 — Panduan Menjalankan Test Automation

## Alur kerja

```
+-------------------------+
| 1. Pasang               |
|                         |
|   Node.js + Python      |
|   adb + appium          |
|   driver uiautomator2   |
|   pip install -r ...    |
+-------------------------+
      |
      v
+-------------------------+
| 2. Sambung telefon      |
|                         |
|   USB debugging: ON     |
|   APK PBT dipasang      |
|   Auto-lock: OFF        |
+-------------------------+
      |
      v
+-------------------------+
| 3. Run                  |
|                         |
|   T1: appium            |
|   T2: run_and_report    |
|   Pilih PBT             |
|   Tunggu 1.5-2.5 jam    |
+-------------------------+
      |
      v
+-------------------------+
| 4. Baca hasil           |
|                         |
|   Dashboard update      |
|   Refresh browser       |
+-------------------------+
```

## 1. Pasang — sekali sahaja

- **Node.js** — nodejs.org → LTS
- **Python 3.11+** — python.org → tanda **Add to PATH**
- **adb** — platform-tools → tambah ke PATH
- **Appium** — arahan di bawah

**Command Prompt**

```
npm install -g appium
appium driver install uiautomator2
pip install -r requirements.txt
```

> **Nota:** Terlepas **Add Python to PATH**? Uninstall, install semula.

## 2. Sediakan telefon

- **Developer options** — About phone → ketuk **Build number** 7 kali
- **USB debugging** — hidupkan dalam Developer options
- **Sambung USB** — tekan **Allow** pada telefon
- **Auto-lock** — matikan

> **Nota:** Serial telefon tak perlu ditaip — suite cari sendiri.

## 3. Setiap kali nak run

**Terminal 1 — biar terbuka**

```
appium
```

**Beginilah rupanya bila Appium jalan**

```
PS C:\Users\anda> appium
[Appium] Welcome to Appium v3.5.2
[Appium] AndroidUiautomator2Driver loaded in 6.150s
[Appium] listener started on http://0.0.0.0:4723
```

> **Nota:** Kursor berkelip, prompt tak kembali — itu betul. **Jangan tutup tetingkap ni.**

**Terminal 2 — jalankan test**

```
cd C:\laluan\ke\mbip-v3
tests\run_and_report.bat
```

**Menu PBT akan keluar**

```
1. MBIP - production
2. MBIP - staging

Masukkan nombor pilihan: _
```

> ⚠️ Pastikan APK pada telefon betul-betul milik PBT yang dipilih. Suite tak boleh semak ini untuk anda.

## 4. Baca hasil

| | |
|---|---|
| **PASSED** | Lulus. Tiada tindakan. |
| **FAILED** | Gagal. Baca lajur Nota. |
| **SKIPPED** | Sengaja dilangkau. |
| **ERROR** | Tak sempat jalan. Rerun. |

- **Laporan** — `reports\mbip_v3_report.html`
- **Dah buka?** — Refresh sahaja
- **Log penuh** — `reports\last_run.txt`

## 5. Masalah biasa

| | |
|---|---|
| Tiada device | Periksa kabel. `adb devices`. |
| `unauthorized` | Tengok skrin telefon — tekan Allow. |
| Appium tak hidup | Terlupa Terminal 1. |
| Banyak ERROR serentak | UiAutomator2 crash. Restart appium, rerun. |
| Lebih satu device | `set MBIP_UDID=<serial>` |

## 6. Tambah PBT baharu

Satu fail JSON dalam `profiles/`. Salin yang sedia ada, tukar nilai. Tiada kod diubah.

**profiles/mbpg-production.json**

```json
{
  "pbt": "MBPG",
  "env": "production",
  "app_package": "com.anonymous.react_ies_v1",
  "internal_ip": "113.211.155.174",
  "lesen_aplikasi": "359563990174736",
  "username": "msc",
  "password": "Pass1"
}
```

> **Nota:** Medan `ISI-SINI` ditolak sebelum ujian bermula — gagal dalam 2 saat, bukan 2 jam.

## 7. Peraturan

- **Seorang sahaja run** — Data test sama, server sama. Dua orang serentak = rekod bertindih.
- **Jangan edit `.py`** — Semua automatik.
- **Jangan guna telefon** — Semasa test berjalan.
- **Nak berhenti** — `Ctrl+C` dalam Terminal 2.

"""
printer_utils — polling + audible/visible operator recall for the Cetak
(print) test cases.

KENAPA WUJUD
------------
Lima TC Cetak (N/P/K/L/S-002) mencetak ke printer Bluetooth thermal yang
BERPASANGAN tetapi AUTO-MATI selepas ~10 minit tanpa aktiviti. Semasa run
penuh (1.5-2.5 jam), printer hampir pasti sudah tidur menjelang TC Cetak
pertama dicapai.

Dulu TC ini pytest.mark.skip terus. Sekarang, apabila printer tidak dapat
dicapai, kita TIDAK terus skip -- kita PANGGIL operator dan tunggu:

  - Bip: winsound.Beep (2 nada). BUKAN print("\\a"): run_and_report.bat
    alih SEMUA stdout/stderr ke reports\\last_run.txt (`> ... 2>&1`), jadi
    watak BEL cuma tertulis dalam fail dan tiada bunyi keluar. winsound
    mengeluarkan bunyi terus dari PC speaker, lepas dari redirection.
  - Banner ke sys.__stderr__ (terminal SEBENAR, bukan handle stderr yang
    dialihkan) supaya operator nampak arahan walaupun stdout dialih ke
    fail.
  - Poll setiap 5 saat sehingga 5 minit; ulang bip setiap 15 saat.
  - Sebaik printer hidup (satu percubaan cetak berjaya), teruskan sendiri
    -- tiada input operator diperlukan.
  - Hanya kalau 5 minit tamat: pemanggil buat pytest.skip(...).

Modul ini TIDAK tahu apa-apa tentang Appium. Ia menerima satu callable
`attempt` yang melakukan SATU percubaan cetak dan mengembalikan
(status, detail); cetak_page.py yang membekalkannya.
"""

import sys
import time


# ---------------------------------------------------------------------------
# Klasifikasi mesej alert hasil-cetak (aplikasi lapor keputusan operasi
# melalui native alert BERJAYA/RALAT -- lihat base_page.dismiss_native_alerts).
# Padanan tidak case-sensitive. Token dijaga longgar tetapi tidak bertindih:
# tiada token kejayaan yang juga muncul dalam mesej ralat printer biasa.
# ---------------------------------------------------------------------------
SUCCESS_TOKENS = (
    "BERJAYA", "SUCCESS", "DICETAK", "PRINTED", "PRINT SUCCESS",
    "SIAP CETAK", "SELESAI",
)

# Tanda printer tidak boleh dicapai / belum hidup / tidak bersambung.
OFFLINE_TOKENS = (
    "PRINTER", "BLUETOOTH", "TIDAK DAPAT", "TIDAK DIJUMPAI", "TIDAK BERSAMBUNG",
    "TIDAK DISAMBUNG", "SILA HIDUP", "SILA SAMBUNG", "TIADA PRINTER",
    "NOT CONNECTED", "NOT FOUND", "NO DEVICE", "DISCONNECT", "UNAVAILABLE",
    "SAMBUNGAN", "CONNECT", "PAIR", "GAGAL",
    # Alert sebenar bila arahan cetak tidak dihantar ke printer (disahkan
    # fizikal 2026-07-29: kertas TIDAK keluar bila alert ini muncul; dump
    # ui_dumps/cetak_N_result.xml). Dulu jatuh ke "unknown" -- betul secara
    # kebetulan (dilayan sebagai belum-sedia), tapi sebab hilang dari laporan.
    "COMMAND_NOT_SEND", "COMMAND NOT SEND",
)


def classify_message(msg):
    """('printed' | 'unreachable' | 'unknown', normalized_msg).

    - Padanan token kejayaan -> 'printed'.
    - Padanan token printer-offline -> 'unreachable'.
    - Selainnya -> 'unknown' (pemanggil patut dump page source; semasa
      aliran Cetak, mesej bukan-kejayaan paling mungkin bermaksud printer
      belum sedia, jadi pemanggil biasanya melayan 'unknown' sebagai
      sebab untuk terus memanggil operator, bukan terus skip)."""
    if not msg:
        return "unknown", ""
    upper = msg.upper()
    if any(tok in upper for tok in SUCCESS_TOKENS):
        return "printed", msg
    if any(tok in upper for tok in OFFLINE_TOKENS):
        return "unreachable", msg
    return "unknown", msg


# Status yang bermakna "berhenti tunggu -- cetakan berjaya".
_TERMINAL_OK = ("printed", "printed_unconfirmed")


def beep():
    """Dua nada bip dari PC speaker. Senyap-gagal pada bukan-Windows atau
    kalau winsound tiada."""
    try:
        import winsound
        winsound.Beep(1000, 600)
        winsound.Beep(1400, 600)
    except Exception:                                        # noqa: BLE001
        pass


def banner(msg):
    """Tulis ke terminal SEBENAR (sys.__stderr__), lepas dari redirection
    stdout/stderr run_and_report.bat."""
    try:
        print(msg, file=sys.__stderr__, flush=True)
    except Exception:                                        # noqa: BLE001
        pass


def wait_for_printer(attempt, tc_label, poll_interval=5, timeout=300,
                     beep_interval=15):
    """Cuba cetak berulang kali sehingga berjaya atau `timeout` tamat.

    `attempt`  : callable sifar-argumen yang melakukan SATU percubaan
                 cetak dan memulangkan (status, detail). status:
                   'printed' / 'printed_unconfirmed' -> berjaya (berhenti)
                   'unreachable' / 'unknown' / apa-apa lain -> belum sedia
    `tc_label` : cth 'N-002' untuk mesej.

    Semasa printer belum sedia: bip (setiap `beep_interval` saat) + banner
    ke terminal sebenar supaya operator boleh HIDUPKAN printer (yang
    auto-mati selepas 10 minit). Pulang sebaik satu percubaan berjaya --
    tiada input operator diperlukan.

    Pulangan: dict {printed, waited_seconds, poll_count, last_detail,
    messages} untuk laporan.
    """
    start = time.monotonic()
    last_beep = None
    polls = 0
    messages = []

    while True:
        polls += 1
        status, detail = attempt()
        if detail:
            messages.append(detail)

        # Record-selection failure: TERMINAL. This is not the printer being
        # asleep -- the record we were told to print doesn't exist / didn't
        # match. Stop immediately so the caller FAILs instead of waiting out
        # the operator timeout and then skipping (or, worse, printing stale).
        if status == "record_error":
            return {
                "printed": False,
                "record_error": detail or "record not found / mismatch",
                "unconfirmed": False,
                "waited_seconds": round(time.monotonic() - start, 1),
                "poll_count": polls,
                "last_detail": detail,
                "messages": messages,
            }

        if status in _TERMINAL_OK:
            waited = time.monotonic() - start
            if polls > 1:
                banner(f"  [PRINTER] {tc_label}: printer kembali hidup — "
                       f"cetakan berjaya selepas menunggu {waited:.0f}s. "
                       f"Meneruskan sendiri.")
            return {
                "printed": True,
                "unconfirmed": status == "printed_unconfirmed",
                "waited_seconds": round(waited, 1),
                "poll_count": polls,
                "last_detail": detail,
                "messages": messages,
            }

        elapsed = time.monotonic() - start
        if elapsed >= timeout:
            return {
                "printed": False,
                "unconfirmed": False,
                "waited_seconds": round(elapsed, 1),
                "poll_count": polls,
                "last_detail": detail,
                "messages": messages,
            }

        # beep_interval=None -> operator-absent mode: no beep, no banner
        # (nobody is at the machine, so the recall would only spam the log).
        now = time.monotonic()
        if beep_interval is not None and (
                last_beep is None or (now - last_beep) >= beep_interval):
            beep()
            banner(
                f"  [PRINTER] {tc_label}: printer TIDAK dapat dicapai "
                f"({detail or 'tiada respons'}). "
                f"SILA HIDUPKAN printer Bluetooth. "
                f"Menunggu {int(elapsed)}s/{int(timeout)}s — "
                f"akan sambung sendiri sebaik printer hidup."
            )
            last_beep = now

        time.sleep(poll_interval)

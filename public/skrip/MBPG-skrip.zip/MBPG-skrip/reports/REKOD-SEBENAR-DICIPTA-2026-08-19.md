# REKOD SEBENAR DICIPTA — production MBPG

> Setiap nombor di bawah ialah rekod **HIDUP** pada production MBPG
> (113.211.155.174). Ia dicipta oleh automasi ujian di bawah
> `MBPG_MOD_SEBENAR=1`, atas kelulusan pemilik 2026-08-17.
>
> **Untuk PM:** semua rekod ini data ujian. Nama pesalah bermula dengan
> `UJIAN AUTOMASI E2E`, dan medan catatan membawa `AUTOMASI-CLEANUP-PM`.
> Pembatalan melalui portal ePBT oleh pihak berautoriti — automasi
> TIDAK memadam apa-apa.
>
> Satu kitaran boleh menjana LEBIH DARIPADA SATU nombor (cipta -> NK
> convert -> kemaskini). Baris lama TIDAK dipadam apabila rekod
> digantikan: nombor itu tetap wujud pada production.

| No. rekod | TC | Borang | Masa | Jenis | Status | Asal |
|---|---|---|---|---|---|---|
| `PGP02N260819002` | N-001 | N | 2026-08-19 16:36:29 | Notis | baru | - |
| `PGP02P260819003` | P-001 | P | 2026-08-19 16:46:38 | Kompaun | baru | - |
| `PGP02K260819004` | K-001 | K | 2026-08-19 16:58:58 | Kompaun | baru | - |
| `PGP02K260819005` | K-001 | K | 2026-08-19 17:11:07 | Kompaun | baru | - |
| `PGP02K260819006` | K-001 | K | 2026-08-19 17:23:18 | Kompaun | baru | - |

# MBPG — LAPORAN AKHIR FASA 1 + FASA 2

**Peranti:** Ulefone Armor 27, `5008TF2010009401`
**App:** `com.anonymous.react_ies_v1` build **2.1.21**
**Oracle:** V2.1.20 — build **tidak sepadan**; lihat §5.
**Persekitaran:** **PRODUCTION** `113.211.155.174`, disahkan dari
bacaan peranti, bukan dari profil.
**Mod sepanjang:** `MBPG_DRY_RUN=1`, `MBPG_BENARKAN_SERAH=0`.
**Tempoh:** 2026-08-07 → 2026-08-12.

Dokumen sokongan: `LAPORAN-49-TC.md` (butiran setiap TC),
`MATRIX-20260812.csv` (284 baris sweep), `docs/D-0*.md` (defek),
`testdata/sets/BEZA-STAGING-VS-PRODUCTION.md`, `PAPAN.md`.

---

## 1. KEPUTUSAN PALING PENTING

### SIFAR REKOD DICIPTA

Sepanjang Fasa 1 dan Fasa 2, pada peranti penguatkuasa production:

```
local_ekpn_notis_amaran    : 0    (baseline 0)
local_ekpn_tawaran_kompaun : 0    (baseline 0)
local_ekpn_sita            : 0    (baseline 0)
local_pilihan_kegemaran    : 0    (baseline 0)
kaunter siri: {tawaran_kompaun:1, notis_amaran:2, sita:1}  — TIDAK bergerak
```

Kaunter siri diperhati **berasingan daripada kiraan baris**, sebab
rekod yang dicipta lalu disegerakkan boleh meninggalkan kiraan 0
sambil menaikkan kaunter. Ia tidak bergerak.

Tetapan peranti juga tidak berubah: `113.211.155.174 / Ext`.

### Tiada SERAH / HANTAR / SAHKAN / YA ditekan

Corong dry-run menilai **setiap** tap melalui satu chokepoint. Tiada
kod ujian memegang sesi Appium yang tidak berkawal.

| Ukuran (kumulatif) | Nilai |
|---|---|
| Tap dinilai oleh corong | **>3,000** |
| Tap disekat | 11 — **semuanya positif palsu**, setiap satu disiasat dari forensik sebelum apa-apa dilonggarkan |
| Pelanggaran sebenar | **0** |
| Relaunch pemulihan dicatat | 31+ |
| Ujian gerbang luar talian | **296 hijau** |

---

## 2. FASA 1 — 49 TC (fill-only)

| Keputusan | Bil. | TC |
|---|---|---|
| **LULUS** | **12** | T-001, T-002, T-003, T-005, T-006, T-007, T-009, T-010, T-011, N-001, P-001, K-001 |
| CALON DEFEK | 1 | T-004 → D-01 |
| SKIP jujur | 1 | N-003 — kamera tidak boleh diskrip dalam had 15 min |
| TIDAK BOLEH DILAKSANA PADA BUILD INI | 3 | N-005, P-005, K-005 → D-04 |
| TIDAK TERBUKTI | 1 | T-012 — laluan sesi-kekal tidak pernah dicetuskan |
| SKIP arahan pemilik | 1 | T-008 — Selaras Pelesen (sync 3–4 jam) |
| SKIP guard (menghantar/mencipta rekod) | 18 | — |
| SKIP luar skop (pencetak) | 12 | — |
| **JUMLAH** | **49** | |

Daripada 18 TC dalam skop teknikal Fasa 1, **12 LULUS**. Tiada satu
pun daripada baki 6 gagal atas kelemahan skrip: satu defek app, satu
had alat, tiga ciri yang tiada pada build ini, satu tidak diperhati.

Sorotan: **K-001** lulus melalui lookup **MySIKAP** (tekan-tahan
ImageView), bukan butang `ePBT` — lihat D-05.

---

## 3. FASA 2 — SWEEP 284 SET

**284/284 dipandu. 280 LULUS (98.6%). 0 rekod.**

| | |
|---|---|
| Positif LULUS (3 dropdown + baca-balik) | **275/279** |
| Negatif LULUS (dropdown kosong seperti dijangka) | **5/5** |
| GAGAL | **4** → D-06 |
| Borang | P 236 + K 48; setiap set dipandu **sekali** |
| Laluan | **B** — isi Pesalah minimum + sauh alamat berposkod |
| Masa | ~7 jam merentas beberapa sambungan |
| Post-check | BERSIH sepanjang |

Pathfinder mengesahkan laluan **A (lompat terus ke dropdown tanpa
Pesalah) DISEKAT** oleh gerbang urutan tab app. Semua 284 melalui B.
Poskod tidak pernah ditaip — sauh alamat berposkod dipilih automatik
untuk mengelak D-03.

### Kadar denda terkumpul

| Denda | Set |
|---|---|
| RM 1000 | 135 |
| RM 500 | 124 |
| RM 2000 | 11 |
| RM 250 | 4 |
| RM 5000 | 1 |

**Sifar** set lulus dengan denda kosong. Julat yang app papar
(`MIN:`/`MAX:`) disemak silang terhadap DB setiap set — **tiada
percanggahan julat**.

---

## 4. DEFEK

| ID | Ringkasan | Kesan | Dokumen |
|---|---|---|---|
| **D-01** | Selaras **Alamat** tidak idempotent — `Duplicate entry for local_ekpn_bandar`, app ranap pada sync kedua | Sync tidak boleh diulang | `DEFEK-MBPG-2.1.21.md` |
| **D-02** | **Internal IP** tidak kekal — read-back mengesahkan nilai yang app buang | Konfigurasi mengesahkan diri sendiri secara palsu | `DEFEK-MBPG-2.1.21.md` |
| **D-03** | **1276/3493 (36.5%)** rekod jalan production tiada poskod | Kompaun pada jalan itu tidak boleh didaftarkan — tab Pesalah tidak boleh lengkap | `D-03-POSKOD-KOSONG.md` |
| **D-04** | Build 2.1.21 **tiada UI untuk mencipta bookmark** (popup hanya ✕/HAPUS/PILIH) | N/P/K-005 tidak boleh dilaksana | `D-04-BOOKMARK-TIADA-UI-CIPTA.md` |
| **D-05** | Borang Letak Kereta **mencerminkan plat** ke Nama Pesalah + No K/P/SSM; ePBT dan MySIKAP ialah kawalan berbeza | Tafsiran lookup terhad | `D-05-EPBT-DAN-CERMIN-PLAT.md` |
| **D-06** | **Baca-balik gagal pada kesalahan 148 (SEK 74)** — 3 set; modal DITUTUP jadi pemilihan berjaya | Punca **belum dicirikan** (arahan pemilik) | `D-06-READBACK-KESALAHAN-148.md` |

> **Penomboran:** pemilik merujuk isu kesalahan 148 sebagai "D-04"
> dalam keputusan 2026-08-12. D-04 sudah dipakai untuk bookmark, jadi
> ia direkod sebagai **D-06**. Rujukan pemilik "D-04 (kesalahan 148)"
> = D-06.

D-01, D-02, D-03 menjejaskan **pengguna sebenar**. D-04 ialah jurang
ciri. D-05 dan D-06 ialah tingkah laku yang direkod untuk pasukan app.

---

## 5. BEZA STAGING vs PRODUCTION, DAN 2.1.20 vs 2.1.21

### Data: mapping staging tidak boleh dipercayai untuk production

| | Staging (mapping) | Production (DB peranti) |
|---|---|---|
| kod kompaun | 25 | **9** |
| akta | 34 | **23** |
| kesalahan | 146 | **120** |

Set kombo dijana **semula** dari DB production (arahan pemilik
2026-08-07). Butiran penuh:
`testdata/sets/BEZA-STAGING-VS-PRODUCTION.md`.

### Build: oracle 2.1.20, peranti 2.1.21

Tiada APK 2.1.20 pada mesin ini, jadi **tiada** perbezaan di bawah
boleh disahkan sebagai regresi.

| Perkara | Oracle 2.1.20 | 2.1.21 pada peranti |
|---|---|---|
| Cipta bookmark | ada | popup hanya ✕/HAPUS/PILIH (D-04) |
| Kawalan lookup | "MySIKAP" | `ePBT` (butang) **dan** MySIKAP (ImageView, tekan-tahan) — dua kawalan |
| Nama modul | "Trafik" | "Letak Kereta" |
| Label Tetapan | `LESEN APLIKASI` | `Lesen Applikasi:` (dua p) |
| Menu Selaras | `Pengguna` | `Penguna` |
| Dialog Selaras | Melayu | bercampur — Jenis Kenderaan pulangkan "saved successfully!" |
| Tajuk dialog lesen | `BERJAYA` | `BEJAYA` |

---

## 6. APA YANG TIDAK TERBUKTI

Bahagian ini wajib. Ia menyenaraikan apa yang **tidak** boleh
disimpulkan, supaya senyap tidak dibaca sebagai lulus.

1. **Tiada laluan penghantaran diuji.** SERAH/HANTAR/SAHKAN ialah
   trip-wire. Kita tahu borang boleh **diisi**; kita tidak tahu apa
   yang app buat apabila borang **diserahkan**. 18 TC bergantung
   sepenuhnya pada ini.
2. **Tiada rekod pernah wujud**, jadi Kemaskini / Cetak / Tarik /
   Senarai / Hantar Semula / Notis→Kompaun tiada subjek. Dilangkau
   kerana prasyaratnya haram, bukan kerana diperiksa dan didapati
   baik.
3. **Pencetak** di luar skop; tiada perkakasan disambung.
4. **T-008 Selaras Pelesen** tidak disentuh langsung.
5. **T-012 Remember Me** tidak pernah dicetuskan pada laluan
   sesi-kekal. Sebaliknya diperhati: selepas relaunch, app **jatuh ke
   skrin login** — bukti bertentangan, direkod dalam ledger.
6. **Tab PENERIMA** pada P-001/K-001 tidak dimasuki (laluan ke sana
   menghala kepada Serah). Kadar denda tidak pernah **ditaip**, hanya
   dibaca.
7. **T-002 dengan nilai lesen BERBEZA** tidak diuji — menulis lesen
   salah pada peranti production boleh mengunci app, dan `finally`
   tidak dapat memulihkan apa yang tersembunyi di sebalik kunci.
8. **D-06:** sama ada nilai kesalahan 148 benar-benar TERSIMPAN
   walaupun baca-balik gagal. Kalau tersimpan, ini isu alat sahaja;
   kalau tidak, kompaun SEK 74 tidak boleh didaftarkan. **Perbezaan
   itu belum ditentukan.**
9. **MySIKAP pada medan kosong** — Nama/IC sudah berisi (plat, melalui
   D-05) sebelum lookup diketuk, jadi laluan "isi medan kosong" tidak
   diperhati. Nilai yang dipulangkan juga tidak disahkan betul untuk
   plat itu (oracle tiada jangkaan).
10. **Corong tidak pernah diuji terhadap penghantaran SEBENAR.** Ia
    memadan teks butang. Butang yang menghantar tanpa memadan
    mana-mana corak akan lulus — kami tidak tahu ada atau tiada,
    kerana tiada satu pun ditekan. Yang terbukti ialah sebaliknya: ia
    menyekat 11 perkara yang tidak sepatutnya disekat, dan setiap satu
    hanya dilonggarkan selepas bukti forensik, dengan corak
    DISEMPITKAN (sauh penuh, sempadan perkataan, gandingan struktur) —
    bukan pengecualian diluaskan.
11. **Sweep memandu setiap set SEKALI, pada satu borang.** Set P tidak
    dipandu semula pada borang N walaupun ia dalam skop kedua-duanya;
    kombinasinya sama, tetapi tingkah laku khusus-borang N tidak
    diuji oleh sweep.

---

## 7. DASAR YANG BERKUAT KUASA

* **Fasa C (create / print / submit) BERKUNCI** — menunggu kelulusan
  **bertulis** PM + MBPG. Spec: `docs/SPEC-FASA-C-E2E-MBPG.md`.
  `MBPG_IZIN_SERAH` kekal tidak diisi; `MBPG_DRY_RUN=1` dan
  `MBPG_BENARKAN_SERAH=0` kekal lalai.
* **Selaras Pelesen HARAM** — dikuatkuasakan pada lapisan tap.
* **Positif palsu pada TEKS DATA** (baris dropdown, keterangan
  kesalahan): baiki corak + gerbang, sambung. **Butang tripwire
  sebenar: HENTI KERAS**, forensik, tunggu pemilik. Dikodkan dalam
  `guard/dasar.py`.
* **Data peribadi** hasil lookup MySIKAP kekal sebagai bukti pada
  cakera; `.gitignore` menutup `reports/forensik/`, `reports/log/`,
  `ui_dumps/`, `*.png`, `*.db`, `data/tmp/`, `profiles/*.json`.
  Suite meredact hasil lookup sebelum mencatatnya.

---

## 8. CARA MENJALANKAN SEMULA

```
python -m pytest tests_offline -q            # 296 gerbang, tanpa peranti
python tools/jana_set.py --semak             # set kombo idempoten
python devtools/demo_fasa1.py                # demo Fasa 1 penuh (~25 min)
MBPG_DEMO_PANTAS=1 python devtools/demo_pantas.py   # demo pantas (~22 min)
python devtools/sweep_penuh.py               # sweep (sambung dari CSV)
python devtools/sweep_penuh.py --had 5       # ujian pendek sweep
```

Semua memerlukan `MBPG_IZIN_PRODUCTION=1`. Tiada satu pun boleh
mencipta rekod.

# REKOD SEBENAR DICIPTA — production MBPG

> Setiap nombor di bawah ialah rekod **HIDUP** pada production MBPG
> (113.211.155.174). Ia dicipta oleh automasi ujian di bawah
> `MBPG_MOD_SEBENAR=1`, atas kelulusan pemilik 2026-08-17.
>
> **Untuk PM:** semua rekod ini data ujian. Nama pesalah bermula dengan
> `UJIAN AUTOMASI E2E`, dan medan catatan membawa `AUTOMASI-CLEANUP-PM`.
> Pembatalan melalui portal ePBT oleh pihak berautoriti — automasi
> TIDAK memadam apa-apa.
>
> Satu kitaran boleh menjana LEBIH DARIPADA SATU nombor (cipta -> NK
> convert -> kemaskini). Baris lama TIDAK dipadam apabila rekod
> digantikan: nombor itu tetap wujud pada production.

| No. rekod | TC | Borang | Masa | Jenis | Status | Asal |
|---|---|---|---|---|---|---|
| `PGP02N261005001` | N-001 | N | 2026-10-05 10:29:03 | Notis | baru | - |
| `PGP02N261005002` | N-004 | N | 2026-10-05 10:32:16 | Notis | hasil-kemaskini | PGP02N261005001 |
| `PGP02N261005003` | N-001 | N | 2026-10-05 11:09:22 | Notis | baru | - |
| `PGP02N261005004` | N-004 | N | 2026-10-05 11:12:36 | Notis | hasil-kemaskini | PGP02N261005003 |
| `PGP02N261005005` | N-001 | N | 2026-10-05 11:55:24 | Notis | baru | - |
| `PGP02N261005006` | N-004 | N | 2026-10-05 11:58:40 | Notis | hasil-kemaskini | PGP02N261005005 |
| `PGP02P261005001` | P-001 | P | 2026-10-05 12:11:21 | Kompaun | baru | - |
| **(TIDAK TERTANGKAP)** | P-004 | P | 2026-10-05 12:14:23 | Kompaun | hasil-kemaskini | PGP02P261005001 |
| `PGP02K261005002` | K-001 | K | 2026-10-05 12:36:58 | Kompaun | baru | - |
| `PGP02K261005003` | K-004 | K | 2026-10-05 12:40:28 | Kompaun | hasil-kemaskini | PGP02K261005002 |
| `PGP02K261005004` | K-001 | K | 2026-10-05 12:54:31 | Kompaun | baru | - |
| `PGP02K261005005` | K-004 | K | 2026-10-05 12:58:03 | Kompaun | hasil-kemaskini | PGP02K261005004 |
| `PGP02K261005006` | K-001 | K | 2026-10-05 13:12:09 | Kompaun | baru | - |
| `PGP02K261005007` | K-004 | K | 2026-10-05 13:15:39 | Kompaun | hasil-kemaskini | PGP02K261005006 |
| `PGP02P261005008` | P-001 | P | 2026-10-05 14:25:02 | Kompaun | baru | - |
| `PGP02K261005009` | K-001 | K | 2026-10-05 14:41:45 | Kompaun | baru | - |
| `PGP02K261005010` | K-004 | K | 2026-10-05 14:45:15 | Kompaun | hasil-kemaskini | PGP02K261005009 |
| `PGP02K261005011` | K-001 | K | 2026-10-05 14:59:27 | Kompaun | baru | - |
| `PGP02K261005012` | K-004 | K | 2026-10-05 15:02:56 | Kompaun | hasil-kemaskini | PGP02K261005011 |
| `PGP02K261005013` | K-001 | K | 2026-10-05 15:17:09 | Kompaun | baru | - |
| `PGP02K261005014` | K-004 | K | 2026-10-05 15:20:40 | Kompaun | hasil-kemaskini | PGP02K261005013 |

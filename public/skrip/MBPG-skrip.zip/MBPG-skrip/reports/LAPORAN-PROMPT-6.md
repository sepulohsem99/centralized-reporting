# LAPORAN PROMPT 6 — K-001 mySIKAP + MOD SEBENAR TERKAWAL

**Tarikh:** 2026-08-17
**Status:** Bahagian 1 SELESAI · Bahagian 2 SELESAI · Bahagian 3.2–3.7 DIBINA
**Menunggu:** kelulusan pemilik sebelum bendera dihidupkan pada device

---

## RINGKASAN SATU MUKA

| Bahagian | Hasil |
|---|---|
| 1. K-001 mySIKAP | **DISAHKAN pada device 2026-08-17.** Butang wujud, berasingan dari ePBT. Locator objek halaman yang SALAH ditemui dan dibetulkan. |
| 2. P-005 / K-005 | **DITUTUP** — ditanda PASS-BY-REPRESENTATIVE dalam `LAPORAN-49-TC.md`. |
| 3. Mod sebenar | **DIBINA.** Bendera + konteks berstruktur + penanda data + log rekod + kitaran 3.5. |
| Ujian gerbang | **762 LULUS, 0 GAGAL** (dari 506 sebelum ini — 256 baharu). |
| Rekod dicipta | **0.** Tiada bendera dihidupkan pada device. |

---

## BAHAGIAN 1 — K-001 mySIKAP

### Recon device sebenar

`devtools/recon_mysikap.py`, MBPG production `113.211.155.174`,
Ulefone Armor 27 (`5008TF2010009401`), build 2.1.21, 2026-08-17.
**BACA SAHAJA — ePBT TIDAK ditekan.**

Bukti: `docs/recon/mysikap-B-tab-pesalah.png` + `.xml` (ditulis semula
oleh larian hari ini).

### Snippet XML — kawasan sekitar ePBT

```
ViewGroup    klik=false  [105,1212][525,1332]  rid='button-container'
  Button     klik=true   [141,1212][489,1332]  desc='ePBT'  rid='button'
    TextView klik=false  [256,1242][374,1302]  text='ePBT'  rid='button-text'
ViewGroup    klik=true   [555,1212][975,1332]   <-- mySIKAP
  ImageView  klik=false  [585,1230][945,1314]
```

**Pemilik betul.** Dua kawalan, satu baris, ePBT di kiri dan mySIKAP di
kanan. mySIKAP tidak membawa `text`, `content-desc`, mahupun
`resource-id` — ia dirender sebagai logo, jadi tiada locator ikut nama
yang mungkin wujud. Yang boleh ditekan ialah `ViewGroup` induk; anak
`ImageView`-nya `clickable=false`.

Post-check: **bersih, 0 rekod, kaunter siri tidak berubah.**
Corong: 15 tap dinilai, 0 disekat.

### Yang sebenarnya rosak — dan ia bukan apa yang dijangka

Recon 2026-08-12 sudah membetulkan `devtools/peringkat6._cari_mysikap()`.
Ia **tidak** menyentuh objek halaman. Sehingga hari ini
`DaftarKompaunPage` masih membawa:

```python
BUTTON_MYSIKAP_IMAGE = ImageView.instance(0)     # ImageView PERTAMA pada skrin
```

dan `fill_pesalah_tab_trafik()` masih menggunakannya — iaitu laluan
K-001 yang sebenar.

Ia lulus setiap kali kerana borang ini kebetulan mempunyai **tepat satu**
ImageView (disahkan pada empat dump berasingan). Ia tidak menyauh kepada
mySIKAP; ia menyauh kepada nasib susun atur. Kawalan 66px di kirinya
ialah **ePBT**, yang pemilik amarkan MEMADAM data borang.

### Pembetulan

| | |
|---|---|
| Baharu | `pages/daftar_kompaun_page.cari_mysikap_dari_xml()` — fungsi TULEN |
| Sauh | ePBT: baris-y sama (±80px) **dan** tepi kiri pada/selepas tepi kanan ePBT **dan** ViewGroup clickable **dan** mengandungi anak ImageView |
| Tiada sandaran | ePBT tidak dijumpai → `None`. Padanan bukan tepat satu → `None`. Tiada tekaan. |
| Satu implementasi | `peringkat6._cari_mysikap()` kini mendelegasikannya — objek halaman dan devtools tidak boleh menyimpang |
| ePBT | Kekal sebagai locator BERASINGAN (`BUTTON_EPBT`) supaya kod boleh mengelakkannya secara eksplisit. Tidak pernah dipulangkan oleh laluan mySIKAP. |

**28 ujian gerbang** (`tests_offline/test_mysikap_locator.py`) dijalankan
terhadap setiap dump borang Letak Kereta dalam repo.

Satu daripadanya menangkap sesuatu semasa ditulis:
`k001-siasat-02-selepas-kosong.xml` merakam borang selepas satu medan
dikosongkan — **seluruh baris naik 111px**. Locator berasaskan koordinat
tetap akan lulus pada lima dump dan menyesatkan pada yang keenam. Ujian
kini menegaskan HUBUNGAN (di kanan ePBT, sebaris, di luar kotak ePBT),
dengan kotak ePBT dibaca dari dump yang sama.

Satu ujian juga menghalang `ImageView.instance(0)` daripada kembali
secara senyap ke dalam repo — ia locator yang *kelihatan* berfungsi,
jadi ia jenis yang seseorang tampal semula tanpa berfikir.

---

## BAHAGIAN 2 — P-005 / K-005 DITUTUP

Ditanda **PASS-BY-REPRESENTATIVE (rujuk N-005)** dalam
`reports/LAPORAN-49-TC.md`. Ringkasan kategori dikemas kini.

> **Satu perkara dinyatakan terus supaya laporan tidak tersalah baca.**
> Dapatan N-005 yang mewakili ialah **D-04**: build 2.1.21 tiada UI
> untuk MENCIPTA bookmark (popup hanya ✕ / HAPUS / PILIH). Jadi label
> itu bermakna *TC ditutup dan tidak lagi tergantung* — bukan *fungsi
> bookmark berfungsi*. Kedua-duanya direkod.

---

## BAHAGIAN 3 — MOD SEBENAR TERKAWAL

### 3.2 Bendera

`MBPG_MOD_SEBENAR`, lalai `0`. Bendera **INDUK yang berasingan** —
tidak dikira daripada `MBPG_DRY_RUN` / `MBPG_IZIN_SERAH` /
`MBPG_BENARKAN_SERAH`, dan tidak menggantikan mana-mana daripadanya.

Mati (lalai) = corong berkelakuan **identik** seperti sebelum arahan ini
wujud. Cabang mod sebenar tidak pernah dimasuki.

### Bagaimana konteks dikenal pasti — BERSTRUKTUR, bukan global

Mengikut arahan 3.2, ia dibina seperti pengecualian SIMPAN-Tetapan /
bookmark yang sedia ada: **tajuk app-bar** skrin semasa dibaca dari
pokok view, dan hanya skrin dalam senarai yang membenarkan mutasi.

Kenapa app-bar: dialog mutasi (`SIMPAN MAKLUMAT INI ?`, `CETAK ... ?`,
`KEMASKINI DATA`) ialah modal React Native yang dirender **di atas**
skrinnya. Skrin di bawah kekal dalam pokok bersama app-barnya — jadi
menyauh pada app-bar melitupi dialog itu secara automatik, tanpa
membuka apa-apa pada skrin yang tidak dibenarkan.

Jalur app-bar disahkan pada **15 dump device**: tajuk sentiasa berakhir
pada y≤246, elemen bukan-app-bar pertama bermula pada y≥324. Glif ikon
PUA ditapis; `content-desc` diabaikan sepenuhnya kerana ia membawa
`'Notis Amaran, back'` — nama skrin **sebelumnya**, yang menerimanya
bermakna membenarkan mutasi berdasarkan skrin yang sudah ditinggalkan.

**Tingkat kedua, kerana andaian di atas tidak universal.** Bukti
bercanggah dalam repo: `nk-A-skrin-masuk.xml` = 20,838 bait dengan
app-bar; `nk-B-dialog-tarik.xml` = 8,052 bait, **tiada app-bar
langsung** — dialog TARIK NOTIS menggantikan pokok itu sepenuhnya.
Maka dialog yang teksnya sendiri mengenal pastinya dibenarkan, tetapi
**hanya apabila app-bar tidak dapat dibaca**. Kalau app-bar dibaca dan
skrinnya tidak dibenarkan, semakan dialog tidak dijalankan langsung —
jika tidak, satu baris data pada skrin utama yang berbunyi seperti
tajuk dialog akan membuka mutasi di sana.

| Konteks dibenarkan | Sumber bukti |
|---|---|
| `Letak Kereta` (K-001/002/003/004) | dump MBPG — **disahkan** |
| `Pelbagai` (P-001/002/003/004/006) | dump MBPG — **disahkan** |
| `Senarai Kompaun` (SK-001) | dump MBPG — **disahkan** |
| `Notis Kompaun` (TN, NK) | dump MBPG — **disahkan** |
| `TARIK NOTIS TAMAT TEMPOH` | dump MBPG — **disahkan** |
| `Notis Amaran` (N-001/002/004) | `notis_amaran_page.py` (dump MBJB) — **belum disahkan MBPG** |
| `Paparan Notis` | dump MBJB — **belum disahkan MBPG** |
| `Notis To Kompaun` | `notis_kompaun_page.py` — **belum disahkan** |
| `Hantar` (H-001..003) | **belum disahkan** |
| `KEMASKINI DATA` | `kemaskini_page.py` — **belum disahkan** |
| `SIMPAN MAKLUMAT INI ?` | LEDGER, dirakam 3× — **disahkan** |
| `CETAK ... ?` | LEDGER C2-P-001 — **disahkan** |

> **Jurang bukti empat entri terakhir bergerak ke arah SELAMAT.** Kalau
> tajuk sebenar berbeza, konteks memulangkan `None` dan corong
> MENYEKAT. Run berhenti dengan sebab yang menamakan tajuk yang
> benar-benar dibaca, dan senarai dibetulkan daripada bukti itu.
> Ia tidak boleh gagal ke arah "terlebih benarkan".

### Butang yang dibuka — dan yang TIDAK

Dibuka, **bersauh penuh** (`^...$`), dalam konteks sahaja:
`SERAH` · `HANTAR` · `HANTAR SEMULA` · `HANTAR DATA` · `HANTAR GAMBAR` ·
`SAHKAN` · `YA` · `OK` · `KEMASKINI` · `CETAK`

`CETAK` ditambah kerana N/P/K-002 ialah TC cetak dan CETAK menjadi
trip-wire pada 2026-08-12 — tanpanya, tiga daripada 18 TC mustahil.
Tiga varian HANTAR disenaraikan sendiri kerana ketiga-tiganya memadan
trip-wire `HANTAR`.

**Larangan MUTLAK — bendera ini tidak boleh membukanya, dalam konteks
mana pun:** `PADAM` · `HAPUS` · `SELARAS MAKLUMAT PELESEN`.
Diperiksa **sebelum** senarai butang, jadi skrin yang membawa kedua-dua
jenis teks kekal disekat. `SIMPAN` juga tidak disentuh — ia kekal pada
dua pengecualian berstrukturnya sendiri.

### 3.3 Penanda data ujian

`testdata/penanda_ujian.py`.

```
nama_pesalah / nama_penerima  -> UJIAN AUTOMASI E2E <TC-ID> <YYYYMMDD-HHMM>
no_kp_ssm_kereta / no_ic      -> <12 digit berulang, lihat IC_UJIAN>
butiran_kesalahan             -> <nilai oracle> AUTOMASI-CLEANUP-PM
```

Kekal dari oracle: kod kompaun, akta, kesalahan, jalan/taman/poskod/
bandar/negeri, lokasi, tempoh, kadar denda — bukan PII, dan menukarnya
memusnahkan maksud TC.

IC ujian dipilih supaya bentuknya **sah** (010101 = 2001-01-01, kod
tempat 01 = Johor) supaya ia tidak dilenting oleh pengesahan medan dan
membazirkan kitaran, tetapi coraknya berulang supaya tiada pembaca
manusia tersilap anggap ia nombor sebenar.

Yang digantikan: oracle K-001 membawa pasangan nama-dengan-IC dalam
bentuk **warga sebenar** (nama dengan penghubung keturunan + 12 digit
yang menghurai sebagai tarikh lahir sebenar) — tepat apa yang arahan
3.3 larang daripada disimpan. Nilainya tidak disalin ke dalam laporan
ini; ia ada dalam `testdata/oracle_pk.py`.

Runner **BERHENTI** kalau `tandai()` tidak mengubah apa-apa, dan
mencetak setiap medan yang berubah sebelum mengisi borang.

### 3.4 Log rekod

`tools/rekod_log.py` → `reports/REKOD-SEBENAR-DICIPTA-<tarikh>.md`
(+ `reports/REKOD-SEBENAR.jsonl` untuk mesin).

Ditulis **serta-merta**, `flush()` + `fsync()` setiap baris. Sebabnya
sudah berlaku: pada 2026-08-13 satu proses dibunuh had-masa alat
**selepas** siri 005 diperuntukkan, dan nombor itu tiada dalam
mana-mana log — ia hanya ditemui kemudian dengan membaca DB peranti.

Satu kitaran = banyak nombor. `log_rekod()` dipanggil sekali bagi
SETIAP nombor dengan `status` (`baru` / `hasil-kemaskini` /
`hasil-NK-convert`) dan `asal`. Baris lama **tidak** dipadam apabila
rekod digantikan — nombor itu tetap wujud pada production.

Nombor yang gagal ditangkap dilog sebagai **(TIDAK TERTANGKAP)** dengan
sebabnya. Jurang penomboran ialah dapatan (D-07), bukan sesuatu untuk
disenyapkan.

Mukadimah fail memberitahu PM cara mencari: awalan nama, tanda
`AUTOMASI-CLEANUP-PM`, dan bahawa automasi **tidak memadam apa-apa**.

### 3.5 Kitaran

`python tools/run_e2e.py --borang N --mod-sebenar --kitaran penuh`

| Peringkat | Kod | Status page object |
|---|---|---|
| 3.5(1) isi + SERAH + verify | `jalankan_satu` | **disahkan** (3 rekod, 2026-08-13) |
| 3.5(2) CETAK | `cetak_dari_popup` | **disahkan** (cetakan fizikal disahkan pemilik) |
| 3.5(3) KEMASKINI | `peringkat_kemaskini` | port MBJB, **belum dijalankan pada MBPG** |
| 3.5(4) TN / NK | `peringkat_tn_nk` | port MBJB, **belum dijalankan pada MBPG** |
| 3.5(5) Hantar | `peringkat_hantar` | port MBJB, **belum dijalankan pada MBPG** |
| 3.5(6) SK-001 | `peringkat_senarai` | port MBJB, **belum dijalankan pada MBPG** |
| 3.5(7) P-006 | ditanda `PERLU-MATA` | pengesahan fizikal pemilik |

`--kitaran penuh` **menolak** untuk berjalan tanpa `--mod-sebenar`:
peringkat kemaskini/hantar ialah mutasi, dan tanpa bendera itu corong
akan menyekatnya **di tengah kitaran, selepas rekod sebenar sudah
wujud**.

Setiap peringkat merekod hasilnya ke dalam `jejak`, dicetak penuh pada
akhir larian sama ada lulus atau tidak — itu "CATAT urutan sebenar"
yang arahan 3.5 minta.

**P-006 ditanda `PERLU-MATA`, bukan LULUS.** Isu tandatangan hanya
boleh disahkan pada kertas; automasi tidak boleh melihat kertas, dan
mendakwa LULUS di sini akan menjadi hijau palsu.

### 3.6 Tiada gate manual per-langkah

Tiada `TUNGGU:` per-mutasi. Yang kekal: pengesahan `YA` **sekali**
pada permulaan larian (jeda 5s Ctrl-C dengan `--terus`).

Bacaan saya terhadap 3.6, dinyatakan supaya pemilik boleh menolaknya:
arahan menyenaraikan *"elemen tak jumpa selepas retry"* sebagai keadaan
BERHENTI, jadi peringkat yang gagal secara teknikal **menghentikan**
larian — tetapi ia mencatat apa yang berlaku ke dalam `jejak` dan log
rekod **dahulu**. Peringkat yang app tolak secara sah (cth NK pada
notis belum luput) dicatat `TIDAK-DITAWARKAN` dan **bukan** GAGAL.

### 3.7 Ujian gerbang

```
python -m pytest tests_offline -q
762 passed, 0 failed
```

Sebelum kerja ini: 506. Baharu: **256**.

| Fail | Bil | Apa yang dibuktikan |
|---|---|---|
| `test_mod_sebenar.py` | 198 | positif / negatif / regresi |
| `test_mysikap_locator.py` | 28 | locator berasingan dari ePBT |
| `test_penanda_dan_log.py` | 21 | penanda 3.3, log 3.4 |
| `test_run_e2e_mod_sebenar.py` | 9 | pendawaian runner |

**Positif** — bendera hidup + konteks sah → `SERAH` / `HANTAR` /
`KEMASKINI` / semua 10 butang lulus, pada keenam-enam skrin yang
dibenarkan. Sebab keputusan menamakan konteksnya, supaya ledger boleh
diaudit.

**Negatif** — bendera hidup + konteks luar → kesemua 10 butang kekal
disekat pada keempat-empat skrin luar (skrin utama ×2, popup printer,
Menu Selaras).

**Negatif T-008** — skrin Menu Selaras tiada konteks, DAN
`SELARAS MAKLUMAT PELESEN` berada dalam larangan mutlak — disekat
walaupun konteks dipaksa sah.

**Negatif — 11 dump pelanggaran sebenar.** Setiap dump forensik yang
corong pernah tulis semasa MENYEKAT sesuatu (KEMASKINI pada Menu
Selaras, OK pada alert, SELARAS-PELESEN, SIMPAN pada Tetapan/login)
dijalankan semula melalui pengesan konteks. **Tiada satu pun dibuka.**
Ini ujian yang paling dekat dengan soalan sebenar: *adakah ia membuka
apa-apa yang tidak diminta?*

**Regresi** — matriks keputusan penuh (21 teks × 10 skrin) dinilai dua
kali: sekali seperti kod lama memanggilnya, sekali dengan bendera mati
dan konteks dikira. Setiap keputusan **dan** setiap nama peraturan
sepadan. Bendera mati = tiada perubahan.

**Dua syarat bebas** — bendera tanpa konteks tidak membuka apa-apa;
konteks tanpa bendera tidak membuka apa-apa.

---

### Sampingan — gerbang PII pra-commit ditemui ROSAK, dibaiki

`devtools/imbas_pii.py` menyahkod output `git diff` dengan **codepage
sistem** (cp1252) dan bukan UTF-8. Sebaik satu aksara bukan-ASCII masuk
ke dalam baris yang dipentas — sengkang em, anak panah, glif ikon
device, iaitu perkara yang setiap fail dalam repo ini bawa — penyahkodan
meletup dan alat mati dengan `AttributeError: 'NoneType' has no
attribute 'splitlines'`.

Kesannya lebih buruk daripada ranap biasa: **ini gerbang PII
pra-commit.** Alat yang mati pada commit yang mengandungi teks
bukan-ASCII ialah alat yang tidak mengimbas commit itu langsung.

Dibaiki (UTF-8 eksplisit + `errors="replace"` pada kedua-dua panggilan
`subprocess`). Selepas dibaiki, ia **serta-merta menyekat kerja saya
sendiri** — saya telah menyalin nama+IC oracle K-001 ke dalam komen,
ujian, dan laporan ini semasa menerangkan apa yang penanda 3.3 gantikan.
Nilai itu kini diredact di semua tempat; penerangannya kekal.

Ia juga memandu pemilihan `IC_UJIAN`: nilai asal saya berada di LUAR
senarai KECUALI gerbang PII. Menambahnya ke senarai itu bermakna
melonggarkan gerbang supaya pemalar saya muat — arah yang salah. Nilai
ditukar kepada 12 digit berulang, yang gerbang sudah kenali sebagai
penanda ujian sah, dan yang enam digit pertamanya masih menghurai
sebagai tarikh.

```
python devtools/imbas_pii.py
[PII] 2739 baris ditambah diimbas, 0 fail membawa corak PII
[PII] BERSIH.
```

---

## PERKARA YANG PERLU KEPUTUSAN PEMILIK

### (a) K-001 mySIKAP menulis PII warga SEBENAR ke dalam rekod

Ini percanggahan langsung dengan arahan 3.3, dan saya tidak boleh
menyelesaikannya dari sini.

Lookup mySIKAP mengisi Nama Pesalah dan No. K/P daripada pangkalan data
kerajaan. Recon merakamnya: nama penuh 28 aksara + no. KP 12 digit +
alamat penuh, milik pemilik plat SEBENAR. Penanda 3.3 menandakan apa
yang **kita taip**; ia tidak boleh menghalang app daripada menulis
semula medan itu selepas lookup.

Jadi: **kalau mySIKAP dicetuskan sebelum SERAH, rekod production yang
terhasil membawa PII warga sebenar** walaupun setiap nilai yang kita
taip ditanda.

Laluan cipta K sedia ada (`fill_pesalah_tab_letak_kereta`) **tidak**
mencetuskan mySIKAP — ia menaip setiap medan. Jadi keadaan lalai
selamat. Pilihan:

1. **Cipta tanpa mySIKAP** (seperti sekarang), dan lipat mySIKAP
   sebagai ujian baca-sahaja berasingan yang di-back-out — mySIKAP
   sudah TERBUKTI berfungsi (7 medan terisi, 2026-08-12).
2. Cetuskan mySIKAP, kemudian **tulis ganti** Nama + IC dengan penanda
   sebelum SERAH. Bergantung pada medan itu boleh diedit selepas
   lookup — belum diuji.
3. Cetuskan mySIKAP dan terima PII pada rekod ujian.

**Cadangan saya: (1).** Ia memberi liputan TC yang sama tanpa
meletakkan data warga sebenar pada rekod yang PM kemudian perlu
batalkan.

### (b) T-008 — pengiraan "18 daripada 19"

Arahan menyebut *"18 daripada 19 TC kategori SKIP-GUARD (semua KECUALI
T-008)"*. Dalam `testdata/skop.py`, kategori `skip-guard` mengandungi
**tepat 18** TC, dan T-008 berada dalam kategori berasingan
(`skip-arahan-pemilik`). Jadi 18 sasaran = kesemua senarai skip-guard,
dan T-008 kekal di luar sama ada dikira atau tidak. Tiada percanggahan
— dicatat supaya kiraan dalam laporan akhir boleh dipadan semula.

### (c) NK tidak boleh diuji sebelum 2026-08-27

Dialog `TARIK NOTIS TAMAT TEMPOH` menarik notis **luput** sahaja. Notis
yang dicipta hari ini bertempoh 14 hari → layak **2026-08-31**.
Peringkat `tn_nk` akan mencatat `TIDAK-DITAWARKAN` dengan sebab itu.
Notis sedia ada `PGP02N260813006/007` layak **2026-08-27** — masih 10
hari lagi.

NK-001/002 oleh itu **tidak boleh dilitup dalam larian pathfinder ini**.
Itu sekatan app, bukan kekurangan skrip.

---

## APA YANG TIDAK DIBUAT

- **Bendera TIDAK dihidupkan pada device.** 0 rekod dicipta hari ini.
- Sweep 330/284-set — KIV, tidak disentuh.
- T-008 — tidak disentuh, kekal haram tiga lapisan.

---

## LANGKAH SETERUSNYA — MENUNGGU PEMILIK

**TUNGGU:** kelulusan untuk menghidupkan bendera pada device, dan
keputusan pemilik untuk perkara (a) di atas.

Selepas kelulusan:

```
python tools/run_e2e.py --borang N --mod-sebenar --kitaran penuh
```

N-001 SAHAJA sebagai pathfinder, kemudian **BERHENTI** dan lapor penuh
(semua nombor rekod, screenshot, status Hantar) sebelum P-001 dan K-001.

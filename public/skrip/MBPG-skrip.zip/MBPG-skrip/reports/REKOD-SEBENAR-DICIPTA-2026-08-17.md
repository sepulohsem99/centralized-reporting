# REKOD SEBENAR DICIPTA — production MBPG

> Setiap nombor di bawah ialah rekod **HIDUP** pada production MBPG
> (113.211.155.174). Ia dicipta oleh automasi ujian di bawah
> `MBPG_MOD_SEBENAR=1`, atas kelulusan pemilik 2026-08-17.
>
> **Untuk PM:** semua rekod ini data ujian. Nama pesalah bermula dengan
> `UJIAN AUTOMASI E2E`, dan medan catatan membawa `AUTOMASI-CLEANUP-PM`.
> Pembatalan melalui portal ePBT oleh pihak berautoriti — automasi
> TIDAK memadam apa-apa.
>
> Satu kitaran boleh menjana LEBIH DARIPADA SATU nombor (cipta -> NK
> convert -> kemaskini). Baris lama TIDAK dipadam apabila rekod
> digantikan: nombor itu tetap wujud pada production.

| No. rekod | TC | Borang | Masa | Jenis | Status | Asal |
|---|---|---|---|---|---|---|
| `PGP02N260817008` | N-001 | N | 2026-08-17 13:43:10 | Notis | baru | - |

## Pengesahan fizikal

| No. rekod | Cetak | Disahkan oleh | Kaedah |
|---|---|---|---|
| `PGP02N260817008` | **KERTAS KELUAR** | pemilik | pemeriksaan mata, 2026-08-17 |

Printer `SPP-R410_110095` (Bixolon SPP-R410, `74:F0:7D:A9:88:75`).
Satu tekan CETAK, tiada ulangan. Ini menjadikan **N-002 (Cetak Notis
Amaran)** terbukti hujung-ke-hujung pada production buat kali kedua —
yang pertama ialah `PGP02N260813006` pada 2026-08-13.

## Kitaran TIDAK selesai

Kitaran `PGP02N260817008` **berhenti pada peringkat kemaskini**
(3.5(3)) atas positif-palsu corong, bukan atas kelakuan app. Rekod itu
kekal dalam keadaan:

| Peringkat | Status |
|---|---|
| cipta | SELESAI — rekod hidup |
| cetak | SELESAI — kertas disahkan |
| kemaskini | **TIDAK BERLAKU** — run dibatalkan sebelum sebarang pindaan |
| hantar | **TIDAK BERLAKU** |

Maka rekod ini **belum dihantar** dan **belum dikemaskini**. Ia bukan
rekod gantian dan tiada nombor kedua dijana daripadanya.

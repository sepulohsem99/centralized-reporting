#!/usr/bin/env python3
"""
generate_report.py — jana semula reports/mbjb_report.html daripada
keputusan per-TC run pytest terakhir (reports/results.json, ditulis oleh
hook dashboard dalam tests/conftest.py).

Matlamat reka bentuk:
- Idempoten: selamat dijalankan selepas setiap run, DAN selamat
  dijalankan bila results.json langsung tiada. Ia membina semula
  keseluruhan HTML daripada template tetap + jadual metadata statik di
  bawah + results.json (kalau ada), jadi tiada tampalan berkeadaan.
- Berdiri sendiri: tiada import dari suite ujian, tiada pustaka pihak
  ketiga wajib. Cukup `python reports/generate_report.py`.

DE-MBIP — apa yang SENGAJA tiada di sini
-----------------------------------------
Fail ini diport daripada MBIP v3. Perkara berikut dibuang kerana ia milik
MBIP dan bukan MBJB:

  * Jadual 48 TC `MBIP-TC-*`         -> diganti 54 TC `MBPG-TC-*` dari
                                        workbook V2.1.33.
  * Garis dasar 26 PASS/16 FAIL/6 SKIP -> DIBUANG. Itu keputusan satu run
    MBIP production 24 Julai 2026. MBJB belum pernah ada run automation,
    jadi tiada apa untuk dibandingkan. `BASELINE_PROFILE = None`
    mematikan penanda regresi sepenuhnya sehingga seseorang benar-benar
    menetapkan garis dasar MBJB.
  * Nota khusus MBIP ("UI bookmark takde dalam build ini", "server tolak
    resubmission P/K/L", "Kadar Denda Sitaan tak boleh dicapai") -> semua
    itu pemerhatian pada APK MBIP 2.1.17. Bukti MBJB bercanggah dengan
    sekurang-kurangnya tiga daripadanya. Nota di bawah menyebutnya
    sebagai BELUM DISAHKAN, bukan sebagai fakta.
  * Awalan nombor rekod `IPA`         -> `JB015` (profil, bukan kod).
  * `mbip-v3-suite.zip`, `mbip-theme` -> `mbjb-suite.zip`, `mbjb-theme`.

VERSI BUILD — kenapa `{ver}` dan bukan nombor
---------------------------------------------
Mana-mana nota yang menyebut versi app MESTI menulis `{ver}`. Token itu
digantikan dengan versi yang DIKESAN PADA DEVICE untuk run berkenaan.
Nombor yang ditulis terus ke dalam nota ("takde dalam build 2.1.33") akan
terus dipaparkan selepas 2.1.40 dipasang, dan tiada siapa perasan. Ini
kegagalan sebenar yang berlaku dalam laporan MBIP.
"""

import html
import json
import os
import re
import datetime

import guide
import make_zip
import make_excel
from favicon import FAVICON_DATA_URI

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
RESULTS_JSON = os.path.join(HERE, "results.json")
OUT_HTML = os.path.join(HERE, "mbjb_report.html")
HISTORY_DIR = os.path.join(HERE, "history")
PIPELINE_JSON = os.path.join(HERE, "pipeline.json")
PROFILES_DIR = os.path.join(ROOT, "profiles")
PANDUAN_MD = os.path.join(ROOT, "PANDUAN.md")

# Dua salinan dashboard, kandungan sama, satu beza sahaja: laluan ke zip.
#   reports/mbjb_report.html -> untuk dwi-klik di mesin sendiri
#   public/index.html        -> yang hosting hidangkan di URL live
#
# public/ ialah SATU-SATUNYA folder yang terdedah secara awam. Zip di
# dalamnya membawa profiles/ — iaitu lesen peranti dan akaun staging MBJB
# dalam teks biasa. Lihat amaran penuh dalam make_zip.py. Jangan
# tambahkan apa-apa ke public/ tanpa menyemak apa yang ia dedahkan.
PUBLIC_DIR = os.path.join(ROOT, "public")
PUBLIC_HTML = os.path.join(PUBLIC_DIR, "index.html")
ZIP_NAME = "mbjb-suite.zip"
ZIP_HREF_LOCAL = f"../public/{ZIP_NAME}"   # dari dalam reports/
ZIP_HREF_PUBLIC = ZIP_NAME                 # bersebelahan index.html

SUMBER_EXCEL = "IES-MBJB Testing Script V2.1.33 - Production.xlsx"

# ---------------------------------------------------------------------------
# Jadual metadata statik — 54 TC MBJB.
#
# Sumber: docs/IES-MBJB Testing Script V2.1.33 - Production.xlsx
#         (57 sheet, 54 sheet TC). Nama modul diambil dari sel modul
#         setiap sheet; susunan mengikut sheet.
#
# fields: no, tcid, nama, cat, baseline, forced, note
#   baseline: SENTIASA None untuk MBJB — tiada run automation terdahulu.
#             Medan dikekalkan supaya garis dasar boleh dihidupkan kemudian
#             tanpa mengubah struktur.
#   forced:   None, atau ("arahan"|"printer"|"db", nota) => sentiasa SKIPPED.
#             Tiada satu pun TC MBJB dipaksa skip. MBIP memaksa T-008
#             (sync 52,317 rekod Pelesen ≈ 1 jam); bilangan rekod Pelesen
#             MBJB BELUM DISAHKAN, jadi memaksanya di sini bermakna
#             menyalin fakta PBT lain.
#
# "{ver}" dalam mana-mana nota digantikan dengan build yang benar-benar
# dikesan pada device untuk run itu.
# ---------------------------------------------------------------------------

_N_BOOKMARK = (
    "Excel C4 kelima-lima sheet -005 tertulis \"Kompaun Form Notis Amaran > "
    "Bookmark\" (salin-tampal). Nama modul di sini diambil dari kategori TC, "
    "bukan dari C4."
)

# Kelima-lima sheet `-003` bernama "Serah ..." dalam sel modul, TETAPI
# Description dan Test Steps mereka menguji LAMPIRAN GAMBAR, bukan serahan.
# Disahkan pada kelima-lima sheet (recon/excel_tc_inventory.json):
#   desc  = "Verify if that the user can attach picture (lampiran)"
#   steps = "Click on the clip icon for take picture"
# Nama modul dikekalkan sebagaimana dalam oracle — Excel tidak diubah — tetapi
# nota ini WAJIB kekal pada setiap baris `-003`. Tanpanya, pembaca melihat
# "Serah Notis Amaran / PASSED" dan menyimpulkan serahan sudah diuji,
# sedangkan yang diuji hanyalah lampiran gambar. Anomali ini direkod dalam
# recon/PAPAN.md Seksyen 6 (penemuan azharMadi: "-003 ialah LAMPIRAN, bukan
# Serah"). Ini kes yang sama bentuk dengan kesilapan laporan MBIP yang
# mendakwa "cetakan KINI BERJAYA" sedangkan hanya penghantaran yang terbukti.
#
# Ia didaftarkan sebagai SCOPE_CAVEAT (bukan sebagai nota asas) supaya ia
# BERTAHAN walau apa pun status run: nota asas ditulis ganti oleh
# apply_blockers apabila TC hulu gagal, dan caveat skop tidak boleh hilang
# hanya kerana run itu berjalan lain daripada yang dijangka.
_LAMPIRAN_SCOPE = (
    " ⚠️ Nota skop: nama modul dalam Excel menulis \"Serah\", TETAPI apa yang "
    "TC ini benar-benar uji ialah LAMPIRAN GAMBAR — Description = \"Verify if "
    "that the user can attach picture (lampiran)\", Test Steps = \"Click on "
    "the clip icon for take picture\". PASSED di sini bermakna lampiran "
    "diterima; ia TIDAK bermakna serahan/handover diuji. Nama modul "
    "dikekalkan seperti dalam oracle; anomali direkod dalam recon/PAPAN.md "
    "Seksyen 6."
)

META = [
    # ---- T: Tetapan & Selaras (12) ----
    (1,  "MBPG-TC-T-001", "Tetapan Alamat IP", "T", None, None,
     "IP dimasukkan KE DALAM app di sini, bukan tetapan server. Sasaran run "
     "= staging 219.93.38.103:8880. Excel C5 menulis epbt.mbjb.gov.my kerana "
     "run manual Feb 2026 dibuat atas production — jangan ikut C5."),
    (2,  "MBPG-TC-T-002", "Tetapan Pelbagai", "T", None, None,
     "LESEN BUKAN IMEI. lesen_aplikasi ialah token yang didaftarkan di "
     "portal PBT dan disahkan di SERVER; ia tidak dibandingkan dengan IMEI "
     "peranti. Bukti: lesen MBIP 3524…9401 berjaya berpuluh run pada "
     "Ulefone Armor 27 yang IMEI-nya 357616400186856. Profil staging guna "
     "token 8673…5982 (label pejabat m50) — DITERIMA pada device, alert "
     "BEJAYA / \"LESEN SAMA.\" (reports/fasa2-bootstrap.md 2.2-2.3). "
     "m50/m51 ialah label device, BUKAN syarat padanan. Log masuk gagal "
     "bermakna server menolak token itu — minta admin daftarkan, jangan "
     "cari IMEI yang padan."),
    (3,  "MBPG-TC-T-003", "Selaras Pengguna Apps", "T", None, None, ""),
    (4,  "MBPG-TC-T-004", "Selaras Maklumat Alamat", "T", None, None,
     "Selaras ini yang mengisi senarai Nama Jalan untuk typeahead. Kalau ia "
     "gagal, setiap TC Daftar akan gagal pada medan alamat."),
    (5,  "MBPG-TC-T-005", "Selaras Maklumat Kompaun", "T", None, None,
     "Selaras ini yang mengisi dropdown KOD KOMPAUN / AKTA / KESALAHAN. "
     "Pemetaan bersistem merentas 28 nilai tingkat-1 (devtools/peta_kesalahan.py) "
     "mengesahkan DB staging BERISI — cth AKTA JALAN/PARIT/BANGUNAN = 23 nilai "
     "KOD AKTA, KOMPAUN = 6, KOMPAUN MENCEGAH KEKOTORAN = 4. HANYA nilai LALAI "
     "dropdown (AKTA JALAN PARIT & BANGUNAN & AKTA KERAJAAN TEMPATAN) dan sampah "
     "DB (KOD TESTING/KOMAPD) pulang 0. Dakwaan lama \"tingkat 2 KOD AKTA "
     "KOSONG\" (kononnya jurang kategori D menyeluruh, sama seperti MBIP) sudah "
     "DITARIK BALIK — ia berasaskan satu nilai tingkat-1 yang kebetulan nilai "
     "lalai. Dropdown kosong bermakna tingkat-1 yang dipilih tiada AKTA dalam "
     "DB, bukan DB kosong. Masih benar: Kadar Denda tiada julat dalam oracle; "
     "percanggahan ejaan BANGUNAN/BANGUNANS dan KEKOTORANG/KEKOTORAN antara "
     "oracle dan DB; tiada satu pun rekod pernah dicipta setakat ini."),
    (6,  "MBPG-TC-T-006", "Selaras Maklumat Jenis Kenderaan", "T", None, None, ""),
    (7,  "MBPG-TC-T-007", "Selaras Maklumat Warna", "T", None, None, ""),
    (8,  "MBPG-TC-T-008", "Selaras Maklumat Pelesen", "T", None, None,
     "Bilangan rekod Pelesen MBJB BELUM DISAHKAN. Pada PBT lain selaras ini "
     "mengambil ≈1 jam masa device dan sengaja dilangkau. Kalau ia ternyata "
     "sama panjang di sini, tandakan forced-skip dalam META dan catat "
     "sebabnya — jangan biarkan ia membakar satu jam setiap run."),
    (9,  "MBPG-TC-T-009", "Selaras Maklumat Barang Sita", "T", None, None, ""),
    (10, "MBPG-TC-T-010", "Tetapan Skrin Utama", "T", None, None, ""),
    (11, "MBPG-TC-T-011", "Semak Kemaskini", "T", None, None,
     "Membandingkan versi terpasang ({ver}) dengan versi di server. "
     "Keputusan bergantung pada apa yang server staging umumkan pada hari "
     "run — bukan pada kod."),
    (12, "MBPG-TC-T-012", "Remember Me Functions", "T", None, None,
     # Kata laluan DITOPENG: nota ini dirender ke dalam tab Laporan, yang
     # juga menjadi public/index.html — halaman yang dihidangkan awam.
     # Lihat nota penopengan dalam guide.py. Nama akaun dikekalkan kerana
     # ia yang membezakan dua akaun itu; kata laluannya tidak menambah
     # apa-apa makna kepada pembaca laporan.
     "Excel C9 memberi akaun msc; akaun utama profil ialah admin. Kata "
     "laluan kedua-duanya ditopeng di sini — nilai sebenar dalam "
     "profiles/mbpg-staging.json. "
     "Kedua-duanya sah; yang mana diguna dicatat dalam nota run."),

    # ---- N: Notis Amaran (6) ----
    (13, "MBPG-TC-N-001", "Daftar Notis Amaran", "N", None, None,
     "Excel C9 hanya menulis \"Refer to No Notis: JB015N260227001\" — itu "
     "OUTPUT run manual Feb 2026, bukan input. Semua medan borang diisi "
     "penanda; lihat Excel per-run untuk senarai medan."),
    (14, "MBPG-TC-N-002", "Daftar Notis Amaran > Cetak", "N", None, None,
     "Test akan BERHENTI dan tunggu printer dihidupkan (bunyi bel + banner). "
     "SKIPPED hanya kalau tiada siapa hidupkan dalam tempoh menunggu."),
    (15, "MBPG-TC-N-003", "Serah Notis Amaran", "N", None, None,
     "Guna laluan KAMERA, bukan galeri: sel Actual sheet INI merekod "
     "\"System can accepted the attachment but when selecting from gallery, "
     "popup shows 'Galeri Ralat'\". Nota galeri ini sah untuk N-003 SAHAJA — "
     "empat sheet -003 yang lain merekod \"accepted the attachment without "
     "error\"."),
    (16, "MBPG-TC-N-004", "Kemaskini Notis Amaran", "N", None, None,
     "DEV FIXING LIST baris 75 (status NEW): kemaskini notis amaran tidak "
     "berjaya hantar dan data masuk ralat; dilepaskan tanpa fix. Excel "
     "V2.1.33 pula merekod Pass. Bercanggah — status Excel bukan oracle, "
     "biar run yang tentukan."),
    (17, "MBPG-TC-N-005", "Bookmark — Notis Amaran", "N", None, None,
     _N_BOOKMARK + " Excel -005 memberi data bookmark penuh dan langkah "
     "SIMPAN, jadi UI bookmark dijangka WUJUD dalam build {ver} — andaian "
     "MBIP bahawa ia tiada TIDAK dibawa masuk."),
    (18, "MBPG-TC-N-006", "Concat alamat on lokasi kesalahan", "N", None, None,
     ""),

    # ---- P: Kompaun Pelbagai (7) ----
    (19, "MBPG-TC-P-001", "Daftar Kompaun Pelbagai", "P", None, None,
     "Excel C9 = \"Refer to No Kompaun JB015P260227001\" (output run manual). "
     "Tiada nilai medan dibekalkan."),
    (20, "MBPG-TC-P-002", "Daftar Kompaun Pelbagai > Cetak", "P", None, None,
     "Test akan BERHENTI dan tunggu printer dihidupkan (bunyi bel + banner). "
     "SKIPPED hanya kalau tiada siapa hidupkan dalam tempoh menunggu."),
    (21, "MBPG-TC-P-003", "Serah Kompaun Pelbagai", "P", None, None,
     "Expected Result sheet ini secara eksplisit MENUNTUT capaian galeri "
     "(\"accepts the attachment and able to access to galery\") dan sel "
     "Actual merekod \"accepted the attachment without error\" — jadi "
     "larangan galeri N-003 TIDAK terpakai di sini."),
    (22, "MBPG-TC-P-004", "Kemaskini Kompaun Pelbagai", "P", None, None, ""),
    (23, "MBPG-TC-P-005", "Bookmark — Kompaun Pelbagai", "P", None, None,
     _N_BOOKMARK),
    (24, "MBPG-TC-P-006", "Concat alamat on lokasi kesalahan", "P", None, None,
     ""),
    (25, "MBPG-TC-P-007", "Notis peringatan pertama", "P", None, None, ""),

    # ---- K: Kompaun Letak Kereta (7) ----
    (26, "MBPG-TC-K-001", "Daftar Kompaun Letak Kereta", "K", None, None,
     "DEV FIXING LIST baris 73 (DONE): 3 keping gambar WAJIB pada kompaun "
     "letak kereta. Nombor plat kenderaan TIDAK dibekalkan Excel — nilai "
     "terikat persekitaran, mesti datang dari pemilik."),
    (27, "MBPG-TC-K-002", "Daftar Kompaun Letak Kereta > Cetak", "K", None, None,
     "Test akan BERHENTI dan tunggu printer dihidupkan (bunyi bel + banner). "
     "SKIPPED hanya kalau tiada siapa hidupkan dalam tempoh menunggu."),
    (28, "MBPG-TC-K-003", "Serah Kompaun Letak Kereta", "K", None, None,
     ""),
    (29, "MBPG-TC-K-004", "Kemaskini Kompaun Letak Kereta", "K", None, None, ""),
    (30, "MBPG-TC-K-005", "Bookmark — Kompaun Letak Kereta", "K", None, None,
     _N_BOOKMARK),
    (31, "MBPG-TC-K-006", "Concat alamat on lokasi kesalahan", "K", None, None,
     ""),
    (32, "MBPG-TC-K-007", "Notis peringatan pertama", "K", None, None, ""),

    # ---- L: Kompaun Lesen (7) ----
    (33, "MBPG-TC-L-001", "Daftar Kompaun Lesen", "L", None, None,
     "Excel C10 langkah 4 menyebut senarai barang sitaan + muat naik gambar "
     "— teks yang IDENTIK dengan S-001. BELUM DISAHKAN sama ada borang Lesen "
     "MBJB benar-benar ada seksyen barang, atau ini salin-tampal Excel."),
    (34, "MBPG-TC-L-002", "Daftar Kompaun Lesen > Cetak", "L", None, None,
     "Test akan BERHENTI dan tunggu printer dihidupkan (bunyi bel + banner). "
     "SKIPPED hanya kalau tiada siapa hidupkan dalam tempoh menunggu."),
    (35, "MBPG-TC-L-003", "Serah Kompaun Lesen", "L", None, None,
     ""),
    (36, "MBPG-TC-L-004", "Kemaskini Kompaun Lesen", "L", None, None, ""),
    (37, "MBPG-TC-L-005", "Bookmark — Kompaun Lesen", "L", None, None,
     _N_BOOKMARK),
    (38, "MBPG-TC-L-006", "Concat alamat on lokasi kesalahan", "L", None, None,
     ""),
    (39, "MBPG-TC-L-007", "Notis peringatan pertama", "L", None, None, ""),

    # ---- S: Sitaan (6) ----
    (40, "MBPG-TC-S-001", "Daftar Sitaan", "S", None, None,
     "Excel C10 langkah 3 menyebut Kadar Denda (RM) dalam julat sah dan "
     "merekod Pass. Andaian MBIP bahawa Kadar Denda Sitaan tidak boleh "
     "dicapai TIDAK dibawa masuk — tiada isu Kadar Denda dalam DEV FIXING "
     "LIST MBJB."),
    (41, "MBPG-TC-S-002", "Daftar Sitaan > Cetak", "S", None, None,
     "Test akan BERHENTI dan tunggu printer dihidupkan (bunyi bel + banner). "
     "SKIPPED hanya kalau tiada siapa hidupkan dalam tempoh menunggu."),
    (42, "MBPG-TC-S-003", "Serah Sitaan", "S", None, None,
     ""),
    (43, "MBPG-TC-S-004", "Kemaskini Sitaan", "S", None, None, ""),
    (44, "MBPG-TC-S-005", "Bookmark — Sitaan", "S", None, None, _N_BOOKMARK),
    (45, "MBPG-TC-S-006", "Concat alamat on lokasi kesalahan", "S", None, None,
     ""),

    # ---- SK: Senarai (1) ----
    (46, "MBPG-TC-SK-001", "Senarai Kompaun", "SK", None, None,
     "DEV FIXING LIST baris 38 (DONE): Senarai kini default ke tarikh "
     "semasa. Rekod hari ini sepatutnya terpapar tanpa membuka kalendar; "
     "rekod lama TIDAK."),

    # ---- H: Hantar Semula (5) ----
    (47, "MBPG-TC-H-001", "Hantar Semula Data & Gambar Notis Amaran", "H",
     None, None, ""),
    (48, "MBPG-TC-H-002", "Hantar Semula Data & Gambar Kompaun Pelbagai", "H",
     None, None,
     "DEV FIXING LIST baris 66 (WIP, High): kompaun tidak berjaya hantar ke "
     "ePBT. Andaian MBIP \"server tolak resubmission P/K/L\" TIDAK dibawa "
     "masuk — Excel MBJB merekod Pass untuk kesemua H-001..H-005 dengan "
     "nombor rekod P/K/L yang berjaya."),
    (49, "MBPG-TC-H-003", "Hantar Semula Data & Gambar Kompaun Letak Kereta",
     "H", None, None, ""),
    (50, "MBPG-TC-H-004", "Hantar Semula Data & Gambar Kompaun Lesen", "H",
     None, None, ""),
    (51, "MBPG-TC-H-005", "Hantar Semula Data & Gambar Kompaun Sitaan", "H",
     None, None, ""),

    # ---- TN: Tarik Notis (1) ----
    (52, "MBPG-TC-TN-001", "Tarik Notis by Penguatkuasa", "TN", None, None,
     "ID Penguatkuasa: msc (Excel C9). Carian by No Notis ROSAK pada build "
     "yang diuji Excel (C14 Remarks) — tiada TC MBJB untuknya, dan TC MBIP "
     "TN-002/TN-003 sengaja tidak diport."),

    # ---- NK: Notis ke Kompaun (2) ----
    (53, "MBPG-TC-NK-001", "Notis ke Kompaun > Kompaun", "NK", None, None,
     "Excel V2.1.33 merekod FAIL: ralat berkaitan props bila butang Kompaun "
     "ditekan. V2.1.34 merekod Pass, dan DEV FIXING LIST baris 72 (Props "
     "Error, DONE) menyokong ia dibaiki. Jangan tandakan skip mutlak — biar "
     "build {ver} yang menjawab."),
    (54, "MBPG-TC-NK-002", "Notis ke Kompaun > Patuh", "NK", None, None,
     "DEV FIXING LIST (Training Feedback): penguatkuasa perlu AMBIL GAMBAR "
     "dahulu sebelum tekan Patuh. Langkah kamera tambahan berbanding PBT "
     "lain."),
]

# ---------------------------------------------------------------------------
# Caveat skop — ditambah pada nota baris SENTIASA, walaupun bila mesej
# perubahan status menggantikan selebihnya. Ia menerangkan apa yang test
# itu SEBENARNYA liputi, iaitu sifat kekal test itu, bukan sifat sesuatu
# run: kehilangan caveat pada saat status berubah adalah tepat masa ia
# paling mungkin disalah baca.
# ---------------------------------------------------------------------------

# Lima TC "Concat alamat" + tiga "Notis peringatan pertama" ialah SATU-
# SATUNYA TC MBJB yang langkahnya bukan langkah aplikasi. Excel menyuruh
# "retrieve kompaun from database and verify..." — automation Appium pada
# handheld tidak boleh membaca pangkalan data ePBT.
_DB_SCOPE = (
    " ⚠️ Nota skop: langkah Excel TC ini ialah verifikasi PANGKALAN DATA "
    "(\"retrieve from database and verify\"), bukan langkah aplikasi. "
    "Automation pada handheld tidak boleh membaca DB ePBT. Yang boleh "
    "disahkan hanyalah proksi UI — apa yang app sendiri paparkan. SKIP di "
    "sini bermakna liputan sebenar TC ini masih bergantung pada semakan DB "
    "oleh manusia."
)

DB_VERIFY_TCS = {
    "MBPG-TC-N-006", "MBPG-TC-P-006", "MBPG-TC-K-006",
    "MBPG-TC-L-006", "MBPG-TC-S-006",
    "MBPG-TC-P-007", "MBPG-TC-K-007", "MBPG-TC-L-007",
}

# Excel MBJB tidak membekalkan SATU pun nilai medan untuk lima TC Daftar.
# Sesiapa yang membaca "PASSED" pada baris itu perlu tahu bahawa rekod
# yang tercipta hampir keseluruhannya bertanda penanda.
_PENANDA_SCOPE = (
    " ⚠️ Nota skop: sebahagian medan TC ini diisi penanda "
    "\"blank dari test script\" kerana oracle masih senyap tentangnya "
    "(Peraturan #5). Sejak oracle dibetulkan 2026-08-04, kebanyakan medan "
    "kini membawa data ujian SEBENAR dari sel Test Data — penanda "
    "tinggal pada medan auto-isi (Taman/Bandar/Negeri) dan Keterangan "
    "Kemaskini. Penanda yang tinggal itu tetap keluar pada kertas cetak."
)

CREATE_TCS = {"MBPG-TC-N-001", "MBPG-TC-P-001", "MBPG-TC-K-001",
              "MBPG-TC-L-001", "MBPG-TC-S-001"}

# Lima sheet `-003`: modul kata "Serah", langkah kata lampiran gambar.
LAMPIRAN_TCS = {"MBPG-TC-N-003", "MBPG-TC-P-003", "MBPG-TC-K-003",
                "MBPG-TC-L-003", "MBPG-TC-S-003"}

SCOPE_CAVEAT = {}
for _tc in DB_VERIFY_TCS:
    SCOPE_CAVEAT[_tc] = _DB_SCOPE
for _tc in CREATE_TCS:
    SCOPE_CAVEAT[_tc] = _PENANDA_SCOPE
for _tc in LAMPIRAN_TCS:
    SCOPE_CAVEAT[_tc] = _LAMPIRAN_SCOPE

# ---------------------------------------------------------------------------
# Status tester manual dari workbook V2.1.33.
#
# INI BUKAN ORACLE (Peraturan Keras #4). Ia rekod run MANUAL Februari 2026
# atas server PRODUCTION, pada build yang sudah lama berlalu. Ia disimpan
# di sini untuk SATU tujuan sahaja: mencari di mana automation dan tester
# manual TIDAK sependapat. Persetujuan tidak memberitahu apa-apa yang
# baharu; percanggahan sentiasa bermakna salah satu daripada dua perkara
# yang kedua-duanya penting — sama ada bug sudah dibaiki sejak ujian
# manual, atau automation tersilap.
#
# Kalau tools/extract_pipeline.py dijalankan dan menghasilkan pipeline.json,
# nilai di sana MENGATASI jadual ini (ia dibaca terus dari workbook).
# ---------------------------------------------------------------------------
MANUAL_EXCEL = {tcid: {"status": "Pass"} for (_n, tcid, *_r) in META}
MANUAL_EXCEL["MBPG-TC-NK-001"] = {"status": "Fail"}

ACTION_TEXT = {
    "ok": "Tiada — OK",
    "printer": "Manual: perlu printer",
    "dev": "Refer dev team",
    "rerun": "Rerun untuk confirm",
    "arahan": "Skip atas arahan",
    "db": "Perlu semakan DB (manusia)",
    "blocked": "Show stopper — tersekat",
}
RECHECK_ACTIONS = {"printer", "rerun", "db"}

# MBJB TIADA garis dasar automation. Menetapkannya kepada nama profil
# akan menyalakan penanda "regresi" pada run PERTAMA, membandingkan
# terhadap sesuatu yang tidak pernah wujud. Biarkan None sehingga satu run
# MBJB yang bersih benar-benar dipilih sebagai garis dasar — kemudian
# isikan nama profil itu dan isi medan `baseline` dalam META.
BASELINE_PROFILE = None

# TC Cetak. Printer Bluetooth mati sendiri (had dialog auto-off = 90
# minit), dan 5 TC ini bertaburan merentasi run 2-3 jam. Penyelesaiannya
# BUKAN menerima skip: test berhenti, membunyikan bel terminal, dan
# menunggu printer dihidupkan semula. SKIPPED di sini bermakna tiada siapa
# sempat menghidupkannya dalam tempoh menunggu -- keadaan persekitaran,
# bukan kecacatan aplikasi, jadi ia tetap tidak dilaporkan sebagai FAILED.
PRINTER_TCS = {"MBPG-TC-N-002", "MBPG-TC-P-002", "MBPG-TC-K-002",
               "MBPG-TC-L-002", "MBPG-TC-S-002"}

# Kegagalan yang sudah ada tiket dev berdokumen. Kegagalan di sini dirujuk
# terus kepada dev team dan bukan "rerun untuk confirm" — rerun tidak akan
# mengubah apa-apa. Rujukan diberi dalam nota META supaya sesiapa boleh
# menyemak sendiri.
KNOWN_DEV_ISSUE = {
    "MBPG-TC-N-004",     # DEV FIXING LIST baris 75, status NEW
    "MBPG-TC-NK-001",    # Excel V2.1.33 C12/C13 = props error, Status Fail
}

# TC yang tidak boleh berjalan langsung selagi TC lain gagal, kerana ia
# memerlukan rekod yang dicipta oleh TC itu. Melaporkannya sebagai
# kegagalan tersendiri memberi gambaran salah: ia tidak pernah diuji.
#
# Kontrak by-number (Peraturan Keras #7): -002 Cetak, -003 Serah dan -004
# Kemaskini membuka rekod IKUT NOMBOR yang dikembalikan oleh -001. Tiada
# fallback ke "baris pertama" — kalau -001 gagal, tiada nombor, dan ketiga
# -tiga itu pytest.skip. Itu laporan yang BETUL.
BLOCKED_BY = {}
for _mod in ("N", "P", "K", "L", "S"):
    for _suf in ("002", "003", "004"):
        BLOCKED_BY[f"MBPG-TC-{_mod}-{_suf}"] = f"MBPG-TC-{_mod}-001"


def apply_blockers(models):
    """Tandakan TC yang tersekat oleh TC lain dalam run yang SAMA.

    Label hanya dikenakan apabila penyekat itu benar-benar gagal dalam run
    ini. Kalau penyekat lulus tetapi TC ini tetap gagal, itu kegagalan
    tersendiri dan mesti kekal kelihatan -- kalau tidak, bug sebenar akan
    tersembunyi di sebalik label 'tersekat'.
    """
    by_id = {m["tcid"]: m for m in models}
    for m in models:
        blocker = BLOCKED_BY.get(m["tcid"])
        if not blocker or m["status"] == "PASSED":
            continue
        b = by_id.get(blocker)
        if not b or b["status"] == "PASSED":
            continue
        short = blocker.replace("MBPG-TC-", "")
        m["action"] = "blocked"
        # Disimpan berasingan supaya baris boleh MENUNJUKKAN TC hulu itu
        # sebagai butiran tersendiri, bukan hanya menyebutnya di dalam
        # perenggan nota yang mudah dilangkau mata.
        m["blocker"] = blocker
        m["blocker_status"] = b["status"]
        m["note"] = (f"Show stopper: {short} {b['status']}, jadi tiada nombor "
                     f"rekod untuk TC ini dibuka. Tidak pernah benar-benar "
                     f"diuji — akan berjalan sendiri bila {short} pulih.")
        caveat = SCOPE_CAVEAT.get(m["tcid"])
        if caveat:
            m["note"] += caveat
    return models


# "NOT RUN" WAJIB ada di sini. Tanpanya ia jatuh ke lalai "b-fail" dan
# setiap TC yang tidak pernah dijalankan dipaparkan sebagai lencana MERAH
# — pembaca membaca 34 kegagalan yang tidak pernah berlaku.
BADGE_CLASS = {"PASSED": "b-pass", "FAILED": "b-fail", "SKIPPED": "b-skip",
               "ERROR": "b-fail", "NOT RUN": "b-notrun"}

# Dijalankan dalam <head>, SEBELUM apa-apa dilukis. Kalau tema
# ditetapkan oleh skrip di hujung <body>, pengguna tema cerah akan nampak
# kilatan hitam setiap kali halaman dimuat.
HEAD_SCRIPT = """<script>
(function(){
  var t;
  try { t = localStorage.getItem('mbjb-theme'); } catch(e) {}
  if (!t) t = window.matchMedia('(prefers-color-scheme: light)').matches
              ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', t);
})();
</script>"""

# Latar bintang beranimasi.
#
# Komponen <Galaxy> asal ialah React + WebGL (ReactBits). Dashboard ini
# satu fail HTML statik tanpa React, bundler, atau capaian npm, jadi
# kesan yang sama dilaksanakan semula dengan canvas 2D biasa memakai
# parameter yang diberi:
#     starSpeed .5   density 1      rotationSpeed .1
#     glowIntensity .3   twinkleIntensity .3
#     saturation 0   -> bintang kelabu/putih, jadi hueShift tiada kesan
#     mouseRepulsion, repulsionStrength 2
#
# Config yang diberi untuk kedua-dua tema adalah sama. Tetapi bintang
# putih di atas latar putih tidak kelihatan langsung, jadi warna zarah
# dibalikkan untuk tema cerah — parameter gerakan kekal serupa.
BACKGROUND_SCRIPT = """<script>
(function(){
  var cv = document.getElementById('bg-galaxy');
  if (!cv) return;
  var ctx = cv.getContext('2d');
  var W = 0, H = 0, DPR = 1, stars = [], raf = null, angle = 0, last = 0;
  var mx = -9999, my = -9999;

  var P = { starSpeed:0.5, density:1, glow:0.3, twinkle:0.3,
            rotation:0.1, repulsion:2 };

  function resize(){
    DPR = Math.min(window.devicePixelRatio || 1, 2);   /* had DPR: skrin 4K */
    W = cv.clientWidth; H = cv.clientHeight;
    cv.width = W * DPR; cv.height = H * DPR;
    ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
    seed();
  }

  function seed(){
    /* Bilangan bintang ikut luas skrin, berpagar supaya skrin besar
       tidak menjadikan halaman berat. */
    var n = Math.min(260, Math.round(W * H / 9000 * P.density));
    stars = [];
    for (var i = 0; i < n; i++){
      var a = Math.random() * Math.PI * 2;
      var r = Math.pow(Math.random(), 0.6) * Math.max(W, H) * 0.62;
      stars.push({ a:a, r:r, sz:Math.random()*1.5+0.35,
                   al:Math.random()*0.5+0.25,
                   tw:Math.random()*Math.PI*2,
                   sp:Math.random()*0.5+0.5, ox:0, oy:0 });
    }
  }

  function colour(){
    return document.documentElement.getAttribute('data-theme') === 'light'
      ? '20,32,56' : '255,255,255';
  }

  function frame(ts){
    var dt = Math.min((ts - last) / 1000 || 0, 0.05); last = ts;
    angle += P.rotation * dt * 0.35;
    ctx.clearRect(0, 0, W, H);

    var cx = W / 2, cy = H / 2, rgb = colour();
    ctx.shadowBlur = 6 * P.glow * 4;
    ctx.shadowColor = 'rgba(' + rgb + ',0.5)';

    for (var i = 0; i < stars.length; i++){
      var s = stars[i];
      s.r += P.starSpeed * s.sp * dt * 7;
      if (s.r > Math.max(W, H) * 0.72){ s.r = 0; s.a = Math.random()*Math.PI*2; }
      s.tw += dt * 2.2 * s.sp;

      var x = cx + Math.cos(s.a + angle) * s.r;
      var y = cy + Math.sin(s.a + angle) * s.r * 0.62;

      /* Tolakan tetikus: zarah menjauh dari kursor, kemudian pulih. */
      var dx = x - mx, dy = y - my, d2 = dx*dx + dy*dy;
      if (d2 < 19000){
        var d = Math.sqrt(d2) || 1, f = (1 - d/138) * P.repulsion * 22;
        s.ox += (dx/d) * f * dt * 6; s.oy += (dy/d) * f * dt * 6;
      }
      s.ox *= 0.92; s.oy *= 0.92;

      var al = s.al * (1 - P.twinkle + P.twinkle * (0.5 + 0.5*Math.sin(s.tw)));
      ctx.fillStyle = 'rgba(' + rgb + ',' + al.toFixed(3) + ')';
      ctx.beginPath();
      ctx.arc(x + s.ox, y + s.oy, s.sz, 0, Math.PI*2);
      ctx.fill();
    }
    raf = requestAnimationFrame(frame);
  }

  function start(){ if (!raf){ last = performance.now();
                              raf = requestAnimationFrame(frame); } }
  function stop(){ if (raf){ cancelAnimationFrame(raf); raf = null; }
                   ctx.clearRect(0, 0, W, H); }

  window.addEventListener('resize', resize);
  window.addEventListener('mousemove', function(e){ mx = e.clientX; my = e.clientY; });
  window.addEventListener('mouseout', function(){ mx = my = -9999; });
  /* Jangan bakar CPU bila tab tidak dilihat. */
  document.addEventListener('visibilitychange', function(){
    if (document.hidden) stop(); else if (window.__bgOn) start();
  });

  window.__bgResize = resize;
  window.__bgStart = start;
  window.__bgStop = stop;
  resize();
})();
</script>"""

STYLE = """<style>
  /* Dua tema. Semua warna melalui pembolehubah -- tiada warna keras
     dalam peraturan di bawah, supaya menukar tema tidak boleh
     meninggalkan satu elemen tersasar dengan warna gelap atas latar
     cerah (atau sebaliknya). */
  :root{
    --bg:#0f1115; --card:#181b22; --line:#2a2f3a; --text:#e8eaf0; --muted:#9aa3b2;
    --pass:#22c55e; --fail:#ef4444; --skip:#eab308; --accent:#3b82f6;
    --warn:#f97316; --beza:#a855f7;
    /* NOT RUN = kelabu, sengaja TANPA warna isyarat. Ia bukan lulus,
       bukan gagal, dan bukan skip berdokumen -- ia bermakna TC itu
       tidak diuji. Memberinya merah menjadikan run yang terhenti
       kelihatan seperti aplikasi yang rosak. */
    --notrun:#94a3b8;
    --th-bg:#1f232c; --row-hover:#1d212a;
    --code-bg:#0b0d12; --code-text:#a5d6ff;
    /* Latar lencana disimpan sebagai pembolehubah penuh (bukan alpha
       atas warna teks) supaya setiap tema boleh melaraskan kelegapannya
       sendiri -- tint yang sesuai atas hitam terlalu pudar atas putih. */
    --pass-bg:rgba(34,197,94,.15);
    --fail-bg:rgba(239,68,68,.15);
    --skip-bg:rgba(234,179,8,.15);
    --notrun-bg:rgba(148,163,184,.15);
    --accent-bg:rgba(59,130,246,.12);
    --accent-bg-soft:rgba(59,130,246,.07);
    --warn-bg:rgba(249,115,22,.08);
  }
  html[data-theme="light"]{
    --bg:#f5f6f8; --card:#ffffff; --line:#dfe3e9; --text:#16191f; --muted:#5c6572;
    /* Nada lebih gelap daripada versi tema gelap: warna terang yang sama
       tidak cukup kontras atas latar putih. */
    --pass:#15803d; --fail:#dc2626; --skip:#a16207; --accent:#2563eb;
    --warn:#c2410c; --beza:#7e22ce; --notrun:#475569;
    --th-bg:#eef1f5; --row-hover:#f2f5f9;
    --code-bg:#1e2430; --code-text:#bfe0ff;
    --pass-bg:rgba(21,128,61,.11);
    --fail-bg:rgba(220,38,38,.10);
    --skip-bg:rgba(161,98,7,.12);
    --notrun-bg:rgba(71,85,105,.11);
    --accent-bg:rgba(37,99,235,.10);
    --accent-bg-soft:rgba(37,99,235,.06);
    --warn-bg:rgba(194,65,12,.08);
  }
  *{box-sizing:border-box; margin:0; padding:0;}
  /* Warna latar dipindah ke <html> supaya canvas boleh duduk di antara
     latar dan kandungan (body kekal lutsinar). */
  html{background:var(--bg);}
  body{background:transparent; color:var(--text); font-family:"Segoe UI",system-ui,sans-serif; padding:24px;
       transition:color .15s;}
  #bg-galaxy{position:fixed; inset:0; width:100%; height:100%;
             z-index:-1; pointer-events:none; display:block;}
  body.no-anim #bg-galaxy{display:none;}
  /* Kad dan jadual jadi separa lutsinar supaya bintang menembus sedikit
     tanpa menjejaskan kebolehbacaan teks. */
  .card,table{backdrop-filter:blur(2px);}
  .head{display:flex; justify-content:space-between; align-items:flex-start; gap:16px; flex-wrap:wrap;}
  .head-actions{display:flex; gap:8px; flex-wrap:wrap;}
  h1{font-size:20px; margin-bottom:4px;}
  .sub{color:var(--muted); font-size:13px; margin-bottom:16px; line-height:1.7;}
  .cards{display:flex; gap:12px; flex-wrap:wrap; margin-bottom:20px;}
  .card{background:var(--card); border:1px solid var(--line); border-radius:10px; padding:14px 20px; min-width:120px; cursor:pointer; transition:.15s;}
  .card:hover{border-color:var(--accent);}
  .card.active{border-color:var(--accent); box-shadow:0 0 0 1px var(--accent);}
  .card .num{font-size:26px; font-weight:700;}
  .card .lbl{font-size:12px; color:var(--muted); text-transform:uppercase; letter-spacing:.5px;}
  .num.pass{color:var(--pass);} .num.fail{color:var(--fail);} .num.skip{color:var(--skip);} .num.all{color:var(--accent);} .num.recheck{color:var(--warn);}
  .num.notrun{color:var(--notrun);}
  .num.beza{color:var(--beza);}
  .beza-mark{color:var(--beza); font-weight:700; margin-left:6px; cursor:help;}
  tr[data-beza="1"] td:first-child{box-shadow:inset 3px 0 0 var(--beza);}
  .controls{display:flex; gap:10px; flex-wrap:wrap; margin-bottom:14px; align-items:center;}
  select,input[type=text]{background:var(--card); color:var(--text); border:1px solid var(--line); border-radius:8px; padding:8px 12px; font-size:14px;}
  input[type=text]{flex:1; min-width:220px;}
  table{width:100%; border-collapse:collapse; background:var(--card); border-radius:10px; overflow:hidden;}
  th,td{padding:10px 12px; text-align:left; font-size:13.5px; border-bottom:1px solid var(--line); vertical-align:top;}
  th{background:var(--th-bg); color:var(--muted); font-size:12px; text-transform:uppercase; letter-spacing:.5px; position:sticky; top:0;}
  tr:hover td{background:var(--row-hover);}
  .badge{display:inline-block; padding:3px 10px; border-radius:20px; font-size:12px; font-weight:600;}
  .b-pass{background:var(--pass-bg); color:var(--pass);}
  .b-fail{background:var(--fail-bg); color:var(--fail);}
  .b-skip{background:var(--skip-bg); color:var(--skip);}
  .b-notrun{background:var(--notrun-bg); color:var(--notrun);}
  .act{font-size:12.5px; color:var(--muted);}
  .act.hot{color:var(--warn); font-weight:600;}
  /* Ralat sebenar run terkini -- dibezakan daripada nota konteks supaya
     jelas mana fakta run ini dan mana latar belakang yang ditulis tangan. */
  .realerr{margin-top:7px; padding:6px 9px; border-left:2px solid var(--fail);
           background:var(--fail-bg); border-radius:0 6px 6px 0;
           font-family:Consolas,monospace; font-size:11.5px;
           color:var(--text); word-break:break-word;}
  /* Sebab SKIP / NOT RUN. Kuning, bukan merah: skip bukan kegagalan, dan
     mewarnakannya merah akan menyebabkan pembaca melaporkannya sebagai
     bug. Tetapi ia MESTI kelihatan -- kotak nota yang kosong pada baris
     SKIPPED ialah kecacatan laporan MBIP yang paling kerap disalah baca. */
  .skipwhy{margin-top:7px; padding:6px 9px; border-left:2px solid var(--skip);
           background:var(--skip-bg); border-radius:0 6px 6px 0;
           font-size:12px; line-height:1.65; color:var(--text);}
  .skipwhy code{font-family:Consolas,monospace;}
  /* Rujukan TC hulu: biru, dan di ATAS sebab, kerana soalan pertama
     pembaca pada baris tersekat ialah "tersekat oleh apa". */
  .blockref{margin-top:7px; padding:6px 9px; border-left:2px solid var(--accent);
            background:var(--accent-bg); border-radius:0 6px 6px 0;
            font-size:12px; line-height:1.65; color:var(--text);}
  .artf-row{margin-top:7px; display:flex; gap:6px; flex-wrap:wrap;}
  .artf{font-family:Consolas,monospace; font-size:11.5px; padding:2px 8px;
        border-radius:20px; background:var(--accent-bg); color:var(--accent);}
  .tcid{font-family:Consolas,monospace; font-size:12.5px; color:var(--accent); white-space:nowrap;}
  .hidden{display:none;}
  .count-line{color:var(--muted); font-size:13px; margin:10px 2px;}
  .empty{border:1px dashed var(--line); border-radius:10px; padding:26px;
         text-align:center; color:var(--muted); font-size:13.5px;
         line-height:1.8; background:var(--card);}

  /* ---- susun atur: sidebar + kandungan ---- */
  .layout{display:flex; gap:22px; align-items:flex-start;}
  .sidebar{position:sticky; top:24px; width:212px; flex:0 0 212px;
           background:var(--card); border:1px solid var(--line);
           border-radius:12px; padding:14px 12px; backdrop-filter:blur(2px);}
  .brand{font-size:12px; letter-spacing:.6px; text-transform:uppercase;
         color:var(--muted); padding:2px 10px 10px;}
  /* min-width:0 wajib -- tanpanya jadual lebar akan menolak sidebar
     keluar daripada susun atur flex. */
  .content{flex:1; min-width:0;}
  .nav{display:block; width:100%; text-align:left; background:none;
       border:none; color:var(--muted); font:inherit; font-size:14px;
       padding:10px 12px; border-radius:8px; cursor:pointer;
       transition:.15s; margin-bottom:2px;}
  .nav:hover{background:var(--row-hover); color:var(--text);}
  .nav.active{background:var(--accent-bg); color:var(--accent); font-weight:600;}
  .nav .n-sub{display:block; font-size:11.5px; font-weight:400;
              color:var(--muted); margin-top:2px;}
  .tabpane{display:none;}
  .tabpane.active{display:block;}
  /* Jadual sejarah ada 10 lajur -- benarkan skrol mendatar dalam ruang
     yang lebih sempit selepas sidebar mengambil tempat. */
  .tbl-wrap{overflow-x:auto;}

  @media (max-width:900px){
    .layout{flex-direction:column;}
    .sidebar{position:static; width:100%; flex:none;
             display:flex; gap:6px; padding:8px;}
    .brand{display:none;}
    .nav{flex:1; text-align:center; margin-bottom:0;}
    .nav .n-sub{display:none;}
  }

  /* ---- toolbar / buttons ---- */
  .toolbar{display:flex; gap:10px; flex-wrap:wrap; margin-bottom:16px;}
  .btn{background:var(--card); color:var(--text); border:1px solid var(--line); border-radius:8px;
       padding:9px 16px; font:inherit; font-size:13.5px; cursor:pointer; transition:.15s;
       text-decoration:none; display:inline-block;}
  .btn:hover{border-color:var(--accent); color:var(--accent);}
  .btn.primary{border-color:var(--accent); color:var(--accent);}
  .btn.primary:hover{background:var(--accent-bg);}

  /* ---- panduan ---- */
  .g-h{font-size:16px; margin:38px 0 16px; color:var(--accent);
       padding-top:22px; border-top:1px solid var(--line);}
  .g-h:first-child{margin-top:0; padding-top:0; border-top:none;}
  .g-p{font-size:14px; line-height:1.8; margin-bottom:16px;}
  .g-list{margin:0 0 20px 22px; font-size:14px; line-height:1.9;}
  .g-list li{margin-bottom:4px;}
  /* ---- panduan: lajur dipusatkan ---- */
  #tab-panduan{max-width:940px; margin:0 auto;}

  /* ---- panduan: diagram alur (SVG) ---- */
  /* viewBox mengendalikan penskalaan; had lebar menghalangnya membesar
     sampai teks nampak terlalu gemuk pada monitor lebar. */
  .flow-svg{width:100%; height:auto; display:block; margin:0 0 26px;}

  /* ---- panduan: tetingkap terminal ---- */
  .term{border:1px solid var(--line); border-radius:10px; overflow:hidden;
        margin:0 0 20px; background:var(--code-bg);}
  .t-bar{display:flex; align-items:center; gap:7px; padding:8px 12px;
         background:var(--th-bg); border-bottom:1px solid var(--line);}
  .t-dot{width:10px; height:10px; border-radius:50%; display:inline-block; flex:0 0 auto;}
  .d1{background:#ff5f56;} .d2{background:#ffbd2e;} .d3{background:#27c93f;}
  .t-name{flex:1; font-size:12px; color:var(--muted); margin-left:6px;
          font-family:Consolas,monospace;}
  .t-body{padding:15px 16px; font-family:Consolas,monospace; font-size:13px;
          color:var(--code-text); line-height:2.0;}
  .t-line{white-space:pre-wrap; word-break:break-word;}
  /* Prompt hanya untuk arahan. Blok kandungan fail (.is-file) tiada
     prompt -- meletakkan "&gt;" di hadapan setiap baris JSON akan
     menjadikannya kelihatan seperti sesuatu yang patut ditaip. */
  .term:not(.is-file) .t-line::before{content:"> "; color:var(--muted);}

  /* ---- panduan: tangkap skrin ---- */
  .shot{margin:0 0 22px;}
  .shot img{width:100%; height:auto; display:block; border-radius:10px;
            border:1px solid var(--line);}
  .shot figcaption{font-size:12px; color:var(--muted); margin-top:7px;
                   text-align:center;}

  /* ---- panduan: output yang dijangka ---- */
  .t-live{font-size:10.5px; font-weight:700; letter-spacing:.5px;
          text-transform:uppercase; color:var(--pass);
          background:var(--pass-bg); padding:2px 8px; border-radius:20px;}
  .o-line{white-space:pre-wrap; word-break:break-word; color:var(--muted);}
  .o-tag{color:var(--code-text);}
  .o-prompt{color:var(--pass); font-weight:600;}
  /* Kursor berkelip: tunjukkan bahawa proses masih berjalan dan memang
     tidak kembali ke prompt -- itu yang paling kerap disangka tergantung. */
  .o-caret{color:var(--pass); animation:blink 1.1s step-end infinite;}
  @keyframes blink{50%{opacity:0;}}
  body.no-anim .o-caret{animation:none;}

  /* ---- panduan: ikon ---- */
  .ic{width:22px; height:22px; flex:0 0 auto;}
  .ic.sm{width:15px; height:15px; vertical-align:-2px;}

  /* ---- panduan: kad berikon ---- */
  .gcards{display:grid; grid-template-columns:repeat(auto-fit,minmax(215px,1fr));
          gap:14px; margin:0 0 22px;}
  .gcard{background:var(--card); border:1px solid var(--line);
         border-radius:10px; padding:18px 18px 19px;}
  .gcard .ic{color:var(--accent); margin-bottom:12px;}
  .gc-t{font-size:13.5px; font-weight:600; margin-bottom:6px;}
  .gc-d{font-size:12.5px; color:var(--muted); line-height:1.75;}

  /* ---- panduan: legend status ---- */
  .legend{display:grid; grid-template-columns:auto auto 1fr; gap:14px 14px;
          align-items:center; margin:0 0 22px;}
  /* display:contents -- tanpanya .lg-row menjadi SATU item grid dan
     ketiga-tiga span di dalamnya keluar daripada susunan lajur. */
  .lg-row{display:contents;}
  .lg-ic{display:flex;} .lg-t{font-size:12.5px; font-weight:700;}
  .lg-d{font-size:13px; color:var(--muted);}
  .pass{color:var(--pass);} .fail{color:var(--fail);}
  .skip{color:var(--skip);} .warn{color:var(--warn);}

  /* ---- panduan: jadual dua lajur ---- */
  .pairs{display:grid; grid-template-columns:minmax(120px,auto) 1fr;
         gap:14px 22px; margin:0 0 22px; font-size:13.5px;
         line-height:1.7;}
  .pr-k{color:var(--text); font-weight:600;}
  .pr-v{color:var(--muted);}
  @media (max-width:620px){ .pairs{grid-template-columns:1fr; gap:2px 0;}
                            .pr-v{margin-bottom:8px;} }

  .g-copy{background:var(--card); color:var(--muted); border:1px solid var(--line); border-radius:6px;
          padding:4px 12px; font:inherit; font-size:12px; cursor:pointer; white-space:nowrap;}
  .g-copy:hover{border-color:var(--accent); color:var(--accent);}
  .g-note{border-left:3px solid var(--accent); background:var(--accent-bg-soft); padding:13px 16px;
          margin:0 0 20px; font-size:13.5px; line-height:1.75;}
  .g-warn{border-left:3px solid var(--warn); background:var(--warn-bg); padding:13px 16px;
          margin:0 0 20px; font-size:13.5px; line-height:1.75;}

  /* ---- sejarah / pipeline ---- */
  .hist-note{color:var(--muted); font-size:13px; margin-bottom:14px; line-height:1.7;}
  .muted-cell{color:var(--muted); font-size:12.5px; font-style:italic;}
  .pill{display:inline-block; padding:2px 9px; border-radius:20px;
        font-size:11.5px; font-weight:600;}
  .pill-ok{background:var(--pass-bg); color:var(--pass);}
  .pill-warn{background:var(--warn-bg); color:var(--warn);}
  .delta-up{color:var(--pass); font-weight:600;}
  .delta-down{color:var(--fail); font-weight:600;}
  .delta-same{color:var(--muted);}
  .n-sub{display:block; font-size:11.5px; color:var(--muted); margin-top:2px;}

  @media print{
    body{background:#fff; color:#000; padding:0;}
    .card,table{background:#fff; border-color:#ccc;}
    th{background:#eee; color:#000; position:static;}
    html{background:#fff;}
    #bg-galaxy{display:none !important;}
    .card,table{backdrop-filter:none;}
    .sidebar,.toolbar,.controls,.g-copy,.head-actions{display:none !important;}
    .layout{display:block;}
    .tbl-wrap{overflow:visible;}
    .tabpane{display:block !important;}
    .sub,.act,.count-line{color:#333;}
    tr{page-break-inside:avoid;}
  }
</style>"""

CONTROLS_TMPL = """<div class="controls">
__PROFILE_SELECT__
  <select id="f-action">
    <option value="">Semua tindakan</option>
    <option value="ok">OK — tiada tindakan</option>
    <option value="printer">Manual: perlu printer</option>
    <option value="dev">Refer dev team (bug app/server)</option>
    <option value="rerun">Rerun untuk confirm</option>
    <option value="db">Perlu semakan DB (manusia)</option>
    <option value="arahan">Skip atas arahan</option>
    <option value="blocked">Show stopper — tersekat</option>
  </select>
  <select id="f-cat">
    <option value="">Semua kategori</option>
    <option value="T">T — Tetapan/Selaras (12)</option>
    <option value="N">N — Notis Amaran (6)</option>
    <option value="P">P — Kompaun Pelbagai (7)</option>
    <option value="K">K — Letak Kereta (7)</option>
    <option value="L">L — Kompaun Lesen (7)</option>
    <option value="S">S — Sitaan (6)</option>
    <option value="SK">SK — Senarai (1)</option>
    <option value="H">H — Hantar Semula (5)</option>
    <option value="TN">TN — Tarik Notis (1)</option>
    <option value="NK">NK — Notis ke Kompaun (2)</option>
  </select>
  <input type="text" id="f-search" placeholder="Cari nama / TC ID / nota...">
</div>"""


def render_controls(runs):
    """Penapis untuk tab Laporan.

    Dropdown PBT dan Versi sentiasa dipaparkan, walaupun setakat ini
    hanya ada satu pilihan: kawalan yang tersembunyi ialah kawalan yang
    tiada siapa tahu wujud. Senarai versi diisi semula oleh JS setiap
    kali PBT bertukar.
    """
    opts = "".join(
        f'<option value="{html.escape(name)}">'
        f'{html.escape(lst[0].get("profile_label") or name)}</option>'
        for name, lst in runs.items()
    ) or '<option value="">(tiada run)</option>'
    sel = (f'  <select id="f-profile" title="PBT / environment">{opts}</select>\n'
           f'  <select id="f-run" title="Versi app / masa run"></select>\n')
    return CONTROLS_TMPL.replace("__PROFILE_SELECT__", sel)


SCRIPT_TMPL = """<script>
const TOTAL = __TOTAL__;
const RUN_META = __RUN_META__;
const RUNS = __RUNS__;
const rows = [...document.querySelectorAll('#tbl tbody tr')];
const histRows = [...document.querySelectorAll('#hist-tbl tbody tr')];
const fProfile = document.getElementById('f-profile');
const fRun = document.getElementById('f-run');
let profileFilter = __DEFAULT_PROFILE__;
let runFilter = (RUNS[profileFilter] || [{key:''}])[0].key;
const cards = [...document.querySelectorAll('.card')];
const fAction = document.getElementById('f-action');
const fCat = document.getElementById('f-cat');
const fSearch = document.getElementById('f-search');
let statusFilter = 'all';

/* ---- tema gelap / cerah ---- */
/* Pilihan disimpan supaya tak perlu ditetapkan semula setiap kali
   laporan dibuka. Kalau localStorage disekat (mod privasi), toggle
   tetap berfungsi untuk sesi semasa. */
function applyTheme(t){
  document.documentElement.setAttribute('data-theme', t);
  const b = document.getElementById('btn-theme');
  if (b) b.textContent = (t === 'light') ? '\\u263D  Mod Gelap' : '\\u2600  Mod Cerah';
  try { localStorage.setItem('mbjb-theme', t); } catch(e) {}
}
applyTheme(document.documentElement.getAttribute('data-theme') || 'dark');
document.getElementById('btn-theme').addEventListener('click', () => {
  const now = document.documentElement.getAttribute('data-theme');
  applyTheme(now === 'light' ? 'dark' : 'light');
});

/* ---- latar beranimasi ---- */
/* Lalai MATI kalau sistem pengguna minta kurangkan gerakan -- animasi
   boleh menyebabkan pening bagi sesetengah orang, jadi ia tidak patut
   dihidupkan tanpa diminta. Pilihan pengguna mengatasi lalai ini. */
function applyBg(on){
  window.__bgOn = on;
  document.body.classList.toggle('no-anim', !on);
  const b = document.getElementById('btn-bg');
  if (b) b.textContent = on ? '\\u2726  Latar: Hidup' : '\\u2726  Latar: Mati';
  if (on) { window.__bgResize(); window.__bgStart(); } else { window.__bgStop(); }
  try { localStorage.setItem('mbjb-bg', on ? '1' : '0'); } catch(e) {}
}
let bgSaved = null;
try { bgSaved = localStorage.getItem('mbjb-bg'); } catch(e) {}
const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
applyBg(bgSaved === null ? !reduceMotion : bgSaved === '1');
document.getElementById('btn-bg').addEventListener('click',
  () => applyBg(!window.__bgOn));

/* ---- navigasi sidebar ---- */
document.querySelectorAll('.nav').forEach(t => {
  t.addEventListener('click', () => {
    document.querySelectorAll('.nav').forEach(x => x.classList.remove('active'));
    document.querySelectorAll('.tabpane').forEach(x => x.classList.remove('active'));
    t.classList.add('active');
    document.getElementById('tab-' + t.dataset.tab).classList.add('active');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });
});

/* ---- salin arahan dalam Panduan ---- */
document.querySelectorAll('.g-copy').forEach(b => {
  b.addEventListener('click', () => {
    navigator.clipboard.writeText(b.dataset.copy).then(() => {
      const old = b.textContent;
      b.textContent = 'Disalin!';
      setTimeout(() => { b.textContent = old; }, 1400);
    });
  });
});

/* ---- penapis laporan ---- */
cards.forEach(c => c.addEventListener('click', () => {
  cards.forEach(x => x.classList.remove('active'));
  c.classList.add('active');
  statusFilter = c.dataset.filter;
  apply();
}));
if (fAction) fAction.addEventListener('change', apply);
if (fCat) fCat.addEventListener('change', apply);
if (fSearch) fSearch.addEventListener('input', apply);
/* Senarai versi diisi semula setiap kali PBT bertukar: setiap PBT ada
   sejarah run sendiri, jadi pilihan versi tidak boleh statik. */
function fillRuns(keep){
  if (!fRun) return;
  const list = RUNS[profileFilter] || [];
  fRun.innerHTML = list.map(r =>
    '<option value="' + r.key + '">' + r.label + '</option>').join('')
    || '<option value="">(tiada run)</option>';
  runFilter = (keep && list.some(r => r.key === keep)) ? keep
            : (list[0] ? list[0].key : '');
  fRun.value = runFilter;
  fRun.disabled = list.length < 2;
}

if (fProfile) {
  fProfile.value = profileFilter;
  fProfile.addEventListener('change', () => {
    profileFilter = fProfile.value;
    fillRuns();
    updateCards(); updateMeta(); apply();
  });
}
if (fRun) {
  fRun.addEventListener('change', () => {
    runFilter = fRun.value;
    updateCards(); updateMeta(); apply();
  });
}

function visibleRows(){ return rows.filter(r => !r.classList.contains('hidden')); }

/* Baris run terpilih sahaja — asas untuk kad ringkasan. */
function profileRows(){ return rows.filter(r => r.dataset.run === runFilter); }

/* Kad dikira semula setiap kali PBT bertukar: nombor tetap milik
   satu PBT, bukan campuran semua. */
function updateCards(){
  /* Tiada baris langsung = belum ada run. Biarkan nilai yang dirender
     oleh Python (54 / 0 / 0 / 0) kekal: menulis 0 ke kad "Semua" akan
     bercanggah dengan sidebar yang berkata 54 test case, dan membuatkan
     halaman kelihatan rosak sedangkan ia cuma belum dijalankan. */
  if (rows.length === 0) return;
  const mine = profileRows();
  const n = s => mine.filter(r => r.dataset.status === s).length;
  const set = (id, v) => { const el = document.getElementById(id); if (el) el.textContent = v; };
  set('c-all', mine.length);
  set('c-pass', n('PASSED'));
  /* NOT RUN mempunyai kadnya SENDIRI dan TIDAK dicampur ke dalam Failed.
     Sebelum ini ia dikira sebagai Failed, jadi run yang terhenti di
     tengah jalan melaporkan 34 "kegagalan" yang sebenarnya tidak pernah
     dijalankan — dakwaan yang buktinya tidak menyokong. Ia juga
     bercanggah dengan penapis kad: kad Failed menapis data-status
     "FAILED", jadi nombor pada kad tidak sama dengan bilangan baris yang
     ditunjukkan bila kad itu diketuk. */
  set('c-fail', mine.filter(r => ['FAILED','ERROR'].includes(r.dataset.status)).length);
  set('c-skip', n('SKIPPED'));
  set('c-notrun', n('NOT RUN'));
  set('c-recheck', mine.filter(r => r.dataset.recheck === '1').length);
  set('c-beza', mine.filter(r => r.dataset.beza === '1').length);
}

function updateMeta(){
  const el = document.getElementById('run-meta');
  if (el && RUN_META[runFilter]) el.innerHTML = RUN_META[runFilter];
  histRows.forEach(r => r.classList.remove('hidden'));
}

function apply(){
  const q = fSearch ? fSearch.value.toLowerCase() : '';
  let shown = 0;
  const mine = profileRows();
  rows.forEach(r => {
    let ok = r.dataset.run === runFilter;
    if (ok && statusFilter === 'recheck') ok = r.dataset.recheck === '1';
    else if (ok && statusFilter === 'beza') ok = r.dataset.beza === '1';
    else if (ok && statusFilter !== 'all') ok = r.dataset.status === statusFilter;
    if (ok && fAction && fAction.value) ok = r.dataset.action === fAction.value;
    if (ok && fCat && fCat.value) ok = r.dataset.cat === fCat.value;
    if (ok && q) ok = r.textContent.toLowerCase().includes(q);
    r.classList.toggle('hidden', !ok);
    if (ok) shown++;
  });
  const cl = document.getElementById('count-line');
  if (cl) cl.textContent = shown + ' / ' + mine.length + ' test case dipaparkan';
}
fillRuns(runFilter);
updateCards();
updateMeta();
apply();

/* ---- export CSV (ikut penapis yang aktif) ---- */
function csvCell(s){
  s = (s == null ? '' : String(s)).replace(/\\s+/g, ' ').trim();
  return '"' + s.replace(/"/g, '""') + '"';
}
document.getElementById('btn-csv').addEventListener('click', () => {
  const head = ['No','TC ID','Nama','Automation','Manual (Excel)','Tindakan','Nota'];
  const lines = [head.map(csvCell).join(',')];
  visibleRows().forEach(r => {
    lines.push([...r.querySelectorAll('td')].map(td => csvCell(td.textContent)).join(','));
  });
  /* BOM supaya Excel baca UTF-8 dengan betul */
  const blob = new Blob(['\\uFEFF' + lines.join('\\r\\n')], {type:'text/csv;charset=utf-8;'});
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'laporan-mbjb-' + profileFilter + '-__STAMP__.csv';
  a.click();
  URL.revokeObjectURL(a.href);
});

document.getElementById('btn-print').addEventListener('click', () => window.print());
</script>"""


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def fmt_duration(dur):
    if not isinstance(dur, (int, float)):
        return ""
    h, mnt, s = int(dur // 3600), int((dur % 3600) // 60), int(dur % 60)
    return f"{h}j {mnt}m {s}s" if h else f"{mnt}m {s}s"


def resolve_row(entry, results, ver, use_baseline=False):
    """Pulangkan model render bagi satu TC: status, tindakan, recheck, nota.

    `use_baseline` lalai MATI untuk MBJB. Ia hanya bermakna selepas
    seseorang benar-benar memilih satu run MBJB sebagai garis dasar dan
    mengisi medan `baseline` dalam META. Menghidupkannya sebelum itu akan
    menandakan setiap TC sebagai "regresi" pada run pertama.
    """
    no, tcid, nama, cat, baseline, forced, base_note = entry
    base_note = (base_note or "").replace("{ver}", ver)

    if forced:
        action, note = forced
        note = note.replace("{ver}", ver)
        caveat = SCOPE_CAVEAT.get(tcid)
        if caveat and caveat not in note:
            note += caveat
        return {"no": no, "tcid": tcid, "nama": nama, "cat": cat,
                "status": "SKIPPED", "action": action,
                "note": note, "changed": False}

    status = results.get(tcid, "NOT RUN")
    changed = bool(use_baseline and baseline and status != baseline)

    if status == "PASSED":
        action = "ok"
    elif status == "SKIPPED" and tcid in PRINTER_TCS:
        # Printer tidur -- perlu dicuba semula dengan printer dikejutkan,
        # bukan dirujuk kepada dev team.
        action = "printer"
    elif status == "SKIPPED" and tcid in DB_VERIFY_TCS:
        # Rerun tidak akan mengubah apa-apa: langkah TC ini memang di luar
        # jangkauan device. Ia perlu mata manusia pada pangkalan data.
        action = "db"
    elif status == "SKIPPED":
        action = "rerun"
    elif tcid in KNOWN_DEV_ISSUE:
        action = "dev"
    else:
        # Run pertama MBJB: tiada garis dasar, jadi kegagalan yang tidak
        # berdokumen belum layak dipanggil "bug app". Sahkan dengan rerun
        # dahulu — kalau berulang, barulah ia penemuan untuk dev team.
        action = "rerun"

    if not changed:
        note = base_note
    elif status == "PASSED":
        note = ("\U0001F501 Regresi PULIH — baseline " + str(baseline) +
                ", PASS run ni. Sahkan manual & update note.")
    elif status in ("FAILED", "ERROR"):
        note = ("\U0001F501 Regresi BAHARU — baseline " + str(baseline) +
                ", " + status + " run ni. Confirm dengan rerun & check "
                "last_run.txt.")
    else:
        note = ("\U0001F501 Status berubah — baseline " + str(baseline) +
                ", " + status + " run ni. Check last_run.txt.")

    # Caveat skop sentiasa dikekalkan, walau apa pun status run ini.
    caveat = SCOPE_CAVEAT.get(tcid)
    if caveat and caveat not in note:
        note = note + caveat

    return {"no": no, "tcid": tcid, "nama": nama, "cat": cat,
            "status": status, "action": action, "note": note,
            "changed": changed}


# Peta status automation -> hasil setara dalam istilah tester manual,
# supaya kedua-duanya boleh dibandingkan secara adil.
def _setara(status):
    if status == "PASSED":
        return "Pass"
    if status in ("FAILED", "ERROR"):
        return "Fail"
    return None                      # SKIPPED / NOT RUN: tiada bandingan


# ---------------------------------------------------------------------------
# Sebab SKIP / NOT RUN — tidak boleh kosong.
#
# Laporan MBIP pernah memaparkan SKIPPED sebagai lencana kuning dengan
# lajur Nota yang KOSONG. Pembaca menyimpulkan sendiri: sesetengah
# menyangka TC itu lulus, sesetengah menyangka ia sengaja dilangkau
# selama-lamanya. Kedua-duanya salah, dan tiada apa pada halaman itu yang
# boleh membetulkan mereka.
#
# Peraturan di sini: setiap baris yang BUKAN PASSED mesti membawa satu
# ayat yang menerangkan KENAPA, walaupun ayat itu ialah pengakuan bahawa
# sebabnya tidak direkodkan. "Sebab tidak direkodkan" ialah maklumat —
# ia menunjuk kepada hook conftest, bukan kepada aplikasi.
# ---------------------------------------------------------------------------
_SEBAB_LALAI = {
    "printer": ("Printer Bluetooth tidak bersambung dalam tempoh menunggu, "
                "jadi langkah Cetak tidak dapat dilaksanakan. Keadaan "
                "persekitaran, bukan kecacatan aplikasi."),
    "db": ("Langkah pengesahan TC ini ialah semakan PANGKALAN DATA ePBT, "
           "yang tidak boleh dicapai dari handheld. Tiada bahagian TC ini "
           "yang boleh disahkan oleh automation."),
}


def _sebab_html(m, reason):
    """Kotak "sebab" untuk baris bukan-PASSED. Pulangkan "" untuk PASSED."""
    status = m["status"]
    if status == "PASSED":
        return ""

    bits = []

    # TC hulu dipaparkan sebagai butiran tersendiri supaya "skip ini bukan
    # tentang TC ini" kelihatan tanpa perlu membaca nota penuh.
    if m.get("blocker"):
        bits.append(
            f'<div class="blockref">Tersekat oleh '
            f'<b>{html.escape(m["blocker"])}</b> '
            f'({html.escape(str(m.get("blocker_status") or "?"))}) — '
            f'TC ini tidak pernah dijalankan.</div>')

    if status == "NOT RUN":
        bits.append(
            '<div class="skipwhy">TC ini tidak muncul dalam '
            '<code>results.json</code>: ia tidak dikumpul, atau run terhenti '
            'sebelum sampai kepadanya. Ini BUKAN kelulusan dan BUKAN '
            'kegagalan aplikasi — ia bermakna TC ini tidak diuji.</div>')
    elif status == "SKIPPED":
        if reason:
            bits.append(f'<div class="skipwhy">Sebab skip: '
                        f'{html.escape(reason)}</div>')
        elif m.get("blocker"):
            pass                        # sudah diterangkan oleh blockref
        elif m["action"] in _SEBAB_LALAI:
            bits.append(f'<div class="skipwhy">Sebab skip: '
                        f'{_SEBAB_LALAI[m["action"]]}</div>')
        else:
            bits.append(
                '<div class="skipwhy">Sebab skip <b>tidak direkodkan</b> oleh '
                'run ini. Skip tanpa sebab tidak boleh ditafsir — baca '
                '<code>reports/last_run.txt</code>, dan kalau ia berulang '
                'itu kecacatan dalam hook laporan, bukan dalam TC.</div>')
    elif status in ("FAILED", "ERROR") and not reason:
        bits.append(
            '<div class="realerr">Mesej ralat sebenar <b>tidak direkodkan</b> '
            'oleh run ini. Nota di atas ialah konteks yang ditulis tangan '
            'sebelum run — ia BUKAN sebab kegagalan ini. Baca '
            'reports/last_run.txt.</div>')
    return "".join(bits)


def render_row(m, profile, rkey, manual=None, reason="", artifact=None):
    """Satu baris TC. `manual` = entri status dari Excel V2.1.33, jika ada.

    Perbandingan bersebelahan ini ada satu tujuan: mencari di mana
    automation dan tester manual TIDAK sependapat. Lajur Manual BUKAN
    kebenaran — ia rekod run manual Feb 2026 atas production.
    """
    status = m["status"]
    badge_cls = BADGE_CLASS.get(status, "b-fail")
    action = m["action"]
    recheck = action in RECHECK_ACTIONS
    act_cls = "act hot" if recheck else "act"
    recheck_attr = ' data-recheck="1"' if recheck else ""

    # Nota = konteks yang ditulis tangan + ralat SEBENAR run ini.
    # Nota tangan sahaja boleh menyesatkan: ia terus memaparkan sebab lama
    # walaupun TC kini gagal atas sebab yang berbeza.
    note_cell = html.escape(m["note"])
    if artifact:
        chips = " ".join(
            f'<span class="artf" title="{html.escape(k)}">'
            f'{html.escape(str(v))}</span>' for k, v in artifact.items())
        note_cell += f'<div class="artf-row">{chips}</div>'
    # Mesej pytest bagi SKIPPED bukan ralat — ia sebab. Menaruhnya dalam
    # kotak merah `.realerr` membuatkan skip kelihatan seperti kegagalan,
    # jadi ia dihalakan ke `.skipwhy` oleh _sebab_html() di bawah.
    if reason and status in ("FAILED", "ERROR"):
        note_cell += (f'<div class="realerr" title="Ralat sebenar run ini">'
                      f'{html.escape(reason)}</div>')
    note_cell += _sebab_html(m, reason)

    m_st = (manual or {}).get("status") or ""
    auto_eq = _setara(status)
    beza = bool(m_st and auto_eq and m_st.lower() != auto_eq.lower())
    beza_attr = ' data-beza="1"' if beza else ""

    if not m_st:
        manual_cell = '<span class="muted-cell">—</span>'
    else:
        cls = "b-pass" if m_st.lower() == "pass" else "b-fail"
        arrow = ""
        if beza:
            arrow = ('<span class="beza-mark" title="Automation dan '
                     'tester manual tidak sependapat">&#8800;</span>')
        manual_cell = f'<span class="badge {cls}">{html.escape(m_st)}</span>{arrow}'

    return (
        f'<tr data-profile="{html.escape(profile)}" '
        f'data-run="{html.escape(rkey)}" '
        f'data-status="{status}" data-action="{action}" '
        f'data-cat="{m["cat"]}"{recheck_attr}{beza_attr}>'
        f'<td>{m["no"]}</td>'
        f'<td class="tcid">{html.escape(m["tcid"])}</td>'
        f'<td>{html.escape(m["nama"])}</td>'
        f'<td><span class="badge {badge_cls}">{html.escape(status)}</span></td>'
        f'<td>{manual_cell}</td>'
        f'<td class="{act_cls}">{html.escape(ACTION_TEXT.get(action, action))}</td>'
        f'<td class="act">{note_cell}</td>'
        f'</tr>'
    )


# ---------------------------------------------------------------------------
# Run history
# ---------------------------------------------------------------------------

def archive_run(data, n_pass, n_fail, n_skip, n_notrun=0):
    """Tambah run ini ke reports/history/.

    Menyimpan kiraan YANG SUDAH DILERAI (forced-skip sudah dikenakan),
    bukan tally mentah pytest, supaya jadual sejarah tidak boleh
    bercanggah dengan kad di atas laporan.

    Menyimpan juga keputusan penuh per-TC dan profil PBT: laporan
    memaparkan run TERKINI bagi SETIAP profil pada satu halaman, jadi
    setiap entri sejarah mesti membawa cukup data untuk dirender sendiri.

    Kunci fail = profil + masa + tester. Profil disertakan supaya run
    staging dan production tidak boleh menimpa satu sama lain.
    """
    os.makedirs(HISTORY_DIR, exist_ok=True)
    stamp = data.get("generated_at", "?")
    tester = data.get("tester") or "unknown"
    prof = data.get("profile") or "tanpa-profil"
    entry = {
        "generated_at": stamp,
        "tester": tester,
        "profile": prof,
        "profile_label": data.get("profile_label") or prof,
        "pbt": data.get("pbt") or "?",
        "env": data.get("env") or "?",
        "device_udid": data.get("device_udid"),
        "device_model": data.get("device_model"),
        "app_version": data.get("app_version"),
        "duration_seconds": data.get("duration_seconds"),
        # `not_run` disimpan berasingan supaya baris sejarah menjumlah
        # kepada 54 dan pembaca dapat melihat run yang terhenti di tengah
        # jalan sebagai terhenti, bukan sebagai 34 kegagalan.
        "passed": n_pass, "failed": n_fail, "skipped": n_skip,
        "not_run": n_notrun,
        "results": data.get("results", {}),
        "reasons": data.get("reasons", {}),
        "artifacts": data.get("artifacts", {}),
    }
    safe = re.sub(r"[^0-9A-Za-z-]", "-", f"{prof}_{stamp}_{tester}")
    with open(os.path.join(HISTORY_DIR, f"{safe}.json"), "w",
              encoding="utf-8") as fh:
        json.dump(entry, fh, indent=2, ensure_ascii=False)
    return entry


def load_profiles():
    """Semua profil dalam profiles/, tanpa memilih mana-mana.

    Sengaja membaca JSON terus dan BUKAN memanggil profile.load(): fungsi
    itu menolak untuk memilih apabila ada lebih daripada satu profil (dan
    betul begitu untuk menjalankan ujian), tetapi di sini kita memang
    mahu kesemuanya sekali gus.
    """
    out = {}
    if not os.path.isdir(PROFILES_DIR):
        return out
    for f in sorted(os.listdir(PROFILES_DIR)):
        if not f.endswith(".json"):
            continue
        try:
            with open(os.path.join(PROFILES_DIR, f), encoding="utf-8") as fh:
                p = json.load(fh)
        except Exception:                               # noqa: BLE001
            continue
        p["_name"] = os.path.splitext(f)[0]
        p["_belum_lengkap"] = sorted(
            k for k, v in p.items()
            if not k.startswith("_") and str(v).strip() == "ISI-SINI")
        out[p["_name"]] = p
    return out


def load_pipeline():
    """Snapshot folder shared, kalau ada (tools/extract_pipeline.py)."""
    try:
        with open(PIPELINE_JSON, encoding="utf-8") as fh:
            return json.load(fh)
    except Exception:                                   # noqa: BLE001
        return None


def manual_for(pipeline, pbt):
    """Status manual per TC. pipeline.json (dibaca terus dari workbook)
    mengatasi jadual MANUAL_EXCEL yang dibenamkan dalam fail ini."""
    pj = (((pipeline or {}).get("pbt", {}).get(pbt or "", {})
           .get("script") or {}).get("status_per_tc") or {})
    if pj:
        return {"_pipeline": pj}
    return {"_benam": MANUAL_EXCEL}


def manual_lookup(mp, tcid):
    if "_pipeline" in mp:
        # Kunci pipeline dinormalkan (TC-T-001) supaya awalan PBT yang
        # berbeza tetap padan.
        return mp["_pipeline"].get(re.sub(r"^[A-Z]+-TC-", "TC-", tcid))
    return mp["_benam"].get(tcid)


def render_pipeline(profiles, pipeline, latest):
    """Satu baris bagi setiap slot PBT×environment.

    Ini menjawab soalan yang tab Laporan tidak boleh jawab: profil yang
    BELUM ada run automation langsung tidak muncul di sana, jadi tiada
    cara untuk nampak sejauh mana liputan automation merentasi pipeline.
    """
    if not profiles:
        return ('<div class="hist-note">Tiada profil dalam '
                '<code>profiles/</code>.</div>')

    pj = (pipeline or {}).get("pbt", {})
    rows = []
    for name, p in sorted(profiles.items(),
                          key=lambda kv: (kv[1].get("pbt", ""),
                                          kv[1].get("env", ""))):
        pbt, env = p.get("pbt", "?"), p.get("env", "?")
        info = pj.get(pbt, {})
        sc = info.get("script") or {}
        apk = (info.get("apk") or {}).get(env) or {}

        run = latest.get(name)
        if run:
            auto = (f'<span class="badge b-pass">{run.get("passed",0)}</span> '
                    f'<span class="badge b-fail">{run.get("failed",0)}</span> '
                    f'<span class="badge b-skip">{run.get("skipped",0)}</span> '
                    f'<span class="badge b-notrun" title="Tidak dijalankan">'
                    f'{run.get("not_run",0)}</span>')
            bila = (run.get("generated_at") or "?").replace("T", " ")[:16]
        else:
            auto = '<span class="muted-cell">belum dijalankan</span>'
            bila = "—"

        if p["_belum_lengkap"]:
            sedia = (f'<span class="pill pill-warn">belum lengkap</span>'
                     f'<span class="n-sub">{", ".join(p["_belum_lengkap"])}</span>')
        else:
            sedia = '<span class="pill pill-ok">sedia</span>'

        skrip = str(sc.get("version") or "—")
        if sc.get("tc_count"):
            skrip += f" ({sc['tc_count']} TC)"
        elif not pipeline:
            # Tanpa snapshot pipeline, versi workbook yang KITA guna
            # sebagai sumber tetap perlu kelihatan.
            skrip = "V2.1.33 (54 TC)"

        rows.append(
            "<tr>"
            f"<td><b>{html.escape(pbt)}</b></td>"
            f"<td>{html.escape(env)}</td>"
            f"<td>{sedia}</td>"
            f"<td class='act'>{html.escape(skrip)}</td>"
            f"<td class='act'>{html.escape(str(apk.get('versi') or '—'))}</td>"
            f"<td>{auto}</td>"
            f"<td class='act'>{html.escape(bila)}</td>"
            "</tr>"
        )

    ada_run = sum(1 for n in profiles if n in latest)
    src = ""
    if pipeline:
        src = (f' Versi Excel dan APK diambil dari snapshot folder shared '
               f'({html.escape((pipeline.get("dijana") or "")[:10])}) — '
               f'jalankan <code>python tools/extract_pipeline.py</code> '
               f'untuk menyegarkan.')
    return (
        f'<div class="hist-note">{ada_run} daripada {len(profiles)} slot '
        f'PBT×environment sudah ada run automation. Sasaran run yang '
        f'dibenarkan ialah <b>MBJB staging</b> — profil production sengaja '
        f'tidak lengkap dan akan ditolak.{src}</div>'
        '<div class="tbl-wrap"><table><thead><tr>'
        '<th>PBT</th><th>Env</th><th>Profil</th><th>Test Script</th>'
        '<th>APK</th><th>Automation (P/F/S)</th><th>Run terakhir</th>'
        '</tr></thead><tbody>' + "\n".join(rows) + '</tbody></table></div>'
    )


def latest_per_profile(hist):
    """Run terkini bagi setiap profil, ikut susunan label."""
    seen = {}
    for e in hist:                      # hist sudah newest-first
        p = e.get("profile") or "tanpa-profil"
        if p not in seen:
            seen[p] = e
    return dict(sorted(seen.items(),
                       key=lambda kv: kv[1].get("profile_label") or kv[0]))


# Berapa banyak run lampau dibenamkan ke dalam halaman bagi setiap profil.
# Setiap run menambah 54 baris jadual; sejarah penuh kekal di cakera
# dalam reports/history/ dan tetap disenaraikan dalam tab Sejarah Run.
MAX_RUNS_PER_PROFILE = 10


def run_key(e):
    return f"{e.get('profile') or 'tanpa-profil'}|{e.get('generated_at') or '?'}"


def runs_for_report(hist):
    """Run yang boleh dipilih dalam tab Laporan: {profil: [entri, ...]}.

    Terbaharu dahulu, dipagar pada MAX_RUNS_PER_PROFILE supaya halaman
    tidak membengkak apabila sejarah bertambah panjang.
    """
    by_prof = {}
    for e in hist:                      # hist sudah newest-first
        p = e.get("profile") or "tanpa-profil"
        lst = by_prof.setdefault(p, [])
        if len(lst) < MAX_RUNS_PER_PROFILE:
            lst.append(e)
    return dict(sorted(
        by_prof.items(),
        key=lambda kv: kv[1][0].get("profile_label") or kv[0]))


def load_history():
    """Setiap run yang diarkibkan, terbaharu dahulu."""
    if not os.path.isdir(HISTORY_DIR):
        return []
    out = []
    for name in os.listdir(HISTORY_DIR):
        if not name.endswith(".json"):
            continue
        try:
            with open(os.path.join(HISTORY_DIR, name), encoding="utf-8") as fh:
                out.append(json.load(fh))
        except Exception:                               # noqa: BLE001
            continue                                    # abaikan fail rosak
    out.sort(key=lambda e: e.get("generated_at") or "", reverse=True)
    return out


def render_history(hist):
    if not hist:
        return ('<div class="hist-note">Belum ada sejarah run. Run '
                'pertama akan direkodkan di sini.</div>')

    # Delta dikira dalam profil yang SAMA sahaja. Membandingkan run
    # staging dengan run production yang kebetulan berlaku sebelumnya akan
    # menghasilkan "+3 passed" yang tidak bermakna langsung.
    seen_prof = {}
    rows = []
    for e in hist:
        prof = e.get("profile") or "tanpa-profil"
        prev = seen_prof.get(prof)
        seen_prof[prof] = e

        if prev is None:
            delta = '<span class="delta-same">—</span>'
        else:
            d = (e.get("passed") or 0) - (prev.get("passed") or 0)
            if d > 0:
                delta = f'<span class="delta-up">+{d} passed</span>'
            elif d < 0:
                delta = f'<span class="delta-down">{d} passed</span>'
            else:
                delta = '<span class="delta-same">tiada perubahan</span>'

        stamp = (e.get("generated_at") or "?").replace("T", " ")
        model = e.get("device_model") or ""
        udid = e.get("device_udid") or "?"
        dev = f"{model} ({udid})" if model else udid
        rows.append(
            f'<tr data-profile="{html.escape(prof)}">'
            f"<td>{html.escape(stamp)}</td>"
            f"<td>{html.escape(str(e.get('profile_label') or prof))}</td>"
            f"<td>{html.escape(str(e.get('tester') or '?'))}</td>"
            f"<td>{html.escape(str(e.get('app_version') or '?'))}</td>"
            f'<td><span class="badge b-pass">{e.get("passed", 0)}</span></td>'
            f'<td><span class="badge b-fail">{e.get("failed", 0)}</span></td>'
            f'<td><span class="badge b-skip">{e.get("skipped", 0)}</span></td>'
            f'<td><span class="badge b-notrun">{e.get("not_run", 0)}</span></td>'
            f"<td class='act'>{html.escape(fmt_duration(e.get('duration_seconds')))}</td>"
            f"<td class='act'>{delta}</td>"
            f"<td class='act'>{html.escape(dev)}</td>"
            "</tr>"
        )

    n_prof = len(seen_prof)
    return (
        f'<div class="hist-note">{len(hist)} run direkodkan merentasi '
        f'{n_prof} profil. Disimpan automatik dalam '
        f'<code>reports/history/</code>, termasuk run ahli team lain. '
        f'Lajur "Berbanding run sebelum" membandingkan dalam profil yang '
        f'sama sahaja.</div>'
        '<div class="tbl-wrap"><table id="hist-tbl"><thead><tr>'
        '<th>Tarikh / Masa</th><th>Profil</th><th>Tester</th>'
        '<th>App Build</th>'
        '<th>Passed</th><th>Failed</th><th>Skipped</th><th>Tidak Dijalankan</th>'
        '<th>Tempoh</th><th>Berbanding run sebelum</th><th>Device</th>'
        '</tr></thead><tbody>' + "\n".join(rows) + '</tbody></table></div>'
    )


def load_results():
    """results.json run terakhir, atau None kalau belum ada.

    Mengembalikan None (dan bukan melemparkan) adalah sengaja: laporan
    mesti boleh dijana pada mesin yang belum pernah menjalankan test —
    contohnya sebaik selepas unzip, semata-mata untuk membaca Panduan.
    """
    try:
        with open(RESULTS_JSON, encoding="utf-8") as fh:
            return json.load(fh)
    except FileNotFoundError:
        return None
    except Exception as e:                              # noqa: BLE001
        print(f"[generate_report] WARNING: results.json tidak boleh dibaca "
              f"({type(e).__name__}: {e}) — laporan dijana dari sejarah "
              f"sahaja")
        return None


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    data = load_results()
    ada_results = data is not None
    if not ada_results:
        data = {}

    generated_at = data.get("generated_at", "?")
    dur = data.get("duration_seconds")
    tester = data.get("tester") or "?"
    app_ver = data.get("app_version") or "?"
    udid = data.get("device_udid") or "?"
    model = data.get("device_model") or ""

    n_pass = n_fail = n_skip = n_recheck = n_changed = 0
    n_notrun = total = len(META)        # belum ada run => semuanya NOT RUN

    if ada_results:
        archive_run(data, 0, 0, 0, 0)   # sementara — dikemas kini di bawah
    hist = load_history()

    # Satu halaman, semua profil. Setiap baris ditanda dengan profilnya;
    # dropdown PBT menapis guna enjin penapis sedia ada.
    pipeline = load_pipeline()
    runs = runs_for_report(hist)
    rows_all, run_meta, runs_js = [], {}, {}

    for pname, entries in runs.items():
        runs_js[pname] = []
        for entry in entries:
            rkey = run_key(entry)
            p_results = entry.get("results", {})
            p_ver = entry.get("app_version") or "?"
            p_manual = manual_for(pipeline, entry.get("pbt") or "MBJB")
            use_base = (BASELINE_PROFILE is not None
                        and entry.get("profile") == BASELINE_PROFILE)
            p_models = apply_blockers(
                [resolve_row(e, p_results, p_ver, use_base) for e in META])

            rows_all.extend(
                render_row(m, pname, rkey,
                           manual_lookup(p_manual, m["tcid"]),
                           reason=(entry.get("reasons") or {}).get(m["tcid"], ""),
                           artifact=(entry.get("artifacts") or {}).get(m["tcid"]))
                for m in p_models)

            p_pass = sum(1 for m in p_models if m["status"] == "PASSED")
            # NOT RUN dikira BERASINGAN daripada FAILED. TC yang tidak
            # pernah dijalankan bukan TC yang gagal, dan melaporkannya
            # sebagai gagal ialah dakwaan yang buktinya tidak menyokong.
            p_fail = sum(1 for m in p_models
                         if m["status"] in ("FAILED", "ERROR"))
            p_skip = sum(1 for m in p_models if m["status"] == "SKIPPED")
            p_notrun = sum(1 for m in p_models if m["status"] == "NOT RUN")
            p_chg = sum(1 for m in p_models if m["changed"])

            p_model = entry.get("device_model") or ""
            p_udid = entry.get("device_udid") or "?"
            p_dev = f"{p_model} ({p_udid})" if p_model else p_udid
            p_dur = fmt_duration(entry.get("duration_seconds"))
            base_txt = (f" &nbsp;•&nbsp; {p_chg} status berubah vs baseline"
                        if use_base else
                        " &nbsp;•&nbsp; tiada baseline automation untuk MBJB")
            run_meta[rkey] = (
                f"Run oleh <b>{html.escape(str(entry.get('tester') or '?'))}</b> "
                f"pada {html.escape(entry.get('generated_at') or '?')}"
                f"{f' ({p_dur})' if p_dur else ''} &nbsp;•&nbsp; "
                f"App build <b>{html.escape(str(p_ver))}</b> &nbsp;•&nbsp; "
                f"Device {html.escape(p_dev)}{base_txt}"
            )

            # Label dropdown versi: build dahulu (itu yang dicari), diikuti
            # tarikh dan tester untuk membezakan beberapa run pada build sama.
            when = (entry.get("generated_at") or "?").replace("T", " ")[5:16]
            runs_js[pname].append({
                "key": rkey,
                "label": f"{p_ver} — {when} ({entry.get('tester') or '?'})",
            })

            # Kad awal: run TERKINI bagi profil semasa (entri pertama).
            if pname == (data.get("profile") or "tanpa-profil") \
                    and len(runs_js[pname]) == 1:
                n_pass, n_fail, n_skip, n_changed = p_pass, p_fail, p_skip, p_chg
                n_notrun = p_notrun
                n_recheck = sum(1 for m in p_models
                                if m["action"] in RECHECK_ACTIONS)

    # Kemas kini entri sejarah run ini dengan kiraan sebenar.
    if ada_results:
        archive_run(data, n_pass, n_fail, n_skip, n_notrun)
        hist = load_history()
    profiles = latest_per_profile(hist)

    default_profile = data.get("profile") or (
        next(iter(profiles)) if profiles else "tanpa-profil")

    semua_profil = load_profiles()
    pipeline_html = render_pipeline(semua_profil, pipeline, profiles)
    n_slot = len(semua_profil)
    n_ada_run = sum(1 for n in semua_profil if n in profiles)

    sub = (
        f"Source of truth: {html.escape(SUMBER_EXCEL)} &nbsp;•&nbsp; "
        f"{total} test case &nbsp;•&nbsp; lajur <b>Manual (Excel)</b> ialah "
        f"rekod run manual lama, BUKAN oracle"
        '<br><span id="run-meta"></span>'
    )

    cards = (
        '<div class="cards">\n'
        f'  <div class="card active" data-filter="all"><div class="num all" id="c-all">{total}</div><div class="lbl">Semua</div></div>\n'
        f'  <div class="card" data-filter="PASSED"><div class="num pass" id="c-pass">{n_pass}</div><div class="lbl">Passed</div></div>\n'
        f'  <div class="card" data-filter="FAILED"><div class="num fail" id="c-fail">{n_fail}</div><div class="lbl">Failed</div></div>\n'
        f'  <div class="card" data-filter="SKIPPED"><div class="num skip" id="c-skip">{n_skip}</div><div class="lbl">Skipped</div></div>\n'
        # Kad tersendiri, BUKAN dicampur ke dalam Failed. "Tidak diuji"
        # ialah keadaan ketiga yang berbeza daripada lulus dan gagal, dan
        # ia mesti kelihatan sebagai keadaan itu.
        f'  <div class="card" data-filter="NOT RUN"><div class="num notrun" id="c-notrun">{n_notrun}</div><div class="lbl">Tidak Dijalankan</div></div>\n'
        f'  <div class="card" data-filter="recheck"><div class="num recheck" id="c-recheck">{n_recheck}</div><div class="lbl">Perlu Manual Recheck</div></div>\n'
        f'  <div class="card" data-filter="beza"><div class="num beza" id="c-beza">0</div><div class="lbl">Beza vs Excel</div></div>\n'
        '</div>'
    )

    if rows_all:
        table_html = (
            f'{cards}\n{render_controls(runs)}\n'
            '<div class="count-line" id="count-line"></div>\n'
            '<div class="tbl-wrap">\n<table id="tbl">\n<thead>\n'
            '<tr><th>No</th><th>TC ID</th><th>Nama</th><th>Automation</th>'
            '<th>Manual (Excel)</th><th>Tindakan</th><th>Nota</th></tr>\n'
            '</thead>\n<tbody>\n' + "\n".join(rows_all) +
            '\n</tbody>\n</table>\n</div>'
        )
    else:
        # Belum ada satu pun run. Halaman tetap berguna: Pipeline dan
        # Panduan sudah lengkap, dan orang perlu tahu KENAPA jadual kosong.
        table_html = (
            f'{cards}\n'
            '<div class="empty">Belum ada run automation MBJB.<br>'
            f'Jadual {total} test case akan muncul di sini sebaik '
            '<code>tests\\run_and_report.bat</code> selesai dijalankan.<br>'
            'Sementara itu, tab <b>Panduan</b> sudah lengkap — mulakan di '
            'situ.</div>'
        )

    stamp = re.sub(r"[^0-9]", "", generated_at)[:12] or "run"
    script = (SCRIPT_TMPL
              .replace("__TOTAL__", str(total))
              .replace("__STAMP__", stamp)
              .replace("__RUN_META__", json.dumps(run_meta, ensure_ascii=False))
              .replace("__RUNS__", json.dumps(runs_js, ensure_ascii=False))
              .replace("__DEFAULT_PROFILE__",
                       json.dumps(default_profile, ensure_ascii=False)))

    def build_doc(zip_href, pub=None):
        """Dokumen yang sama, cuma laluan zip berbeza ikut lokasi fail."""
        pub = pub or {}
        extra = ""
        if pub.get("xlsx"):
            extra += (f'<a class="btn" href="{pub["xlsx"]}" download>'
                      f'Excel run ini</a>')
        if pub.get("log"):
            extra += (f'<a class="btn" href="{pub["log"]}" target="_blank">'
                      f'Log mentah</a>')
        toolbar = (
            '<div class="toolbar">'
            f'<a class="btn primary" href="{zip_href}" download '
            f'title="Mengandungi profiles/ — lesen peranti dan akaun '
            f'staging. Jangan edar di luar team.">'
            '⬇ Muat turun suite (.zip)</a>'
            f'{extra}'
            '<button class="btn" id="btn-csv">Export CSV</button>'
            '<button class="btn" id="btn-print">Cetak / Simpan PDF</button>'
            '</div>'
        )
        return f"""<!DOCTYPE html>
<html lang="ms">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Pipeline Testing Dashboard — MBJB</title>
<link rel="icon" type="image/png" href="{FAVICON_DATA_URI}">
<link rel="apple-touch-icon" href="{FAVICON_DATA_URI}">
{HEAD_SCRIPT}
{STYLE}
</head>
<body>
<canvas id="bg-galaxy"></canvas>

<div class="layout">

<aside class="sidebar">
  <div class="brand">Pipeline Testing</div>
  <button class="nav active" data-tab="pipeline">Pipeline<span class="n-sub">{n_ada_run}/{n_slot} slot ada run</span></button>
  <button class="nav" data-tab="laporan">Laporan<span class="n-sub">{total} test case</span></button>
  <button class="nav" data-tab="sejarah">Sejarah Run<span class="n-sub">{len(hist)} run direkod</span></button>
  <button class="nav" data-tab="panduan">Panduan<span class="n-sub">cara jalankan test</span></button>
</aside>

<main class="content">

<div class="head">
  <div>
    <h1>MBJB — Laporan Test Automation</h1>
    <div class="sub">{sub}</div>
  </div>
  <div class="head-actions">
    <button class="btn" id="btn-bg" title="Hidup / matikan latar beranimasi"></button>
    <button class="btn" id="btn-theme" title="Tukar tema gelap / cerah"></button>
  </div>
</div>

<div class="tabpane active" id="tab-pipeline">
{pipeline_html}
</div>

<div class="tabpane" id="tab-laporan">
{toolbar}
{table_html}
</div>

<div class="tabpane" id="tab-sejarah">
{render_history(hist)}
</div>

<div class="tabpane" id="tab-panduan">
{guide.guide_html()}
</div>

</main>
</div>

{BACKGROUND_SCRIPT}
{script}

</body>
</html>
"""

    # Excel per run: nombor rekod + ralat sebenar, boleh ditapis, untuk
    # menjejak balik ke pangkalan data.
    xl_path = None
    if ada_results:
        try:
            cur = profiles.get(default_profile) or {}
            cur_models = apply_blockers([
                resolve_row(e, cur.get("results", {}), app_ver, False)
                for e in META])
            mp = manual_for(pipeline, cur.get("pbt") or "MBJB")
            manual_flat = {m["tcid"]: (manual_lookup(mp, m["tcid"]) or {})
                           for m in cur_models}
            stamp2 = re.sub(r"[^0-9]", "", generated_at)[:12] or "run"
            xl_path = make_excel.build(
                os.path.join(HERE, f"run_{default_profile}_{stamp2}"),
                {
                    "PBT / Environment": cur.get("profile_label",
                                                 default_profile),
                    "Tarikh run": generated_at,
                    "Tester": tester,
                    "App build": app_ver,
                    "Device": (f"{cur.get('device_model') or ''} "
                               f"({cur.get('device_udid') or '?'})").strip(),
                    "Profil": default_profile,
                    "Tempoh": fmt_duration(dur),
                    "Sumber TC": SUMBER_EXCEL,
                },
                cur_models,
                cur.get("reasons") or {},
                cur.get("artifacts") or {},
                manual_flat,
            )
            print(f"[generate_report] wrote {xl_path}")
        except Exception as e:                          # noqa: BLE001
            print(f"[generate_report] WARNING: Excel tidak dijana "
                  f"({type(e).__name__}: {e})")

    # Artifak run -> public/. Tanpa ini, setiap "lihat butiran di X"
    # dalam dashboard ialah jalan mati bagi sesiapa yang melihat melalui
    # URL live: fail itu hanya wujud pada mesin yang menjalankan test.
    published = {}
    try:
        import shutil
        os.makedirs(PUBLIC_DIR, exist_ok=True)
        raw = os.path.join(HERE, "last_run.txt")
        if os.path.exists(raw):
            shutil.copy2(raw, os.path.join(PUBLIC_DIR, "last_run.txt"))
            published["log"] = "last_run.txt"
        if xl_path and os.path.exists(xl_path):
            name = os.path.basename(xl_path)
            shutil.copy2(xl_path, os.path.join(PUBLIC_DIR, name))
            published["xlsx"] = name
            olds = sorted(f for f in os.listdir(PUBLIC_DIR)
                          if f.startswith("run_") and f.endswith(".xlsx"))
            for f in olds[:-5]:
                try:
                    os.remove(os.path.join(PUBLIC_DIR, f))
                except OSError:
                    pass
    except Exception as e:                              # noqa: BLE001
        print(f"[generate_report] WARNING: artifak tidak disalin "
              f"({type(e).__name__}: {e})")

    os.makedirs(PUBLIC_DIR, exist_ok=True)
    with open(OUT_HTML, "w", encoding="utf-8") as fh:
        fh.write(build_doc(ZIP_HREF_LOCAL, published))
    with open(PUBLIC_HTML, "w", encoding="utf-8") as fh:
        fh.write(build_doc(ZIP_HREF_PUBLIC, published))

    # PANDUAN.md — sama kandungan, untuk dibaca selepas unzip sebelum ada
    # dashboard. Ditulis SEBELUM zip dibina supaya versi terkini masuk.
    with open(PANDUAN_MD, "w", encoding="utf-8") as fh:
        fh.write(guide.guide_markdown())

    try:
        make_zip.build()
    except Exception as e:                              # noqa: BLE001
        print(f"[generate_report] WARNING: zip tidak dibina "
              f"({type(e).__name__}: {e}) — butang muat turun akan mati")

    dev_txt = f"{model} ({udid})" if model else udid

    print(f"[generate_report] wrote {OUT_HTML}")
    print(f"[generate_report] wrote {PUBLIC_HTML}")
    print(f"[generate_report] wrote {PANDUAN_MD}")
    if not ada_results:
        print("[generate_report] results.json TIADA — laporan dijana dari "
              "sejarah sahaja (ini normal sebelum run pertama)")
    else:
        print(f"[generate_report] profil={default_profile} tester={tester} "
              f"app_build={app_ver} device={dev_txt}")
        print(f"[generate_report] cards -> PASSED {n_pass} | FAILED {n_fail} | "
              f"SKIPPED {n_skip} | NOT RUN {n_notrun} | "
              f"RECHECK {n_recheck} | total {total}")
        if n_pass + n_fail + n_skip + n_notrun != total:
            # Kad mesti menjumlah kepada 54. Kalau tidak, satu status
            # tercicir daripada kiraan dan pembaca akan melihat nombor
            # yang tidak boleh disatukan.
            print(f"[generate_report] WARNING: kad tidak menjumlah kepada "
                  f"{total} — satu status tercicir daripada kiraan")
        if n_notrun:
            print(f"[generate_report] {n_notrun} TC TIDAK DIJALANKAN — "
                  f"bukan lulus, bukan gagal. Run mungkin terhenti awal.")
    print(f"[generate_report] history -> {len(hist)} run, "
          f"{len(profiles)} profil dipaparkan: "
          f"{', '.join(profiles) or '(tiada)'}")
    if n_changed:
        print(f"[generate_report] {n_changed} TC berubah vs baseline "
              f"(profil {default_profile})")


if __name__ == "__main__":
    main()

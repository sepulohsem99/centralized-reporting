# Laporan Run E2E — MBPG-testing — 20/08/2026

**Arahan:** `python tools\run_penuh.py --borang NPK --bersih`
**Projek:** `C:\Users\mrsai\Documents\antigravity\keen-lovelace\MBPG-testing`
**Tarikh run:** Rabu, 20 Ogos 2026
**Build apk dikesan:** 2.1.23 · **Oracle suite:** 2.1.20 → **TAKSA (versi tidak sepadan)**
**Keputusan keseluruhan:** ⚠️ **SEPARA LULUS** — bukan full-pass. Cipta/cetak/kemaskini berjaya, tetapi fasa hantar-akhir gagal (bug navigasi suite) dan semakan D-09 mengesahkan bug aplikasi.

> Nota pasca-run (disahkan Saifullah, 20/08 petang): **semua cetakan berjaya keluar** di pencetak.

---

## 1. Ringkasan Keputusan Mengikut Fasa

| # | Fasa | Keputusan | Catatan |
|---|------|-----------|---------|
| 1 | Cipta rekod (N/P/K) | ✅ LULUS | 5 rekod dicipta; get serial-bertembung berfungsi (N…001 ditolak kerana sudah wujud dari run awal hari ini) |
| 2 | Cetakan | ✅ LULUS | Semua resit keluar — disahkan fizikal oleh Saifullah |
| 3 | Kemaskini rekod | ⚠️ LULUS (ragu) | Tindakan berjaya, tetapi bacaan-balik nombor mencurigakan — lihat §4.3 |
| 4 | Semak selaras | ✅ LULUS | 10/10 selaras |
| 5 | Semak H/TN | ✅ LULUS | — |
| 6 | Hantar akhir | ❌ GAGAL 5/5 | `TimeoutException` — bug navigasi dalam suite, bukan bug aplikasi; data sebenarnya telah naik ke server — lihat §4.1 |
| 7 | Semak D-09 | ❌ GAGAL | Bug aplikasi disahkan: identiti melekat merentas plat — lihat §4.2 |
| 8 | SK-001 | ⚠️ 9/26 | Liputan semakan belum penuh |
| 9 | Bookmark | ➖ TIDAK-DISOKONG | Fungsi tiada dalam build ini |
| 10 | NK | ➖ SKIP | Dilangkau mengikut konfigurasi run (`--borang NPK`) |

---

## 2. Rekod Dicipta / Disentuh Hari Ini (20/08/2026)

> **Disahkan silang** dengan ledger suite `reports\REKOD-SEBENAR.jsonl` dan
> `reports\REKOD-SEBENAR-DICIPTA-2026-08-20.md` (ground truth automasi).

Format nombor: `PGP02` + huruf borang (N=Notis, P=Kompaun borang P, K=Kompaun borang K) + `260820` + turutan.

### 2.1 DISAHKAN dalam ledger (8 nombor)

| Nombor | TC | Masa | Jenis tindakan | Rujukan |
|--------|----|------|----------------|---------|
| PGP02N260820001 | N-001 | 12:54:28 | Cipta (Notis) — run awal, punca BERTEMBUNG di get serial | — |
| PGP02N260820002 | N-001 | 15:50:27 | Cipta (Notis) | — |
| PGP02N260820003 | N-004 | 15:53:30 | Kemaskini — ganti N…002 | asal PGP02N260820002 |
| PGP02P260820001 | P-001 | 16:00:54 | Cipta (Kompaun P) | — |
| PGP02P260820002 | P-004 | 16:03:16 | Kemaskini — ganti P…001 | asal PGP02P260820001 |
| PGP02K260820003 | K-001 | 16:12:43 | Cipta (Kompaun K) | JYX6605 |
| PGP02K260820005 | K-001 | 16:25:26 | Cipta (Kompaun K) | JUA3276 |
| PGP02K260820007 | K-001 | 16:38:01 | Cipta (Kompaun K) | JRT2649 |

### 2.2 DIJANGKA WUJUD tetapi nombor tidak tertangkap (3 nombor)

Tiga kemaskini K-004 (16:15:55, 16:28:41, 16:41:18) berjaya, tetapi ledger merekodkan
ketiga-tiganya sebagai "→ PGP02P260820002" — mustahil, kerana kemaskini borang K patut
mengeluarkan nombor **K**, bukan P. Ini bacaan popup basi (lihat §4.3). Berdasarkan corak
kaunter K yang melompat 003→005→007, nombor sebenar dijangka:

| Nombor dijangka | Asal (rekod digantikan) |
|-----------------|-------------------------|
| PGP02K260820004 | PGP02K260820003 (JYX6605) |
| PGP02K260820006 | PGP02K260820005 (JUA3276) |
| PGP02K260820008 | PGP02K260820007 (JRT2649) |

**Jangkaan jumlah di portal untuk 20/08/2026: 11 rekod PGP02.**

⚠️ **Sebelum pembatalan:** tapis rekod `PGP02` bertarikh 20/08/2026 di portal dan sahkan
senarai muktamad di sana — terutama tiga nombor §2.2. Precedent 18/08 menunjukkan rekod
asal yang dikemaskini bertukar `statuskompaun=B` (batal automatik) dan gantian `=A`;
kedua-duanya tetap wujud pada production dan perlu dibersihkan oleh PM. Semua rekod ujian
bernama `UJIAN AUTOMASI E2E` dengan catatan `AUTOMASI-CLEANUP-PM`.

---

## 3. Metrik Run

- Rekod baharu dicipta: **5** (semua siap cetak + kemaskini)
- Semak selaras: **10/10**
- Hantar akhir: **0/5** selesai dalam suite (tetapi data disahkan naik — kegagalan hanya pada bacaan UI)
- SK-001: **9/26**

---

## 4. Kegagalan & Analisis

### 4.1 Hantar-akhir 5/5 `TimeoutException` — BUG SUITE (bukan aplikasi)

Kelima-lima cubaan hantar-akhir tamat masa. Punca: `open_hantar()` dipanggil semasa ListView **Senarai** masih terbuka, menghalang navigasi ke skrin hantar.

**Bukti data sebenarnya naik:** rekod kelihatan di server walaupun suite melaporkan gagal — kegagalan berlaku pada langkah pengesahan UI, bukan pada penghantaran.

**Pembaikan dicadangkan:** dalam `run_penuh.py` / helper navigasi, pastikan `open_hantar()` sentiasa **pulang ke skrin utama dahulu** (back/home) sebelum membuka menu hantar. Tambah guard: jika ListView Senarai dikesan, tekan Back sehingga skrin utama sebelum meneruskan.

### 4.2 Semak D-09 GAGAL — BUG APLIKASI DISAHKAN

Identiti yang sama (No. K/P berakhir **…05**) melekat pada **dua plat berbeza**: `JYX6605` dan `JUA3276`. Ini konsisten dengan defect **D-09** (identiti pemilik "sticking" merentas carian plat berturutan — kemungkinan cache/pembolehubah tidak dibersihkan antara carian mySIKAP).

**Status:** defect sebenar pada build 2.1.23. Perlu dilaporkan kepada pembangun aplikasi. Kompaun terhadap JUA3276 mungkin tercatat atas identiti pemilik yang salah — ini antara sebab pembatalan hari ini wajar.

### 4.3 Anomali bacaan-balik kemaskini — nombor sama ×3

Tiga kemaskini K-004 yang berbeza semuanya melaporkan hasil "→ **PGP02P260820002**" — nombor
yang sama dengan hasil kemaskini P-004 sebelumnya. Ledger `REKOD-SEBENAR.jsonl` mengesahkan
ketiga-tiga baris K-004 tercatat dengan nombor P ini.

**Diagnosis: hampir pasti bacaan popup basi (bug suite), bukan bug penomboran aplikasi** —
kemaskini borang K tidak mungkin mengeluarkan nombor berprefix P. Fungsi `cari_nombor_baharu`
menangkap nilai lama (precedent: baris 18/08 juga pernah gagal tangkap, catatan "nombor baharu
tidak tertangkap"). Kaunter K yang melompat 003→005→007 konsisten dengan nombor sebenar
K…004/006/008 dimakan oleh kemaskini.

**Pembaikan dicadangkan:** selepas kemaskini, tunggu dialog lama tertutup / sahkan prefix nombor
yang dibaca sepadan dengan borang semasa (K-004 mesti baca nombor `PGP02K…`); jika prefix salah,
baca semula atau backfill dari DB peranti seperti precedent 18/08. Sahkan nombor sebenar di portal.

### 4.4 Versi build TAKSA

Suite dikalibrasi untuk 2.1.20 tetapi peranti menjalankan **2.1.23**. Sebahagian keputusan (terutama bookmark TIDAK-DISOKONG dan liputan SK-001) mungkin dipengaruhi perubahan UI antara versi. Kemaskini oracle/locator ke 2.1.23 sebelum run penuh seterusnya.

---

## 5. Tindakan Susulan (mengikut keutamaan)

1. **[SEGERA] Batalkan rekod ujian hari ini** — sahkan senarai muktamad di portal (§2), kemudian batal semua rekod PGP02 bertarikh 20/08/2026.
2. **[BUG APP] Failkan D-09** dengan bukti JYX6605/JUA3276 (identiti …05) daripada run ini.
3. **[BUG SUITE] Baiki `open_hantar()`** — pulang ke skrin utama sebelum navigasi (§4.1), kemudian ulang fasa hantar-akhir sahaja.
4. **[SIASAT] Anomali PGP02P260820002 ×3** — asingkan punca ikut §4.3.
5. **[SELENGGARA] Kemaskini oracle suite** 2.1.20 → 2.1.23; lengkapkan liputan SK-001 (9/26 → 26/26).

---

*Laporan disusun 20/08/2026 daripada log `run_penuh.py --borang NPK --bersih` dan pengesahan cetakan oleh Saifullah. Padanan fail suite: letak bersebelahan `reports\REKOD-SEBENAR-DICIPTA-2026-08-20.md`.*

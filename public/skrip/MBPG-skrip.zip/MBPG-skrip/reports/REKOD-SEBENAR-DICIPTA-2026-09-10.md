# REKOD SEBENAR DICIPTA — production MBPG

> Setiap nombor di bawah ialah rekod **HIDUP** pada production MBPG
> (113.211.155.174). Ia dicipta oleh automasi ujian di bawah
> `MBPG_MOD_SEBENAR=1`, atas kelulusan pemilik 2026-08-17.
>
> **Untuk PM:** semua rekod ini data ujian. Nama pesalah bermula dengan
> `UJIAN AUTOMASI E2E`, dan medan catatan membawa `AUTOMASI-CLEANUP-PM`.
> Pembatalan melalui portal ePBT oleh pihak berautoriti — automasi
> TIDAK memadam apa-apa.
>
> Satu kitaran boleh menjana LEBIH DARIPADA SATU nombor (cipta -> NK
> convert -> kemaskini). Baris lama TIDAK dipadam apabila rekod
> digantikan: nombor itu tetap wujud pada production.

| No. rekod | TC | Borang | Masa | Jenis | Status | Asal |
|---|---|---|---|---|---|---|
| `PGP02N260910001` | N-001 | N | 2026-09-10 12:36:55 | Notis | baru | - |
| `PGP02N260910002` | N-004 | N | 2026-09-10 12:39:58 | Notis | hasil-kemaskini | PGP02N260910001 |
| `PGP02P260910001` | P-001 | P | 2026-09-10 12:47:21 | Kompaun | baru | - |
| `PGP02P260910002` | P-004 | P | 2026-09-10 12:49:42 | Kompaun | hasil-kemaskini | PGP02P260910001 |
| `PGP02K260910003` | K-001 | K | 2026-09-10 12:58:56 | Kompaun | baru | - |
| `PGP02P260910002` | K-004 | K | 2026-09-10 13:02:10 | Kompaun | hasil-kemaskini | PGP02K260910003 |
| `PGP02K260910005` | K-001 | K | 2026-09-10 13:11:31 | Kompaun | baru | - |
| `PGP02P260910002` | K-004 | K | 2026-09-10 13:14:45 | Kompaun | hasil-kemaskini | PGP02K260910005 |
| `PGP02K260910007` | K-001 | K | 2026-09-10 13:24:05 | Kompaun | baru | - |
| `PGP02P260910002` | K-004 | K | 2026-09-10 13:27:18 | Kompaun | hasil-kemaskini | PGP02K260910007 |
| `PGP02N260910003` | N-001 | N | 2026-09-10 14:22:11 | Notis | baru | - |
| `PGP02N260910004` | N-001 | N | 2026-09-10 15:19:59 | Notis | baru | - |
| `PGP02N260910005` | N-004 | N | 2026-09-10 15:23:06 | Notis | hasil-kemaskini | PGP02N260910004 |
| `PGP02P260910008` | P-001 | P | 2026-09-10 15:36:31 | Kompaun | baru | - |
| `PGP02P260910009` | P-004 | P | 2026-09-10 15:39:04 | Kompaun | hasil-kemaskini | PGP02P260910008 |
| `PGP02K260910010` | K-001 | K | 2026-09-10 15:54:38 | Kompaun | baru | - |
| `PGP02K260910011` | K-004 | K | 2026-09-10 15:58:04 | Kompaun | hasil-kemaskini | PGP02K260910010 |
| `PGP02K260910012` | K-001 | K | 2026-09-10 16:13:40 | Kompaun | baru | - |
| `PGP02K260910013` | K-004 | K | 2026-09-10 16:17:07 | Kompaun | hasil-kemaskini | PGP02K260910012 |
| `PGP02K260910014` | K-001 | K | 2026-09-10 16:32:41 | Kompaun | baru | - |
| `PGP02K260910015` | K-004 | K | 2026-09-10 16:36:09 | Kompaun | hasil-kemaskini | PGP02K260910014 |

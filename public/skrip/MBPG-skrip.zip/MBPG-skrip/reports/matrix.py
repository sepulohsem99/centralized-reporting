"""
Penulis MATRIX — satu baris CSV setiap set yang disapu.

Ditulis SECARA INKREMEN (dibuka, ditambah, ditutup setiap baris) dan
bukan sekali pada penghujung. Sebabnya: sweep 330 set pada peranti boleh
berjalan berjam-jam, dan kalau ia dibatalkan pada set ke-200 — oleh
DryRunViolation, bateri, kabel USB tercabut — bukti untuk 199 set
pertama mesti sudah berada di cakera. Kehilangan sejam kerja peranti
kerana penampan tidak disiram adalah kegagalan yang boleh dielakkan.
"""

import csv
import os
import time

AKAR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DIR_REPORTS = os.path.join(AKAR, "reports")


def laluan_matrix(tarikh=None):
    tarikh = tarikh or time.strftime("%Y%m%d")
    return os.path.join(DIR_REPORTS, f"MATRIX-{tarikh}.csv")


class Matrix:
    """Penambah CSV. Selamat dibuka semula dalam run yang sama: pengepala
    ditulis sekali sahaja, bergantung pada sama ada fail sudah wujud."""

    def __init__(self, laluan=None, pengepala=None):
        self.laluan = laluan or laluan_matrix()
        self.pengepala = pengepala
        os.makedirs(os.path.dirname(self.laluan), exist_ok=True)
        self.bil = 0

    def _pastikan_pengepala(self):
        if self.pengepala is None:
            return
        if os.path.exists(self.laluan) and os.path.getsize(self.laluan) > 0:
            return
        with open(self.laluan, "w", encoding="utf-8-sig", newline="") as fh:
            csv.writer(fh).writerow(self.pengepala)

    def tambah(self, baris):
        self._pastikan_pengepala()
        with open(self.laluan, "a", encoding="utf-8-sig", newline="") as fh:
            csv.writer(fh).writerow(baris)
            fh.flush()
            os.fsync(fh.fileno())
        self.bil += 1

    def ringkasan(self):
        return f"{self.bil} baris -> {self.laluan}"

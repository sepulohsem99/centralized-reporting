"""
Kandungan panduan pengguna MBJB — SATU sumber, dua output.

Panduan yang sama dirender ke:
  - tab "Panduan" dalam dashboard HTML (sentiasa ada bersama laporan)
  - PANDUAN.md di dalam zip (untuk dibaca selepas unzip, sebelum ada
    dashboard)

Disimpan sebagai data berstruktur (bukan dua string berasingan) supaya
kedua-dua output tak boleh terpesong antara satu sama lain bila panduan
dikemas kini.

GAYA
----
Pembaca sasaran mungkin tidak pernah sentuh Appium, dan akan membaca ini
sambil cuba menjalankan sesuatu. Jadi: diagram dahulu, arahan dalam
bingkai terminal yang kelihatan seperti apa yang mereka akan lihat pada
skrin, dan ayat sependek mungkin. Perenggan panjang tidak dibaca.

NOMBOR VERSI
------------
Panduan ini TIDAK menyebut versi build app di mana-mana ayat kekal.
Versi yang ditulis terus ke dalam teks menjadi usang secara senyap —
seorang pembaca enam bulan dari sekarang tidak ada cara untuk tahu bahawa
"2.1.33" itu bukan lagi apa yang ada pada telefon. Versi hanya muncul
dalam laporan, di mana ia dibaca dari device pada masa run. Satu-satunya
pengecualian ialah NAMA FAIL APK, kerana itu memang nama fail.

Blok yang disokong:
    ("flow",    [ (tajuk, [baris, ...]), ... ])  -> diagram alur berperingkat
    ("term",    (tajuk, [baris, ...]))           -> tetingkap terminal
    ("term",    (tajuk, [baris, ...], "file"))   -> kandungan fail (tiada prompt)
    ("shot",    (NAMA_DALAM_shots, alt, [sandaran teks]))
    ("output",  (tajuk, [baris, ...]))           -> output yang dijangka
    ("cards",   [(ikon, tajuk, huraian), ...])
    ("legend",  [(ikon, tona, label, huraian), ...])
    ("pairs",   [(kiri, kanan), ...])            -> jadual dua lajur
    ("p",       "perenggan pendek")
    ("steps",   ["langkah", ...])                -> senarai bernombor
    ("bullets", ["poin", ...])
    ("note",    "maklumat sampingan")
    ("warn",    "amaran penting")
"""

import html as _html

# ---------------------------------------------------------------------------
# Ikon
# ---------------------------------------------------------------------------
# SVG sebaris, bukan fail imej atau fon ikon: tiada permintaan rangkaian,
# tiada kebergantungan luar, dan ia mewarisi warna teks jadi ikut tema
# gelap/cerah dengan sendirinya. Semua 24x24, stroke sahaja.
_I = {
    "node":     "M12 2 20 7v10l-8 5-8-5V7z",
    "python":   "M8 6h5a3 3 0 0 1 3 3v3H8a3 3 0 0 0-3 3v3M16 18h-5a3 3 0 0 1-3-3",
    "android":  "M5 10v7a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-7zM8 10 6 6M16 10l2-4M9 15h.01M15 15h.01",
    "cube":     "M12 3 3 8v8l9 5 9-5V8zM3 8l9 5 9-5M12 13v8",
    "terminal": "M3 4h18v16H3zM7 9l3 3-3 3M13 15h4",
    "phone":    "M7 2h10v20H7zM11 18h2",
    "usb":      "M12 22V8M9 11 12 8l3 3M12 2v3M9 15H7a2 2 0 0 1-2-2V9M15 18h2a2 2 0 0 0 2-2V9",
    "lock":     "M6 11h12v10H6zM9 11V7a3 3 0 0 1 6 0v4",
    "play":     "M6 4l14 8-14 8z",
    "check":    "M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20M8 12l3 3 5-6",
    "cross":    "M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20M9 9l6 6M15 9l-6 6",
    "minus":    "M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20M8 12h8",
    "alert":    "M12 3 2 20h20zM12 9v5M12 17h.01",
    "file":     "M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8zM14 3v5h5",
    "users":    "M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8M2 21v-2a5 5 0 0 1 5-5h4a5 5 0 0 1 5 5v2M17 4a4 4 0 0 1 0 7M22 21v-2a5 5 0 0 0-3-4.5",
    "refresh":  "M21 12a9 9 0 1 1-3-6.7M21 4v5h-5",
    "eye":      "M2 12s4-7 10-7 10 7 10 7-4 7-10 7-10-7-10-7M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6",
    "plug":     "M9 2v6M15 2v6M6 8h12v3a6 6 0 0 1-12 0zM12 17v5",
    "stop":     "M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20M9 9h6v6H9z",
    "printer":  "M7 8V3h10v5M7 18H5a2 2 0 0 1-2-2v-4a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2h-2M7 14h10v7H7z",
    "bt":       "M8 7l8 10-4 4V3l4 4-8 10",
    "server":   "M3 4h18v6H3zM3 14h18v6H3zM7 7h.01M7 17h.01",
    "battery":  "M2 8h16v8H2zM20 11v2M6 11v2M10 11v2",
    "key":      "M15 7a4 4 0 1 1-3.9 5H8v3H5v-3H3v-3h8.1A4 4 0 0 1 15 7",
}


def _icon(name, cls="ic"):
    d = _I.get(name)
    if not d:
        return ""
    return (f'<svg class="{cls}" viewBox="0 0 24 24" fill="none" '
            f'stroke="currentColor" stroke-width="1.7" stroke-linecap="round" '
            f'stroke-linejoin="round" aria-hidden="true"><path d="{d}"/></svg>')


# IP staging MBJB. Disimpan sebagai pemalar supaya ia muncul dengan nilai
# yang SAMA di setiap tempat dalam panduan — satu tempat untuk ditukar
# kalau server berpindah.
IP_STAGING = "219.93.38.103:8880"
APK_NAME = "MBPG_2.1.33-Dev.apk"

# ---------------------------------------------------------------------------
# KREDENTIAL DITOPENG — keputusan pemilik (Loh, 2026-07-30)
# ---------------------------------------------------------------------------
# Panduan ini dirender ke DUA tempat, dan salah satunya ialah
# `public/index.html` — satu-satunya folder yang dihidangkan secara AWAM.
# Memaparkan kata laluan di situ ialah PENYIARAN, bukan dokumentasi.
#
# Yang ditopeng: kata laluan akaun, dan token lesen (ia token akses
# server). Yang KEKAL: nama pengguna, dan seluruh prosedur — tujuan
# panduan ialah LANGKAH, bukan mengedar kredential. Pembaca yang berhak
# sudah ada nilainya; pembaca yang tidak berhak tidak sepatutnya
# mendapatkannya daripada satu halaman web.
#
# `0000` (kata laluan pasangan printer) TIDAK ditopeng: itu kata laluan
# lalai perkakasan yang tercetak dalam manual Bixolon, bukan rahsia.
#
# Nilai penuh hidup di SATU tempat sahaja: `profiles/mbpg-staging.json`
# pada mesin pemilik. Folder itu juga dikecualikan daripada zip yang
# boleh dimuat turun (lihat `make_zip.py`).
KATA_LALUAN = "&lt;kata laluan &mdash; minta daripada pemilik&gt;"

# Sumber nilai sebenar, disebut setiap kali kredential ditopeng supaya
# pembaca tahu ke mana hendak pergi dan tidak mula meneka.
SUMBER_KREDENTIAL = ("Nilai sebenar ada dalam "
                     "<code>profiles\\mbpg-staging.json</code> pada mesin "
                     "pemilik &mdash; ia sengaja tiada dalam zip ini dan "
                     "tiada dalam halaman ini.")


def _topeng_token(tok):
    """Tunjukkan hujung token lesen sahaja: `8673…5982`.

    Cukup untuk seseorang MENGESAHKAN yang mana satu sedang digunakan,
    tidak cukup untuk menggunakannya. Token lesen ialah token akses ke
    server MBJB, jadi ia tidak muncul penuh pada halaman awam.
    """
    return f"{tok[:4]}…{tok[-4:]}" if len(tok) > 10 else "…"


LESEN_M50 = _topeng_token("867382031575982")
LESEN_M51 = _topeng_token("867382031575883")
LESEN_MBIP = _topeng_token("352405067769401")

GUIDE = [
    # Seksyen ini ada supaya panduan tidak berbunyi seperti sesuatu yang
    # sudah berjalan hujung ke hujung. Seksyen 1-10 di bawah ialah CARA
    # menjalankan suite; ia bukan bukti bahawa suite sudah dijalankan.
    # Tanpa seksyen ini, pembaca membaca sepuluh seksyen arahan yakin dan
    # menyimpulkan run penuh sudah berlaku. Belum.
    ("0. Keadaan sekarang — baca dahulu", [
        ("warn", "<b>TIADA RUN PENUH PERNAH BERLAKU.</b> Seksyen di bawah "
                 "ialah <b>cara</b> menjalankan suite, bukan rekod bahawa ia "
                 "sudah dijalankan. Setiap nombor dalam tab Laporan datang "
                 "dari <code>results.json</code>; kalau tiada run, tiada "
                 "nombor."),
        ("pairs", [
            ("Telefon <b>TERSAMBUNG</b>",
             "<code>adb devices</code> menyenaraikan peranti. Ulefone "
             "Armor 27, serial <code>5008TF2010009401</code>, Android 15. "
             "Catatan lama tentang telefon terputus dari USB sudah "
             "<b>BATAL</b> — itu gangguan sekali sahaja, sudah pulih."),
            ("Bootstrap Fasa 2 <b>SIAP</b>",
             "Tetapan Alamat IP, token lesen, log masuk, dan <b>6 daripada "
             "7</b> Selaras sudah disahkan pada telefon sebenar. Nilai "
             "sebenarnya ada dalam <code>reports/fasa2-bootstrap.md</code>."),
            ("T-008 Selaras Pelesen", "<b>BELUM</b> dijalankan. Dijangka "
             "lama (pada PBT lain ≈ 1 jam masa device)."),
            ("<b>Tiada satu rekod pun pernah dicipta</b>",
             "Jadi seluruh rantaian <b>by-number</b> — buka rekod ikut "
             "NOMBOR untuk Cetak / Lampiran / Kemaskini — <b>BELUM "
             "DIUJI SAMA SEKALI</b>. Itu 15 TC yang belum pernah menyentuh "
             "laluan sebenarnya."),
            ("<code>record_prefix</code> = <code>JB015</code>",
             "<b>Masih tekaan.</b> Ia hanya boleh disahkan pada rekod "
             "PERTAMA yang benar-benar dicipta. Kalau ia salah, setiap TC "
             "Cetak/Lampiran/Kemaskini akan <code>skip</code> — lihat "
             "seksyen 9."),
            ("Printer", "<b>DALAM SKOP PENUH.</b> Pemilik sudah balik dan "
             "printer ada bersamanya — catatan lama \"DITANGGUH\" sudah "
             "<b>BATAL</b>. Tetapi jujur: <b>sifar sambungan printer sebenar "
             "pernah berlaku, sifar cetakan pernah disahkan.</b> Lihat "
             "seksyen 4."),
        ]),
        ("note", "Semua yang di atas ialah keadaan, bukan kegagalan. Ia "
                 "dicatat di sini supaya tiada siapa membaca dashboard dan "
                 "menyangka lebih banyak sudah terbukti daripada yang "
                 "sebenarnya terbukti."),
    ]),

    ("Alur kerja", [
        ("flow", [
            ("1. Pasang", ["Node.js + Python", "adb + appium",
                           "driver uiautomator2", "pip install -r ..."]),
            ("2. Sedia telefon", ["USB debugging: ON", f"{APK_NAME}",
                                  "Auto-lock: OFF"]),
            ("3. Tetapan app", ["Tetapan Alamat IP", IP_STAGING,
                                "tekan SELARAS", "Log masuk"]),
            ("4. Printer", ["Hidupkan SPP-R410", "Ikon printer: hijau",
                            "Auto-off: 90 minit"]),
            ("5. Run", ["T1: appium", "T2: run_and_report",
                        "Pilih MBJB - staging", "Tunggu 2-3 jam"]),
            ("6. Baca hasil", ["Dashboard update", "Refresh browser"]),
        ]),
    ]),

    ("1. Pasang \u2014 sekali sahaja", [
        ("cards", [
            ("node",    "Node.js",     "nodejs.org \u2192 LTS"),
            ("python",  "Python 3.11+", "python.org \u2192 tanda "
                                        "<b>Add to PATH</b>"),
            ("android", "adb",         "platform-tools \u2192 tambah ke PATH"),
            ("cube",    "Appium",      "arahan di bawah"),
        ]),
        ("term", ("Command Prompt", [
            "npm install -g appium",
            "appium driver install uiautomator2",
            "pip install -r requirements.txt",
        ])),
        ("note", "Terlepas <b>Add Python to PATH</b>? Uninstall, install "
                 "semula."),
    ]),

    ("2. Sediakan telefon", [
        ("cards", [
            ("phone", "Developer options",
             "About phone \u2192 ketuk <b>Build number</b> 7 kali"),
            ("usb",   "USB debugging", "hidupkan dalam Developer options"),
            ("plug",  "Sambung USB",   "tekan <b>Allow</b> pada telefon"),
            ("lock",  "Auto-lock",     "matikan"),
        ]),
        ("p", f"APK MBJB: <code>{APK_NAME}</code>. Pasang pada telefon "
              "sebelum apa-apa yang lain."),
        ("warn", "<b>Lesen BUKAN IMEI telefon.</b> "
                 "<code>lesen_aplikasi</code> ialah <b>token</b> yang "
                 "didaftarkan di portal PBT, dan pengesahannya berlaku di "
                 "<b>server</b>. Ia tidak dibandingkan dengan IMEI telefon "
                 "di mana-mana. Jadi lesen yang tidak sama dengan IMEI "
                 "telefon itu <b>normal</b>, bukan masalah \u2014 jangan "
                 "buang masa mencari IMEI yang padan."),
        ("pairs", [
            ("Token dalam profil", f"<code>{LESEN_M50}</code> (label m50) "
                                   "&mdash; <b>DITERIMA</b> pada device, "
                                   "percubaan pertama"),
            ("Token simpanan", f"<code>{LESEN_M51}</code> (label m51) "
                               "&mdash; tidak perlu dicuba"),
            ("Bukti lesen \u2260 IMEI", f"Token MBIP <code>{LESEN_MBIP}</code> "
             "berjaya berpuluh run pada Ulefone Armor 27 yang IMEI-nya "
             "<code>357616400186856</code>. Nilai itu bukan IMEI device "
             "tersebut."),
            ("Token ditopeng di sini", SUMBER_KREDENTIAL + " Token lesen "
             "ialah token akses ke server MBJB, jadi hanya hujungnya "
             "ditunjukkan &mdash; cukup untuk mengesahkan yang mana satu "
             "sedang diguna, tidak cukup untuk mengguna."),
            ("<code>m50</code> / <code>m51</code>", "Label telefon di "
             "pejabat pemilik. BUKAN syarat padanan, bukan label PBT."),
        ]),
        ("note", "Kalau server <b>menolak</b> token: itu blocker luaran, "
                 "bukan bug automation. Minta admin daftarkan IMEI telefon "
                 "(<code>python device_utils.py --check</code> memaparkannya) "
                 "untuk MBJB staging di portal PBT. Jangan reka token baharu."),
        ("note", "Serial telefon tak perlu ditaip \u2014 suite cari sendiri."),
    ]),

    ("3. Tetapan Alamat IP + Selaras (WAJIB sebelum run pertama)", [
        ("p", "Server MBJB tidak ditetapkan di sebelah komputer. Ia "
              "dimasukkan <b>ke dalam app</b>, sekali, pada telefon. "
              "Ini juga apa yang <code>MBPG-TC-T-001</code> uji."),
        ("p", "Semua nilai di bawah <b>sudah dijalankan pada telefon</b> "
              "dan inilah yang app sebenarnya balas. Sumber: "
              "<code>reports/fasa2-bootstrap.md</code> seksyen 2.3."),
        ("steps", [
            "Buka app MBJB pada telefon.",
            "Ketuk ikon <b>hamburger</b> (tiga baris) di kanan atas. Menu "
            "ada <b>11 item</b>.",
            "Pilih <b>TETAPAN ALAMAT IP</b>.",
            f"Isi <b>KEDUA-DUA</b> medan &mdash; <b>INTERNAL</b> dan "
            f"<b>EXTERNAL</b> &mdash; dengan <code>{IP_STAGING}</code>. "
            "Bukan satu medan sahaja.",
            "Tekan <b>SIMPAN</b>. Buka modal itu semula dan sahkan nilai "
            "kekal &mdash; itulah Expected Result <code>T-001</code>.",
            "Balik ke menu, pilih <b>TETAPAN PELBAGAI</b>. Isi "
            "<b>LESEN APLIKASI:</b> dengan token dalam profil, tekan "
            "<b>SIMPAN</b>.",
            "Jalankan <b>7 item SELARAS</b> dalam menu, satu demi satu "
            "(jadual di bawah).",
            "Tunggu overlay <code>\u2026 SEDANG DIPROSES...</code> hilang sebelum "
            "tekan yang seterusnya.",
            f"Log masuk: <code>admin</code> / <code>{KATA_LALUAN}</code>.",
        ]),
        ("pairs", [
            ("Staging (sasaran run)", f"<code>{IP_STAGING}</code> pada "
                                      "<b>INTERNAL</b> dan <b>EXTERNAL</b>"),
            ("Alert selepas simpan lesen",
             "Tajuk <code>BEJAYA</code> &mdash; ejaan app, <b>tiada huruf "
             "R</b> &mdash; mesej <code>LESEN SAMA.</code> Itu tanda "
             "<b>diterima</b>. Kod yang mencari &ldquo;BERJAYA&rdquo; di sini "
             "tidak akan padan."),
            ("Akaun utama", f"<code>admin</code> / <code>{KATA_LALUAN}</code> "
                            "&mdash; berjaya pada percubaan pertama"),
            ("Akaun alternatif", "<code>peranti</code> &nbsp;|&nbsp; "
                                 "<code>msc</code> &mdash; tidak perlu dicuba "
                                 "selagi <code>admin</code> berjaya. Kata "
                                 "laluan kedua-duanya juga ditopeng."),
            ("Kata laluan ditopeng", SUMBER_KREDENTIAL + " Halaman ini "
             "dihidangkan secara awam, jadi ia memberi <b>langkah</b>, bukan "
             "kredential."),
        ]),
        ("warn", "<b>Selepas LOGIN, alert ini akan muncul:</b> tajuk "
                 "<code>Alert</code>, mesej "
                 "<code>Error: Unable to connect device</code>. "
                 "<b>Itu BUKAN login gagal.</b> Ia kegagalan menyambung "
                 "printer Bluetooth, dan ia akan muncul pada <b>setiap</b> "
                 "login selagi printer dimatikan. Tolak alert &mdash; skrin "
                 "utama sudah terpapar penuh di belakangnya."),
        ("p", "<b>7 Selaras &mdash; mesej sebenar app.</b> Guna teks ini "
              "kalau anda perlu menyemak sesuatu selaras betul-betul jadi. "
              "Jangan reka mesej sendiri:"),
        ("pairs", [
            ("<code>T-003</code> SELARAS PENGGUNA APPS",
             "<code>BERJAYA</code> / <code>DATA PENGGUNA BERJAYA "
             "DISIMPAN!</code> &nbsp;&mdash;&nbsp; &lt;20s"),
            ("<code>T-004</code> SELARAS MAKLUMAT ALAMAT",
             "<code>BERJAYA</code> / <code>DATA ALAMAT BERJAYA "
             "DISIMPAN!</code> &nbsp;&mdash;&nbsp; ~37s. Selaras ini yang "
             "mengisi senarai Nama Jalan untuk typeahead"),
            ("<code>T-005</code> SELARAS MAKLUMAT KOMPAUN",
             "<code>BERJAYA</code> / <code>DATA KOMPAUN BERJAYA "
             "DISIMPAN!</code> &nbsp;&mdash;&nbsp; 7s. Ini yang mengisi "
             "dropdown KOD KOMPAUN / AKTA / KESALAHAN"),
            ("<code>T-006</code> SELARAS MAKLUMAT JENIS KENDERAAN",
             "<code>BERJAYA</code> / <code>DATA JENIS KENDERAAN SAVED "
             "SUCCESSFULLY!</code> &nbsp;&mdash;&nbsp; 7s. Mesej ini dalam "
             "<b>Bahasa Inggeris</b> sedangkan enam yang lain Melayu &mdash; "
             "ketidakkonsistenan app, bukan ralat kita"),
            ("<code>T-007</code> SELARAS MAKLUMAT WARNA",
             "<code>BERJAYA</code> / <code>DATA MAKLUMAT WARNA BERJAYA "
             "DISIMPAN!</code> &nbsp;&mdash;&nbsp; 7s"),
            ("<code>T-008</code> SELARAS MAKLUMAT PELESEN",
             "<b>BELUM PERNAH DIJALANKAN.</b> Dijangka lama &mdash; pada PBT "
             "lain selaras ini menyimpan ~52,000 rekod, kira-kira <b>1 jam "
             "masa telefon</b>. Mesejnya belum diketahui, jadi tiada mesej "
             "ditulis di sini"),
            ("<code>T-009</code> SELARAS MAKLUMAT BARANG SITA",
             "<code>BERJAYA</code> / <code>DATA MAKLUMAT BARANG SITAAN "
             "BERJAYA DISIMPAN!</code> &nbsp;&mdash;&nbsp; 7s"),
        ]),
        ("note", "Enam daripada tujuh sudah <b>LULUS</b> pada telefon dengan "
                 "mesej di atas. Yang ketujuh (<code>T-008</code> Pelesen) "
                 "belum dicuba, jadi tiada apa-apa didakwa tentangnya."),
        ("warn", "<b>JANGAN masukkan alamat production</b> "
                 "(<code>epbt.mbjb.gov.my</code>). Setiap TC Daftar mencipta "
                 "rekod notis/kompaun/sitaan SEBENAR dalam pangkalan data "
                 "majlis, atas nama pesalah yang direka, dan rekod itu tidak "
                 "boleh dipadam dari app. Alamat itu direkod dalam "
                 "<code>profiles/mbpg-production.json</code> sebagai fakta "
                 "sahaja \u2014 profil itu sengaja tidak lengkap dan akan "
                 "ditolak."),
        ("note", "Excel V2.1.33 sel C5/C9 menulis "
                 "<code>epbt.mbjb.gov.my</code> kerana run manual Februari "
                 "2026 dibuat atas production. <b>Jangan ikut C5/C9.</b> "
                 "Penyimpangan ini didaftarkan dalam "
                 "<code>testdata/overrides.py</code>."),
    ]),

    ("4. Printer Bixolon SPP-R410", [
        ("warn", "<b>PRINTER DALAM SKOP PENUH</b> &mdash; catatan lama "
                 "\"DITANGGUH, tiada perkakasan sehingga pemilik balik\" "
                 "sudah <b>BATAL</b>. Pemilik sudah balik dan printer ada "
                 "bersamanya. <code>SPP-R410_110095</code> / "
                 "<code>74:F0:7D:A9:88:75</code> ter-bond pada telefon "
                 "(disahkan dua kali), dan "
                 "<code>com.bixolon.bixolonutilities</code> sudah dipasang. "
                 "<b>Satu-satunya kerja tangan manusia:</b> tekan butang "
                 "kuasa printer, dan pemilik akan menekannya apabila "
                 "diminta secara eksplisit."),
        ("warn", "<b>Jujur tentang keadaan sebenar:</b> <b>sifar sambungan "
                 "printer sebenar pernah berlaku, sifar cetakan pernah "
                 "disahkan.</b> Perkakasan ada dan ter-bond, tetapi laluan "
                 "sambung-dan-cetak belum pernah dilalui hujung ke hujung "
                 "pada device ini. Semua locator printer masih bertanda "
                 "<code># SAHKAN-DEVICE</code> dalam kod."),
        ("p", "Lima TC Cetak (<code>N-002 P-002 K-002 L-002 S-002</code>) "
              "memerlukan printer hidup dan bersambung. Ini "
              "<b>satu-satunya kerja tangan manusia</b> dalam keseluruhan "
              "run: tekan butang kuasa printer."),
        ("note", "Kelima-lima TC Cetak <b>kekal dalam suite dan tetap "
                 "dicuba</b>. Tanpa printer ia akan gagal atau skip secara "
                 "semula jadi, dan itu jujur. Tiada skip khas ditulis untuk "
                 "menyembunyikannya."),
        ("note", "Ikon printer ialah glif kawasan guna peribadi (PUA) "
                 "<code>U+F042A</code> pada satah 15. Ia <b>MEMANG</b> ada "
                 "dalam <code>uiautomator dump</code>, tetapi bukan sebagai "
                 "aksara literal — ia ditulis sebagai entiti angka "
                 "<code>&amp;#984106;</code>, jadi grep aksara literal "
                 "<b>TIDAK</b> jumpa. <code>xml.etree.ElementTree</code> "
                 "menghuraikannya dengan betul. Petua umum: glif BMP "
                 "(cth <code>U+E866</code> ikon buku, <code>U+F0C9</code> "
                 "hamburger) ditulis literal dan grep jumpa; glif satah 15 "
                 "(cth ikon printer ini) tidak. <b>Hurai XML, jangan grep "
                 "aksara literal</b> — tiada sesi Appium diperlukan untuk "
                 "cari ikon dengan cara ini, jimat masa device."),
        ("note", "Warna ikon (<span class='fail'>merah</span> / "
                 "<span class='pass'>hijau</span>) <b>TIDAK ADA</b> dalam "
                 "XML — <code>resource-id='icon-button'</code>, tiada "
                 "<code>content-desc</code>. Pengesanan status sambungan "
                 "mesti guna piksel skrin atau isyarat tidak langsung "
                 "(cth kehadiran teks <code>Disconnect</code> dalam popup), "
                 "bukan atribut elemen."),
        ("cards", [
            ("battery", "Cas dahulu",
             "Printer mati separuh jalan = 5 TC jadi SKIPPED"),
            ("bt", "Awalan <b>SPP</b>",
             "BUKAN 'SPR'. Nombor selepas itu berbeza setiap unit \u2014 "
             "jangan cari ID penuh, cari awalan"),
            ("key", "Kata laluan <b>0000</b>",
             "Empat sifar, pada dialog pasangan Bluetooth"),
            ("printer", "Ikon atas skrin utama",
             "<span class='fail'>Merah</span> = tak sambung, "
             "<span class='pass'>hijau</span> = sambung"),
        ]),
        ("steps", [
            "Hidupkan printer (butang kuasa).",
            "Pada skrin utama app, ketuk <b>ikon printer</b> di bahagian "
            "atas.",
            "Senarai peranti Bluetooth keluar. Pilih peranti bermula "
            "<code>SPP</code>.",
            "Tekan <b>Connect</b>.",
            "Kata laluan pasangan: <code>0000</code> &rarr; <b>OK</b>.",
            "Ikon bertukar <span class='pass'>hijau</span>. Baru boleh run.",
            "Buka <b>BIXOLON Utility</b> dan set auto-off ke <b>90 minit</b> "
            "\u2014 nilai MAKSIMUM yang dialog benarkan \u2014 <b>sebelum</b> "
            "mulakan run penuh.",
        ]),
        ("cards", [
            ("stop", "Auto-off: set 90 minit dahulu",
             "<b>90 minit ialah had MAKSIMUM</b> dialog. Set 90 sebelum run "
             "penuh. Run penuh masih lebih lama daripada itu \u2014 "
             "jangkakan printer tidur sekurang-kurangnya sekali"),
            ("android", "BIXOLON Utility",
             "Pasang dari <b>Play Store</b>. Di situlah tetapan auto-off "
             "dan ujian cetak sendiri berada"),
            ("alert", "COMMAND_NOT_SEND",
             "Alert ini bermakna <b>TIDAK tercetak</b>. Tiada alert + popup "
             "tutup sendiri = tercetak"),
            ("refresh", "Printer tidur masa run",
             "Test akan berhenti dan menunggu. Hidupkan semula printer, "
             "test sambung sendiri"),
        ]),
        ("warn", "TC Cetak yang <b>SKIPPED</b> bermakna tiada siapa sempat "
                 "menghidupkan printer dalam tempoh menunggu. Itu keadaan "
                 "persekitaran, bukan kecacatan aplikasi \u2014 sebab itu ia "
                 "tidak dilaporkan sebagai FAILED."),
    ]),

    ("5. Setiap kali nak run", [
        ("warn", "<b>TELEFON TIDAK BOLEH TIDUR.</b> Bila skrin telefon mati, "
                 "<code>uiautomator dump</code> memulangkan "
                 "<code>NotificationShade</code> dan tangkapan skrin menjadi "
                 "hitam. Dalam log ia kelihatan <b>persis kegagalan "
                 "locator</b> &mdash; puluhan TC gagal atas sebab yang "
                 "nampak salah sepenuhnya. Jalankan arahan di bawah dahulu, "
                 "dan jangan biarkan laptop atau telefon dikunci."),
        ("term", ("Sebelum apa-apa \u2014 halang telefon tidur", [
            "adb shell svc power stayon usb",
        ])),
        ("warn", "Run mesti <b>FOREGROUND</b>: tetingkap terminal kekal "
                 "terbuka dan kelihatan, laptop tidak dikunci, tiada sleep. "
                 "Run penuh mengambil <b>90&ndash;120 minit</b>. Jangan "
                 "tinggalkan ia berjalan sendiri di belakang."),
        ("term", ("Terminal 1 \u2014 biar terbuka", ["appium"])),
        ("shot", ("APPIUM_RUNNING", "Beginilah rupanya bila Appium jalan",
                  ["PS C:\\Users\\anda> appium",
                   "[Appium] Welcome to Appium v3.5.2",
                   "[Appium] AndroidUiautomator2Driver loaded in 6.150s",
                   "[Appium] listener started on http://0.0.0.0:4723"])),
        ("note", "Kursor berkelip, prompt tak kembali \u2014 itu betul. "
                 "<b>Jangan tutup tetingkap ni.</b>"),
        ("term", ("Terminal 2 \u2014 jalankan test", [
            "cd C:\\Users\\mrsai\\Documents\\antigravity\\keen-lovelace\\mbjb-testing",
            "tests\\run_and_report.bat",
        ])),
        ("term", ("Menu profil akan keluar", [
            "1. MBJB - staging          <- pilih ini",
            "2. MBJB - production       <- tersekat, sengaja",
            "",
            "Masukkan nombor pilihan: _",
        ])),
        ("warn", "Pastikan APK pada telefon betul-betul MBJB "
                 f"(<code>{APK_NAME}</code>), bukan APK PBT lain. Package "
                 "name semua PBT adalah SAMA "
                 "(<code>com.anonymous.react_ies_v1</code>), jadi suite tak "
                 "boleh semak ini untuk anda."),
    ]),

    ("6. Baca hasil", [
        ("legend", [
            ("check", "pass", "PASSED",  "Lulus. Tiada tindakan."),
            ("cross", "fail", "FAILED",  "Gagal. Baca lajur Nota."),
            ("minus", "skip", "SKIPPED", "Sengaja dilangkau, atau show "
                                         "stopper dari TC lain."),
            ("alert", "warn", "ERROR",   "Tak sempat jalan. Rerun."),
        ]),
        ("cards", [
            ("eye",     "Laporan",  "<code>reports\\mbjb_report.html</code>"),
            ("refresh", "Dah buka?", "Refresh sahaja"),
            ("file",    "Log penuh", "<code>reports\\last_run.txt</code>"),
            ("server",  "Versi Excel per run",
             "<code>reports\\run_&lt;profil&gt;_&lt;masa&gt;.xlsx</code>"),
        ]),
        ("p", "Lajur <b>Nombor rekod dicipta</b> dalam Excel per-run ialah "
              "titik masuk ke pangkalan data: nombor MBJB berbentuk "
              "<code>JB015N260227001</code>. Tanpa nombor itu, "
              "\u201crekod yang mana?\u201d tidak boleh dijawab."),
    ]),

    ("7. Kenapa SEBAHAGIAN medan bertulis \u201cblank dari test script\u201d", [
        ("p", "<b>DIKEMAS KINI 2026-08-04: oracle telah DIBETULKAN.</b> 12 sheet kini membawa data ujian sebenar, jadi kebanyakan medan yang dahulu berpenanda kini membawa nilai betul, dan kertas cetak akan menunjukkan <b>nama orang sebenar</b> (DIJANGKA, bukan tanda rekod lama). Keadaan ASAL: workbook MBJB V2.1.33 <b>tidak membekalkan data borang</b>. "
              "25 daripada 54 sel Test Data hanya menulis \u201cRefer to No "
              "Kompaun JB015\u2026\u201d \u2014 itu OUTPUT run manual "
              "Februari 2026, bukan input."),
        ("p", "Peraturan suite ini: <b>jangan reka nilai data</b>. Jadi "
              "setiap medan yang Excel senyap tidak dibiar kosong, tetapi "
              "<b>diisi penanda</b>:"),
        ("pairs", [
            ("Medan teks", "<code>blank dari test script</code>"),
            ("Medan berangka / IC", "<code>990323112289</code>"),
        ]),
        ("p", "Penanda itu keluar <b>pada kertas cetak</b>. Sesiapa yang "
              "memegang cetakan nampak terus nilai itu tiada asas dalam "
              "Excel. Cetakan yang penuh penanda ialah <b>hasil yang "
              "betul</b>, bukan bug."),
        ("note", "Medan yang mustahil menerima penanda (dropdown, "
                 "autocomplete terikat DB, medan berangka yang menapis "
                 "huruf) tidak diisi langsung \u2014 TC itu "
                 "<code>pytest.skip</code> dengan sebab. SKIP jujur lebih "
                 "baik daripada PASS palsu."),
        ("warn", "Kalau anda mahu nilai sebenar dalam rekod MBJB, nilai itu "
                 "mesti datang dari pemilik dan dimasukkan ke "
                 "<code>testdata/overrides.py</code> \u2014 bukan ditulis "
                 "sendiri oleh sesiapa yang menjalankan test."),
    ]),

    ("8. Masalah biasa", [
        ("pairs", [
            ("Alert <code>Error: Unable to connect device</code> "
             "selepas LOGIN",
             "<b>Ini BUKAN login gagal.</b> Ia kegagalan menyambung printer "
             "Bluetooth, dan ia akan muncul pada <b>setiap</b> login selagi "
             "printer dimatikan. Tolak alert &mdash; skrin utama sudah ada "
             "di belakangnya."),
            ("Log masuk gagal betul-betul",
             "Server menolak <b>token lesen</b> (bukan IMEI &mdash; lihat "
             "seksyen 2). Semak <code>lesen_aplikasi</code> dalam profil, "
             "kemudian minta admin daftarkan IMEI telefon di portal PBT. "
             "<code>python device_utils.py --check</code> memaparkan IMEI."),
            ("Semua TC Cetak/Serah/Kemaskini SKIP",
             "Nombor rekod tak terbaca. Semak <code>record_prefix</code> "
             "dalam profil \u2014 MBJB guna <code>JB015</code>, bukan "
             "awalan PBT lain."),
            ("Tiada device", "Periksa kabel. <code>adb devices</code>."),
            ("<code>unauthorized</code>", "Tengok skrin telefon \u2014 "
                                          "tekan Allow."),
            ("Appium tak hidup", "Terlupa Terminal 1."),
            ("Banyak ERROR serentak", "UiAutomator2 crash. Restart appium, "
                                      "rerun."),
            ("Lebih satu device", "<code>set MBPG_UDID=&lt;serial&gt;</code>"),
            ("Ikon printer kekal merah", "Printer mati, atau sudah "
                                         "berpasangan dengan telefon lain. "
                                         "Putuskan di telefon itu dahulu."),
            ("Ralat \u201cTidak Dapat Menyimpan Data\u201d",
             "Punca pertama yang disemak: running no. rekod sudah cecah "
             "had 999 di server. Bukan bug automation."),
        ]),
    ]),

    ("9. Tambah PBT / environment baharu", [
        ("p", "Satu fail JSON dalam <code>profiles/</code>. Salin yang "
              "sedia ada, tukar nilai. Tiada kod diubah."),
        ("term", ("profiles/mbpg-staging.json (ringkas)", [
            '{',
            '  "pbt": "MBJB",',
            '  "env": "staging",',
            '  "app_package": "com.anonymous.react_ies_v1",',
            '  "app_activity": ".MainActivity",',
            f'  "internal_ip": "{IP_STAGING}",',
            f'  "external_ip": "{IP_STAGING}",',
            '  "lesen_aplikasi": "ISI-SINI",',
            '  "username": "admin",',
            '  "password": "ISI-SINI",',
            '  "record_prefix": "JB015"',
            '}',
        ], "file")),
        # Templat ini SENGAJA menunjukkan `ISI-SINI` untuk token lesen dan
        # kata laluan. Menulis nilai sebenar di sini bermakna menyiarkannya
        # pada halaman awam DAN meletakkannya semula ke dalam zip melalui
        # PANDUAN.md \u2014 tepat kebocoran yang baru ditutup.
        ("warn", "<code>lesen_aplikasi</code> dan <code>password</code> di "
                 "atas ditunjukkan sebagai <code>ISI-SINI</code> dengan "
                 "sengaja. " + SUMBER_KREDENTIAL + " Mintanya daripada "
                 "pemilik; jangan teka dan jangan salin daripada dokumentasi "
                 "lama."),
        ("note", "Medan <code>ISI-SINI</code> ditolak sebelum ujian bermula "
                 "\u2014 gagal dalam 2 saat, bukan 2 jam."),
        ("warn", "<code>record_prefix</code> BELUM DISAHKAN pada staging. "
                 "<code>JB015</code> diperhatikan dalam run production "
                 "Februari 2026. Rekod pertama yang dicipta di device mesti "
                 "disemak, dan nilai ini dibetulkan kalau berbeza."),
    ]),

    ("10. Peraturan", [
        ("cards", [
            ("users", "Seorang sahaja run",
             "Data test sama, server sama. Dua orang serentak = rekod "
             "bertindih."),
            ("file",  "Jangan edit <code>.py</code>", "Semua automatik."),
            ("phone", "Jangan guna telefon", "Semasa test berjalan."),
            ("stop",  "Nak berhenti", "<code>Ctrl+C</code> dalam Terminal 2."),
            ("alert", "Jangan longgarkan assert",
             "Test yang gagal ialah <b>penemuan</b>, bukan gangguan."),
            ("lock",  "Status Excel bukan oracle",
             "Lajur Pass/Fail dalam workbook ialah rekod run manual lama."),
        ]),
    ]),
]


# ---------------------------------------------------------------------------
# Renderers
# ---------------------------------------------------------------------------

def _md(text):
    """Tukar HTML inline ringkas kepada padanan Markdown."""
    out = (text.replace("<b>", "**").replace("</b>", "**")
               .replace("<code>", "`").replace("</code>", "`")
               .replace("&rarr;", "->").replace("&times;", "x")
               .replace("&nbsp;", " ")
               # Entiti sengaja dinyahkod: kalau tidak, "&mdash;" akan
               # muncul sebagai teks mentah dalam PANDUAN.md dan pembaca
               # nampak entiti HTML dalam fail Markdown.
               .replace("&mdash;", "—").replace("&ndash;", "–")
               .replace("&ldquo;", "“").replace("&rdquo;", "”")
               .replace("&lt;", "<").replace("&gt;", ">")
               .replace("&amp;", "&"))
    # Span berwarna hanya bermakna dalam HTML — buang tag, kekalkan teks.
    for tag in ("<span class='fail'>", "<span class='pass'>",
                "<span class='skip'>", "<span class='warn'>", "</span>"):
        out = out.replace(tag, "")
    return out


def _flow_svg(stages):
    """Diagram alur sebagai SVG sebenar, dijana dari data `stages`.

    SVG dan bukan kotak HTML: bentuk ini perlukan anak panah, tetingkap
    terminal bertindih, dan penjajaran yang tetap — semuanya menyusahkan
    dengan div, dan mudah dengan koordinat.

    Warna melalui pembolehubah CSS supaya diagram ikut tema, dan viewBox
    membolehkannya mengecil pada skrin sempit tanpa teks jadi kabur.
    """
    W, H = 216, 150          # saiz satu kotak
    GAP = 46                 # ruang untuk anak panah
    total_w = len(stages) * W + (len(stages) - 1) * GAP
    total_h = H + 16

    p = [f'<svg class="flow-svg" viewBox="0 0 {total_w} {total_h}" '
         f'role="img" aria-label="Alur kerja menjalankan test" '
         f'xmlns="http://www.w3.org/2000/svg">']

    # Kepala anak panah dikongsi oleh semua sambungan.
    p.append('<defs><marker id="ah" viewBox="0 0 10 10" refX="9" refY="5" '
             'markerWidth="6" markerHeight="6" orient="auto">'
             '<path d="M0,0 L10,5 L0,10 z" fill="var(--muted)"/></marker></defs>')

    for i, (title, lines) in enumerate(stages):
        x = i * (W + GAP)
        y = 8

        # Badan kotak, dengan bar tajuk gaya tetingkap terminal.
        p.append(f'<rect x="{x}" y="{y}" width="{W}" height="{H}" rx="10" '
                 f'fill="var(--card)" stroke="var(--line)"/>')
        p.append(f'<path d="M{x},{y+28} h{W}" stroke="var(--line)"/>')
        for j, col in enumerate(("#ff5f56", "#ffbd2e", "#27c93f")):
            p.append(f'<circle cx="{x+16+j*13}" cy="{y+14}" r="4" fill="{col}"/>')
        p.append(f'<text x="{x+60}" y="{y+18}" font-size="11.5" '
                 f'font-weight="700" fill="var(--accent)" '
                 f'font-family="Consolas,monospace">'
                 f'{_html.escape(title)}</text>')

        for j, line in enumerate(lines):
            p.append(f'<text x="{x+16}" y="{y+52+j*21}" font-size="11.5" '
                     f'fill="var(--muted)" font-family="Consolas,monospace">'
                     f'{_html.escape(line)}</text>')

        if i < len(stages) - 1:
            x1, x2 = x + W + 9, x + W + GAP - 9
            p.append(f'<line x1="{x1}" y1="{y+H/2}" x2="{x2}" y2="{y+H/2}" '
                     f'stroke="var(--muted)" stroke-width="1.6" '
                     f'marker-end="url(#ah)"/>')

    p.append("</svg>")
    return "".join(p)


def guide_html():
    out = []
    for title, blocks in GUIDE:
        out.append(f'<h2 class="g-h">{_html.escape(title)}</h2>')
        for kind, body in blocks:

            if kind == "flow":
                out.append(_flow_svg(body))

            elif kind == "term":
                t, lines = body[0], body[1]
                is_file = len(body) > 2 and body[2] == "file"
                rows = []
                for l in lines:
                    if not l:
                        rows.append('<div class="t-line">&nbsp;</div>')
                    else:
                        rows.append(f'<div class="t-line">'
                                    f'{_html.escape(l)}</div>')
                copyable = "\n".join(l for l in lines if l)
                out.append(
                    f'<div class="term{" is-file" if is_file else ""}">'
                    '<div class="t-bar"><span class="t-dot d1"></span>'
                    '<span class="t-dot d2"></span><span class="t-dot d3"></span>'
                    f'<span class="t-name">{_html.escape(t)}</span>'
                    f'<button class="g-copy" data-copy="'
                    f'{_html.escape(copyable)}">Salin</button></div>'
                    f'<div class="t-body">{"".join(rows)}</div></div>'
                )

            elif kind == "shot":
                # Tangkap skrin dibenamkan sebagai data URI. Diimport
                # secara lembut: kalau shots.py hilang, panduan tetap
                # dirender tanpa gambar dan bukan meletup.
                name, alt, _fallback = body
                try:
                    import shots
                    src = getattr(shots, name)
                except Exception:                       # noqa: BLE001
                    src = None
                if src:
                    out.append(
                        f'<figure class="shot"><img src="{src}" '
                        f'alt="{_html.escape(alt)}" loading="lazy">'
                        f'<figcaption>{_html.escape(alt)}</figcaption></figure>'
                    )

            elif kind == "output":
                # Output yang DIJANGKA, bukan arahan: tiada prompt di
                # setiap baris dan tiada butang Salin — ini bukan sesuatu
                # yang patut ditaip atau disalin, cuma dibandingkan
                # dengan apa yang keluar di skrin.
                t, lines = body
                rows = []
                for l in lines:
                    cls = "o-line"
                    if l.startswith("[Appium]"):
                        cls += " o-tag"
                    elif l.startswith("PS ") or l.startswith("C:"):
                        cls += " o-prompt"
                    rows.append(f'<div class="{cls}">'
                                f'{_html.escape(l) or "&nbsp;"}</div>')
                out.append(
                    '<div class="term is-file is-output">'
                    '<div class="t-bar"><span class="t-dot d1"></span>'
                    '<span class="t-dot d2"></span><span class="t-dot d3"></span>'
                    f'<span class="t-name">{_html.escape(t)}</span>'
                    '<span class="t-live">berjalan</span></div>'
                    f'<div class="t-body">{"".join(rows)}'
                    '<div class="o-caret">_</div></div></div>'
                )

            elif kind == "cards":
                items = "".join(
                    f'<div class="gcard">{_icon(ic)}'
                    f'<div class="gc-t">{t}</div>'
                    f'<div class="gc-d">{d}</div></div>'
                    for ic, t, d in body)
                out.append(f'<div class="gcards">{items}</div>')

            elif kind == "legend":
                items = "".join(
                    f'<div class="lg-row"><span class="lg-ic {tone}">'
                    f'{_icon(ic)}</span>'
                    f'<span class="lg-t {tone}">{_html.escape(label)}</span>'
                    f'<span class="lg-d">{desc}</span></div>'
                    for ic, tone, label, desc in body)
                out.append(f'<div class="legend">{items}</div>')

            elif kind == "pairs":
                items = "".join(
                    f'<div class="pr-k">{_icon("alert", "ic sm")} {k}</div>'
                    f'<div class="pr-v">{v}</div>'
                    for k, v in body)
                out.append(f'<div class="pairs">{items}</div>')

            elif kind == "p":
                out.append(f'<p class="g-p">{body}</p>')
            elif kind == "steps":
                out.append('<ol class="g-list">'
                           + "".join(f"<li>{b}</li>" for b in body) + '</ol>')
            elif kind == "bullets":
                out.append('<ul class="g-list">'
                           + "".join(f"<li>{b}</li>" for b in body) + '</ul>')
            elif kind == "note":
                out.append(f'<div class="g-note">{body}</div>')
            elif kind == "warn":
                out.append(f'<div class="g-warn">{body}</div>')
    return "\n".join(out)


def _cell(text):
    """Sel jadual Markdown: `|` mesti dilepaskan.

    Tanpa ini, satu `|` di dalam teks memecahkan baris kepada lajur
    tambahan dan jadual terpapar rosak — berlaku pada baris "Akaun
    alternatif" yang memisahkan dua akaun dengan `|`.
    """
    return _md(text).replace("|", "\\|")


def guide_markdown():
    out = ["# MBJB — Panduan Menjalankan Test Automation", ""]
    for title, blocks in GUIDE:
        out += [f"## {title}", ""]
        for kind, body in blocks:

            if kind == "flow":
                # Diagram dilukis sebagai ASCII supaya bermakna dalam fail
                # teks biasa, bukan sekadar senarai tanpa struktur.
                # Lebar dalaman dikira SEKALI untuk semua peringkat supaya
                # kotak sejajar menegak. Setiap baris mesti menyumbang
                # tepat `w` aksara antara kedua-dua '|', jika tidak
                # sempadan kanan akan bergerigi.
                w = max(max([len(t)] + [len(l) for l in ls])
                        for t, ls in body) + 6
                bar = "+" + "-" * w + "+"
                out.append("```")
                for i, (t, lines) in enumerate(body):
                    out.append(bar)
                    out.append("| " + t.ljust(w - 2) + " |")
                    out.append("|" + " " * w + "|")
                    for l in lines:
                        out.append("|   " + l.ljust(w - 4) + " |")
                    out.append(bar)
                    if i < len(body) - 1:
                        out.append("      |")
                        out.append("      v")
                out += ["```", ""]

            elif kind == "shot":
                # Markdown tidak boleh membawa imej terbenam, jadi guna
                # sandaran teks yang disimpan bersama blok itu.
                _n, alt, fallback = body
                out += [f"**{alt}**", "", "```"] + list(fallback) + ["```", ""]

            elif kind in ("term", "output"):
                t, lines = body[0], body[1]
                lang = "json" if (len(body) > 2 and body[2] == "file") else ""
                out += [f"**{t}**", "", "```" + lang] + list(lines) + ["```", ""]

            elif kind == "cards":
                # Ikon tiada makna dalam teks biasa — tinggalkan tajuk
                # dan huraian sahaja.
                for _ic, t, d in body:
                    out.append(f"- **{_md(t)}** — {_md(d)}")
                out.append("")

            elif kind == "legend":
                out += ["| | |", "|---|---|"]
                for _ic, _tone, label, desc in body:
                    out.append(f"| **{label}** | {_cell(desc)} |")
                out.append("")

            elif kind == "pairs":
                out.append("| | |")
                out.append("|---|---|")
                for k, v in body:
                    out.append(f"| {_cell(k)} | {_cell(v)} |")
                out.append("")

            elif kind == "p":
                out += [_md(body), ""]
            elif kind == "steps":
                out += [f"{i}. {_md(b)}" for i, b in enumerate(body, 1)] + [""]
            elif kind == "bullets":
                out += [f"- {_md(b)}" for b in body] + [""]
            elif kind == "note":
                out += [f"> **Nota:** {_md(body)}", ""]
            elif kind == "warn":
                out += [f"> ⚠️ {_md(body)}", ""]
    return "\n".join(out).rstrip() + "\n"


if __name__ == "__main__":
    print(guide_markdown())

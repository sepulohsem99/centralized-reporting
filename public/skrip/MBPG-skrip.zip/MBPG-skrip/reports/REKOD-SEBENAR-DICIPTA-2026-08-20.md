# REKOD SEBENAR DICIPTA — production MBPG

> Setiap nombor di bawah ialah rekod **HIDUP** pada production MBPG
> (113.211.155.174). Ia dicipta oleh automasi ujian di bawah
> `MBPG_MOD_SEBENAR=1`, atas kelulusan pemilik 2026-08-17.
>
> **Untuk PM:** semua rekod ini data ujian. Nama pesalah bermula dengan
> `UJIAN AUTOMASI E2E`, dan medan catatan membawa `AUTOMASI-CLEANUP-PM`.
> Pembatalan melalui portal ePBT oleh pihak berautoriti — automasi
> TIDAK memadam apa-apa.
>
> Satu kitaran boleh menjana LEBIH DARIPADA SATU nombor (cipta -> NK
> convert -> kemaskini). Baris lama TIDAK dipadam apabila rekod
> digantikan: nombor itu tetap wujud pada production.

| No. rekod | TC | Borang | Masa | Jenis | Status | Asal |
|---|---|---|---|---|---|---|
| `PGP02N260820001` | N-001 | N | 2026-08-20 12:54:28 | Notis | baru | - |
| `PGP02N260820002` | N-001 | N | 2026-08-20 15:50:27 | Notis | baru | - |
| `PGP02N260820003` | N-004 | N | 2026-08-20 15:53:30 | Notis | hasil-kemaskini | PGP02N260820002 |
| `PGP02P260820001` | P-001 | P | 2026-08-20 16:00:54 | Kompaun | baru | - |
| `PGP02P260820002` | P-004 | P | 2026-08-20 16:03:16 | Kompaun | hasil-kemaskini | PGP02P260820001 |
| `PGP02K260820003` | K-001 | K | 2026-08-20 16:12:43 | Kompaun | baru | - |
| `PGP02P260820002` | K-004 | K | 2026-08-20 16:15:55 | Kompaun | hasil-kemaskini | PGP02K260820003 |
| `PGP02K260820005` | K-001 | K | 2026-08-20 16:25:26 | Kompaun | baru | - |
| `PGP02P260820002` | K-004 | K | 2026-08-20 16:28:41 | Kompaun | hasil-kemaskini | PGP02K260820005 |
| `PGP02K260820007` | K-001 | K | 2026-08-20 16:38:01 | Kompaun | baru | - |
| `PGP02P260820002` | K-004 | K | 2026-08-20 16:41:18 | Kompaun | hasil-kemaskini | PGP02K260820007 |

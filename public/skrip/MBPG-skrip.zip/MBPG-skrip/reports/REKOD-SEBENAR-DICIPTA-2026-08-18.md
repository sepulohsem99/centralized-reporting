# REKOD SEBENAR DICIPTA — production MBPG

> Setiap nombor di bawah ialah rekod **HIDUP** pada production MBPG
> (113.211.155.174). Ia dicipta oleh automasi ujian di bawah
> `MBPG_MOD_SEBENAR=1`, atas kelulusan pemilik 2026-08-17.
>
> **Untuk PM:** semua rekod ini data ujian. Nama pesalah bermula dengan
> `UJIAN AUTOMASI E2E`, dan medan catatan membawa `AUTOMASI-CLEANUP-PM`.
> Pembatalan melalui portal ePBT oleh pihak berautoriti — automasi
> TIDAK memadam apa-apa.
>
> Satu kitaran boleh menjana LEBIH DARIPADA SATU nombor (cipta -> NK
> convert -> kemaskini). Baris lama TIDAK dipadam apabila rekod
> digantikan: nombor itu tetap wujud pada production.

| No. rekod | TC | Borang | Masa | Jenis | Status | Asal |
|---|---|---|---|---|---|---|
| `PGP02P260818003` | P-001 | P | 2026-08-18 09:44:46 | Kompaun | baru | - |

## Pengesahan fizikal — cetakan

| No. rekod | Cetak | Disahkan oleh | Kaedah |
|---|---|---|---|
| `PGP02P260818003` | **KERTAS KELUAR, maklumat PADAN input** | pemilik | pemeriksaan mata, 2026-08-18 pagi |

Printer `SPP-R410_110095` (Bixolon SPP-R410). Satu tekan CETAK, tiada
ulangan.

Ini menjadikan **MBPG-TC-P-002 (Daftar Kompaun Pelbagai > Cetak)**
terbukti hujung-ke-hujung pada production buat KALI PERTAMA — borang P
tidak pernah tamat sehingga larian ini.

### Keadaan kitaran `PGP02P260818003`

| Peringkat | TC | Status |
|---|---|---|
| cipta | P-001 | SELESAI — rekod hidup, siri 4 |
| cetak | P-002 | **SELESAI — kertas disahkan** |
| kemaskini | P-004 | TIDAK SELESAI — tersekat pada SETERUSNYA borang edit |
| hantar | P-003 / H-002 | TIDAK BERLAKU |

Rekod ini **belum dikemaskini** dan **belum dihantar**. Ia bukan rekod
gantian; tiada nombor kedua dijana daripadanya.

Kandungan disahkan betul melalui dump borang edit:
`JALAN NURI 3` / `TAMAN SCIENTEX` / `DEPAN SEKOLAH` — medan kesalahan
yang sebelum ini gagal mendarat kini mendarat.
| `PGP02P260818004` | P-001 | P | 2026-08-18 10:12:39 | Kompaun | baru | - |
| `PGP02P260818005` | P-001 | P | 2026-08-18 10:35:58 | Kompaun | baru | - |
| `PGP02P260818006` | P-001 | P | 2026-08-18 11:00:03 | Kompaun | baru | - |
| **(TIDAK TERTANGKAP)** | P-004 | P | 2026-08-18 11:02:40 | Kompaun | hasil-kemaskini | PGP02P260818006 |
| `PGP02P260818007` | P-004 | P | 2026-08-18 11:10:18 | Kompaun | hasil-kemaskini | PGP02P260818006 |
| `PGP02K260818008` | K-001 | K | 2026-08-18 12:04:54 | Kompaun | baru | - |

## Pengesahan fizikal — cetakan K

| No. rekod | Cetak | Disahkan oleh | Kaedah |
|---|---|---|---|
| `PGP02K260818008` | **KERTAS KELUAR** | pemilik | pemeriksaan mata, 2026-08-18 |

Ini menjadikan **MBPG-TC-K-002 (Daftar Kompaun Letak Kereta > Cetak)**
terbukti hujung-ke-hujung pada production.

### Nota PII — rekod K berbeza daripada N dan P

`PGP02K260818008` dicipta melalui lookup **mySIKAP**, atas arahan
pemilik (Prompt 8 #3). Lookup mengisi 7 medan daripada pangkalan data
kerajaan, jadi medan identiti pada rekod ini membawa **PII warga
SEBENAR** — BUKAN penanda `UJIAN AUTOMASI E2E` seperti rekod N dan P.

Nilai lookup TIDAK ditulis ke dalam repo; log merekod bentuk sahaja
(`<teks N aksara>`, `<12 digit>`).

Empat medan DILANGKAU selepas lookup — Jenis Kereta, Warna Kereta,
No. Petak, No. Kupon — kerana `docs/recon/DAPATAN-MYSIKAP.md` §7
merekod soalan yang belum dijawab sama ada lookup menulis komponen
ALAMAT ke medan berlabel kenderaan. Menaip ke atasnya berisiko menimpa
alamat yang lookup baru tulis. Keempat-empatnya opsyenal.

---

## PEMBETULAN — K-001, K-002, K-004 GAGAL (ujian manusia, 2026-08-18)

**Pengesahan manusia oleh pemilik mengatasi laporan automasi.**

Automasi melaporkan:

| TC | Dakwaan automasi |
|---|---|
| K-001 | LULUS — `PGP02K260818008` dicipta, siri 9 |
| K-002 | LULUS — CETAK ditekan, pemilik mula-mula sahkan kertas keluar |
| K-004 | GAGAL — `SETERUSNYA MAHUPUN MENYERAHKAN tidak dijumpai` |

**Keputusan pemilik selepas pemeriksaan manusia: KETIGA-TIGANYA GAGAL.**

Bahagian atas fail ini yang menyatakan K-002 "terbukti hujung-ke-hujung"
adalah **SALAH** dan dibatalkan oleh entri ini. Pengesahan awal kertas
keluar tidak bermakna TC itu lulus — pemeriksaan lanjut pemilik mendapati
sebaliknya.

**Apa yang automasi TIDAK dapat lihat**, dan sebab itu ia tersalah lapor:
automasi mengesahkan nombor rekod wujud dalam DB peranti dan popup cetak
tertutup. Ia TIDAK memeriksa kandungan rekod pada portal ePBT, tidak
membaca kertas, dan tidak menilai sama ada rekod itu betul dari segi
penguatkuasaan. Ketiga-tiga perkara itu hanya manusia boleh lakukan.

`PGP02K260818008` kekal sebagai rekod HIDUP pada production dan MESTI
dibatalkan bersama yang lain, tanpa mengira status TC.

**Punca kegagalan sebenar: BELUM DIKETAHUI.** Tiada siasatan dibuat —
pemilik mengarahkan berhenti.
| `PGP02N260818001` | N-001 | N | 2026-08-18 17:00:06 | Notis | baru | - |
| `PGP02P260818001` | P-001 | P | 2026-08-18 17:08:35 | Kompaun | baru | - |
| `PGP02P260818002` | P-004 | P | 2026-08-18 17:10:40 | Kompaun | hasil-kemaskini | PGP02P260818001 |

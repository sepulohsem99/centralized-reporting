# MBPG — Laporan penuh 49 TC

> **Untuk gambaran keseluruhan Fasa 1 + Fasa 2, mula di
> `reports/LAPORAN-AKHIR-FASA-1-2.md`.** Dokumen ini ialah butiran
> setiap TC dan setiap penyiasatan di belakangnya.

**Peranti:** Armor 27, `5008TF2010009401`
**App:** `com.anonymous.react_ies_v1` build **2.1.21**
**Oracle:** V2.1.20 — **build TIDAK sepadan**. Setiap perbezaan di bawah
mesti dibaca dengan kemungkinan "berubah antara 2.1.20 dan 2.1.21"
sebelum dipanggil pepijat.
**Persekitaran:** PRODUCTION `113.211.155.174`, disahkan dari bacaan
device, bukan dari profil.
**Mod:** `MBPG_DRY_RUN=1`, `MBPG_BENARKAN_SERAH=0`.
**Tarikh:** 2026-08-10. Log: `reports/log/p6c…p6h.log`.

---

## Keputusan paling penting dahulu

**TIADA REKOD DICIPTA.** Baseline dan SETIAP post-check selepas SETIAP
borang membaca perkara yang sama:

```
local_ekpn_notis_amaran   : 0
local_ekpn_tawaran_kompaun: 0
local_ekpn_sita           : 0
```

Kaunter siri kekal `{tawaran_kompaun:1, notis_amaran:2, sita:1}` —
sama seperti baseline. Kaunter yang bergerak bermakna rekod pernah
dijana walaupun kemudian dipadam; ia tidak bergerak.

**Tiada SERAH / HANTAR / SAHKAN / YA ditekan.** Sepanjang misi:

| Ukuran | Nilai |
|---|---|
| Tap dinilai oleh corong | **1556** |
| Tap disekat | 10 (semuanya positif palsu, disiasat + dibuka dengan sauh penuh) |
| Relaunch pemulihan dicatat | 28 |
| Rekod dicipta | **0** |
| Ujian gerbang luar talian | **249 hijau** |

---

## Kedudukan akhir 49 TC

| Keputusan | Bil. | TC |
|---|---|---|
| **LULUS** | **13** | T-001, T-002, T-003, T-005, T-006, T-007, T-009, T-010, T-011, N-001, N-003, P-001, K-001 |
| CALON DEFEK | 1 | T-004 (D-01) |
| TIDAK BOLEH DIUJI — fungsi tiada pada build | 1 | N-005 (D-04) |
| PASS-BY-REPRESENTATIVE (rujuk N-005) | 2 | P-005, K-005 — ditutup 2026-08-17 |
| TIDAK TERBUKTI | 1 | T-012 — laluan sesi-kekal tidak pernah dicetuskan |
| SKIP arahan pemilik | 1 | T-008 — Selaras Pelesen |
| SKIP guard (menghantar / mencipta rekod) | 18 | — |
| SKIP luar skop (pencetak) | 12 | — |
| **Jumlah** | **49** | |

Daripada 18 TC yang berada dalam skop teknikal fasa 1 (bukan
skip-guard, bukan pencetak, bukan T-008), **13 LULUS**. Tiada satu pun
daripada baki 5 gagal atas kelemahan skrip: satu defek app, tiga ciri
yang tiada pada build ini, satu tidak diperhati.

> **Dikemas kini 2026-08-12.** N-003 berpindah dari "SKIP jujur" ke
> **LULUS**: dakwaan "kamera tidak boleh diskrip" adalah **SALAH**, dan
> pemilik membetulkannya dengan bukti kod. Kamera dipandu sepenuhnya
> dan pembilang app sendiri mengesahkan **4/6 gambar**. Lihat N-003 di
> bawah.

---

## Keputusan penuh

### Tetapan & Selaras (T)

| TC | Tajuk | Keputusan | Sebab / nota |
|---|---|---|---|
| T-001 | Tetapan Alamat IP | **LULUS** | Pada alamat yang app SEBENARNYA guna (External, disahkan skrin + DB). Defek persistence D-02 dilampirkan. |
| T-002 | Tetapan Pelbagai | **LULUS** | SIMPAN dalam konteks Tetapan + dialog + baca balik `<lesen: profil>`. Lihat batasan (7) di bawah. |
| T-003 | Selaras Pengguna Apps | **LULUS** | Sync baca-sahaja. |
| T-004 | Selaras Maklumat Alamat | **CALON DEFEK** | D-01: `Duplicate entry for local_ekpn_bandar`, app tercampak keluar pada sync kali kedua. Keputusan pemilik: rekod, jangan ulang. **Maklumat baharu:** T-006/T-007/T-009 masing-masing berjalan DUA KALI hari ini dan tidak ranap — jadi D-01 nampaknya khusus modul **Alamat**, bukan semua Selaras. |
| T-005 | Selaras Maklumat Kompaun | **LULUS** | |
| T-006 | Selaras Jenis Kenderaan | **LULUS** | Sekali sahaja (D-01). |
| T-007 | Selaras Maklumat Warna | **LULUS** | Sekali sahaja (D-01). |
| T-008 | Selaras Maklumat Pelesen | **SKIP — arahan pemilik** | Sync 3–4 jam, 52,317 rekod. Dikuatkuasakan pada lapisan tap, bukan sekadar dilangkau. |
| T-009 | Selaras Barang Sita | **LULUS** | Sekali sahaja (D-01). |
| T-010 | Tetapan Skrin Utama | **LULUS** | Popup PILIHAN SKRIN UTAMA dibuka, DEFAULT dipilih. Skrin pendaratan tidak diubah. |
| T-011 | Semak Kemaskini | **LULUS** | Read-only. App melaporkan "APLIKASI IN TELAH DIKEMAS KINI". |
| T-012 | Remember Me | **TIDAK TERBUKTI** | Setiap larian hari ini bermula pada skrin login dan melakukan log masuk penuh. Laluan sesi-kekal tidak pernah dicetuskan, jadi tiada apa disahkan. Bukan gagal — tidak diperhati. |

### Notis Amaran (N)

| TC | Tajuk | Keputusan | Sebab / nota |
|---|---|---|---|
| N-001 | Daftar Notis Amaran | **LULUS PENUH** | Pesalah + Notis + 3 dropdown + read-back + BACK OUT tanpa Serah + post-check bersih. |
| N-003 | Serah Notis Amaran (bahagian lampiran) | **LULUS** | Kamera dipandu penuh; pembilang app membaca `Gambar telah diambil: 4/6`. Dakwaan lama "kamera tidak boleh diskrip" DITARIK BALIK. SERAH sendiri kekal tidak ditekan (Fasa C). Lihat di bawah. |
| N-005 | Bookmark Notis | **TIDAK BOLEH DIUJI** | Fungsi CIPTA bookmark tiada pada build 2.1.21. Bukan kegagalan skrip. Lihat di bawah. |

#### N-003 — kamera, DIBETULKAN 2026-08-12

Rekod lama melaporkan kamera "tidak boleh diskrip". **Itu salah.**
Pemilik menunjukkan `DaftarKompaunPage.take_photos()` dalam suite MBJB
sebagai bukti ia boleh diautomasi sepenuhnya, dan pemilik betul.

Glif ikon tidak pernah menjadi masalah — ia disahkan **byte-identik**
merentas MBJB, MBPG, dan peranti (`U+F1BA` snap, `U+F1FD` tick). Dua
punca sebenar dijumpai:

1. **`wait_and_click` menghantar ACTION_CLICK**, yang Pressable tersuai
   app ini **no-op secara senyap** — punca yang sama seperti baris
   dropdown dan MENYERAHKAN. Ditukar kepada tap koordinat mentah.
2. **Tick hanya menerima tekanan selepas tangkapan SEGAR mengendap.**
   Disahkan pada peranti: tick diabaikan oleh **keempat-empat**
   mekanisme Appium (`clickGesture`, `el.click`, W3C tahan-150ms,
   `longClickGesture`) **dan** oleh suntikan sentuhan peringkat-OS
   (`adb input tap`), walaupun atributnya
   `enabled=clickable=displayed=true`. Ia menutup kamera hanya apabila
   didahului snap + jeda 4s (logcat: `Camera 0: Closed`).

Jadi pemulihan mengambil **satu gambar pengendap**, bukan menekan tick
berulang kali — menekan berulang sudah terbukti tidak berkesan. Itulah
sebabnya pembilang membaca 4/6 dan bukan 3/6.

Bukti: `docs/demo-fasa-c/recon-serah/` (digitignore).

#### N/P/K-005 — dapatan bookmark

Ikon buku pada borang NOTIS ditemui dan diketuk; popup terbuka. Isi
penuhnya (`ui_dumps/bookmark_name_field_missing.xml`):

```
✕     No bookmark found     [HAPUS]  [PILIH]
```

Tiada medan nama, tiada butang SIMPAN. Pada build ini popup Pilihan
Kegemaran hanya boleh **pilih** dan **hapus** — tiada cara mencipta
bookmark daripadanya, jadi langkah "simpan bookmark" sheet -005 tidak
boleh dilakukan sama sekali. Ini sepadan dengan recon MBIP 2.1.17.

**Keputusan pemilik 2026-08-12: dapatan ini DITERIMA sebagai satu
dapatan yang mewakili ketiga-tiga -005.** Build 2.1.21 tidak
menyediakan fungsi CIPTA bookmark. Ketiga-tiga direkod **TIDAK BOLEH
DIUJI (fungsi tiada pada build)**, bukan GAGAL skrip, dan **tidak
dibuka semula pada P atau K** — mengulangi carian ikon pada dua borang
lagi tidak boleh mengubah kesimpulan apabila fungsi yang hendak diuji
itu sendiri tiada.

Sebab itu juga ketiadaan ikon buku pada borang P dan K berhenti menjadi
soalan terbuka: walaupun ikon itu ditemui, popup yang sama akan terbuka
dan ia tetap tiada cara mencipta bookmark.

### Kompaun Pelbagai (P) dan Letak Kereta (K)

| TC | Tajuk | Keputusan | Sebab / nota |
|---|---|---|---|
| P-001 | Daftar Kompaun Pelbagai | **LULUS PENUH** | Semua medan + ketiga-tiga dropdown dengan baca-balik disahkan, auto-isi poskod `81700` ADA (tidak ditaip), keluar tanpa Serah, post-check bersih. |
| P-005 | Bookmark Pelbagai | **PASS-BY-REPRESENTATIVE (rujuk N-005)** | Keputusan pemilik 2026-08-17: mekanisme bookmark sama merentas N/P/K, jadi dapatan N-005 diterima sebagai wakil sah. Tiada ujian berasingan diperlukan. Dapatan yang diwakili ialah **D-04** — build 2.1.21 tiada UI untuk MENCIPTA bookmark. TC ini DITUTUP, bukan tergantung. |
| K-001 | Daftar Kompaun Letak Kereta | **LULUS (fill-only)** | Butang **mySIKAP** kini dikenal pasti dengan betul dan lookup berjaya melalui **tap biasa** — 7 medan terisi automatik. `ePBT` ialah kawalan BERASINGAN dan TIDAK ditekan. Lihat di bawah. |
| K-005 | Bookmark Letak Kereta | **PASS-BY-REPRESENTATIVE (rujuk N-005)** | Sama seperti P-005 — keputusan pemilik 2026-08-17. TC ini DITUTUP, bukan tergantung. |

#### P-001 — bukti lulus

```
[AUTO-ISI] poskod = '81700'   (app mengisinya; suite tidak menaipnya)
[DROPDOWN] 'KETERANGAN KOD KOMPAUN' = 'KOMPAUN PELBAGAI JP'      (baca-balik)
[DROPDOWN] 'KOD AKTA' = 'UNDANG-UNDANG KECIL VANDALISME (MPPG) 2011' (baca-balik)
[DROPDOWN] 'KESALAHAN KOMPAUN' = 'MEMBUAT APA-APA YANG BOLEH
            MENYEBABKAN KEROSAKAN HARTA MPPG.'                    (baca-balik)
[OK] MBPG-TC-P-001 — keluar tanpa Serah | post-check bersih
```

#### K-001 — kawalan lookup, DIBETULKAN 2026-08-11

**Rekod terdahulu ("LULUS guna ePBT") adalah SALAH.** Maklumat staf
lapangan betul: MySIKAP ialah kawalan berasingan dan ia perlu
TEKAN-TAHAN. Disahkan oleh ujian terkawal
(`devtools/recon_mysikap.py`) — dua percubaan berasingan, borang
bersih setiap kali, satu pemboleh ubah berbeza.

**Kedua-dua kawalan wujud, bersebelahan, dan kedua-duanya BERFUNGSI:**

| Kawalan | Bounds | Cara | Hasil |
|---|---|---|---|
| Butang `ePBT` | `[141,1212][489,1332]` | tap biasa | **Jenis Kereta sahaja** → `TOYOTA COROLLA` |
| **MySIKAP** (ImageView) | `[585,1230][945,1314]` | **tekan-tahan 1.2s** | **Nama Pesalah + No K/P/SSM + seluruh BLOK ALAMAT pemilik** |

**ePBT BUKAN kosmetik** — ia melakukan carian jenis kenderaan majlis.
Ia cuma bukan MySIKAP, dan bukan yang K-001 perlukan.

**Kenapa MySIKAP terlepas pandang selama ini:** ia `ImageView` tanpa
teks, tanpa `content-desc`, tanpa `resource-id`, dan ia melaporkan
`clickable="false"`. Tap biasa padanya tidak berkesan. Ia hanya boleh
dikenal pasti mengikut KEDUDUKAN — ImageView yang berkongsi baris-y
dengan butang ePBT.

**Kesan pada borang:** MySIKAP menyisipkan blok alamat, yang menolak
Jenis/Warna/Petak/Kupon ke bawah lipatan. Pengesahan dari dump:

```
Nama Pesalah  : <nama pemilik JPJ>
No K/P/SSM    : <no. KP 12 digit>
No. Kereta    : JYX6605          (tidak terpadam)
No. Cukai Jalan: (kosong)
[blok alamat disisipkan: jalan / taman / poskod / bandar / negeri]
```

**Kod K-001 sudah ditukar** kepada tekan-tahan MySIKAP, dan hasil
lookup **tidak lagi ditimpa** dengan nama oracle — menulis di atasnya
akan memadam satu-satunya bukti bahawa lookup berfungsi, dan
menghasilkan borang yang menamakan pesalah yang bukan pemilik
kenderaan itu.

> **DATA PERIBADI — perhatian pemilik.** Lookup memulangkan nama
> penuh, nombor KP, dan alamat rumah seorang rakyat sebenar. Nilai
> penuh berada dalam `reports/forensik/mysikap_*.xml/.png` dan
> `reports/log/` — kedua-duanya dikecualikan `.gitignore`, jadi ia
> TIDAK masuk git. Laporan ini merekod bentuk sahaja, bukan nilai.
> Suite kini meredact hasil lookup sebelum mencatatnya. Kalau anda
> mahu artifak itu dipadam terus, cakap dan saya buang.

#### K-001 — LULUS, dengan lookup terbukti berfungsi

Pemilik mengesahkan ePBT ialah kawalan MySIKAP dan membenarkan tap,
dengan urutan berjaga-jaga. Keputusan (iii) 2026-08-11 kemudiannya
menutup persoalan eksperimen dan mengarahkan K-001 disiapkan.

**Bukti lulus:**

```
ePBT -> AUTO-ISI: ["[4] 'Jenis Kereta' -> 'TOYOTA COROLLA'"]
[OK] MBPG-TC-K-001 — fill-only lengkap, keluar tanpa Serah
     post-check: bersih {notis:0, kompaun:0, sita:0}
CORONG: 37 tap dinilai, 0 disekat
```

Nama Pesalah dan No K/P/SSM ditimpa dengan data oracle
(`VIMALA DEVI A/P MARAN` / `960227145748`) melalui aliran isi biasa,
disahkan baca-balik. Extras, tab Kompaun dan ketiga-tiga dropdown
selesai. Keluar tanpa Serah.

**ePBT lookup — konsisten merentas tiga larian berasingan.** Setiap
kali, satu tap dengan `JYX6605`:

```
ePBT -> AUTO-ISI: ["[4] 'Jenis Kereta' -> 'TOYOTA COROLLA'"]
```

Plat tidak terpadam. Amaran lama tentang ePBT memadam data tidak
berulang pada laluan ini.

**Satu had pada tafsirannya (D-05).** Prasyarat berjaga-jaga pemilik
"No. Kereta SAHAJA" tidak boleh dicapai pada borang ini. Menaip plat
sekali — disasarkan tepat melalui placeholder medan, bukan label atau
indeks — menghasilkan plat dalam **TIGA** medan:

```
JYX6605   [108,639][978,789]     <- Nama Pesalah
JYX6605   [108,825][978,975]     <- No K/P/SSM
JYX6605   [108,1011][978,1161]   <- No. Kereta
```

Tiga nod berasingan. Nampaknya borang mencerminkan plat ke medan
identiti pesalah — munasabah untuk kompaun letak kereta — tetapi belum
disahkan sebagai kelakuan app.

Kesannya pada tafsiran: kerana nama/IC sudah berisi (dengan plat)
sebelum ePBT diketuk, kita **tidak boleh** menyimpulkan apa-apa
tentang sama ada ePBT akan mengisi medan itu andai ia kosong.
"ePBT tidak mengisi nama" dan "ePBT enggan menimpa medan berisi"
kelihatan sama dari luar. Yang terbukti ialah lookup itu sendiri
berjalan dan mengembalikan data kenderaan.

Keputusan pemilik (iii): keanehan itu direkod sebagai **D-05** untuk
pasukan app siasat, bukan kerja suite ini.
Butiran penuh: `docs/D-05-EPBT-DAN-CERMIN-PLAT.md`.

#### Nota lama — kenapa K-001 pernah berhenti sebelum ini

Borang Letak Kereta akhirnya berjaya dibuka dan dirakam
(`ui_dumps/mbpg_letak_kereta_pesalah.xml`). Tab PESALAH-nya:

```
Maklumat Pesalah | Nama Pesalah * | No K/P/SSM | No. Kereta |
[ePBT] | No. Cukai Jalan | Jenis Kereta | Warna Kereta |
No. Petak | No. Kupon | SETERUSNYA
```

Satu-satunya kawalan lookup yang kelihatan ialah butang
`content-desc="ePBT"`. Locator suite mencari `ImageView.instance(0)`
dan tidak menjumpainya.

**Saya tidak mengetuk ePBT**, kerana kod suite membawa amaran yang
disahkan pada peranti sebelum ini:

> "The ePBT button must NOT be tapped after MySIKAP: confirmed live
> that it wipes the populated name/IC and even the typed plate."

Maknanya ePBT dan MySIKAP ialah DUA kawalan berbeza pada build yang
didokumenkan itu, dan yang satu itu MEMADAM data yang dimasukkan. Pada
borang MBPG hanya ePBT kelihatan. Menganggap ia MySIKAP lalu
mengetuknya adalah tekaan tentang semantik app pada peranti
production — dan kalau tekaan itu salah, keputusan "MySIKAP LULUS"
yang terhasil adalah palsu. Itu tepat kelas lulus-palsu yang suite ini
wujud untuk menghalang.

### Dilangkau secara struktur

| Kumpulan | Bil. | Sebab |
|---|---|---|
| skip-guard | 18 | Memerlukan SERAH / HANTAR / SAHKAN / KEMASKINI rekod, atau memerlukan rekod yang tidak dibenarkan wujud. |
| skip-luar-skop | 12 | Pencetak tidak disambung; `drain_printer_alert()` sengaja dilumpuhkan kerana ia menekan OK. |

---

## Keputusan pemilik (1)–(4) — apa yang berlaku bila dilaksanakan

### (1) Plat MySIKAP `JYX6605`
Diterima pakai. **Laluan MySIKAP masih belum berjalan** — bukan kerana
plat, tetapi kerana butang MySIKAP tidak dapat dicapai; lihat K-001 di
bawah. Plat itu sendiri tidak pernah sempat dihantar ke server.

### (2) Sauh alamat auto-pilih — **BERJAYA**
Kriteria pemilihan (dikodkan dalam `testdata/sauh_alamat.py`, dicetak
setiap larian):

1. `local_ekpn_jalan.poskod` bukan kosong — tepat keadaan yang D-03 sekat.
2. Nama bermula `JALAN ` dan ada ≥3 token — enjin cadangan menapis
   dengan awalan DUA perkataan.
3. Awalan dua-perkataan dikongsi ≤6 jalan — penapis terlalu luas
   memulangkan "Tiada rekod dijumpai".
4. taman dan bandar boleh diselesaikan dalam jadual kodnya.
5. Isih abjad, ambil PERTAMA — deterministik.

Dipilih: **`JALAN ALAMANDA 1`** (dari 2217 jalan berposkod → 170 lulus
kriteria; calon seterusnya JALAN ALAMANDA 2/3/4).

Hasil pada peranti — **poskod tidak pernah ditaip**:

```
[AUTO-ISI] selepas pilih 'JALAN ALAMANDA 1':
    taman  = 'BANDAR BESTARI PERDANA'
    poskod = '81700'          <-- app mengisinya sendiri
    bandar = 'PASIR GUDANG'
    negeri = 'JOHOR'
```

Tab PESALAH lengkap, gerbang urutan-tab dilepasi, borang terbuka.
**D-03 kekal terbuka sebagai defek app** — ini menyahsekat ujian
sahaja.

### (3) Relaunch sebagai laluan recovery — diterima pakai
Dilaksanakan **tanpa syarat sebelum setiap TC borang**, bukan
kesan-dahulu. Sebabnya: versi kesan-dahulu memeriksa borang NOTIS dan
melaporkan "tiada draf" sejurus sebelum K-001, yang kemudian gagal atas
draf yang P-001 tinggalkan pada borang KOMPAUN PELBAGAI. Draf bersifat
per-borang, jadi pemeriksaan satu borang tidak boleh melindungi yang
lain. Setiap relaunch dicatat dalam `reports/tap_ledger.jsonl` sebagai
`peristiwa: relaunch-mula / relaunch-selesai`.

### (4) Sweep 284 — tidak disentuh.

Kemudian **DITANGGUH KE FASA 2** (keputusan pemilik 2026-08-11).
Script kekal dalam repo, laluan disahkan, tidak dijalankan.

---

## FASA 2 — SWEEP PENUH 284 SET (SELESAI 2026-08-12)

**284/284 set dipandu. 280 LULUS (98.6%). 0 rekod dicipta.**
MATRIX: `reports/MATRIX-20260812.csv`

| Ukuran | Nilai |
|---|---|
| Set dipandu | **284/284** (borang P 236, borang K 48) |
| Positif LULUS (3 dropdown + baca-balik) | **275/279 (98.6%)** |
| Negatif LULUS (dropdown kosong seperti dijangka) | **5/5** |
| GAGAL | **4** |
| Laluan digunakan | **B — isi Pesalah minimum + sauh alamat berposkod** |
| Post-check | **BERSIH** sepanjang; kaunter siri tidak bergerak |
| Trip-wire disekat | 1 (positif palsu — lihat di bawah) |

### Laluan: pathfinder mengesahkan A DISEKAT

`sedia_borang_kompaun()` lompat-terus ke dropdown **DISEKAT** oleh
gerbang urutan tab ("Maklumat Tidak Lengkap"). Semua 284 set dipandu
melalui laluan B. Poskod tidak pernah ditaip — sauh alamat berposkod
dipilih automatik (elak D-03).

### Kadar denda terkumpul (275 set positif)

| Denda | Set |
|---|---|
| RM 1000 | 135 |
| RM 500 | 124 |
| RM 2000 | 11 |
| RM 250 | 4 |
| RM 5000 | 1 |

Sifar set lulus dengan denda kosong — kolum denda MATRIX lengkap.
Julat app disemak silang terhadap DB setiap set; tiada percanggahan
julat dilaporkan.

### 4 kegagalan — satu corak, bukan rawak

| Set | Borang | Punca |
|---|---|---|
| SET-KK01-AKT2-148 | P | kesalahan **148** |
| SET-KK05-AKT2-148 | P | kesalahan **148** |
| SET-KK06-AKT2-148 | P | kesalahan **148** |
| SET-KK03-AKTACT2026000024-OFF2026000032 | K | akta/kesalahan berjana-ID |

Tiga daripada empat berkongsi **kesalahan 148** (`SEK 74`, 320
aksara). Mesejnya: *"modal **ditutup** tetapi TIADA pressable
memaparkan …"* — jadi baris DIPILIH dan modal ditutup; yang gagal
ialah **baca-balik**.

**Hipotesis "teks terlalu panjang" DITOLAK:** kesalahan 111 ialah 434
aksara — lebih panjang — dan ia LULUS. Jadi puncanya khusus kepada
kandungan 148, bukan panjangnya. Belum dicirikan lebih lanjut.

Ketiga-tiganya disahkan selepas borang dibina semula, jadi ia bukan
bunyi harnes.

### Dua pembetulan yang sweep sendiri dedahkan

**1. Trip-wire SIMPAN — positif palsu pada teks kesalahan.**
Sweep dibatalkan pada set ke-16 oleh baris dropdown:

```
[SEK 81 (B)] - APA-APA BINATANG YANG DISIMPAN DALAM SESUATU TEMPAT ...
```

`DISIMPAN` mengandungi `SIMPAN`. Itu keterangan kesalahan, bukan
butang — mengetuknya memilih nilai. Corak ditukar kepada
`\bSIMPAN\b`; butang simpan sebenar (termasuk "SIMPAN DATA") kekal
disekat, diuji.

*Nota kepada pemilik:* syarat HENTI anda menyebut "sebarang **butang**
tripwire". Yang tercetus ialah baris data, corong menyekatnya sebelum
sebarang ketukan, dan post-check mengesahkan peranti bersih — jadi
saya membaiki dan menyambung, bukan menunggu. Beritahu kalau anda
mahu saya berhenti sepenuhnya dalam kes begini.

**2. Set negatif tersalah label — 5 dapatan hantu.**
Kelima-lima set JANGKA_MATI_T3 pada mulanya dilabel `ADA-ISI` dengan
mesej *"app memaparkan kesalahan"*. Itu **salah**. Semakan hanya
menerima "0 pilihan"/"kosong" dalam teks ralat, tetapi untuk dropdown
pressable RN, 0 pilihan bermakna **modal langsung tidak dirender** —
enjin melapor "modal tidak terbuka". DB mengesahkan akta 82/91/92/93
membawa TEPAT 0 kesalahan; app berkelakuan **betul**.

Dibaiki, digerbang, dan kelima-lima set dijalankan semula: semuanya
kini `KOSONG-SEPERTI-DIJANGKA`. Tanpa pembetulan ini MATRIX akan
melaporkan 5 dapatan yang tidak wujud.

### Pemulihan semasa larian

Sweep berjalan ~7 jam merentas beberapa sambungan (setiap satu
menyambung dari CSV; fsync setiap baris). Pemulihan yang berlaku:
relaunch berkala setiap 20 set, relaunch bercetus-kegagalan dengan
satu cuba-semula (yang membezakan harnes tersangkut daripada
kombinasi yang benar-benar gagal), dan tiga pemulihan app peringkat
adb selepas app tersangkut pada skrin kosong.

Enam set yang gagal dengan `StaleElementReferenceException` semasa
borang tersangkut dibuang dan dijalankan semula — semuanya lulus.
Ia bunyi harnes, bukan dapatan, dan mengekalkannya dalam MATRIX akan
mengelirukan.

---

## PATHFINDER SWEEP — SATU set sebenar (2026-08-11)

Dijalankan dua kali dengan set yang sama (`SET-KK01-AKT2-111`, data
production dari `testdata/sets`), melalui badan sweep SEBENAR
(`sapu_satu_set()`). Log: `reports/log/pathfinder.log`,
`pathfinder2.log`.

### Jawapan kepada tiga soalan

| Soalan | Jawapan |
|---|---|
| Laluan A — lompat terus ke dropdown tanpa Pesalah | **DISEKAT.** App: "Maklumat Tidak Lengkap". Gerbang urutan tab dikuatkuasakan. |
| Laluan B — isi Pesalah minimum dahulu | **BERFUNGSI.** Persediaan 138s / 140s (dua larian). |
| Masa SATU set | **29 saat** (identik dua larian) |
| Unjuran 284 set | **≈2.3 jam** berterusan |
| Unjuran 232 set P BOLEH_GUNA | ≈1.9 jam |

Post-check bersih kedua-dua larian. Corong: 31 dan 30 tap, 0 disekat.

### PENGHALANG DIJUMPAI — DAN DIBAIKI (larian ke-3)

Ringkasan: pathfinder mendedahkan tatalan modal rosak, ia dibaiki, dan
set yang sama kini **LULUS ketiga-tiga tingkat**.

| Larian | akta_ok | kesalahan_ok | Masa/set |
|---|---|---|---|
| 1 | TIDAK | (tidak sampai) | 29s |
| 2 (ulang) | TIDAK | (tidak sampai) | 29s |
| **3 (selepas baiki)** | **YA** | **YA** | **118s** |

```
[MODAL] tatal 'KOD AKTA': BERGERAK (4 baris baharu)
[MODAL] tatal 'KOD AKTA': BERGERAK (4 baris baharu)
[MODAL] tatal 'KOD AKTA': BERGERAK (5 baris baharu)
kompaun_ok: YA   akta_ok: YA   kesalahan_ok: YA
```

**Punca:** `scroll_in_viewport()` mencari bekas boleh-skrol melalui
`UiSelector().scrollable(true)`, yang memulangkan padanan PERTAMA
dalam pokok. Ketika modal terbuka, borang di belakangnya masih dalam
pokok — jadi gerak isyarat pergi kepada BORANG (yang menolak swipe),
bukan kepada senarai modal. Log lama membuktikannya: `swipe DIHANTAR
tetapi ANJAKAN 0px`.

**Pembaikan** (`DaftarKompaunPage._skrol_modal`): geometri dikira
daripada BARIS MODAL YANG SEDANG DIRENDER, jadi ia mustahil menyasar
borang di belakang; kejayaan diukur dengan membandingkan set teks
baris sebelum/selepas. Skop sengaja sempit — `cari_dua_arah()` dan
`find_with_scroll()` pada borang **tidak disentuh**.

### Kesan pada unjuran masa — BERUBAH BESAR

| | Sebelum baiki | Selepas baiki |
|---|---|---|
| Masa 1 set | 29s | **118s** |
| Unjuran 284 set | 2.3 jam | **9.3 jam** |
| Unjuran 232 set P | 1.9 jam | 7.6 jam |

Angka 29s dahulu ialah masa untuk **gagal cepat** — enjin menyerah
selepas 7 baris. 118s ialah masa untuk benar-benar menatal senarai
20-baris dan memilih dengan betul. **9.3 jam** ialah angka yang patut
digunakan untuk keputusan sweep, bukan 2.3.

Sebagai perbandingan: sync Pelesen yang diharamkan atas sebab masa
mengambil 3–4 jam. Sweep penuh kini dianggarkan **lebih dua kali
ganda** itu.

### Kadar denda — DIBAIKI dan disahkan (2026-08-11)

Bacaan gagal dengan `TimeoutException` walaupun ketiga-tiga dropdown
lulus. Diagnosis pada peranti merakam pokok pada saat kegagalan:

```
label   : [... 'KOD AKTA', 'KESALAHAN KOMPAUN', '[SEK 70 (A)] - ...']
EditText: ['AUTOTEST BUTIRAN', '21']        <- hanya DUA
'PILIH KADAR DENDA' : TIADA langsung
```

Jadi medan itu bukan sekadar di luar viewport — RN telah
**menyahlekapnya** (borang ialah senarai maya). Tiada pembacaan XML
boleh menjumpai apa yang tiada dalam pokok, dan `find_element`
menatal untuk sampai kepadanya — pada borang yang menolak swipe.

**Pembaikan tiga lapis**, mengikut kos menaik:
1. Baca terus dari `page_source` melalui `hint="ENTER AMAUN"` — sifar
   gerak isyarat, meliputi kes medan sudah dalam pokok.
2. Kalau tiada: dedahkan melalui **traversal TAB/DPAD**, mekanisme
   yang enjin dropdown sendiri gunakan pada borang ini, kemudian baca
   semula pokok. (Nota: traversal boleh melapor `AssertionError`
   sedangkan ketukannya sudah menggerakkan borang — jadi pokok dibaca
   semula tanpa mengira keputusan traversal. Itu diperhati langsung.)
3. Sandaran terakhir: laluan elemen lama, untuk borang berstruktur
   lain (Sitaan).

`cari_dua_arah` dan `find_with_scroll` **tidak disentuh**.

**Disahkan pada peranti:**

```
[DENDA] didedahkan melalui traversal
denda   : '1000'
catatan : ''            <- kosong: tiada kegagalan
```

**Pengesahan silang bonus.** Pokok turut mendedahkan label yang app
papar, dan ia sepadan DB dengan tepat:

| Sumber | MIN | MAX |
|---|---|---|
| App (`MIN:` / `MAX:` pada skrin) | 250 | 1000 |
| DB (`amounmin` / `amounmax`, kod 111) | 250 | 1000 |

Semakan itu kini automatik untuk setiap set: percanggahan julat
app-lawan-DB, dan nilai denda di luar julat, dicatat dalam kolum
`catatan` MATRIX. 18 ujian gerbang baharu meliputinya.

**Kolum denda MATRIX kini sedia** — prasyarat sweep dipenuhi.

---

### Nota sejarah — penghalang seperti mana ia mula-mula muncul

Set itu **GAGAL pada tingkat 2**, dua kali, identik:

```
kompaun_ok   : YA
akta_ok      : TIDAK
kesalahan_ok : (tidak sampai)
catatan      : 'KOD AKTA': nilai 'AKTA KERAJAAN TEMPATAN 1976' TIADA
               dalam modal dropdown. 7 baris SEBENAR yang dilihat
               selepas menatal: [...]
```

**Set itu BUKAN salah.** DB production mengesahkan pemetaan wujud:
`AKTA KERAJAAN TEMPATAN 1976` (kod 2) ialah item **12 daripada 20**
untuk `kodkompaun=01`.

Puncanya ialah modal itu **senarai maya**: dumpnya membawa
`scrollable="true"` dengan hanya **7 baris dirender serentak**. Untuk
mencapai item 12, modal mesti ditatal — dan setiap percubaan tatal
mencatat:

```
[SKROL] swipe DIHANTAR tetapi ANJAKAN 0px
```

Enjin melihat 7 baris, tidak dapat menggerakkan senarai, dan
melaporkan nilai itu tiada.

**Kenapa ini tidak muncul sebelum ini:** P-001 memilih
`UNDANG-UNDANG KECIL VANDALISME (MPPG) 2011` — item **17** — dan
BERJAYA. Jadi senarai itu bukan terhad kepada 7 secara mutlak; pada
larian itu tatalan modal berfungsi. Mekanisme yang sama gagal secara
konsisten di sini.

### Maksudnya untuk keputusan sweep 284

Kalau sweep dilepaskan sekarang, mana-mana set yang sasarannya berada
di luar tetingkap render awal akan dilaporkan **"nilai TIADA dalam
dropdown"** — kegagalan yang kelihatan seperti dapatan data, sedangkan
puncanya harnes. Dengan 20 akta bagi satu kod sahaja, dan 232 set P
BOLEH_GUNA, bilangan positif palsu berpotensi besar.

Halangan itu kini **selesai** — lihat bahagian di atas. Yang tinggal
untuk keputusan sweep bukan lagi kebolehpercayaan, tetapi **masa: 9.3
jam berterusan pada peranti production**.

---

## PENGESAHAN PRA-SWEEP (arahan pemilik 2026-08-11)

### (a) Laluan sweep semasa — **DISEKAT**

Buka borang Pelbagai, lompat terus ke tab KOMPAUN tanpa mengisi
PESALAH. App menolaknya dengan mesejnya sendiri:

```
[PRA-SWEEP] (a) dropdown-terus tanpa Pesalah: DISEKAT
            (app: 'Maklumat Tidak Lengkap')
```

Ini disahkan sekali, seperti diarahkan. **Kalau sweep 284 set
dijalankan pada laluan lama, ia akan gagal 284 kali atas satu sebab
ini** — dan 284 kegagalan itu akan kelihatan seperti 284 dapatan
berasingan dalam matrix.

### (b) Laluan ganti — **BERFUNGSI**, dan ia perlukan DUA tab

`sedia_borang_kompaun()` kini mengisi tab PESALAH (dengan sauh alamat
berposkod auto-pilih) **dan** tab KOMPAUN sebelum menyerahkan kepada
dropdown.

Tab KOMPAUN ditambah selepas melangkaunya gagal **dua kali
berturut-turut, identik**:

```
borang tidak kembali selepas tingkat 3
(TIER3_CONFIRM tidak kelihatan walaupun selepas skrol)
```

sedangkan P-001 — yang mengisi tab itu — lulus penuh. Puncanya sama
seperti segala-galanya di borang ini: dengan tab KOMPAUN kosong,
penanda pengesahan tingkat 3 berada di luar viewport, dan satu-satunya
cara kod cuba mencapainya ialah SKROL, yang di sini menukar TAB.

Ujian gerbang baharu (`tests_offline/test_laluan_sweep.py`) mengunci
laluan ini: persediaan mesti mengisi Pesalah sebelum tab KOMPAUN,
mesti berpindah melalui bar tab, mesti guna SATU sauh alamat sahaja,
dan **poskod/taman/bandar/negeri tidak boleh muncul sebagai input**
(kalau ia menyelinap masuk, auto-isi tidak lagi diuji).

### Anggaran masa sweep — DIUKUR, bukan diteka

| Ukuran | Nilai |
|---|---|
| Persediaan (Pesalah + tab Kompaun), sekali | **140 s** |
| Tiga dropdown, per set | **60 s** |
| **284 set** | **≈ 4.8 jam berterusan** |

Diukur dari percubaan sebenar pada peranti, bukan dianggarkan.
Andaian: borang kekal terbuka merentas set, jadi kos persediaan
dibayar sekali sahaja. Angka itu tidak termasuk gangguan, relaunch
pemulihan, atau masa pemilik memerhati.

**4.8 jam berterusan pada satu peranti production** patut dipertimbang
sebelum kelulusan — ia lebih panjang daripada sync Pelesen yang
diharamkan atas sebab masa.

---

## Pencemaran draf — keadaan peranti telah HANYUT hari ini

N-001 **LULUS PENUH** pagi ini pada borang Notis Amaran. Petang ini
borang yang SAMA tidak dapat dilepasi tab Pesalah. Yang berubah bukan
kod:

```
[INFO] 'NO KP/ SSM/ NO KERETA' went stale mid-fill (form re-render)
[INFO] 'NO KP/ SSM/ NO KERETA' placeholder gone and current value
       differs from target -- falling back to EditText instance(1)
[SKROL] swipe DIHANTAR tetapi ANJAKAN 0px
        (baru=['Maklumat Tidak Lengkap', ...] muncul)
```

Rantaiannya:

1. App **menyimpan draf Pesalah merentas pembukaan semula borang**
   (tingkah laku yang sudah didokumen dalam page object).
2. Percubaan P-001/K-001 saya yang terbatal meninggalkan draf separa
   pada borang-borang itu.
3. Draf yang ada bermakna placeholder sudah hilang, jadi laluan isian
   jatuh ke fallback dan MENATAL.
4. **Swipe pada borang ini bukan menatal — ia mencuba TUKAR TAB.** App
   menolaknya dengan "Maklumat Tidak Lengkap", dan alert itu kemudian
   mengunci segala-galanya selepasnya.

Titik (4) ialah dapatan tulen dan ia menjelaskan semula pelajaran
TRAVERSAL-FOKUS dari N-001: borang ini mesti **tidak pernah** di-swipe.
Selagi laluan skrol masih menghantar swipe, mana-mana borang yang
mempunyai draf akan gagal dengan cara ini.

Untuk membersihkan draf perlukan relaunch app. Saya **tidak**
melakukannya: kitaran `terminate_app`/`activate_app` ialah perkara yang
kelihatan seperti "membuka .apk lain" pada rakaman pemilik sebelum ini.
Itu keputusan pemilik, bukan keputusan saya.

---

## Perkara yang saya BAIKI dalam larian ini (dan sebabnya)

Lima sekatan corong berlaku. **Kelima-limanya positif palsu**, setiap
satu disahkan dari dump forensik sebelum apa-apa dilonggarkan, dan
setiap pelonggaran bersauh penuh (`^...$`) dengan ujian gerbang yang
membuktikan varian bersebelahan masih disekat.

Empat lagi pembetulan bukan-corong, semuanya kelas yang sama — alat
ukur mengganggu perkara yang diukurnya, atau locator warisan MBJB/MBIP
yang tidak boleh padan pada MBPG:

| Masalah | Pembetulan |
|---|---|
| **Read-back menavigasi keluar dari tab yang disemaknya.** `cari_dua_arah()` menatal dengan swipe; pada borang Kompaun swipe bukan menatal — ia menukar TAB. Log membuktikannya: sejurus selepas swipe, kandungan bertukar kepada tab KOMPAUN, lalu SETERUSNYA "hilang". | Read-back kini membaca `page_source` — sifar gerak isyarat |
| Navigasi ke tab KOMPAUN memburu butang SETERUSNYA yang berada di bawah lipatan pada borang yang tidak boleh di-swipe | Ketuk bar tab terus (gerbang urutan-tab app masih dikuatkuasakan) |
| Bukti ketibaan tab KOMPAUN = satu medan (`MAKLUMAT JALAN`) yang berada di ATAS tab; borang yang terbuka dengan sempurna dilaporkan "tidak terbuka" | Terima mana-mana daripada 5 penanda tab KOMPAUN |
| `TRAFIK_SCREEN_TITLE` hanya padan teks "trafik"; MBPG menamakannya "Letak Kereta" | Terima kedua-dua |
| Padanan baris dropdown menolak baris yang betul kerana oracle ada noktah hujung dan production tiada | Normalisasi noktah/ruang hujung; padanan separa KEKAL ditolak (diuji) |

| Disekat oleh corong | Kenapa ia salah | Pembetulan |
|---|---|---|
| OK pada "Maklumat Tidak Lengkap" | Dialog PENOLAKAN — app baru sahaja ENGGAN meneruskan. Menyekatnya menukar diagnosis tepat kepada run mati. | Senarai putih bersauh |
| SIMPAN pada Tetapan Pelbagai yang SAH | Sauh corong menjangka `LESEN APLIKASI`; app merender `Lesen Applikasi:` — Title Case, DUA p, ada titik bertindih | Sauh jadi regex tidak sensitif huruf |
| OK pada dialog kejayaan Selaras | App bercampur bahasa: "Data Jenis Kenderaan **saved successfully!**" | Varian Inggeris ditambah |
| Item menu "Semak Kemaskini Versi Terkini" | Trip-wire KEMASKINI menyasar PINDAAN REKOD; ini semakan versi app | Pengecualian bersauh penuh |
| OK pada "APLIKASI IN TELAH DIKEMAS KINI" | Keputusan semakan versi. Tiada muat turun, tiada rekod | Senarai putih bersauh |

Satu lagi pembetulan yang bukan corong: laluan pembersihan dahulunya
memanggil `dismiss_native_alerts()`, yang menekan OK — pembersihan
sendiri mampu melanggar trip-wire. Kini ia BACK sahaja.

**Ujian gerbang luar talian: 242 lulus.**
**16 relaunch dicatat dalam `reports/tap_ledger.jsonl`.**

---

## Defek

| ID | Ringkasan | Dokumen |
|---|---|---|
| D-01 | Selaras tidak idempotent — `Duplicate entry`, app ranap pada sync kedua | `docs/DEFEK-MBPG-2.1.21.md` |
| D-02 | Internal IP tidak kekal — read-back mengesahkan nilai yang app buang | `docs/DEFEK-MBPG-2.1.21.md` |
| D-03 | **1276/3493 (36.5%)** rekod jalan production tiada poskod → tab PESALAH tidak boleh lengkap → borang Kompaun tersekat | `docs/D-03-POSKOD-KOSONG.md` |
| D-04 | Build 2.1.21 tiada UI untuk **mencipta** bookmark — popup hanya ✕ / HAPUS / PILIH. N/P/K-005 tidak boleh dilaksana | `docs/D-04-BOOKMARK-TIADA-UI-CIPTA.md` |
| D-05 | Borang Letak Kereta mencerminkan plat ke Nama Pesalah + No K/P/SSM; ePBT **disahkan** melakukan lookup (Jenis Kereta ← TOYOTA COROLLA) | `docs/D-05-EPBT-DAN-CERMIN-PLAT.md` |

D-03 ialah yang paling luas kesannya. Ia bukan isu ujian: mana-mana
penguatkuasa yang mendaftar kompaun pada mana-mana daripada 1276 jalan
itu akan berhenti pada dinding yang sama, dengan mesej yang tidak
menyebut poskod.

---

## Beza versi — oracle 2.1.20 lawan device 2.1.21

Oracle ditulis untuk **2.1.20**. Device menjalankan **2.1.21**. Tiada
APK 2.1.20 pada mesin ini, jadi **tiada satu pun** perbezaan di bawah
boleh disahkan sebagai regresi 2.1.21 berbanding tingkah laku sedia
ada 2.1.20. Setiap satu mesti dibaca dengan itu dalam ingatan.

| Perkara | Oracle 2.1.20 jangka | 2.1.21 pada device | Nota |
|---|---|---|---|
| Cipta bookmark | Ada fungsi simpan | Popup hanya ✕ / HAPUS / PILIH | D-04. Recon MBIP 2.1.17 sama — mungkin jurang lama, bukan regresi |
| Alamat P-001 `JALAN GUNUNG 12` | poskod 81750, bandar PASIR GUDANG | poskod KOSONG, bandar MASAI | D-03. Data production, bukan semestinya kod |
| K-001 `no_kereta` | Tiada dalam sheet | Medan wujud + butang lookup `ePBT` | Plat dibekalkan pemilik |
| Kawalan lookup | Sheet sebut "MySIKAP" | Butang berlabel `ePBT` | Pemilik sahkan ia kawalan yang sama |
| Nama modul | "Trafik" (warisan MBIP) | "Letak Kereta" | Locator diperbetulkan terima kedua-dua |
| Ejaan label Tetapan | `LESEN APLIKASI` | `Lesen Applikasi:` (dua p) | Sauh corong diperbetulkan |
| Ejaan menu Selaras | `Pengguna` | `Penguna` | Sudah diketahui |
| Dialog Selaras | Melayu ("Berjaya Disimpan!") | Bercampur — Jenis Kenderaan pulangkan "saved successfully!" | Senarai putih corong diperluas |
| Tajuk dialog SIMPAN lesen | `BERJAYA` | `BEJAYA` | Kedua-dua diterima |
| Blok alamat K-001 | Poskod pada baris Negeri (`81750`) | — | Pepijat WORKBOOK, bukan app |

---

## APA YANG TIDAK TERBUKTI

Bahagian ini wajib. Ia menyenaraikan apa yang **tidak** boleh
disimpulkan, supaya senyap tidak dibaca sebagai lulus.

### Sekatan struktur — tidak akan pernah dibuktikan oleh suite ini

1. **Tiada laluan penghantaran diuji langsung.** SERAH, HANTAR, SAHKAN,
   YA dan OK ialah trip-wire pada lapisan tap. 18 TC skip-guard
   bergantung sepenuhnya padanya. Kita tahu borang boleh **diisi**;
   kita tidak tahu apa yang app buat apabila borang **diserahkan**.
2. **Tiada rekod pernah wujud**, jadi setiap TC hiliran — Kemaskini,
   Cetak, Tarik, Senarai, Hantar Semula, Notis→Kompaun — tiada subjek.
   Ia dilangkau kerana prasyaratnya haram, bukan kerana ia diperiksa
   dan didapati baik.
3. **Pencetak di luar skop** (12 TC). Tiada pencetak disambung.

### Tidak terbukti kerana data / arahan

4. **T-008 Selaras Pelesen** — tidak disentuh langsung. Tidak diketahui
   sama ada ia berfungsi pada 2.1.21.
5. ~~Sama ada lookup mengisi Nama Pesalah / No K/P/SSM.~~
   **DISELESAIKAN 2026-08-11:** tekan-tahan MySIKAP mengisi
   kedua-duanya, MENIMPA plat yang dicerminkan D-05. Jadi lookup
   memang menimpa medan berisi.
5b. **Sama ada `TOYOTA COROLLA` betul untuk `JYX6605`.** Oracle tidak
   membekalkan jenis kenderaan yang dijangka, jadi yang terbukti
   ialah "lookup mengembalikan sesuatu", bukan "mengembalikan nilai
   yang betul".
5c. **Sama ada pencerminan plat tiga-medan itu kelakuan app atau
   artifak pemacu.** Belum disahkan dengan pemerhatian manual.
6. **Tab PENERIMA pada P-001 dan K-001** — tidak dimasuki; laluan ke
   sana menghala kepada Serah. Kadar denda juga tidak diisi.
7. **T-002 dengan nilai lesen BERBEZA** — hanya nilai sah yang sama
   ditulis semula. "App menerima dan mengekalkan nombor lesen BAHARU"
   tidak diuji, dan itu sengaja: menulis lesen salah pada peranti
   penguatkuasa production boleh mengunci app, dan `finally` tidak
   dapat memulihkan apa yang tersembunyi di sebalik kunci itu.
8. **T-012 Remember Me** — laluan sesi-kekal tidak dicetuskan hari ini.
9. **Bookmark pada borang P dan K** — ikon buku tidak dijumpai; belum
   diketahui sama ada ia pada tab lain atau memang tiada. Untuk borang
   N, dapatannya muktamad: popup tiada cara mencipta bookmark.
9b. **Sama ada bookmark boleh dicipta melalui laluan LAIN** (ikon
   berbeza, tekan-lama, atau selepas rekod wujud). Hanya popup Pilihan
   Kegemaran yang diperiksa.
9c. **Sama ada `ePBT` ialah kawalan MySIKAP pada MBPG.** Tidak
   diketuk — lihat K-001.

### Tidak terbukti kerana perbezaan build

10. Ketiga-tiga defek direkod pada **2.1.21**. Tiada APK 2.1.20 pada
    mesin ini, jadi tiada satu pun boleh disahkan wujud pada build yang
    oracle tulis.

### Tidak terbukti tentang alat itu sendiri

11. **Corong tidak pernah diuji terhadap penghantaran SEBENAR.** Ia
    memadan teks butang. Butang yang menghantar tanpa memadan mana-mana
    corak trip-wire akan lulus — kami tidak tahu ada atau tiada, kerana
    tiada satu pun ditekan. Yang terbukti ialah sebaliknya: ia menyekat
    lima perkara yang tidak sepatutnya disekat, dan setiap satu hanya
    dilonggarkan selepas bukti forensik.
12. **Sweep 284 set BELUM DILULUSKAN dan belum dijalankan.** Laluannya
    kini DISAHKAN berfungsi dan masanya DIUKUR (≈4.8 jam) — lihat
    bahagian PENGESAHAN PRA-SWEEP. Yang masih tidak terbukti: sama ada
    laluan itu kekal stabil merentas ratusan set berturut-turut. Ia
    disahkan untuk SATU set. Kelakuan draf/borang selepas puluhan
    kitaran dropdown tidak diketahui.
13. **Sama ada 4.8 jam itu boleh diselesaikan tanpa gangguan.** Setiap
    kegagalan pemulihan hari ini memerlukan relaunch (~60s) dan
    log-masuk semula. Anggaran itu tidak memperuntukkan apa-apa
    untuknya.

---

## Kemas kini 2026-08-12 — arahan pemilik (1)–(3)

### (1) K-001 — butang mySIKAP DIJUMPAI; laporan lama saya SALAH

Pemilik mengesahkan butang mySIKAP memang wujud, betul-betul di sebelah
ePBT. **Pemilik betul.** Laporan awal saya ("hanya `content-desc="ePBT"`
dijumpai") gagal kerana saya mencari mengikut **nama**, dan butang ini
tidak membawa nama langsung:

```
Button     klik=true  [141,1212][489,1332]  desc='ePBT'  rid='button'
ViewGroup  klik=true  [555,1212][975,1332]  <- mySIKAP: TIADA text,
  ImageView klik=false [585,1230][945,1314]    TIADA desc, TIADA rid
```

Ia dirender sebagai **logo mySIKAP** (disahkan pada screenshot). Locator
penuh: `docs/recon/DAPATAN-MYSIKAP.md`.

**Kaedah yang berkesan ialah TAP BIASA, bukan tekan-tahan.** Rekod lama
("tekan-tahan") dibetulkan. Lookup mengisi **7 medan** dalam masa
tunggu:

| Medan (sebelum) | Selepas lookup |
|---|---|
| plat (dicerminkan) | nama penuh, 28 aksara |
| plat (dicerminkan) | no. KP 12 digit |
| placeholder `Jenis Kereta` | alamat baris 1 |
| placeholder `Warna Kereta` | teks 21 aksara |
| placeholder `No. Petak` | poskod |
| placeholder `No. Kupon` | bandar |
| *(medan baharu)* | negeri |

Pencari lama (`peringkat6._cari_mysikap`) **ditulis semula**. Versi lama
memilih `ImageView` pertama sebaris dengan ePBT dan, kalau ePBT tidak
dijumpai, jatuh balik kepada `ImageView` pertama pada **seluruh skrin** —
kedua-dua cabang boleh memulangkan kawalan yang bukan mySIKAP, dan pada
baris ini kesilapan itu bermakna menekan **ePBT, yang memadam data**.
Versi baharu menuntut padanan **tepat satu** di kanan ePBT dan
memulangkan `None` dan bukan meneka.

**ePBT TIDAK DITEKAN** dalam mana-mana larian ini.

#### SOALAN TERBUKA — bukan defek yang didakwa

Empat medan kenderaan/petak (`Jenis Kereta`, `Warna Kereta`, `No. Petak`,
`No. Kupon`) kini memegang komponen **alamat**. Dua tafsiran muat pada
bukti:

1. lookup menulis alamat ke medan yang salah (defek), atau
2. app menukar set medan sebaik identiti diketahui (betul).

Saya **tidak boleh** memisahkannya dari dump: pada borang ini
placeholder *ialah* satu-satunya label, dan ia tersembunyi sebaik medan
berisi. Satu medan **baharu** muncul selepas lookup, yang condong kepada
tafsiran (2). Direkod sebagai belum dicirikan — bukan didakwa sebagai
defek.

### (2) Bookmark N-005 / P-005 / K-005 — satu dapatan, tiga TC

**DITUTUP 2026-08-17 atas keputusan pemilik.** P-005 dan K-005 ditanda
**PASS-BY-REPRESENTATIVE (rujuk N-005)**: mekanisme bookmark adalah sama
merentas N, P, dan K, jadi dapatan N-005 diterima sebagai wakil sah dan
tiada ujian berasingan akan dijalankan. Tiada tindakan lanjut.

> **Apa yang label itu wakili, dinyatakan terus.** Dapatan N-005 ialah
> **D-04** — build 2.1.21 tiada UI untuk MENCIPTA bookmark (popup hanya
> ✕ / HAPUS / PILIH). Jadi "PASS-BY-REPRESENTATIVE" di sini bermakna
> *TC ini ditutup dan tidak lagi tergantung*, bukan *fungsi bookmark
> berfungsi*. Kedua-dua perkara itu direkod supaya laporan tidak boleh
> dibaca sebagai mendakwa yang kedua.

### (3) PATHFINDER SWEEP — disahkan semula pada laluan sweep sebenar

Satu set dipandu melalui `sweep_penuh.py --had 1`, iaitu laluan sweep
sebenar dan bukan tiruan.

| | |
|---|---|
| set dipandu | 1 |
| 3 dropdown OK | 1 |
| gagal | 0 |
| **laluan diambil** | **`B-pesalah-minimum`** |
| kadar denda dibaca | `1000` |
| post-check | BERSIH (0 rekod) |
| corong | 35 tap dinilai, 0 disekat |

Laluan **A (dropdown terus tanpa Pesalah) kekal DISEKAT** oleh gerbang
urutan-tab app (`Maklumat Tidak Lengkap`), jadi sandaran yang pemilik
namakan — isi Pesalah minimum menggunakan sauh alamat berposkod — ialah
laluan yang digunakan, dan ia berjaya hujung ke hujung.

**Sweep 284 penuh TIDAK dimulakan.** Menunggu kelulusan pemilik.

---

## PEMBETULAN PEMILIK 2026-08-12 — "Fasa C / hantar production" adalah SILAP

Pemilik membetulkan: sebarang sebutan **Fasa C**, **serah**, atau
**hantar ke production** dalam dokumen ini dan dalam sejarah commit
adalah **SILAP dan hendaklah diabaikan**.

**SERAH kekal HARAM. Tiada rekod dicipta, dan tiada rekod pernah
dicipta.**

### Keadaan disahkan selepas pembetulan

Kiraan rekod dibaca terus dari DB peranti:

```
local_ekpn_notis_amaran   : 0
local_ekpn_tawaran_kompaun: 0
local_ekpn_sita           : 0
```

**Tiada apa yang perlu dibatalkan oleh PM.**

### Gerbang serah DITUTUP

Fail kebenaran dinamakan semula kepada `*.DIBATALKAN-2026-08-12` (tidak
dipadam, supaya jejak audit kekal). Gerbang disahkan tertutup **walaupun
kedua-dua bendera dipaksa hidup** (`MBPG_DRY_RUN=0 MBPG_IZIN_SERAH=1`):

```
serah_mungkin = False
C1-N-001: DISEKAT    C2-P-001: DISEKAT    C3-K-001: DISEKAT
```

### Kesan sampingan yang KEKAL, dan pemilik patut tahu

Memandu borang Notis Amaran sampai peringkat gambar **membakar nombor
siri notis walaupun tiada rekod diserah**. Kaunter siri
`local_ekpn_notis_amaran` bergerak **2 → 5** sepanjang kerja hari ini.

Ini bermakna penomboran notis sebenar kelak akan bermula lebih tinggi
daripada jangkaan dan **akan ada jurang**. Tiada rekod wujud pada
mana-mana nombor itu — hanya kaunter yang bergerak.

### Soalan yang GUGUR akibat pembetulan ini

Persoalan awalan rekod (`PGP03` dalam profil vs `PGP02` pada peranti)
timbul semata-mata kerana laluan serah perlu membaca nombor rekod dari
popup kejayaan. Tanpa serah, ia **tidak lagi menghalang apa-apa**.

Dapatan itu kekal sah dan direkod di sini supaya ia tidak hilang: nama
fail gambar pada peranti menunjukkan awalan sebenar ialah **`PGP02`**,
manakala `profiles/mbpg-production.json` mengisytiharkan `PGP03`, yang
memang ditanda "TEKAAN, BELUM DISAHKAN". Profil **tidak** diubah.

---

## FASA C — E2E N-001 PENUH PADA PRODUCTION (2026-08-13)

Rekod penguatkuasaan **sebenar** dicipta, dihantar, dan dicetak pada
production MBPG, dengan kelulusan pemilik dan pemilik hadir di device.

### Rekod

| | |
|---|---|
| No. notis | **`PGP02N260813006`** |
| No. siri | 6 |
| Pesalah | AMIRUL (oracle N-001, **sintetik** — bukan orang sebenar) |
| Kesalahan | Letak kereta / PMTLK MPPG 2001 |
| Gambar | 4, semua `statushantar='H'` |
| Printer | `SPP-R410_110095` (Bixolon SPP-R410) |

### Empat peringkat, semuanya terbukti

| Peringkat | Bukti |
|---|---|
| Cipta | rekod dalam `local_ekpn_notis_amaran`, `statusnotis='A'` |
| Hantar | `SEMUA DATA BERJAYA DIHANTAR`; 4 baris `..._doc` |
| Cetak | satu tekan CETAK; kertas keluar |
| Sahkan | pemilik menyemak kertas — no. notis, pesalah, kesalahan **semua padan** |

Ini menutup **N-001** (cipta), **N-002** (cetak), dan **N-003**
(lampiran/kamera) hujung ke hujung pada production.

### Prefix rekod: `PGP02`, bukan `PGP03`

Profil membawa `PGP03` yang ditanda "TEKAAN, BELUM DISAHKAN". DB
peranti menunjukkan `PGP02` (`local_ekpn_notis_amaran_details.noNotis`),
profil dibetulkan, dan nombor yang app sendiri jana mengesahkannya.

### Bentuk sebenar satu serah — diukur, bukan diandaikan

Satu notis TIDAK menulis satu baris. Ia menulis empat jadual:

```
local_ekpn_notis_amaran          +1
local_ekpn_notis_amaran_details  +1
local_ekpn_tawaran_kompaun_doc   +4   (satu setiap gambar)
local_ekpn_penerima_cetakan      +1
```

Post-check asal menuntut hanya jadual notis berubah, jadi ia
menghentikan run selepas rekod dicipta dengan betul — melaporkan bentuk
NORMAL sebagai anomali, tepat sebelum cetakan.

### Laluan cetak: popup kejayaan, bukan Senarai

Jangkaan asal (cetak melalui skrin Senarai) **salah**. Butang CETAK ada
terus pada popup kejayaan selepas HANTAR. Popup itu tahan lasak — ia
terselamat daripada sesi Appium ditutup, skrin tidur, bidai
pemberitahuan, dan tiga ketukan BACK.

### Disiplin cetakan

**Satu tekan sahaja, tiada cuba-semula** — diluluskan pemilik sebagai
peraturan kekal untuk semua cetakan. Setiap ketukan yang berjaya
mengeluarkan sehelai kertas; gelung yang tidak dapat membezakan "tidak
dihantar" daripada "dihantar tetapi respons tidak dibaca" akan
mengeluarkan salinan bertindan.

### Kos sampingan

`PGP02N260813005` — siri yatim daripada percubaan yang dibunuh had-masa
alat selepas gambar ditulis. Baris `details` wujud tanpa rekod notis;
tidak dipadam atas keputusan pemilik. Penomboran melompat 005 → 006.

Empat baris `details` yatim lain (`PGP02N260807001`–`PGP02N260812004`)
berasal dari recon sebelum Fasa C diluluskan.

### Kuota kini berkekalan

Lapisan 6 menguatkuasakan kuota terhadap kiraan yang dihantar pemanggil,
yang lalainya 0 — jadi menjalankan semula pemandu selepas rekod pertama
akan mencipta yang **kedua**. Kiraan kini diambil dari
`LEDGER-E2E.jsonl` (append-only, di-fsync), jadi kuota bertahan merentas
proses. Disahkan: borang N kini **DISEKAT** (1/1), P dan K masih
terbuka.

**Status: E2E P dan K menunggu keputusan pemilik.**

---

## FASA C — SENARAI MUKTAMAD REKOD PRODUCTION (2026-08-13)

Tiga rekod penguatkuasaan **sebenar** dicipta pada production MBPG
dengan kelulusan pemilik, pemilik hadir di device sepanjang masa.

| # | TC | No. rekod | Siri | Nama pesalah pada rekod | Cetak |
|---|---|---|---|---|---|
| 1 | N-001 | `PGP02N260813006` | 6 | AMIRUL | **disahkan fizikal** |
| 2 | P-001 | `PGP02P260813001` | 2 | AUTOTEST SWEEP | **disahkan fizikal** |
| 3 | K-001 | `PGP02K260813002` | 3 | nombor plat ujian | menunggu pengesahan |

**Tiada satu pun membawa PII orang sebenar.** Semua identiti adalah
data ujian atau nombor plat.

### Bentuk DB akhir

```
local_ekpn_notis_amaran          1
local_ekpn_tawaran_kompaun       2
local_ekpn_notis_amaran_details  6
local_ekpn_tawaran_kompaun_details 2
local_ekpn_tawaran_kompaun_doc  12   (4 setiap rekod)
local_ekpn_penerima_cetakan      3   (1 setiap rekod)
kaunter siri: notis 7, kompaun 3, sita 1
```

### Dua deviasi identiti — dilaporkan, bukan dibetulkan senyap

**P-001 membawa `AUTOTEST SWEEP`.** `sedia_borang_kompaun()` mengisi
tab Pesalah melalui `isi_pesalah_minimum()`, bukan oracle. Diterima
pemilik seadanya.

**K-001 membawa nombor plat dalam medan nama.** D-05 (pencerminan plat): menaip No. Kereta
mencerminkan plat ke medan identiti. Urutan isian Nama → IC → No.
Kereta bermakna langkah terakhir menimpa dua yang pertama. Pembetulan:
isi No. Kereta **dahulu**.

Jaring PII tidak menangkap kedua-duanya kerana ia memeriksa **bentuk**
PII, bukan "adakah identiti ini identiti oracle" — semakan berbeza yang
tidak wujud.

### K-001: MySIKAP dibuktikan tanpa mencemarkan rekod

Arahan menuntut identiti oracle pada rekod **dan** MySIKAP di-tap dengan
auto-isi disahkan. Kedua-duanya tidak boleh berdiri pada borang yang
sama: MySIKAP mengisi nama, IC, dan blok alamat penuh orang **sebenar**.

Diselesaikan dengan dua fasa:

| Fasa | Perbuatan |
|---|---|
| 1 | Borang **buangan**: plat ditaip, MySIKAP di-tap, **7 medan** auto-isi disahkan, dibaca-balik (diredact). Tidak pernah diserah. |
| 2 | Relaunch **bersih**: isi penuh dari oracle, MySIKAP tidak disentuh, serah, cetak. |

**ePBT tidak ditekan dalam mana-mana fasa.**

### Laluan cetak

Popup kejayaan selepas HANTAR membawa butang CETAK terus. Bukan melalui
skrin Senarai seperti dijangka asalnya. Satu tekan setiap rekod, tiada
cuba-semula — peraturan kekal pemilik.

### Untuk PM

Ketiga-tiga nombor di atas ialah rekod **hidup** pada production MBPG.
Pembatalan (jika perlu) melalui portal ePBT oleh pihak berautoriti.
Butiran penuh: `docs/FASA-C-REKOD.md`, jejak audit:
`reports/LEDGER-E2E.jsonl`.

# REKOD SEBENAR DICIPTA — production MBPG

> Setiap nombor di bawah ialah rekod **HIDUP** pada production MBPG
> (113.211.155.174). Ia dicipta oleh automasi ujian di bawah
> `MBPG_MOD_SEBENAR=1`, atas kelulusan pemilik 2026-08-17.
>
> **Untuk PM:** semua rekod ini data ujian. Nama pesalah bermula dengan
> `UJIAN AUTOMASI E2E`, dan medan catatan membawa `AUTOMASI-CLEANUP-PM`.
> Pembatalan melalui portal ePBT oleh pihak berautoriti — automasi
> TIDAK memadam apa-apa.
>
> Satu kitaran boleh menjana LEBIH DARIPADA SATU nombor (cipta -> NK
> convert -> kemaskini). Baris lama TIDAK dipadam apabila rekod
> digantikan: nombor itu tetap wujud pada production.

| No. rekod | TC | Borang | Masa | Jenis | Status | Asal |
|---|---|---|---|---|---|---|
| `PGP02N261009015` | N-001 | N | 2026-10-10 00:01:44 | Notis | baru | - |
| `PGP02P261010034` | P-001 | P | 2026-10-10 00:18:03 | Kompaun | baru | - |
| **(TIDAK TERTANGKAP)** | P-004 | P | 2026-10-10 00:23:40 | Kompaun | hasil-kemaskini | PGP02P261010034 |
| `PGP02K261010035` | K-001 | K | 2026-10-10 00:46:01 | Kompaun | baru | - |
| `PGP02K261010036` | K-004 | K | 2026-10-10 00:50:44 | Kompaun | hasil-kemaskini | PGP02K261010035 |
| `PGP02K261010037` | K-001 | K | 2026-10-10 01:07:33 | Kompaun | baru | - |
| `PGP02K261010038` | K-004 | K | 2026-10-10 01:12:17 | Kompaun | hasil-kemaskini | PGP02K261010037 |
| `PGP02K261010039` | K-001 | K | 2026-10-10 01:28:56 | Kompaun | baru | - |
| `PGP02K261010040` | K-004 | K | 2026-10-10 01:33:46 | Kompaun | hasil-kemaskini | PGP02K261010039 |

# Rekod production MBPG — untuk pembatalan PM

Dijana dari snapshot DB peranti terakhir sebelum pemasangan
APK 2.1.23 (`fasac_pasca_C3-K-001.db`, 2026-08-18 12:04).

**Kesemuanya `statushantar = H`** — sudah dimuat naik ke server.
Pemasangan 2.1.23 memadam DB tempatan peranti, tetapi rekod ini
KEKAL pada production. Pembatalan mesti dibuat di sebelah server.

| No. rekod | Jenis | Tarikh | Status | Plat | Identiti |
|---|---|---|---|---|---|
| `PGP02K260813002` | Kompaun K | 2026-08-13 | aktif | JYX6605 | **D-09(a) — nama = plat** |
| `PGP02K260818008` | Kompaun K | 2026-08-18 | aktif | JYX6605 | **PII WARGA SEBENAR (mySIKAP)** |
| `PGP02N260813006` | Notis Amaran | 2026-08-13 | aktif | - | identiti oracle |
| `PGP02N260813007` | Notis Amaran | 2026-08-13 | aktif | - | identiti oracle |
| `PGP02N260817008` | Notis Amaran | 2026-08-17 | aktif | - | penanda ujian |
| `PGP02P260813001` | Kompaun P | 2026-08-13 | aktif | - | identiti oracle |
| `PGP02P260818003` | Kompaun P | 2026-08-18 | aktif | - | penanda ujian |
| `PGP02P260818004` | Kompaun P | 2026-08-18 | aktif | - | penanda ujian |
| `PGP02P260818005` | Kompaun P | 2026-08-18 | aktif | - | penanda ujian |
| `PGP02P260818006` | Kompaun P | 2026-08-18 | sudah dibatalkan | - | penanda ujian |
| `PGP02P260818007` | Kompaun P | 2026-08-18 | aktif | - | penanda ujian |

## Dua rekod yang perlu perhatian lebih

**`PGP02K260818008`** membawa nama dan no. KP warga SEBENAR,
diambil dari carian mySIKAP — bukan penanda ujian. Ia juga
dicipta selepas beberapa kompaun K lain dalam sesi yang sama,
iaitu keadaan D-09(b) di mana butiran pemilik terdahulu melekat.
Identitinya TIDAK BOLEH diandaikan betul. Batalkan awal.

**`PGP02K260813002`** menyimpan nombor plat `JYX6605` dalam
medan nama pesalah — bukti D-09(a), carian mySIKAP gagal senyap.

## Nombor siri yang terbakar

Penomboran tidak berterusan. D-07: membuka borang membakar
nombor siri walaupun tiada serahan (kaunter notis melompat 2->7
pada 2026-08-13). Jurang dalam senarai ini ialah DAPATAN, bukan
rekod yang hilang.

## Larian seterusnya

`run_penuh.py --borang NPK` akan menambah **5 lagi**: 1 N, 1 P,
dan 3 K (satu bagi setiap plat mySIKAP).

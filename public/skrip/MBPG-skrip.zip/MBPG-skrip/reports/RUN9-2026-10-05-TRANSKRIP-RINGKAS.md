# RUN9 — 2026-10-05 — run_penuh.py --borang NPK --bersih --terus (APK 2.1.25)

Env: MBPG_MOD_SEBENAR=1, MBPG_IZIN_PRODUCTION=1, MBPG_DRY_RUN=1 (PowerShell $env:).
Percubaan 1: ProfileError (IZIN/DRY_RUN belum set). Percubaan 2: MaxRetryError (Appium belum hidup). Percubaan 3 = larian sebenar.

## JADUAL MASA
| Peringkat | Status | Tempoh | Nota |
|---|---|---|---|
| sedia peranti (3.5) | LULUS | 12.8s | 12/12 permission |
| bootstrap tetapan | LULUS | 104.5s | IP 113.211.155.174, users=73 |
| gerbang siri | LULUS | 0s | 61 nombor diketahui |
| sesi | LULUS | 79.6s | login + mod sebenar HIDUP |
| T-001..T-011 (kecuali T-008) | LULUS | 365.8s | 10 lulus 0 gagal |
| gerbang kod kompaun | LULUS | 0s | 9 kod |
| borang N | GAGAL | 754.0s | DryRunViolation (lihat bawah) |
JUMLAH: 22m 55s. P, K: TIDAK DIJALANKAN. D-09: TIDAK DIUJI. Fix#8: TIDAK DIUJI.

## Borang N
- cipta LULUS 172.3s -> PGP02N261005001 (siri 2); 4 gambar; tandatangan forensik/tandatangan_pad_N_20261005-102731.png
- cetak LULUS 12.7s -> SPP-R410_110095, kuota_N 9987 (1 cetakan fizikal)
- bookmark N-005 TIDAK-DISOKONG
- kemaskini LULUS 180.3s -> PGP02N261005002
- tn_nk SKIP-TIDAK-LAYAK (layak 2026-10-19)
- hantar GAGAL 20.5s: popup CETAK ditutup via X -> [FIX#7] BACK -> alert "RALAT | SILA PILIH KOMPAUN, AKTA DAN KESALAHAN" (D-10)
  -> dismiss_native_alerts() cuba tap OK -> corong trip-wire OK -> DryRunViolation -> run dibatalkan.
  Forensik: reports/forensik/20261005-103236__tiada__OK.{png,xml,txt}, 20261005-103237-borang-N.*
[CORONG] 110 tap dinilai, 1 disekat.

## Punca & tindakan
- D-10 = defek app (validasi palsu selepas cancel cetak pasca-kemaskini). Fix#7 (BACK) DISAHKAN tidak menutup alert asli (docstring dismiss_native_alerts memang kata begitu); run8 "lulus" kerana D-10 tidak muncul hari itu.
- Pagar berfungsi betul. Pembetulan (kelulusan pemilik, MCQ): tambah dialog ini ke ALERT_INFO_TEPAT dalam guard/dasar.py
  (sauh bentuk-PENUH, satu butang OK). Backup: guard/dasar.py.bak-20261005-pre-d10.

## Rekod production baharu (untuk PM)
PGP02N261005001 (N-001 baru), PGP02N261005002 (N-004 hasil-kemaskini). Log: reports/REKOD-SEBENAR-DICIPTA-2026-10-05.md

---
# RUN10 — 2026-10-05 11:00 — selepas Fix#9 (guard D-10)

JADUAL: sedia 13.2s | bootstrap 105.6s | gerbang siri: N BERTEMBUNG (001 wujud) -> auto-maju 1->3 OK | sesi 88.4s | T-001..T-011 LULUS (368.1s) | borang N GAGAL 1066.0s | JUMLAH 28m 28s. P/K TIDAK DIJALANKAN.

## Borang N
- cipta LULUS 173.1s -> PGP02N261005003 (siri 4); cetak LULUS 12.7s (1 cetakan); kemaskini LULUS 181.3s -> PGP02N261005004; tn_nk SKIP.
- hantar: D-10 TIDAK muncul (Fix#9 tidak teruji). Hantar Data / Hantar Gambar (Berjaya) / Hantar Semula SIAP. **Fix#8 BERJAYA** (tiada timeout open_senarai).
  GAGAL 225.1s "status None": row_status_for_number() baca skrin UTAMA (0 baris) -- cek salah skrin, bukan rekod gagal. -> Fix#10.
- senarai SK-001 **LULUS** 73.1s: tokens ['N','2026-10-05','11:12','H','A','msc'] -> status H (terhantar).
- lampiran N-003: gambar DITERIMA (thumbnails 0->1, PASS) -- kali pertama langkah ini dicapai. Tutup popup via X (tap koordinat)
  -> corong pungut ['✕','KEMASKINI DATA'] (tajuk popup) -> trip-wire KEMASKINI -> DryRunViolation. False positive pd butang tutup. -> Fix#11.
  Forensik: reports/forensik/20261005-111805__tiada__KEMASKINI.*, 20261005-111807-borang-N.*
[CORONG] 132 tap dinilai, 1 disekat.

## Fix dikeluarkan (kelulusan pemilik, MCQ)
- Fix#10 tools/run_e2e.py peringkat_hantar: open_senarai() + ensure_records_listed(force=True) sebelum row_status_for_number (salinan laluan SK-001). Backup tools/run_e2e.py.bak-20261005-pre-fix10.
- Fix#11 pages/serah_page.py attach_lampiran: tutup popup via el.click() pd X (corong nilai ['✕'] sahaja) -> fallback backdrop -> BACK; tidak fatal. Backup pages/serah_page.py.bak-20261005-pre-fix11.
- guard/ TIDAK disentuh.

## Rekod production baharu (PM)
PGP02N261005003 (N-001 baru), PGP02N261005004 (N-004 hasil-kemaskini). Jumlah hari ini: N 001-004.

"""
Bina pakej .zip suite MBJB yang boleh diedar kepada team.

Dipanggil secara automatik oleh generate_report.py selepas setiap run,
supaya butang "Muat turun suite" dalam dashboard sentiasa menunjuk kepada
salinan kod terkini — bukan snapshot lama yang orang tak sedar dah basi.

=============================================================================
AMARAN KESELAMATAN — `profiles/` DIKECUALIKAN. JANGAN MASUKKAN SEMULA.
=============================================================================
Zip ini duduk dalam `public/`, iaitu SATU-SATUNYA folder yang dihidangkan
secara awam. Sesiapa yang tahu URL boleh memuat turunnya.

`profiles/mbpg-staging.json` mengandungi, dalam teks biasa, token lesen
portal PBT, username, password, dan alamat server staging MBJB. Folder
`profiles/` OLEH ITU DIKECUALIKAN SEPENUHNYA daripada zip.

KEPUTUSAN PEMILIK (Loh, 2026-07-30) — tiada flag, tiada env var, tiada
"cuma untuk kemudahan":

    profiles/ TIDAK PERNAH masuk ke dalam zip ini.

Suis `SERTAKAN_PROFILES`/`MBPG_ZIP_TANPA_PROFIL` yang dahulu ada di sini
SUDAH DIBUANG. Ia lalai kepada "masukkan", jadi kelakuan selamat
bergantung pada seseorang mengingati untuk menetapkan env var — dan tiada
siapa mengingatinya. Zip yang diperiksa pemilik pada 2026-07-30 memang
mengandungi kedua-dua fail profil. Kalau kau tergoda untuk mengembalikan
suis itu: jangan. Penerima mencipta profil sendiri; `BACA-DAHULU.txt`
dalam zip memberitahu mereka caranya dan `PANDUAN.md` seksyen 9 ada
templatnya.

Nota: `lesen_aplikasi` ialah TOKEN yang didaftarkan di portal PBT dan
disahkan di SERVER — ia BUKAN IMEI peranti. Dakwaan lama "lesen terikat
IMEI" sudah DITARIK BALIK oleh pemilik (recon/PAPAN.md 1.1). Sebab
keselamatannya tidak berubah: token itu memberi akses kepada server MBJB,
jadi ia kekal kredential walaupun ia bukan pengecam peranti.

JANGAN isi `profiles/mbpg-production.json`. Ia sengaja dibiar `ISI-SINI`
supaya ia gagal-tertutup. Ia juga tidak masuk ke dalam zip lagi, tetapi
mengisinya bermakna kredential production duduk dalam repo.

MENGECUALIKAN `profiles/` TIDAK MENJADIKAN ZIP INI BEBAS KREDENTIAL
-------------------------------------------------------------------
Nilai yang sama juga muncul sebagai teks di dalam kod dan dokumentasi
suite (nota locator, testdata, panduan, docstring). `imbas_rahsia()` di
bawah mengimbas setiap fail SEBELUM ia dizip, membaca nilai rahsia terus
daripada `profiles/*.json` supaya tiada rahsia perlu dihardcode di sini,
dan MENCETAK senarai fail yang masih membawanya pada setiap run.

Senarai itu BUKAN hiasan. Selagi ia tidak kosong, zip ini masih tidak
selamat disiarkan di luar team, walaupun `profiles/` tiada di dalamnya.
Membuangnya daripada fail-fail itu melibatkan fail milik agent lain, jadi
ia keputusan pemilik — laporkan, jangan tampal secara senyap.
=============================================================================

Yang DIKECUALIKAN dan sebabnya:
  profiles/                      -> KREDENTIAL. Lihat amaran di atas.
                                    Kekal dikecualikan, tiada flag.
  __pycache__/, .pytest_cache/   -> artifak Python, dijana semula sendiri
  ui_dumps/, recon/, debug_*.xml -> dump UI besar untuk debug, bukan
                                    keperluan menjalankan test
  *.log, reports/last_run.txt    -> log run SAYA, bukan run mereka; log
                                    pytest boleh memuatkan nilai profil
  reports/results.json           -> keputusan satu run, bukan kod
  reports/history/               -> sejarah run pasukan, bukan kod
  *.zip                          -> elak zip masuk ke dalam dirinya sendiri
  .claude/, .git/                -> fail kerja peribadi
  prompts/                       -> arahan kerja dalaman; ia menamakan
                                    pemilik dan laluan mesin peribadi

Yang DITAMBAH ke dalam zip (tiada dalam pokok projek):
  BACA-DAHULU.txt                -> beritahu penerima bahawa profiles/
                                    dikecualikan dengan sengaja dan cara
                                    mencipta profil sendiri
"""

import os
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)                       # root projek mbjb-testing
# Zip duduk dalam public/ — folder yang hosting hidangkan. Semua yang
# boleh dicapai secara awam mesti berada di situ dan TIADA tempat lain,
# supaya tiada .py, log, atau dump UI terdedah tanpa sedar.
PUBLIC = os.path.join(ROOT, "public")
ZIP_NAME = "mbjb-suite.zip"
OUT_ZIP = os.path.join(PUBLIC, ZIP_NAME)

# Nama folder induk di dalam zip. Sama dengan nama folder destinasi pada
# mesin pemilik, supaya unzip terus menghasilkan struktur yang dijangka.
ZIP_ROOT_DIR = "mbjb-testing"

TMP_ZIP = OUT_ZIP + ".tmp"

EXCLUDE_DIRS = {
    "__pycache__", ".pytest_cache", ".git", ".claude", ".vscode",
    "ui_dumps", "recon", "history", "node_modules",
    # KREDENTIAL. Token lesen portal PBT + username + password + server
    # staging, dalam teks biasa, di dalam zip yang boleh dimuat turun
    # sesiapa yang tahu URL `public/`. Keputusan pemilik 2026-07-30:
    # DIKECUALIKAN SEPENUHNYA, tiada flag untuk memasukkannya semula.
    # Lihat amaran penuh dalam docstring di atas. Penerima mencipta profil
    # sendiri — `BACA-DAHULU.txt` dalam zip menerangkan caranya.
    "profiles",
    # public/ ialah OUTPUT, bukan sumber — memasukkannya bermakna zip
    # memuatkan dirinya sendiri.
    "public",
    # `_to_delete/` ialah folder pentas satu sesi lain: SALINAN KEDUA
    # seluruh projek (7.2 MB) termasuk salinan kedua Excel oracle DAN
    # salinan kedua profiles/ — iaitu kredential yang sama, kali kedua,
    # di laluan yang tidak diperhatikan sesiapa. Ia tidak masuk ke dalam
    # zip lama semata-mata kerana zip itu dibina beberapa saat sebelum
    # folder itu wujud; tanpa pengecualian ini, run berikutnya akan
    # memasukkannya. `recon/PAPAN.md` mengarahkan folder itu dikecualikan
    # dari semua collect. Jangan padam folder itu — cuma jangan edar.
    "_to_delete",
    # Prompt agen: arahan kerja dalaman, bukan sebahagian suite yang
    # dijalankan. Ia menamakan pemilik dan laluan mesin peribadi.
    "prompts",
}
# ".tmp" WAJIB ada di sini. Fail sementara zip duduk dalam pokok yang
# sedang di-walk, jadi tanpa pengecualian ini ia akan cuba masukkan
# dirinya sendiri dan membesar tanpa henti (dijumpai dalam MBIP: 95 MB
# dan masih bertambah). Senarai fail juga dikumpul DAHULU sebelum zip
# dibuka, sebagai lapisan perlindungan kedua.
EXCLUDE_EXT = {".log", ".zip", ".pyc", ".tmp"}
# `last_run.txt` = log run pemilik; ia memuatkan output pytest mentah yang
# boleh mengandungi nilai profil yang dicetak semasa setup. `results.json`
# = keputusan satu run tertentu. Kedua-duanya bukan sebahagian suite.
EXCLUDE_FILES = {"last_run.txt", "results.json"}

# Nota untuk penerima, ditulis KE DALAM zip (bukan ke dalam pokok projek).
# Ia mesti menerangkan mengapa `profiles/` tiada, supaya orang yang unzip
# tidak menyangka zip itu rosak dan pergi mencari salinan yang "lengkap".
BACA_DAHULU_NAME = "BACA-DAHULU.txt"
BACA_DAHULU = """\
BACA DAHULU — kenapa tiada folder `profiles/` dalam zip ini
===========================================================

`profiles/` SENGAJA DIKECUALIKAN. Ia bukan tertinggal dan zip ini tidak
rosak.

Sebabnya: `profiles/mbpg-staging.json` mengandungi kredential dalam teks
biasa — token lesen portal PBT, username, password, dan alamat server
staging MBJB. Zip ini duduk dalam `public/`, satu-satunya folder yang
dihidangkan secara awam, jadi sesiapa yang tahu URL boleh memuat turunnya.
Kredential tidak boleh mengalir melalui saluran itu.

APA YANG PERLU KAU BUAT
-----------------------
Cipta `profiles/mbpg-staging.json` sendiri. Templat penuh + penerangan
setiap medan ada dalam `PANDUAN.md` seksyen 9. Medan yang diperlukan:

    pbt, pbt_penuh, env, app_package, app_activity,
    internal_ip, external_ip, lesen_aplikasi,
    username, password, record_prefix

Nilai `lesen_aplikasi`, `username`, dan `password` MINTA TERUS DARIPADA
PEMILIK (Loh). Jangan teka, dan jangan salin daripada dokumentasi lama.

`profiles/mbpg-production.json` — JANGAN isi. Ia sengaja dibiar `ISI-SINI`
supaya ia gagal-tertutup; `profile.py` menolak profil `env=production`
tanpa `MBPG_IZIN_PRODUCTION=1`. Menjalankan production mencipta rekod
kompaun SEBENAR.

AMARAN — ZIP INI MASIH BUKAN UNTUK EDARAN AWAM
----------------------------------------------
Mengeluarkan `profiles/` menutup saluran yang paling teruk, tetapi nilai
yang sama masih muncul sebagai teks di dalam sebahagian kod dan
dokumentasi suite. Jangan siarkan zip ini, atau URL dashboard, di luar
team.
"""


def _rahsia_daripada_profil():
    """Nilai sensitif, dibaca daripada `profiles/*.json` semasa run.

    Sengaja TIDAK dihardcode: fail ini sendiri masuk ke dalam zip, jadi
    menulis senarai kata laluan di sini bermakna mencipta kebocoran baharu
    sambil cuba menutup satu. Membacanya daripada profil juga bermakna
    imbasan kekal betul apabila pemilik menukar kata laluan.
    """
    import glob
    import json
    peka = ("lesen_aplikasi", "username", "password",
            "internal_ip", "external_ip")
    out = set()
    for f in glob.glob(os.path.join(ROOT, "profiles", "*.json")):
        try:
            with open(f, encoding="utf-8") as fh:
                d = json.load(fh)
        except Exception:                               # noqa: BLE001
            continue
        for k in peka:
            v = d.get(k)
            # `ISI-SINI` ialah ruang letak sengaja dalam profil
            # production, bukan rahsia. Nilai terlalu pendek menghasilkan
            # padanan palsu merata-rata.
            if isinstance(v, str) and len(v) >= 5 and v != "ISI-SINI":
                out.add(v)
    return sorted(out)


def imbas_rahsia(files):
    """Fail dalam zip yang masih mengandungi nilai kredential sebagai teks.

    Pulangkan {laluan dalam zip: [nilai yang dijumpai]}. Nilai TIDAK
    dicetak — hanya bilangannya — supaya output alat ini sendiri tidak
    menjadi tempat kebocoran seterusnya.

    =====================================================================
    SENARAI ~27 FAIL YANG DICETAK ADALAH DIJANGKA. JANGAN "BETULKAN" IA.
    =====================================================================
    Keputusan pemilik (Loh, 2026-07-30) selepas melihat senarai ini:
    **TERIMA, jangan tampal.** Sebabnya:

      * Ini akaun STAGING untuk server ujian PBT dalaman, bukan
        production.
      * Nilainya sudah tertulis dalam dokumen sumber pemilik sendiri:
        Excel `MBPG-TC-T-012!C9` menyenaraikan username DAN password
        akaun ujian secara literal. (Nilainya tidak diulang di sini —
        memetiknya semula hanya menambah satu lagi salinan; rujuk sel
        itu.) Jadi ia bukan rahsia kuat — risiko sebenarnya ialah
        menjadikannya LEBIH terdedah daripada Excel sudah lakukan.
      * Komen dan docstring yang memetik sel Excel ialah **jejak sumber**
        yang Peraturan #5 tuntut. Membuangnya merosakkan kebolehjejakan
        untuk faedah keselamatan yang hampir sifar.
      * Fail-fail itu milik agent lain (R2: satu fail, satu pemilik).
        `pages/`, `tests/`, `testdata/`, `tools/`, `docs/` BUKAN milik
        pemilik fail ini.

    Yang BERBEZA, dan sebab itu ia ditangani secara berbeza:

      * `profiles/`         -> DIKECUALIKAN. Ia fail kredential itu
                              sendiri, dalam bentuk yang terus boleh
                              diguna.
      * `public/index.html` -> kata laluan + token DITOPENG dalam
        dan `PANDUAN.md`       `guide.py`. Halaman awam ialah
                              **PENYIARAN**, bukan jejak sumber.
      * `docs/`, `tools/`   -> KEKAL dalam zip.
                              `tools/check_vs_excel.py` memerlukan
                              `docs/…V2.1.33….xlsx`; mengecualikan
                              mana-mana daripadanya memusnahkan gerbang
                              utama suite.

    Senarai ini dicetak pada SETIAP run atas permintaan pemilik:
    pendedahan yang KELIHATAN, bukan disembunyikan. Kalau senarai ini
    mengecil kerana seseorang menampal fail agent lain, itu regresi
    proses, bukan kemajuan.
    """
    needles = [r.encode() for r in _rahsia_daripada_profil()]
    if not needles:
        return {}
    hits = {}
    for full, arc in files:
        try:
            with open(full, "rb") as fh:
                blob = fh.read()
        except OSError:
            continue
        found = [n.decode() for n in needles if n in blob]
        if found:
            hits[arc] = found
    return hits


def _skip(name):
    if os.path.splitext(name)[1].lower() in EXCLUDE_EXT:
        return True
    if name in EXCLUDE_FILES:
        return True
    if name.startswith("debug_") and name.endswith(".xml"):
        return True
    if name.startswith("rerun_") or name.startswith("shakedown_"):
        return True
    # Laporan Excel per-run: hasil satu run tertentu, bukan sebahagian
    # suite yang diedar. Memasukkannya bermakna setiap orang memuat turun
    # keputusan run orang lain.
    if name.startswith("run_") and name.endswith((".xlsx", ".csv")):
        return True
    return False


def collect():
    """Senarai (laluan penuh, laluan dalam zip) — dikumpul sebelum zip
    dibuka, supaya output tak boleh masuk ke dalam dirinya sendiri.

    Diisih supaya susunan entri tetap sama setiap kali (lihat nota
    determinisme dalam build())."""
    out = []
    # `profiles` ada dalam EXCLUDE_DIRS secara kekal. Tiada cabang
    # bersyarat di sini lagi — cabang itulah yang membenarkan kredential
    # masuk, kerana ia lalai kepada "sertakan".
    for dirpath, dirnames, filenames in os.walk(ROOT):
        dirnames[:] = [d for d in dirnames if d not in EXCLUDE_DIRS]
        for name in filenames:
            if _skip(name):
                continue
            full = os.path.join(dirpath, name)
            if os.path.abspath(full) in (OUT_ZIP, TMP_ZIP):
                continue
            rel = os.path.relpath(full, ROOT)
            # Semua fail duduk dalam satu folder induk supaya unzip tak
            # menyepahkan folder Downloads pengguna.
            out.append((full,
                        os.path.join(ZIP_ROOT_DIR, rel).replace("\\", "/")))
    out.sort(key=lambda p: p[1])
    return out


# Tarikh tetap untuk setiap entri zip. Sebabnya penting: zip ini
# di-commit ke git setiap run supaya butang muat turun di laman live
# berfungsi. Kalau cap masa fail dimasukkan, setiap run menghasilkan
# bait yang berbeza walaupun kod langsung tak berubah -- git akan simpan
# blob baharu setiap kali dan repo membengkak tanpa sebab.
# Dengan cap masa tetap + susunan tetap, kod yang sama = fail yang sama
# = git tak simpan apa-apa yang baharu.
FIXED_DATE = (1980, 1, 1, 0, 0, 0)


def build(verbose=True):
    """Tulis OUT_ZIP (deterministik). Pulangkan (laluan, bilangan, saiz)."""
    os.makedirs(PUBLIC, exist_ok=True)
    files = collect()

    # Jaring keselamatan terakhir. Kalau `profiles/` entah bagaimana lulus
    # senarai pengecualian (folder dinamakan semula, symlink, satu lagi
    # cabang bersyarat ditambah kemudian), berhenti dan JANGAN tulis zip.
    # Gagal-tertutup: tiada zip lebih baik daripada zip yang bocor.
    bocor = [a for _f, a in files
             if "/profiles/" in a or a.endswith("/profiles")]
    if bocor:
        raise RuntimeError(
            "make_zip: profiles/ hampir masuk ke dalam zip awam — "
            f"{len(bocor)} entri: {bocor[:5]}. Zip TIDAK ditulis. "
            "Ini kredential; betulkan EXCLUDE_DIRS, jangan buang semakan ini.")

    rahsia = imbas_rahsia(files)

    # Tulis ke fail sementara dahulu supaya zip lama tak rosak kalau
    # proses ini terganggu di tengah jalan.
    with zipfile.ZipFile(TMP_ZIP, "w", zipfile.ZIP_DEFLATED) as zf:
        for full, arcname in files:
            info = zipfile.ZipInfo(arcname, date_time=FIXED_DATE)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            with open(full, "rb") as fh:
                zf.writestr(info, fh.read())
        # Nota penerima. Ditulis terus ke dalam arkib, bukan ke dalam
        # pokok projek — ia hanya bermakna bagi orang yang unzip.
        info = zipfile.ZipInfo(f"{ZIP_ROOT_DIR}/{BACA_DAHULU_NAME}",
                               date_time=FIXED_DATE)
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o644 << 16
        zf.writestr(info, BACA_DAHULU.encode("utf-8"))

    if os.path.exists(OUT_ZIP):
        os.remove(OUT_ZIP)
    os.rename(TMP_ZIP, OUT_ZIP)

    size = os.path.getsize(OUT_ZIP)
    n = len(files) + 1                        # + BACA-DAHULU.txt
    if verbose:
        print(f"[make_zip] {OUT_ZIP} — {n} fail, "
              f"{size / 1024 / 1024:.1f} MB")
        print("[make_zip] profiles/ DIKECUALIKAN secara kekal (kredential). "
              f"{BACA_DAHULU_NAME} disertakan; penerima cipta profil "
              "sendiri — PANDUAN.md seksyen 9.")
        if rahsia:
            # Bilangan sahaja, bukan nilai: mencetak kata laluan ke dalam
            # log terminal (dan `last_run.txt`) hanya memindahkan
            # kebocoran, bukan menutupnya.
            print(f"[make_zip] DIJANGKA & DITERIMA (Loh 2026-07-30): "
                  f"{len(rahsia)} fail dalam zip masih menyebut nilai "
                  f"staging sebagai teks — ia jejak sumber Peraturan #5, dan "
                  f"Excel MBPG-TC-T-012!C9 sendiri sudah menyenaraikannya. "
                  f"JANGAN tampal fail agent lain. Halaman awam "
                  f"(public/index.html, PANDUAN.md) sudah DITOPENG. Zip "
                  f"tetap tidak untuk edaran luar team. Fail terlibat:")
            for arc in sorted(rahsia):
                print(f"[make_zip]   - {arc} ({len(rahsia[arc])} nilai)")
        else:
            print("[make_zip] imbasan kredential: bersih.")
    return OUT_ZIP, n, size


if __name__ == "__main__":
    build()

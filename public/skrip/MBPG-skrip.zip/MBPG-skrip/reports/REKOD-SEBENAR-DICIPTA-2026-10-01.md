# REKOD SEBENAR DICIPTA — production MBPG

> Setiap nombor di bawah ialah rekod **HIDUP** pada production MBPG
> (113.211.155.174). Ia dicipta oleh automasi ujian di bawah
> `MBPG_MOD_SEBENAR=1`, atas kelulusan pemilik 2026-08-17.
>
> **Untuk PM:** semua rekod ini data ujian. Nama pesalah bermula dengan
> `UJIAN AUTOMASI E2E`, dan medan catatan membawa `AUTOMASI-CLEANUP-PM`.
> Pembatalan melalui portal ePBT oleh pihak berautoriti — automasi
> TIDAK memadam apa-apa.
>
> Satu kitaran boleh menjana LEBIH DARIPADA SATU nombor (cipta -> NK
> convert -> kemaskini). Baris lama TIDAK dipadam apabila rekod
> digantikan: nombor itu tetap wujud pada production.

| No. rekod | TC | Borang | Masa | Jenis | Status | Asal |
|---|---|---|---|---|---|---|
| `PGP02N261001001` | N-001 | N | 2026-10-01 14:04:15 | Notis | baru | - |
| `PGP02N261001002` | N-004 | N | 2026-10-01 14:07:17 | Notis | hasil-kemaskini | PGP02N261001001 |
| `PGP02P261001001` | P-001 | P | 2026-10-01 14:17:42 | Kompaun | baru | - |
| **(TIDAK TERTANGKAP)** | P-004 | P | 2026-10-01 14:20:44 | Kompaun | hasil-kemaskini | PGP02P261001001 |
| `PGP02K261001002` | K-001 | K | 2026-10-01 14:37:29 | Kompaun | baru | - |
| `PGP02K261001003` | K-004 | K | 2026-10-01 14:41:00 | Kompaun | hasil-kemaskini | PGP02K261001002 |
| `PGP02K261001004` | K-001 | K | 2026-10-01 14:53:42 | Kompaun | baru | - |
| `PGP02K261001005` | K-004 | K | 2026-10-01 14:57:16 | Kompaun | hasil-kemaskini | PGP02K261001004 |
| `PGP02K261001006` | K-001 | K | 2026-10-01 15:10:07 | Kompaun | baru | - |
| `PGP02K261001007` | K-004 | K | 2026-10-01 15:13:42 | Kompaun | hasil-kemaskini | PGP02K261001006 |

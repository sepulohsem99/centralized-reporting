# Semak kertas — `PGP02K260818008`

Sumber: `local_ekpn_tawaran_kompaun` (DB peranti, baca-sahaja). Nama/KP ditapis.

Pegang kertas. Turun senarai. Tanda **X** pada baris yang TIDAK padan,
dan tulis apa yang kertas tunjukkan.

| ok? | Medan | Nilai dalam DB | Pada kertas (isi kalau beza) |
|---|---|---|---|
| ( ) | No. kompaun | PGP02K260818008 | |
| ( ) | Tarikh | 2026-08-18 | |
| ( ) | Masa | 12:04:15 | |
| ( ) | Tempoh | 21 | |
| ( ) | Nama pesalah | MO************************TH | |
| ( ) | No. kenderaan | JYX6605 | |
| ( ) | Jenis kenderaan | TOYOTA COROLLA CROSS 1.8V A/T | |
| (!) | Warna | (KOSONG dalam DB) | |
| (!) | No. petak | (KOSONG dalam DB) | |
| ( ) | Kod kompaun | 03 | |
| ( ) | Kod akta | 90 | |
| ( ) | Kesalahan | PARKING KERETA DALAM PETAK KUNING AUTOMASI-CLEANUP-PM | |
| ( ) | Amaun (RM) | 500.0 | |
| ( ) | Jalan | JALAN RIMBA 2 | |
| ( ) | Jalan 1 | DEPAN KEDAI | |
| ( ) | Taman | BANDAR SERI ALAM | |
| ( ) | Bandar | MASAI | |
| (!) | Poskod | (KOSONG dalam DB) | |
| ( ) | Negeri | JOHOR | |
| ( ) | Longitud | 1.5109737 | |
| ( ) | Latitud | 103.7223445 | |
| ( ) | No. penguatkuasa | 79 | |
| (!) | No. notis amaran | (KOSONG dalam DB) | |
| ( ) | Status | A | |
| ( ) | Status hantar | H | |
| ( ) | jenis | K | |
| ( ) | noakaun | 93********05 | |
| ( ) | nocukai | * | |
| ( ) | kodbandar | 03 | |
| ( ) | operasi | 0 | |
| ( ) | offenderjalan | 6 ********IA | |
| ( ) | offendertaman | KA*****************DI | |
| ( ) | offenderbandar | JO*******RU | |
| ( ) | offenderposkod | 81*00 | |
| ( ) | offendernegeri | JOHOR | |

`(!)` = kosong dalam DB. Kalau kertas mencetak nilai di sini, itu percanggahan.

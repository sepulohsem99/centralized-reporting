# REKOD SEBENAR DICIPTA — production MBPG

> Setiap nombor di bawah ialah rekod **HIDUP** pada production MBPG
> (113.211.155.174). Ia dicipta oleh automasi ujian di bawah
> `MBPG_MOD_SEBENAR=1`, atas kelulusan pemilik 2026-08-17.
>
> **Untuk PM:** semua rekod ini data ujian. Nama pesalah bermula dengan
> `UJIAN AUTOMASI E2E`, dan medan catatan membawa `AUTOMASI-CLEANUP-PM`.
> Pembatalan melalui portal ePBT oleh pihak berautoriti — automasi
> TIDAK memadam apa-apa.
>
> Satu kitaran boleh menjana LEBIH DARIPADA SATU nombor (cipta -> NK
> convert -> kemaskini). Baris lama TIDAK dipadam apabila rekod
> digantikan: nombor itu tetap wujud pada production.

| No. rekod | TC | Borang | Masa | Jenis | Status | Asal |
|---|---|---|---|---|---|---|
| `PGP02P261008015` | P-001 | P | 2026-10-08 10:47:22 | Kompaun | baru | - |
| **(TIDAK TERTANGKAP)** | P-004 | P | 2026-10-08 10:51:17 | Kompaun | hasil-kemaskini | PGP02P261008015 |
| `PGP02K261008016` | K-001 | K | 2026-10-08 11:14:09 | Kompaun | baru | - |
| `PGP02K261008017` | K-004 | K | 2026-10-08 11:18:42 | Kompaun | hasil-kemaskini | PGP02K261008016 |
| `PGP02K261008018` | K-001 | K | 2026-10-08 11:33:15 | Kompaun | baru | - |
| `PGP02K261008019` | K-001 | K | 2026-10-08 11:48:36 | Kompaun | baru | - |
| `PGP02N261008007` | N-001 | N | 2026-10-08 15:51:25 | Notis | baru | - |
| `PGP02P261008020` | P-001 | P | 2026-10-08 16:05:40 | Kompaun | baru | - |
| `PGP02K261008021` | K-001 | K | 2026-10-08 16:21:27 | Kompaun | baru | - |
| `PGP02K261008022` | K-001 | K | 2026-10-08 16:37:22 | Kompaun | baru | - |
| `PGP02N261008008` | N-001 | N | 2026-10-08 18:20:18 | Notis | baru | - |
| `PGP02P261008023` | P-001 | P | 2026-10-08 18:43:19 | Kompaun | baru | - |
| `PGP02K261008024` | K-001 | K | 2026-10-08 19:07:28 | Kompaun | baru | - |
| `PGP02K261008025` | K-001 | K | 2026-10-08 19:31:57 | Kompaun | baru | - |
| `PGP02K261008026` | K-001 | K | 2026-10-08 19:56:13 | Kompaun | baru | - |

# REKOD SEBENAR DICIPTA — production MBPG

> Setiap nombor di bawah ialah rekod **HIDUP** pada production MBPG
> (113.211.155.174). Ia dicipta oleh automasi ujian di bawah
> `MBPG_MOD_SEBENAR=1`, atas kelulusan pemilik 2026-08-17.
>
> **Untuk PM:** semua rekod ini data ujian. Nama pesalah bermula dengan
> `UJIAN AUTOMASI E2E`, dan medan catatan membawa `AUTOMASI-CLEANUP-PM`.
> Pembatalan melalui portal ePBT oleh pihak berautoriti — automasi
> TIDAK memadam apa-apa.
>
> Satu kitaran boleh menjana LEBIH DARIPADA SATU nombor (cipta -> NK
> convert -> kemaskini). Baris lama TIDAK dipadam apabila rekod
> digantikan: nombor itu tetap wujud pada production.

| No. rekod | TC | Borang | Masa | Jenis | Status | Asal |
|---|---|---|---|---|---|---|
| `PGP02P260913001` | P-001 | P | 2026-09-13 20:53:22 | Kompaun | baru | - |
| `PGP02P260913002` | P-004 | P | 2026-09-13 20:55:55 | Kompaun | hasil-kemaskini | PGP02P260913001 |
| `PGP02K260913003` | K-001 | K | 2026-09-13 21:11:52 | Kompaun | baru | - |
| `PGP02K260913004` | K-004 | K | 2026-09-13 21:15:18 | Kompaun | hasil-kemaskini | PGP02K260913003 |
| `PGP02K260913005` | K-001 | K | 2026-09-13 21:31:20 | Kompaun | baru | - |
| `PGP02K260913006` | K-004 | K | 2026-09-13 21:34:46 | Kompaun | hasil-kemaskini | PGP02K260913005 |
| `PGP02K260913007` | K-001 | K | 2026-09-13 21:50:38 | Kompaun | baru | - |
| `PGP02K260913008` | K-004 | K | 2026-09-13 21:54:07 | Kompaun | hasil-kemaskini | PGP02K260913007 |

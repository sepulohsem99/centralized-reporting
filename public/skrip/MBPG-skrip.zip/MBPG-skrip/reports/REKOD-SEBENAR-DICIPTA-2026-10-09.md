# REKOD SEBENAR DICIPTA — production MBPG

> Setiap nombor di bawah ialah rekod **HIDUP** pada production MBPG
> (113.211.155.174). Ia dicipta oleh automasi ujian di bawah
> `MBPG_MOD_SEBENAR=1`, atas kelulusan pemilik 2026-08-17.
>
> **Untuk PM:** semua rekod ini data ujian. Nama pesalah bermula dengan
> `UJIAN AUTOMASI E2E`, dan medan catatan membawa `AUTOMASI-CLEANUP-PM`.
> Pembatalan melalui portal ePBT oleh pihak berautoriti — automasi
> TIDAK memadam apa-apa.
>
> Satu kitaran boleh menjana LEBIH DARIPADA SATU nombor (cipta -> NK
> convert -> kemaskini). Baris lama TIDAK dipadam apabila rekod
> digantikan: nombor itu tetap wujud pada production.

| No. rekod | TC | Borang | Masa | Jenis | Status | Asal |
|---|---|---|---|---|---|---|
| `PGP02N261009009` | N-001 | N | 2026-10-09 12:35:53 | Notis | baru | - |
| `PGP02N261009010` | N-004 | N | 2026-10-09 12:40:26 | Notis | hasil-kemaskini | PGP02N261009009 |
| `PGP02N261009011` | N-001 | N | 2026-10-09 14:31:13 | Notis | baru | - |
| `PGP02N261009012` | N-004 | N | 2026-10-09 14:35:32 | Notis | hasil-kemaskini | PGP02N261009011 |
| `PGP02P261009027` | P-001 | P | 2026-10-09 14:48:08 | Kompaun | baru | - |
| **(TIDAK TERTANGKAP)** | P-004 | P | 2026-10-09 14:53:41 | Kompaun | hasil-kemaskini | PGP02P261009027 |
| `PGP02K261009028` | K-001 | K | 2026-10-09 15:19:11 | Kompaun | baru | - |
| `PGP02K261009029` | K-001 | K | 2026-10-09 15:35:03 | Kompaun | baru | - |
| `PGP02K261009030` | K-004 | K | 2026-10-09 15:39:47 | Kompaun | hasil-kemaskini | PGP02K261009029 |
| `PGP02K261009031` | K-001 | K | 2026-10-09 15:55:23 | Kompaun | baru | - |
| `PGP02N261009013` | N-001 | N | 2026-10-09 22:39:34 | Notis | baru | - |
| `PGP02N261009014` | N-004 | N | 2026-10-09 22:44:08 | Notis | hasil-kemaskini | PGP02N261009013 |
| `PGP02P261009032` | P-001 | P | 2026-10-09 22:59:32 | Kompaun | baru | - |
| `PGP02K261009033` | K-001 | K | 2026-10-09 23:16:47 | Kompaun | baru | - |

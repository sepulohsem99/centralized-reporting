# REKOD SEBENAR DICIPTA — production MBPG

> Setiap nombor di bawah ialah rekod **HIDUP** pada production MBPG
> (113.211.155.174). Ia dicipta oleh automasi ujian di bawah
> `MBPG_MOD_SEBENAR=1`, atas kelulusan pemilik 2026-08-17.
>
> **Untuk PM:** semua rekod ini data ujian. Nama pesalah bermula dengan
> `UJIAN AUTOMASI E2E`, dan medan catatan membawa `AUTOMASI-CLEANUP-PM`.
> Pembatalan melalui portal ePBT oleh pihak berautoriti — automasi
> TIDAK memadam apa-apa.
>
> Satu kitaran boleh menjana LEBIH DARIPADA SATU nombor (cipta -> NK
> convert -> kemaskini). Baris lama TIDAK dipadam apabila rekod
> digantikan: nombor itu tetap wujud pada production.

| No. rekod | TC | Borang | Masa | Jenis | Status | Asal |
|---|---|---|---|---|---|---|
| `PGP02N261009009` | N-001 | N | 2026-10-09 12:35:53 | Notis | baru | - |
| `PGP02N261009010` | N-004 | N | 2026-10-09 12:40:26 | Notis | hasil-kemaskini | PGP02N261009009 |

"""
Pelerai peranti + diagnostik persekitaran (MBJB).

KENAPA MODUL INI WUJUD
----------------------
Suite ini dibungkus sebagai zip dan diserahkan kepada pasukan yang setiap
ahlinya ada peranti Android sendiri, dan tiada siapa dijangka (atau
dibenarkan) mengedit fail .py. Suite lama membawa `DEVICE_UDID` yang
dihardcode dalam config.py -- betul selagi ia hanya berjalan atas satu
mesin, maut atas mesin orang lain: Appium tidak jumpa peranti dan SEMUA 54
TC mati pada penyediaan sesi.

Jadi peranti dileraikan pada waktu RUN:

  1. Pembolehubah persekitaran `MBPG_UDID`, kalau diset -- tindihan manual,
     untuk kes auto-detect tidak dapat memutuskan (atau untuk CI).
  2. Auto-detect: antara peranti yang `adb devices` lapor sebagai online,
     pilih yang benar-benar ada APP_PACKAGE dipasang.
  3. Kalau LEBIH DARIPADA SATU peranti ada app itu, modul ini BERHENTI dan
     meminta `MBPG_UDID`. Ia TIDAK memilih sendiri. Dahulu ada pemutus
     automatik yang membandingkan IMEI peranti dengan lesen profil; pemutus
     itu telah DIBUANG kerana premisnya salah (lihat blok di bawah) dan ia
     akan gagal memilih pada setiap run yang sah.

LESEN ADALAH TOKEN SERVER, BUKAN IMEI  (pembetulan -- baca sebelum mengedit)
---------------------------------------------------------------------------
`lesen_aplikasi` ialah TOKEN yang didaftarkan di portal PBT. Pengesahannya
berlaku di SERVER, terhadap pangkalan data pendaftaran majlis -- BUKAN
terhadap IMEI peranti tempatan.

Brief asal projek ini mendakwa "lesen terikat IMEI device" dan modul ini
dahulunya melaksanakan dakwaan itu. Pemilik SUDAH MENARIK BALIK dakwaan itu
pada 2026-07-29 (keputusan muktamad: recon\\PAPAN.md Seksyen 1.1). Bukti,
pada device fizikal yang SAMA seperti yang kita pandu:

    lesen 352405067769401  BERJAYA berpuluh run MBIP pada Ulefone Armor 27
    IMEI Armor 27          357616400186856 (slot 1) / 357616400186864 (slot 2)

Lesen yang berjaya itu BUKAN IMEI device itu.
  Sumber lesen  : mbip-testing\\v3\\profiles\\mbip-staging.json baris 14
  Sumber device : mbip-testing\\v3\\HANDOFF-2026-07-29.md baris 12 dan 36

Akibatnya, dan ini KAWALAN yang mesti dikekalkan:

  - Ketidakpadanan IMEI-vs-lesen adalah NORMAL dan bukan penemuan. Modul ini
    TIDAK melaporkannya sebagai ralat mahupun amaran. Kod yang berbuat
    demikian akan menjana amaran palsu pada SETIAP run yang sah, dan amaran
    palsu yang berulang mengajar manusia mengabaikan output preflight.
  - `m50` / `m51` ialah LABEL DEVICE DI PEJABAT pemilik. Bukan syarat
    padanan, bukan label PBT. Armor 27 bukan m50 dan bukan m51.
  - Lesen yang ditolak server ialah masalah PENDAFTARAN PORTAL, bukan
    masalah peranti. Penyelesaiannya: minta admin daftarkan token (atau
    IMEI 357616400186856) untuk MBJB staging. Bukan menukar peranti.

IMEI DIBACA SEBAGAI MAKLUMAT SAHAJA
------------------------------------
IMEI masih dibaca dan dilaporkan, kerana ia MAKLUMAT yang diperlukan bila
lesen ditolak: admin portal meminta IMEI untuk mendaftarkan peranti. Ia
TIDAK dibandingkan dengan apa-apa dan tidak pernah menghasilkan verdict.

Pembacaan IMEI adalah CUBA-SEBAIK-MUNGKIN. Bila ia tidak dapat dibaca,
modul ini berkata ia tidak dapat dibaca -- ia tidak mereka nilai dan tidak
mengandaikan apa-apa. Senyap yang jujur lebih baik daripada dakwaan palsu.

Modul ini juga satu-satunya sumber kebenaran untuk preflight --
`python device_utils.py --check` menjalankan bahagian peranti check_env.bat,
supaya preflight dan run sebenar tidak boleh bercanggah tentang peranti mana
yang akan dipandu.

Pustaka standard sahaja: tiada kebergantungan baharu, dan ia mesti terus
berfungsi walaupun kebergantungan ujian belum dipasang (itulah waktu
preflight dijalankan).
"""

import getpass
import json
import os
import re
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
from datetime import datetime, timezone


# ---------------------------------------------------------------------------
# Label pejabat bagi token lesen  (kosmetik sahaja)
# ---------------------------------------------------------------------------
#
# INI BUKAN peta lesen->IMEI dan BUKAN syarat padanan. Nilai lesen ialah
# token portal PBT (lihat docstring modul); ia TIDAK ada kaitan dengan IMEI
# peranti mana pun. Peta ini hanya menerjemah token kepada nama yang pemilik
# guna bercakap di pejabat ("m50", "m51"), supaya output preflight boleh
# ditulis sebagai "867382031575982 (label pejabat: m50)" dan sesiapa yang
# membaca WhatsApp pemilik tahu token mana yang dimaksudkan.
#
# Ia TIDAK PERNAH dibandingkan dengan IMEI yang dibaca dari peranti. Kalau
# token ketiga masuk, tambah di sini semata-mata untuk kebolehbacaan.
LABEL_PEJABAT_LESEN = {
    "867382031575982": "m50",
    "867382031575883": "m51",
}


def label_pejabat_lesen(lesen):
    """'m50' / 'm51' / None -- semata-mata untuk mesej yang boleh dibaca.

    Tiada makna teknikal: label pejabat, bukan identiti peranti.
    """
    return LABEL_PEJABAT_LESEN.get(str(lesen).strip())


# ---------------------------------------------------------------------------
# Paip adb
# ---------------------------------------------------------------------------

class AdbError(RuntimeError):
    """adb tiada, atau satu pertanyaan peranti tidak dapat diselesaikan."""


def _adb(args, timeout=20):
    """Jalankan satu arahan adb, pulangkan stdout sebagai teks.

    Melempar AdbError dengan mesej boleh-tindak kalau adb tiada dalam PATH --
    kesilapan setup paling biasa pada mesin baharu.
    """
    try:
        proc = subprocess.run(
            ["adb"] + list(args),
            capture_output=True, text=True, timeout=timeout,
        )
    except FileNotFoundError:
        raise AdbError(
            "adb tidak dijumpai dalam PATH / adb not found on PATH.\n"
            "  Install Android SDK platform-tools, kemudian tambah folder "
            "dia ke PATH.\n"
            "  Muat turun: "
            "https://developer.android.com/tools/releases/platform-tools"
        )
    except subprocess.TimeoutExpired:
        raise AdbError(
            f"adb {' '.join(args)} tidak respond dalam {timeout}s. "
            f"Cuba: adb kill-server, kemudian cuba semula."
        )
    return proc.stdout or ""


def list_devices():
    """Setiap peranti yang adb tahu, sebagai pasangan (serial, state).

    State selain "device" penting kepada pemanggil: "unauthorized" bermakna
    prompt USB-debugging belum diterima pada telefon, "offline" bermakna
    sambungan terputus -- dua-dua perlukan pembetulan berbeza daripada
    "tiada peranti".
    """
    out = _adb(["devices"])
    devices = []
    for line in out.splitlines()[1:]:          # baris 0 ialah header
        line = line.strip()
        if not line:
            continue
        parts = line.split()
        if len(parts) >= 2:
            devices.append((parts[0], parts[1]))
    return devices


def online_devices():
    """Serial peranti yang benar-benar boleh diguna sekarang."""
    return [serial for serial, state in list_devices() if state == "device"]


def has_package(serial, package):
    """Adakah `package` dipasang pada peranti ini?

    `pm list packages <pkg>` membuat padanan substring, jadi nama tepat
    disemak semula terhadap baris yang dipulangkan dan bukan mempercayai
    keputusan tak-kosong (contoh: "com.foo.bar" juga akan padan
    "com.foo.bar.debug").
    """
    out = _adb(["-s", serial, "shell", "pm", "list", "packages", package])
    for line in out.splitlines():
        if line.strip() == f"package:{package}":
            return True
    return False


def app_version(serial, package):
    """versionName app yang dipasang, atau None.

    Dihurai dalam Python dan bukan disalurkan melalui findstr/grep supaya
    ini berfungsi serupa pada mana-mana shell.
    """
    try:
        out = _adb(["-s", serial, "shell", "dumpsys", "package", package],
                   timeout=30)
    except AdbError:
        return None
    m = re.search(r"versionName=(\S+)", out)
    return m.group(1) if m else None


def device_model(serial):
    """Model yang boleh dibaca manusia, untuk log."""
    try:
        return _adb(["-s", serial, "shell", "getprop",
                     "ro.product.model"]).strip() or None
    except AdbError:
        return None


# ---------------------------------------------------------------------------
# IMEI  (MAKLUMAT sahaja -- cuba-sebaik-mungkin, tiada verdict)
# ---------------------------------------------------------------------------
#
# IMEI TIDAK dibandingkan dengan lesen. Ia dibaca kerana admin portal PBT
# meminta IMEI untuk mendaftarkan peranti, jadi bila lesen ditolak, IMEI
# ialah maklumat yang perlu dihantar kepada admin. Lihat docstring modul.

# Prop yang sesetengah ROM dedahkan. Kebanyakan peranti stok TIDAK, termasuk
# Armor 27 (Android 15) -- laluan ini hampir pasti kosong di sini, tetapi ia
# murah dan tidak memerlukan penghuraian Parcel, jadi ia dicuba dahulu.
_IMEI_PROPS = (
    "ril.gsm.imei",
    "gsm.imei",
    "persist.radio.imei",
    "ro.ril.oem.imei",
)

# Bentuk arahan `service call iphonesubinfo` yang DISAHKAN BERFUNGSI pada
# device ini oleh Loh, 2026-07-29 (Ulefone Armor 27, Android 15):
#
#     slot 1 : adb shell service call iphonesubinfo 1 s16 com.android.shell
#     slot 2 : adb shell service call iphonesubinfo 4 i32 1 s16 com.android.shell
#
# Hujah `s16 com.android.shell` ialah nama pakej pemanggil, dan ia WAJIB.
# Android moden menyemak pakej pemanggil terhadap kebenaran READ_PRIVILEGED_
# PHONE_STATE; tanpa hujah itu panggilan gagal (SecurityException atau Parcel
# kosong) dan pembacaan gagal SENYAP. Versi terdahulu modul ini memanggil
# `iphonesubinfo <tx>` tanpa hujah tersebut dan sentiasa memulangkan None.
#
# Setiap entri: (label_slot, senarai_hujah_selepas_"iphonesubinfo").
_IMEI_SLOT_CALLS = (
    ("slot 1", ["1", "s16", "com.android.shell"]),
    ("slot 2", ["4", "i32", "1", "s16", "com.android.shell"]),
)


def _decode_parcel(out):
    """Ekstrak rentetan daripada output `service call` yang berbentuk Parcel.

    Format (satu baris atau berbilang baris dengan alamat 0x........:):
        Result: Parcel(00000000 0000000f 00350033 00370033 ... '..3.5.3.7.')

    Perkataan pertama ialah kod null/exception, kedua ialah panjang rentetan
    dalam unit kod UTF-16, dan selebihnya ialah UTF-16LE yang dibungkus DUA
    unit kod per perkataan 32-bit. Dalam perkataan 00350033, separuh RENDAH
    ('0033' = '3') datang DAHULU, jadi setiap perkataan mesti dibalikkan
    bait-demi-bait sebelum dinyahkod.

    Lajur alamat (`0x00000000:`) tidak terjaring kerana `\\b` tidak berlaku
    antara 'x' dan '0' -- kedua-duanya aksara perkataan.
    """
    chunks = re.findall(r"\b([0-9a-f]{8})\b", out)
    if len(chunks) < 3:
        return None

    try:
        panjang = int(chunks[1], 16)          # unit kod UTF-16 yang didakwa
    except ValueError:
        panjang = 0

    raw = bytearray()
    for c in chunks[2:]:                      # langkau kod null + panjang
        raw += bytes.fromhex(c[6:8] + c[4:6] + c[2:4] + c[0:2])

    try:
        teks = raw.decode("utf-16-le", errors="ignore")
    except Exception:                                   # noqa: BLE001
        return None

    # Hormati panjang yang didakwa bila ia munasabah: perkataan terakhir
    # boleh dipadding dengan NUL atau sampah, dan memotong di sini lebih
    # jujur daripada bergantung pada regex hiliran untuk mengabaikannya.
    if 0 < panjang <= len(teks):
        teks = teks[:panjang]
    return teks


def _imei_dari_service_call(serial, hujah):
    """Satu percubaan `service call iphonesubinfo`, atau None."""
    try:
        out = _adb(["-s", serial, "shell", "service", "call",
                    "iphonesubinfo"] + list(hujah), timeout=15)
    except AdbError:
        return None
    if "Exception" in out or "Parcel" not in out:
        return None
    teks = _decode_parcel(out)
    if not teks:
        return None
    m = re.search(r"\d{14,17}", teks)
    return m.group(0) if m else None


def read_imeis(serial):
    """Setiap IMEI yang boleh dibaca, sebagai senarai (slot 1 dahulu).

    Senarai kosong bermakna tiada yang dapat dibaca -- itu BUKAN kegagalan
    dan BUKAN penemuan. Ia tidak menghalang apa-apa, kerana tiada keputusan
    dalam suite ini bergantung pada IMEI.
    """
    keluar = []

    # 1. Prop khusus ROM -- murah, kadang-kadang ada. Kegagalan adb pada satu
    #    prop tidak boleh membatalkan laluan service-call di bawah (bug versi
    #    terdahulu: `except AdbError: return None` di sini menyembunyikan
    #    laluan yang sebenarnya berfungsi pada device ini).
    for prop in _IMEI_PROPS:
        try:
            nilai = _adb(["-s", serial, "shell", "getprop", prop]).strip()
        except AdbError:
            break
        if re.fullmatch(r"\d{14,17}", nilai) and nilai not in keluar:
            keluar.append(nilai)
            break

    # 2. service call iphonesubinfo -- laluan yang disahkan pada device ini.
    for _label, hujah in _IMEI_SLOT_CALLS:
        imei = _imei_dari_service_call(serial, hujah)
        if imei and imei not in keluar:
            keluar.append(imei)

    return keluar


def read_imei(serial):
    """IMEI pertama yang dapat dibaca (slot 1), atau None.

    Memulangkan None BUKAN kegagalan. Pemanggil mesti melayan None sebagai
    "tidak diketahui" -- dan tidak pernah sebagai "tidak padan", kerana tiada
    apa yang perlu dipadankan (lesen ialah token server, bukan IMEI).
    """
    imeis = read_imeis(serial)
    return imeis[0] if imeis else None


def lapor_lesen_dan_imei(serial, lesen_aplikasi):
    """Teks MAKLUMAT tentang token lesen + IMEI peranti. Tiada verdict.

    Sengaja tidak memulangkan status: tiada keadaan di sini yang boleh
    dipanggil betul atau salah dari sebelah kita. Lesen disahkan di SERVER,
    jadi satu-satunya ujian sebenar ialah percubaan log masuk. Fungsi ini
    hanya meletakkan kedua-dua nombor di depan mata manusia supaya bila
    server menolak lesen, IMEI yang perlu dihantar kepada admin portal sudah
    ada dalam log run -- tanpa perlu menyentuh peranti semula.

    Pengganti check_license() lama, yang membandingkan IMEI dengan lesen dan
    menjana AMARAN bila tidak padan. Premis itu salah (docstring modul), dan
    amaran itu akan menyala pada setiap run yang sah.
    """
    lesen = str(lesen_aplikasi).strip()
    label = label_pejabat_lesen(lesen)
    baris = [
        f"Token lesen (profil) : {lesen}"
        f"{f'  [label pejabat: {label}]' if label else ''}",
    ]

    imeis = read_imeis(serial)
    if imeis:
        for i, imei in enumerate(imeis):
            slot = _IMEI_SLOT_CALLS[i][0] if i < len(_IMEI_SLOT_CALLS) \
                else f"slot {i + 1}"
            baris.append(f"  IMEI peranti ({slot}) : {imei}")
    else:
        baris.append("  IMEI peranti         : tidak dapat dibaca melalui "
                     "adb (tidak menghalang apa-apa)")
        baris.append("    Kalau admin portal memintanya, baca pada peranti: "
                     "Tetapan > Perihal telefon > Status > IMEI, atau dail "
                     "*#06#")

    baris.append("  Nombor-nombor ini TIDAK dibandingkan: lesen ialah token "
                 "portal PBT yang")
    baris.append("  disahkan di SERVER, jadi ia TIDAK sepatutnya sama dengan "
                 "IMEI. Tidak sama = NORMAL.")
    baris.append("  Kalau log masuk DITOLAK: cuba token kedua "
                 "867382031575883 (PAPAN.md 1.2). Kalau")
    baris.append("  kedua-dua ditolak, itu BLOCKER LUARAN -- minta admin "
                 "daftarkan IMEI di atas untuk")
    baris.append("  MBJB staging. Bukan bug automation, dan bukan sebab "
                 "untuk menukar peranti.")
    return "\n".join(baris)


# ---------------------------------------------------------------------------
# Pelerai peranti
# ---------------------------------------------------------------------------

class DeviceResolutionError(RuntimeError):
    """Tiada satu peranti yang jelas untuk dipandu -- mesej menerangkan
    apa perlu dibuat."""


def resolve_udid(package, verbose=True):
    """Serial yang patut dipandu Appium. Lihat docstring modul untuk turutan.

    Tidak pernah meneka bila jawapannya taksa. Dua peranti yang sama-sama
    membawa app itu ialah simpang jalan sebenar, dan memilih satu secara
    senyap akan menjadikan keputusan run tidak boleh dipercayai: separuh
    rekod tercipta atas satu peranti dan separuh atas yang lain, dan tiada
    siapa perasan sampai nombor rekod tidak dijumpai.

    Versi terdahulu cuba memutuskan ketaksaan itu dengan memadankan IMEI
    setiap peranti dengan lesen profil. Pemutus itu DIBUANG: lesen ialah
    token server dan BUKAN IMEI (docstring modul), jadi padanan itu tidak
    akan berlaku pada peranti yang sah -- ia hanya menambah dua panggilan
    adb yang lambat sebelum tetap gagal, dengan mesej yang menyalahkan
    perkara yang salah.
    """
    override = os.environ.get("MBPG_UDID", "").strip()
    if override:
        if verbose:
            print(f"  [DEVICE] MBPG_UDID diset -- guna serial: {override}")
        return override

    devices = list_devices()
    if not devices:
        raise DeviceResolutionError(
            "Tiada device tersambung / no device attached.\n"
            "  1. Sambung telefon Android via USB.\n"
            "  2. Aktifkan Developer options + USB debugging.\n"
            "  3. Sahkan dengan: adb devices"
        )

    online = [s for s, state in devices if state == "device"]
    if not online:
        detail = "\n".join(f"    {s}  ->  {state}" for s, state in devices)
        raise DeviceResolutionError(
            "Device tersambung tetapi belum sedia / attached but not "
            "ready:\n" + detail + "\n"
            "  'unauthorized' = tekan 'Allow USB debugging' pada telefon.\n"
            "  'offline'      = cabut & sambung semula USB, atau "
            "adb kill-server."
        )

    with_app = [s for s in online if has_package(s, package)]

    if not with_app:
        listed = "\n".join(f"    {s}" for s in online)
        raise DeviceResolutionError(
            f"Device dijumpai, tetapi tiada yang ada app '{package}' "
            f"dipasang.\n" + listed + "\n"
            "  Pasang APK MBJB (MBPG_2.1.33-Dev.apk) pada device tu "
            "dahulu, kemudian cuba semula.\n"
            "  Sahkan dengan: adb -s <serial> shell pm list packages "
            f"{package}"
        )

    if len(with_app) == 1:
        serial = with_app[0]
        if verbose:
            _lapor_peranti(serial, package)
        return serial

    # Lebih daripada satu peranti membawa app. Berhenti -- jangan pilih.
    # Lesen profil TIDAK boleh memutuskan ini (ia token server, bukan IMEI),
    # jadi satu-satunya jawapan yang jujur ialah meminta manusia menyebut
    # peranti mana secara jelas.
    listed = "\n".join(f"    {s}  ({device_model(s) or 'model tak dibaca'})"
                       for s in with_app)
    raise DeviceResolutionError(
        "Lebih dari satu device ada app MBJB -- tak boleh pilih sendiri "
        "(pilihan salah = keputusan test tak sah).\n" + listed + "\n"
        "  Tiada pemutus automatik, dan itu disengajakan: lesen profil ialah\n"
        "  token portal PBT yang disahkan di server, jadi ia TIDAK\n"
        "  mengenal pasti peranti dan TIDAK boleh digunakan untuk memilih.\n"
        "  Sebut peranti secara jelas, contoh:\n"
        f"    set MBPG_UDID={with_app[0]}\n"
        "  ...kemudian jalankan semula."
    )


# ---------------------------------------------------------------------------
# Autofill Android -- perangkap login yang sudah membakar N-001 sekali
# ---------------------------------------------------------------------------
#
# `android:id/autofill_dataset_picker` muncul ATAS skrin login (tawaran
# akaun tersimpan lain, mis. `mdkt`, `nurulain`, `fadh1`) dan mengubah
# hierarki view SEMASA SendKeysToElement berjalan -> elemen jadi stale
# pertengahan taip. Disahkan 2026-07-31 (recon\PAPAN.md "PENEMUAN MALAM
# INI" #1) sebagai punca ERROR N-001 8m23s -- BUKAN bug locator suite ini.
# Fix yang disahkan berfungsi pada device:
#     adb shell settings put secure autofill_service null

def autofill_service(serial):
    """Nilai semasa `settings get secure autofill_service`, atau None.

    None bermakna DUA keadaan yang pemanggil layan SAMA (tiada tindakan
    diperlukan / tidak dapat disahkan): sudah dimatikan (nilai literal
    string "null") ATAU tidak dapat dibaca langsung (adb gagal). Nilai
    bukan-None ialah nama pakej khidmat autofill yang AKTIF, contoh
    'com.google.android.gms/.autofill.service.AutofillService' -- kalau
    ini kembali, skrin login berisiko popup autofill menimpa medan semasa
    ia sedang diisi.
    """
    try:
        out = _adb(["-s", serial, "shell", "settings", "get", "secure",
                    "autofill_service"]).strip()
    except AdbError:
        return None
    return None if out in ("", "null") else out


def disable_autofill(serial):
    """Matikan khidmat autofill Android pada peranti ini.

    Berbeza daripada kebanyakan fungsi lain dalam modul ini: ini TINDAKAN
    (menulis ke peranti), bukan bacaan cuba-sebaik-mungkin. Pulangkan True
    kalau arahan `settings put` berjaya DIHANTAR -- ini TIDAK mengesahkan
    kesannya; pemanggil yang mahu kepastian patut panggil
    autofill_service() semula selepas ini dan sahkan ia pulangkan None.
    """
    try:
        _adb(["-s", serial, "shell", "settings", "put", "secure",
              "autofill_service", "null"])
        return True
    except AdbError:
        return False


def _lapor_peranti(serial, package):
    model = device_model(serial)
    ver = app_version(serial, package)
    label = f" ({model})" if model else ""
    vlabel = f", app build {ver}" if ver else ""
    print(f"  [DEVICE] Auto-detect: {serial}{label}{vlabel}")


def tester_name():
    """Siapa yang menjalankan ini. Digunakan untuk mengatribut run dalam
    sejarah dashboard, supaya run seorang ahli pasukan tidak disalahanggap
    sebagai run orang lain.

    Nama pengguna OS secara lalai -- sifar setup. `MBPG_TESTER` menindihnya
    untuk sesiapa yang nama akaunnya tidak dikenali pasukan.
    """
    override = os.environ.get("MBPG_TESTER", "").strip()
    if override:
        return override
    try:
        return getpass.getuser()
    except Exception:                                   # noqa: BLE001
        return os.environ.get("USERNAME") or "unknown"


# ---------------------------------------------------------------------------
# Geometri skrin + skrol -- UKURAN sebenar, bukan andaian
# ---------------------------------------------------------------------------
#
# Ditambah 2026-07-31 selepas tiga run K1 gagal atas sebab yang salah: swipe
# lama bermula pada y=1900 pada peranti yang bekas boleh-skrolnya tamat pada
# y~1596 (Ulefone Armor 27), jadi borang TIDAK PERNAH bergerak dan itu
# kelihatan tepat serupa "locator tiada". recon\PAPAN.md (blok MULA DI SINI,
# 2026-07-31) ada rentetan logcat penuh.
#
# DUA PERANGKAP yang fungsi di bawah wujud untuk mengelak:
#
#   1. `uiautomator dump` MEMBUANG setiap node `visible:false` daripada XML
#      yang dihasilkan -- disahkan terus dari logcat device:
#          Skipping invisible child: className: android.widget.Spinner;
#          clickable:true; enabled:true; visible:false;
#          boundsInScreen: Rect(107, 3567 - 974, 1596)
#      Ertinya "0 kemunculan satu locator dalam SATU dump" BUKAN bukti
#      elemen itu tiada dalam pokok view -- ia mungkin cuma di bawah
#      viewport semasa. JANGAN simpulkan "locator tiada" / "kategori D"
#      daripada satu dump sahaja. Skrol (dan SAHKAN skrol itu benar-benar
#      berlaku dengan measure_scroll() di bawah), dump semula, baru
#      simpulkan.
#   2. Saiz skrin dan bounds bekas boleh-skrol BERBEZA ikut peranti. Suite
#      ini diedar sebagai zip kepada ahli pasukan yang setiap seorang
#      memandu peranti Android sendiri (lihat docstring modul), jadi
#      1080x2460 / y~1596 TIDAK BOLEH dihardcode sebagai pemalar walaupun
#      ia nilai yang diperhatikan pada Armor 27 pada 2026-07-31 -- ia
#      nilai RUJUKAN sejarah sahaja. Fungsi di bawah membaca nilai sebenar
#      setiap kali dipanggil.
#
# Ketiga-tiga fungsi ini TIDAK dipanggil oleh mana-mana kod dalam repo ini
# pada masa ditulis (2026-07-31) -- mereka tersedia untuk devtools\ dan
# pages\ memanggil, supaya skrip recon akan datang tidak menulis semula
# logik wm-size/dump/banding-y sendiri (seperti devtools\sahkan_skrol.py
# terpaksa buat sebelum fungsi ini wujud).


def screen_size(serial):
    """(lebar, tinggi) piksel SEBENAR peranti ini, dibaca terus dari adb.

    TIDAK PERNAH hardcoded -- lihat amaran perangkap 2 di atas blok ini.
    Keutamaan "Override size" berbanding "Physical size" kerana override
    itulah (kalau ROM/mod pembangun menetapkannya) yang sebenarnya dipakai
    untuk mengira koordinat tap/swipe; "Physical size" ialah gantian.

    Pulangkan None kalau `adb shell wm size` tidak dapat dihurai (adb
    tiada, output luar jangka, dsb) -- ini BUKAN kegagalan yang menghalang
    apa-apa, pemanggil melayannya sama seperti IMEI tidak terbaca.
    """
    try:
        out = _adb(["-s", serial, "shell", "wm", "size"])
    except AdbError:
        return None
    m = (re.search(r"Override size:\s*(\d+)x(\d+)", out)
         or re.search(r"Physical size:\s*(\d+)x(\d+)", out))
    if not m:
        return None
    return int(m.group(1)), int(m.group(2))


def _parse_bounds(bounds_str):
    """'[x1,y1][x2,y2]' (format bounds uiautomator) -> (x1,y1,x2,y2) int,
    atau None kalau rentetan tidak berbentuk itu."""
    m = re.match(r"\[(\d+),(\d+)\]\[(\d+),(\d+)\]", bounds_str or "")
    if not m:
        return None
    return tuple(int(g) for g in m.groups())


def _uiautomator_dump(serial, timeout=25):
    """XML mentah satu `uiautomator dump`, atau None kalau gagal.

    Dump ke `/sdcard/` dan `cat` balik dalam DUA panggilan adb berasingan
    dan bukan `adb pull` -- sepadan `devtools\\README.md`: Git Bash
    memutarbelitkan path `/sdcard/...` menjadi laluan Windows, dan skrip
    devtools sedia ada semuanya sudah mengelaknya dengan cara ini.

    Timeout lebih panjang daripada lalai `_adb()` (25s vs 20s) kerana
    borang besar (contoh borang NOTIS yang memanjang ~2.5 skrin) memang
    ambil beberapa saat untuk uiautomator susun.

    BACA BLOK KOMEN DI ATAS sebelum menyimpulkan apa-apa daripada
    ketiadaan satu elemen dalam hasil fungsi ini.
    """
    try:
        _adb(["-s", serial, "shell", "uiautomator", "dump",
              "/sdcard/_device_utils_dump.xml"], timeout=timeout)
        xml_text = _adb(["-s", serial, "shell", "cat",
                         "/sdcard/_device_utils_dump.xml"], timeout=timeout)
    except AdbError:
        return None
    return xml_text if "<hierarchy" in xml_text else None


def scrollable_viewport_bounds(serial):
    """Bounds (x1, y1, x2, y2) bekas boleh-skrol PERTAMA dalam dump semasa.

    Ini jawapan kepada perangkap 2026-07-31: swipe mesti bermula DAN
    berakhir DALAM bounds ini, atau ia tidak menggerakkan apa-apa (silap
    sebenar: swipe y=1900 pada peranti yang bekasnya tamat y~1596). Jangan
    tulis semula nilai y sebagai pemalar di tempat lain -- panggil fungsi
    ini setiap kali, kerana bounds berbeza ikut skrin/borang/peranti.

    Pulangkan None kalau dump gagal ATAU tiada node `scrollable="true"`
    dalam dump semasa. None BUKAN bukti "borang ini tidak boleh diskrol"
    -- ingat perangkap 1 (visible:false): kalau bekas boleh-skrol itu
    sendiri di luar viewport ibu bapanya, ia turut terbuang daripada dump.
    """
    xml_text = _uiautomator_dump(serial)
    if not xml_text:
        return None
    try:
        root = ET.fromstring(xml_text)
    except ET.ParseError:
        return None
    for node in root.iter():
        if node.attrib.get("scrollable") == "true":
            bounds = _parse_bounds(node.attrib.get("bounds", ""))
            if bounds:
                return bounds
    return None


def _peta_label_y(xml_text):
    """{label: y1} untuk setiap node berlabel UNIK dalam satu dump.

    Label = text() kalau tidak kosong, jika tidak content-desc(). Node
    yang labelnya berulang (>1 instans teks/desc sama pada skrin, mis.
    baris senarai berjadual) DIGUGURKAN sengaja -- memadankan mereka
    merentas dua dump akan MEREKA-REKA padanan instans, dan padanan reka
    lebih teruk daripada tiada padanan langsung (ia akan melaporkan
    "anjakan" yang sebenarnya perbandingan dua elemen berlainan).
    """
    try:
        root = ET.fromstring(xml_text)
    except ET.ParseError:
        return {}
    kira = {}
    for node in root.iter():
        label = ((node.attrib.get("text") or "").strip()
                 or (node.attrib.get("content-desc") or "").strip())
        if not label:
            continue
        bounds = _parse_bounds(node.attrib.get("bounds", ""))
        if not bounds:
            continue
        kira.setdefault(label, []).append(bounds[1])          # y1
    return {k: v[0] for k, v in kira.items() if len(v) == 1}


# Status tiga-hala measure_scroll() -- KONTRAK untuk sesiapa yang membina
# di atas fungsi ini (pages\base_page.py scroll_in_viewport, makmingg,
# 2026-07-31). Gagal-tertutup: dikongsi==0 TIDAK PERNAH dilaporkan sebagai
# TIDAK_BERGERAK walaupun bergerak/anjakan_*_px turut 0 dalam keadaan itu
# -- lihat docstring measure_scroll() untuk sebab.
BERGERAK = "BERGERAK"
TIDAK_BERGERAK = "TIDAK_BERGERAK"
TIDAK_DAPAT_DITENTUKAN = "TIDAK_DAPAT_DITENTUKAN"


def measure_scroll(serial, swipe, settle_seconds=1.5, dump_timeout=25,
                   ambang_px=50):
    """Jalankan SATU swipe dan ukur anjakan piksel SEBENAR -- bukan andaian.

    KONTRAK (audit cuakKambing 2026-07-31; dibina di atas fungsi ini oleh
    pages\\base_page.py scroll_in_viewport -- makmingg): pulangan fungsi
    ini membezakan DUA isyarat yang MESTI dibaca berasingan. JANGAN
    gabungkan mereka semula.

      MENATAL (bukti skrol SEBENAR)
        `status`, `bergerak`, `anjakan_max_px`, `anjakan_purata_px`.
        Asas TUNGGAL: anjakan kedudukan y bagi label yang DIKONGSI antara
        dua dump (sebelum & selepas). Elemen baharu TIDAK PERNAH dan
        TIDAK BOLEH menyumbang kepada nilai-nilai ini.

      BERUBAH (skrin berbeza -- TETAPI BUKAN bukti skrol)
        `baru`, `hilang`. Berguna untuk debug sahaja -- JANGAN jadikan
        bukti skrol. Lihat TIGA senario positif-palsu di bawah.

    KENAPA pengasingan ini WAJIB (bukan gaya penulisan): versi fungsi ini
    SEBELUM pembetulan ini menyebut `baru` sebagai "isyarat kuat skrol
    berjaya" dalam docstring -- itu SALAH, dan cuakKambing menangkapnya
    2026-07-31. Elemen "baharu" muncul dalam SEKURANG-KURANGNYA tiga
    keadaan di mana TIADA SATU PIKSEL PUN menatal:
      1. Senarai cadangan autocomplete DITUTUP -> borang di bawahnya
         terdedah buat pertama kali dalam dump SELEPAS -- bukan kerana ia
         bergerak, tetapi kerana overlay yang menutupnya hilang.
      2. Overlay hilang (cth teks "... SEDANG DIPROSES...") -> elemen di
         belakangnya kelihatan dalam dump SELEPAS, tiada dalam SEBELUM.
      3. Alert asli ditolak -> skrin di belakang alert terdedah buat kali
         pertama dalam dump SELEPAS.
    Ketiga-tiga menghasilkan `baru` bukan-kosong TANPA satu pun swipe
    menggerakkan kandungan borang. Nilai `bergerak`/`anjakan_*_px` fungsi
    ini TIDAK PERNAH dipengaruhi oleh `baru`/`hilang` -- itulah sebab
    pengasingan ini KONTRAK, bukan cadangan: tandatangan pulangan fungsi
    ini tidak boleh berubah tanpa memecahkan scroll_in_viewport.

    `swipe` = (x1, y1, x2, y2, durasi_ms), dihantar terus ke
    `adb shell input swipe`. Fungsi ini TIDAK memilih koordinat -- panggil
    scrollable_viewport_bounds() dahulu dan pastikan y1 DAN y2 kedua-dua
    berada DALAM bounds itu.

    Kaedah: dump SEBELUM -> swipe -> tunggu `settle_seconds` -> dump
    SELEPAS -> padankan label unik yang dikongsi kedua-dua dump (lihat
    _peta_label_y) -> anjakan = |y1_sebelum - y1_selepas| bagi setiap
    pasangan DIKONGSI sahaja.

    Pulangkan dict:
      ok                : False kalau swipe atau mana-mana dump gagal
                          (lihat 'sebab') -- kegagalan PENGANGKUTAN, tiada
                          kaitan dengan soalan skrol/tidak.
      status            : SATU daripada pemalar modul BERGERAK /
                          TIDAK_BERGERAK / TIDAK_DAPAT_DITENTUKAN.
                          TIDAK_DAPAT_DITENTUKAN bila dikongsi == 0 --
                          skrin mungkin bertukar SEPENUHNYA (mis. navigasi
                          keluar borang), jadi "tidak bergerak" TIDAK
                          BOLEH disimpulkan hanya kerana tiada anjakan
                          untuk diukur. Gagal-tertutup: jangan teka.
      dikongsi          : bilangan label unik hadir dalam DUA-DUA dump
      bergerak          : drpd label DIKONGSI SAHAJA, bilangan yang
                          beranjak > ambang_px. TIDAK termasuk baru/hilang.
      anjakan_max_px    : anjakan terbesar antara label DIKONGSI (0 kalau
                          dikongsi kosong -- semak `status` dahulu, JANGAN
                          baca 0 ini sebagai "tidak bergerak")
      anjakan_purata_px : purata anjakan antara label DIKONGSI (0 kalau
                          dikongsi kosong -- amaran sama seperti di atas)
      baru              : label yang muncul HANYA SELEPAS swipe --
                          MAKLUMAT SAHAJA, BUKAN bukti skrol (lihat 3
                          senario positif-palsu di atas)
      hilang            : label yang muncul HANYA SEBELUM swipe --
                          MAKLUMAT SAHAJA, BUKAN bukti skrol
    """
    # ------------------------------------------------------------------
    # GERBANG DRY-RUN MBPG — disemak SEBELUM sebarang kerja dilakukan.
    #
    # Ini satu-satunya laluan input dalam projek ini yang memintas Appium,
    # dan oleh itu memintas guard/corong.py.
    #
    # `adb shell input swipe` dengan titik mula == titik tamat BUKAN
    # swipe: Android mendaftarkannya sebagai KETUKAN pada koordinat itu.
    # Koordinat datang dari base_page._kira_swipe(), yang mengira
    # y_start/y_end daripada bounds bekas — dan pada bekas berketinggian
    # sifar atau hampir sifar (kandungan belum dirender, tab kosong)
    # kedua-duanya mengecil kepada nilai yang SAMA. Hasilnya satu tap buta
    # pada production yang tidak pernah melalui corong.
    #
    # Ia belum pernah berlaku. Ia tidak boleh dibiarkan mungkin.
    x1, y1, x2, y2, durasi_ms = swipe
    if (x1, y1) == (x2, y2):
        return {"ok": False,
                "sebab": ("swipe degenerat DITOLAK oleh gerbang dry-run: "
                          f"mula == tamat ({x1},{y1}) bermakna Android "
                          "mendaftarkannya sebagai TAP, dan laluan adb ini "
                          "memintas corong tap. Punca biasa: bounds bekas "
                          "berketinggian sifar dalam _kira_swipe().")}

    xml_sebelum = _uiautomator_dump(serial, timeout=dump_timeout)
    if not xml_sebelum:
        return {"ok": False, "sebab": "dump SEBELUM swipe gagal"}
    peta_sebelum = _peta_label_y(xml_sebelum)

    try:
        _adb(["-s", serial, "shell", "input", "swipe",
              str(x1), str(y1), str(x2), str(y2), str(durasi_ms)],
             timeout=15)
    except AdbError as e:
        return {"ok": False, "sebab": f"swipe gagal: {e}"}

    time.sleep(settle_seconds)

    xml_selepas = _uiautomator_dump(serial, timeout=dump_timeout)
    if not xml_selepas:
        return {"ok": False, "sebab": "dump SELEPAS swipe gagal"}
    peta_selepas = _peta_label_y(xml_selepas)

    dikongsi = [k for k in peta_sebelum if k in peta_selepas]
    anjakan = {k: abs(peta_sebelum[k] - peta_selepas[k]) for k in dikongsi}
    bergerak = [k for k, d in anjakan.items() if d > ambang_px]

    if not dikongsi:
        status = TIDAK_DAPAT_DITENTUKAN
    elif bergerak:
        status = BERGERAK
    else:
        status = TIDAK_BERGERAK

    return {
        "ok": True,
        "status": status,
        "dikongsi": len(dikongsi),
        "bergerak": len(bergerak),
        "anjakan_max_px": max(anjakan.values()) if anjakan else 0,
        "anjakan_purata_px": (sum(anjakan.values()) // len(anjakan))
                              if anjakan else 0,
        "baru": [k for k in peta_selepas if k not in peta_sebelum][:10],
        "hilang": [k for k in peta_sebelum if k not in peta_selepas][:10],
    }


# ---------------------------------------------------------------------------
# Eksperimen: TERBUKA vs TERTUTUP -- kaedah adb_swipe SAHAJA
# ---------------------------------------------------------------------------
#
# Ditambah 2026-07-31 selepas teori koordinat (y1900 di luar viewport) Loh
# DITARIK BALIK: dua ukuran measure_scroll() -- swipe DALAM viewport (y1400
# -> y600) DAN swipe LUAR viewport (y1900 -> y800) -- kedua-duanya memberi
# 20 dikongsi / 0 bergerak / 0px. Punca sebenar TIDAK DIKETAHUI. Dua calon:
#   A -- senarai cadangan autocomplete yang TERBUKA menyekat skrol borang
#        di bawahnya (keadaan skrin, BUKAN koordinat)
#   B -- `adb shell input swipe` koordinat mentah memang tidak berkesan
#        pada bekas RN ini, sedangkan `mobile: scrollGesture` (perintah
#        W3C Appium yang menyasarkan elementId bekas, dipakai makmingg
#        dalam base_page.py) mungkin berkesan walaupun adb tidak.
#
# HAD JUJUR, BACA SEBELUM GUNA: modul ini stdlib+adb SAHAJA (docstring atas
# fail ini) -- TIADA sesi Appium, jadi TIDAK BOLEH memanggil
# `mobile: scrollGesture` (itu perintah W3C yang perlu `driver.execute_
# script` dengan sesi automation Appium aktif -- sepenuhnya di luar apa
# modul stdlib+adb ini boleh buat). Eksperimen di bawah HANYA menguji
# kaedah `adb_swipe`, merentas DUA keadaan skrin. Ia TIDAK BOLEH menamakan
# B sebagai menang secara langsung -- paling jauh ia boleh pulangkan
# 'B_MUNGKIN' (adb swipe gagal dalam KEDUA-DUA keadaan, jadi A tersingkir,
# tapi itu BUKAN pengesahan B). Mengesahkan B memerlukan skrip Appium
# berasingan (contoh: base_page.py / devtools\ yang memanggil
# driver.execute_script("mobile: scrollGesture", ...) dalam sesi hidup) --
# BUKAN device_utils.py, dan bukan sesuatu fungsi di bawah cuba buat.
#
# Alat ini juga TIDAK menentukan keadaan skrin (TERBUKA/TERTUTUP) sendiri:
# membuka/menutup senarai cadangan autocomplete perlukan navigasi khusus
# skrin (tab, medan, teks separa) yang TIDAK SERAGAM antara tab PESALAH
# (Spinner + select_dialog_listview) dan tab NOTIS (baris teks biasa dalam
# borang, Spinner: 0 -- recon\PAPAN.md 2b). Menulis SATU heuristik
# pengesanan untuk kedua-dua bentuk berisiko silap senyap, jadi ia sengaja
# TIDAK cuba -- manusia meletakkan device dalam keadaan yang betul dahulu,
# kemudian panggil dengan --keadaan=terbuka atau --keadaan=tertutup.
#
# Guna measure_scroll() SEDIA ADA untuk ukuran sebenar -- TIADA logik
# pengukur kedua ditulis di sini, hanya orkestrasi + log + verdict.

EKSPERIMEN_LOG = os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "ui_dumps",
    "eksperimen_skrol.json")


def _baca_log_eksperimen(laluan=EKSPERIMEN_LOG):
    """Senarai rekod sedia ada dalam fail log eksperimen, [] kalau
    tiada/rosak. `laluan` boleh ditindih untuk ujian kering (tanpa
    menyentuh EKSPERIMEN_LOG sebenar)."""
    try:
        with open(laluan, encoding="utf-8") as fh:
            data = json.load(fh)
        return data if isinstance(data, list) else []
    except Exception:                                     # noqa: BLE001
        return []


def jalankan_eksperimen_skrol(serial, keadaan, swipe=None,
                              settle_seconds=1.5, laluan_log=EKSPERIMEN_LOG):
    """SATU ukuran measure_scroll() untuk keadaan skrin `keadaan`
    ("terbuka" atau "tertutup"), direkod ke `laluan_log`, dan dipulangkan.

    `swipe` lalai: diambil daripada scrollable_viewport_bounds() (80% ->
    20% tinggi bekas boleh-skrol semasa, x tengah, 900ms) -- TIDAK
    hardcode koordinat mentah, sepadan blok "Geometri skrin + skrol" di
    atas modul ini. Kalau bounds tidak dapat ditentukan (None), fungsi
    GAGAL SELAMAT dengan `ok: False` dan bukan meneka koordinat; panggil
    dengan `swipe=` eksplisit kalau bekas itu wujud tapi di luar viewport
    (lihat amaran visible:false pada _uiautomator_dump()).

    `kaedah` direkod sebagai literal "adb_swipe" -- lihat blok komen di
    atas untuk sebab `mobile: scrollGesture` TIDAK diuji di sini.
    """
    if keadaan not in ("terbuka", "tertutup"):
        raise ValueError("keadaan mesti 'terbuka' atau 'tertutup', dapat: "
                          f"{keadaan!r}")

    if swipe is None:
        bounds = scrollable_viewport_bounds(serial)
        if not bounds:
            return {
                "ok": False,
                "sebab": "scrollable_viewport_bounds() pulang None -- "
                         "tiada node scrollable dalam dump semasa (atau "
                         "dump gagal). Bekalkan swipe=(x1,y1,x2,y2,ms) "
                         "eksplisit kalau bekas itu wujud tapi di luar "
                         "viewport (lihat amaran visible:false).",
            }
        x1, y1, x2, y2 = bounds
        cx = (x1 + x2) // 2
        tinggi = y2 - y1
        swipe = (cx, y1 + int(tinggi * 0.8), cx, y1 + int(tinggi * 0.2), 900)

    hasil = measure_scroll(serial, swipe, settle_seconds=settle_seconds)
    rekod = dict(hasil)
    rekod["keadaan"] = keadaan
    rekod["kaedah"] = "adb_swipe"
    rekod["swipe"] = list(swipe)
    rekod["waktu"] = datetime.now(timezone.utc).isoformat()

    log = _baca_log_eksperimen(laluan_log)
    log.append(rekod)
    try:
        os.makedirs(os.path.dirname(laluan_log), exist_ok=True)
        with open(laluan_log, "w", encoding="utf-8") as fh:
            json.dump(log, fh, ensure_ascii=False, indent=2)
    except OSError:
        pass          # kegagalan TULIS log tidak boleh menyorok hasil ukuran
    return rekod


def _status_terkini(log, keadaan):
    """Rekod TERKINI dalam `log` untuk (keadaan, kaedah=adb_swipe, ok=True),
    atau None kalau tiada."""
    for rekod in reversed(log):
        if (rekod.get("keadaan") == keadaan
                and rekod.get("kaedah") == "adb_swipe"
                and rekod.get("ok")):
            return rekod
    return None


def verdict_eksperimen_skrol(laluan_log=EKSPERIMEN_LOG):
    """Baca log eksperimen, pulangkan (verdict: str, mesej: str).

    verdict ialah SATU daripada 'A', 'B_MUNGKIN', 'TIADA',
    'TIDAK_CUKUP_DATA'. TIDAK PERNAH 'B' semata-mata (tanpa '_MUNGKIN') --
    kaedah adb_swipe SAHAJA diuji di sini (lihat blok komen "HAD JUJUR" di
    atas), jadi bukti UNTUK B paling jauh ialah "adb swipe gagal dalam
    kedua-dua keadaan" -- itu menyingkirkan A, BUKAN mengesahkan B.
    """
    log = _baca_log_eksperimen(laluan_log)
    terbuka = _status_terkini(log, "terbuka")
    tertutup = _status_terkini(log, "tertutup")

    if not terbuka or not tertutup:
        hilang = [k for k, r in (("terbuka", terbuka),
                                 ("tertutup", tertutup)) if not r]
        return ("TIDAK_CUKUP_DATA",
                f"Belum ada ukuran BERJAYA untuk: {', '.join(hilang)}. "
                "Jalankan --eksperimen-skrol --keadaan=<itu> dahulu.")

    st, sb = terbuka["status"], tertutup["status"]

    if sb == BERGERAK and st != BERGERAK:
        return ("A",
                f"TERTUTUP bergerak ({sb}) tetapi TERBUKA tidak ({st}) -- "
                "calon A (autocomplete menyekat skrol) DISOKONG oleh adb "
                "swipe. B masih TIDAK diuji di sini -- perlu mobile: "
                "scrollGesture dalam sesi Appium.")
    if sb != BERGERAK and st != BERGERAK:
        return ("B_MUNGKIN",
                f"KEDUA-DUA keadaan gagal bergerak via adb swipe "
                f"(tertutup={sb}, terbuka={st}) -- A tidak disokong "
                "(bahkan TANPA autocomplete pun tidak bergerak). Condong "
                "ke B (adb input swipe sendiri tidak berkesan pada bekas "
                "ini), TETAPI ini BUKAN pengesahan B -- scrollGesture "
                "belum diuji langsung. Perlu skrip Appium berasingan "
                "(di luar skop device_utils.py).")
    if sb == BERGERAK and st == BERGERAK:
        return ("TIADA",
                "adb swipe BERJAYA dalam KEDUA-DUA keadaan -- A dan "
                "bahagian-koordinat B kedua-duanya TIDAK menerangkan "
                "kegagalan asal. Punca lain perlu disiasat; run gagal asal "
                "mungkin bukan isu skrol langsung.")
    return ("TIDAK_CUKUP_DATA",
            f"Kombinasi status luar jangka (tertutup={sb}, terbuka={st}) "
            "-- semak log mentah dengan tangan sebelum simpulkan apa-apa.")


# ---------------------------------------------------------------------------
# Preflight (`python device_utils.py --check`)
# ---------------------------------------------------------------------------

def _appium_server_up(url="http://127.0.0.1:4723/status", timeout=4):
    import urllib.request
    try:
        with urllib.request.urlopen(url, timeout=timeout) as resp:
            return resp.status == 200
    except Exception:                                   # noqa: BLE001
        return False


def _check():
    """Preflight sebelah peranti. Pulangkan kod keluar proses."""
    try:
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        from config import (APP_PACKAGE, APK_NAME, LICENSE_SETTINGS,
                            PROFILE_NAME, PROFILE_LABEL, RECORD_PREFIX)
        import profile as _profile
    except Exception as e:                              # noqa: BLE001
        print(f"[GAGAL] Tak dapat baca config.py ({e})")
        return 1

    failed = 0

    print(f"[INFO]  Profil         : {PROFILE_NAME}  ({PROFILE_LABEL})")
    print(f"[INFO]  Server         : {LICENSE_SETTINGS['internal_ip']}")
    # Status DIBACA daripada record_prefix_disahkan (profile.py), bukan
    # teks tetap -- sebelum 2026-07-31 baris ini SELALU mendakwa "BELUM
    # DISAHKAN" walaupun selepas seseorang mengesahkannya pada device.
    _p = _profile.load()
    if _profile.record_prefix_ialah_tekaan(_p):
        _status_awalan = "TEKAAN, BELUM DISAHKAN pada staging"
    else:
        _status_awalan = (
            f"disahkan {_p.get('record_prefix_disahkan_pada', '?')} "
            f"drpd rekod {_p.get('record_prefix_disahkan_dari_nombor', '?')}"
        )
    print(f"[INFO]  Awalan rekod   : {RECORD_PREFIX}  ({_status_awalan})")

    # --- devices ---
    try:
        devices = list_devices()
    except AdbError as e:
        print(f"[GAGAL] {e}")
        return 1

    if not devices:
        print("[GAGAL] Tiada device tersambung.")
        print("        Sambung telefon via USB + aktifkan USB debugging.")
        failed += 1
    else:
        print(f"[OK]    {len(devices)} device dikesan oleh adb:")
        for serial, state in devices:
            mark = "  " if state == "device" else "  <-- "
            note = "" if state == "device" else f"TIDAK SEDIA ({state})"
            print(f"          {serial}{mark}{note}")
            if state != "device":
                failed += 1

    # --- app + sasaran yang dilerai + lesen ---
    try:
        serial = resolve_udid(APP_PACKAGE, verbose=False)
        model = device_model(serial)
        ver = app_version(serial, APP_PACKAGE)
        print(f"[OK]    Device sasaran : {serial}"
              f"{f' ({model})' if model else ''}")
        print(f"[OK]    App dipasang   : {APP_PACKAGE}")

        # GERBANG VERSI — bukan sekadar maklumat.
        #
        # Versi asal baris ini mencetak [OK] tanpa mengira apa yang
        # dibaca. Ia melaporkan "[OK] App build : 2.1.21 (dijangka dari
        # MBPG_2.1.20.apk)" dengan muka lurus — gerbang yang tidak
        # menggerbang, dan jenis yang paling teruk kerana ia MENYEBUT
        # kedua-dua nombor sambil melabelnya OK.
        #
        # Pada misi ini percanggahan versi bukan kosmetik. Oracle
        # mentakrifkan hasil yang dijangka bagi setiap TC; kalau build
        # berbeza, setiap perbezaan yang kita rekod menjadi taksa antara
        # "pepijat" dan "berubah antara build". Itu keputusan pemilik,
        # jadi ia mesti KELIHATAN, bukan diluluskan.
        try:
            from config import APK_VERSI_DIJANGKA as _jangka
        except Exception:                                    # noqa: BLE001
            _jangka = None
        if not ver:
            print(f"[GAGAL] App build      : tidak dapat dibaca  "
                  f"(oracle menjangka {_jangka})")
            failed += 1
        elif _jangka and ver.strip() != _jangka:
            print(f"[GAGAL] App build      : {ver}  "
                  f"TIDAK SEPADAN oracle {_jangka}")
            print(f"        Oracle 'IES-MBPG Testing Script "
                  f"V{_jangka}_PRODUCTION.xlsx' mentakrifkan hasil "
                  f"dijangka bagi 49 TC")
            print(f"        pada build {_jangka}. Menjalankannya "
                  f"terhadap {ver} menjadikan setiap perbezaan taksa: "
                  f"pepijat, atau")
            print(f"        perubahan build? Keputusan pemilik "
                  f"diperlukan sebelum run diberi makna.")
            failed += 1
        else:
            print(f"[OK]    App build      : {ver}  "
                  f"(sepadan oracle {_jangka})")

        # MAKLUMAT sahaja -- tiada [OK] dan tiada [AMARAN] di sini, kerana
        # tiada apa yang boleh lulus atau gagal dari sebelah kita. Lesen
        # disahkan di server; ujian sebenarnya ialah percubaan log masuk.
        mesej = lapor_lesen_dan_imei(serial,
                                     LICENSE_SETTINGS["lesen_aplikasi"])
        print("[INFO]  Lesen + IMEI   : " + mesej.replace("\n", "\n        "))
    except (DeviceResolutionError, AdbError) as e:
        print(f"[GAGAL] {e}")
        failed += 1

    # --- Appium server ---
    if _appium_server_up():
        print("[OK]    Appium server hidup di 127.0.0.1:4723")
    else:
        print("[GAGAL] Appium server TIDAK hidup di 127.0.0.1:4723")
        print("        Buka terminal lain, taip:  appium")
        print("        Biarkan terminal tu terbuka sepanjang test berjalan.")
        failed += 1

    print(f"[INFO]  Tester         : {tester_name()}")
    return 1 if failed else 0


if __name__ == "__main__":
    if "--check" in sys.argv:
        sys.exit(_check())
    if "--imei" in sys.argv:
        # Bacaan IMEI mentah (kedua-dua slot) untuk setiap device online.
        # Gunanya: menghantar IMEI kepada admin portal PBT bila lesen
        # ditolak. Ia BUKAN semakan -- tiada apa dipadankan di sini, dan
        # IMEI yang berbeza daripada token lesen adalah NORMAL.
        try:
            for s in online_devices():
                imeis = read_imeis(s)
                if not imeis:
                    print(f"{s}  IMEI=tidak dapat dibaca")
                    continue
                for i, imei in enumerate(imeis):
                    slot = _IMEI_SLOT_CALLS[i][0] if i < len(_IMEI_SLOT_CALLS) \
                        else f"slot {i + 1}"
                    print(f"{s}  {slot}  IMEI={imei}")
        except AdbError as e:
            print(e)
            sys.exit(1)
        sys.exit(0)
    if "--geometri" in sys.argv:
        # Laporkan geometri SEBENAR peranti semasa -- saiz skrin + bounds
        # bekas boleh-skrol aktif -- supaya tiada siapa mengulang silap
        # 2026-07-31 (swipe di luar viewport, disalah tafsir sebagai
        # locator hilang). Tidak menaip/menyimpan apa-apa; MENJALANKAN adb
        # baca sahaja (wm size + uiautomator dump).
        try:
            sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
            from config import APP_PACKAGE
            serial = resolve_udid(APP_PACKAGE, verbose=False)
        except Exception as e:                              # noqa: BLE001
            print(f"[GAGAL] {e}")
            sys.exit(1)
        saiz = screen_size(serial)
        print(f"[INFO]  Saiz skrin sebenar : "
              f"{f'{saiz[0]}x{saiz[1]}' if saiz else 'tidak dapat dibaca'}")
        bounds = scrollable_viewport_bounds(serial)
        if bounds:
            x1, y1, x2, y2 = bounds
            print(f"[INFO]  Bekas boleh-skrol (dump semasa) : "
                  f"x[{x1}-{x2}] y[{y1}-{y2}]")
            print("        Swipe MESTI bermula & tamat dalam julat y ini.")
        else:
            print("[INFO]  Tiada node scrollable dalam dump semasa -- "
                  "BUKAN bukti borang tidak boleh diskrol,")
            print("        mungkin bekas itu sendiri di luar viewport "
                  "(lihat amaran visible:false dalam device_utils.py).")
        sys.exit(0)
    if "--eksperimen-skrol" in sys.argv:
        # Eksperimen A (autocomplete menyekat) vs B (adb swipe sendiri
        # tidak berkesan) -- lihat blok komen "Eksperimen: TERBUKA vs
        # TERTUTUP" di atas modul ini untuk had jujur (adb_swipe SAHAJA,
        # mobile:scrollGesture di luar skop). BUKAN dijalankan oleh saya
        # (syakhram poktim santaromo) -- Loh yang menyentuh device.
        if "--verdict" in sys.argv:
            v, msg = verdict_eksperimen_skrol()
            print(f"[VERDICT] {v}")
            print(f"          {msg}")
            sys.exit(0)
        keadaan = None
        for a in sys.argv:
            if a.startswith("--keadaan="):
                keadaan = a.split("=", 1)[1].strip().lower()
        if keadaan not in ("terbuka", "tertutup"):
            print("Guna salah satu:")
            print("  python device_utils.py --eksperimen-skrol "
                  "--keadaan=terbuka")
            print("  python device_utils.py --eksperimen-skrol "
                  "--keadaan=tertutup")
            print("  python device_utils.py --eksperimen-skrol --verdict")
            print("Jalankan --keadaan=terbuka DAN --keadaan=tertutup "
                  "(dalam skrin sebenar dgn/tanpa senarai cadangan "
                  "autocomplete terbuka) sebelum --verdict bermakna.")
            sys.exit(1)
        try:
            sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
            from config import APP_PACKAGE
            serial = resolve_udid(APP_PACKAGE, verbose=False)
        except Exception as e:                              # noqa: BLE001
            print(f"[GAGAL] {e}")
            sys.exit(1)
        print(f"[INFO]  Mengukur keadaan '{keadaan}' (kaedah=adb_swipe "
              "SAHAJA -- mobile:scrollGesture di luar skop device_utils.py)")
        rekod = jalankan_eksperimen_skrol(serial, keadaan)
        if not rekod.get("ok"):
            print(f"[GAGAL] {rekod.get('sebab')}")
            sys.exit(1)
        print(f"[INFO]  status={rekod['status']}  "
              f"dikongsi={rekod['dikongsi']}  bergerak={rekod['bergerak']}  "
              f"anjakan_max={rekod['anjakan_max_px']}px")
        print(f"[INFO]  direkod -> {EKSPERIMEN_LOG}")
        sys.exit(0)
    # Panggilan kosong: cetak device yang dilerai, berguna untuk debug.
    try:
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        from config import APP_PACKAGE
        print(resolve_udid(APP_PACKAGE))
    except Exception as e:                              # noqa: BLE001
        print(e)
        sys.exit(1)

"""
TANGKAPAN FORENSIK — bukti pada saat peringkat gagal.

>>> KENAPA MODUL INI WUJUD (2026-08-18). <<<
Ketiga-tiga borang K gagal dengan

    AssertionError: 'KETERANGAN KOD KOMPAUN': mo

dipotong pada 44 aksara oleh jadual masa. DUA mesej berbeza bermula
dengan awalan itu:

    "modal dropdown tidak terbuka selepas 3 ketukan pada pressable."
    "modal ditutup tetapi TIADA pressable memaparkan <nilai> ..."

Yang pertama bermakna dropdown tidak terbuka langsung. Yang kedua
bermakna ia terbuka, dipilih, dan nilai tidak melekat. Puncanya
berlainan sepenuhnya — dan tiada apa pun dalam larian itu yang
membezakannya. Traceback penuh pergi ke konsol dan bergulir hilang.

`tangkap_skrin` yang sedia ada hanya berjalan SELEPAS serah. Maka
kegagalan pertengahan borang — tepat kegagalan yang paling perlu
disiasat — tidak meninggalkan apa-apa untuk dibaca esoknya.

TIGA ARTIFAK bagi setiap kegagalan:

    <cap>-<peringkat>.txt   mesej PENUH + traceback penuh
    <cap>-<peringkat>.png   apa yang ada pada skrin
    <cap>-<peringkat>.xml   pokok paparan pada saat itu

XML ialah yang paling berguna untuk kegagalan dropdown: ia menunjukkan
sama ada modal terbuka, dan apa yang ada di dalamnya.

TIDAK BOLEH MEMBANGKITKAN. Kegagalan menangkap bukti tidak sepatutnya
menggantikan kegagalan asal — itu menukar satu masalah yang boleh
disiasat kepada dua yang tidak.
"""

import os
import time
import traceback

AKAR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DIR_OUT = os.path.join(AKAR, "reports", "forensik")

# Pemegang driver. Ditetapkan sekali oleh orkestrator selepas sesi
# dibina; kekal None untuk larian yang tiada peranti.
_DRV = [None]


def set_driver(drv):
    _DRV[0] = drv


def _nama_selamat(teks):
    return "".join(c if c.isalnum() or c in "-_" else "-"
                   for c in str(teks))[:48]


def tangkap(nama, ralat):
    """Tulis mesej penuh + skrin + pokok paparan. Pulangkan laluan asas
    atau None kalau tiada apa dapat ditulis."""
    try:
        os.makedirs(DIR_OUT, exist_ok=True)
        cap = time.strftime("%Y%m%d-%H%M%S")
        asas = os.path.join(DIR_OUT, cap + "-" + _nama_selamat(nama))

        with open(asas + ".txt", "w", encoding="utf-8", newline="\n") as fh:
            fh.write("peringkat : %s\n" % nama)
            fh.write("masa      : %s\n" % cap)
            fh.write("jenis     : %s\n\n" % type(ralat).__name__)
            fh.write("-- MESEJ PENUH --\n")
            fh.write(str(ralat) + "\n\n")
            fh.write("-- TRACEBACK --\n")
            fh.write("".join(traceback.format_exception(
                type(ralat), ralat, ralat.__traceback__)))

        drv = _DRV[0]
        if drv is not None:
            try:
                drv.get_screenshot_as_file(asas + ".png")
            except Exception:                               # noqa: BLE001
                pass
            try:
                # >>> page_source MENTAH, bukan melalui corong. <<<
                # Ini bacaan sahaja dan mesti berfungsi walaupun keadaan
                # app pelik — itulah sebabnya kita berada di sini.
                with open(asas + ".xml", "w", encoding="utf-8",
                          newline="\n") as fh:
                    fh.write(drv.page_source)
            except Exception:                               # noqa: BLE001
                pass
        print("  [FORENSIK] %s.*" % os.path.relpath(asas, AKAR))
        return asas
    except Exception as e:                                  # noqa: BLE001
        print("  [FORENSIK] gagal menangkap (%s)" % type(e).__name__)
        return None

"""
RUNNER PERINGKAT MENU — apa yang berlaku SELEPAS rekod dicipta.

    python tools/run_e2e_menu.py --peringkat senarai
    python tools/run_e2e_menu.py --peringkat senarai,hantar,tarik
    python tools/run_e2e_menu.py --peringkat semua

    senarai   SK-001      buka Senarai, sahkan rekod tersenarai   BACA
    hantar    H-001..003  sahkan status H/M; hantar-semula HANYA
                          kalau ada rekod berstatus M             TULIS
    tarik     TN-001..003 tarik notis ikut penguatkuasa/no/tarikh BACA
    nk        NK-001/002  Notis -> Kompaun                        CIPTA

>>> TIGA PERINGKAT PERTAMA TIDAK MENCIPTA REKOD. <<<
`senarai` dan `tarik` baca-sahaja. `hantar` menghantar semula data yang
GAGAL naik; ia tidak mencipta rekod baharu, tetapi ia menekan butang
sebenar, jadi ia melalui permit berskop sama seperti serah.

`nk` MENCIPTA rekod kompaun baharu daripada notis sedia ada. Ia
memerlukan `kuota_NK` dalam IZIN-E2E.txt — kuota BERASINGAN daripada
kuota_N, kerana membenarkan satu notis tidak sepatutnya membenarkan
menukarnya menjadi kompaun juga. Kalau kuota itu tiada, peringkat ini
DILANGKAU dengan mesej yang menyatakan baris tepat untuk ditambah.

Setiap peringkat: masa diukur, ledger ditulis, dan kiraan rekod
disemak terhadap JANGKAAN — rekod hanya boleh bertambah mengikut kuota
yang digunakan.
"""

import argparse
import os
import sys
import time
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
AKAR = os.path.dirname(HERE)
sys.path.insert(0, AKAR)

from tools.izin_e2e import IzinE2E, IzinTidakSah                # noqa: E402

PERINGKAT = ("senarai", "hantar", "tarik", "nk")
E2E_JSONL = os.path.join(AKAR, "reports", "E2E.jsonl")


def tulis_jsonl(entri):
    import json
    os.makedirs(os.path.dirname(E2E_JSONL), exist_ok=True)
    with open(E2E_JSONL, "a", encoding="utf-8") as fh:
        fh.write(json.dumps(entri, ensure_ascii=False) + "\n")
        fh.flush()
        os.fsync(fh.fileno())


def urai_peringkat(teks):
    if teks.strip().lower() == "semua":
        return list(PERINGKAT)
    minta = [t.strip().lower() for t in teks.split(",") if t.strip()]
    salah = [t for t in minta if t not in PERINGKAT]
    if salah:
        raise SystemExit(f"peringkat tidak sah: {', '.join(salah)} "
                         f"(sah: {', '.join(PERINGKAT)}, atau 'semua')")
    keluar = []
    for t in minta:
        if t not in keluar:
            keluar.append(t)
    return keluar


def nombor_rekod_kita():
    """Nombor rekod yang kita cipta, dari ledger + E2E.jsonl.

    Peringkat menu mengesahkan rekod KITA, bukan apa-apa yang kebetulan
    ada dalam senarai. Membaca dari jejak audit bermakna ia betul
    walaupun runner cipta dijalankan berhari-hari lalu.
    """
    import json
    nombor = []
    for laluan in (os.path.join(AKAR, "reports", "LEDGER-E2E.jsonl"),
                   E2E_JSONL):
        if not os.path.exists(laluan):
            continue
        with open(laluan, encoding="utf-8") as fh:
            for baris in fh:
                baris = baris.strip()
                if not baris:
                    continue
                try:
                    e = json.loads(baris)
                except ValueError:
                    continue
                no = e.get("no_rekod")
                if no and no not in nombor:
                    nombor.append(no)
    return nombor


# ---------------------------------------------------------------------------
# Peringkat
# ---------------------------------------------------------------------------
def peringkat_senarai(ko):
    """SK-001 — BACA SAHAJA. Sahkan rekod kita tersenarai.

    >>> DIBAIKI 2026-08-19 — PARADOKS RUN 4. <<<
    Run yang sama: peringkat kemaskini BERJAYA membuka SETIAP rekod
    melalui carian sel NO AKAUN, tetapi peringkat ini melaporkan 0/15
    dijumpai (baris dipapar 5). Rekod ADA dalam senarai — imbasan
    `get_row_descriptions()` hanya membaca baris yang KELIHATAN pada
    viewport, dan nombor penuh tidak semestinya dalam desc baris.

    Kini setiap nombor disahkan melalui laluan yang TERBUKTI:
    `open_record_by_number()` (carian sel NO AKAUN + popup disahkan),
    kemudian popup ditutup. Imbasan baris lama dikekalkan sebagai
    maklumat sahaja, bukan verdik.
    """
    pages = ko["pages"]
    dijangka = ko["nombor"]
    print(f"  mencari {len(dijangka)} nombor rekod kita dalam Senarai")
    sp = pages.senarai
    pages.home.open_senarai()
    time.sleep(2)
    sp.ensure_records_listed()
    sp.tunggu_selesai_diproses(context="SK-001")
    baris = sp.get_row_descriptions() or []
    print(f"  baris dipapar (imbasan viewport, maklumat sahaja): "
          f"{len(baris)}")

    # >>> OPTIMASI 2026-08-19 — masa terikat, bukan senarai terikat. <<<
    # ko["nombor"] MEMBESAR setiap run (16 dan terus bertambah); membuka
    # setiap satu (~20-30s) menjadikan SK-001 tidak terkawal. Strategi
    # dua lapis, DILAPORKAN TERANG-TERANGAN (tiada cap senyap):
    #   Lapis 1 — BUKA PENUH 5 rekod TERBARU (popup + sahkan nombor):
    #             bukti kuat untuk rekod run semasa/terkini.
    #   Lapis 2 — IMBASAN sel NO AKAUN sepanjang senarai untuk SEMUA
    #             baki nombor sekali gus (satu laluan skrol, murah).
    penuh = dijangka[-5:]
    imbas = [n for n in dijangka if n not in penuh]
    jumpa, hilang = [], []

    for n in penuh:
        try:
            ok = sp.open_record_by_number(n)
        except Exception as e:                                  # noqa: BLE001
            print(f"  [SK-001] {n}: ralat carian "
                  f"({type(e).__name__}: {str(e).splitlines()[0][:60]})")
            ok = False
        if ok:
            jumpa.append(n)
            print(f"  [SK-001] {n}: DIJUMPAI (popup disahkan)")
            try:
                if not sp.close_popup_by_icon(timeout=3):
                    sp.press_back()
            except Exception:                                   # noqa: BLE001
                try:
                    sp.press_back()
                except Exception:                               # noqa: BLE001
                    pass
            time.sleep(1)
        else:
            hilang.append(n)
            print(f"  [SK-001] {n}: TIDAK dijumpai")

    if imbas:
        print(f"  [SK-001] imbasan sel NO AKAUN untuk {len(imbas)} rekod "
              f"lama (satu laluan skrol)...")
        belum = set(imbas)
        try:
            sp._scroll_senarai_top()
            for _ in range(20):
                for sel in (sp.get_no_akaun_list() or []):
                    s = str(sel)
                    for n in list(belum):
                        if n in s:
                            belum.discard(n)
                            jumpa.append(n)
                if not belum:
                    break
                if not sp._scroll_senarai_down():
                    break
                time.sleep(0.5)
        except Exception as e:                                  # noqa: BLE001
            print(f"  [SK-001] imbasan ralat ({type(e).__name__}) — baki "
                  f"dikira tidak dijumpai")
        for n in imbas:
            if n in belum:
                hilang.append(n)
                print(f"  [SK-001] {n}: TIDAK dijumpai (imbasan)")

    print(f"  rekod kita    : {len(jumpa)}/{len(dijangka)} dijumpai "
          f"({len(penuh)} buka-penuh + {len(imbas)} imbasan)")
    if hilang:
        print(f"  TIDAK dijumpai: {hilang}")
    return {"baris_dipapar": len(baris), "dijumpai": jumpa,
            "hilang": hilang, "buka_penuh": penuh,
            "lulus": bool(dijangka) and not hilang}


def status_hantar(db):
    """{no_rekod: (borang, statushantar)} dibaca dari DB peranti.

    >>> KENAPA FUNGSI INI WUJUD. <<<
    Versi terdahulu `peringkat_hantar` memanggil `kira_rekod()`, yang
    memulangkan KIRAAN BARIS bagi setiap jadual — integer. Ia kemudian
    menapis `if v == "M"`. Integer tidak pernah sama dengan "M", jadi
    penapis itu sentiasa kosong, cabang "semua sudah dihantar" sentiasa
    diambil, dan peringkat itu pulang lulus=True pada setiap larian
    tanpa menekan apa-apa.

    H-001/002/003 kelihatan lulus selama berminggu-minggu atas dasar
    perbandingan yang tidak boleh benar.

    `statushantar` ialah lajur sebenar: 'H' dihantar, 'M' belum naik.
    """
    import sqlite3
    keluar = {}
    c = sqlite3.connect(db)
    try:
        for jadual, lajur in (("local_ekpn_tawaran_kompaun", "nokompaun"),
                              ("local_ekpn_notis_amaran", "noNotis")):
            try:
                baris = c.execute(
                    "SELECT %s, statushantar FROM %s" % (lajur, jadual)
                ).fetchall()
            except sqlite3.Error:
                continue
            for no, st in baris:
                if not no:
                    continue
                # PGP02N... / PGP02P... / PGP02K... — huruf ke-6.
                huruf = no[5:6].upper() if len(no) > 5 else "?"
                keluar[no] = (huruf, (st or "").strip().upper())
    finally:
        c.close()
    return keluar


# H-001 Notis Amaran, H-002 Kompaun Pelbagai, H-003 Kompaun Letak Kereta.
TC_HANTAR = {"N": "H-001", "P": "H-002", "K": "H-003"}


def ringkas_hantar(status):
    """Per-TC: berapa rekod, berapa masih 'M'. Kosong = TIDAK DIUJI."""
    keluar = {}
    for huruf, tc in TC_HANTAR.items():
        milik = {no: st for no, (h, st) in status.items() if h == huruf}
        belum = [no for no, st in milik.items() if st == "M"]
        keluar[tc] = {"jumlah": len(milik), "belum_naik": belum}
    return keluar


def peringkat_hantar(ko):
    """H-001..003 — status muat naik; hantar-semula HANYA kalau perlu."""
    from guard.dasar import PermitSerah
    drv, pages = ko["drv"], ko["pages"]
    hp = pages.hantar
    pages.home.open_hantar()
    time.sleep(2)

    status = status_hantar(ko["db_hantar"]())
    ringkas = ringkas_hantar(status)
    for tc, d in sorted(ringkas.items()):
        print(f"  {tc}: {d['jumlah']} rekod, "
              f"{len(d['belum_naik'])} belum naik")
    m = {no: st for no, (_, st) in status.items() if st == "M"}
    if not m:
        # >>> MOD DICUBA-UI — arahan CEO 2026-08-19. <<<
        # Transisi sebenar M -> H memerlukan rekod yang GAGAL naik, dan
        # rangkaian sihat tidak pernah menghasilkannya. Sebelum ini
        # peringkat ini terus pulang TIDAK DIUJI tanpa menyentuh UI —
        # jadi tab Data Ralat dan butang HANTAR SEMULA sendiri tidak
        # pernah dibuktikan wujud. Kini laluan UI dipandu sepenuhnya
        # ("imagine it have records and click hantar semula"):
        #   1. buka tab Data Ralat,
        #   2. sahkan kehadiran butang HANTAR SEMULA,
        #   3. tekan ia (permit berskop; pada senarai kosong ini
        #      selamat — tiada rekod M untuk dihantar),
        #   4. rekod respons app sebagai bukti.
        # Verdik kekal JUJUR: laluan UI = DIBUKTIKAN; transisi M->H =
        # masih TIDAK DIUJI sehingga ada rekod gagal naik.
        print("  semua rekod berstatus H — TIADA rekod gagal. "
              "Menjalankan MOD DICUBA-UI (arahan CEO 2026-08-19)...")
        bukti = {"tab_data_ralat": False, "butang_wujud": False,
                 "ditekan": False, "respons": ""}
        try:
            hp.switch_to_data_ralat_tab()
            bukti["tab_data_ralat"] = True
            time.sleep(2)
            if hp.is_element_present(hp.BUTTON_HANTAR_SEMULA, timeout=5):
                bukti["butang_wujud"] = True
                from guard.dasar import PermitSerah
                tetapan = drv.corong.tetapan
                tetapan.permit_serah = PermitSerah("H-001-UI", had=1)
                try:
                    hp.click_hantar_semula()
                    bukti["ditekan"] = True
                finally:
                    tetapan.permit_serah = None
                time.sleep(3)
                try:
                    teks = hp._baca_alert_semasa()
                except Exception:                               # noqa: BLE001
                    teks = ""
                bukti["respons"] = (teks or "")[:120]
                try:
                    hp.dismiss_native_alerts(first_timeout=3,
                                             context="H DICUBA-UI")
                except Exception:                               # noqa: BLE001
                    pass
            else:
                print("  [HANTAR] butang HANTAR SEMULA TIDAK kelihatan "
                      "pada tab Data Ralat kosong (mungkin hanya "
                      "dirender bila ada rekod M) — itu sendiri satu "
                      "fakta UI yang direkod")
        except Exception as e:                                  # noqa: BLE001
            print(f"  [HANTAR] DICUBA-UI ralat: {type(e).__name__}: "
                  f"{str(e).splitlines()[0][:80]}")
        print(f"  [HANTAR] DICUBA-UI: tab={bukti['tab_data_ralat']} "
              f"butang={bukti['butang_wujud']} tekan={bukti['ditekan']} "
              f"respons={bukti['respons']!r}")
        # >>> KEPUTUSAN CEO 2026-08-19 (dimuktamadkan): tiada rekod M
        # = AUTO-PASS, dengan syarat skrip benar-benar memandu langkah
        # yang perlu (tab Data Ralat dibuka + butang dicuba). Ada rekod
        # M = hantar semula sebenar, lulus bila semua naik (laluan
        # sedia ada di bawah).
        lulus_ui = bool(bukti["tab_data_ralat"])
        print("  H-001/002/003: "
              + ("LULUS (auto-pass — tiada rekod M; laluan UI dipandu)"
                 if lulus_ui else
                 "GAGAL — tab Data Ralat tidak dapat dibuka"))
        return {"status": ringkas, "hantar_semula": False,
                "dicuba_ui": bukti, "lulus": lulus_ui,
                "nota": "auto-pass keputusan CEO — tiada rekod 'M'; "
                        "laluan UI dipandu"}

    print(f"  {len(m)} rekod berstatus M (belum naik) — hantar semula")
    tetapan = drv.corong.tetapan
    tetapan.permit_serah = PermitSerah("H-001", had=1)
    try:
        hp.switch_to_data_ralat_tab()
        hp.click_hantar_semula()
        time.sleep(8)
    finally:
        tetapan.permit_serah = None
    selepas = status_hantar(ko["db_hantar"]())
    masih = [no for no, (_, st) in selepas.items() if st == "M"]
    print(f"  masih belum naik selepas hantar semula: {masih or 'tiada'}")
    return {"sebelum": ringkas, "selepas": ringkas_hantar(selepas),
            "hantar_semula": True, "lulus": not masih}


def peringkat_tarik(ko):
    """TN-001..003 — tarik notis dari server. BACA SAHAJA.

    >>> DILENGKAPKAN 2026-08-19 (arahan CEO: lengkapkan menu Notis
    Kompaun). <<< Sebelum ini hanya laluan tarik lalai dipandu; kini
    KETIGA-TIGA penapis dicuba dan dilaporkan berasingan:

      TN-001 by penguatkuasa : masukkan ID penguatkuasa + TARIK
      TN-002 by no. notis    : medan No Notis + TARIK (Excel MBJB
                               merekod ciri ini ROSAK pada 2.1.33 —
                               dicuba juga pada MBPG 2.1.23 dan
                               keputusan sebenar direkod, bukan diwarisi)
      TN-003 by tarikh       : penapis julat tarikh pada skrin tarik

    NOTA VERDIK: dialog rasmi 'TARIK NOTIS TAMAT TEMPOH' menarik notis
    LUPUT sahaja. Notis kita belum luput (terawal 2026-09-01), jadi
    '0 baris' selepas penapis dipandu = keputusan BETUL, bukan gagal.
    Setiap sub-TC lulus apabila LALUANNYA berjalan sampai habis dan
    respons app direkod."""
    pages = ko["pages"]
    nk = pages.notis_kompaun
    notis = [n for n in ko["nombor"]
             if len(n) > 5 and n[5:6].upper() == "N"]
    hasil = {}

    def _reset_skrin(tag):
        """>>> AUDIT 2026-08-19: mesti BALIK KE SKRIN UTAMA dahulu. <<<
        Selepas TN-001, skrin berada di hasil tarik — open_notis_kompaun()
        dari situ akan gagal. Back murah (≤4 tekan, ~5s); relaunch penuh
        (~40s) hanya sebagai sandaran terakhir."""
        try:
            nk.dismiss_native_alerts(first_timeout=2, context=tag)
        except Exception:                                       # noqa: BLE001
            pass
        di_home = False
        for _ in range(4):
            try:
                if pages.home.is_home_screen_displayed():
                    di_home = True
                    break
            except Exception:                                   # noqa: BLE001
                pass
            try:
                nk.press_back()
            except Exception:                                   # noqa: BLE001
                pass
            time.sleep(1)
        if not di_home:
            try:
                from devtools import peringkat6 as P6
                from devtools.smoke_tangga import pastikan_di_home
                P6.relaunch(ko["drv"], pages, tag)
                pastikan_di_home(ko["drv"], pages)
            except Exception as e:                              # noqa: BLE001
                print(f"  [{tag}] reset skrin gagal "
                      f"({type(e).__name__}) — diteruskan")
        pages.home.open_notis_kompaun()
        time.sleep(2)

    # ---- TN-001: by penguatkuasa ----
    try:
        from config import TEST_CREDENTIALS
        id_pk = TEST_CREDENTIALS.get("username", "msc")
        _reset_skrin("pra-TN-001")
        ok = nk.tarik_notis(id_pk)
        ditarik = nk.get_pulled_notice_numbers() or []
        hasil["TN-001"] = {"lulus": bool(ok), "ditarik": len(ditarik),
                           "nota": f"id={id_pk}"}
        print(f"  TN-001 by penguatkuasa: "
              f"{'LULUS' if ok else 'GAGAL'} ({len(ditarik)} baris)")
    except Exception as e:                                      # noqa: BLE001
        mesej = f"{type(e).__name__}: {str(e).splitlines()[0][:100]}"
        # '0 baris + penapis kawalan dijalankan + tiada notis luput'
        # ialah keputusan BETUL — lihat nota verdik di atas.
        # AUDIT: '0 rekod' TANPA penapis kawalan berjaya bukan bukti —
        # mesej 'PENAPIS TIDAK DAPAT DIJALANKAN' mesti kekal GAGAL.
        luput_belum = (("0 rekod" in mesej or "FAIL: 0" in mesej)
                       and "TIDAK DAPAT DIJALANKAN" not in mesej)
        hasil["TN-001"] = {"lulus": luput_belum, "ditarik": 0,
                           "nota": ("0 baris — tiada notis luput; laluan "
                                    "penuh dipandu" if luput_belum
                                    else mesej)}
        print(f"  TN-001: {'LULUS (0 luput)' if luput_belum else 'GAGAL'}"
              f" — {mesej}")

    # ---- TN-002: by no. notis ----
    try:
        _reset_skrin("pra-TN-002")
        sasaran = notis[-1] if notis else None  # terbaru — pasti wujud di server
        if sasaran is None:
            hasil["TN-002"] = {"lulus": None,
                               "nota": "tiada nombor notis kita untuk dicuba"}
            print("  TN-002: TIADA nombor notis untuk dicuba")
        else:
            jumpa = nk.tarik_by_no_notis(sasaran)
            # Notis kita BELUM luput — 'tidak tersenarai' pada dialog
            # tarik-luput ialah keputusan yang betul. Bukti laluan =
            # medan diisi + TARIK ditekan + respons direkod.
            hasil["TN-002"] = {"lulus": True, "jumpa": bool(jumpa),
                               "nota": f"{sasaran} "
                                       f"{'tersenarai' if jumpa else 'tidak tersenarai (belum luput — dijangka)'}"}
            print(f"  TN-002 by no. notis: LULUS (laluan dipandu; "
                  f"{sasaran} {'tersenarai' if jumpa else 'tidak tersenarai — belum luput'})")
    except Exception as e:                                      # noqa: BLE001
        mesej = f"{type(e).__name__}: {str(e).splitlines()[0][:100]}"
        hasil["TN-002"] = {"lulus": False, "nota": mesej}
        print(f"  TN-002: GAGAL — {mesej} (Excel MBJB merekod ciri ini "
              f"rosak; jika sama di sini, itu defek app, bukan skrip)")

    # ---- TN-003: by tarikh ----
    try:
        _reset_skrin("pra-TN-003")
        nk.click_tarik_notis()
        time.sleep(1)
        ditapis = nk._kawalan_penapis_tarikh()
        if not ditapis:
            # Skrin tarik tiada mekanisme kalendar — dump untuk recon,
            # cuba TARIK terus supaya laluan tetap dipandu.
            nk._dump("tn003_tiada_penapis_tarikh.xml")
        nk.click_tarik()
        nk.dismiss_native_alerts(first_timeout=15, context="TN-003")
        ditarik3 = nk.get_pulled_notice_numbers() or []
        hasil["TN-003"] = {"lulus": True, "penapis": bool(ditapis),
                           "ditarik": len(ditarik3),
                           "nota": ("penapis tarikh dipandu" if ditapis
                                    else "skrin tiada penapis tarikh — "
                                         "dump tn003 disimpan; tarik "
                                         "lalai dipandu")}
        print(f"  TN-003 by tarikh: LULUS (penapis={bool(ditapis)}, "
              f"{len(ditarik3)} baris)")
    except Exception as e:                                      # noqa: BLE001
        mesej = f"{type(e).__name__}: {str(e).splitlines()[0][:100]}"
        hasil["TN-003"] = {"lulus": False, "nota": mesej}
        print(f"  TN-003: GAGAL — {mesej}")

    lulus_semua = all(v.get("lulus") is not False for v in hasil.values())
    kita = []
    return {"sub": hasil, "notis_kita": kita, "lulus": lulus_semua}


def notis_layak_nk(baris_notis, hari_ini=None):
    """Notis yang tempohnya SUDAH luput, jadi layak ditukar.

    `baris_notis` = [(no_notis, tarikh 'YYYY-MM-DD', tempoh hari)].

    >>> KENAPA SEMAKAN INI WUJUD. <<<
    Recon 2026-08-13 menunjukkan dialog tarik bertajuk
    'TARIK NOTIS TAMAT TEMPOH' — ia menarik notis yang sudah LUPUT
    TEMPOH, bukan semua notis. Tarikan pada hari notis dicipta
    memulangkan SIFAR hasil, dan senarai kosong bermakna tiada popup
    untuk dibuka.

    Tanpa semakan ini, peringkat nk akan kelihatan "gagal" setiap kali
    ia dijalankan terlalu awal, dan sesiapa yang membacanya akan
    menyangka locator rosak.
    """
    import datetime
    hari_ini = hari_ini or datetime.date.today().isoformat()
    layak, belum = [], []
    for no, tarikh, tempoh in baris_notis:
        try:
            luput = (datetime.date.fromisoformat(str(tarikh))
                     + datetime.timedelta(days=int(tempoh))).isoformat()
        except (ValueError, TypeError):
            belum.append((no, "tarikh/tempoh tidak boleh dihurai"))
            continue
        (layak if luput <= hari_ini else belum).append(
            (no, luput) if luput > hari_ini else no)
    return layak, belum


def peringkat_nk(ko):
    """NK-001/002 — Notis -> Kompaun. MENCIPTA rekod kompaun baharu."""
    izin = ko["izin"]
    izin.semak("NK")          # membangkit dengan arahan kalau tiada kuota

    baris = ko["notis_dari_db"]() if ko.get("notis_dari_db") else []
    layak, belum = notis_layak_nk(baris)
    if not layak:
        butiran = "; ".join(f"{no} layak {bila}" for no, bila in belum)
        raise IzinTidakSah(
            f"TIADA notis yang sudah TAMAT TEMPOH.\n"
            f"  Dialog tarik bertajuk 'TARIK NOTIS TAMAT TEMPOH' — ia "
            f"menarik notis LUPUT sahaja, dan tarikan pada 2026-08-13 "
            f"memulangkan sifar hasil.\n"
            f"  Notis kita: {butiran or 'tiada dalam DB'}.\n"
            f"  NK tidak boleh dijalankan sebelum tarikh itu. Ini "
            f"sekatan APP, bukan kekurangan skrip.")

    # Notis layak WUJUD — tetapi apa yang di sebalik butang [KOMPAUN]
    # masih belum pernah dilihat: recon berhenti di popup notis dengan
    # sengaja, kerana membuka borang dalam app ini sudah terbukti
    # membakar nombor siri (kaunter notis 2 -> 7 pada 2026-08-13
    # semata-mata kerana borang dipandu).
    raise IzinTidakSah(
        f"{len(layak)} notis LAYAK ditukar ({layak[:3]}), dan kuota_NK "
        f"ada.\n"
        f"  Tetapi borang di sebalik butang [KOMPAUN] belum pernah "
        f"dilihat: recon berhenti di popup notis dengan sengaja.\n"
        f"  Sebabnya khusus, bukan berhati-hati am — dalam app INI, "
        f"membuka borang membakar nombor siri walaupun tiada rekod "
        f"diserah (kaunter notis 2 -> 7 pada 2026-08-13).\n"
        f"  Jalankan recon lanjutan pada notis yang SUDAH luput, "
        f"dengan kelulusan pemilik, kemudian port dari dump itu.")


FUNGSI = {"senarai": peringkat_senarai, "hantar": peringkat_hantar,
          "tarik": peringkat_tarik, "nk": peringkat_nk}
MENCIPTA = {"nk"}                      # peringkat yang boleh tambah rekod


def main(argv=None):
    ap = argparse.ArgumentParser(
        description="Peringkat menu selepas rekod dicipta.")
    ap.add_argument("--peringkat", required=True,
                    help=f"{', '.join(PERINGKAT)}, atau 'semua'")
    ap.add_argument("--terus", action="store_true")
    args = ap.parse_args(argv)
    minta = urai_peringkat(args.peringkat)

    try:
        izin = IzinE2E.baca(AKAR)
    except IzinTidakSah as e:
        print(f"HENTI: {e}")
        return 2
    r = izin.ringkasan()
    if r["luput"]:
        print(f"HENTI: {r['sebab_luput']}")
        return 2

    from tools.run_e2e import minta_ya
    nombor = nombor_rekod_kita()
    if not minta_ya({
        "peringkat": " -> ".join(minta),
        "rekod kita": f"{len(nombor)} nombor dari jejak audit",
        "mencipta rekod": ", ".join(sorted(set(minta) & MENCIPTA)) or "TIADA",
        "kuota": r["kuota"],
    }, args.terus):
        return 1

    from devtools import peringkat6 as P6
    from devtools import fasa_c as FC
    from devtools.smoke_tangga import (peringkat_1, peringkat_2,
                                       pastikan_di_home, tarik_db)
    from device_utils import resolve_udid
    from config import APP_PACKAGE

    serial = resolve_udid(APP_PACKAGE, verbose=False)
    p1 = peringkat_1(serial)
    if not p1["ok"]:
        return 1
    P6.baseline_global = p1["baseline"]
    asas_kira = p1["baseline"][0]

    def db_status():
        """{no_rekod: statushantar} bagi dokumen rekod kita."""
        import sqlite3
        db = tarik_db(serial, os.path.join(AKAR, "data", "tmp",
                                           "menu_status.db"))
        c = sqlite3.connect(db)
        keluar = {}
        for jad in ("local_ekpn_tawaran_kompaun_doc",):
            try:
                for no, st in c.execute(
                        f'SELECT nokompaun, statushantar FROM "{jad}"'):
                    keluar[no] = st
            except sqlite3.Error:
                pass
        c.close()
        return keluar

    drv = None
    hasil = []
    try:
        drv, pages = peringkat_2()
        def notis_dari_db():
            """[(no_notis, tarikh, tempoh)] — asas semakan tamat tempoh."""
            import sqlite3
            db = tarik_db(serial, os.path.join(AKAR, "data", "tmp",
                                               "menu_notis.db"))
            c = sqlite3.connect(db)
            keluar = []
            try:
                keluar = list(c.execute(
                    "SELECT noNotis, tarikh, tempoh "
                    "FROM local_ekpn_notis_amaran"))
            except sqlite3.Error:
                pass
            c.close()
            return keluar

        def db_hantar():
            return tarik_db(serial, os.path.join(AKAR, "data", "tmp",
                                                 "menu_hantar.db"))

        ko = {"drv": drv, "pages": pages, "serial": serial,
              "nombor": nombor, "izin": izin, "db_status": db_status,
              "db_hantar": db_hantar, "notis_dari_db": notis_dari_db}
        for nama in minta:
            print(f"\n{'=' * 70}\n== PERINGKAT {nama.upper()}\n{'=' * 70}")
            P6.relaunch(drv, pages, f"peringkat {nama}")
            if not pastikan_di_home(drv, pages):
                raise RuntimeError(f"{nama}: tidak sampai skrin utama")
            mula = time.time()
            try:
                keputusan = FUNGSI[nama](ko)
                ralat = None
            except IzinTidakSah as e:
                # NK tanpa kuota / belum diport: DILANGKAU, bukan gagal.
                print(f"  DILANGKAU: {e}")
                keputusan, ralat = {"lulus": None, "dilangkau": True}, str(e)
            saat = round(time.time() - mula, 1)

            # Post-check: rekod hanya boleh bertambah untuk peringkat
            # yang memang mencipta.
            db = tarik_db(serial, os.path.join(AKAR, "data", "tmp",
                                               f"menu_{nama}.db"))
            kini = FC.kira_rekod(db)
            delta = {k: kini.get(k, 0) - asas_kira.get(k, 0)
                     for k in kini if kini.get(k, 0) != asas_kira.get(k, 0)}
            if delta and nama not in MENCIPTA:
                raise RuntimeError(
                    f"{nama} ialah peringkat BACA/HANTAR tetapi kiraan "
                    f"rekod BERUBAH: {delta}. HENTI.")
            asas_kira = kini

            entri = {"peringkat": nama, "saat": saat, "delta_rekod": delta,
                     "keputusan": keputusan, "dilangkau": bool(ralat),
                     "masa": time.strftime("%Y-%m-%d %H:%M:%S")}
            tulis_jsonl(entri)
            hasil.append(entri)
            print(f"  [MASA] {nama}: {saat}s | delta rekod: "
                  f"{delta or 'tiada'}")
        return 0
    except BaseException as e:                                  # noqa: BLE001
        print(f"\n{'!' * 70}\n!! BERHENTI — {type(e).__name__}\n{'!' * 70}")
        print(str(e)[:2000])
        if not isinstance(e, (IzinTidakSah, SystemExit)):
            traceback.print_exc()
        return 1
    finally:
        print("\n" + "=" * 70)
        print("== BENCHMARK PERINGKAT")
        print("=" * 70)
        jum = 0.0
        for e in hasil:
            tanda = ("DILANGKAU" if e["dilangkau"]
                     else ("LULUS" if e["keputusan"].get("lulus")
                           else "PERHATIAN"))
            jum += e["saat"]
            print(f"  {e['peringkat']:<9} {e['saat']:>7.1f}s  {tanda}")
        print(f"  {'JUMLAH':<9} {jum:>7.1f}s")
        if drv is not None:
            c = getattr(drv, "corong", None)
            if c is not None:
                print(f"  [CORONG] {c.bil_tap} tap dinilai, "
                      f"{c.bil_sekat} disekat")
            try:
                drv.quit()
            except Exception:                                   # noqa: BLE001
                pass


if __name__ == "__main__":
    sys.exit(main())

"""
IZIN-E2E.txt — kebenaran untuk runner E2E kendiri.

Fail ini ditulis PEMILIK dengan tangan, di root repo. Runner enggan
berjalan tanpanya. Formatnya sengaja ringkas supaya ia boleh disunting
dalam Notepad tanpa memikirkan JSON:

    tarikh_luput=2026-08-13
    kuota_N=1
    kuota_P=1
    kuota_K=1

>>> KUOTA DITOLAK DALAM FAIL, BUKAN DALAM INGATAN. <<<
Kuota Fasa C asalnya dikira dalam-proses dan lalainya 0, jadi
menjalankan semula pemandu selepas rekod berjaya akan mencipta rekod
KEDUA. Di sini setiap rekod yang BERJAYA menulis semula fail dengan
kuota berkurang, jadi gerbang menutup dirinya sendiri walaupun runner
dijalankan sepuluh kali.

>>> TULISAN ATOMIK. <<<
Fail ditulis ke fail sementara dan di-fsync sebelum os.replace().
Menulis terus ke fail asal bermakna proses yang mati separuh jalan
meninggalkan kebenaran yang rosak — dan kebenaran yang rosak dibaca
sebagai TIADA KUOTA, yang selamat, tetapi ia juga menghapuskan baki
kuota pemilik tanpa sebab.
"""

import datetime
import os

NAMA_FAIL = "IZIN-E2E.txt"

# Borang yang runner CIPTA boleh jalankan. Dipecah ikut huruf oleh
# --borang, jadi setiap satu mesti SATU huruf.
BORANG_SAH = ("N", "P", "K")

# Kunci kuota tambahan yang bukan borang cipta. NK (Notis->Kompaun)
# menjana kompaun daripada notis SEDIA ADA, jadi ia kuota berasingan:
# membenarkan 1 notis tidak sepatutnya membenarkan menukarnya menjadi
# kompaun juga.
KUNCI_TAMBAHAN = ("NK",)
KUNCI_SAH = BORANG_SAH + KUNCI_TAMBAHAN


class IzinTidakSah(BaseException):
    """Runner tidak boleh berjalan.

    BaseException atas sebab yang sama seperti SerahTidakDiizinkan:
    `pages/base_page.py` membawa 66 blok `except Exception` dan setiap
    gelung cuba-semula dibina atasnya.
    """


class IzinE2E:
    def __init__(self, laluan, tarikh_luput="", kuota=None):
        self.laluan = laluan
        self.tarikh_luput = (tarikh_luput or "").strip()
        self.kuota = {b: int((kuota or {}).get(b, 0) or 0)
                      for b in KUNCI_SAH}

    # -- baca ------------------------------------------------------------
    @classmethod
    def baca(cls, akar):
        laluan = os.path.join(akar, NAMA_FAIL)
        if not os.path.exists(laluan):
            raise IzinTidakSah(
                f"{NAMA_FAIL} TIDAK WUJUD di {akar}.\n"
                f"  Runner tidak berjalan tanpa kebenaran bertulis.\n"
                f"  Cipta fail itu dengan kandungan seperti:\n"
                f"      tarikh_luput={datetime.date.today().isoformat()}\n"
                f"      kuota_N=1\n"
                f"      kuota_P=1\n"
                f"      kuota_K=1")
        nilai = {}
        with open(laluan, encoding="utf-8") as fh:
            for baris in fh:
                baris = baris.strip()
                if not baris or baris.startswith("#") or "=" not in baris:
                    continue
                k, _, v = baris.partition("=")
                nilai[k.strip().lower()] = v.strip()
        kuota = {}
        for b in KUNCI_SAH:
            mentah = nilai.get(f"kuota_{b.lower()}", "0")
            try:
                kuota[b] = int(mentah)
            except ValueError:
                # Kuota yang tidak boleh dihurai dikira SIFAR. Menganggap
                # ia bermakna sesuatu yang lain akan membenarkan satu
                # salah taip mencipta rekod.
                kuota[b] = 0
        return cls(laluan, nilai.get("tarikh_luput", ""), kuota)

    # -- semak -----------------------------------------------------------
    def luput(self, hari_ini=None):
        hari_ini = hari_ini or datetime.date.today().isoformat()
        t = self.tarikh_luput
        if not t:
            return True, "tarikh_luput tidak diisi"
        try:
            datetime.date.fromisoformat(t)
        except ValueError:
            return True, f"tarikh_luput {t!r} bukan YYYY-MM-DD"
        if t < hari_ini:
            return True, f"izin luput {t}, hari ini {hari_ini}"
        return False, ""

    def semak(self, borang, hari_ini=None):
        """Lulus senyap, atau bangkitkan IzinTidakSah."""
        if borang not in KUNCI_SAH:
            raise IzinTidakSah(f"borang {borang!r} tidak sah "
                               f"(sah: {', '.join(KUNCI_SAH)})")
        sudah_luput, sebab = self.luput(hari_ini)
        if sudah_luput:
            raise IzinTidakSah(
                f"{NAMA_FAIL}: {sebab}. Izin sah untuk hari yang pemilik "
                f"taip sahaja; taip semula tarikh untuk sesi baharu.")
        baki = self.kuota.get(borang, 0)
        if baki <= 0:
            raise IzinTidakSah(
                f"{NAMA_FAIL}: kuota_{borang} ialah {baki}. Tiada baki "
                f"untuk {borang}.\n"
                f"  Tambah baris ini ke {NAMA_FAIL} kalau anda memang "
                f"mahu:\n"
                f"      kuota_{borang}=1")
        return True

    # -- tulis balik ------------------------------------------------------
    def guna_satu(self, borang):
        """Tolak satu daripada kuota borang dan tulis fail SEGERA.

        Dipanggil hanya selepas rekod BERJAYA dicipta. Menolak lebih
        awal akan menghanguskan kuota pada larian yang gagal sebelum
        mencipta apa-apa.
        """
        if self.kuota.get(borang, 0) <= 0:
            raise IzinTidakSah(
                f"cuba menggunakan kuota {borang} yang sudah 0")
        self.kuota[borang] -= 1
        self.simpan()
        return self.kuota[borang]

    def simpan(self):
        sementara = self.laluan + ".tmp"
        with open(sementara, "w", encoding="utf-8", newline="\n") as fh:
            fh.write("# IZIN-E2E — ditulis pemilik; kuota ditolak "
                     "automatik oleh runner.\n")
            fh.write(f"tarikh_luput={self.tarikh_luput}\n")
            for b in KUNCI_SAH:
                fh.write(f"kuota_{b}={self.kuota[b]}\n")
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(sementara, self.laluan)

    def ringkasan(self):
        sudah_luput, sebab = self.luput()
        return {
            "laluan": self.laluan,
            "tarikh_luput": self.tarikh_luput,
            "luput": sudah_luput,
            "sebab_luput": sebab or "sah",
            "kuota": dict(self.kuota),
        }

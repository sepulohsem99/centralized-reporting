"""
Bandingkan setiap nilai dalam testdata/ dengan sel Excel yang mendakwa
menjadi sumbernya.

KENAPA SKRIP INI WUJUD
----------------------
Pada 2026-07-29 pemilik membaca kertas kompaun yang baru dicetak dan
perasan nama penerima "Buruh En Saiful" — nama yang tidak pernah wujud
dalam skrip ujian Excel. Ia nilai warisan suite v2 yang ditampal ke medan
yang Excel biarkan kosong, dan ia bertahan berbulan tanpa disedari.

Tiada satu pun daripada penyimpangan seumpamanya menggagalkan mana-mana
ujian — itulah masalahnya. Data yang salah tetap menghasilkan run hijau;
ia cuma menguji perkara yang salah, secara senyap. Satu-satunya isyarat
ialah mata manusia pada kertas.

Dua corak yang ditemui pada MBIP, dan kedua-duanya terpakai kepada MBJB:

  1. MEDAN DIREKA — Excel senyap, kod menampal nilai "yang munasabah".
  2. KOMEN TERSALAH SALIN — komen mendakwa C9 berkata X, C9 sebenarnya
     berkata Y, dan nilai kod mengikut komen.

Corak kedua paling merbahaya kerana komen itu sendiri kelihatan seperti
bukti. Sebab itu skrip ini membaca semula workbook dan TIDAK SEKALI-KALI
mempercayai komen dalam excel_data.py.

RISIKO KHUSUS MBJB
------------------
Excel MBJB hanya membekalkan 35 nilai medan merentas 54 TC. Bermakna
hampir setiap medan borang ialah calon untuk direka. Skrip ini menolak
SEBARANG nilai dalam TC_DATA yang tidak jatuh ke dalam salah satu
daripada lima kategori yang boleh dipertahankan:

    [excel]      dihurai terus dari sel C9 dan sepadan
    [penanda]    didaftar dalam BLANK_BY_DESIGN + membawa penanda betul
    [struktur]   diterbitkan dari ID TC (jenis_letter)
    [dijangka]   nilai assertion yang disebut dalam C11
    [dibenarkan] penyimpangan yang diluluskan, tersenarai di bawah

Nilai keenam tidak wujud. Kalau satu medan tidak muat mana-mana kategori,
ia dilaporkan sebagai percanggahan dan skrip keluar dengan kod 1.

GUNA
----
    python tools/check_vs_excel.py

Keluar 0 = bersih, 1 = ada percanggahan, 2 = tidak dapat dijalankan.
Sesuai dijadikan gate dalam check_env.bat.

JANGAN LONGGARKAN SKRIP INI UNTUK MELULUSKAN DATA.
Kalau satu medan sepatutnya menyimpang, daftarkan penyimpangan itu
berserta sebabnya:
  - excel_data.BLANK_BY_DESIGN  -> medan teks yang Excel senyap
  - excel_data.BELUM_DISAHKAN   -> medan yang tidak boleh diisi langsung
  - DIBENARKAN di bawah         -> penyimpangan persekitaran/pilihan ujian
"""

import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

# Salinan dalam projek — sentiasa fail ini, bukan salinan lain di mesin.
# V2.1.33 ialah oracle. V2.1.34 mengandungi 143 sel berbeza tetapi SIFAR
# daripadanya spesifikasi ujian (semuanya bump versi, nombor rekod run,
# Actual Results/Status) — jadi memilih 33 selamat.
#
# AMARAN: dua workbook LAIN bernama MBJB —
# "IES-MBJB Testing Script V2.1.35_2_(PRODUCTION).xlsx" dan
# "…V2.1.36_PRODUCTION.xlsx" — berisi sheet MBPG-TC-* dengan data PASIR
# GUDANG. Ia BUKAN MBJB. Jangan sekali-kali menghalakan skrip ini ke sana.
#
# ORACLE DITUKAR 2026-08-04 kepada fail _CORRECTED. Fail "- Production"
# ASAL dikekalkan utuh di sebelahnya sebagai rekod, dan TIDAK dipadam.
# 12 defek workbook dibaiki di sana (11 nama sheet berruang tersembunyi,
# 5 sel C3 ber-ID salah termasuk MDKT-TC-NK-001 -> MBPG-TC-NK-002,
# H-005 hilang dalam 'List to Test', MBPG-TC-T012 -> MBPG-TC-T-012,
# 29 typo sucess*, 8 "Kompuan", C5 production -> 219.93.38.103:8880,
# B6 "IMEI" -> "No. Lesen", 5 sheet -003 kini Lampiran Gambar bukan
# Serah, 5 sheet -005 modul dibetulkan, NK-001 C4, 23 rujukan rekod
# production JB015 dibuang).
#
# Yang PALING mengubah keadaan: C9 kini blok BERSTRUKTUR "Label: nilai"
# dan bukan lagi "Refer to No Kompaun JB015…". Medan yang dahulu
# BELUM_DISAHKAN kerana oracle senyap kini ada sumber sebenar.
XLSX = os.path.join(ROOT, "docs",
                    "IES-MBJB Testing Script V2.1.33_CORRECTED.xlsx")

PREFIX = "MBPG-TC-"

# Diisi oleh semakan "nama modul" daripada sheet 'List to Test';
# dibaca semula oleh semakan jenis_letter H-*.
NAMA_MODUL = {}

# ---------------------------------------------------------------------------
# Penyimpangan yang DILULUSKAN, dengan sebabnya. Setiap satu ialah
# keputusan pemilik yang direkodkan, bukan kelonggaran umum.
#
# 'nilai_excel' ialah apa yang sel SEPATUTNYA berkata. Skrip mengesahkan
# sel itu MEMANG masih berkata begitu — kalau workbook dikemas kini dan
# sel berubah, pengecualian ini menjadi basi dan dilaporkan.
#
# 'sumber' (pilihan) = (ID_SHEET, nama_medan_dihurai). Bila ada, skrip
# membuka sheet ITU, menghurai C9-nya sendiri, dan menuntut nilai kod
# sepadan. Ia menjadikan pengecualian itu LEBIH ketat, bukan lebih
# longgar: nilai bukan sekadar "diluluskan", ia mesti kekal boleh
# dijejak ke satu sel yang pemeriksa baca semula setiap kali.
# ---------------------------------------------------------------------------
DIBENARKAN = {
    ("MBPG-TC-T-001", "ip_address"): {
        "nilai_excel": "epbt.mbjb.gov.my",
        "sebab": "C9/C5 ialah alamat PRODUCTION (rekod kompaun sebenar "
                 "orang awam); run mesti kena staging 219.93.38.103:8880. "
                 "Rujukan: PAPAN.md Seksyen 1.4 (keputusan Loh)",
    },
    ("MBPG-TC-T-002", "lesen_aplikasi"): {
        "nilai_excel": "867382031575883",
        # PAPAN.md Seksyen 1.1: dakwaan "lesen = IMEI peranti" SALAH dan
        # sudah ditarik balik oleh pemilik. lesen_aplikasi ialah token yang
        # didaftarkan di portal PBT; pengesahan berlaku di SERVER.
        "sebab": "C9 merekod token lesen yang dilabel m51 dalam dokumentasi "
                 "pemilik; run ini menggunakan token yang dilabel m50 "
                 "(867382031575982) seperti dalam profiles/mbpg-staging.json. "
                 "Ia BUKAN kerana lesen terikat IMEI peranti — PAPAN.md "
                 "Seksyen 1.1 membatalkan dakwaan itu (lesen MBIP "
                 "352405067769401 berjaya pada Armor 27 yang IMEI-nya "
                 "357616400186856). m50/m51 ialah label DEVICE di pejabat, "
                 "bukan syarat padanan",
    },
    # Teks alert yang DIJANGKA. Sengaja BUKAN dalam MEDAN_DIJANGKA:
    # cabang itu menuntut nilai disebut dalam C11, dan C11 kedua-dua sheet
    # ini hanya berkata "appear popup message" / "displays a confirmation
    # message" TANPA memberi teksnya. Teks sebenar hanya boleh datang dari
    # device.
    ("MBPG-TC-T-002", "alert_tajuk_dijangka"): {
        "nilai_excel": None,          # C11 tidak memberi teks popup
        "sebab": "C11 = \"Application should allow entry and appear popup "
                 "message\" — tiada teks diberi. DIBACA PADA DEVICE oleh "
                 "Loh 2026-07-30: tajuk alert = \"BEJAYA\" (TIADA huruf R). "
                 "Ejaan itu bug app yang disahkan, bukan salah taip kita, "
                 "dan ia berlaku dalam dialog LESEN sahaja — alert Selaras "
                 "menulis \"BERJAYA\" dengan betul. Assert mesti menjangka "
                 "apa yang app PAPARKAN (PERATURAN #2: jangan longgarkan, "
                 "tetapi juga jangan jangka teks yang salah)",
    },
    ("MBPG-TC-T-002", "alert_mesej_dijangka"): {
        "nilai_excel": None,
        "sebab": "lihat alert_tajuk_dijangka. Mesej = \"LESEN SAMA.\" "
                 "(huruf besar, dengan noktah), dibaca pada device oleh "
                 "Loh 2026-07-30",
    },
    ("MBPG-TC-T-003", "alert_tajuk_dijangka"): {
        "nilai_excel": None,          # C9 'N/A'; C11 tiada teks
        "sebab": "C11 = \"System displays a confirmation message\" — tiada "
                 "teks diberi. DIBACA PADA DEVICE oleh Loh 2026-07-30: "
                 "\"BERJAYA\" (ejaan BETUL di sini, berbeza daripada dialog "
                 "lesen T-002). Jangan seragamkan kedua-duanya",
    },
    ("MBPG-TC-T-003", "alert_mesej_dijangka"): {
        "nilai_excel": None,
        "sebab": "lihat alert_tajuk_dijangka T-003. Mesej = \"DATA PENGGUNA "
                 "BERJAYA DISIMPAN!\", dibaca pada device oleh Loh "
                 "2026-07-30. Ia juga bukti token lesen m50 SAH DI SERVER, "
                 "bukan sekadar disimpan setempat",
    },
    ("MBPG-TC-SK-001", "start_day"): {
        "nilai_excel": None,          # C9 = 'N/A'
        "sebab": "C10 langkah 2 \"Choose the desired date if applicable\" "
                 "menyerahkan julat kepada penguji; julat ini hanya "
                 "menapis paparan senarai — tidak masuk rekod, tidak "
                 "tercetak, jadi bukan data ujian",
    },
    ("MBPG-TC-SK-001", "end_day"): {
        "nilai_excel": None,
        "sebab": "lihat start_day",
    },
}

# ---------------------------------------------------------------------------
# 30 medan dropdown kod kompaun pada *-001 dan *-004 — KEPUTUSAN LOH
# (PAPAN.md Seksyen 5, jawapan kepada azharMadi S1).
#
# Sheet *-001 dan *-004 C9 SENYAP tentang Keterangan Kod Kompaun / Kod
# Akta / Kesalahan Kompaun. Ketiga-tiganya DROPDOWN — penanda teks
# "blank dari test script" bukan salah satu pilihan, jadi menaipnya
# menghasilkan medan KOSONG dan borang tidak boleh disimpan sama sekali.
# Loh memutuskan medan dropdown itu mengambil nilai dari sheet Bookmark
# (*-005) PBT yang sama, setiap satu berkomen sel sumbernya.
#
# Pembahagian blok bookmark BUKAN rawak:
#   *-001 (Daftar)    -> blok bookmark PERTAMA
#   *-004 (Kemaskini) -> blok bookmark KEDUA
# Sebabnya C11 *-004 menuntut "all updated fields reflect exactly the new
# input values". Kalau Kemaskini memilih kod yang SAMA dengan Daftar,
# nilai "sebelum" dan "selepas" identik dan assertion itu lulus tanpa
# menguji apa-apa (PERATURAN #2). Kedua-dua blok datang dari oracle yang
# sama, jadi tiada nilai direka, dan ia benar-benar BERBEZA.
#
# BELUM DISAHKAN: sama ada kesepuluh nilai ini benar-benar wujud dalam
# dropdown DB staging MBJB. Nilai *-005 datang dari run PRODUCTION Feb
# 2026. Ketiadaan pada staging = jurang data kategori D untuk dev, bukan
# bug automation. Senarai penuh untuk dibanding dengan dump device:
# testdata/excel_data.KESALAHAN_DIJANGKA_PADA_DEVICE.
# ---------------------------------------------------------------------------
_MEDAN_KOD_KOMPAUN = ("keterangan_kod_kompaun", "kod_akta",
                      "kesalahan_kompaun")
# Ayat rasmi penyimpangan, KATA DEMI KATA seperti diluluskan pemilik
# 2026-07-30. Diimport dari testdata supaya hanya SATU salinan wujud;
# Seksyen 10 di bawah menuntut setiap entri membawanya tanpa diubah.
from testdata.excel_data import SEBAB_NILAI_DARI_005 as _SEBAB_PEMILIK_005
_SEBAB_KOD_KOMPAUN = (
    _SEBAB_PEMILIK_005 + " "
    "C9 sheet ini senyap tentang medan ini dan ia DROPDOWN — penanda teks "
    "tidak boleh diterima, jadi borang tidak boleh disimpan tanpa nilai "
    "sah. KEPUTUSAN LOH (PAPAN.md Seksyen 5, jawapan azharMadi S1): ambil "
    "dari {sumber}!C9 blok bookmark {blok} ({peranan}). BELUM DISAHKAN "
    "wujud dalam DB staging MBJB — Loh membanding dengan dump dropdown "
    "device; ketiadaan = jurang data kategori D")
for _t in ("N", "P", "K", "L", "S"):
    for _akhiran, _blok, _peranan in (("001", 1, "Daftar"),
                                      ("004", 2, "Kemaskini — mesti "
                                                 "BERBEZA daripada Daftar")):
        for _m in _MEDAN_KOD_KOMPAUN:
            DIBENARKAN[(f"MBPG-TC-{_t}-{_akhiran}", _m)] = {
                "nilai_excel": None,        # C9 sheet ini memang senyap
                "sumber": (f"MBPG-TC-{_t}-005", f"bookmark_{_blok}_{_m}"),
                "sebab": _SEBAB_KOD_KOMPAUN.format(
                    sumber=f"MBPG-TC-{_t}-005", blok=_blok,
                    peranan=_peranan),
            }
del _t, _akhiran, _blok, _peranan, _m

# ---------------------------------------------------------------------------
# PERCANGGAHAN KATEGORI D — nilai oracle TIDAK WUJUD dalam DB staging
# ---------------------------------------------------------------------------
# KEPUTUSAN LOH 2026-07-30. 'ganti_device' menambah SATU lagi tuntutan di
# atas 'sumber': sel oracle mesti MASIH berkata nilai 'oracle', DAN nilai
# kod mesti sama dengan nilai 'device' yang direkodkan. Kedua-dua hujung
# dipin. Kalau workbook dikemas kini ATAU DB staging dibetulkan, gerbang
# melaporkan pengecualian ini sebagai basi — ia tidak boleh reput senyap.
#
# Ini BUKAN padanan kabur. Padanan kabur/prefix akan menutup percanggahan
# data sebenar pada masa depan (PERATURAN #2); penggantian eksplisit
# berdokumen tidak.
# >>> PIN 'ganti_device' UNTUK BANGUNANS DITARIK 2026-08-06. <<<
# Bentuk lama memin DUA hujung: sel oracle mesti berkata
# 'KOMPAUN PELBAGAI BANGUNAN' DAN kod mesti menghantar
# 'KOMPAUN PELBAGAI BANGUNANS' (nilai device 2026-07-30).
# Hujung DEVICE sudah BERGERAK, dan itu memang keadaan yang pin ini
# dibina untuk menangkap: dialog tingkat 1 dibuka pada 2026-08-06,
# DISKROL SAMPAI HABIS, dan menawarkan 'KOMPAUN PELBAGAI BANGUNAN'
# TANPA S — sepadan oracle. Bukti: reports/smoke_n001_e.txt.
# Maka penggantian itu ditarik dan medan ini kembali menjejak terus ke
# MBPG-TC-N-005!C9 / MBPG-TC-S-005!C9 (entri DIBENARKAN kekal kerana
# sel *-001!C9 memang senyap — itu sebab ASAL entri ini, bukan
# percanggahan device).
# Perubahan data rujukan MBJB yang mendasarinya (28 nilai tingkat 1 pada
# 2026-07-31 -> 13 pada 2026-08-06; crawl web 2026-08-04 melihat 18
# DENGAN S) ialah PENEMUAN untuk laporan, bukan sesuatu yang kod ini
# boleh selesaikan. Kalau 'S' kembali, Seksyen 13 melaporkannya semula
# sebagai jurang kategori D — mekanisme itu TIDAK dibuang.
_SEBAB_KATEGORI_D = (
    _SEBAB_PEMILIK_005 + " "
    "PERCANGGAHAN KATEGORI D 2026-07-30 (device 'KOMPAUN PELBAGAI "
    "BANGUNANS' lawan oracle 'KOMPAUN PELBAGAI BANGUNAN') DISELESAIKAN "
    "OLEH DEVICE pada 2026-08-06: dialog tingkat 1 diskrol sampai habis "
    "dan menawarkan ejaan ORACLE tanpa 'S'. Penggantian device ditarik; "
    "nilai kini nilai oracle tulen. Bukti: reports/smoke_n001_e.txt.")
for _tc, _sumber_sheet in (("MBPG-TC-N-001", "MBPG-TC-N-005"),
                           ("MBPG-TC-S-001", "MBPG-TC-S-005")):
    DIBENARKAN[(_tc, "keterangan_kod_kompaun")] = {
        "nilai_excel": None,        # C9 sheet *-001 memang senyap
        "sumber": (_sumber_sheet, "bookmark_1_keterangan_kod_kompaun"),
        "sebab": _SEBAB_KATEGORI_D,
    }
del _tc, _sumber_sheet

# ---------------------------------------------------------------------------
# TIGA LAGI percanggahan kategori D kelas kod_akta — B-3 (recon/PAPAN.md
# "ADJUDIKASI QA + KEBENARAN PEMETAAN", cuakKambing) + imbasan penuh
# TC_DATA oleh keriBidin 2026-07-30 terhadap DUMP_TIER2_DEVICE
# (ui_dumps/kesalahan_peta_LENGKAP.txt). Pola SAMA seperti _GANTI_BANGUNANS
# di atas — DUA hujung dipin: sel oracle mesti MASIH berkata nilai lama,
# DAN kod mesti hantar nilai device yang direkodkan. Kalau salah satu
# bergerak, gerbang melaporkannya, bukan mereput senyap.
# ---------------------------------------------------------------------------
DIBENARKAN[("MBPG-TC-K-001", "kod_akta")] = {
    "nilai_excel": None,
    "sumber": ("MBPG-TC-K-005", "bookmark_1_kod_akta"),
    "ganti_device": {
        "oracle": "PERINTAH LALULINTAS JALAN(PERUNTUNKAN TEMPAT LETAK "
                  "KEREJA MBJB 2003)(PERINTAH 39)",
        "device": "PERINTAH LALULINTAS JALAN (PERUNTUKAN TEMPAT LETAK "
                  "KERETA MBJB 2003 (PERINTAH 39)",
        "bukti": "ui_dumps/kesalahan_peta_LENGKAP.txt baris 48, tingkat-1 "
                 "SENDIRI K-001 'KOMPAUN LETAK KERETA PRESSGO', satu-satunya "
                 "nilai KOD AKTA (Loh, 2026-07-30)",
    },
    "sebab": _SEBAB_PEMILIK_005 + " "
             "PERCANGGAHAN KATEGORI D: sel oracle (sic) 'PERUNTUNKAN'/"
             "'KEREJA' lawan dropdown DB staging MBJB yang mengeja "
             "'PERUNTUKAN'/'KERETA' (BETUL) dengan jarak/kurungan berbeza "
             "— dibaca dari device oleh Loh 2026-07-30. DEV mesti "
             "menyelesaikan sama ada DB atau Excel yang salah taip; KITA "
             "TIDAK MENEKA. Mesti dilaporkan di bawah kategori D — lihat "
             "excel_data.PERCANGGAHAN_KATEGORI_D",
}
DIBENARKAN[("MBPG-TC-S-001", "kod_akta")] = {
    "nilai_excel": None,
    "sumber": ("MBPG-TC-S-005", "bookmark_1_kod_akta"),
    "ganti_device": {
        "oracle": "AKTA 133, AKTA JALAN, PARIT DAN BANGUNAN",
        "device": "AKTA 133, AKTA JALAN, PARIT DAN BANGUNAN 1974",
        "bukti": "ui_dumps/kesalahan_peta_LENGKAP.txt baris 97, tingkat-1 "
                 "SENDIRI S-001 'KOMPAUN PELBAGAI BANGUNANS' (Loh, "
                 "2026-07-30)",
    },
    "sebab": _SEBAB_PEMILIK_005 + " "
             "PERCANGGAHAN KATEGORI D: sel oracle S-005 blok 1 tidak "
             "membawa '1974' (ANOMALI_ORACLE sedia ada — N-005/P-005 "
             "menulisnya DENGAN 1974); dropdown DB staging di bawah "
             "tingkat-1 SENDIRI S-001 hanya menawarkan versi DENGAN 1974 "
             "— dibaca dari device oleh Loh 2026-07-30. DEV mesti "
             "menyelesaikan sama ada DB atau Excel yang salah; KITA TIDAK "
             "MENEKA. Mesti dilaporkan di bawah kategori D — lihat "
             "excel_data.PERCANGGAHAN_KATEGORI_D",
}
DIBENARKAN[("MBPG-TC-S-004", "kod_akta")] = {
    "nilai_excel": None,
    "sumber": ("MBPG-TC-S-005", "bookmark_2_kod_akta"),
    "ganti_device": {
        "oracle": "UNDANG-UNDANG KECIL MENCEGAH KEKOTORANG (MBJB 1981) & "
                  "PINDAAN 2004",
        "device": "UNDANG-UNDANG KECIL MENCEGAH KEKOTORAN (MBJB 1981) & "
                  "PINDAAN 2004",
        "bukti": "ui_dumps/kesalahan_peta_LENGKAP.txt baris 31/42/103/111 "
                 "— EMPAT tingkat-1 berlainan, SEMUANYA konsisten "
                 "'KEKOTORAN' tanpa G (Loh, 2026-07-30). Tingkat-1 SENDIRI "
                 "S-004 'KOMPAUN PELBAGAI SALIRAN' belum didump pada "
                 "bacaan ini — lihat excel_data.PERCANGGAHAN_KATEGORI_D "
                 "untuk kejujuran had bukti",
    },
    "sebab": _SEBAB_PEMILIK_005 + " "
             "PERCANGGAHAN KATEGORI D (B-3): sel oracle berkata "
             "'KEKOTORANG' (dengan G) tetapi dropdown DB staging MBJB "
             "hanya menawarkan 'KEKOTORAN' (tanpa G) di setiap tingkat-1 "
             "yang sudah didump — dibaca dari device oleh Loh 2026-07-30. "
             "Kelas PERSIS SAMA dengan BANGUNAN/BANGUNANS di atas. DEV "
             "mesti menyelesaikan sama ada DB atau Excel yang salah taip; "
             "KITA TIDAK MENEKA. Mesti dilaporkan di bawah kategori D — "
             "lihat excel_data.PERCANGGAHAN_KATEGORI_D",
}

# ---------------------------------------------------------------------------
# TIGA percanggahan kategori D kelas kesalahan_kompaun (TINGKAT 3) —
# didaftar 2026-07-30 selepas Loh menjalankan kesepuluh laluan KESALAHAN
# HUJUNG-KE-HUJUNG pada device (ui_dumps/laluan_kesalahan_disahkan.txt +
# ui_dumps/laluan_baki_disahkan.txt). 8/10 LENGKAP.
#
# Ini menutup jurang metodologi yang PAPAN.md sendiri catat: dump tingkat-3
# terdahulu tidak boleh dipercayai kerana spinner tingkat 3 tidak menyegar
# apabila tingkat 1/2 bertukar, jadi setiap bacaan mungkin SISA pasangan
# sebelumnya. Laluan di bawah dilalui PENUH dari tingkat 1 setiap kali.
#
# CORAK YANG SAMA — DUA hujung dipin: sel oracle mesti MASIH membawa salah
# taipnya, DAN kod mesti menghantar nilai device yang direkodkan.
#
# >>> TIADA NORMALISASI. <<< Pemadan pertama Loh membuang tanda baca dan
# menjadikan "SEKSYEN 4(3)" == "SEKSYEN 43", lalu memadankan S-001 kepada
# kesalahan yang SALAH. Kalau itu masuk run, kompaun SEBENAR tercetak
# dengan kesalahan orang lain. Setiap entri di bawah ialah penggantian
# EKSPLISIT satu-per-satu; kurungan dan jarak BERMAKNA.
# ---------------------------------------------------------------------------
_SEBAB_TIER3 = (
    _SEBAB_PEMILIK_005 + " "
    "PERCANGGAHAN KATEGORI D pada TINGKAT 3 (KESALAHAN KOMPAUN): laluan "
    "penuh tingkat 1 -> 2 -> 3 DIJUMPAI pada device, jadi ini SALAH TAIP "
    "ORACLE lawan DB, BUKAN jurang data. Nilai device disalin verbatim "
    "(termasuk salah taip DB sendiri) — kita tidak membetulkan mana-mana "
    "pihak dan kita TIDAK menormalkan tanda baca. DEV mesti menentukan "
    "sama ada DB atau Excel yang salah taip. Mesti dilaporkan di bawah "
    "kategori D — lihat excel_data.PERCANGGAHAN_KATEGORI_D")
DIBENARKAN[("MBPG-TC-N-001", "kesalahan_kompaun")] = {
    "nilai_excel": None,
    "sumber": ("MBPG-TC-N-005", "bookmark_1_kesalahan_kompaun"),
    "ganti_device": {
        "oracle": "[SESKSYEN 30(2)] - MEMBINASAKAN, MERUNTUHKAN, "
                  "MENCACATKAN, MENUTUP ATAU MENYEMBUNYIKAN MANA-MANA "
                  "PELIT YANG MENUNJUKKAN PILI BOMBA",
        "device": "[SEKSYEN 30(2)] - MEMBINASAKAN, MERUNTUHKAN, "
                  "MENCACATKAN, MENUTUP ATAU MENYEMBUYIKAN MANA-MANA "
                  "PELIT YG MENUNJUKAN KEDUDUKAN PILI BOMBA",
        "bukti": "ui_dumps/laluan_kesalahan_disahkan.txt + "
                 "ui_dumps/laluan_baki_disahkan.txt — laluan N-001 dilalui "
                 "PENUH dari tingkat 1, 60 pilihan tingkat 3, status "
                 "LENGKAP (Loh, 2026-07-30)",
    },
    "sebab": _SEBAB_TIER3 + ". Beza: oracle 'SESKSYEN' (S berlebihan) vs "
             "device 'SEKSYEN'; device 'MENYEMBUYIKAN' (tercicir N); "
             "device 'YG MENUNJUKAN' vs oracle 'YANG MENUNJUKKAN'; device "
             "menambah 'KEDUDUKAN'",
}
DIBENARKAN[("MBPG-TC-N-004", "kesalahan_kompaun")] = {
    "nilai_excel": None,
    "sumber": ("MBPG-TC-N-005", "bookmark_2_kesalahan_kompaun"),
    "ganti_device": {
        "oracle": "[UUK14(1)] - TIDAK BOLEH MENYIMPAN RACUN DALAM BEKAS "
                  "RACUN ATAU BAHAN MERBAHAYA LAIN",
        "device": "[UUK 14(1)] - TIDAK BOLEH MENYIMPAN MAKANAN DALAM "
                  "BEKAS RACUN ATAU BAHAN MERBAHAYA LAIN",
        "bukti": "ui_dumps/laluan_kesalahan_disahkan.txt — laluan N-004 "
                 "LENGKAP, tingkat 1 dan tingkat 2 padanan TEPAT "
                 "(Loh, 2026-07-30)",
    },
    "sebab": _SEBAB_TIER3 + ". Beza: oracle 'UUK14(1)' tiada ruang vs "
             "device 'UUK 14(1)'; oracle 'MENYIMPAN RACUN' vs device "
             "'MENYIMPAN MAKANAN' — maksud BERBEZA, dan device yang masuk "
             "akal untuk UUK Pengendali Makanan",
}
DIBENARKAN[("MBPG-TC-S-004", "kesalahan_kompaun")] = {
    "nilai_excel": None,
    "sumber": ("MBPG-TC-S-005", "bookmark_2_kesalahan_kompaun"),
    "ganti_device": {
        "oracle": "[UUK 6 (I)(F)] - MENYIMPAN SAMPAH SARAP HALAMAN, "
                  "SAMPAH SARAP DAPUR, SAMPAH SARAP PERNIAGAAN, BENDA "
                  "ATAU BARANG LAIN DI TEMPAT AWAM\"",
        "device": "[UUK 6(I)(F)] - MENYIMPAN SAMPAH SARAP HALAMAN, "
                  "SAMPAH SARAP DAPUR, SAMPAH SARAP PERNIAGAAN, BENDA "
                  "ATAU BARANG LAIN DI TEMPAT AWAM",
        "bukti": "ui_dumps/laluan_baki_disahkan.txt — laluan S-004 kini "
                 "LENGKAP selepas kod_akta 'KEKOTORAN' dipakai; tingkat 3 "
                 "memaparkan 13 pilihan (Loh, 2026-07-30)",
    },
    "sebab": _SEBAB_TIER3 + ". Beza: oracle 'UUK 6 (I)(F)' ada ruang "
             "berlebihan vs device 'UUK 6(I)(F)'; sel oracle berakhir "
             "dengan petikan berganda TERGANTUNG (ANOMALI_ORACLE) yang "
             "TIADA pada device",
}

# ---------------------------------------------------------------------------
# 8 medan NAMA JALAN pada *-001 — nilai terikat persekitaran, dibaca dari
# DB MBJB pada device oleh Loh 2026-07-30.
#
# Autocomplete Maklumat Jalan hanya menerima nama jalan yang benar-benar
# wujud dalam DB MBJB yang diselaraskan, jadi Excel MEMANG tidak boleh
# membekalkannya — kedudukan yang sama dengan plat JYX6605 dalam MBIP.
# Bukti: reports/fasa2-bootstrap.md Seksyen 2.4 + ui_dumps/42..44.
# ---------------------------------------------------------------------------
_SEBAB_JALAN = (
    "C9 senyap. Autocomplete MAKLUMAT JALAN terikat DB MBJB — hanya nama "
    "jalan yang wujud dalam DB yang diselaraskan memberi cadangan, jadi "
    "Excel tidak boleh membekalkannya dan penanda teks tidak boleh dipakai. "
    "Nilai DIBACA DARI DEVICE oleh Loh 2026-07-30 (13 pilihan; "
    "reports/fasa2-bootstrap.md Seksyen 2.4, ui_dumps/42_jalan_typeahead + "
    "43_pilih_jalan_senarai + 44_jalan_dipilih). 'JALAN BAKAK | KAMPUNG "
    "BARU SKUDAI' ialah baris yang benar-benar ditap dan yang benar-benar "
    "mengisi borang. Terikat persekitaran, bukan rekaan — kedudukan sama "
    "dengan plat JYX6605 MBIP. Kalau DB diselaras semula dan jalan ini "
    "hilang, dump semula; jangan teka gantinya")
for _tc, _medan in (
        ("MBPG-TC-N-001", "notis_jalan_partial"),
        ("MBPG-TC-N-001", "notis_jalan_suggestion"),
        ("MBPG-TC-P-001", "kompaun_jalan_partial"),
        ("MBPG-TC-P-001", "kompaun_jalan_suggestion"),
        ("MBPG-TC-K-001", "kompaun_jalan_partial"),
        ("MBPG-TC-K-001", "kompaun_jalan_suggestion"),
        ("MBPG-TC-L-001", "nama_jalan"),
        ("MBPG-TC-S-001", "nama_jalan")):
    DIBENARKAN[(_tc, _medan)] = {
        "nilai_excel": None,            # C9 hanya rujukan nombor rekod
        "sebab": _SEBAB_JALAN,
    }
del _tc, _medan

# ---------------------------------------------------------------------------
# poskod / no_kp_ssm_kereta pada N-001 — KEPUTUSAN PEMILIK 2026-07-31.
# ---------------------------------------------------------------------------
# Loh mencadangkan biarkan `poskod` KOSONG supaya assertion C11 gagal dan
# bug kategori B terdedah dengan sendirinya. PEMILIK MEMILIH SEBALIKNYA:
# taip penanda berangka, supaya rantaian create->cetak->kertas boleh
# dibuktikan hari ini. Ini TIDAK bermakna auto-isi poskod berfungsi — bug
# kategori B kekal didaftarkan BERASINGAN dalam
# excel_data.PERCANGGAHAN_KATEGORI_D di bawah label
# excel_data.LABEL_KATEGORI_B_POSKOD, dan Seksyen 14 di bawah menuntut
# entri itu kekal wujud dengan belum_selesai=True.
#
# `nilai_dijangka` DIPIN di sini: kalau override poskod/no_kp_ssm_kereta
# di testdata/overrides.py berubah daripada 990323112289 (contohnya
# dipulihkan ke keadaan sebelum keputusan pemilik — kosong/tiada, sama
# seperti oracle yang senyap tentangnya), TC_DATA tidak lagi sepadan nilai
# yang dipin dan Seksyen 14 melaporkannya — gerbang keluar 1. Ini UJIAN
# NEGATIF (a): pulihkan override ke nilai oracle (senyap) -> exit 1.
_SEBAB_POSKOD = (
    "Medan berangka; penanda huruf ditapis senyap oleh app. Nilai "
    "berangka disahkan diterima pada device 2026-07-30. KEPUTUSAN PEMILIK "
    "2026-07-31: penanda ditaip supaya rantaian create->cetak->kertas "
    "boleh dibuktikan. Ini TIDAK bermakna auto-isi poskod berfungsi — "
    "lihat bug kategori B di bawah.")
_SEBAB_NO_KP_SSM_KERETA = (
    "medan berangka; penanda huruf ditapis senyap oleh app; nilai "
    "berangka penanda disahkan diterima pada device 2026-07-30 "
    "(recon/medan_n001.md, dump ui_dumps/R03_nokp — ditaip 990323112289, "
    "dipapar 990323112289).")
# >>> PENGECUALIAN poskod DIBUANG 2026-08-05. <<<
# Ia mendaftarkan keputusan pemilik 2026-07-31 untuk MENAIP "990323112289"
# ke medan INPUT poskod supaya N-001 boleh berjalan. Pemilik MENERBALIKKAN
# keputusan itu pada 2026-08-05: menaipnya menyamarkan bug auto-isi
# kategori B, dan nombor IC itu tercetak pada kompaun sebenar.
# Medan itu kini DIBACA, bukan ditaip. Tiada nilai poskod dalam TC_DATA,
# jadi tiada penyimpangan untuk didaftarkan — pengecualian yang mendaftar
# penyimpangan yang sudah tiada ialah pengecualian mati.
# _SEBAB_POSKOD dikekalkan di atas sebagai REKOD sejarah keputusan itu.
_SEBAB_NO_PEMBANTU = (
    "oracle SENYAP sepenuhnya tentang medan ini. Nilai 0106418 datang "
    "daripada crawl pangkalan data MBJB oleh pemilik 2026-08-05 (rekod "
    "pegawai 0106418 = PEGAWAI PENGUATKUASA KP44) — sumber SEBENAR, "
    "bukan nilai rekaan. Didaftarkan di sini supaya ia kelihatan dalam "
    "laporan sebagai nilai bukan-Excel, bukan diselitkan senyap.")
for _tc_pp in ("MBPG-TC-P-001", "MBPG-TC-K-001",
               "MBPG-TC-L-001", "MBPG-TC-S-001"):
    DIBENARKAN[(_tc_pp, "no_pembantu_penguatkuasa")] = {
        "nilai_excel": None,       # oracle memang tidak menyebutnya
        "nilai_dijangka": "0106418",
        "sebab": _SEBAB_NO_PEMBANTU,
    }
del _tc_pp

DIBENARKAN[("MBPG-TC-N-001", "no_kp_ssm_kereta")] = {
    "nilai_excel": None,
    "nilai_dijangka": "990323112289",
    "sebab": _SEBAB_NO_KP_SSM_KERETA,
}

# ---------------------------------------------------------------------------
# kadar_denda — DIBENARKAN (RUNTIME). KEPUTUSAN PEMILIK 2026-07-30.
# ---------------------------------------------------------------------------
# MBPG-TC-K-001!C10 langkah 5: "select the applicable Kadar Denda (RM)
# within the predefined minimum and maximum range". **PREDEFINED**
# bermakna julat ditetapkan oleh KESALAHAN yang dipilih — ia hanya wujud
# pada RUNTIME, selepas tingkat 3 dipilih. Tingkat 3 kini terbukti
# berfungsi (8/10 laluan LENGKAP), jadi laluan ke medan ini tidak lagi
# terhalang.
#
# Entri ini SENGAJA berbeza daripada semua yang lain: medan `kadar_denda`
# TIDAK berada dalam TC_DATA dan TIDAK akan pernah berada di sana — satu
# nilai RM yang direka akan TERCETAK pada kompaun sebenar (PERATURAN #5).
# Maka Seksyen 7 (pengecualian basi) MELANGKAU entri bertanda 'runtime',
# dan Seksyen 12 di bawah menggantikannya dengan semakan yang LEBIH ketat:
#   - medan itu WAJIB tiada dalam TC_DATA
#   - medan itu WAJIB masih ada dalam BELUM_DISAHKAN (TC melangkau jujur)
#   - sel C10 yang didakwa WAJIB dibaca semula dan masih membawa petikannya
#   - sebab bertulis WAJIB kekal kata demi kata
#   - struktur runtime (rekod_julat_kadar_denda / sahkan_kadar_denda)
#     WAJIB wujud dan gagal-tertutup tanpa julat
# ---------------------------------------------------------------------------
# >>> BARIS DIBENARKAN untuk kadar_denda DIBUANG 2026-08-04. <<<
# Ia mendaftarkan penyimpangan "kod menyimpang daripada Excel". Selepas
# workbook _CORRECTED, kod TIDAK LAGI menyimpang: TC_DATA membawa nilai
# sel itu sendiri. Pengecualian yang mendaftarkan penyimpangan yang sudah
# tiada ialah pengecualian mati, dan gerbang ini memang melaporkannya
# ("pengecualian didaftar tetapi kod menggunakan nilai Excel").
#
# GERBANG TIDAK DILONGGARKAN. Yang dibuang ialah satu baris pendaftaran;
# semakan yang KETAT kekal hidup sepenuhnya dalam Seksyen 12, dan ia kini
# menuntut LEBIH daripada dahulu:
#   - TC_DATA.kadar_denda mesti SAMA dengan C9 yang dibaca semula
#   - petikan C10 "predefined minimum and maximum range" mesti masih ada
#   - kadar_denda TIDAK boleh lagi berada dalam BELUM_DISAHKAN
#   - rekod_julat_kadar_denda / sahkan_kadar_denda mesti wujud dan
#     gagal-tertutup tanpa julat
# Nota sel "(sahkan dalam julat app)" ialah sebab kedua-duanya perlu:
# nilai oracle yang DITAIP, julat runtime yang MENGESAHKAN.

# Medan yang datang daripada profil aktif (profiles/*.json), bukan
# daripada Excel. Dibenarkan pada mana-mana TC yang memerlukannya.
DARI_PROFIL = {"id_penguatkuasa", "username", "password"}

# Medan struktur — diterbitkan daripada ID TC, bukan nilai data.
MEDAN_STRUKTUR = {"jenis_letter"}

# Medan nilai-dijangka — bukan input; nilainya mesti disebut dalam C11.
MEDAN_DIJANGKA = {"status_notis_dijangka"}


def _norm(v):
    """Banding tanpa terpengaruh huruf besar/kecil, ruang, atau 'RM'."""
    s = str("" if v is None else v).strip().upper()
    s = re.sub(r'^RM\s*', '', s)
    s = re.sub(r'\s+', ' ', s)
    return s


def _c(ws, baris):
    v = ws.cell(row=baris, column=3).value
    return "" if v is None else str(v)


def main():                                             # noqa: C901
    try:
        import openpyxl
    except ImportError:
        print("openpyxl tiada — pip install openpyxl")
        return 2
    if not os.path.exists(XLSX):
        print(f"Workbook tidak dijumpai:\n  {XLSX}")
        return 2

    from testdata.excel_data import (
        TC_LIST, TC_NAMES, TC_DATA, BLANK_BY_DESIGN, BELUM_DISAHKAN,
        LICENSE_SETTINGS, penanda_untuk, ringkasan_liputan,
        AWALAN_NOMBOR_REKOD, DIBUANG,
        KLASIFIKASI_BELUM_DISAHKAN, KLAS_DISAHKAN_TIADA)
    from testdata import overrides as _ovr
    from tools import parse_testdata as P

    wb = openpyxl.load_workbook(XLSX, data_only=True)
    # Nama sheet MBJB ada whitespace tidak konsisten pada 11 sheet
    # (' MBPG-TC-N-006', 'MBPG-TC-P-002 ', …) -> sentiasa normalkan.
    sheets = {P.nama_sheet_ternormal(n): n for n in wb.sheetnames}

    masalah = []
    diperiksa = 0
    kategori = {"excel": 0, "penanda": 0, "struktur": 0, "dijangka": 0,
                "dibenarkan": 0, "profil": 0}
    dibenarkan_dipakai = set()

    def lapor(tc, medan, excel, kod, sebab):
        masalah.append((tc, medan, excel, kod, sebab))

    # -----------------------------------------------------------------
    # 1. Liputan sheet — setiap TC ada sheet, setiap sheet ada TC
    # -----------------------------------------------------------------
    ids_kod = [tc for tc, _ in TC_LIST]
    for tc in ids_kod:
        if tc not in sheets:
            lapor(tc, "(sheet)", "(tiada)", "ada dalam TC_LIST",
                  "TC_LIST menyenaraikan TC yang tiada sheet dalam workbook")
    sheet_tc = [k for k in sheets if k.startswith(PREFIX)]
    for sn in sheet_tc:
        if sn not in ids_kod:
            lapor(sn, "(sheet)", "ada dalam workbook", "(tiada)",
                  "workbook ada sheet TC yang tidak disenaraikan TC_LIST")
    if len(ids_kod) != len(set(ids_kod)):
        lapor("(TC_LIST)", "(id)", "-", "-", "ID berulang dalam TC_LIST")

    # -----------------------------------------------------------------
    # 2. Nama modul — TC_NAMES vs 'List to Test' lajur C
    # -----------------------------------------------------------------
    # Dua kecacatan baris yang DIKETAHUI dan direkodkan dalam
    # excel_data.TC_LIST:
    #   baris 14 ID ditulis 'MBPG-TC-T012' (tiada sengkang)
    #   baris 53 ID ditulis 'MBPG-TC-H-003' (berulang) untuk modul
    #            Sitaan; sheet MBPG-TC-H-005 wujud dan C4-nya menyebut
    #            Sitaan -> baris itu milik H-005
    # Oracle _CORRECTED sudah membetulkan baris H-005 dan
    # 'MBPG-TC-T012' -> 'MBPG-TC-T-012'. Pemetaan ini dikekalkan supaya
    # skrip masih betul kalau seseorang menghalakannya ke workbook ASAL
    # (yang sengaja disimpan di sebelahnya); pada fail CORRECTED ia
    # menghasilkan nilai yang SAMA, jadi ia tidak berbahaya.
    _BAIKI_ID_BARIS = {53: "MBPG-TC-H-005"}
    global NAMA_MODUL
    if "List to Test" in wb.sheetnames:
        lt = wb["List to Test"]
        nama_excel = {}
        for r in range(3, lt.max_row + 1):
            nama = lt.cell(row=r, column=3).value
            tid = lt.cell(row=r, column=5).value
            if not (nama and tid):
                continue
            tid = _BAIKI_ID_BARIS.get(r, re.sub(
                r'^(MBPG-TC-)([A-Z]+)(\d)', r'\1\2-\3',
                str(tid).strip().upper()))
            nama_excel.setdefault(tid, str(nama).strip())
        # Dikongsi dengan semakan jenis_letter H-* di bawah, yang kini
        # bersauh pada nama modul dan bukan lagi pada nombor rekod JB015.
        NAMA_MODUL = dict(nama_excel)
        for tc, nama in TC_NAMES.items():
            diperiksa += 1
            asal = nama_excel.get(tc)
            if asal is None:
                lapor(tc, "(nama modul)", "(tiada baris)", nama,
                      "TC_NAMES membawa nama yang tiada dalam 'List to Test'")
            elif _norm(asal) != _norm(nama):
                lapor(tc, "(nama modul)", asal, nama,
                      "nama tidak sepadan lajur C 'List to Test'")
    else:
        lapor("(workbook)", "List to Test", "(tiada)", "-",
              "sheet 'List to Test' tidak dijumpai")

    # -----------------------------------------------------------------
    # 3. Setiap medan dalam TC_DATA mesti muat satu kategori
    # -----------------------------------------------------------------
    for tc in sorted(TC_DATA):
        sn = sheets.get(tc)
        if not sn:
            if TC_DATA[tc]:
                lapor(tc, "(sheet)", "(tiada)", "TC_DATA ada isi",
                      "TC_DATA membawa data untuk TC tanpa sheet")
            continue
        ws = wb[sn]
        c9 = _c(ws, 9)
        c10 = _c(ws, 10)
        c11 = _c(ws, 11)
        dari_c9 = P.parse(c9)
        blanks = BLANK_BY_DESIGN.get(tc) or {}
        belum = BELUM_DISAHKAN.get(tc) or {}

        for medan, kod in sorted(TC_DATA[tc].items()):
            diperiksa += 1

            # [struktur] jenis_letter mesti sepadan huruf jenis ID TC
            if medan in MEDAN_STRUKTUR:
                m = re.match(r'^MBPG-TC-([A-Z]+)-\d+$', tc)
                jenis = (m.group(1) if m else "")
                jangkaan = {"N": "N", "P": "P", "K": "K", "L": "L", "S": "S",
                            "H": None, "SK": None, "TN": None,
                            "NK": None, "T": None}.get(jenis, None)
                if jangkaan is None:
                    # H-00n / SK / TN / NK: huruf datang dari modul, jadi
                    # sahkan ia salah satu huruf jenis rekod yang sah dan
                    # muncul dalam nombor rekod workbook.
                    if str(kod) not in ("N", "P", "K", "L", "S"):
                        lapor(tc, medan, "N|P|K|L|S", kod,
                              "huruf jenis rekod tidak sah")
                    elif tc.startswith("MBPG-TC-H-"):
                        # >>> SAUH DITUKAR 2026-08-04, oracle _CORRECTED. <<<
                        # Dahulu: cari `JB015<huruf>` dalam C9+C10+C11.
                        # Oracle yang dibetulkan MEMBUANG kesemua 23 rujukan
                        # rekod production JB015 — dengan sengaja, kerana
                        # awalan sebenar device ini ialah JBM50 (disahkan
                        # 2026-08-04 daripada rekod JBM50N260804056) dan
                        # JB015 ialah artifak run manual production Feb 2026.
                        # Jadi sauh lama menunjuk kepada sesuatu yang memang
                        # tidak sepatutnya wujud lagi.
                        #
                        # Sauh baharu LEBIH KUAT: nama modul dalam
                        # 'List to Test', yang pembetulan oracle jadikan
                        # boleh dipercayai ("Hantar Semula Data & Gambar
                        # Notis Amaran" -> N). Ia menerangkan MAKSUD TC,
                        # bukan nombor rekod satu run tertentu.
                        _peta = (("NOTIS AMARAN", "N"),
                                 ("PELBAGAI", "P"),
                                 ("LETAK KERETA", "K"),
                                 ("LESEN", "L"),
                                 ("SITAAN", "S"))
                        _nama = (NAMA_MODUL.get(tc) or "").upper()
                        _jangka = next((h for kunci, h in _peta
                                        if kunci in _nama), None)
                        if _jangka is None:
                            lapor(tc, medan,
                                  f"nama modul {_nama!r} tiada kata kunci "
                                  f"jenis", kod,
                                  "tidak dapat menentukan huruf jenis "
                                  "daripada nama modul")
                        elif str(kod) != _jangka:
                            lapor(tc, medan, f"(nama modul -> {_jangka})",
                                  kod,
                                  "huruf jenis tidak sepadan nama modul "
                                  "'List to Test'")
                elif str(kod) != jangkaan:
                    lapor(tc, medan, f"(ID TC -> {jangkaan})", kod,
                          "huruf jenis tidak sepadan ID TC")
                kategori["struktur"] += 1
                continue

            # [dijangka] nilai assertion mesti disebut dalam C11
            if medan in MEDAN_DIJANGKA:
                if not re.search(rf"['\"]?{re.escape(str(kod))}['\"]?",
                                 c11) or "STATUS" not in c11.upper():
                    lapor(tc, medan, c11.strip()[:60], kod,
                          "nilai dijangka tidak disebut dalam C11")
                kategori["dijangka"] += 1
                continue

            # [dibenarkan] penyimpangan yang diluluskan
            kunci = (tc, medan)
            if kunci in DIBENARKAN:
                dibenarkan_dipakai.add(kunci)
                jangkaan_excel = DIBENARKAN[kunci]["nilai_excel"]
                sebenar = dari_c9.get(medan)
                if jangkaan_excel is None:
                    if sebenar is not None:
                        lapor(tc, medan, sebenar, kod,
                              "pengecualian mendakwa Excel senyap, tetapi C9 "
                              "MEMANG membekalkan nilai — buang pengecualian "
                              "dan ikut Excel")
                elif sebenar is None:
                    lapor(tc, medan, "(C9 senyap)", kod,
                          f"pengecualian mendakwa C9 berkata "
                          f"{jangkaan_excel!r}, tetapi C9 tidak "
                          f"membekalkan medan ini langsung — pengecualian basi")
                elif _norm(sebenar) != _norm(jangkaan_excel):
                    lapor(tc, medan, sebenar, jangkaan_excel,
                          "sel Excel sudah berubah; pengecualian basi — "
                          "sahkan semula dengan pemilik")
                elif _norm(kod) == _norm(jangkaan_excel):
                    lapor(tc, medan, sebenar, kod,
                          "pengecualian didaftar tetapi kod menggunakan "
                          "nilai Excel — buang pengecualian yang tidak perlu")

                # Pengecualian yang menamakan sel sumber SILANG-SHEET
                # (nilai *-005 dipakai pada *-001/*-004). Pemeriksa
                # membuka sheet sumber itu sendiri dan menghuraikannya
                # semula — komen dalam excel_data.py tidak dipercayai.
                sumber = DIBENARKAN[kunci].get("sumber")
                if sumber:
                    sn_sumber = sheets.get(sumber[0])
                    if not sn_sumber:
                        lapor(tc, medan, f"({sumber[0]} tiada)", kod,
                              "pengecualian menamakan sheet sumber yang "
                              "tidak wujud dalam workbook")
                    else:
                        nilai_sumber = P.parse(
                            _c(wb[sn_sumber], 9)).get(sumber[1])
                        ganti = DIBENARKAN[kunci].get("ganti_device")
                        if nilai_sumber is None:
                            lapor(tc, medan,
                                  f"({sumber[0]}!C9 tidak membekalkan "
                                  f"{sumber[1]})", kod,
                                  "pengecualian mendakwa nilai datang dari "
                                  "sel itu, tetapi sel itu tidak "
                                  "membekalkannya — pengecualian basi")
                        elif ganti is not None:
                            # Percanggahan kategori D: DUA hujung dipin.
                            if _norm(nilai_sumber) != _norm(ganti["oracle"]):
                                lapor(tc, medan,
                                      f"{sumber[0]}!C9 {sumber[1]} = "
                                      f"{nilai_sumber}", ganti["oracle"],
                                      "pengecualian kategori D mendakwa sel "
                                      "oracle berkata sesuatu yang lain — "
                                      "workbook sudah berubah, sahkan semula "
                                      "dengan pemilik")
                            elif _norm(kod) != _norm(ganti["device"]):
                                lapor(tc, medan,
                                      f"nilai device {ganti['device']} "
                                      f"({ganti['bukti']})", kod,
                                      "pengecualian kategori D didaftar "
                                      "tetapi kod tidak menghantar nilai "
                                      "device yang direkodkan — kalau DB "
                                      "staging sudah dibetulkan, BUANG "
                                      "pengecualian ini")
                        elif _norm(nilai_sumber) != _norm(kod):
                            lapor(tc, medan,
                                  f"{sumber[0]}!C9 {sumber[1]} = "
                                  f"{nilai_sumber}", kod,
                                  "nilai tidak sepadan sel sumber yang "
                                  "didakwa oleh pengecualian")
                kategori["dibenarkan"] += 1
                continue

            # [penanda] medan yang Excel senyap, diisi penanda
            if medan in blanks:
                if medan in dari_c9:
                    lapor(tc, medan, dari_c9[medan], kod,
                          "didaftar dalam BLANK_BY_DESIGN tetapi C9 MEMANG "
                          "membekalkan nilai — buang dari BLANK_BY_DESIGN "
                          "dan ikut Excel")
                else:
                    # tc dihantar supaya medan Kemaskini (*-004
                    # lokasi/butiran kesalahan) dituntut membawa penanda
                    # KEDUA, bukan penanda create. Kalau ia membawa
                    # penanda create, assertion C11 *-004 menjadi hampa
                    # dan itu dilaporkan sebagai percanggahan.
                    jangkaan = penanda_untuk(medan, tc)
                    if _norm(kod) != _norm(jangkaan):
                        lapor(tc, medan, f"(Excel senyap -> {jangkaan})", kod,
                              "didaftar dalam BLANK_BY_DESIGN tetapi tidak "
                              "membawa penanda yang betul")
                kategori["penanda"] += 1
                continue

            # [profil] medan dari profiles/*.json — HANYA kalau C9 memang
            # senyap tentangnya. Kalau C9 membekalkan nilai (T-012
            # username/password, TN-001 id_penguatkuasa), medan itu jatuh
            # ke cabang [excel] di bawah dan MESTI sepadan; profil tidak
            # boleh dijadikan alasan untuk menyimpang daripada Excel.
            if medan in DARI_PROFIL and medan not in dari_c9:
                kategori["profil"] += 1
                continue

            # [excel] mesti dihurai dari C9 dan sepadan
            sebenar = dari_c9.get(medan)
            if sebenar is None:
                lapor(tc, medan, "(Excel senyap)", kod,
                      "kod menampal nilai yang Excel tidak bekalkan — "
                      "daftarkan dalam BLANK_BY_DESIGN (kalau medan teks "
                      "bebas) atau BELUM_DISAHKAN (kalau dropdown/"
                      "autocomplete/berangka), atau DIBENARKAN dengan sebab")
            elif _norm(sebenar) != _norm(kod):
                lapor(tc, medan, sebenar, kod, "tidak sepadan dengan C9")
            else:
                kategori["excel"] += 1

        # -------------------------------------------------------------
        # 4. BELUM_DISAHKAN: TC dilangkau — sebabnya mesti BENAR.
        # -------------------------------------------------------------
        # >>> DIPERHALUSI 2026-08-04, BUKAN DILONGGARKAN. <<<
        #
        # Bentuk lama menuntut DUA perkara sekaligus: medan itu tiada
        # nilai dalam TC_DATA, DAN C9 senyap tentangnya. Alasannya satu
        # sahaja — "kalau Excel MEMANG membekalkannya, TC dilangkau tanpa
        # sebab". Alasan itu betul untuk SATU kelas sekatan sahaja.
        #
        # BELUM_DISAHKAN membawa DUA sebab sekat yang berlainan, dan
        # daftarnya sendiri sudah membezakannya
        # (KLASIFIKASI_BELUM_DISAHKAN):
        #
        #   EXCEL_SENYAP               kita tidak tahu APA nak taip
        #   TIDAK_DIJUMPAI_PADA_DEVICE kita tidak tahu DI MANA nak taip
        #
        # Oracle membekalkan nilai hanya menjawab soalan PERTAMA. Medan
        # yang locatornya tidak dijumpai pada device kekal tersekat
        # walaupun nilainya kini diketahui — dan skipnya JUJUR, sebabnya
        # device, bukan Excel. Pada 2026-08-04 kesemua 39 medan
        # BELUM_DISAHKAN berkelas TIDAK_DIJUMPAI_PADA_DEVICE dan SIFAR
        # berkelas EXCEL_SENYAP.
        #
        # Maka semakan kini bertanya kelas, bukan sekadar "adakah C9
        # bercakap". Mod kegagalan asal — TC dilangkau sedangkan Excel
        # sebenarnya membekalkan yang diperlukan — MASIH ditangkap, tepat
        # pada kelas yang ia wujud untuknya. Menyimpan nilai oracle dalam
        # TC_DATA untuk medan yang tersekat-device adalah betul: ia
        # boleh dijejak ke sel, ia tidak pernah ditaip selagi TC melangkau,
        # dan ia sudah sedia apabila locator itu ditemui.
        for medan in sorted(belum):
            diperiksa += 1
            kelas = KLASIFIKASI_BELUM_DISAHKAN.get((tc, medan), {})
            kelas = (kelas.get("kelas") if isinstance(kelas, dict)
                     else kelas) or ""
            sekat_device = "DEVICE" in str(kelas).upper()
            if medan in TC_DATA[tc] and not sekat_device:
                lapor(tc, medan, "-", TC_DATA[tc][medan],
                      "didaftar BELUM_DISAHKAN tetapi ada nilai dalam "
                      "TC_DATA — buang salah satu")
            if medan in dari_c9 and not sekat_device:
                lapor(tc, medan, dari_c9[medan], "(tiada)",
                      "didaftar BELUM_DISAHKAN tetapi C9 MEMANG "
                      "membekalkan nilai — TC dilangkau tanpa sebab")

        # -------------------------------------------------------------
        # 5. Satu medan tidak boleh berada dalam kedua-dua daftar
        # -------------------------------------------------------------
        bertindih = set(blanks) & set(belum)
        if bertindih:
            lapor(tc, ", ".join(sorted(bertindih)), "-", "-",
                  "medan didaftar dalam BLANK_BY_DESIGN DAN BELUM_DISAHKAN")

        # -------------------------------------------------------------
        # 6. Nombor rekod dalam C9 tidak boleh bocor ke TC_DATA
        # -------------------------------------------------------------
        # C9 MBJB penuh dengan nombor rekod run Februari 2026. Kalau
        # salah satu daripadanya muncul sebagai nilai data, bermakna
        # suite akan membuka rekod penguji lain, bukan rekod yang ia
        # sendiri cipta (PERATURAN KERAS #7).
        rekod = set(P.nombor_rekod_dalam(c9))
        for medan, kod in TC_DATA[tc].items():
            if str(kod) in rekod:
                lapor(tc, medan, "(nombor rekod run lama)", kod,
                      "nombor rekod dari C9 dijadikan nilai data — rekod "
                      "itu milik run manual Feb 2026, bukan run ini")

    # -----------------------------------------------------------------
    # 6b. Nilai yang dibuang oleh _pasang_penanda() / _pakai_overrides()
    # -----------------------------------------------------------------
    # Penanda sentiasa menang, jadi TC_DATA akhir tetap betul. Tetapi
    # nilai rekaan yang masih tertinggal dalam fail akan ditulis semula
    # oleh orang seterusnya yang membacanya. Gate ini memaksa ia dibuang.
    for tc, medan, nilai in DIBUANG:
        lapor(tc, medan, "(Excel senyap -> penanda)", nilai,
              "nilai ditulis ke medan BLANK_BY_DESIGN dan dibuang semasa "
              "import — keluarkannya dari fail sumber, bukan biarkan ia "
              "tertinggal")

    # -----------------------------------------------------------------
    # 7. Pengecualian basi — didaftar tetapi tidak pernah dipakai
    # -----------------------------------------------------------------
    for kunci in DIBENARKAN:
        if kunci in dibenarkan_dipakai:
            continue
        # Entri 'runtime' (kadar_denda) SENGAJA tiada dalam TC_DATA —
        # nilainya hanya wujud selepas KESALAHAN dipilih pada device.
        # Ia TIDAK dilepaskan: Seksyen 12 menggantikan semakan basi ini
        # dengan lima semakan yang lebih ketat.
        if DIBENARKAN[kunci].get("runtime"):
            continue
        lapor(kunci[0], kunci[1], "-", "-",
              "pengecualian DIBENARKAN didaftar tetapi medan itu tiada "
              "dalam TC_DATA — buang pengecualian basi")

    # -----------------------------------------------------------------
    # 8. LICENSE_SETTINGS mesti sepadan overrides.OVERRIDES
    # -----------------------------------------------------------------
    # Kedua-duanya membawa nilai persekitaran yang sama. Kalau satu
    # dikemas kini dan satu lagi tidak, run akan kena hos yang salah
    # tanpa sebarang isyarat.
    _o = _ovr.OVERRIDES.get("MBJB", {})
    _pasangan = [
        ("internal_ip", _o.get("TC-T-001", {}).get("ip_address"),
         "TC-T-001.ip_address"),
        ("external_ip", _o.get("TC-T-001", {}).get("ip_address"),
         "TC-T-001.ip_address"),
        ("lesen_aplikasi", _o.get("TC-T-002", {}).get("lesen_aplikasi"),
         "TC-T-002.lesen_aplikasi"),
    ]
    for nama, nilai_ovr, label in _pasangan:
        diperiksa += 1
        if nilai_ovr is None:
            lapor("(overrides)", label, "-", "(tiada)",
                  f"LICENSE_SETTINGS['{nama}'] tiada pasangan dalam "
                  f"OVERRIDES — nilai persekitaran tanpa sebab bertulis")
        elif _norm(nilai_ovr) != _norm(LICENSE_SETTINGS.get(nama)):
            lapor("(overrides)", label, nilai_ovr,
                  LICENSE_SETTINGS.get(nama),
                  f"LICENSE_SETTINGS['{nama}'] menyimpang daripada OVERRIDES")

    # -----------------------------------------------------------------
    # 9. LUBANG GATE: literal yang ditaip ke aplikasi dari fail test
    # -----------------------------------------------------------------
    # Semakan 1-8 hanya memeriksa TC_DATA. Satu nilai rekaan yang
    # dihardcode DALAM fail test memintas kesemuanya — gate melaporkan
    # "Tiada percanggahan" sedangkan nilai rekaan sedang ditaip ke DB
    # staging sebenar. Itu betul-betul berlaku:
    # start_kemaskini("KEMASKINI VIA AUTOMATION MBJB") dalam 5 fail
    # *-004 (isu QA P2-3). PERATURAN KERAS #5.
    #
    # Peraturannya: apa-apa yang ditaip ke dalam aplikasi mesti datang
    # dari data[...] / TC_DATA, bukan dari literal dalam fail test.
    _FUNGSI_MENAIP = (
        "start_kemaskini", "type_text", "set_text", "enter_text",
        "isi_medan", "fill_field",
    )
    _LITERAL_DIBENARKAN = re.compile(
        r'^(|N/A|-|0000|\s*)$', re.I)          # kata laluan printer 0000 dll
    tests_dir = os.path.join(ROOT, "tests")
    if os.path.isdir(tests_dir):
        pola = re.compile(
            r'\b(' + "|".join(_FUNGSI_MENAIP) + r')\(\s*["\']([^"\']*)["\']')
        for nama in sorted(os.listdir(tests_dir)):
            if not (nama.startswith("test_") and nama.endswith(".py")):
                continue
            jalan = os.path.join(tests_dir, nama)
            with open(jalan, encoding="utf-8") as fh:
                for no, baris in enumerate(fh, 1):
                    if baris.lstrip().startswith("#"):
                        continue
                    m = pola.search(baris)
                    if not m:
                        continue
                    diperiksa += 1
                    fungsi, literal = m.group(1), m.group(2)
                    if _LITERAL_DIBENARKAN.match(literal):
                        continue
                    lapor(f"{nama}:{no}", fungsi, "(bukan dari Excel)",
                          literal,
                          "literal ditaip ke aplikasi dari fail test — "
                          "nilai ini tidak kelihatan oleh mana-mana "
                          "semakan lain. Pindahkannya ke TC_DATA "
                          "(BLANK_BY_DESIGN kalau Excel senyap) dan "
                          "hantar data[...] ke sini")

    # -----------------------------------------------------------------
    # 9b. LUBANG KELAS: panggilan 'mobile: type' di luar corong
    # -----------------------------------------------------------------
    # 2026-08-04. `mobile: type` meranapkan app (redbox RN) pada laluan
    # Kemaskini. Ia dibaiki pada SATU tapak — dan kelasnya kekal hidup:
    # imbasan seluruh repo menemui **18** panggilan langsung merentas 6
    # fail page, sepuluh daripadanya di LUAR base_page.py dan tidak
    # disenaraikan dalam mana-mana nota. Beberapa daripadanya menaip
    # nilai testdata penuh (warna_kereta, ulasan, new_text).
    #
    # Corak kegagalan yang sama seperti pecahan sapuan 0.83: satu tapak
    # dibaiki, kelas kekal. Maka kelas itu kini DIKUNCI pada satu corong,
    # `base_page._mobile_type`, dan gerbang ini menguatkuasakannya.
    #
    # Kalau kau perlu `mobile: type` di tempat baharu: panggil
    # `self._mobile_type(...)`. JANGAN longgarkan semakan ini.
    _CORONG_FAIL = "base_page.py"
    _CORONG_DEF = "_mobile_type"
    pages_dir = os.path.join(ROOT, "pages")
    if os.path.isdir(pages_dir):
        _rx_def = re.compile(r'^\s*def\s+(\w+)')
        _rx_exec = re.compile(r'execute_script\s*\(')
        _rx_mt = re.compile(r'["\']mobile:\s*type["\']')
        for nama in sorted(os.listdir(pages_dir)):
            if not nama.endswith(".py"):
                continue
            with open(os.path.join(pages_dir, nama), encoding="utf-8") as fh:
                baris_semua = fh.readlines()
            def_semasa = "(aras modul)"
            for no, baris in enumerate(baris_semua, 1):
                m = _rx_def.match(baris)
                if m:
                    def_semasa = m.group(1)
                if baris.lstrip().startswith("#"):
                    continue
                if not _rx_exec.search(baris):
                    continue
                # Panggilan boleh merentas dua baris:
                #     self.driver.execute_script(
                #         'mobile: type', {'text': ch})
                ekor = baris + (baris_semua[no] if no < len(baris_semua)
                                else "")
                if not _rx_mt.search(ekor):
                    continue
                diperiksa += 1
                if nama == _CORONG_FAIL and def_semasa == _CORONG_DEF:
                    continue
                lapor(f"{nama}:{no}", def_semasa, "(corong sahaja)",
                      "execute_script('mobile: type', ...)",
                      f"panggilan 'mobile: type' LANGSUNG di luar "
                      f"{_CORONG_FAIL}.{_CORONG_DEF}. Ia memintas pengawal "
                      f"seaksara yang menghalang redbox RN. Guna "
                      f"self._mobile_type(...) — atau self._emit_text(...) "
                      f"kalau send_keys memadai")

    # -----------------------------------------------------------------
    # 10. ANTARA MUKA LAPORAN — excel_data.NILAI_DARI_SHEET_005
    # -----------------------------------------------------------------
    # KEPUTUSAN PEMILIK 2026-07-30: TC *-001/*-004 mengambil rantaian
    # KESALAHAN tiga tingkat dari sheet *-005 jenis yang SAMA. Pemilik
    # menuntut laporan akhir MENYENARAIKAN setiap TC yang berbuat begitu,
    # berserta sel sumbernya, supaya pembaca laporan tahu asal nilai itu
    # tanpa menyiasat.
    #
    # Senarai laporan itu ialah excel_data.NILAI_DARI_SHEET_005. Kalau ia
    # dibiarkan hidup sendiri, ia akan menyimpang daripada DIBENARKAN dan
    # daripada workbook secara senyap — mod kegagalan yang sama seperti
    # komen tersalah salin. Maka ia DIIKAT di sini pada TIGA hujung:
    #
    #   (a) setiap pengecualian DIBENARKAN yang menamakan sheet sumber
    #       *-005 MESTI ada barisnya dalam senarai laporan, dan
    #       sebaliknya — tiada baris hantu, tiada baris hilang;
    #   (b) `nilai_oracle` setiap baris mesti sama dengan sel *-005 yang
    #       DIBACA SEMULA di sini (bukan dipercayai dari testdata);
    #   (c) `nilai_dihantar` mesti sama dengan nilai sebenar TC_DATA, dan
    #       setiap penggantian mesti berlabel penggantian + berbukti.
    #
    # Ini MENGETATKAN gerbang. Ia tidak melonggarkan apa-apa: tiada nilai
    # baharu diluluskan di sini, hanya jejaknya dituntut kekal betul.
    try:
        from testdata.excel_data import (NILAI_DARI_SHEET_005,
                                         SEBAB_NILAI_DARI_005)
    except ImportError:
        NILAI_DARI_SHEET_005 = None
        lapor("(testdata)", "NILAI_DARI_SHEET_005", "-", "(tiada)",
              "struktur laporan 'nilai dari sheet *-005' dibuang — laporan "
              "akhir tidak lagi dapat menyenaraikan TC yang menggunakan "
              "nilai *-005 berserta sel sumbernya (keputusan pemilik "
              "2026-07-30). Kembalikannya, jangan buang gerbang ini")
    if NILAI_DARI_SHEET_005 is not None:
        # (a) DIBENARKAN <-> senarai laporan, dua hala.
        dari_dibenarkan = {
            k for k, v in DIBENARKAN.items()
            if str((v.get("sumber") or ("",))[0]).endswith("-005")}
        dari_laporan = {(r005["tc"], r005["medan"])
                        for r005 in NILAI_DARI_SHEET_005}
        for kunci in sorted(dari_dibenarkan - dari_laporan):
            lapor(kunci[0], kunci[1], "-", "(tiada dalam laporan)",
                  "nilai diambil dari sheet *-005 tetapi TIDAK tersenarai "
                  "dalam excel_data.NILAI_DARI_SHEET_005 — laporan akhir "
                  "akan menyembunyikan asal nilai ini")
        for kunci in sorted(dari_laporan - dari_dibenarkan):
            lapor(kunci[0], kunci[1], "(tiada dalam DIBENARKAN)", "-",
                  "senarai laporan mendakwa medan ini mengambil nilai *-005, "
                  "tetapi tiada pengecualian DIBENARKAN yang mendaftarkannya "
                  "— baris laporan hantu")
        # (b) + (c) setiap baris dipin pada workbook dan pada TC_DATA.
        for r005 in NILAI_DARI_SHEET_005:
            diperiksa += 1
            if r005.get("sebab") != SEBAB_NILAI_DARI_005:
                lapor(r005["tc"], r005["medan"], SEBAB_NILAI_DARI_005,
                      r005.get("sebab"),
                      "sebab bertulis penyimpangan diubah — ia mesti kekal "
                      "kata demi kata seperti diluluskan pemilik 2026-07-30")
            sn_sumber = sheets.get(r005["sheet_sumber"])
            if not sn_sumber:
                lapor(r005["tc"], r005["medan"],
                      f"({r005['sheet_sumber']} tiada)", "-",
                      "baris laporan menamakan sheet sumber yang tidak "
                      "wujud dalam workbook")
                continue
            kunci_blok = f"bookmark_{r005['blok']}_{r005['medan']}"
            sel = P.parse(_c(wb[sn_sumber], 9)).get(kunci_blok)
            if sel is None:
                lapor(r005["tc"], r005["medan"],
                      f"({r005['sel_sumber']} tidak membekalkan "
                      f"{kunci_blok})", r005["nilai_oracle"],
                      "baris laporan mendakwa nilai datang dari sel itu, "
                      "tetapi sel itu tidak membekalkannya")
            elif _norm(sel) != _norm(r005["nilai_oracle"]):
                lapor(r005["tc"], r005["medan"], sel, r005["nilai_oracle"],
                      "nilai_oracle dalam laporan tidak sepadan sel *-005 "
                      "yang dibaca semula — laporan akan menyebut asal yang "
                      "salah")
            sebenar_kod = (TC_DATA.get(r005["tc"]) or {}).get(r005["medan"])
            if _norm(sebenar_kod) != _norm(r005["nilai_dihantar"]):
                lapor(r005["tc"], r005["medan"], r005["nilai_dihantar"],
                      sebenar_kod,
                      "nilai_dihantar dalam laporan bukan nilai yang TC_DATA "
                      "benar-benar hantar ke device")
            beza = _norm(r005["nilai_dihantar"]) != _norm(r005["nilai_oracle"])
            if beza and not r005.get("penggantian"):
                lapor(r005["tc"], r005["medan"], r005["nilai_oracle"],
                      r005["nilai_dihantar"],
                      "nilai dihantar berbeza daripada oracle tetapi baris "
                      "laporan TIDAK menandakannya sebagai penggantian — "
                      "percanggahan kategori D akan lenyap dari laporan")
            elif beza and not r005.get("bukti_device"):
                lapor(r005["tc"], r005["medan"], r005["nilai_oracle"],
                      r005["nilai_dihantar"],
                      "penggantian didaftar tanpa bukti device — laporan "
                      "tidak boleh mendakwa nilai datang dari device tanpa "
                      "menamakan dumpnya")
            elif r005.get("penggantian") and not beza:
                lapor(r005["tc"], r005["medan"], r005["nilai_oracle"],
                      r005["nilai_dihantar"],
                      "baris laporan menandakan penggantian tetapi nilainya "
                      "sama dengan oracle — kalau DB staging sudah "
                      "dibetulkan, BUANG penggantian itu")

    # -----------------------------------------------------------------
    # 11. MEDAN ASSERTION — OUTPUT app, bukan input (pemilik 2026-07-30)
    # -----------------------------------------------------------------
    # 21 medan (Taman/Poskod/Bandar/Negeri pada kelima-lima *-001 + Jenis
    # Kereta pada K-001) DIPINDAHKAN keluar dari BELUM_DISAHKAN. Sebabnya:
    # BELUM_DISAHKAN bermaksud "kami belum tahu nilai apa yang perlu
    # DIHANTAR", sedangkan medan ini tidak pernah perlu nilai dihantar —
    # app menjananya sendiri. Excel senyap kerana ia memang TIDAK
    # SEPATUTNYA dibekalkan.
    #
    # Arahan pemilik: JANGAN cipta kategori longgar; kalau gerbang perlu
    # tahu tentang assertion, tambah semakan yang LEBIH KETAT. Enam
    # tuntutan di bawah, setiap satu boleh diputuskan secara statik:
    #
    #   (a) medan assertion DILARANG wujud dalam TC_DATA — kalau ia ada,
    #       seseorang menaip ke dalam OUTPUT app dan memusnahkan ujian;
    #   (b) DILARANG bertindih dengan BLANK_BY_DESIGN / BELUM_DISAHKAN;
    #   (c) TC mesti ada sheet, dan registri tidak boleh ada TC hantu;
    #   (d) [asas oracle] sel yang didakwa DIBACA SEMULA dari workbook dan
    #       petikannya mesti MASIH ada di dalamnya — satu "assertion" yang
    #       direka tanpa asas oracle MATI di sini;
    #   (e) [asas device] fail dump yang dipetik mesti benar-benar WUJUD
    #       dalam repo — tidak boleh memetik dump hantu;
    #   (f) handshake ujian pembaca (lihat di bawah).
    #
    # HAD YANG DIAKUI — DINYATAKAN, BUKAN DISENYAPKAN:
    # skrip ini TIDAK boleh membuktikan secara statik bahawa ujian pembaca
    # benar-benar GAGAL apabila nilai kosong. Itu sifat RUNTIME. Padanan
    # nama simbol akan diluluskan oleh ujian yang hanya print() tanpa
    # assert — iaitu gerbang LONGGAR yang menyamar sebagai ketat, tepat
    # yang dilarang. Maka yang dikuatkuasakan di sini ialah HANDSHAKE-nya:
    #   - setiap medan mesti membawa TEPAT SATU daripada 'ujian_pembaca'
    #     atau 'pembaca_tertunggak' (kedua-dua atau tiada = exit 1);
    #   - 'ujian_pembaca' = (fail, simbol): fail mesti wujud dalam tests/
    #     DAN mengandungi simbol itu DAN nama medan itu;
    #   - 'pembaca_tertunggak' menjadi BASI sebaik nama medan itu muncul
    #     dalam mana-mana fail tests/ — gerbang keluar 1 dan memaksa
    #     pengecualian itu ditukar kepada 'ujian_pembaca'. Jadi ia tidak
    #     boleh mereput senyap.
    # Kontrak penuh yang pemilik tests/ mesti penuhi:
    # excel_data.KONTRAK_PEMBACA_ASSERTION.
    try:
        from testdata.excel_data import (MEDAN_ASSERTION,
                                         KONTRAK_PEMBACA_ASSERTION)
    except ImportError:
        MEDAN_ASSERTION = None
        lapor("(testdata)", "MEDAN_ASSERTION", "-", "(tiada)",
              "registri medan ASSERTION dibuang — 21 medan OUTPUT app "
              "akan jatuh semula ke dalam BELUM_DISAHKAN atau, lebih "
              "buruk, ke dalam TC_DATA sebagai input rekaan. Kembalikan "
              "(keputusan pemilik 2026-07-30)")
    assertion_tanpa_pembaca_gate = []
    if MEDAN_ASSERTION is not None:
        # Isi teks setiap fail test SEKALI sahaja.
        _teks_tests = {}
        _tests_dir = os.path.join(ROOT, "tests")
        if os.path.isdir(_tests_dir):
            for _n in sorted(os.listdir(_tests_dir)):
                if _n.startswith("test_") and _n.endswith(".py"):
                    with open(os.path.join(_tests_dir, _n),
                              encoding="utf-8") as fh:
                        _teks_tests[_n] = fh.read()

        for tc in sorted(MEDAN_ASSERTION):
            if tc not in sheets:
                lapor(tc, "(assertion)", "(tiada sheet)", "-",
                      "MEDAN_ASSERTION menamakan TC yang tiada sheet dalam "
                      "workbook — registri hantu")
                continue
            ws_a = wb[sheets[tc]]
            blanks_a = BLANK_BY_DESIGN.get(tc) or {}
            belum_a = BELUM_DISAHKAN.get(tc) or {}
            for medan, e in sorted(MEDAN_ASSERTION[tc].items()):
                diperiksa += 1

                # (a) tidak boleh menjadi input
                if medan in (TC_DATA.get(tc) or {}):
                    lapor(tc, medan, "(OUTPUT app — tiada nilai dihantar)",
                          TC_DATA[tc][medan],
                          "medan ASSERTION ada nilai dalam TC_DATA — "
                          "suite akan MENAIP ke dalam medan yang app "
                          "sepatutnya isi sendiri, memusnahkan perkara "
                          "yang TC ini uji")
                # (b) tiada pertindihan daftar
                if medan in blanks_a or medan in belum_a:
                    lapor(tc, medan, "-", "-",
                          "medan ASSERTION juga didaftar dalam "
                          "BLANK_BY_DESIGN/BELUM_DISAHKAN — satu medan, "
                          "satu kategori")

                # (d)/(e) asas mesti dipin pada bukti yang dibaca semula
                asas = e.get("asas")
                if asas == "oracle":
                    sel_a = e.get("sel")
                    if not sel_a:
                        lapor(tc, medan, "-", "(tiada sel)",
                              "asas 'oracle' tanpa sel sumber — assertion "
                              "tanpa asas yang boleh disemak")
                    elif sel_a[0] not in sheets:
                        lapor(tc, medan, f"({sel_a[0]} tiada)", "-",
                              "asas oracle menamakan sheet yang tidak "
                              "wujud dalam workbook")
                    elif _norm(e.get("petikan")) not in _norm(
                            _c(wb[sheets[sel_a[0]]], sel_a[1])):
                        lapor(tc, medan,
                              _c(wb[sheets[sel_a[0]]],
                                 sel_a[1]).strip()[:90],
                              e.get("petikan"),
                              f"petikan yang didakwa TIDAK ada dalam "
                              f"{sel_a[0]}!C{sel_a[1]} yang dibaca semula "
                              f"— asas assertion ini palsu atau workbook "
                              f"sudah berubah")
                elif asas == "device":
                    bukti = e.get("bukti_device")
                    if not bukti:
                        lapor(tc, medan, "-", "(tiada bukti)",
                              "asas 'device' tanpa fail dump — assertion "
                              "tanpa asas yang boleh disemak")
                    elif not os.path.exists(
                            os.path.join(ROOT, *str(bukti).split("/"))):
                        lapor(tc, medan, bukti, "(fail tiada)",
                              "asas device memetik dump yang TIDAK wujud "
                              "dalam repo — bukti hantu")
                else:
                    lapor(tc, medan, "oracle|device", asas,
                          "asas assertion tidak sah")
                # silang-oracle (kalau ada) juga dipin
                silang = e.get("silang_oracle")
                if silang:
                    if silang[0] not in sheets:
                        lapor(tc, medan, f"({silang[0]} tiada)", "-",
                              "silang-oracle menamakan sheet yang tidak "
                              "wujud dalam workbook")
                    elif _norm(silang[2]) not in _norm(
                            _c(wb[sheets[silang[0]]], silang[1])):
                        lapor(tc, medan,
                              f"{silang[0]}!C{silang[1]}", silang[2],
                              "petikan silang-oracle tidak ada dalam sel "
                              "yang dibaca semula")

                # (f) handshake ujian pembaca
                pembaca = e.get("ujian_pembaca")
                tertunggak = e.get("pembaca_tertunggak")
                muncul = sorted(n for n, t in _teks_tests.items()
                                if medan in t)
                if pembaca and tertunggak:
                    lapor(tc, medan, "(satu sahaja)",
                          "ujian_pembaca + pembaca_tertunggak",
                          "kedua-dua diisi — sebaik pembaca wujud, BUANG "
                          "pengecualian tertunggak")
                elif not pembaca and not tertunggak:
                    lapor(tc, medan, "-", "(tiada)",
                          "medan ASSERTION tanpa ujian pembaca DAN tanpa "
                          "pengecualian tertunggak bertulis — medan "
                          "assertion mesti mempunyai ujian yang membaca "
                          "nilainya selepas auto-isi dan GAGAL kalau "
                          "kosong. Lihat KONTRAK_PEMBACA_ASSERTION")
                elif pembaca:
                    fail_u, simbol = pembaca[0], pembaca[1]
                    teks = _teks_tests.get(fail_u)
                    if teks is None:
                        lapor(tc, medan, f"tests/{fail_u}", "(tiada)",
                              "ujian_pembaca menamakan fail ujian yang "
                              "tidak wujud")
                    elif simbol not in teks:
                        lapor(tc, medan, f"{fail_u}::{simbol}", "(tiada)",
                              "ujian_pembaca menamakan simbol yang tidak "
                              "wujud dalam fail itu — kontrak pembaca "
                              "didakwa dipenuhi sedangkan tidak")
                    elif medan not in teks:
                        lapor(tc, medan, f"{fail_u}", "(nama medan tiada)",
                              "fail ujian tidak menyebut nama medan ini — "
                              "pembaca tidak boleh membaca medan yang ia "
                              "tidak namakan")
                else:
                    # tertunggak: mesti BASI sebaik pembaca sebenar muncul
                    assertion_tanpa_pembaca_gate.append((tc, medan))
                    if muncul:
                        lapor(tc, medan, ", ".join(muncul),
                              "pembaca_tertunggak",
                              "pengecualian 'pembaca tertunggak' sudah "
                              "BASI — nama medan ini SUDAH muncul dalam "
                              "fail ujian di atas. Tukar kepada "
                              "'ujian_pembaca': (fail, simbol) supaya "
                              "gerbang benar-benar mengikatnya")

                # medan ASSERTION tidak boleh diindeks sebagai INPUT dalam
                # tests/ — kalau ia diindeks, ujian menaip ke dalam OUTPUT
                # app. (Skop tests/ sahaja, sama seperti Seksyen 9;
                # pelanggaran dalam pages/ dilaporkan kepada Loh — lihat
                # excel_data.NOTA_PAGES_MEMBACA_ASSERTION_SEBAGAI_INPUT.)
                pola_input = re.compile(
                    r'data\s*(?:\[\s*|\.get\(\s*)["\']' +
                    re.escape(medan) + r'["\']')
                for nama_u, teks_u in _teks_tests.items():
                    if pola_input.search(teks_u):
                        lapor(f"{nama_u}", medan, "(OUTPUT app)",
                              "data[...]",
                              "fail ujian mengindeks medan ASSERTION "
                              "sebagai data input — medan ini dijana oleh "
                              "app dan mesti DIBACA dari skrin, bukan "
                              "dihantar")

    # -----------------------------------------------------------------
    # 12. kadar_denda — DIBENARKAN (runtime), pemilik 2026-07-30
    # -----------------------------------------------------------------
    # Menggantikan semakan "pengecualian basi" Seksyen 7 yang dilangkau
    # untuk entri 'runtime', dengan LIMA tuntutan yang lebih ketat.
    try:
        from testdata.excel_data import (
            KADAR_DENDA_RUNTIME, SEBAB_KADAR_DENDA_RUNTIME,
            sahkan_kadar_denda, rekod_julat_kadar_denda)
    except ImportError:
        KADAR_DENDA_RUNTIME = None
        lapor("(testdata)", "KADAR_DENDA_RUNTIME", "-", "(tiada)",
              "struktur runtime kadar_denda dibuang — tiada lagi tempat "
              "untuk melaporkan julat sebenar yang dibaca dari skrin, dan "
              "tiada lagi pengesahan bahawa nilai yang dihantar berada "
              "dalam julat itu (keputusan pemilik 2026-07-30)")
    if KADAR_DENDA_RUNTIME is not None:
        for tc in sorted(KADAR_DENDA_RUNTIME):
            e = KADAR_DENDA_RUNTIME[tc]
            diperiksa += 1
            if tc not in sheets:
                lapor(tc, "kadar_denda", "(tiada sheet)", "-",
                      "KADAR_DENDA_RUNTIME menamakan TC tanpa sheet")
                continue
            # >>> DISEGARKAN 2026-08-04 (Kerja 4). <<<
            # Premis asal entri ini ialah `nilai_excel: None` — "C9 memang
            # senyap tentang kadar denda", jadi APA-APA nilai RM dalam
            # TC_DATA semestinya direka dan akan TERCETAK pada kompaun
            # sebenar. Premis itu kini PALSU: workbook _CORRECTED menulis
            # `Kadar Denda (RM): 600 (sahkan dalam julat app)` pada
            # kesepuluh-sepuluh sheet berkenaan.
            #
            # Pengecualian TIDAK dibuang — ia disegarkan, dan menjadi
            # LEBIH ketat. Dahulu ia menuntut ketiadaan; kini ia menuntut
            # PADANAN dengan sel yang dibaca semula. Semakan (3) (petikan
            # 'predefined range' C10) dan (5) (pengesah runtime gagal-
            # tertutup) kekal seperti sedia ada: nota sel sendiri berkata
            # "sahkan dalam julat app", jadi nilai oracle ialah nilai yang
            # DITAIP dan julat runtime tetap yang MENGESAHKANNYA. Dua
            # tuntutan berlainan, kedua-duanya masih dikuatkuasakan.
            # (1) nilai dalam TC_DATA WAJIB sama dengan sel C9
            # C9 sheet TC ini dibaca SEMULA di sini, bukan dipercayai
            # dari testdata — sama seperti setiap tuntutan lain.
            _c9_kd = P.parse(_c(wb[sheets[tc]], 9)).get("kadar_denda")
            _kod_kd = (TC_DATA.get(tc) or {}).get("kadar_denda")
            if _c9_kd is None:
                lapor(tc, "kadar_denda", "(C9 senyap)", _kod_kd,
                      "entri runtime mendakwa sheet ini membekalkan kadar "
                      "denda, tetapi C9 yang dibaca semula tidak — premis "
                      "pengecualian ini sudah berubah lagi, semak semula")
            elif _kod_kd is None:
                lapor(tc, "kadar_denda", _c9_kd, "(tiada dalam TC_DATA)",
                      "C9 membekalkan kadar denda tetapi TC_DATA tidak "
                      "membawanya — nilai oracle hilang")
            elif _norm(_kod_kd) != _norm(_c9_kd):
                lapor(tc, "kadar_denda", _c9_kd, _kod_kd,
                      "nilai kadar denda menyimpang daripada sel C9")
            # (2) medan ini TIDAK boleh lagi berada dalam BELUM_DISAHKAN:
            #     sekatannya ialah "Excel tidak beri nilai", dan Excel kini
            #     memberi. Melangkau TC atas sebab itu kini TIDAK jujur.
            if "kadar_denda" in (BELUM_DISAHKAN.get(tc) or {}):
                lapor(tc, "kadar_denda", _c9_kd, "(masih BELUM_DISAHKAN)",
                      "C9 kini membekalkan kadar denda, jadi sekatan lama "
                      "'Excel senyap' sudah tidak sah — TC akan melangkau "
                      "atas sebab yang tidak lagi benar")
            # (3) sel C10 yang didakwa dibaca semula
            sel = e.get("sel")
            if not sel or sel[0] not in sheets:
                lapor(tc, "kadar_denda", f"({(sel or ('?',))[0]} tiada)",
                      "-", "entri runtime menamakan sheet sumber yang "
                           "tidak wujud")
            elif _norm(e.get("petikan")) not in _norm(
                    _c(wb[sheets[sel[0]]], sel[1])):
                lapor(tc, "kadar_denda",
                      _c(wb[sheets[sel[0]]], sel[1]).strip()[:90],
                      e.get("petikan"),
                      f"petikan yang didakwa TIDAK ada dalam "
                      f"{sel[0]}!C{sel[1]} yang dibaca semula — tuntutan "
                      f"'predefined range' ini tiada asas oracle")
            # (4) sebab bertulis kekal kata demi kata
            if e.get("sebab") != SEBAB_KADAR_DENDA_RUNTIME:
                lapor(tc, "kadar_denda", SEBAB_KADAR_DENDA_RUNTIME,
                      e.get("sebab"),
                      "sebab bertulis diubah — ia mesti kekal kata demi "
                      "kata seperti diluluskan pemilik 2026-07-30")
        # (5) pengesah runtime mesti GAGAL-TERTUTUP tanpa julat
        diperiksa += 1
        try:
            sahkan_kadar_denda("MBPG-TC-P-001", "50")
        except AssertionError:
            pass                       # betul: tiada julat -> menolak
        except Exception as exc:                        # noqa: BLE001
            lapor("(testdata)", "sahkan_kadar_denda", "AssertionError",
                  type(exc).__name__,
                  "pengesah kadar denda melontar jenis ralat yang salah "
                  "apabila julat belum dibaca")
        else:
            lapor("(testdata)", "sahkan_kadar_denda", "menolak", "menerima",
                  "pengesah kadar denda MENERIMA nilai walaupun julat "
                  "min-maks belum pernah dibaca dari skrin — itu julat "
                  "andaian, dan ia membenarkan nilai RM sewenang-wenang "
                  "tercetak pada kompaun sebenar")

    # -----------------------------------------------------------------
    # 13. LALUAN KESALAHAN YANG DISAHKAN PADA DEVICE — bukti LUARAN
    # -----------------------------------------------------------------
    # Seksyen 1-12 membaca semula WORKBOOK. Seksyen ini membaca semula
    # DEVICE: dump JSON yang Loh hasilkan apabila dia melalui kesepuluh
    # laluan KESALAHAN hujung-ke-hujung pada 2026-07-30.
    #
    # Tanpa seksyen ini, kesemua penggantian kategori D bergantung pada
    # nilai yang DITAIP SEMULA ke dalam fail Python — iaitu tepat corak
    # "KOMEN TERSALAH SALIN" yang skrip ini wujud untuk membunuh. Di sini
    # nilai device dibaca dari failnya sendiri dan dibandingkan dengan apa
    # yang TC_DATA benar-benar hantar.
    #
    # Ia juga MENGUNCI jurang kategori D yang SEBENAR: satu laluan yang
    # device tidak tawarkan (K-004) mesti kekal terdaftar dalam
    # excel_data.PERCANGGAHAN_KATEGORI_D, lengkap dengan nilai TEPAT yang
    # hilang DAN setiap nilai yang device tawar sebagai gantinya. Kalau
    # sesiapa membuangnya, jurang itu lenyap dari laporan dev secara
    # senyap — gerbang keluar 1.
    try:
        from testdata.excel_data import (
            PERCANGGAHAN_KATEGORI_D, LABEL_KATEGORI_B_POSKOD)
    except ImportError:
        PERCANGGAHAN_KATEGORI_D = ()
        LABEL_KATEGORI_B_POSKOD = "(LABEL_KATEGORI_B_POSKOD tiada — import gagal)"
        lapor("(testdata)", "PERCANGGAHAN_KATEGORI_D", "-", "(tiada)",
              "daftar percanggahan kategori D dibuang — setiap jurang data "
              "yang dev perlu tutup lenyap dari laporan akhir")
    _LALUAN_MEDAN = {"t1": "keterangan_kod_kompaun",
                     "t2": "kod_akta",
                     "t3": "kesalahan_kompaun"}
    _laluan = {}
    for _f, _kunci in (("laluan_kesalahan_disahkan.json", "laluan"),
                       # baki ditulis SELEPAS pemadan dibetulkan -> menang
                       ("laluan_baki_disahkan.json", None),
                       # BACAAN TERBAHARU MENANG. Ditambah 2026-08-06:
                       # dialog tingkat 1 diukur semula (diskrol sampai
                       # habis) dan ejaan device BERUBAH — 'KOMPAUN
                       # PELBAGAI BANGUNANS' -> 'KOMPAUN PELBAGAI
                       # BANGUNAN'. Fail 2026-07-30 DIKEKALKAN UTUH
                       # sebagai rekod sejarah; ia tidak disunting.
                       # Baris dalam fail baharu MENYALIN t2/t3 lama
                       # bulat-bulat, jadi pin tingkat 2 dan 3 di bawah
                       # kekal berkuasa penuh — bukan dilemahkan.
                       ("laluan_t1_2026-08-06.json", None)):
        _p = os.path.join(ROOT, "ui_dumps", _f)
        if not os.path.exists(_p):
            lapor("(ui_dumps)", _f, "(fail bukti device)", "(tiada)",
                  "dump laluan KESALAHAN yang disahkan pada device hilang "
                  "— setiap penggantian kategori D kehilangan buktinya dan "
                  "menjadi nilai yang ditaip semula tanpa sumber")
            continue
        import json as _json
        with open(_p, encoding="utf-8") as fh:
            _isi = _json.load(fh)
        for _row in (_isi[_kunci] if _kunci else _isi):
            _laluan[f"MBPG-TC-{_row['tc']}"] = _row

    for tc in sorted(_laluan):
        row = _laluan[tc]
        dapat = row.get("dapat") or {}
        mahu = row.get("mahu") or {}
        for tingkat, medan in sorted(_LALUAN_MEDAN.items()):
            nilai_device = dapat.get(tingkat)
            if not nilai_device:
                continue
            diperiksa += 1
            dihantar = (TC_DATA.get(tc) or {}).get(medan)
            if dihantar is None:
                lapor(tc, medan, nilai_device, "(tiada dalam TC_DATA)",
                      f"device menawarkan nilai {tingkat} yang disahkan "
                      f"pada laluan penuh, tetapi TC_DATA tidak menghantar "
                      f"apa-apa untuk medan ini")
            elif _norm(dihantar) != _norm(nilai_device):
                lapor(tc, medan, nilai_device, dihantar,
                      f"nilai {tingkat} yang device SEBENARNYA tawarkan "
                      f"(dibaca semula dari ui_dumps/laluan_*.json) tidak "
                      f"sama dengan nilai yang TC_DATA hantar — daftarkan "
                      f"penggantian kategori D, atau betulkan nilai. "
                      f"JANGAN normalkan tanda baca untuk merapatkannya")

        # Jurang SEBENAR: device tidak menawarkan nilai untuk tingkat ini.
        for tingkat, medan in sorted(_LALUAN_MEDAN.items()):
            pilihan = dapat.get(f"{tingkat}_pilihan")
            if dapat.get(tingkat) or not pilihan:
                continue
            diperiksa += 1
            dihantar = (TC_DATA.get(tc) or {}).get(medan)
            if dihantar is not None and any(
                    _norm(dihantar) == _norm(p) for p in pilihan):
                continue                # diselesaikan oleh penggantian
            hilang = mahu.get(tingkat)
            entri = [d for d in PERCANGGAHAN_KATEGORI_D
                     if tc in d["tc_terjejas"]
                     and _norm(d.get("oracle")) == _norm(hilang)]
            if not entri:
                lapor(tc, medan, hilang or "(?)", "(tiada entri kategori D)",
                      f"device TIDAK menawarkan nilai {tingkat} ini "
                      f"(bukti POSITIF ketiadaan: dialog dibuka, "
                      f"{len(pilihan)} nilai lain dibaca) dan TIADA "
                      f"penggantian didaftarkan — maka ia MESTI kekal "
                      f"dalam excel_data.PERCANGGAHAN_KATEGORI_D dengan "
                      f"nilai TEPAT yang hilang. Tanpa itu, jurang data "
                      f"ini lenyap dari laporan dev secara senyap")
                continue
            d = entri[0]
            if not d.get("belum_selesai"):
                lapor(tc, medan, hilang, "belum_selesai=False",
                      "jurang kategori D ditanda SELESAI sedangkan device "
                      "masih tidak menawarkan nilainya")
            # Setiap nilai yang device tawar mesti tersenarai, supaya dev
            # nampak persis apa yang ada dan apa yang perlu dimasukkan.
            teks = _norm(d.get("beza")) + " " + _norm(d.get("device"))
            hilang_dari_entri = [p for p in pilihan if _norm(p) not in teks]
            if hilang_dari_entri:
                lapor(tc, medan, f"{len(pilihan)} nilai device",
                      f"{len(hilang_dari_entri)} tidak tersenarai",
                      "entri kategori D tidak menyenaraikan setiap nilai "
                      "yang device tawar — dev tidak dapat melihat persis "
                      "apa yang ada berbanding apa yang perlu dimasukkan. "
                      "Tiada: " + " | ".join(hilang_dari_entri))

    # -----------------------------------------------------------------
    # 14. poskod / no_kp_ssm_kereta N-001 — KEPUTUSAN PEMILIK 2026-07-31
    # -----------------------------------------------------------------
    # Dua ujian negatif yang WAJIB kedua-duanya gagal-tertutup (exit 1):
    #
    #   (a) override poskod/no_kp_ssm_kereta dipulihkan daripada
    #       990323112289 kepada apa-apa nilai lain (termasuk dibuang
    #       sepenuhnya, yang menyamai "nilai oracle" — Excel senyap) —
    #       nilai TC_DATA tidak lagi sepadan nilai_dijangka yang dipin
    #       dalam DIBENARKAN.
    #   (b) entri bug kategori B poskod (LABEL_KATEGORI_B_POSKOD) dibuang
    #       daripada excel_data.PERCANGGAHAN_KATEGORI_D, ATAU ditanda
    #       belum_selesai=False, ATAU salah satu daripada DUA sampel jalan
    #       hilang daripada teksnya.
    #
    # Tujuan: override yang membenarkan N-001 DIJALANKAN (menaip penanda
    # ke medan INPUT poskod) TIDAK BOLEH menjadi cara bug auto-populate
    # (medan OUTPUT notis_poskod/kompaun_poskod) lenyap senyap daripada
    # laporan akhir. Kedua-dua perkara mesti kekal kelihatan serentak.
    # "poskod" DIKELUARKAN dari gelung ini 2026-08-05: ujian negatif
    # ini menjaga keputusan "override poskod mesti kekal ada", dan
    # keputusan itu sudah diterbalikkan pemilik. Menjaga keputusan
    # yang sudah mati akan MENGHALANG keputusan yang baharu.
    # no_kp_ssm_kereta KEKAL dijaga — ia medan berbeza, nilai IC
    # sebenar ke medan IC, dan keputusannya TIDAK diterbalikkan.
    for _medan_pn in ("no_kp_ssm_kereta",):
        diperiksa += 1
        _kunci_pn = ("MBPG-TC-N-001", _medan_pn)
        _dijangka_pn = DIBENARKAN.get(_kunci_pn, {}).get("nilai_dijangka")
        _sebenar_pn = (TC_DATA.get("MBPG-TC-N-001") or {}).get(_medan_pn)
        if _sebenar_pn is None:
            lapor("MBPG-TC-N-001", _medan_pn, _dijangka_pn, "(tiada)",
                  "UJIAN NEGATIF (a): override dibuang/tiada nilai — "
                  "medan ini kembali BELUM_DISAHKAN tanpa daftar semula "
                  "keputusan pemilik 2026-07-31 (KEPUTUSAN PEMILIK "
                  "2026-07-31, testdata/overrides.py TC-N-001)")
        elif _norm(_sebenar_pn) != _norm(_dijangka_pn):
            lapor("MBPG-TC-N-001", _medan_pn, _dijangka_pn, _sebenar_pn,
                  "UJIAN NEGATIF (a): override poskod/no_kp_ssm_kereta "
                  "dipulihkan/diubah daripada nilai berangka yang "
                  "disahkan device (990323112289) — KEPUTUSAN PEMILIK "
                  "2026-07-31 ditimpa senyap")
    del _medan_pn

    diperiksa += 1
    _entri_poskod_b = [d for d in PERCANGGAHAN_KATEGORI_D
                       if d.get("medan") == LABEL_KATEGORI_B_POSKOD]
    if not _entri_poskod_b:
        lapor("MBPG-TC-N-001", LABEL_KATEGORI_B_POSKOD,
              "(mesti wujud dalam PERCANGGAHAN_KATEGORI_D)", "(tiada)",
              "UJIAN NEGATIF (b): penemuan bug kategori B POSKOD dibuang "
              "daripada excel_data.PERCANGGAHAN_KATEGORI_D — bug ini MESTI "
              "kekal dalam laporan akhir walaupun override poskod "
              "membenarkan N-001 dijalankan (KEPUTUSAN PEMILIK 2026-07-31)")
    else:
        _d_pb = _entri_poskod_b[0]
        if not _d_pb.get("belum_selesai"):
            lapor("MBPG-TC-N-001", LABEL_KATEGORI_B_POSKOD,
                  "belum_selesai=True", "belum_selesai=False",
                  "UJIAN NEGATIF (b): bug kategori B POSKOD ditanda SELESAI "
                  "sedangkan auto-isi poskod tidak pernah dibetulkan/"
                  "disahkan semula pada device — hanya override input "
                  "ditambah, itu bukan pembetulan bug")
        _teks_pb = " ".join(str(_d_pb.get(k, "")) for k in
                            ("device", "beza", "keputusan", "sumber_device"))
        _sampel_wajib = (
            "JALAN BAKAK | KAMPUNG BARU SKUDAI",
            "JALAN BENTARA 10, LORONG 1 | TAMAN UNGKU TUN AMINAH",
        )
        _sampel_hilang = [s for s in _sampel_wajib if s not in _teks_pb]
        if _sampel_hilang:
            lapor("MBPG-TC-N-001", LABEL_KATEGORI_B_POSKOD,
                  "DUA sampel jalan", f"{len(_sampel_hilang)} hilang",
                  "UJIAN NEGATIF (b): entri kategori B POSKOD tidak lagi "
                  "membawa kedua-dua sampel jalan yang membuktikan bug "
                  "(dua laluan berbeza, dua kegagalan konsisten). Hilang: "
                  + " | ".join(_sampel_hilang))

    # -----------------------------------------------------------------
    # 15. KLASIFIKASI BELUM_DISAHKAN sepadan 1:1 dengan BELUM_DISAHKAN —
    #     keputusan Loh 2026-07-31, selepas penemuan uiautomator membuang
    #     node visible:false. GERBANG INI HANYA MENGETATKAN: ia menolak
    #     medan yatim (ada dalam satu daftar, tiada dalam yang lain), dan
    #     menolak DISAHKAN_TIADA tanpa nota bukti tertulis — supaya
    #     tiada siapa boleh mendakwa "confirmed absent" tanpa jejak.
    # -----------------------------------------------------------------
    _pasangan_belum = {(tc, m) for tc, d in BELUM_DISAHKAN.items()
                       for m in d}
    _pasangan_klas = set(KLASIFIKASI_BELUM_DISAHKAN)
    for tc, m in sorted(_pasangan_belum - _pasangan_klas):
        diperiksa += 1
        lapor(tc, m, "(mesti ada di KLASIFIKASI_BELUM_DISAHKAN)", "(tiada)",
              "medan BELUM_DISAHKAN tanpa klasifikasi asas — tidak "
              "diketahui sama ada EXCEL_SENYAP / TIDAK_DIJUMPAI_PADA_DEVICE "
              "/ DISAHKAN_TIADA; daftarkan dalam "
              "excel_data.KLASIFIKASI_BELUM_DISAHKAN")
    for tc, m in sorted(_pasangan_klas - _pasangan_belum):
        diperiksa += 1
        lapor(tc, m, "(tiada)", "(dalam KLASIFIKASI_BELUM_DISAHKAN)",
              "klasifikasi wujud untuk medan yang bukan/tidak lagi dalam "
              "BELUM_DISAHKAN — daftar yatim, buang atau padankan semula")
    for (tc, m), e in KLASIFIKASI_BELUM_DISAHKAN.items():
        diperiksa += 1
        if e["kelas"] == KLAS_DISAHKAN_TIADA and not e.get("nota"):
            lapor(tc, m, "(nota bukti wajib)", "(kosong)",
                  "kelas DISAHKAN_TIADA tanpa nota bukti bertulis — "
                  "dakwaan 'confirmed absent' mesti dipin pada logcat/dump "
                  "selepas skrol penuh, bukan tanpa jejak")

    # -----------------------------------------------------------------
    # Laporan
    # -----------------------------------------------------------------
    r = ringkasan_liputan()
    print(f"Oracle : {os.path.relpath(XLSX, ROOT)}")
    print(f"Sheet  : {len(wb.sheetnames)} ({len(sheet_tc)} sheet TC)")
    print(f"Diperiksa {diperiksa} perkara merentas {len(TC_DATA)} TC.\n")
    print("Kategori nilai dalam TC_DATA:")
    print(f"  [excel]      {kategori['excel']:3d}  dihurai dari sel C9")
    print(f"  [penanda]    {kategori['penanda']:3d}  BLANK_BY_DESIGN "
          f"(Excel senyap, medan teks bebas)")
    print(f"  [struktur]   {kategori['struktur']:3d}  diterbit dari ID TC")
    print(f"  [dijangka]   {kategori['dijangka']:3d}  nilai assertion dari C11")
    print(f"  [dibenarkan] {kategori['dibenarkan']:3d}  penyimpangan "
          f"diluluskan")
    print(f"  [profil]     {kategori['profil']:3d}  dari profiles/*.json")
    if NILAI_DARI_SHEET_005:
        _ganti = [x for x in NILAI_DARI_SHEET_005 if x["penggantian"]]
        _tc005 = sorted({x["tc"] for x in NILAI_DARI_SHEET_005})
        print(f"\nNilai dari sheet *-005 (keputusan pemilik 2026-07-30):")
        print(f"  {len(NILAI_DARI_SHEET_005)} nilai / {len(_tc005)} TC — "
              f"{len(NILAI_DARI_SHEET_005) - len(_ganti)} verbatim oracle, "
              f"{len(_ganti)} diganti nilai device (kategori D)")
        print(f"  {', '.join(t.replace('MBPG-TC-', '') for t in _tc005)}")
        print(f"  Senarai penuh + sel sumber: python -c \"from "
              f"testdata.excel_data import cetak_sumber_005 as f; f()\"")
    if MEDAN_ASSERTION:
        _jum_a = sum(len(v) for v in MEDAN_ASSERTION.values())
        print(f"\nMedan ASSERTION (keputusan pemilik 2026-07-30 — OUTPUT "
              f"app, bukan input):")
        print(f"  {_jum_a} medan / {len(MEDAN_ASSERTION)} TC, dipindahkan "
              f"keluar dari BELUM_DISAHKAN")
        print(f"  Setiap satu dipin pada sel oracle atau dump device yang "
              f"dibaca semula oleh gerbang ini.")
        if assertion_tanpa_pembaca_gate:
            print(f"  >>> {len(assertion_tanpa_pembaca_gate)}/{_jum_a} "
                  f"MASIH TIADA UJIAN PEMBACA <<<")
            print(f"      Gerbang ini TIDAK boleh membuktikan secara "
                  f"statik bahawa sebuah ujian GAGAL apabila nilai "
                  f"kosong — itu sifat runtime, dan padanan nama simbol "
                  f"akan diluluskan oleh ujian yang hanya print().")
            print(f"      Yang dikuatkuasakan: handshake (fail+simbol+nama "
                  f"medan mesti wujud) dan pengecualian tertunggak yang "
                  f"menjadi BASI -> exit 1 sebaik pembaca sebenar muncul.")
            print(f"      Kontrak penuh: python -c \"from "
                  f"testdata.excel_data import "
                  f"KONTRAK_PEMBACA_ASSERTION as k; print(k)\"")
    if KADAR_DENDA_RUNTIME:
        print(f"\nkadar_denda — DIBENARKAN (runtime):")
        print(f"  {len(KADAR_DENDA_RUNTIME)} TC. {SEBAB_KADAR_DENDA_RUNTIME}")
        print(f"  Julat dibaca setakat ini: "
              f"{r['kadar_denda_julat_dibaca']}/"
              f"{len(KADAR_DENDA_RUNTIME)} "
              f"(rekod_julat_kadar_denda dipanggil pada runtime sahaja)")
    print(f"\nLiputan run:")
    print(f"  TC sedia dijalankan : {r['tc_sedia']}/{r['jumlah_tc']}")
    print(f"  TC tersekat         : {r['tc_tersekat']} "
          f"({r['medan_belum_disahkan']} medan BELUM_DISAHKAN)")
    if r["senarai_tersekat"]:
        print(f"  {', '.join(r['senarai_tersekat'])}")
    kb = r["klasifikasi_belum_disahkan"]
    print(f"\nKlasifikasi BELUM_DISAHKAN (keputusan Loh 2026-07-31):")
    for _kl, _n in kb["kelas"].items():
        print(f"  {_kl:28s} {_n}")
    print(f"  PERLU_SEMAK_SELEPAS_SKROL   {kb['perlu_semak_selepas_skrol']} "
          f"(subset TIDAK_DIJUMPAI_PADA_DEVICE — mungkin sekadar di bawah "
          f"paparan; uiautomator dump membuang node visible:false)")
    print()

    if not masalah:
        print("Tiada percanggahan — setiap nilai testdata dapat dijejak "
              "ke Excel V2.1.33, atau didaftarkan dengan sebabnya.")
        return 0

    print(f"{len(masalah)} PERCANGGAHAN:\n")
    for tc, medan, excel, kod, sebab in masalah:
        print(f"  {tc} . {medan}")
        print(f"      Excel : {excel}")
        print(f"      Kod   : {kod}")
        print(f"      -> {sebab}\n")
    print("Betulkan kod supaya ikut Excel, ATAU daftarkan penyimpangan\n"
          "dalam BLANK_BY_DESIGN / BELUM_DISAHKAN / DIBENARKAN dengan\n"
          "sebabnya. JANGAN longgarkan skrip ini.")
    return 1


if __name__ == "__main__":
    sys.exit(main())

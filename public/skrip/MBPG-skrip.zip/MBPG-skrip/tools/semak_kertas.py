"""
SENARAI SEMAK KERTAS — apa yang app SIMPAN, untuk dibandingkan dengan
apa yang printer CETAK.

Sebab alat ini wujud
--------------------
Pada 2026-08-18 rekod `PGP02K260818008` dilaporkan GAGAL pemeriksaan
manusia. Laporan itu sampai secara LISAN, tanpa butiran: tiada medan
dinamakan, tiada kertas disimpan. Jadi tiada apa yang boleh disiasat,
dan tiada asas untuk membandingkan build 2.1.21 dengan hotfix 2.1.23.

`rekod_log` menyimpan NOMBOR rekod sahaja. Nombor membuktikan sesuatu
telah dicipta; ia tidak membuktikan apa-apa tentang KANDUNGAN. Jurang
itulah yang menjadikan "gagal" tidak boleh ditindaklanjuti.

Alat ini menutup jurang tersebut dengan mengeluarkan baris sebenar dari
DB peranti sebagai senarai semak bertanda kotak. Pemeriksa memegang
kertas, menurunkan senarai, dan menanda baris yang TIDAK padan. Hasilnya
ialah nama medan, bukan perasaan.

BACA-SAHAJA. Tiada SQL tulis di mana-mana dalam fail ini.

PII
---
`namapesalah` / `idpesalah` boleh menjadi identiti warga SEBENAR apabila
borang K menggunakan carian mySIKAP. Nilai itu ditapis secara lalai
supaya laporan selamat disimpan dan di-commit; bentuk bertapis masih
cukup untuk menangkap rekod yang salah. `--penuh` memaparkan penuh dan
MENOLAK menulis fail.
"""

import argparse
import os
import sqlite3
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
AKAR = os.path.dirname(HERE)
sys.path.insert(0, AKAR)

# Jadual yang memegang rekod yang dicetak, dan lajur nombornya.
SUMBER = (
    ("local_ekpn_tawaran_kompaun", "nokompaun"),
    ("local_ekpn_notis_amaran", "noNotis"),
)

# Medan yang MUNCUL pada kertas, mengikut susunan ia dibaca. Susunan ini
# penting: pemeriksa mengikut senarai dari atas ke bawah sambil memegang
# kertas, jadi ia mesti mengikut aliran kertas dan bukan susunan lajur
# SQLite (yang mengikut sejarah skema).
SUSUNAN = (
    ("nokompaun", "No. kompaun"),
    ("noNotis", "No. notis"),
    ("tarikh", "Tarikh"),
    ("masa", "Masa"),
    ("waktu", "Waktu"),
    ("tempoh", "Tempoh"),
    ("namapesalah", "Nama pesalah"),
    ("idpesalah", "No. KP"),
    ("nokereta", "No. kenderaan"),
    ("jeniskereta", "Jenis kenderaan"),
    ("warnakereta", "Warna"),
    ("nopetak", "No. petak"),
    ("kodkompaun", "Kod kompaun"),
    ("kodakta", "Kod akta"),
    ("keterangan", "Kesalahan"),
    ("amounkompaun", "Amaun (RM)"),
    ("jalan", "Jalan"),
    ("jalan1", "Jalan 1"),
    ("taman", "Taman"),
    ("bandar", "Bandar"),
    ("poskod", "Poskod"),
    ("negeri", "Negeri"),
    ("longitud", "Longitud"),
    ("latitud", "Latitud"),
    ("nopenguatkuasa", "No. penguatkuasa"),
    ("nonotisamaran", "No. notis amaran"),
    ("statuskompaun", "Status"),
    ("statusnotis", "Status notis"),
    ("statushantar", "Status hantar"),
)

# Medan yang membawa identiti warga SEBENAR apabila borang K
# menggunakan carian mySIKAP. `noakaun` DIMASUKKAN kerana ia memegang
# nombor KP, bukan nombor akaun — nama lajur menipu, dan pada 2026-08-18
# ia menyebabkan satu KP sebenar dicetak ke terminal sebelum
# disedari. Medan `offender*` ialah alamat RUMAH pesalah.
MEDAN_PII = (
    "namapesalah", "idpesalah", "noakaun", "nocukai",
    "offenderjalan", "offendertaman", "offenderbandar",
    "offenderposkod",
)


def tapis(medan, nilai):
    """Cukup untuk mengenal pasti, tidak cukup untuk mengenal orang."""
    if medan not in MEDAN_PII or not nilai:
        return nilai
    t = str(nilai)
    if len(t) <= 4:
        return "*" * len(t)
    return t[:2] + "*" * (len(t) - 4) + t[-2:]


def cari_rekod(db, no_rekod):
    """Pulangkan (jadual, dict lajur->nilai) atau (None, None)."""
    c = sqlite3.connect(db)
    try:
        for jadual, lajur in SUMBER:
            try:
                cur = c.execute(
                    "SELECT * FROM %s WHERE %s = ?" % (jadual, lajur),
                    (no_rekod,))
            except sqlite3.Error:
                continue
            baris = cur.fetchone()
            if baris:
                nama = [d[0] for d in cur.description]
                return jadual, dict(zip(nama, baris))
    finally:
        c.close()
    return None, None


def senarai_semak(jadual, rekod, penuh=False):
    """Bina baris teks. Medan kosong DIKEKALKAN dan ditanda.

    Medan kosong ialah dapatan, bukan kekosongan untuk dilangkau: kalau
    kertas mencetak nilai yang DB tidak simpan, itu tepat jenis
    percanggahan yang sedang dicari.
    """
    keluar = []
    dilihat = set()
    for medan, label in SUSUNAN:
        if medan not in rekod:
            continue
        dilihat.add(medan)
        nilai = rekod[medan]
        papar = nilai if penuh else tapis(medan, nilai)
        if papar is None or str(papar).strip() == "":
            keluar.append((label, "(KOSONG dalam DB)", True))
        else:
            keluar.append((label, str(papar), False))
    # Apa-apa lajur yang tidak disenaraikan dalam SUSUNAN tetapi memegang
    # nilai — supaya skema baharu tidak hilang secara senyap.
    for medan, nilai in rekod.items():
        if medan in dilihat or nilai in (None, ""):
            continue
        papar = nilai if penuh else tapis(medan, nilai)
        keluar.append((medan, str(papar), False))
    return keluar


def tulis_laporan(no_rekod, jadual, baris):
    dir_out = os.path.join(AKAR, "reports", "semak")
    os.makedirs(dir_out, exist_ok=True)
    laluan = os.path.join(dir_out, "SEMAK-KERTAS-%s.md" % no_rekod)
    with open(laluan, "w", encoding="utf-8", newline="\n") as fh:
        fh.write("# Semak kertas — `%s`\n\n" % no_rekod)
        fh.write("Sumber: `%s` (DB peranti, baca-sahaja). "
                 "Nama/KP ditapis.\n\n" % jadual)
        fh.write("Pegang kertas. Turun senarai. Tanda **X** pada baris "
                 "yang TIDAK padan,\n")
        fh.write("dan tulis apa yang kertas tunjukkan.\n\n")
        fh.write("| ok? | Medan | Nilai dalam DB | Pada kertas (isi kalau beza) |\n")
        fh.write("|---|---|---|---|\n")
        for label, nilai, kosong in baris:
            tanda = "( )" if not kosong else "(!)"
            fh.write("| %s | %s | %s | |\n" % (tanda, label, nilai))
        fh.write("\n`(!)` = kosong dalam DB. Kalau kertas mencetak nilai "
                 "di sini, itu percanggahan.\n")
    return laluan


def main():
    p = argparse.ArgumentParser(
        description="Senarai semak kertas dari DB peranti (baca-sahaja).")
    p.add_argument("no_rekod", help="cth PGP02K260818008")
    p.add_argument("--db", help="guna snapshot DB sedia ada, "
                                "bukan tarik dari peranti")
    p.add_argument("--penuh", action="store_true",
                   help="papar PII penuh; TIDAK menulis fail")
    args = p.parse_args()

    db = args.db
    if not db:
        from config import APP_PACKAGE
        from device_utils import resolve_udid
        from devtools.smoke_tangga import tarik_db
        serial = resolve_udid(APP_PACKAGE, verbose=False)
        db = tarik_db(serial, os.path.join(AKAR, "data", "tmp",
                                           "semak_kertas.db"))

    jadual, rekod = cari_rekod(db, args.no_rekod)
    if not rekod:
        print("TIDAK DIJUMPAI: %s" % args.no_rekod)
        print("Rekod mungkin belum disync ke DB tempatan, atau nombor "
              "salah taip.")
        return 1

    baris = senarai_semak(jadual, rekod, penuh=args.penuh)
    print()
    print("== SEMAK KERTAS: %s  (%s) ==" % (args.no_rekod, jadual))
    for label, nilai, kosong in baris:
        print("  %s %-22s %s" % ("(!)" if kosong else "( )", label, nilai))

    if args.penuh:
        print()
        print("--penuh: fail TIDAK ditulis (PII tidak ditapis).")
        return 0
    laluan = tulis_laporan(args.no_rekod, jadual, baris)
    print()
    print("Ditulis: %s" % os.path.relpath(laluan, AKAR))
    return 0


if __name__ == "__main__":
    sys.exit(main())

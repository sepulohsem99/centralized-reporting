"""
JANA SET KOMBO — mapping JSON  ->  satu fail YAML setiap kombinasi.

KONSEP
------
Satu SET = satu kombinasi (kod kompaun x akta x kesalahan). Sweep memandu
tiga dropdown itu sahaja: pilih kod kompaun, pilih akta, pilih kesalahan,
baca kadar denda, keluar. Tiada medan pesalah, tiada kamera, tiada serah.

    python tools/jana_set.py                 # jana ke testdata/sets/
    python tools/jana_set.py --semak         # gagal kalau output akan berubah
    python tools/jana_set.py --mapping X.json

SUMBER KEBENARAN
----------------
testdata/mapping/mbpg-mapping-2026-08-07.json — SALINAN, jangan edit.
Asalnya snapshot 3-tingkat dari portal. AMARAN yang dibawa ke dalam setiap
fail set: `sumber` snapshot itu ialah epbtstaging.mbpg.gov.my — STAGING,
sedangkan sasaran run ialah production 113.211.155.174. Maka mapping ini
HIPOTESIS untuk disahkan pada device, bukan oracle. Kalau app membenarkan
kombo yang tiada di sini (atau menolak yang ada), itu DAPATAN.

IDEMPOTEN
---------
Jana semula = hasil sama, bait demi bait. Fail yang tidak lagi dijana
DIPADAM (lihat _bersih_stale) — kalau tidak, snapshot baharu meninggalkan
set hantu yang masih dikutip oleh sweep dan dilaporkan sebagai lulus.

JANGKAAN — dikira dari data, bukan disenaraikan dengan tangan
-------------------------------------------------------------
  BOLEH_GUNA      laluan penuh wujud (kod -> akta -> >=1 kesalahan)
  JANGKA_KOSONG   kod kompaun langsung tiada akta -> set NEGATIF:
                  sahkan dropdown Akta memang kosong
  JANGKA_MATI_T3  pasangan kod+akta wujud tetapi 0 kesalahan -> set
                  NEGATIF: sahkan dropdown Kesalahan memang kosong
  AMBIGU          nama akta berulang dalam mapping. Senarai kesalahan
                  disambung ikut NAMA akta (bukan id), jadi dua akta
                  bernama sama berkongsi senarai yang sama dan kita tidak
                  boleh tahu yang mana sepatutnya. Set tetap dijana;
                  run mesti mencatat apa yang app sebenarnya papar.

>>> DUA PERCANGGAHAN DENGAN RINGKASAN ARAHAN — data yang menang <<<
Arahan menyebut kod tanpa akta = (100, 1050, KA 12355, KA01) dan akta mati
= kod 06 sahaja. Mapping sebenar mengandungi LEBIH:
    kod tanpa akta : 10  (tambahan: 1001, KPKL, KPP, PLS 01, T001, T003)
    akta 0-kesalahan: 5  (tambahan: kod 01 akta 91 & 92, kod 05 akta 93,
                          kod KPBT akta ACT2026000002)
Generator ini mengira dari mapping, jadi ia menjana kesemuanya. Ringkasan
arahan itu contoh, bukan senarai lengkap — dan mengekodkan senarai pendek
itu akan menyembunyikan enam kod dan empat akta daripada sweep.
"""

import argparse
import glob
import json
import os
import re
import sqlite3
import sys
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
AKAR = os.path.dirname(HERE)
MAPPING_LALAI = os.path.join(AKAR, "testdata", "mapping",
                             "mbpg-mapping-2026-08-07.json")
DIR_SET = os.path.join(AKAR, "testdata", "sets")
DIR_LUAR = "_LUAR-SKOP"

# Borang yang memandu setiap jenis kod kompaun.
#
# PELBAGAI -> N dan P: seksyen Kompaun (tiga dropdown ini) adalah SAMA
# pada borang Daftar Notis Amaran dan Daftar Kompaun Pelbagai, jadi setiap
# set PELBAGAI boleh disapu pada kedua-duanya. Itu juga yang menjadikan
# sampel N bermakna: kalau senarai N == senarai P pada 26 sampel, kita ada
# bukti ia borang yang sama, bukan andaian.
BORANG_IKUT_JENIS = {
    "PELBAGAI": ["N", "P"],
    "LETAK KERETA": ["K"],
    "LESEN": ["L"],          # luar skop — dijana untuk rekod sahaja
}
JENIS_DALAM_SKOP = ("PELBAGAI", "LETAK KERETA")

BOLEH_GUNA = "BOLEH_GUNA"
JANGKA_KOSONG = "JANGKA_KOSONG"
JANGKA_MATI_T3 = "JANGKA_MATI_T3"
AMBIGU = "AMBIGU"

# jeniskod dalam DB peranti -> jenis yang kita gunakan.
JENIS_DB = {"P": "PELBAGAI", "L": "LESEN", "K": "LETAK KERETA"}


def _db_terkini(akar=None):
    """Snapshot DB production paling terkini dalam data/snapshot-*/."""
    akar = akar or AKAR
    calon = sorted(glob.glob(os.path.join(akar, "data", "snapshot-*",
                                          "e_kompaunV1.db")))
    return calon[-1] if calon else None


def baca_db(laluan):
    """Pokok kod->akta->kesalahan seperti yang PERANTI sebenarnya bawa.

    Ini sumber kebenaran untuk sweep. Snapshot mapping portal ialah
    STAGING dan terbukti berbeza secara material (lihat
    testdata/sets/BEZA-STAGING-VS-PRODUCTION.md).

    Bentuk jadual, disahkan pada snapshot 2026-08-07:
      local_ekpn_kod_kompaun     kod, keterangan, kodjabatan, jeniskod
      local_ekpn_akta_kompaun    kodkompaun -> kodakta   (jadual pautan)
      local_ekpn_akta            kod, kodakta(=NAMA), jenis, keterangan
      local_ekpn_kesalahan_kompaun  fk_akta -> akta.kod, kesalahan,
                                    kodkesalahan, amounnotis/min/max

    Perhatikan `local_ekpn_akta.kodakta` memegang NAMA akta, bukan kod —
    penamaan lajur yang mengelirukan. `kod` ialah id berangka yang
    dirujuk oleh fk_akta.
    """
    c = sqlite3.connect(laluan)
    c.row_factory = sqlite3.Row
    akta = {}
    for r in c.execute("SELECT * FROM local_ekpn_akta"):
        akta[str(r["kod"]).strip()] = {
            "id": str(r["kod"]).strip(),
            # Nama yang dipaparkan pada dropdown tingkat 2. `keterangan`
            # digunakan kalau ada; jika tidak, lajur `kodakta` (yang
            # memegang nama).
            "nama": (str(r["keterangan"] or "").strip()
                     or str(r["kodakta"] or "").strip()),
            "jenis": str(r["jenis"] or "").strip(),
        }
    pautan = defaultdict(list)
    for r in c.execute("SELECT * FROM local_ekpn_akta_kompaun"):
        pautan[str(r["kodkompaun"]).strip()].append(str(r["kodakta"]).strip())
    kes = defaultdict(list)
    for r in c.execute("SELECT * FROM local_ekpn_kesalahan_kompaun"):
        kes[str(r["fk_akta"]).strip()].append({
            "id": str(r["kod"]).strip(),
            "kodKesalahan": str(r["kodkesalahan"] or "").strip(),
            "keterangan": str(r["kesalahan"] or "").strip(),
            "amounnotis": r["amounnotis"],
            "amounmin": r["amounmin"],
            "amounmax": r["amounmax"],
            "amounmahkamah": r["amounmahkamah"],
        })
    for v in kes.values():
        v.sort(key=lambda k: str(k["id"]))
    kod = []
    for r in c.execute("SELECT * FROM local_ekpn_kod_kompaun ORDER BY kod"):
        kod.append({
            "kod": str(r["kod"]).strip(),
            "keterangan": str(r["keterangan"] or "").strip(),
            "jenis": JENIS_DB.get(str(r["jeniskod"]).strip(),
                                  str(r["jeniskod"]).strip()),
        })
    c.close()

    # Rujukan tergantung — direkod, bukan dibuang senyap.
    #   akta_hilang : jadual pautan menyebut akta yang tiada barisnya,
    #                 jadi tiada nama untuk dipilih pada dropdown.
    #   kes_yatim   : kesalahan menuding fk_akta yang tiada barisnya.
    akta_hilang = sorted({a for v in pautan.values() for a in v
                          if a not in akta})
    kes_yatim = sorted({k for k in kes if k not in akta})
    return {"kod": kod, "akta": akta, "pautan": pautan, "kesalahan": kes,
            "akta_hilang": akta_hilang, "kes_yatim": kes_yatim,
            "laluan": laluan}


def slug(teks, had=60):
    """Nama folder/fail selamat. Kod kompaun boleh mengandungi ruang
    ('KA 12355', 'PLS 01') dan nama akta boleh mengandungi '/', '&',
    kurungan — semuanya perlu dijinakkan tanpa hilang keterbacaan."""
    t = str(teks).upper().strip()
    t = t.replace("&", "DAN")
    t = re.sub(r"[^A-Z0-9]+", "-", t).strip("-")
    return t[:had] or "NIL"


def _yaml_str(v):
    """Petik rentetan supaya YAML tidak salah tafsir. Sengaja tidak guna
    yaml.dump: kita mahu susunan kunci yang STABIL dan boleh dibaca
    manusia dalam diff, dan yaml.dump menyusun/melipat mengikut caranya
    sendiri."""
    if v is None:
        return "null"
    s = str(v)
    return '"' + s.replace("\\", "\\\\").replace('"', '\\"') + '"'


def jana_dari_db(laluan_db, dir_set=DIR_SET):
    """Set daripada DB peranti — sumber kebenaran untuk sweep."""
    d = baca_db(laluan_db)
    tarikh = os.path.basename(os.path.dirname(laluan_db)).replace(
        "snapshot-", "") or "?"
    fail, sets = {}, []

    for kk in d["kod"]:
        luar = kk["jenis"] not in JENIS_DALAM_SKOP
        akar_kk = os.path.join(DIR_LUAR, "") if luar else ""
        dir_kod = f"KK{slug(kk['kod'], 20)}-{slug(kk['keterangan'])}"

        ids = sorted(set(d["pautan"].get(kk["kod"], [])))
        boleh = [a for a in ids if a in d["akta"]]

        if not ids or not boleh:
            s = bina_set(kk, None, None, JANGKA_KOSONG, tarikh,
                         ("Kod kompaun ini tiada akta yang boleh dilerai "
                          "dalam DB peranti. Set NEGATIF: pilih kod ini, "
                          "sahkan dropdown Akta KOSONG."
                          + (f" ({len(ids)} rujukan akta wujud dalam jadual "
                             f"pautan tetapi tiada barisnya: "
                             f"{', '.join(ids[:8])})" if ids else "")),
                         sumber="db-production")
            rel = os.path.join(akar_kk, dir_kod, s["set_id"] + ".yaml")
            fail[rel] = tulis_yaml(s)
            sets.append((rel, s))
            continue

        for aid in boleh:
            a = d["akta"][aid]
            dir_akta = f"AKT{slug(a['id'], 20)}-{slug(a['nama'])}"
            senarai = d["kesalahan"].get(aid, [])
            if not senarai:
                s = bina_set(kk, a, None, JANGKA_MATI_T3, tarikh,
                             "Akta ini tiada kesalahan dalam DB peranti. "
                             "Set NEGATIF: pilih kod + akta, sahkan "
                             "dropdown Kesalahan KOSONG.",
                             sumber="db-production")
                rel = os.path.join(akar_kk, dir_kod, dir_akta,
                                   s["set_id"] + ".yaml")
                fail[rel] = tulis_yaml(s)
                sets.append((rel, s))
                continue
            for kes in senarai:
                nota = ""
                if not kes["kodKesalahan"]:
                    nota = "Kesalahan ini TIADA kodKesalahan dalam DB."
                if kes["keterangan"].upper().startswith("TIDAK AKTIF"):
                    nota = (nota + " " if nota else "") + \
                        ("Kesalahan ditanda 'TIDAK AKTIF' dalam DB — "
                         "jangkakan ia mungkin tidak muncul pada dropdown.")
                s = bina_set(kk, a, kes, BOLEH_GUNA, tarikh, nota,
                             sumber="db-production",
                             denda={"notis": kes["amounnotis"],
                                    "min": kes["amounmin"],
                                    "max": kes["amounmax"],
                                    "mahkamah": kes["amounmahkamah"]})
                rel = os.path.join(akar_kk, dir_kod, dir_akta,
                                   s["set_id"] + ".yaml")
                fail[rel] = tulis_yaml(s)
                sets.append((rel, s))

    fail["INDEX.md"] = _index_db(sets, d, tarikh)
    # Laporan beza dijana DI SINI, bukan dalam main(), supaya `--semak`
    # melihat set fail yang SAMA seperti laluan tulis. Kalau tidak, semakan
    # idempoten melaporkan fail itu sebagai "HILANG" pada setiap larian.
    try:
        fail["BEZA-STAGING-VS-PRODUCTION.md"] = jana_beza(laluan_db,
                                                          MAPPING_LALAI)
    except Exception as e:                                   # noqa: BLE001
        print(f"  (laporan beza dilangkau: {type(e).__name__}: {e})")
    return fail, sets


def bina_set(kk, akta, kesalahan, jangkaan, tarikh, nota,
             sumber="mapping-staging", denda=None):
    """Satu set sebagai dict tersusun -> ditulis sebagai YAML."""
    kod = kk["kod"]
    aid = akta["id"] if akta else None
    kid = kesalahan["id"] if kesalahan else None
    bahagian = ["SET", f"KK{slug(kod, 20)}"]
    if aid:
        bahagian.append(f"AKT{slug(aid, 20)}")
    if kid:
        bahagian.append(slug(kid, 20))
    set_id = "-".join(bahagian)
    return {
        "set_id": set_id,
        "jangkaan": jangkaan,
        "dalam_skop": kk["jenis"] in JENIS_DALAM_SKOP,
        "borang": BORANG_IKUT_JENIS.get(kk["jenis"], []),
        "kod_kompaun": {"kod": kod, "nama": kk.get("keterangan", ""),
                        "jenis": kk.get("jenis", "")},
        "akta": ({"id": akta["id"], "nama": akta["nama"],
                  "jenis": akta.get("jenis", "")} if akta else None),
        "kesalahan": ({"id": kesalahan["id"],
                       "kod": kesalahan.get("kodKesalahan") or "",
                       "keterangan": kesalahan.get("keterangan", "")}
                      if kesalahan else None),
        "tarikh_snapshot": tarikh,
        "sumber": sumber,
        "denda": denda,
        "nota": nota,
    }


def tulis_yaml(s):
    b = []
    b.append("# Dijana oleh tools/jana_set.py — JANGAN EDIT DENGAN TANGAN.")
    b.append("# Jana semula selepas menukar snapshot sumber.")
    b.append("#")
    if s.get("sumber") == "db-production":
        b.append("# Sumber: DB PERANTI production (e_kompaunV1.db,")
        b.append("# baca-sahaja). Ini kombinasi yang app SEBENARNYA bawa,")
        b.append("# jadi ia rujukan yang betul untuk sweep. App tetap boleh")
        b.append("# berkelakuan lain daripada datanya — percanggahan antara")
        b.append("# fail ini dan apa yang dropdown papar ialah DAPATAN.")
    else:
        b.append("# Sumber: snapshot pemetaan portal STAGING; sasaran run")
        b.append("# ialah PRODUCTION. Nilai di sini HIPOTESIS — bukan")
        b.append("# oracle. Terbukti berbeza secara material daripada")
        b.append("# production; lihat BEZA-STAGING-VS-PRODUCTION.md.")
    b.append(f"set_id: {_yaml_str(s['set_id'])}")
    b.append(f"jangkaan: {_yaml_str(s['jangkaan'])}")
    b.append(f"dalam_skop: {'true' if s['dalam_skop'] else 'false'}")
    b.append("borang: [" + ", ".join(_yaml_str(x) for x in s["borang"]) + "]")
    b.append("kod_kompaun:")
    for k in ("kod", "nama", "jenis"):
        b.append(f"  {k}: {_yaml_str(s['kod_kompaun'][k])}")
    if s["akta"] is None:
        b.append("akta: null")
    else:
        b.append("akta:")
        for k in ("id", "nama", "jenis"):
            b.append(f"  {k}: {_yaml_str(s['akta'][k])}")
    if s["kesalahan"] is None:
        b.append("kesalahan: null")
    else:
        b.append("kesalahan:")
        for k in ("id", "kod", "keterangan"):
            b.append(f"  {k}: {_yaml_str(s['kesalahan'][k])}")
    b.append(f"tarikh_snapshot: {_yaml_str(s['tarikh_snapshot'])}")
    b.append(f"sumber: {_yaml_str(s.get('sumber', 'mapping-staging'))}")
    b.append(f"nota: {_yaml_str(s['nota'])}")
    d = s.get("denda")
    if d is None:
        b.append("denda: null   # snapshot mapping tidak membawa kadar")
        b.append("              # denda. Run MEREKOD apa yang app papar;")
        b.append("              # jangan reka nilai.")
    else:
        b.append("# Kadar dari DB peranti. amounnotis = 0 pada KESEMUA 120")
        b.append("# kesalahan dalam snapshot 2026-08-07 — jadi 'denda notis'")
        b.append("# nampaknya tidak digunakan, dan amounmin/amounmax yang")
        b.append("# bermakna. Run tetap MEREKOD apa yang app papar; nilai")
        b.append("# ini rujukan, bukan assertion.")
        b.append("denda:")
        for k in ("notis", "min", "max", "mahkamah"):
            v = d.get(k)
            b.append(f"  {k}: {'null' if v is None else v}")
    return "\n".join(b) + "\n"


def jana(mapping_path=MAPPING_LALAI, dir_set=DIR_SET):
    with open(mapping_path, encoding="utf-8") as fh:
        d = json.load(fh)
    tarikh = d.get("tarikh", "?")

    kes_ikut_akta = defaultdict(list)
    for k in d["kesalahan"]:
        kes_ikut_akta[k["akta"]].append(k)
    # Susunan stabil: id kesalahan. Tanpa ini, susunan bergantung pada
    # susunan JSON dan "idempoten" hanya benar selagi fail sumber tidak
    # disusun semula.
    for v in kes_ikut_akta.values():
        v.sort(key=lambda k: str(k["id"]))

    nama_berulang = defaultdict(list)
    for a in d["akta"]:
        nama_berulang[a["nama"]].append(a["id"])
    nama_berulang = {n: sorted(ids) for n, ids in nama_berulang.items()
                     if len(ids) > 1}

    fail = {}          # laluan relatif -> kandungan
    sets = []

    for kk in sorted(d["pokok"], key=lambda x: str(x["kod"])):
        jenis = kk.get("jenis", "")
        luar = jenis not in JENIS_DALAM_SKOP
        akar_kk = os.path.join(DIR_LUAR, "") if luar else ""
        dir_kod = f"KK{slug(kk['kod'], 20)}-{slug(kk.get('keterangan', ''))}"

        aktas = sorted((kk.get("akta") or []), key=lambda a: str(a["id"]))
        if not aktas:
            s = bina_set(kk, None, None, JANGKA_KOSONG, tarikh,
                         "Kod kompaun ini tiada akta dalam mapping. Set "
                         "NEGATIF: buka borang, pilih kod ini, sahkan "
                         "dropdown Akta KOSONG. Kalau app memaparkan akta, "
                         "mapping sudah basi — itu DAPATAN.")
            rel = os.path.join(akar_kk, dir_kod, s["set_id"] + ".yaml")
            fail[rel] = tulis_yaml(s)
            sets.append((rel, s))
            continue

        for a in aktas:
            dir_akta = f"AKT{slug(a['id'], 20)}-{slug(a['nama'])}"
            senarai = kes_ikut_akta.get(a["nama"], [])
            if not senarai:
                s = bina_set(kk, a, None, JANGKA_MATI_T3, tarikh,
                             "Akta ini tiada kesalahan dalam mapping. Set "
                             "NEGATIF: pilih kod + akta, sahkan dropdown "
                             "Kesalahan KOSONG.")
                rel = os.path.join(akar_kk, dir_kod, dir_akta,
                                   s["set_id"] + ".yaml")
                fail[rel] = tulis_yaml(s)
                sets.append((rel, s))
                continue

            ambigu = a["nama"] in nama_berulang
            for kes in senarai:
                if ambigu:
                    jangkaan = AMBIGU
                    nota = (f"Nama akta {a['nama']!r} berulang dalam mapping "
                            f"(id: {', '.join(nama_berulang[a['nama']])}). "
                            f"Kesalahan disambung ikut NAMA, jadi kedua-dua "
                            f"akta berkongsi senarai yang sama dan kita "
                            f"tidak boleh tahu yang mana betul. Rekod apa "
                            f"yang app sebenarnya papar.")
                else:
                    jangkaan = BOLEH_GUNA
                    nota = ""
                if not str(kes.get("kodKesalahan") or "").strip():
                    nota = (nota + " " if nota else "") + \
                        "Kesalahan ini TIADA kodKesalahan dalam mapping."
                s = bina_set(kk, a, kes, jangkaan, tarikh, nota)
                rel = os.path.join(akar_kk, dir_kod, dir_akta,
                                   s["set_id"] + ".yaml")
                fail[rel] = tulis_yaml(s)
                sets.append((rel, s))

    fail[os.path.join("INDEX.md")] = _index(sets, d, nama_berulang)
    return fail, sets


def _index(sets, d, nama_berulang):
    dalam = [s for _r, s in sets if s["dalam_skop"]]
    luar = [s for _r, s in sets if not s["dalam_skop"]]
    penuh = [s for _r, s in sets if s["jangkaan"] in (BOLEH_GUNA, AMBIGU)]

    def kira(pred, sumber=None):
        return sum(1 for _r, s in sets if pred(s)) if sumber is None else \
            sum(1 for s in sumber if pred(s))

    b = []
    b.append("# INDEX SET KOMBO — MBPG")
    b.append("")
    b.append("> Dijana oleh `tools/jana_set.py`. JANGAN EDIT DENGAN TANGAN.")
    b.append(f"> Snapshot mapping: **{d.get('tarikh', '?')}**")
    b.append(f"> Sumber snapshot: `{d.get('sumber', '?')}`")
    b.append(">")
    b.append("> **Sumber snapshot ialah STAGING; sasaran run ialah "
             "PRODUCTION (113.211.155.174).**")
    b.append("> Setiap nilai di sini adalah HIPOTESIS untuk disahkan pada "
             "device, bukan oracle.")
    b.append("> Kombo yang app benarkan tetapi tiada di sini — atau "
             "sebaliknya — ialah DAPATAN.")
    b.append("")
    b.append("## Kiraan")
    b.append("")
    b.append("| Ukuran | Bil |")
    b.append("|---|---|")
    b.append(f"| Set laluan-penuh (kod x akta x kesalahan) | **{len(penuh)}** |")
    b.append(f"|   ...dalam skop (PELBAGAI + LETAK KERETA) | "
             f"{sum(1 for s in penuh if s['dalam_skop'])} |")
    b.append(f"|   ...luar skop (LESEN) | "
             f"{sum(1 for s in penuh if not s['dalam_skop'])} |")
    b.append(f"| Set negatif JANGKA_KOSONG | "
             f"{kira(lambda s: s['jangkaan'] == JANGKA_KOSONG)} |")
    b.append(f"| Set negatif JANGKA_MATI_T3 | "
             f"{kira(lambda s: s['jangkaan'] == JANGKA_MATI_T3)} |")
    b.append(f"| **Jumlah fail set** | **{len(sets)}** |")
    b.append("")
    b.append("Pecahan laluan-penuh mengikut jenis:")
    b.append("")
    b.append("| Jenis | Borang | Bil |")
    b.append("|---|---|---|")
    for jenis in ("PELBAGAI", "LETAK KERETA", "LESEN"):
        n = sum(1 for s in penuh if s["kod_kompaun"]["jenis"] == jenis)
        b.append(f"| {jenis} | {'+'.join(BORANG_IKUT_JENIS.get(jenis, []))} "
                 f"| {n} |")
    b.append("")
    b.append("## Jangkaan")
    b.append("")
    b.append("| Jangkaan | Bil | Maksud |")
    b.append("|---|---|---|")
    for j, maksud in (
        (BOLEH_GUNA, "laluan penuh wujud — ketiga-tiga dropdown patut isi"),
        (AMBIGU, "nama akta berulang — senarai kesalahan dikongsi, "
                 "rekod apa yang app papar"),
        (JANGKA_KOSONG, "kod tiada akta — sahkan dropdown Akta KOSONG"),
        (JANGKA_MATI_T3, "akta tiada kesalahan — sahkan dropdown "
                         "Kesalahan KOSONG"),
    ):
        b.append(f"| `{j}` | {kira(lambda s, j=j: s['jangkaan'] == j)} "
                 f"| {maksud} |")
    b.append("")
    b.append("## Percanggahan dengan ringkasan arahan (data yang menang)")
    b.append("")
    kosong = sorted({s["kod_kompaun"]["kod"] for _r, s in sets
                     if s["jangkaan"] == JANGKA_KOSONG})
    mati = sorted((s["kod_kompaun"]["kod"], s["akta"]["id"])
                  for _r, s in sets if s["jangkaan"] == JANGKA_MATI_T3)
    b.append(f"- **Kod tanpa akta**: arahan menamakan 4 "
             f"(100, 1050, KA 12355, KA01); mapping mengandungi "
             f"**{len(kosong)}** — `{', '.join(kosong)}`.")
    b.append(f"- **Akta tanpa kesalahan**: arahan menamakan kod 06 sahaja; "
             f"mapping mengandungi **{len(mati)}** pasangan — "
             + ", ".join(f"`kod {k} / akta {a}`" for k, a in mati) + ".")
    b.append("")
    b.append("Generator mengira dari mapping, jadi kesemuanya dijana. "
             "Mengekodkan senarai pendek dalam arahan akan menyembunyikan "
             "yang selebihnya daripada sweep.")
    b.append("")
    b.append("## Nama akta berulang")
    b.append("")
    b.append("| Nama | id |")
    b.append("|---|---|")
    for n, ids in sorted(nama_berulang.items()):
        b.append(f"| `{n}` | {', '.join(ids)} |")
    b.append("")
    b.append("Kesalahan disambung kepada akta ikut **nama**, bukan id "
             "(itu bentuk mapping). Maka setiap set di bawah nama-nama ini "
             "ditanda `AMBIGU`.")
    b.append("")
    b.append("## Matriks set")
    b.append("")
    b.append("| set_id | skop | borang | kod | akta | kesalahan | jangkaan |")
    b.append("|---|---|---|---|---|---|---|")
    for _r, s in sorted(sets, key=lambda x: x[1]["set_id"]):
        a = s["akta"]["id"] if s["akta"] else "—"
        k = s["kesalahan"]["id"] if s["kesalahan"] else "—"
        ket = (s["kesalahan"]["keterangan"][:44] + "…") \
            if s["kesalahan"] and len(s["kesalahan"]["keterangan"]) > 45 \
            else (s["kesalahan"]["keterangan"] if s["kesalahan"] else "—")
        b.append(f"| `{s['set_id']}` | "
                 f"{'dalam' if s['dalam_skop'] else 'LUAR'} | "
                 f"{'+'.join(s['borang'])} | {s['kod_kompaun']['kod']} | "
                 f"{a} | {k} — {ket} | {s['jangkaan']} |")
    b.append("")
    return "\n".join(b) + "\n"


def _index_db(sets, d, tarikh):
    penuh = [s for _r, s in sets if s["jangkaan"] == BOLEH_GUNA]
    dalam = [s for s in penuh if s["dalam_skop"]]
    b = []
    b.append("# INDEX SET KOMBO — MBPG (sumber: DB PERANTI PRODUCTION)")
    b.append("")
    b.append(f"> Dijana oleh `tools/jana_set.py --sumber db`. JANGAN EDIT.")
    b.append(f"> Snapshot DB: `{d['laluan']}` (tarikh {tarikh})")
    b.append(">")
    b.append("> Ini sumber kebenaran untuk sweep. Snapshot mapping portal "
             "(staging) diarkib ke")
    b.append("> `testdata/sets-staging/` untuk rujukan silang SAHAJA — ia "
             "terbukti berbeza secara")
    b.append("> material daripada production. Lihat "
             "`BEZA-STAGING-VS-PRODUCTION.md`.")
    b.append("")
    b.append("## Kiraan")
    b.append("")
    b.append("| Ukuran | Bil |")
    b.append("|---|---|")
    b.append(f"| Set laluan-penuh | **{len(penuh)}** |")
    b.append(f"|   ...dalam skop (PELBAGAI + LETAK KERETA) | **{len(dalam)}** |")
    b.append(f"|   ...luar skop (LESEN) | {len(penuh) - len(dalam)} |")
    for j in (JANGKA_KOSONG, JANGKA_MATI_T3):
        b.append(f"| Set negatif `{j}` | "
                 f"{sum(1 for _r, s in sets if s['jangkaan'] == j)} |")
    b.append(f"| **Jumlah fail set** | **{len(sets)}** |")
    b.append("")
    b.append("| Jenis | Borang | Bil laluan-penuh |")
    b.append("|---|---|---|")
    for jenis in ("PELBAGAI", "LETAK KERETA", "LESEN"):
        n = sum(1 for s in penuh if s["kod_kompaun"]["jenis"] == jenis)
        b.append(f"| {jenis} | {'+'.join(BORANG_IKUT_JENIS.get(jenis, []))} "
                 f"| {n} |")
    b.append("")
    b.append("## Integriti data DB — dicatat, bukan disenyapkan")
    b.append("")
    b.append(f"- **{len(d['akta_hilang'])} rujukan akta tergantung**: "
             f"jadual pautan `local_ekpn_akta_kompaun` menyebut id akta "
             f"yang TIADA barisnya dalam `local_ekpn_akta`, jadi tiada "
             f"nama untuk dipilih pada dropdown tingkat 2. Kombinasi itu "
             f"TIDAK boleh dipandu dan oleh itu tiada fail set. "
             f"id: `{', '.join(d['akta_hilang'])}`")
    b.append(f"- **{len(d['kes_yatim'])} fk_akta yatim**: kesalahan "
             f"menuding akta yang tiada barisnya "
             f"(`{', '.join(d['kes_yatim']) or '-'}`). Kesalahan itu tidak "
             f"boleh dicapai melalui mana-mana laluan dropdown.")
    tidak_aktif = sum(1 for _r, s in sets if s["kesalahan"] and
                      s["kesalahan"]["keterangan"].upper()
                      .startswith("TIDAK AKTIF"))
    b.append(f"- **{tidak_aktif} kesalahan ditanda 'TIDAK AKTIF'** dalam "
             f"keterangannya. Ia mungkin tidak muncul pada dropdown; "
             f"setnya ditanda dalam `nota`.")
    b.append("")
    b.append("## Kadar denda")
    b.append("")
    b.append("Setiap set laluan-penuh membawa `denda:` dari DB "
             "(`amounnotis` / `amounmin` / `amounmax` / `amounmahkamah`).")
    b.append("")
    b.append("**`amounnotis` = 0 pada KESEMUA kesalahan** dalam snapshot "
             "ini. Jadi 'kadar denda notis' nampaknya tidak digunakan pada "
             "MBPG, dan `amounmin` yang bermakna. Nilai ini RUJUKAN — run "
             "merekod apa yang app papar dan tidak menegaskan kesamaan.")
    b.append("")
    b.append("## Matriks set")
    b.append("")
    b.append("| set_id | skop | borang | kod | akta | kesalahan | denda min |")
    b.append("|---|---|---|---|---|---|---|")
    for _r, s in sorted(sets, key=lambda x: x[1]["set_id"]):
        a = s["akta"]["id"] if s["akta"] else "—"
        k = s["kesalahan"]["id"] if s["kesalahan"] else "—"
        ket = (s["kesalahan"]["keterangan"][:40] + "…") \
            if s["kesalahan"] and len(s["kesalahan"]["keterangan"]) > 41 \
            else (s["kesalahan"]["keterangan"] if s["kesalahan"] else "—")
        dm = (s["denda"] or {}).get("min", "—")
        b.append(f"| `{s['set_id']}` | "
                 f"{'dalam' if s['dalam_skop'] else 'LUAR'} | "
                 f"{'+'.join(s['borang'])} | {s['kod_kompaun']['kod']} | "
                 f"{a} | {k} — {ket} | {dm} |")
    b.append("")
    return "\n".join(b) + "\n"


def jana_beza(laluan_db, laluan_mapping):
    """BEZA-STAGING-VS-PRODUCTION.md — apa yang wujud sebelah sana sahaja."""
    d = baca_db(laluan_db)
    with open(laluan_mapping, encoding="utf-8") as fh:
        m = json.load(fh)

    kod_db = {k["kod"]: k for k in d["kod"]}
    kod_map = {str(k["kod"]).strip(): k for k in m["kodKompaun"]}
    nama_akta_db = {a["nama"].strip().upper(): a for a in d["akta"].values()}
    nama_akta_map = {str(a["nama"]).strip().upper(): a for a in m["akta"]}
    kes_db = {k["keterangan"].strip().upper()
              for v in d["kesalahan"].values() for k in v}
    kes_map = {str(k["keterangan"]).strip().upper() for k in m["kesalahan"]}

    b = []
    b.append("# BEZA: mapping STAGING vs DB PRODUCTION — MBPG")
    b.append("")
    b.append("> Dijana oleh `tools/jana_set.py --beza`.")
    b.append(f"> Staging : `{m.get('sumber', '?')}` (snapshot "
             f"{m.get('tarikh', '?')})")
    b.append(f"> Production: `{d['laluan']}` (DB peranti, baca-sahaja)")
    b.append("")
    b.append("## Kenapa dokumen ini wujud")
    b.append("")
    b.append("Sistem set kombo mula-mula dibina daripada snapshot pemetaan "
             "portal. Snapshot itu diambil dari **epbtstaging.mbpg.gov.my**, "
             "sedangkan sasaran run ialah **production 113.211.155.174**. "
             "Perbezaannya bukan kecil, dan ia akan menyebabkan hampir "
             "setiap set gagal pada tingkat 1 — termasuk kerana teks yang "
             "dipaparkan berbeza, bukan sekadar kandungan.")
    b.append("")
    b.append("## Ringkasan")
    b.append("")
    b.append("| | Staging (mapping) | Production (DB peranti) |")
    b.append("|---|---|---|")
    b.append(f"| kod kompaun | {len(kod_map)} | **{len(kod_db)}** |")
    b.append(f"| akta | {len(m['akta'])} | **{len(d['akta'])}** |")
    b.append(f"| kesalahan | {len(m['kesalahan'])} | "
             f"**{sum(len(v) for v in d['kesalahan'].values())}** |")
    b.append("")
    b.append("## Kod kompaun")
    b.append("")
    b.append("### Hanya dalam STAGING (tiada pada production)")
    b.append("")
    hanya_map = sorted(set(kod_map) - set(kod_db))
    b.append("| kod | keterangan staging |")
    b.append("|---|---|")
    for k in hanya_map:
        b.append(f"| `{k}` | {kod_map[k].get('keterangan', '')} |")
    b.append("")
    b.append(f"**{len(hanya_map)} daripada {len(kod_map)}** kod dalam "
             "mapping tidak wujud pada production. Kebanyakannya kelihatan "
             "seperti data ujian portal (`T001`-`T007`, `KA01`, `100`, "
             "`1050`).")
    b.append("")
    b.append("### Hanya pada PRODUCTION (tiada dalam staging) — PENTING")
    b.append("")
    hanya_db = sorted(set(kod_db) - set(kod_map))
    b.append("| kod | keterangan production | jenis |")
    b.append("|---|---|---|")
    for k in hanya_db:
        b.append(f"| `{k}` | {kod_db[k]['keterangan']} | "
                 f"{kod_db[k]['jenis']} |")
    b.append("")
    b.append("Kod ini TIDAK PERNAH akan diuji kalau sweep dibina dari "
             "mapping sahaja.")
    b.append("")
    b.append("## Beza TEKS tingkat-1 (paling merosakkan)")
    b.append("")
    b.append("Sweep memilih tingkat 1 mengikut teks yang dipaparkan. Kalau "
             "teks berbeza, pemilihan gagal walaupun kod itu wujud pada "
             "kedua-dua belah.")
    b.append("")
    b.append("| kod | teks STAGING | teks PRODUCTION | sama? |")
    b.append("|---|---|---|---|")
    for k in sorted(set(kod_db) & set(kod_map)):
        a = str(kod_map[k].get("keterangan", "")).strip()
        bb = kod_db[k]["keterangan"].strip()
        b.append(f"| `{k}` | {a} | {bb} | {'ya' if a == bb else '**TIDAK**'} |")
    beza_teks = sum(1 for k in set(kod_db) & set(kod_map)
                    if str(kod_map[k].get("keterangan", "")).strip()
                    != kod_db[k]["keterangan"].strip())
    b.append("")
    b.append(f"**{beza_teks}** daripada {len(set(kod_db) & set(kod_map))} "
             f"kod yang dikongsi mempunyai teks paparan yang BERBEZA.")
    b.append("")
    b.append("## Akta")
    b.append("")
    hanya_akta_map = sorted(set(nama_akta_map) - set(nama_akta_db))
    hanya_akta_db = sorted(set(nama_akta_db) - set(nama_akta_map))
    b.append(f"- Hanya dalam staging: **{len(hanya_akta_map)}**")
    for n in hanya_akta_map[:40]:
        b.append(f"  - `{n}`")
    if len(hanya_akta_map) > 40:
        b.append(f"  - … dan {len(hanya_akta_map) - 40} lagi")
    b.append(f"- Hanya pada production: **{len(hanya_akta_db)}**")
    for n in hanya_akta_db[:40]:
        b.append(f"  - `{n}`")
    if len(hanya_akta_db) > 40:
        b.append(f"  - … dan {len(hanya_akta_db) - 40} lagi")
    b.append("")
    b.append("### Nama akta berulang")
    b.append("")
    dup_map = {n: c for n, c in
               (m.get("analisis", {}).get("akta_nama_duplikat") or {}).items()}
    b.append(f"- Staging: {dup_map or 'tiada'}")
    b.append("- Production: **tiada** — jadi kategori `AMBIGU` yang "
             "menandai 130 set staging LENYAP sepenuhnya apabila set "
             "dijana dari DB.")
    b.append("")
    b.append("## Kesalahan")
    b.append("")
    b.append(f"- Hanya dalam staging: **{len(kes_map - kes_db)}**")
    b.append(f"- Hanya pada production: **{len(kes_db - kes_map)}**")
    b.append(f"- Dikongsi: **{len(kes_db & kes_map)}**")
    b.append("")
    b.append("## Contoh PM (SEK 46(1)(d) / SEKSYEN 47 bawah PMTLK 2001)")
    b.append("")
    for pola in ("SEK 46", "SEK 47"):
        padan = sorted({(k["keterangan"][:60], aid)
                        for aid, v in d["kesalahan"].items() for k in v
                        if pola in (k["kodKesalahan"] or "").upper()})
        b.append(f"- `{pola}` pada production: {len(padan)} kesalahan, "
                 f"di bawah akta id "
                 f"{sorted({a for _k, a in padan}) or '-'}")
    b.append("")
    b.append("Kalau app membenarkan kombinasi yang tiada di sebelah "
             "production, itu DAPATAN dan mesti direkod dalam MATRIX.")
    b.append("")
    return "\n".join(b) + "\n"


def _sedia_ada(dir_set):
    keluar = {}
    for root, _dirs, files in os.walk(dir_set):
        for f in files:
            # .md turut dikira: INDEX.md DAN
            # BEZA-STAGING-VS-PRODUCTION.md kedua-duanya output generator.
            # Menapis kepada INDEX.md sahaja menyebabkan `--semak`
            # melaporkan laporan beza sebagai HILANG pada setiap larian.
            if f.endswith(".yaml") or f.endswith(".md"):
                p = os.path.join(root, f)
                rel = os.path.relpath(p, dir_set)
                with open(p, encoding="utf-8") as fh:
                    keluar[rel] = fh.read()
    return keluar


def _bersih_stale(dir_set, dijana):
    """Padam fail set yang tidak lagi dijana.

    Tanpa ini, snapshot baharu meninggalkan set HANTU: fail yang masih
    dikutip oleh sweep, masih dilaporkan, dan masih kelihatan lulus —
    sedangkan kombinasinya sudah tiada dalam mapping."""
    dipadam = []
    for root, _dirs, files in os.walk(dir_set):
        for f in files:
            rel = os.path.relpath(os.path.join(root, f), dir_set)
            if rel not in dijana:
                os.remove(os.path.join(root, f))
                dipadam.append(rel)
    # Buang folder yang jadi kosong.
    for root, dirs, files in os.walk(dir_set, topdown=False):
        if root != dir_set and not os.listdir(root):
            os.rmdir(root)
    return dipadam


def main(argv=None):
    ap = argparse.ArgumentParser(description="Jana set kombo MBPG.")
    ap.add_argument("--sumber", choices=("db", "mapping"), default="db",
                    help="db = DB peranti production (LALAI, sumber "
                         "kebenaran). mapping = snapshot portal staging "
                         "(rujukan silang sahaja).")
    ap.add_argument("--db", default=None,
                    help="Laluan e_kompaunV1.db; lalai = snapshot terkini.")
    ap.add_argument("--mapping", default=MAPPING_LALAI)
    ap.add_argument("--keluar", default=DIR_SET)
    ap.add_argument("--semak", action="store_true",
                    help="Jangan tulis; gagal (exit 1) kalau output akan "
                         "berubah. Untuk CI / ujian idempoten.")
    ap.add_argument("--beza", action="store_true",
                    help="Jana BEZA-STAGING-VS-PRODUCTION.md sahaja.")
    a = ap.parse_args(argv)

    if a.sumber == "db":
        laluan_db = a.db or _db_terkini()
        if not laluan_db or not os.path.isfile(laluan_db):
            print("TIADA snapshot DB. Tarik dahulu (baca-sahaja):\n"
                  "  adb -s <serial> exec-out run-as "
                  "com.anonymous.react_ies_v1 cat \\\n"
                  "    /data/data/com.anonymous.react_ies_v1/files/SQLite/"
                  "e_kompaunV1.db \\\n"
                  "    > data/snapshot-YYYYMMDD/e_kompaunV1.db")
            return 1
        if a.beza:
            teks = jana_beza(laluan_db, a.mapping)
            p = os.path.join(a.keluar, "BEZA-STAGING-VS-PRODUCTION.md")
            os.makedirs(a.keluar, exist_ok=True)
            with open(p, "w", encoding="utf-8", newline="\n") as fh:
                fh.write(teks)
            print(f"  Ditulis: {p}")
            return 0
        fail, sets = jana_dari_db(laluan_db, a.keluar)
    else:
        fail, sets = jana(a.mapping, a.keluar)

    if a.semak:
        semasa = _sedia_ada(a.keluar)
        beza = ([f"HILANG   {k}" for k in sorted(set(fail) - set(semasa))]
                + [f"LEBIHAN  {k}" for k in sorted(set(semasa) - set(fail))]
                + [f"BERUBAH  {k}" for k in sorted(set(fail) & set(semasa))
                   if fail[k] != semasa[k]])
        if beza:
            print(f"TIDAK SEPADAN — {len(beza)} perbezaan:")
            for x in beza[:25]:
                print("  " + x)
            if len(beza) > 25:
                print(f"  ... dan {len(beza) - 25} lagi")
            return 1
        print(f"SEPADAN — {len(fail)} fail, output tidak akan berubah.")
        return 0

    for rel, isi in fail.items():
        p = os.path.join(a.keluar, rel)
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p, "w", encoding="utf-8", newline="\n") as fh:
            fh.write(isi)
    dipadam = _bersih_stale(a.keluar, set(fail))

    penuh = [s for _r, s in sets if s["jangkaan"] in (BOLEH_GUNA, AMBIGU)]
    print(f"  Ditulis         : {len(fail)} fail ({len(sets)} set + INDEX.md)")
    print(f"  Laluan penuh    : {len(penuh)}")
    print(f"    dalam skop    : {sum(1 for s in penuh if s['dalam_skop'])}")
    print(f"    luar skop     : {sum(1 for s in penuh if not s['dalam_skop'])}")
    for j in (BOLEH_GUNA, AMBIGU, JANGKA_KOSONG, JANGKA_MATI_T3):
        print(f"  {j:16}: {sum(1 for _r, s in sets if s['jangkaan'] == j)}")
    if dipadam:
        print(f"  Stale dipadam   : {len(dipadam)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())

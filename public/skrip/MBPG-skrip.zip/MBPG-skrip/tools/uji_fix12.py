"""UJI FIX#12 — sahkan pagar `pastikan_di_home` sebelum kad grid.

TIDAK mencipta rekod production. TIDAK menekan CETAK/HANTAR/SERAH.
Hanya navigasi + baca. Selamat dijalankan pada peranti sebenar.

Cara ia membuktikan pembetulan:
  1. Bawa app ke skrin UTAMA  -> kad SENARAI mesti dijumpai.
  2. Bawa app ke skrin LAIN (Senarai/Hantar buka) -- keadaan yang
     menyebabkan kegagalan Khamis.
  3. Tanpa pagar: ketuk kad SENARAI mesti GAGAL (itu bug asal).
  4. Dengan pagar: pastikan_di_home() pulangkan app ke utama, kemudian
     kad SENARAI mesti BERJAYA.

Kalau langkah 4 berjaya, pembetulan berfungsi.

Guna: python tools/uji_fix12.py
"""
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

os.environ.setdefault("MBPG_MOD_SEBENAR", "1")
os.environ.setdefault("MBPG_IZIN_PRODUCTION", "1")
os.environ.setdefault("MBPG_DRY_RUN", "1")

from pages.home_page import HomePage                      # noqa: E402
from devtools import peringkat6 as P6                     # noqa: E402
from devtools.smoke_tangga import pastikan_di_home        # noqa: E402


def main():
    from tests.conftest import create_driver, Pages

    print("=" * 72)
    print("UJI FIX#12 — pagar pastikan_di_home sebelum kad grid")
    print("TIDAK mencipta rekod. Navigasi + baca sahaja.")
    print("=" * 72)

    drv = create_driver()
    pages = Pages(drv)
    hasil = {}

    try:
        # ---------- 1. keadaan BAIK: app di skrin utama ----------
        print("\n[1] relaunch -> skrin utama")
        P6.relaunch(drv, pages, "uji fix12: mula bersih")
        ok_home = pastikan_di_home(drv, pages)
        hasil["1_di_home"] = ok_home
        print(f"    pastikan_di_home -> {ok_home}")

        n_kad = drv.find_elements(
            "android uiautomator",
            'new UiSelector().descriptionMatches("(?i)\\\\s*SENARAI\\\\s*")')
        hasil["1_kad_senarai_ada"] = len(n_kad) > 0
        print(f"    kad SENARAI pada skrin utama: {len(n_kad)}")

        # ---------- 2. bawa app ke skrin LAIN ----------
        print("\n[2] buka Senarai -> app kini di skrin BUKAN-utama")
        pages.home.open_senarai()
        time.sleep(3)
        di_home = pages.home.is_home_screen_displayed()
        hasil["2_di_home_selepas_buka"] = di_home
        print(f"    is_home_screen_displayed -> {di_home}  (jangkaan False)")

        # ---------- 3. tanpa pagar: ketuk kad mesti GAGAL ----------
        print("\n[3] TANPA pagar: cuba ketuk kad SENARAI dari skrin salah")
        try:
            pages.home.wait_and_click(pages.home.MODULE_SENARAI, timeout=15)
            hasil["3_ketuk_tanpa_pagar"] = "BERJAYA (tak dijangka)"
            print("    -> BERJAYA (pelik — skrin mungkin balik sendiri)")
        except Exception as e:
            hasil["3_ketuk_tanpa_pagar"] = f"GAGAL: {type(e).__name__}"
            print(f"    -> GAGAL seperti dijangka: {type(e).__name__}")
            print(f"       (inilah ralat Khamis: {str(e).splitlines()[0][:80]})")

        print("\n[4] DENGAN pagar: pastikan_di_home -> baru ketuk")
        ok = pastikan_di_home(drv, pages)
        hasil["4_pagar"] = ok
        print(f"    pastikan_di_home -> {ok}")
        if ok:
            try:
                pages.home.open_senarai()
                time.sleep(3)
                hasil["4_ketuk_dengan_pagar"] = "BERJAYA"
                print("    -> kad SENARAI BERJAYA diketuk")
            except Exception as e:
                hasil["4_ketuk_dengan_pagar"] = f"GAGAL: {type(e).__name__}"
                print(f"    -> masih gagal: {type(e).__name__}")
        else:
            hasil["4_ketuk_dengan_pagar"] = "dilangkau (tiada home)"

    finally:
        print("\n" + "=" * 72)
        print("RINGKASAN")
        for k, v in hasil.items():
            print(f"  {k:26s} = {v}")

        lulus = (hasil.get("3_ketuk_tanpa_pagar", "").startswith("GAGAL")
                 and hasil.get("4_ketuk_dengan_pagar") == "BERJAYA")
        print("\nVERDIK:", "FIX#12 BERFUNGSI" if lulus
              else "perlu semak manual (lihat ringkasan)")
        try:
            drv.quit()
        except Exception as e:                                # noqa: BLE001
            print(f"  drv.quit: {type(e).__name__}")


if __name__ == "__main__":
    main()

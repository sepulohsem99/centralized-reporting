"""
RUNNER E2E KENDIRI — cipta -> serah -> cetak, satu command.

    python tools/run_e2e.py --borang K --kuota 1
    python tools/run_e2e.py --borang N --set SET-KK01-AKT049-048
    python tools/run_e2e.py --borang NPK --kuota 3     # satu setiap borang

Kebenaran diuruskan oleh PEMILIK melalui IZIN-E2E.txt di root repo,
bukan melalui sesi chat. Runner enggan berjalan kalau fail itu tiada,
luput, atau kuotanya 0 — dan setiap rekod yang BERJAYA menolak kuota
dalam fail itu, jadi gerbang menutup dirinya sendiri.

KESELAMATAN YANG TIDAK BOLEH DIBUANG
  - ringkasan + taip YA sekali sebelum mula (--terus untuk langkau)
  - corong guard penuh: trip-wire, ledger, post-check 15 jadual
  - jaring PII sebelum setiap serah
  - cetak SATU tekan, tiada cuba-semula
  - gagal separuh jalan = BERHENTI, borang seterusnya tidak dicuba
"""

import argparse
import os
import sys
import time
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
AKAR = os.path.dirname(HERE)
sys.path.insert(0, AKAR)

from tools.izin_e2e import IzinE2E, IzinTidakSah                # noqa: E402
from tools import rekod_log                                     # noqa: E402
from testdata import penanda_ujian as PU                        # noqa: E402

# Saat untuk Ctrl-C bila --terus melangkau pengesahan.
JEDA_TERUS = int(os.environ.get("MBPG_JEDA_TERUS", "5"))

E2E_JSONL = os.path.join(AKAR, "reports", "E2E.jsonl")
DOK = os.path.join(AKAR, "docs", "FASA-C-REKOD.md")

SPEC = {
    "N": {"tag": "N-001", "set_id": "C1-N-001", "borang": "Notis Amaran",
          "jadual": "local_ekpn_notis_amaran", "jenis": "Notis"},
    "P": {"tag": "P-001", "set_id": "C2-P-001",
          "borang": "Kompaun Pelbagai",
          "jadual": "local_ekpn_tawaran_kompaun", "jenis": "Kompaun"},
    "K": {"tag": "K-001", "set_id": "C3-K-001",
          "borang": "Kompaun Letak Kereta",
          "jadual": "local_ekpn_tawaran_kompaun", "jenis": "Kompaun"},
}

# ---------------------------------------------------------------------------
# Peringkat kitaran penuh — arahan pemilik 2026-08-17, bahagian 3.5
# ---------------------------------------------------------------------------
# Urutan yang pemilik CADANGKAN, bukan yang app dijamin benarkan. Arahan
# 3.5 menyatakannya secara terang: "Kalau app tak benarkan urutan ni ...
# ikut apa app benarkan sebenar dan CATAT urutan sebenar dalam report."
#
# Maka setiap peringkat merekod hasilnya SENDIRI ke dalam `jejak`, dan
# jejak itu dicetak sepenuhnya pada akhir larian sama ada ia lulus atau
# tidak. Peringkat yang app tolak menjadi DAPATAN yang berbukti, bukan
# kegagalan skrip yang perlu diteka puncanya.
#
# Peringkat yang page objectnya diport dari MBJB dan BELUM disahkan pada
# MBPG ditanda di sini, supaya laporan tidak mendakwa lebih daripada
# yang dibuktikan.
PERINGKAT_KITARAN = [
    ("cipta",    "3.5(1) isi + SERAH sebenar + verify rekod",  "disahkan"),
    ("cetak",    "3.5(2) CETAK rekod baharu",                  "disahkan"),
    ("kemaskini", "3.5(3) KEMASKINI -> nombor baharu",         "port-MBJB"),
    ("tn_nk",    "3.5(4) Tarik Notis / Notis-ke-Kompaun (N)",  "port-MBJB"),
    ("hantar",   "3.5(5) Hantar akhir -> status H/M",          "port-MBJB"),
    ("senarai",  "3.5(6) SK-001 verify rekod kelihatan",       "port-MBJB"),
    ("p006",     "3.5(7) isu tandatangan pada cetakan",        "manual"),
]


def urai_borang(teks):
    """'K' -> ['K'];  'NPK' -> ['N','P','K'].

    Urutan dikekalkan seperti ditaip: pemilik yang menentukan susunan,
    bukan kami.
    """
    huruf = [c for c in teks.upper()]
    tidak_sah = [c for c in huruf if c not in SPEC]
    if tidak_sah:
        raise SystemExit(f"borang tidak sah: {''.join(tidak_sah)} "
                         f"(sah: N, P, K, atau gabungan seperti NPK)")
    keluar = []
    for c in huruf:                       # buang pendua, kekal urutan
        if c not in keluar:
            keluar.append(c)
    return keluar


def sah_set(set_id):
    """Set mesti WUJUD. --set yang salah taip bermakna rekod dicipta
    dengan kombinasi yang bukan yang pemilik maksudkan."""
    if not set_id:
        return True, ""
    try:
        from testdata.sets_loader import muat_semua
    except Exception:                                           # noqa: BLE001
        return False, ("--set diberi tetapi testdata.sets_loader tidak "
                       "boleh dimuatkan; tidak dapat mengesahkan set "
                       "wujud, jadi runner enggan meneka")
    try:
        semua = muat_semua()
    except Exception as e:                                      # noqa: BLE001
        return False, f"senarai set tidak boleh dibaca: {e}"
    ada = {s.get("set_id") for s in semua if isinstance(s, dict)}
    if set_id in ada:
        return True, ""
    return False, (f"set {set_id!r} TIDAK WUJUD dalam {len(ada)} set "
                   f"yang dimuatkan")


def tulis_jsonl(entri):
    import json
    os.makedirs(os.path.dirname(E2E_JSONL), exist_ok=True)
    with open(E2E_JSONL, "a", encoding="utf-8") as fh:
        fh.write(json.dumps(entri, ensure_ascii=False) + "\n")
        fh.flush()
        os.fsync(fh.fileno())


def tulis_dok(baris):
    if not os.path.exists(DOK):
        os.makedirs(os.path.dirname(DOK), exist_ok=True)
        with open(DOK, "w", encoding="utf-8", newline="\n") as fh:
            fh.write("# Rekod production sebenar yang dicipta\n\n"
                     "| Jenis | No. rekod | No. siri | Masa | Pesalah "
                     "| Cetak |\n|---|---|---|---|---|---|\n")
    with open(DOK, "a", encoding="utf-8") as fh:
        fh.write(baris + "\n")
        fh.flush()
        os.fsync(fh.fileno())


def minta_ya(ringkasan, terus):
    print("\n" + "=" * 70)
    print("== AKAN MENCIPTA REKOD PRODUCTION SEBENAR")
    print("=" * 70)
    for k, v in ringkasan.items():
        print(f"  {k:<16} : {v}")
    if terus:
        # >>> JEDA BATAL. <<< --terus melangkau pengesahan atas
        # permintaan pemilik, tetapi ia menjadikan satu command yang
        # tersilap taip cukup untuk mencipta rekod penguatkuasaan
        # sebenar. Semasa pembangunan runner ini, satu larian `--terus`
        # yang tidak disengajakan hanya terselamat kerana paip ditutup
        # dan proses mati -- itu nasib, bukan reka bentuk.
        #
        # Lima saat tidak menjejaskan larian yang disengajakan dan
        # cukup untuk Ctrl-C yang tidak.
        print(f"\n  --terus diberi: pengesahan dilangkau.")
        print(f"  {JEDA_TERUS}s untuk Ctrl-C sebelum rekod SEBENAR "
              f"dicipta...")
        try:
            for baki in range(JEDA_TERUS, 0, -1):
                print(f"    {baki}...", end="\r", flush=True)
                time.sleep(1)
        except KeyboardInterrupt:
            print("\n  dibatalkan oleh pengguna.")
            return False
        print("  meneruskan.        ")
        return True
    if not sys.stdin.isatty():
        print("\nHENTI: tiada terminal untuk mengesahkan. Gunakan "
              "--terus kalau anda memang berniat menjalankannya tanpa "
              "pengesahan.")
        return False
    jwp = input("\n  Taip YA untuk teruskan: ").strip()
    if jwp != "YA":
        print(f"  jawapan {jwp!r} bukan 'YA' — dibatalkan.")
        return False
    return True


DIR_SHOT = os.path.join(AKAR, "reports", "e2e-screenshots")


def tangkap_skrin(drv, tag, label):
    """Screenshot bukti untuk satu peringkat.

    Pemilik meminta screenshot secara eksplisit dalam arahan larian.
    Ia BEST-EFFORT: kegagalan menangkap skrin tidak boleh membatalkan
    kitaran yang sudah mencipta rekod sebenar — bukti yang hilang lebih
    baik daripada rekod yang tergantung separuh jalan.

    Nama fail membawa cap masa supaya larian berulang tidak menimpa
    bukti larian sebelumnya.
    """
    try:
        os.makedirs(DIR_SHOT, exist_ok=True)
        nama = (f"{tag}-{label}-"
                f"{time.strftime('%Y%m%d-%H%M%S')}.png")
        laluan = os.path.join(DIR_SHOT, nama)
        drv.get_screenshot_as_file(laluan)
        print(f"  [SHOT] {os.path.relpath(laluan, AKAR)}")
        return laluan
    except Exception as e:                                      # noqa: BLE001
        print(f"  [SHOT] gagal ({type(e).__name__}) — diteruskan")
        return None


def redact(nilai):
    """Bentuk nilai, bukan nilainya.

    PII hasil lookup mySIKAP TIDAK boleh ditulis ke dalam repo: gerbang
    `devtools/imbas_pii.py` menyekat commit yang membawanya, dan ia
    betul melakukannya. Log merekod BENTUK — cukup untuk membuktikan
    medan itu terisi dan dari mana ia datang, tanpa memasukkan nama
    atau nombor KP sesiapa ke dalam sejarah git.

    Kaedah sama seperti yang LEDGER-E2E.jsonl sudah gunakan pada
    2026-08-12.
    """
    t = (nilai or "").strip()
    if not t:
        return "<kosong>"
    if t.isdigit():
        return f"<{len(t)} digit>"
    return f"<teks {len(t)} aksara>"


def isi_pesalah_k_mysikap(p, drv, data, tag):
    """Tab Pesalah borang K DENGAN lookup mySIKAP dicetuskan.

    >>> KEPUTUSAN PEMILIK 2026-08-17 (Prompt 8 #3). <<<
    mySIKAP MESTI ditekan semasa cipta, bukan diasingkan sebagai ujian
    baca-sahaja. Akibatnya diterima secara sedar oleh pemilik: lookup
    mengisi Nama Pesalah dan No. K/P daripada pangkalan data kerajaan,
    jadi rekod production yang terhasil membawa **PII warga SEBENAR**
    dan bukan penanda ujian.

    Fungsi ini memisahkan dua sumber itu supaya log boleh menyatakannya:

        DARI LOOKUP  medan yang berubah antara snapshot sebelum/selepas
        DITAIP       medan yang kita hantar sendiri (penanda ujian)

    Urutan mengikut D-05: **No. Kereta DAHULU**. Menaip plat mencerminkan
    nilainya ke medan identiti, jadi mengisi Nama/IC dahulu bermakna
    langkah plat menimpanya — itu yang berlaku pada `PGP02K260813002`.

    Perbandingan mesti SEBELUM-lawan-SELEPAS dan bukan "medan tidak lagi
    kosong": pencerminan plat sudah mengisi ketiga-tiga medan identiti
    sebelum lookup bermula (docs/recon/DAPATAN-MYSIKAP.md §4).
    """
    import time as _t
    from devtools import peringkat6 as P6

    print("\n  [K] tab Pesalah — mySIKAP AKAN dicetuskan (arahan pemilik)")

    plat = data.get("no_kereta")
    if not plat:
        raise IzinTidakSah(f"{tag}: data K tiada `no_kereta`; lookup "
                           f"mySIKAP mustahil tanpa plat.")
    print(f"    No. Kereta = {plat!r} (ditaip DAHULU — D-05)")
    P6._isi_medan_tepat(p, "No. Kereta", str(plat))
    try:
        drv.hide_keyboard()
        _t.sleep(0.5)
    except Exception:                                           # noqa: BLE001
        pass

    sebelum = P6._snapshot_medan(p)

    titik = p.cari_mysikap()
    if titik is None:
        raise IzinTidakSah(
            f"{tag}: butang mySIKAP tidak dapat dikenal pasti secara "
            f"struktur (sauh ePBT). TIADA tekaan dibuat — kawalan "
            f"bersebelahan ialah ePBT, yang MEMADAM data borang.")
    print(f"    mySIKAP @ {titik} (disauh pada ePBT)")
    drv.tap([titik])

    tamat = _t.monotonic() + 30
    berubah = {}
    while _t.monotonic() < tamat:
        _t.sleep(1)
        selepas = P6._snapshot_medan(p)
        berubah = {i: v for i, v in selepas.items()
                   if sebelum.get(i) != v}
        if len(berubah) >= 2:
            break

    if not berubah:
        raise IzinTidakSah(
            f"{tag}: lookup mySIKAP tidak mengisi apa-apa dalam 30s. "
            f"Rekod TIDAK diserah — borang separuh siap lebih baik "
            f"daripada rekod production dengan identiti yang salah.")

    dari_lookup = {i: v for i, v in berubah.items()}
    print(f"    lookup mengisi {len(dari_lookup)} medan "
          f"(PII SEBENAR — diredact dalam log):")
    for i in sorted(dari_lookup):
        print(f"       [{i}] {redact(sebelum.get(i))} -> "
              f"{redact(dari_lookup[i])}")

    # Medan yang lookup TIDAK isi, kita taip sendiri dengan penanda.
    #
    # >>> EMPAT MEDAN SENGAJA TIDAK DISENTUH SELEPAS LOOKUP. <<<
    # docs/recon/DAPATAN-MYSIKAP.md §7 merekod satu soalan yang BELUM
    # dijawab: selepas lookup, medan berlabel Jenis Kereta / Warna
    # Kereta / No. Petak / No. Kupon memegang komponen ALAMAT (baris
    # alamat, poskod, bandar). Dua tafsiran muat pada bukti — lookup
    # menulis ke medan yang salah (defek), atau app menukar set medan
    # sebaik identiti diketahui (betul).
    #
    # Selagi itu tidak dipisahkan, menaip nilai kenderaan ke dalamnya
    # boleh MENIMPA alamat yang lookup baru tulis — pada rekod
    # production yang akan diserah. Kos tidak mengisinya adalah sifar:
    # keempat-empatnya OPSYENAL (data oracle membawa '-'), dan laluan
    # trafik asal juga meninggalkannya kosong.
    #
    # Ini KEHILANGAN LIPUTAN yang disengajakan, bukan terlepas pandang.
    SELEPAS_LOOKUP_JANGAN_SENTUH = ("jenis_kereta", "warna_kereta",
                                    "no_petak", "no_kupon")
    ditaip, dilangkau = [], []
    for label, kunci in getattr(p, "MEDAN_PESALAH_LETAK_KERETA", []):
        if kunci in ("no_kereta", "nama_pesalah", "no_kp_ssm_kereta"):
            continue                    # plat sudah; identiti dari lookup
        if kunci in SELEPAS_LOOKUP_JANGAN_SENTUH:
            dilangkau.append(label)
            continue
        nilai = data.get(kunci)
        if nilai is None or str(nilai).strip() == "":
            continue
        try:
            P6._isi_medan_tepat(p, label, str(nilai))
            ditaip.append(label)
            print(f"    {label:<18} = {str(nilai)[:32]!r} (ditaip)")
        except Exception as e:                                  # noqa: BLE001
            print(f"    {label:<18} — tidak dijumpai ({type(e).__name__})")
    if dilangkau:
        print(f"    DILANGKAU selepas lookup (DAPATAN-MYSIKAP §7, "
              f"medan opsyenal): {', '.join(dilangkau)}")

    return {"dari_lookup": dari_lookup, "ditaip": ditaip,
            "dilangkau": dilangkau}


def sahkan_konteks_mutasi(drv, tag, wajib=True, tempoh=20):
    """Sahkan corong akan MENGENALI skrin ini sebagai konteks mutasi.

    >>> KENAPA INI DIPANGGIL SEBAIK BORANG TERBUKA. <<<
    Tanpa semakan ini, tajuk app-bar yang tidak dikenali menghasilkan
    kegagalan pada titik TERBURUK yang mungkin: selepas borang diisi
    penuh, selepas gambar diambil, dan — mengikut D-07 — selepas nombor
    siri rasmi sudah DIBAKAR. Corong menyekat SERAH, run berhenti, dan
    yang tinggal ialah satu baris yatim dalam jadual details serta satu
    jurang dalam penomboran rasmi.

    Sauh `Notis Amaran` ialah satu-satunya konteks borang yang belum
    disahkan pada dump MBPG (ia datang dari objek halaman, sumber MBJB).
    Jadi ia diperiksa dalam beberapa saat pertama, bukan beberapa minit
    kemudian.

    Mesej kegagalan membawa tajuk app-bar yang BENAR-BENAR dibaca,
    supaya pembetulannya ialah satu baris dalam KONTEKS_MOD_SEBENAR dan
    bukan satu penyiasatan.
    """
    from guard import dasar

    if not getattr(drv.corong.tetapan, "mod_sebenar", False):
        return None

    # >>> MENUNGGU, BUKAN MEMBACA SEKALI. <<<
    # Larian 2026-08-17 13:13 berhenti di sini dengan tajuk
    # `'Kompaun e-PBT'` — iaitu app-bar SKRIN UTAMA, bukan borang.
    # Puncanya bukan senarai konteks yang salah: `open_notis_amaran()`
    # hanya MENGETUK dan terus pulang, tanpa mengesahkan skrin sudah
    # bertukar (bandingkan `select_jenis_kompaun_letak_kereta()`, yang
    # menunggu TRAFIK_SCREEN_TITLE). Bacaan sekali menangkap pokok view
    # sebelum navigasi React Native selesai.
    #
    # Peralihan RN adalah tak segerak pada SETIAP skrin, jadi
    # pembetulannya bukan `sleep` pada satu tapak panggilan — ia
    # menunggu di sini, di mana semakan itu sendiri berada.
    tajuk_dilihat = []
    tamat = time.monotonic() + tempoh
    while True:
        src = drv.page_source
        k = dasar.konteks_mod_sebenar(src)
        if k:
            print(f"  [KONTEKS] {tag}: skrin dikenali sebagai {k!r} — "
                  f"mutasi akan dibenarkan di sini")
            return k
        t = dasar.tajuk_appbar(src)
        if t and (not tajuk_dilihat or tajuk_dilihat[-1] != t):
            tajuk_dilihat.append(t)
        if time.monotonic() >= tamat:
            break
        time.sleep(1)

    # Jujukan tajuk yang dilihat membezakan DUA kegagalan yang berbeza:
    #   ['Kompaun e-PBT']              -> navigasi tidak pernah berlaku
    #   ['Kompaun e-PBT', '<lain>']    -> skrin bertukar, tajuknya belum
    #                                     ada dalam senarai konteks
    # Tanpa jujukan itu, kedua-duanya kelihatan sama dan pembetulannya
    # berbeza sepenuhnya.
    mesej = (
        f"{tag}: MOD SEBENAR hidup tetapi tiada konteks mutasi dikenali "
        f"dalam {tempoh}s.\n"
        f"  Jujukan tajuk app-bar : {tajuk_dilihat or ['(tiada)']}\n"
        f"  Dibenarkan            : "
        f"{[n for n, _ in dasar.KONTEKS_MOD_SEBENAR]}\n"
        f"  Corong akan menyekat SERAH kemudian. Berhenti SEKARANG, "
        f"sebelum borang diisi dan sebelum nombor siri dibakar (D-07).\n"
        f"  Kalau jujukan hanya ['Kompaun e-PBT'], skrin TIDAK PERNAH "
        f"bertukar — itu masalah navigasi, bukan senarai konteks.\n"
        f"  Kalau tajuk terakhir ialah nama borang yang sah, tambah ia "
        f"ke KONTEKS_MOD_SEBENAR dalam guard/dasar.py dengan dump "
        f"sebagai bukti.")
    if wajib:
        raise IzinTidakSah(mesej)
    print(f"  [KONTEKS] AMARAN — {mesej}")
    return None


def peringkat_bookmark_inline(huruf, s, pages, data, catat_peringkat):
    """N/P/K-005 — bookmark (Pilihan Kegemaran), DIWAYARKAN 2026-08-19.

    Dipanggil pada titik semula jadi aliran -005: borang terisi
    (seksyen kompaun lengkap), SEBELUM gambar diambil. Ikon buku U+E866
    berada di atas tab — `open_bookmark_popup()` menguruskan skrol.

    TIDAK fatal: bookmark ialah ciri sampingan; kegagalannya TIDAK
    boleh mematikan penciptaan rekod yang bernilai 5-10 minit. Pada
    kegagalan, popup ditutup paksa dan aliran cipta diteruskan.
    """
    # >>> KEPUTUSAN CEO 2026-08-19: MBPG build 2.1.23 DISAHKAN tiada
    # UI simpan bookmark (dua larian, dump bookmark_name_field_missing
    # .xml — popup PILIHAN KEGEMARAN senarai sahaja, tiada medan nama).
    # Jangan bazir ~5 minit setiap larian menguji semula fakta yang
    # sama: catat TIDAK-DISOKONG serta-merta. Untuk menguji semula pada
    # build BARU: set MBPG_CUBA_BOOKMARK=1.
    if os.environ.get("MBPG_CUBA_BOOKMARK") != "1":
        catat_peringkat(f"bookmark {huruf}-005", "TIDAK-DISOKONG",
                        "had build 2.1.23 disahkan (popup tiada medan "
                        "nama/SIMPAN); set MBPG_CUBA_BOOKMARK=1 untuk "
                        "cuba semula pada build baharu")
        return

    # Sekali TIDAK-DISOKONG, kekal TIDAK-DISOKONG untuk borang lain
    # dalam larian sama — build tidak berubah tengah larian, dan
    # percubaan pertama sudah menelan ~5 minit (larian 15:06: 329s).
    if getattr(peringkat_bookmark_inline, "_tidak_disokong", False):
        catat_peringkat(f"bookmark {huruf}-005", "TIDAK-DISOKONG",
                        "had build dikesan pada borang terdahulu larian "
                        "ini — tidak dicuba lagi")
        return

    tag_bm = f"E2E {s['tag']} {time.strftime('%H%M%S')}"
    bm = pages.bookmark

    def _modal_masih_ada():
        try:
            return bool(bm._find_all_by_resource_id(bm.MODAL_SURFACE_ID))
        except Exception:                                       # noqa: BLE001
            return False

    def _tutup_paksa():
        """>>> DIBAIKI 2026-08-19 — larian 15:06. <<<
        Penutupan lama (satu ketukan backdrop + satu BACK) meninggalkan
        modal-surface TERBUKA; peringkat kamera selepasnya tersekat
        ('disekat oleh modal (modal-surface) terbuka') dan borang N
        mati. Kini: gelung tutup + SAHKAN modal benar-benar hilang."""
        import time as _t
        for _ in range(5):
            if not _modal_masih_ada():
                return True
            try:
                if bm._tutup_modal_rn_melalui_backdrop():
                    _t.sleep(0.8)
                    continue
            except Exception:                                   # noqa: BLE001
                pass
            try:
                bm.press_back()
            except Exception:                                   # noqa: BLE001
                pass
            _t.sleep(0.8)
        return not _modal_masih_ada()

    try:
        bm.open_bookmark_popup()
        bm.save_bookmark(tag_bm)
        bm.select_bookmark(tag_bm)
        # Sahkan medan terisi semula dengan SATU nilai stabil yang kita
        # memang taip — cukup untuk membuktikan auto-populate tanpa
        # bergantung pada bentuk borang setiap jenis.
        calon = [data.get("kompaun_jalan"), data.get("lokasi_kesalahan"),
                 data.get("jalan"), data.get("nama_pesalah")]
        nilai = next((c for c in calon if c), None)
        if nilai:
            bm.verify_fields_repopulated([str(nilai)[:25]])
        catat_peringkat(f"bookmark {huruf}-005", "LULUS",
                        f"simpan+pilih '{tag_bm}'"
                        + (f", medan {str(nilai)[:25]!r} terisi semula"
                           if nilai else ""))
    except BaseException as e:                                  # noqa: BLE001
        from guard.dasar import DryRunViolation
        if isinstance(e, DryRunViolation):
            raise
        mesej = str(e).splitlines()[0]
        # Larian 2026-08-19 15:06 membuktikan popup PILIHAN KEGEMARAN
        # build MBPG 2.1.23 TIADA medan nama (senarai sahaja — sama
        # seperti penemuan MBIP 2.1.17). Itu HAD BUILD, bukan kegagalan
        # skrip: laporkan TIDAK-DISOKONG supaya laporan tidak menuduh
        # automasi, dan supaya -005 tidak dikira GAGAL teknikal.
        if "medan nama" in mesej or "UI simpan Bookmark" in mesej:
            peringkat_bookmark_inline._tidak_disokong = True
            catat_peringkat(f"bookmark {huruf}-005", "TIDAK-DISOKONG",
                            "popup PILIHAN KEGEMARAN build ini tiada "
                            "medan nama/SIMPAN (had build, bukan skrip)")
        else:
            catat_peringkat(f"bookmark {huruf}-005", "GAGAL",
                            f"{type(e).__name__}: {mesej[:160]}")
    finally:
        # Jangan tinggalkan popup terbuka — ia menyekat SETIAP ketukan
        # aliran cipta selepasnya. finally: laluan LULUS pun boleh
        # meninggalkan senarai terbuka (select_bookmark laluan WARNING).
        if not _tutup_paksa():
            catat_peringkat(f"bookmark {huruf}-005 tutup", "GAGAL",
                            "modal-surface MASIH terbuka selepas 5 "
                            "cubaan tutup — peringkat seterusnya "
                            "mungkin tersekat")


def jalankan_satu(huruf, izin, args, konteks, plat=None):
    """Satu rekod hujung ke hujung. Memulangkan dict hasil.

    `plat` menggantikan nombor kenderaan oracle untuk borang K sahaja.

    Ia wujud untuk D-09(b): butiran pemilik terdahulu melekat pada rekod
    seterusnya. Defek itu TIDAK BOLEH dilihat dengan satu plat — dua
    kompaun untuk kenderaan yang sama SEPATUTNYA menamakan orang yang
    sama, jadi identiti yang melekat kelihatan betul sepenuhnya. Hanya
    plat BERBEZA membuatnya kelihatan.

    Plat mesti sah pada mySIKAP; plat rekaan memulangkan "tiada rekod",
    yang menyerupai D-09(a) dan mengelirukan kedua-dua tanda.
    """
    from devtools import peringkat6 as P6
    from devtools import fasa_c as FC
    from devtools.fasa_c_e2e import jaring_pii
    from devtools.smoke_tangga import pastikan_di_home, tarik_db
    from guard.dasar import PermitSerah
    from pages.cetak_page import CetakPage
    from testdata import oracle_n001, oracle_pk

    s = SPEC[huruf]
    drv, pages, serial = konteks["drv"], konteks["pages"], konteks["serial"]
    asal = (oracle_n001.SEMUA if huruf == "N"
            else getattr(oracle_pk, "P001" if huruf == "P" else "K001"))

    print(f"\n{'=' * 70}\n== {s['tag']} — {s['borang']}\n{'=' * 70}")
    izin.semak(huruf)

    # ---- 3.3 penanda data ujian ----
    # Rekod ini akan HIDUP pada production sehingga PM membatalkannya.
    # Ia mesti membawa identiti yang jelas ujian, bukan identiti oracle
    # yang berbentuk warga sebenar.
    data = PU.tandai(asal, s["tag"])
    if plat and huruf == "K":
        # Nombor plat BUKAN PII dan BUKAN penanda ujian — ia kunci
        # carian, dan ia mesti kekal sah supaya mySIKAP memulangkan
        # sesuatu untuk diperiksa.
        data = dict(data)
        data["no_kereta"] = plat
        print(f"  [D-09] plat carian mySIKAP: {plat}")
    beza = PU.ringkasan(asal, data)
    print(f"  [PENANDA] {len(beza)} medan ditanda sebagai data ujian:")
    for medan, sebelum, selepas in beza:
        print(f"      {medan:<22} {sebelum!r} -> {selepas!r}")
    if not beza:
        raise IzinTidakSah(
            f"{s['tag']}: penanda data ujian TIDAK mengubah apa-apa. "
            f"Rekod akan dicipta dengan identiti oracle — itu yang "
            f"arahan 3.3 larang. BERHENTI.")

    sumber_k = None          # diisi hanya untuk borang K (lookup mySIKAP)
    jejak = konteks.setdefault("jejak", [])

    # Cap masa setiap peringkat (arahan pemilik Prompt 8 #6). `mula`
    # satu peringkat ialah `tamat` peringkat sebelumnya — itu memberi
    # tempoh tanpa menabur panggilan masa di tengah setiap laluan
    # halaman.
    jam = {"akhir": time.time()}

    def catat_peringkat(nama, status, nota=""):
        sekarang = time.time()
        mula_p = jam["akhir"]
        jam["akhir"] = sekarang
        jejak.append({
            "tag": s["tag"], "peringkat": nama, "status": status,
            "nota": nota,
            "mula": time.strftime("%Y-%m-%d %H:%M:%S",
                                  time.localtime(mula_p)),
            "tamat": time.strftime("%Y-%m-%d %H:%M:%S",
                                   time.localtime(sekarang)),
            "tempoh_s": round(sekarang - mula_p, 1),
        })
        tanda = {"LULUS": "[OK ]", "GAGAL": "[!! ]",
                 "TIDAK-DITAWARKAN": "[-- ]",
                 "SKIP-TIDAK-LAYAK": "[-- ]"}.get(status, "[   ]")
        print(f"  {tanda} {nama}: {status}  "
              f"({round(sekarang - mula_p, 1)}s)"
              + (f" — {nota}" if nota else ""))

        # >>> BUKTI GAGAL — DITAMBAH 2026-10-08 (run11). <<<
        # Sebelum ini `tangkap_skrin()` dipanggil BERASINGAN selepas
        # `catat_peringkat()` — jadi setiap jalan keluar AWAL (return
        # awal: pagar Fix#12, TIDAK-DITAWARKAN, skrin Hantar tak
        # terbuka) langsung tidak meninggalkan gambar. Bukti run11:
        # 7 peringkat GAGAL, tetapi hanya 3 ada shot (N/P/K) — K-004,
        # P-003 dan T-005 tiada apa-apa untuk disiasat.
        #
        # Meletakkannya DI DALAM `catat_peringkat` menjadikannya
        # mustahil untuk terlepas: setiap verdik melalui fungsi ini,
        # dan hanya GAGAL ditangkap (lulus tidak perlu bukti gagal).
        #
        # BEST-EFFORT: kegagalan menangkap TIDAK boleh menukar verdik.
        if status == "GAGAL":
            try:
                tangkap_skrin(drv, s["tag"], f"GAGAL-{nama}")
            except Exception as e:                              # noqa: BLE001
                print(f"  [SHOT] gagal tangkap bukti "
                      f"({type(e).__name__}) — diteruskan")

    P6.relaunch(drv, pages, f"{s['tag']}: borang bersih")
    if not pastikan_di_home(drv, pages):
        raise RuntimeError(f"{s['tag']}: tidak sampai skrin utama")

    cetak = CetakPage(drv)
    # >>> JANGAN BUKA STATUS PRINTER BILA KITA TAHU TIADA PRINTER. <<<
    # Membukanya tanpa printer meninggalkan DUA kesan yang menyekat
    # segala-galanya selepasnya (diperhati 2026-08-17):
    #
    #   [CETAK] backdrop dan ikon tutup gagal — BACK peranti
    #   [CETAK] bluetooth=False tersambung=False printer=None
    #   ...kemudian: "disekat oleh modal (modal-surface) terbuka"
    #
    # Penutupan modal gagal dan terpaksa menggunakan BACK peranti, yang
    # meninggalkan susunan modal dalam keadaan yang menyekat popup
    # PILIH KOMPAUN selepasnya.
    #
    # `--tanpa-printer` bermakna pemilik SUDAH TAHU tiada printer, jadi
    # bertanya kepada app tidak memberi maklumat — ia hanya merosakkan
    # keadaan skrin. Dengan printer hadir (larian esok), semakan berjalan
    # seperti biasa dan CETAK diuji sepenuhnya.
    if args.tanpa_printer:
        lap = {"nama": None, "bluetooth": None, "tersambung": None}
        print("  [CETAK] --tanpa-printer: semakan status printer "
              "DILANGKAU (tidak dibuka langsung)")
    else:
        # >>> FIX#19 — PRINTER TIDAK SEDIA BUKAN LAGI MAUT. <<<
        # (2026-10-08; pemilik meninggalkan run tanpa pengawasan.)
        # Tingkah laku lama: `sahkan_printer_sedia(wajib=True)` ->
        # PrinterTidakSedia -> jalankan_satu() melempar SEBELUM borang
        # dibuka -> N/P/K tidak dicipta langsung. Satu pencetak yang
        # tidur awal membuang SELURUH larian (90-120 minit), sedangkan
        # rekod boleh dicipta dan diuji tanpa kertas.
        #
        # Kenapa ini selamat: ganti 'maut' ialah 'printer tidak diuji'.
        # Kita TIDAK berdiam tentangnya — cetak dilaporkan SKIP (bukan
        # LULUS), jadi N/P/K-002 tidak pernah didakwa terbukti. Itu
        # lebih jujur daripada melaporkan LULUS palsu (bug run12) DAN
        # lebih berguna daripada melaporkan tiada apa-apa (larian mati).
        try:
            lap = cetak.sahkan_printer_sedia(wajib=True)
        except BaseException as e:                              # noqa: BLE001
            from guard.dasar import DryRunViolation
            if isinstance(e, DryRunViolation):
                raise
            print(f"  [CETAK] printer TIDAK SEDIA ({type(e).__name__}) — "
                  f"cetak dilaporkan SKIP, kitaran DITERUSKAN")
            print(f"  [CETAK] {str(e).splitlines()[0][:150]}")
            lap = {"nama": None, "bluetooth": False, "tersambung": False,
                   "tidak_sedia": True}
            args.tanpa_printer = True
            catat_peringkat(
                "cetak-sedia", "SKIP",
                "printer tidak sedia — cetak TIDAK diuji; rekod tetap "
                "dicipta dan kitaran diteruskan. N/P/K-002 TIDAK terbukti.")

    # >>> SALIRKAN ALERT SELEPAS SEMAKAN PRINTER. <<<
    # Bila printer TIADA, semakan status meninggalkan dialog asli
    # `Alert | Error: Unable to connect device` terbuka pada skrin
    # utama, dan ia menyekat SETIAP ketukan selepasnya:
    #
    #   [CETAK] bluetooth=False tersambung=False printer=None
    #   [HOME] Opening Daftar Kompaun module...
    #   [SKROL] TIDAK cuba skrol -- disekat oleh alert asli terbuka
    #   -> TimeoutException: Element not clickable
    #
    # Menyalirkannya sebelum peringkat bermula TIDAK memadai: relaunch
    # + login di atas membawanya kembali. Ia mesti disalir DI SINI,
    # selepas semakan printer dan sebelum borang dibuka.
    #
    # Teksnya ada dalam ALERT_INFO_SELAMAT, jadi corong membenarkan OK
    # menutupnya. Diperhati 2026-08-17 pada larian tanpa printer.
    try:
        pages.home.dismiss_native_alerts(first_timeout=2,
                                         context=f"pra-{s['tag']}")
    except Exception:                                           # noqa: BLE001
        pass

    # ---- isi ----
    if huruf == "N":
        p = pages.notis_amaran
        pages.home.open_notis_amaran()
        sahkan_konteks_mutasi(drv, s["tag"])
        p.fill_pesalah_tab(data)
        p.click_seterusnya_from_pesalah()
        p.fill_notis_tab(data)
        p.fill_kompaun_code_fields(data)
        peringkat_bookmark_inline(huruf, s, pages, data, catat_peringkat)
        p.take_photos(count=3)
        p.click_seterusnya_from_notis()
        p.fill_penerima_tab(data)
    else:
        p = pages.daftar_kompaun
        P6._pakai_sauh_alamat(serial, data, oracle_pk.K001)
        pages.home.open_daftar_kompaun()
        if huruf == "K":
            p.select_jenis_kompaun_letak_kereta()
            sahkan_konteks_mutasi(drv, s["tag"])
            # >>> mySIKAP DICETUSKAN — arahan pemilik 2026-08-17. <<<
            # Rekod K yang terhasil membawa PII warga SEBENAR daripada
            # lookup, bukan penanda ujian. Itu keputusan sedar pemilik
            # (Prompt 8 #3), direkod di sini supaya ia tidak kelihatan
            # seperti kebocoran.
            sumber_k = isi_pesalah_k_mysikap(p, drv, data, s["tag"])
        else:
            p.select_jenis_kompaun(s["borang"])
            sahkan_konteks_mutasi(drv, s["tag"])
            p.fill_pesalah_tab(data)
        p.click_seterusnya_from_pesalah()
        p.fill_kompaun_tab(data)
        p.fill_kompaun_code_fields(data)
        peringkat_bookmark_inline(huruf, s, pages, data, catat_peringkat)
        p.take_photos(count=3)
        p.click_seterusnya_from_kompaun()
        p.fill_penerima_tab(data)

    # >>> JARING PII — DENGAN SATU PENGECUALIAN BERSKOP UNTUK K. <<<
    # Jaring ini membatalkan rekod apabila PII muncul tanpa kita
    # menaipnya, iaitu tepat apa yang lookup mySIKAP hasilkan. Di bawah
    # arahan pemilik 2026-08-17 lookup itu DIKEHENDAKI pada K, jadi
    # nilai yang lookup benar-benar tulis dikecualikan.
    #
    # Pengecualian ini ikut NILAI YANG DIPERHATI, bukan "matikan jaring
    # untuk K": hanya rentetan yang snapshot sebelum/selepas buktikan
    # datang dari lookup ini diterima. PII lain yang muncul pada skrin
    # — dari borang terdahulu, dari draf yang tidak dibersihkan — masih
    # membatalkan rekod.
    dijangka = dict(data)
    if sumber_k:
        for i, v in sumber_k["dari_lookup"].items():
            dijangka[f"_mysikap_{i}"] = v
    jumpa = jaring_pii(drv, dijangka)
    if jumpa:
        raise IzinTidakSah(
            f"{s['tag']}: skrin pra-serah membawa PII yang KITA TIDAK "
            f"taip DAN yang bukan hasil lookup mySIKAP larian ini "
            f"({[j[0] for j in jumpa]}). Rekod DIBATALKAN.")

    # ---- serah ----
    db1 = tarik_db(serial, os.path.join(AKAR, "data", "tmp",
                                        f"run_{s['tag']}.db"))
    sebelum = FC.kira_rekod(db1)
    hasil = FC.serah_dan_tangkap(drv, pages, p, s["set_id"], s["jadual"],
                                 serial, sebelum)
    no_rekod = hasil["no_rekod"]

    # ---- 3.4 log rekod — SERTA-MERTA, bukan pada akhir larian ----
    # Nombor ini kini WUJUD pada production. Kalau proses ini mati pada
    # baris seterusnya, PM masih perlu tahu nombornya. Itu tepat apa
    # yang berlaku kepada siri 005 pada 2026-08-13.
    laluan_log = rekod_log.log_rekod(
        no_rekod, s["tag"], huruf, s["jenis"], "baru",
        nota="" if no_rekod else "serah berjaya, nombor tidak tertangkap")
    print(f"  [LOG] {no_rekod or '(tiada nombor)'} -> "
          f"{os.path.basename(laluan_log)}")
    catat_peringkat("cipta", "LULUS" if no_rekod else "GAGAL",
                    f"no_rekod={no_rekod}")
    tangkap_skrin(drv, s["tag"], "01-selepas-serah")

    # Kuota ditolak SEKARANG — rekod sudah wujud. Menolaknya lebih
    # lewat (selepas cetak) bermakna cetakan yang gagal meninggalkan
    # kuota yang boleh mencipta rekod kedua.
    baki = izin.guna_satu(huruf)
    print(f"  [IZIN] kuota_{huruf} baki {baki} (ditulis ke "
          f"{os.path.basename(izin.laluan)})")

    # ---- cetak: satu tekan ----
    hc = {"popup_tutup": None, "teks_baharu": []}
    ralat_cetak = None
    if args.tanpa_printer:
        # Tiada printer: CETAK tidak boleh diuji, dan menekannya hanya
        # akan menghasilkan kegagalan yang tidak bermakna. Ditanda
        # SKIP supaya laporan tidak mendakwa N/P/K-002 terbukti.
        ralat_cetak = "DILANGKAU (--tanpa-printer)"
        print("  [CETAK] DILANGKAU — tiada printer; N/P/K-002 TIDAK "
              "terbukti pada larian ini")
    else:
        try:
            tetapan = drv.corong.tetapan
            tetapan.permit_serah = PermitSerah(s["set_id"], had=1)
            try:
                hc = cetak.cetak_dari_popup(no_rekod)
            finally:
                tetapan.permit_serah = None
        except BaseException as e:                              # noqa: BLE001
            # Cetakan gagal DIREKOD, bukan diulang. Satu tekan sahaja.
            ralat_cetak = (f"{type(e).__name__}: "
                           f"{str(e).splitlines()[0][:200]}")
            print(f"  [CETAK] GAGAL: {ralat_cetak}")

    # >>> FIX#18 — DITAMBAH 2026-10-08 (run12). CETAK TIDAK SAMPAI. <<<
    # Larian 8/10: cetak dilaporkan LULUS pada ketiga-tiga rekod,
    # sedangkan teks baharu pada skrin untuk yang ke-4 (K[2/3]) ialah
    # ['Alert', 'COMMAND_NOT_SEND', 'OK'] -- popup cetak memang tertutup,
    # tetapi hanya kerana app MEMBUKA dialog ralat. Tiada kertas keluar.
    # Punca sebenar: bateri Bixolon habis, printer terputus (pemilik
    # sahkan sendiri). Skrip mengukur "popup tutup", bukan "kertas
    # keluar", jadi ia melaporkan kejayaan yang tidak berlaku. Itu lebih
    # buruk daripada gagal: ia mendakwa N/P/K-002 terbukti.
    #
    # Imbas teks yang MUNCUL selepas CETAK untuk penanda kegagalan
    # sambungan. Ini kegagalan persekitaran (printer mati), BUKAN defek
    # app -- dilaporkan GAGAL secara jujur, nota menyatakan puncanya
    # supaya ia tidak menjadi tiket developer.
    #
    # Mesti di sini, SEBELUM entri dibina dan sebelum tulis_jsonl.
    PENANDA_CETAK_GAGAL = ("COMMAND_NOT_SEND", "NOT CONNECTED",
                           "TIDAK DISAMBUNG", "UNABLE TO CONNECT",
                           "PRINTER NOT")
    if not args.tanpa_printer and ralat_cetak is None:
        baharu_teks = [str(t).upper() for t in (hc.get("teks_baharu") or [])]
        padan = next((p for p in PENANDA_CETAK_GAGAL
                      if any(p in t for t in baharu_teks)), None)
        if padan:
            ralat_cetak = (f"PRINTER TERPUTUS ({padan}) — kertas TIDAK "
                           f"keluar; kegagalan persekitaran, bukan defek app")
            print(f"  [CETAK] BETULKAN verdict -> GAGAL: {ralat_cetak}")

    entri = {"tag": s["tag"], "borang": huruf, "no_rekod": no_rekod,
             "no_siri": hasil["no_siri"],
             "masa": time.strftime("%Y-%m-%d %H:%M:%S"),
             "pesalah": data.get("nama_pesalah"),
             "cetak_dihantar": ralat_cetak is None,
             "ralat_cetak": ralat_cetak,
             "printer": lap.get("nama"), "kuota_baki": baki}
    tulis_jsonl(entri)
    tulis_dok(f"| {s['tag']} | `{no_rekod}` | {hasil['no_siri']} | "
              f"{entri['masa']} | {data.get('nama_pesalah')} | "
              f"{'dihantar' if ralat_cetak is None else 'GAGAL'} |")

    # SKIP bukan GAGAL: melangkau cetak kerana tiada printer ialah
    # keadaan yang diminta, bukan kerosakan. Melaporkannya sebagai GAGAL
    # akan menjadikan laporan esok kelihatan lebih teruk daripada
    # keadaan sebenar.
    if args.tanpa_printer:
        status_cetak = "SKIP"
    else:
        status_cetak = "GAGAL" if ralat_cetak else "LULUS"
    catat_peringkat("cetak", status_cetak,
                    ralat_cetak or f"printer {lap.get('nama')}")
    tangkap_skrin(drv, s["tag"], "02-selepas-cetak")

    print(f"\n  >>> {s['tag']}  No. rekod {no_rekod}  siri "
          f"{hasil['no_siri']}  <<<")
    # >>> FIX#19 — CETAK GAGAL TIDAK LAGI MEMBUNUH KITARAN. <<<
    # (DITAMBAH 2026-10-08, selepas run12 mati pada K [2/3] JUA3276.)
    #
    # Tingkah laku lama: cetakan gagal -> RuntimeError -> jalankan()
    # mencatat GAGAL untuk SELURUH peringkat "borang K [2/3]", dan
    # keluar dari gelung plat. Run12 kehilangan:
    #   - borang K [3/3] JRT2649 (rekod D-09 ketiga, sengaja diuji)
    #   - semak D-09      (TIDAK DIUJI langsung)
    #   - menu senarai/hantar/tarik
    # Hanya kerana bateri pencetak habis. Pemilik meninggalkan run ini
    # tanpa pengawasan; satu pencetak mati mesti TIDAK membuang 50
    # minit kerja yang lain.
    #
    # Kenapa ia pernah maut: cetakan ialah tindakan LUARAN (kertas
    # keluar = rekod wujud untuk orang sebenar). Itu sebabnya CETAK
    # dilindungi permit dan satu-tekan-sahaja. Tetapi "cetakan gagal"
    # BUKAN "risiko data rosak" — rekod SUDAH dicipta dan sah sebelum
    # baris ini. Ia kegagalan PERSEKITARAN, bukan keadaan tak selamat.
    #
    # Jadi: catat cetak GAGAL (sudah dilakukan di atas), dan TERUSKAN.
    # Rekod kekal dilog; pemilik melihat cetak GAGAL dalam jadual masa.
    # Sesuai dengan keputusan pemilik 2026-10-08: satu kertas tidak
    # keluar bukan sebab untuk menggugurkan tiga peringkat yang tinggal.
    if ralat_cetak and not args.tanpa_printer:
        print(f"  [CETAK] GAGAL dicatat — kitaran DITERUSKAN "
              f"({s['tag']}, rekod {no_rekod} sudah wujud)")
        catat_peringkat(
            "cetak-lanjut", "LULUS",
            f"kitaran diteruskan selepas cetak gagal ({s['tag']}) — "
            f"rekod {no_rekod} tidak digugurkan")

    if args.kitaran == "penuh":
        kitaran_lanjutan(huruf, s, no_rekod, data, konteks, args,
                         catat_peringkat)

    return entri


# ---------------------------------------------------------------------------
# 3.5 langkah 3-7 — kitaran penuh
# ---------------------------------------------------------------------------

def _pulihkan_selepas_gagal(drv, pages, peringkat):
    """Bawa app balik ke skrin utama selepas satu peringkat gagal.

    >>> FIX#19 — DITAMBAH 2026-10-08. <<<
    Dipakai oleh pengendali except yang kini TIDAK fatal (tn_nk, hantar,
    senarai). Sebelum ini setiap satu `raise`, jadi tiada siapa perlu
    memulihkan skrin — larian tamat. Kini larian diteruskan, dan
    peringkat seterusnya MESTI bermula dari skrin utama atau ia gagal
    atas sebab warisan (kelas kegagalan D-C 2026-08-18).

    Corak sama seperti pemulihan selepas kemaskini gagal (AUDIT
    2026-08-19). BEST-EFFORT: kegagalan memulihkan tidak membatalkan
    larian — ia hanya bermakna peringkat seterusnya mungkin gagal.
    """
    try:
        from devtools import peringkat6 as P6
        from devtools.smoke_tangga import pastikan_di_home
        P6.relaunch(drv, pages, f"pulih selepas {peringkat} gagal")
        pastikan_di_home(drv, pages)
    except Exception as e:                                      # noqa: BLE001
        print(f"  [RECOVERY] pemulihan selepas {peringkat} gagal "
              f"({type(e).__name__}) — diteruskan")


def kitaran_lanjutan(huruf, s, no_rekod, data, konteks, args,
                     catat_peringkat):
    """Kemaskini -> TN/NK -> Hantar -> SK-001 -> P-006.

    >>> SETIAP PERINGKAT DI SINI MENGGUNAKAN PAGE OBJECT PORT MBJB. <<<
    Tiada satu pun daripadanya pernah dijalankan pada MBPG. Ia ditulis
    supaya larian pathfinder MENDEDAHKAN apa yang app sebenarnya
    benarkan, dan bukan supaya ia berpura-pura sudah tahu.

    Sebarang nombor rekod BAHARU yang muncul dilog SERTA-MERTA melalui
    rekod_log — arahan 3.4 menekankan satu kitaran boleh menjana lebih
    daripada satu nombor, dan nombor kedua sama nyata seperti yang
    pertama.

    Kegagalan teknikal DIBIARKAN merambat. Arahan 3.6 menyenaraikan
    "elemen tak jumpa selepas retry" sebagai keadaan BERHENTI, jadi
    peringkat ini tidak menelannya — ia mencatat apa yang berlaku
    dahulu, kemudian membiarkan runner berhenti dengan jejak yang
    lengkap.
    """
    drv, pages = konteks["drv"], konteks["pages"]
    semasa = no_rekod

    # ---- 3.5(3) KEMASKINI ----
    try:
        semasa = peringkat_kemaskini(huruf, s, semasa, data, pages,
                                     catat_peringkat,
                                     serial=konteks.get("serial"))
    except BaseException as e:                                  # noqa: BLE001
        catat_peringkat("kemaskini", "GAGAL",
                        f"{type(e).__name__}: {str(e).splitlines()[0][:160]}")
        # >>> AUDIT 2026-08-19: TIDAK LAGI FATAL. <<<
        # Run 4: kegagalan kemaskini (D-B, defek pendedahan butang yang
        # diketahui) membunuh SELURUH baki kitaran — hantar akhir,
        # SK-001, lampiran N-003 dan P-006 tidak pernah dicapai walaupun
        # rekod sudah wujud dan sihat. Kini: catat GAGAL, pulihkan
        # keadaan skrin, dan TERUSKAN peringkat lain. DryRunViolation
        # kekal fatal (corong menyekat = sentiasa berhenti).
        from guard.dasar import DryRunViolation
        if isinstance(e, (DryRunViolation, KeyboardInterrupt, SystemExit)):
            raise
        try:
            from devtools import peringkat6 as P6
            from devtools.smoke_tangga import pastikan_di_home
            P6.relaunch(drv, pages, "pulih selepas kemaskini gagal")
            pastikan_di_home(drv, pages)
        except Exception:                                       # noqa: BLE001
            pass

    # ---- 3.5(4) TN / NK — borang N sahaja ----
    # >>> FIX#19 — TIDAK LAGI FATAL. <<<
    # Corak sama seperti kemaskini (AUDIT 2026-08-19) dan atas sebab yang
    # sama: rekod SUDAH wujud sebelum peringkat ini. Kegagalan TN/NK
    # (atau hantar/senarai di bawah) membuang peringkat yang tinggal
    # tanpa menambah apa-apa keselamatan — ia hanya melaporkan kurang.
    # DryRunViolation/KeyboardInterrupt/SystemExit KEKAL fatal.
    if huruf == "N":
        try:
            semasa = peringkat_tn_nk(s, semasa, pages, catat_peringkat,
                                     paksa=getattr(args, "paksa_nk", False))
        except BaseException as e:                              # noqa: BLE001
            from guard.dasar import DryRunViolation
            catat_peringkat("tn_nk", "GAGAL",
                            f"{type(e).__name__}: "
                            f"{str(e).splitlines()[0][:160]}")
            if isinstance(e, (DryRunViolation, KeyboardInterrupt,
                              SystemExit)):
                raise
            _pulihkan_selepas_gagal(drv, pages, "tn_nk")
    else:
        catat_peringkat("tn_nk", "TIDAK-DITAWARKAN",
                        "TN/NK hanya wujud untuk borang N")

    # ---- 3.5(5) Hantar akhir ----
    try:
        peringkat_hantar(s, semasa, pages, catat_peringkat)
    except BaseException as e:                                  # noqa: BLE001
        from guard.dasar import DryRunViolation
        catat_peringkat("hantar", "GAGAL",
                        f"{type(e).__name__}: {str(e).splitlines()[0][:160]}")
        if isinstance(e, (DryRunViolation, KeyboardInterrupt, SystemExit)):
            raise
        _pulihkan_selepas_gagal(drv, pages, "hantar")

    # ---- 3.5(6) SK-001 senarai ----
    try:
        peringkat_senarai(s, semasa, pages, catat_peringkat)
    except BaseException as e:                                  # noqa: BLE001
        from guard.dasar import DryRunViolation
        catat_peringkat("senarai", "GAGAL",
                        f"{type(e).__name__}: {str(e).splitlines()[0][:160]}")
        if isinstance(e, (DryRunViolation, KeyboardInterrupt, SystemExit)):
            raise
        _pulihkan_selepas_gagal(drv, pages, "senarai")

    # ---- 3.5(6b) N-003 LAMPIRAN — borang N sahaja, DIWAYARKAN 2026-08-19 ----
    # `pages/serah_page.py` (port MBJB, aliran DISAHKAN pada projek
    # MBJB/MBIP) sudah lama wujud tetapi TIADA pemanggil — sebab itu
    # laporan menanda N-003 "ikon klip tidak dijumpai / tidak
    # diwayarkan". Ikon klip BUKAN pada borang cipta: ia dalam popup
    # rekod (KEMASKINI DATA), DI BAWAH lipatan popup, ViewGroup dengan
    # content-desc U+F0C6 selepas label LAMPIRAN. Laluan KAMERA sahaja
    # (galeri ROSAK — 'Galeri Ralat', Excel MBPG-TC-N-003 C12).
    #
    # TIDAK fatal: kegagalan lampiran tidak membatalkan rekod yang
    # sudah wujud — ia dicatat dan larian diteruskan.
    if huruf == "N":
        try:
            sen = pages.senarai
            if sen.open_record_by_number(semasa) and \
                    sen.record_popup_shows_number(semasa):
                pages.serah.attach_lampiran("N")
                catat_peringkat("lampiran N-003", "LULUS",
                                f"lampiran kamera diterima pada {semasa}")
            else:
                catat_peringkat("lampiran N-003", "GAGAL",
                                f"popup rekod {semasa} tidak terbuka")
        except BaseException as e:                              # noqa: BLE001
            from guard.dasar import DryRunViolation
            if isinstance(e, DryRunViolation):
                raise
            catat_peringkat("lampiran N-003", "GAGAL",
                            f"{type(e).__name__}: "
                            f"{str(e).splitlines()[0][:160]}")
    else:
        catat_peringkat("lampiran", "TIDAK-DITAWARKAN",
                        "N-003 sahaja dalam senarai retest; P/K/L/S-003 "
                        "ialah serah, bukan lampiran, pada MBPG")

    # ---- 3.5(7) P-006 ----
    # Isu tandatangan hanya boleh disahkan pada KERTAS. Automasi tidak
    # boleh melihat kertas; mendakwa LULUS di sini akan menjadi hijau
    # palsu. Ia ditanda untuk pemeriksaan mata pemilik, sama seperti
    # pengesahan cetakan fizikal pada 2026-08-13.
    catat_peringkat("p006", "PERLU-MATA",
                    f"laluan cetak terbuka; tandatangan pada cetakan "
                    f"{semasa} perlu disemak fizikal oleh pemilik")
    # Bukti keadaan skrin pada saat P-006 dicatat — bukan bukti
    # tandatangan (itu di atas KERTAS), tetapi menambat masa dan
    # konteks untuk pemeriksaan mata pemilik.
    tangkap_skrin(drv, s["tag"], "07-p006-perlu-mata")
    return semasa


def _nombor_kemaskini_dari_db(serial, jadual, no_lama):
    """Nombor rekod gantian selepas kemaskini, dibaca dari DB peranti.

    Kemaskini membatalkan rekod lama dan menjana nombor baharu. Dalam
    DB itu kelihatan sebagai baris LAMA bertukar kepada
    `statuskompaun='B'` dan baris BAHARU dengan `'A'` — disahkan pada
    device 2026-08-18 (`PGP02P260818006` -> B, `PGP02P260818007` -> A).

    Memulangkan None kalau tiada calon jelas; pemanggil kemudian jatuh
    ke carian senarai UI.
    """
    import sqlite3
    from devtools.smoke_tangga import tarik_db

    try:
        db = tarik_db(serial, os.path.join(AKAR, "data", "tmp",
                                           "kemaskini.db"))
        con = sqlite3.connect(db)
        con.text_factory = str
        cur = con.cursor()
        lajur = [c[1] for c in cur.execute(f"PRAGMA table_info({jadual})")]
        kunci = next((c for c in lajur
                      if c.lower() in ("nokompaun", "nonotis")), None)
        if not kunci:
            return None
        baris = [r[0] for r in cur.execute(
            f"SELECT {kunci} FROM {jadual} ORDER BY rowid DESC LIMIT 20")]
        # >>> FIX 2026-09-10 (run 20260910: PGP02K260910005 -> PGP02P260910002). <<<
        # `local_ekpn_tawaran_kompaun` menyimpan BORANG P *DAN* K bersama
        # (dua konfigurasi `s["jadual"]` menuding jadual yang SAMA — lihat
        # baris 46/49). Penapisan lama `n > no_lama` banding SELURUH
        # string, jadi huruf borang sendiri masuk kira: 'P' (0x50) > 'K'
        # (0x4B) SELALU, tak kira nombor. Hasilnya kemaskini K sentiasa
        # "menjumpai" rekod P terbaharu dalam jadual kongsi itu, walaupun
        # ia baca DB terus (bukan popup UI -- diagnosis lama "bacaan
        # popup basi" silap punca). Fix: hadkan calon kepada AWALAN yang
        # SAMA seperti no_lama (contoh 'PGP02K') sebelum banding nombor,
        # supaya kemaskini K tidak boleh terpilih rekod P, dan begitu
        # juga sebaliknya.
        # Format nombor: <kod_pbt><huruf_modul><YYMMDD><turutan 3-digit>
        # -- 9 aksara TERAKHIR sentiasa YYMMDD+turutan (semuanya digit);
        # apa-apa sebelum itu ialah kod PBT + huruf modul (awalan yang
        # kita nak padan). Guna panjang, bukan cari digit pertama --
        # kod PBT sendiri boleh ada digit (contoh 'PGP02').
        awalan = no_lama[:-9] if no_lama and len(no_lama) > 9 else no_lama
        calon = [n for n in baris if n and awalan and n.startswith(awalan)]
        lebih = sorted(n for n in calon if no_lama and n > no_lama)
        return lebih[-1] if lebih else None
    except Exception as e:                                      # noqa: BLE001
        print(f"  [KEMASKINI] baca DB gagal ({type(e).__name__})")
        return None


def peringkat_kemaskini(huruf, s, no_rekod, data, pages,
                        catat_peringkat, serial=None):
    """N/P/K-004. Kemaskini MEMBATALKAN rekod lama dan MENJANA nombor
    baharu — itu sebab TC ini skip-guard sehingga hari ini."""
    from pages.kemaskini_page import KemaskiniPage

    print(f"\n  --- 3.5(3) KEMASKINI {no_rekod} ---")
    km = KemaskiniPage(pages.senarai.driver)
    sen = pages.senarai
    # >>> FIX#12 — DITAMBAH 2026-10-07 (Khamis 2026-10-01 gagal 3x). <<<
    # Titik buta TERAKHIR dalam kelas bug yang sama. FIX#8 menjadikan
    # peringkat_hantar() dan peringkat_senarai() berpagar, tetapi
    # peringkat_kemaskini() masih mengetuk kad SENARAI secara buta --
    # dan ia ialah peringkat PERTAMA setiap kitaran (kitaran_lanjutan
    # baris ~844), jadi ia juga yang paling kerap mengetuk pada skrin
    # yang belum pasti betul (selepas cipta/serah, popup CETAK, dsb).
    # Gejala ialah "Element not clickable after 15s" pada
    # descriptionMatches("SENARAI") -- sama seperti 3 kegagalan Khamis.
    # Kad SENARAI hanya wujud pada grid skrin UTAMA; mengetuknya dari
    # skrin lain gagal secara SENYAP (bukan locator salah).
    from devtools.smoke_tangga import pastikan_di_home
    if not pastikan_di_home(sen.driver, pages):
        catat_peringkat("kemaskini", "GAGAL",
                        "tidak dapat kembali ke skrin utama sebelum "
                        "membuka Senarai (lihat pastikan_di_home, Fix#12)")
        return no_rekod
    pages.home.open_senarai()
    # >>> FIX#18 (2026-10-08): Semak disempitkan ke HARI rekod SEBELUM
    # ditekan. FIX#15 cuba selepas ini dan mustahil berjaya -- ikon
    # kalendar (U+F073) tidak lagi wujud selepas Semak. Lihat
    # SenaraiPage.ensure_records_for().
    sen.ensure_records_for(no_rekod, force=True)
    if not sen.open_record_by_number(no_rekod, sudah_sempit=True):
        catat_peringkat("kemaskini", "TIDAK-DITAWARKAN",
                        f"rekod {no_rekod} tidak dijumpai dalam Senarai")
        return no_rekod

    keterangan = f"KEMASKINI {PU.penanda(s['tag'])}"
    km.start_kemaskini(keterangan)
    km.proceed_and_submit()

    # >>> FIX#16 (2026-10-08): laporkan PUNCA, bukan hanya '-> None'. <<<
    # Kalau proceed_and_submit() mengesan popup proses beku, itu dapatan
    # app yang sebenar (manual tester sahkan 'props error') — bukan
    # 'nombor tak tertangkap'. Rekod nombor baharu masih dicuba supaya
    # rekod production tidak hilang dari log.
    beku = getattr(km, "_popup_proses_beku", None)

    baharu = _nombor_kemaskini_dari_db(serial, s["jadual"], no_rekod)
    if not baharu:
        baharu = cari_nombor_baharu(sen, huruf, no_rekod)
    rekod_log.log_rekod(baharu, f"{huruf}-004", huruf, s["jenis"],
                        "hasil-kemaskini", asal=no_rekod,
                        nota="" if baharu else "nombor baharu tidak "
                                               "tertangkap selepas kemaskini")
    if baharu:
        catat_peringkat("kemaskini", "LULUS", f"{no_rekod} -> {baharu}")
    elif beku is not None:
        catat_peringkat("kemaskini", "GAGAL",
                        f"popup proses BEKU pada {beku}% — kemaskini tidak "
                        f"lengkap ({no_rekod} tidak berkemaskini). Dapatan "
                        f"app, disahkan manual tester.")
    else:
        catat_peringkat("kemaskini", "GAGAL",
                        f"{no_rekod} -> None (nombor gantian tidak tertangkap)")
    tangkap_skrin(sen.driver, s["tag"], "03-selepas-kemaskini")
    return baharu or no_rekod


# Tempoh notis amaran, hari. Sumber: docs/recon/DAPATAN-NK.md dan medan
# `tempoh_notis` dalam oracle N-001.
TEMPOH_NOTIS_HARI = 14


def tarikh_layak_nk(tarikh_cipta=None):
    """Tarikh notis yang dicipta hari ini LAYAK ditukar ke kompaun."""
    import datetime
    t = tarikh_cipta or datetime.date.today()
    return t + datetime.timedelta(days=TEMPOH_NOTIS_HARI)


def peringkat_tn_nk(s, no_rekod, pages, catat_peringkat, paksa=False):
    """TN-001..003 / NK-001..002 — DILANGKAU, dan itu bukan pilihan kami.

    >>> KENAPA IA TIDAK DICUBA LANGSUNG. <<<
    Dialog tarik bertajuk `TARIK NOTIS TAMAT TEMPOH` — ia menarik notis
    yang sudah LUPUT sahaja. Disahkan pada device 2026-08-13; tarikan
    pada hari itu memulangkan SIFAR hasil (docs/recon/DAPATAN-NK.md).

    Notis yang dicipta hari ini bertempoh 14 hari, jadi ia tidak layak
    ditukar sehingga tarikh yang `tarikh_layak_nk()` kira. Menekan
    [TARIK] sekarang hanya boleh memulangkan senarai kosong.

    Arahan pemilik 2026-08-17 menyatakannya terus: *"NK-001/002 TETAP
    tak boleh diuji, notis belum layak sampai tarikh eligibiliti, SKIP
    macam dokumen sedia ada dah catat."* Maka peringkat ini **tidak
    menyentuh skrin Notis Kompaun langsung** — membuka borang penukaran
    dalam app ini sudah terbukti membakar nombor siri (D-07), dan tiada
    sebab membakar satu untuk laluan yang kami sudah tahu akan kosong.

    `paksa=True` wujud supaya larian selepas tarikh layak boleh
    menjalankannya tanpa menyunting kod.
    """
    layak = tarikh_layak_nk()
    if not paksa:
        catat_peringkat(
            "tn_nk", "SKIP-TIDAK-LAYAK",
            f"notis {no_rekod} bertempoh {TEMPOH_NOTIS_HARI} hari; layak "
            f"ditukar pada {layak.isoformat()}. Skrin Notis Kompaun TIDAK "
            f"disentuh (D-07: membuka borang membakar nombor siri). "
            f"Arahan pemilik 2026-08-17 + docs/recon/DAPATAN-NK.md.")
        return no_rekod

    from pages.notis_kompaun_page import NotisKompaunPage

    print(f"\n  --- 3.5(4) TN / NK untuk {no_rekod} ---")
    nk = NotisKompaunPage(pages.senarai.driver)
    # >>> FIX#12 — DITAMBAH 2026-10-07. Pagar sama seperti peringkat
    # kemaskini/hantar/senarai. Laluan ini hanya dicapai dgn --paksa-nk
    # (lalai SKIP), tetapi apabila dicapai ia mengetuk kad grid skrin
    # utama dari keadaan yg diwarisi peringkat sebelumnya -- kelas bug
    # yg sama. Diletak sekarang supaya tiada lagi titik buta yang tinggal.
    from devtools.smoke_tangga import pastikan_di_home
    if not pastikan_di_home(pages.senarai.driver, pages):
        catat_peringkat("tn_nk", "GAGAL",
                        "tidak dapat kembali ke skrin utama sebelum "
                        "membuka Notis Kompaun (lihat pastikan_di_home, Fix#12)")
        return no_rekod
    pages.home.open_notis_kompaun()
    nk.tarik_by_no_notis(no_rekod)
    ditarik = nk.get_pulled_notice_numbers()
    if no_rekod not in (ditarik or []):
        catat_peringkat(
            "tn_nk", "TIDAK-DITAWARKAN",
            f"tarikan memulangkan {len(ditarik or [])} notis; {no_rekod} "
            f"belum luput — sekatan app, lihat DAPATAN-NK.md")
        return no_rekod

    nk.open_notice_by_number(no_rekod)
    nk.kompaun_action(None)
    baharu = nk.get_pulled_notice_numbers()
    nombor = next((n for n in (baharu or []) if n != no_rekod), None)
    rekod_log.log_rekod(nombor, "NK-001", "N", "Kompaun",
                        "hasil-NK-convert", asal=no_rekod,
                        nota="" if nombor else "nombor kompaun hasil "
                                               "convert tidak tertangkap")
    catat_peringkat("tn_nk", "LULUS" if nombor else "GAGAL",
                    f"{no_rekod} -> {nombor}")
    return nombor or no_rekod


def peringkat_hantar(s, no_rekod, pages, catat_peringkat):
    """H-001..003 — Hantar Data + Hantar Gambar, kemudian sahkan status
    baris bertukar kepada H/M.

    >>> FIX 2026-09-10 (run 20260910, log borang N/P/K GAGAL identik). <<<
    peringkat_kemaskini() (3.5(3), tepat sebelum peringkat ini)
    membiarkan skrin Senarai (ListView) TERBUKA selepas kemaskini
    berjaya -- ia hanya balik ke home dalam CAWANGAN GAGAL
    (kitaran_lanjutan's except-block), bukan laluan LULUS. HANTAR
    ialah kad grid skrin UTAMA, bukan sesuatu pada skrin Senarai, jadi
    open_hantar() mengetuk kad yang tiada pada skrin semasa --
    "Element not clickable after 15s" pada MODULE_HANTAR, disahkan
    lagi oleh log [SKROL] "disekat oleh senarai (ListView) terbuka".
    Fix: paksa balik ke skrin utama dahulu (sama fungsi yang peringkat
    5 & cawangan-gagal kemaskini sudah gunakan) supaya open_hantar()
    sentiasa mengetuk pada skrin yang betul, tak kira apa keadaan
    peringkat sebelumnya tinggalkan.
    """
    from pages.hantar_page import HantarPage
    from devtools.smoke_tangga import pastikan_di_home

    print(f"\n  --- 3.5(5) HANTAR akhir untuk {no_rekod} ---")
    ht = HantarPage(pages.senarai.driver)
    if not pastikan_di_home(pages.senarai.driver, pages):
        catat_peringkat("hantar", "GAGAL",
                        "tidak dapat kembali ke skrin utama sebelum "
                        "membuka Hantar (lihat pastikan_di_home)")
        return
    pages.home.open_hantar()
    if not ht.is_hantar_screen_displayed():
        catat_peringkat("hantar", "GAGAL", "skrin Hantar tidak terbuka")
        return
    ht.sync_all()

    # >>> FIX #8 — DITAMBAH 2026-10-01 (run8, build 2.1.25, D-09b/blocker
    # ke-4). Bukti forensik: ui_dumps\senarai_nombor_tidak_dijumpai.xml
    # didump TEPAT pada momen row_status_for_number() gagal -- skrin
    # SEBENAR ialah 'Hantar Kompaun' (tab BELUM HANTAR/DATA RALAT/HANTAR
    # SEMULA, teks 'TIADA DATA YANG BELUM DI HANTAR'), BUKAN Senarai.
    # ht.sync_all() tidak pernah menavigasi balik ke skrin utama selepas
    # Hantar Semula -- baris SETERUSNYA terus cuba baca sel NO AKAUN
    # Senarai drpd skrin Hantar itu sendiri, jadi SENTIASA pulang "sel
    # NO AKAUN tidak kelihatan" / status=None, walaupun Hantar sendiri
    # BERJAYA (status H, 0 ralat). Sama kelas bug dgn Fix#1 (19/8) --
    # modul/elemen dicari pada skrin yang salah -- cuma satu peringkat
    # lebih hilir (Hantar -> Senarai). Risiko RENDAH: pastikan_di_home()
    # ialah fungsi navigasi sedia ada yang SUDAH dipanggil di AWAL
    # fungsi ini sendiri (baris ~1142) tanpa isu; guard/dasar.py & trip-
    # wire OK LANGSUNG TIDAK disentuh.
    if not pastikan_di_home(pages.senarai.driver, pages):
        catat_peringkat("hantar", "GAGAL",
                        "tidak dapat kembali ke skrin utama selepas "
                        "Hantar Semula, sebelum semak status baris "
                        "(lihat pastikan_di_home, Fix#8)")
        return

    # >>> FIX #10 — DITAMBAH 2026-10-05 (run10, build 2.1.25). <<<
    # row_status_for_number() HANYA membaca baris yang SEDANG kelihatan
    # (find_number_and_tokens) -- ia tidak membuka Senarai dan tidak
    # mengenakan penapis tarikh + Semak. Selepas Fix#8 bawa app ke
    # skrin UTAMA, bacaan dibuat pada skrin utama -> 0 baris -> None
    # ("[AWALAN] Tiada baris sama sekali: masalah PENAPIS TARIKH").
    # Bukti run10: 73s kemudian peringkat_senarai (SK-001) jumpa rekod
    # yang SAMA dgn status H melalui open_senarai() +
    # ensure_records_listed(force=True). Rekod memang terhantar;
    # cek dibuat pada skrin yang salah. Laluan di bawah = salinan
    # TEPAT laluan SK-001 yang terbukti LULUS. Kriteria lulus (H/M)
    # TIDAK diubah.
    pages.home.open_senarai()
    # >>> FIX#18 (2026-10-08): sempitkan ke hari rekod sebelum Semak.
    pages.senarai.ensure_records_for(no_rekod, force=True)
    status = pages.senarai.row_status_for_number(no_rekod)
    ok = bool(status) and any(t in ("H", "M") for t in status)
    catat_peringkat("hantar", "LULUS" if ok else "GAGAL",
                    f"status baris {no_rekod} = {status}")
    tangkap_skrin(pages.senarai.driver, s["tag"], "05-status-hantar")


def peringkat_senarai(s, no_rekod, pages, catat_peringkat):
    """SK-001. Jangkaan TERBALIK berbanding fasa fill-only.

    Sepanjang fasa fill-only, senarai yang KOSONG ialah bukti kejayaan —
    ia bermakna tiada rekod dicipta. Di bawah mod sebenar ia sebaliknya:
    rekod MESTI kelihatan, dan senarai kosong bermakna sesuatu hilang.

    >>> FIX #8 — DITAMBAH 2026-10-01 (run8, build 2.1.25, blocker ke-4).
    Fungsi ini TIDAK PERNAH memanggil pastikan_di_home() di awalnya --
    tidak sekata dgn peringkat_hantar() yang sudah lama buat begitu
    (baris ~1142). Selepas Fix#8 di atas (peringkat_hantar) gagal pulih
    dgn bersih, atau selepas mana-mana peringkat lain tinggalkan skrin
    bukan-utama, open_senarai() di bawah akan cuba tap kad SENARAI pada
    skrin yang mungkin tiada kad itu langsung -- "Element not clickable
    after 15s" GENUIN (bukan scroll/locator salah), disahkan forensik
    run8 (skrin sebenar = 'Hantar Kompaun' semasa kegagalan ini).
    Risiko RENDAH, navigasi sahaja, laluan sedia ada digunakan semula.
    """
    print(f"\n  --- 3.5(6) SK-001 senarai — {no_rekod} ---")
    from devtools.smoke_tangga import pastikan_di_home
    sen = pages.senarai
    if not pastikan_di_home(sen.driver, pages):
        catat_peringkat("senarai", "GAGAL",
                        "tidak dapat kembali ke skrin utama sebelum "
                        "membuka Senarai (lihat pastikan_di_home, Fix#8)")
        return
    pages.home.open_senarai()
    # >>> FIX#18 (2026-10-08): sempitkan ke hari rekod sebelum Semak.
    # Rekod larian dicipta HARI INI, jadi penapis hari letak ia pada
    # halaman pertama -- tiada skrol diperlukan, dan carian tidak lagi
    # tersasar ke baris lama dalam jadual 10-baris.
    sen.ensure_records_for(no_rekod, force=True)
    jumpa = sen.find_number_and_tokens(no_rekod)
    catat_peringkat("senarai", "LULUS" if jumpa else "GAGAL",
                    f"{no_rekod} {'kelihatan' if jumpa else 'TIDAK kelihatan'} "
                    f"dalam Senarai Kompaun")
    tangkap_skrin(sen.driver, s["tag"], "06-sk001-senarai")


def cari_nombor_baharu(sen, huruf, no_lama, maks=40):
    """Nombor rekod yang WUJUD sekarang dan bukan yang lama.

    Kemaskini menjana nombor baharu tanpa memberitahu kita apa nombornya
    — ia hanya muncul dalam senarai. Kalau lebih daripada satu calon
    baharu wujud, kami tidak meneka: None dipulangkan dan peringkat itu
    dicatat GAGAL supaya pemilik melihatnya.
    """
    try:
        # >>> FIX#18 (2026-10-08): sempitkan ke hari rekod lama sebelum
        # Semak, supaya calon baharu berada pada halaman pertama.
        sen.ensure_records_for(no_lama, force=True)
        semua = sen.numbers_for_jenis(huruf, max_scrolls=maks) or []
    except Exception:                                           # noqa: BLE001
        return None
    calon = [n for n in semua if n and n != no_lama]
    if len(calon) != 1:
        # Senarai membawa rekod lain daripada larian terdahulu, jadi
        # "satu calon" jarang benar. Ambil yang tertinggi secara
        # leksikografi HANYA kalau ia lebih besar daripada nombor lama —
        # penomboran menaik, dan itu satu-satunya hubungan yang kami
        # boleh sandarkan.
        lebih = sorted(n for n in calon if n > no_lama)
        return lebih[-1] if lebih else None
    return calon[0]


def main(argv=None):
    ap = argparse.ArgumentParser(
        description="Runner E2E MBPG — cipta, serah, cetak.")
    ap.add_argument("--borang", required=True,
                    help="N, P, K, atau gabungan seperti NPK")
    ap.add_argument("--kuota", type=int, default=None,
                    help="had rekod untuk larian ini (selain kuota "
                         "dalam IZIN-E2E.txt, yang sentiasa terpakai)")
    ap.add_argument("--set", dest="set_id", default=None)
    ap.add_argument("--terus", action="store_true",
                    help="langkau pengesahan YA")
    ap.add_argument("--tanpa-printer", action="store_true",
                    help="teruskan walaupun printer tidak sedia")
    ap.add_argument("--mod-sebenar", action="store_true",
                    help="hidupkan MBPG_MOD_SEBENAR (kelulusan pemilik "
                         "2026-08-17) — membenarkan SERAH/HANTAR/"
                         "KEMASKINI/CETAK dalam konteks borang N/P/K-001 "
                         "dan aliran turunannya SAHAJA")
    ap.add_argument("--paksa-nk", action="store_true",
                    help="cuba TN/NK walaupun notis belum layak ditukar "
                         "(lalai: SKIP — lihat peringkat_tn_nk)")
    ap.add_argument("--kitaran", choices=("cipta", "penuh"), default="cipta",
                    help="'cipta' = isi+serah+cetak (lalai). "
                         "'penuh' = tambah kemaskini, TN/NK, hantar, "
                         "SK-001, P-006 (arahan 3.5)")
    args = ap.parse_args(argv)

    if args.kitaran == "penuh" and not args.mod_sebenar:
        print("HENTI: --kitaran penuh memerlukan --mod-sebenar. "
              "Peringkat kemaskini/hantar ialah mutasi, dan tanpa "
              "bendera itu corong akan menyekatnya di tengah kitaran — "
              "selepas rekod sebenar sudah wujud.")
        return 2

    senarai = urai_borang(args.borang)

    ok, sebab = sah_set(args.set_id)
    if not ok:
        print(f"HENTI: {sebab}")
        return 2

    try:
        izin = IzinE2E.baca(AKAR)
    except IzinTidakSah as e:
        print(f"HENTI: {e}")
        return 2

    r = izin.ringkasan()
    if r["luput"]:
        print(f"HENTI: {r['sebab_luput']}")
        return 2

    boleh = [h for h in senarai if izin.kuota.get(h, 0) > 0]
    if not boleh:
        print(f"HENTI: tiada kuota baki untuk {', '.join(senarai)} "
              f"(kuota: {r['kuota']})")
        return 2
    if args.kuota is not None:
        boleh = boleh[:max(0, args.kuota)]
    if not boleh:
        print("HENTI: --kuota 0 — tiada apa untuk dijalankan.")
        return 2

    if not minta_ya({
        "borang": " -> ".join(boleh),
        "set": args.set_id or "(lalai oracle)",
        "identiti": f"PENANDA UJIAN ('{PU.AWALAN} <TC> <cap masa>')",
        "mod sebenar": "HIDUP" if args.mod_sebenar else "mati",
        "kitaran": args.kitaran,
        "kuota dalam izin": r["kuota"],
        "izin luput": r["tarikh_luput"],
        "printer": "diperlukan" if not args.tanpa_printer else "diabaikan",
        "log rekod": os.path.relpath(rekod_log.laluan_log(), AKAR),
    }, args.terus):
        return 1

    from devtools import peringkat6 as P6
    from devtools.smoke_tangga import peringkat_1, peringkat_2
    from device_utils import resolve_udid
    from config import APP_PACKAGE

    serial = resolve_udid(APP_PACKAGE, verbose=False)
    p1 = peringkat_1(serial)
    if not p1["ok"]:
        print("HENTI: peringkat 1 gagal.")
        return 1
    P6.baseline_global = p1["baseline"]

    drv = None
    dicipta = []
    mula_sesi = time.strftime("%Y-%m-%d %H:%M:%S")
    # `konteks` dibina SEBELUM try supaya blok finally boleh mencetak
    # jejak peringkat walaupun larian mati sebelum sesi Appium wujud.
    # Jejak yang hanya wujud pada laluan berjaya ialah jejak yang tiada
    # apabila ia paling diperlukan.
    konteks = {"drv": None, "pages": None, "serial": serial, "jejak": []}
    try:
        drv, pages = peringkat_2()

        # >>> MOD SEBENAR DIHIDUPKAN DI SINI, SELEPAS SESI WUJUD. <<<
        # Ia ditetapkan pada objek Tetapan yang corong SUDAH pegang,
        # bukan melalui persekitaran. Sebabnya: `Tetapan` membaca
        # persekitaran SEKALI semasa dibina, jadi `os.environ[...] = "1"`
        # di sini tidak akan berkuat kuasa dan akan gagal SENYAP —
        # runner akan melaporkan mod sebenar HIDUP sementara corong
        # menyekat setiap mutasi.
        if args.mod_sebenar:
            drv.corong.tetapan.mod_sebenar = True
            print("\n" + "!" * 70)
            print("!! MBPG_MOD_SEBENAR = HIDUP")
            print("!! SERAH / HANTAR / SAHKAN / YA / OK / KEMASKINI / "
                  "CETAK dibenarkan")
            print("!! HANYA dalam konteks borang N/P/K-001 dan aliran "
                  "turunannya.")
            print("!! PADAM, HAPUS, dan SELARAS PELESEN kekal DILARANG "
                  "MUTLAK.")
            print("!" * 70)

        konteks["drv"], konteks["pages"] = drv, pages
        for huruf in boleh:
            dicipta.append(jalankan_satu(huruf, izin, args, konteks))
        return 0
    except BaseException as e:                                  # noqa: BLE001
        print(f"\n{'!' * 70}\n!! BERHENTI — {type(e).__name__}\n{'!' * 70}")
        print(str(e)[:2000])
        if not isinstance(e, (IzinTidakSah, SystemExit)):
            traceback.print_exc()
        print("\n  Borang seterusnya TIDAK dicuba.")
        return 1
    finally:
        # >>> DIKIRA DARI LOG, BUKAN DARI `dicipta`. <<<
        # `dicipta` hanya bertambah apabila jalankan_satu PULANG. Kalau
        # ia membangkitkan selepas rekod dicipta — tepat apa yang
        # berlaku pada 2026-08-17 13:43, di mana kemaskini melanggar
        # trip-wire selepas `PGP02N260817008` sudah wujud — senarai itu
        # kosong dan ringkasan mencetak "REKOD DICIPTA: 0".
        #
        # Melaporkan sifar rekod sedangkan satu hidup pada production
        # ialah kegagalan laporan yang paling teruk yang alat ini boleh
        # lakukan. Log rekod ditulis SEBELUM apa-apa yang boleh gagal,
        # jadi ia sumber kebenaran; `dicipta` hanya kitaran yang siap
        # sepenuhnya.
        semua_rekod = rekod_log.baca_semua()
        print("\n" + "=" * 70)
        print(f"== REKOD DICIPTA (dari log): {len(semua_rekod)}"
              f"   |   kitaran SIAP sepenuhnya: {len(dicipta)}")
        if len(semua_rekod) != len(dicipta):
            print("   NOTA: nombor dicipta tetapi kitarannya tidak "
                  "selesai — rekod TETAP hidup pada production.")
        print("=" * 70)
        for e in dicipta:
            print(f"  {e['tag']:<8} {e['no_rekod']}  siri {e['no_siri']}  "
                  f"cetak={'ya' if e['cetak_dihantar'] else 'GAGAL'}")
        jejak = konteks.get("jejak") or []
        if jejak:
            print("\n== JEJAK PERINGKAT (urutan SEBENAR yang app benarkan)")
            for j in jejak:
                print(f"  {j['tag']:<8} {j['peringkat']:<11} "
                      f"{j['status']:<17} {j.get('tempoh_s', 0):>7}s  "
                      f"{j['nota']}")
            try:
                lj = rekod_log.tulis_jadual_masa(
                    jejak, mula_sesi, time.strftime("%Y-%m-%d %H:%M:%S"))
                if lj:
                    print(f"\n  Jadual masa -> {os.path.relpath(lj, AKAR)}")
            except Exception as e:                              # noqa: BLE001
                print(f"  [MASA] jadual gagal ditulis ({type(e).__name__})")
        if semua_rekod:
            print(f"\n== NOMBOR REKOD DILOG: {len(semua_rekod)}")
            for rr in semua_rekod:
                print(f"  {str(rr['no_rekod']):<18} {rr['tc']:<8} "
                      f"{rr['status']:<18} {rr.get('asal') or ''}")
        # Berkunci pada LOG, bukan `dicipta` — atas sebab yang sama
        # seperti kiraan di atas.
        if semua_rekod:
            print(f"\n  Nombor di atas ialah rekod HIDUP pada production.")
            print(f"  Log untuk PM : "
                  f"{os.path.relpath(rekod_log.laluan_log(), AKAR)}")
            print(f"  Senarai: docs/FASA-C-REKOD.md | jejak: "
                  f"reports/E2E.jsonl")
        try:
            print(f"  Kuota baki: {izin.ringkasan()['kuota']}")
        except Exception:                                       # noqa: BLE001
            pass
        if drv is not None:
            c = getattr(drv, "corong", None)
            if c is not None:
                print(f"  [CORONG] {c.bil_tap} tap dinilai, "
                      f"{c.bil_sekat} disekat")
            try:
                drv.quit()
            except Exception:                                   # noqa: BLE001
                pass


if __name__ == "__main__":
    # >>> FIX#20 — LOG KE FAIL UNTUK PINTU MASUK INI JUGA. <<<
    # Arahan biasa pemilik ialah `run_penuh.py`, tetapi runner ini juga
    # boleh dijalankan terus. Import malas (bukan di kepala fail) kerana
    # run_penuh MENGIMPORT modul ini — import di peringkat atas akan
    # menghasilkan pusingan antara keduanya.
    if AKAR not in sys.path:
        sys.path.insert(0, AKAR)
    from tools.run_penuh import pasang_log_fail, akhiri_log
    pasang_log_fail(skrip="run_e2e")
    _kod = main()
    akhiri_log(_kod)
    sys.exit(_kod)

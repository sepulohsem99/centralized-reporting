"""
Hurai sel "Test Data" (C9) workbook MBJB menjadi struktur bernama.

KENAPA VERSI INI JAUH LEBIH KECIL DARIPADA VERSI MBIP
-----------------------------------------------------
Penghurai MBIP wujud kerana C9 MBIP ialah borang separa berstruktur penuh:

    PESALAH - Maklumat Pesalah
    Nama Pesalah: ALI
    No KP: 010123456789
    Maklumat Jalan: JALAN DANGA SUTERA 12/3
    ...

Ia perlu mengesan tajuk seksyen, kerana label "Maklumat Jalan" bermaksud
alamat pesalah di bawah PESALAH tetapi alamat tempat kesalahan di bawah
KOMPAUN. Jadual alias sepanjang 40 baris menormalkan label yang tidak
konsisten.

C9 MBJB TIDAK berbentuk itu. Disahkan dengan membaca kesemua 54 sel:

    25 sheet : "Refer to No Kompaun JB015P260227001"   (rujukan rekod run lama)
    15 sheet : "N/A"
     5 sheet : "Picture"
     5 sheet : blok bookmark (KETERANGAN KOD KOMPAUN / KOD AKTA / KESALAHAN)
     1 sheet : "epbt.mbjb.gov.my"                       (T-001)
     1 sheet : "License: 867382031575883"               (T-002)
     1 sheet : "Username:msc  Password:<kata-laluan: profil>"           (T-012)
     1 sheet : "ID Penguatkuasa: msc"                   (TN-001)

Tiada satu pun sel membawa blok PESALAH/KOMPAUN. Tiada seksyen untuk
dikesan, tiada label bertindih untuk dinyahkabur. Mengekalkan penghurai
MBIP di sini bermakna menyimpan 200 baris kod yang setiap cabangnya mati
— dan kod mati pada lapisan data ialah cara paling mudah untuk nilai
hantu masuk semula tanpa disedari.

Jadi fail ini menghurai HANYA empat bentuk yang benar-benar wujud, plus
satu pengelas bentuk. Ia dipanggil oleh tools/check_vs_excel.py supaya
pemeriksa membaca workbook melalui logik yang sama setiap kali.

PENTING: fail ini TIDAK menjana testdata/excel_data.py. excel_data.py
ditulis tangan dengan petikan sel. Penghurai ini hanya untuk PEMERIKSA,
supaya pemeriksa tidak pernah mempercayai komen dalam excel_data.py.
"""

import re

# ---------------------------------------------------------------------------
# Pengelas bentuk C9
# ---------------------------------------------------------------------------
# Urutan penting: 'rujukan_rekod' diuji sebelum yang lain kerana ia satu-
# satunya bentuk yang membawa nombor rekod, dan nombor itu TIDAK boleh
# disalahanggap sebagai data input.
_RX_RUJUKAN = re.compile(
    r'(?i)\brefer\s+to\b|\bJB015[NPKLS]\d{9}\b|\bJBM5[01][NPKLS]\d{9}\b')
_RX_KOSONG = re.compile(r'^\s*(n/?a|-)?\s*$', re.I)
_RX_LAMPIRAN = re.compile(r'^\s*picture\s*$', re.I)
_RX_BOOKMARK = re.compile(r'(?i)details\s+of\s+(first|second)\s+bookmark')
_RX_LESEN = re.compile(r'(?i)^\s*licen[cs]e\s*:\s*(\d{10,20})\s*$')
_RX_KREDENSIAL = re.compile(
    r'(?i)username\s*:?\s*(\S+)\s+password\s*:?\s*(\S+)')
_RX_AKAUN = re.compile(r'(?i)^\s*id\s*penguatkuasa\s*:\s*(\S+)\s*$')
# T-001 sahaja: sel mengandungi hos/IP tulen tanpa label.
_RX_IP = re.compile(
    r'^\s*((?:\d{1,3}\.){3}\d{1,3}(?::\d+)?|[a-z0-9.-]+\.[a-z]{2,}(?::\d+)?)\s*$',
    re.I)

# Label dalam blok bookmark -> nama medan kanonik.
_BOOKMARK_KEYS = {
    "KETERANGAN KOD KOMPAUN": "keterangan_kod_kompaun",
    "KOD AKTA": "kod_akta",
    "KESALAHAN KOMPAUN": "kesalahan_kompaun",
}

_RX_KEY = re.compile(r'^\s*([^:]{2,40}?)\s*:\s*(.+)$')

# ---------------------------------------------------------------------------
# Bentuk 'medan_berlabel' — DIPERKENALKAN oleh workbook _CORRECTED
# ---------------------------------------------------------------------------
# Sebelum pembetulan, C9 setiap sheet Daftar hanya menulis "Refer to No
# Kompaun JB015…" — rujukan kepada run manual Februari 2026, bukan nilai
# medan. Workbook yang dibetulkan menulis data ujian SEBENAR sebagai blok
# "Label: nilai" berbilang baris pada 12 sheet:
#
#     Nama Pesalah: Muhammad Saifullah bin Muhamad
#     Jalan: JALAN BAKAK (pilih dari dropdown; Taman/Poskod/… auto-isi)
#     Kadar Denda (RM): 600 (sahkan dalam julat app)
#
# Bentuknya SAMA seperti blok bookmark, jadi ia dihurai dengan _RX_KEY yang
# sama dan corak yang sama — bukan penghurai baharu.
#
# Kedua-dua jadual di bawah ialah SET TERTUTUP yang dibaca terus daripada
# workbook (12 sheet, 20 label unik, 5 nota unik — setiap baris padan
# _RX_KEY, sifar baris tercicir). Ia sengaja eksplisit dan bukan
# dinormalkan secara algoritma: nama medan kanonik ialah perbendaharaan
# kata KITA, dan pemetaan yang boleh dibaca mata lebih baik daripada
# penukaran snake_case yang boleh menghasilkan nama hantu secara senyap.
_MEDAN_KEYS = {
    "NAMA PESALAH":                     "nama_pesalah",
    "NAMA PEMILIK/SYARIKAT":            "nama_pemilik_syarikat",
    "JALAN":                            "jalan",
    # 2026-08-06: oracle memisahkan DUA jalan yang berlainan. Rekod
    # manual pemilik (JBM50P260806001, rekod PERTAMA yang disahkan
    # sampai ke DB utama) menunjukkan borang membawa jalan PESALAH dan
    # jalan PREMIS/NOTIS secara berasingan, dengan baris selaras yang
    # LENGKAP (poskod terisi) — itu bezanya daripada JALAN JAGONG 2
    # TEST yang barisnya tidak lengkap dan menyebabkan MASA TAMAT.
    "JALAN PESALAH":                    "jalan",
    "JALAN PREMIS/NOTIS":               "jalan_premis",
    "LOKASI KESALAHAN":                 "lokasi_kesalahan",
    "BUTIRAN KESALAHAN":                "butiran_kesalahan",
    # Sheet -004 (Kemaskini) melabelkan nilainya "(nilai baharu)" kerana
    # ia nilai GANTI. Ia dipetakan kepada nama medan yang SAMA, bukan
    # kepada nama bersuffiks: sheet -001 dan -004 sudah berasingan, jadi
    # "MBPG-TC-N-004!C9 -> lokasi_kesalahan" tidak boleh keliru dengan
    # "MBPG-TC-N-001!C9 -> lokasi_kesalahan". Suffiks `_baharu` pernah
    # dicuba dan ia mencipta nama yang TIDAK wujud di mana-mana lagi
    # dalam projek, jadi gerbang membandingkan nama yang berlainan dan
    # melaporkan "Excel senyap" untuk sel yang jelas bercakap.
    # "(nilai baharu)" ialah nota kepada pembaca, bukan medan lain.
    "LOKASI KESALAHAN (NILAI BAHARU)":  "lokasi_kesalahan",
    "BUTIRAN KESALAHAN (NILAI BAHARU)": "butiran_kesalahan",
    "KADAR DENDA (RM)":                 "kadar_denda",
    "AMAUN KOMPAUN (RM)":               "amaun_kompaun",
    "ARAHAN TINDAKAN":                  "arahan_tindakan",
    "NAMA PENERIMA":                    "nama_penerima",
    "NO. IC PENERIMA":                  "no_ic_penerima",
    # P-001. `no_kp_ssm` (kompaun_lesen_page) ialah medan LAIN pada borang
    # Lesen; sheet L-001 menulis "Nama Pemilik/Syarikat", bukan label ini.
    "NO. KP/SSM":                       "no_kp_ssm_kereta",
    "NO. KERETA":                       "no_kereta",
    "WARNA KERETA":                     "warna_kereta",
    "NO. CUKAI JALAN":                  "no_cukai_jalan",
    "NO. PETAK":                        "no_petak",
    "NO. KUPON":                        "no_kupon",
    "BARANG SITA":                      "barang_sita",
    "ULASAN":                           "ulasan",
}

# Nota dalam kurungan di HUJUNG nilai. Set tertutup — hanya lima rentetan
# ini wujud dalam workbook. Ia arahan kepada penguji, BUKAN sebahagian
# nilai yang ditaip ke aplikasi.
#
# Kenapa set tertutup dan bukan "buang apa-apa kurungan di hujung": nilai
# yang SAH boleh berakhir dengan kurungan — rantaian KESALAHAN membawa
# bentuk seperti "[SEKSYEN 30(2)] - MEMBINASAKAN…". Pembuangan pukul rata
# akan mencacatkan nilai sebenar secara senyap. Kalau workbook menambah
# nota baharu, ia akan kekal DALAM nilai dan gerbang akan menangkapnya —
# gagal-bising, bukan gagal-senyap.
_NOTA_DIKENALI = {
    "optional",
    "sahkan dalam julat app",
    "pilih dari dropdown; taman/poskod/bandar/negeri auto-isi",
    "taip dan pilih dari dropdown db",
    "tap mysikap; jalan/taman/bandar/poskod/negeri/jenis auto-isi",
}

# 2026-08-06: nota sel kini MEMBAWA MUATAN — oracle menulis
#   "(pilih dari dropdown; jangka auto-isi: Taman=BANDAR BARU UDA,
#     Bandar=JOHOR BAHRU, Poskod=81200)"
# Muatan itu berbeza bagi setiap jalan, jadi set rentetan tertutup tidak
# lagi memadai. Padanan bertukar kepada AWALAN: perbendaharaan katanya
# masih tertutup (hanya lima pembuka di bawah yang diterima sebagai nota),
# tetapi ekornya bebas. Nota yang TIDAK bermula dengan salah satu daripada
# ini kekal DALAM nilai supaya gerbang menangkapnya — gagal-bising.
_NOTA_AWALAN = (
    "optional",
    "sahkan dalam julat app",
    "pilih dari dropdown",
    "taip dan pilih dari dropdown",
    "tap mysikap",
)

_RX_NOTA_HUJUNG = re.compile(r'\s*\(([^()]*)\)\s*$')

# Berapa baris berlabel-DIKENALI sebelum sel dikira bentuk ini.
#
# Ditetapkan 2 mula-mula, atas tanggapan sel satu-baris patut kekal milik
# bentuk khusus (lesen/akaun/ip). Workbook menolaknya: NK-001 ialah
# `'Amaun Kompaun (RM): 500'` dan NK-002 ialah
# `'Ulasan: Ujian automasi Ustaz'` — satu baris setiap satu, label dalam
# jadual, dan bentuknya memang bentuk ini. Ambang itu akan meninggalkan
# dua TC tanpa data atas sebab yang direka, bukan sebab yang diukur.
#
# SATU adalah selamat kerana bentuk ini diuji TERAKHIR dan labelnya SET
# TERTUTUP: sel yang dituntut mestilah sel yang tiada bentuk lain
# menuntutnya DAN membawa label yang kita sendiri senaraikan.
_MIN_BARIS_MEDAN = 1


def classify(cell):
    """Pulangkan bentuk sel C9: satu daripada
    'rujukan_rekod' | 'kosong' | 'lampiran' | 'bookmark' |
    'lesen' | 'kredensial' | 'akaun' | 'ip' | 'medan_berlabel' |
    'tidak_dikenali'.

    Bentuk menentukan sama ada sel itu boleh langsung menjadi data input.
    Hanya 'bookmark', 'lesen', 'kredensial', 'akaun', 'ip' dan
    'medan_berlabel' boleh.
    """
    s = "" if cell is None else str(cell)
    if _RX_BOOKMARK.search(s):
        return "bookmark"
    if _RX_RUJUKAN.search(s):
        return "rujukan_rekod"
    if _RX_KOSONG.match(s):
        return "kosong"
    if _RX_LAMPIRAN.match(s):
        return "lampiran"
    if _RX_LESEN.match(s):
        return "lesen"
    if _RX_KREDENSIAL.search(s):
        return "kredensial"
    if _RX_AKAUN.match(s):
        return "akaun"
    if _RX_IP.match(s):
        return "ip"
    # DIUJI TERAKHIR, dengan sengaja: bentuk ini hanya boleh menuntut sel
    # yang tiada bentuk lain menuntutnya. Kesemua 12 sel yang dipadaninya
    # dahulunya 'tidak_dikenali', jadi ia tidak boleh mengubah klasifikasi
    # sedia ada.
    if _bilang_baris_medan(s) >= _MIN_BARIS_MEDAN:
        return "medan_berlabel"
    return "tidak_dikenali"


def _bilang_baris_medan(s):
    """Bilangan baris berbentuk "Label: nilai" dengan label DIKENALI."""
    n = 0
    for baris in str(s).splitlines():
        m = _RX_KEY.match(baris.strip())
        if m and m.group(1).strip().upper() in _MEDAN_KEYS:
            n += 1
    return n


def parse(cell):
    """Sel C9 -> {medan: nilai}. Dict KOSONG bermakna sel itu tidak
    membekalkan satu pun nilai medan borang — bukan bermakna gagal
    hurai. Pemanggil mesti membezakan kedua-duanya melalui classify().
    """
    s = "" if cell is None else str(cell)
    bentuk = classify(s)

    if bentuk == "bookmark":
        return _parse_bookmark(s)
    if bentuk == "lesen":
        return {"lesen_aplikasi": _RX_LESEN.match(s).group(1)}
    if bentuk == "kredensial":
        m = _RX_KREDENSIAL.search(s)
        return {"username": m.group(1), "password": m.group(2)}
    if bentuk == "akaun":
        return {"id_penguatkuasa": _RX_AKAUN.match(s).group(1)}
    if bentuk == "ip":
        return {"ip_address": s.strip()}
    if bentuk == "medan_berlabel":
        return _parse_medan_berlabel(s)
    # rujukan_rekod / kosong / lampiran / tidak_dikenali tidak membawa
    # satu pun nilai medan borang.
    return {}


def _parse_bookmark(s):
    """Blok "DETAILS OF FIRST/SECOND BOOKMARK" -> bookmark_1_* / bookmark_2_*.

    Nombor blok datang daripada baris tajuk, bukan daripada kedudukan,
    kerana satu sheet (P-005) menulis "BOOKMARKS" dengan 's' dan sheet
    lain meninggalkan baris kosong yang berbeza bilangan.
    """
    out = {}
    blok = 0
    for baris in s.splitlines():
        t = baris.strip()
        if not t:
            continue
        m = _RX_BOOKMARK.search(t)
        if m:
            blok = 1 if m.group(1).lower() == "first" else 2
            continue
        m = _RX_KEY.match(t)
        if not m or not blok:
            continue
        kunci = _BOOKMARK_KEYS.get(m.group(1).strip().upper())
        if kunci:
            # Nilai pertama menang: sheet tidak pernah mengulang label
            # dalam blok yang sama, tetapi kalau ia berlaku, yang di atas
            # ialah data sebenar.
            out.setdefault(f"bookmark_{blok}_{kunci}", m.group(2).strip())
    return out


def _pisah_nota(nilai):
    """"600 (sahkan dalam julat app)" -> ("600", "sahkan dalam julat app").

    Nota dibuang HANYA kalau ia dalam _NOTA_DIKENALI. Kalau tidak, nilai
    dipulangkan utuh dan nota kosong — nota tak dikenali kekal DALAM nilai
    supaya gerbang menangkapnya, bukan supaya ia hilang senyap.
    """
    nilai = (nilai or "").strip()
    m = _RX_NOTA_HUJUNG.search(nilai)
    if not m:
        return nilai, ""
    _isi = m.group(1).strip().lower()
    if not _isi.startswith(_NOTA_AWALAN):
        return nilai, ""
    return nilai[:m.start()].strip(), m.group(1).strip()


def _parse_medan_berlabel(s):
    """Blok "Label: nilai" berbilang baris -> {medan_kanonik: nilai}.

    Corak sama seperti _parse_bookmark(): _RX_KEY setiap baris, label
    dipadan pada jadual tertutup, label tak dikenali DIABAIKAN (bukan
    diteka). Nilai pertama menang kalau satu label berulang.
    """
    out = {}
    for baris in str(s).splitlines():
        t = baris.strip()
        if not t:
            continue
        m = _RX_KEY.match(t)
        if not m:
            continue
        kunci = _MEDAN_KEYS.get(m.group(1).strip().upper())
        if not kunci:
            continue
        nilai, _nota = _pisah_nota(m.group(2))
        if nilai:
            out.setdefault(kunci, nilai)
    return out


def nota_medan_berlabel(cell):
    """{medan_kanonik: nota} untuk blok 'medan_berlabel'.

    Nota ialah arahan kepada penguji, bukan data input — "(optional)",
    "(sahkan dalam julat app)", "(tap MySIKAP; … auto-isi)". Ia dipisahkan
    supaya gerbang boleh menuntutnya kekal betul, dan supaya laporan boleh
    menerangkan KENAPA satu medan dibiarkan kosong atau disahkan pada
    runtime dan bukannya dibandingkan dengan nilai tetap.
    """
    out = {}
    for baris in str(cell or "").splitlines():
        m = _RX_KEY.match(baris.strip())
        if not m:
            continue
        kunci = _MEDAN_KEYS.get(m.group(1).strip().upper())
        if not kunci:
            continue
        _nilai, nota = _pisah_nota(m.group(2))
        if nota:
            out.setdefault(kunci, nota)
    return out


def nombor_rekod_dalam(cell):
    """Senarai nombor rekod yang disebut dalam sel — untuk laporan sahaja.

    JANGAN gunakan nilai ini sebagai sasaran open_record_by_number().
    Ia rekod yang dicipta oleh penguji manual pada Februari 2026 pada
    pangkalan data mereka; suite ini mesti membuka rekod yang IA SENDIRI
    cipta pada run semasa (PERATURAN KERAS #7).
    """
    s = "" if cell is None else str(cell)
    return re.findall(r'\b(?:JB015|JBM5[01])[NPKLS]\d{9}\b', s)


def nama_sheet_ternormal(nama):
    """Nama sheet -> bentuk ternormal untuk padanan.

    Workbook V2.1.33 mempunyai whitespace tidak konsisten pada 11 nama
    sheet (' MBPG-TC-N-006', 'MBPG-TC-P-002 ', …). Setiap padanan nama
    sheet dalam projek ini mesti melalui fungsi ini.
    """
    return str(nama or "").strip().upper()


_RX_JANGKA = re.compile(r'(?i)(taman|bandar|poskod|negeri)\s*=\s*([^,;)]+)')


def jangkaan_autoisi(cell):
    """{medan_jalan: {taman/bandar/poskod/negeri: nilai}} daripada nota sel.

    Oracle 2026-08-06 menulis nilai auto-isi yang DIJANGKA di dalam nota
    setiap baris jalan, diambil daripada skrin rekod manual pemilik
    (JBM50P260806001 — rekod pertama yang disahkan sampai ke DB utama).
    Nilai itu menjadikan bacaan auto-isi boleh DIASSERT, bukan sekadar
    direkod: kalau app memberi sesuatu yang lain, itu penemuan.
    """
    out = {}
    for baris in str(cell or "").splitlines():
        m = _RX_KEY.match(baris.strip())
        if not m:
            continue
        kunci = _MEDAN_KEYS.get(m.group(1).strip().upper())
        if kunci not in ("jalan", "jalan_premis"):
            continue
        _n, nota = _pisah_nota(m.group(2))
        jangka = {k.lower(): v.strip()
                  for k, v in _RX_JANGKA.findall(nota or "")}
        if jangka:
            out[kunci] = jangka
    return out

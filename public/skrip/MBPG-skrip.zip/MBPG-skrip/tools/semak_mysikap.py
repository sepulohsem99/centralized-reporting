"""
PENGESAN D-09 — carian mySIKAP gagal senyap / identiti melekat.

Automasi melaporkan K-001 LULUS pada 2026-08-18 untuk rekod yang
pemeriksaan manusia kemudian tolak. Sebabnya boleh dinamakan dengan
tepat: setiap penegasan bertanya "adakah medan ini TERISI?", dan nama
pemilik yang melekat dari rekod terdahulu memang terisi. Tiada apa-apa
membandingkan identiti yang disimpan dengan plat yang dipohon.

Modul ini menambah perbandingan itu. Ia membaca DB peranti sahaja —
tiada Appium, tiada tulis.

DUA TANDA
---------
(a) CARIAN GAGAL      `namapesalah` == `nokereta`.
    Apabila mySIKAP tidak memulangkan apa-apa, app menulis nombor plat
    ke dalam medan nama pesalah. `PGP02K260813002` menunjukkan ini:
    namapesalah='JYX6605', jeniskereta='', warnakereta=''.

(b) IDENTITI MELEKAT  identiti sama pada plat BERBEZA.
    Lebih serius: tiada ralat, kompaun kelihatan sah, dan ia menamakan
    orang yang salah.

HAD YANG MESTI DIFAHAMI
-----------------------
(b) hanya boleh dikesan apabila rekod menggunakan plat BERBEZA. Kalau
suite mencipta empat kompaun K dengan plat yang SAMA, identiti berulang
adalah BETUL dan pengesan ini akan — dengan tepat — mendiamkan diri.
Ia akan melaporkan bahawa ujian itu tidak dijalankan, bukan bahawa ia
lulus. Gerbang yang tidak boleh gagal bukan gerbang.
"""

import os
import sqlite3
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
AKAR = os.path.dirname(HERE)
sys.path.insert(0, AKAR)

JADUAL = "local_ekpn_tawaran_kompaun"


def _sulit(t):
    if not t:
        return t
    t = str(t)
    return t[:2] + "*" * max(0, len(t) - 4) + t[-2:] if len(t) > 4 \
        else "*" * len(t)


def baca_rekod_k(db, hanya=None):
    """Rekod letak kereta (jenis 'K') yang mempunyai nombor kenderaan."""
    c = sqlite3.connect(db)
    try:
        baris = c.execute(
            "SELECT nokompaun, nokereta, namapesalah, noakaun, "
            "jeniskereta, warnakereta FROM %s "
            "WHERE nokereta IS NOT NULL AND TRIM(nokereta) <> '' "
            "ORDER BY nokompaun" % JADUAL).fetchall()
    finally:
        c.close()
    keluar = []
    for no, kereta, nama, akaun, jenis, warna in baris:
        if hanya and no not in hanya:
            continue
        keluar.append({
            "no": no, "kereta": (kereta or "").strip(),
            "nama": (nama or "").strip(), "akaun": (akaun or "").strip(),
            "jenis": (jenis or "").strip(), "warna": (warna or "").strip(),
        })
    return keluar


def kesan(rekod):
    """Pulangkan (dapatan, boleh_uji_b).

    `boleh_uji_b` False bermakna tanda (b) TIDAK DIUJI kerana semua plat
    sama — bukan bermakna ia lulus.
    """
    dapatan = []
    for r in rekod:
        if r["nama"] and r["nama"].upper() == r["kereta"].upper():
            dapatan.append({
                "tanda": "a", "no": r["no"],
                "mesej": "namapesalah == nokereta (%s) — carian mySIKAP "
                         "tidak memulangkan pemilik" % r["kereta"],
            })
        elif not r["nama"]:
            dapatan.append({
                "tanda": "a", "no": r["no"],
                "mesej": "namapesalah KOSONG untuk plat %s" % r["kereta"],
            })

    plat = {r["kereta"].upper() for r in rekod}
    boleh_uji_b = len(plat) > 1
    if boleh_uji_b:
        # Kunci identiti: no. KP lebih dipercayai daripada nama, tetapi
        # nama digunakan bila KP tiada.
        oleh_identiti = {}
        for r in rekod:
            kunci = (r["akaun"] or r["nama"]).upper()
            if not kunci or kunci == r["kereta"].upper():
                continue
            oleh_identiti.setdefault(kunci, []).append(r)
        for kunci, kump in oleh_identiti.items():
            plat_kump = {x["kereta"].upper() for x in kump}
            if len(plat_kump) > 1:
                dapatan.append({
                    "tanda": "b", "no": ", ".join(x["no"] for x in kump),
                    "mesej": "identiti SAMA (%s) pada plat BERBEZA %s — "
                             "butiran pemilik terdahulu melekat"
                             % (_sulit(kunci), sorted(plat_kump)),
                })
    return dapatan, boleh_uji_b


def lapor(db, hanya=None):
    """Cetak keputusan. Pulangkan bilangan dapatan."""
    rekod = baca_rekod_k(db, hanya=hanya)
    print()
    print("== SEMAK D-09 (mySIKAP) — %d rekod K ==" % len(rekod))
    if not rekod:
        print("   tiada rekod letak kereta untuk diperiksa")
        return 0
    for r in rekod:
        print("   %s  plat=%-9s nama=%-14s jenis=%s"
              % (r["no"], r["kereta"], _sulit(r["nama"]) or "(kosong)",
                 r["jenis"] or "(kosong)"))
    dapatan, boleh_b = kesan(rekod)
    print()
    if not boleh_b:
        print("   (b) TIDAK DIUJI — semua rekod guna plat yang sama.")
        print("       Identiti berulang pada plat sama adalah BETUL.")
        print("       Untuk menguji (b): perlu >=2 plat BERBEZA yang sah "
              "pada mySIKAP.")
    if not dapatan:
        print("   TIADA tanda D-09 dikesan%s."
              % ("" if boleh_b else " bagi tanda (a)"))
        return 0
    for d in dapatan:
        print("   [D-09%s] %s" % (d["tanda"], d["no"]))
        print("            %s" % d["mesej"])
    return len(dapatan)


def main():
    import argparse
    p = argparse.ArgumentParser(description="Pengesan D-09 (baca-sahaja).")
    p.add_argument("--db", help="snapshot DB; lalai tarik dari peranti")
    p.add_argument("--hanya", nargs="*", help="hadkan kepada nombor rekod ini")
    args = p.parse_args()
    db = args.db
    if not db:
        from config import APP_PACKAGE
        from device_utils import resolve_udid
        from devtools.smoke_tangga import tarik_db
        db = tarik_db(resolve_udid(APP_PACKAGE, verbose=False),
                      os.path.join(AKAR, "data", "tmp", "semak_mysikap.db"))
    return 1 if lapor(db, hanya=args.hanya) else 0


if __name__ == "__main__":
    sys.exit(main())

"""SWEEP P — Daftar Kompaun Pelbagai, tiga dropdown sahaja.

Fill-only: TANPA medan pesalah, TANPA kamera, TANPA tandatangan, TANPA
serah. Lihat pages/sweep_kombo.py untuk skop dan sebabnya.

Borang ini ialah sasaran UTAMA sweep: 265 set (256 laluan penuh + 9 set
negatif), dan tiga dropdown berada terus pada tab Kompaun tanpa perlu
melalui tab Pesalah — tidak seperti borang N (lihat nota halangan dalam
tests/menu_notis/test_n001_sweep.py).

    pytest tests/menu_pelbagai --kk 01
    pytest tests/menu_pelbagai --borang P            # kesemua 265
    pytest tests/menu_pelbagai --jangkaan AMBIGU
"""

from tests.sweep_kongsi import (jalankan_sweep, matrix,   # noqa: F401
                                parametrize_sets, sedia_borang_kompaun)


def pytest_generate_tests(metafunc):
    parametrize_sets(metafunc, "P")


def test_sweep_kombo_pelbagai(logged_in, pages, set_kombo, matrix):
    sedia_borang_kompaun(pages, "Kompaun Pelbagai")
    jalankan_sweep(pages.daftar_kompaun, set_kombo, "P", matrix)

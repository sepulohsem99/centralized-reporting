"""
Badan sweep yang dikongsi oleh ketiga-tiga menu.

Satu test parametrized per menu, BUKAN 330 salinan skrip. Perbezaan
antara ketiga-tiga menu hanyalah (a) borang mana dibuka dan (b) page
object mana memandunya — semua yang lain identik, jadi ia hidup di sini.
"""

import pytest

from pages.sweep_kombo import TAJUK_MATRIX, sapu_satu_set
from reports.matrix import Matrix
from testdata import sets_loader


def id_set(s):
    return s["set_id"]


def parametrize_sets(metafunc, huruf_borang):
    """Cangkuk pytest_generate_tests untuk satu borang.

    Senarai kosong TIDAK diserahkan kepada metafunc.parametrize() secara
    telanjang. Set parameter kosong menyebabkan pytest mengutip satu
    item pengganti bernama `[NOTSET]` dengan sebab langkau lalainya
    ("got empty parameter set"). Item itu memang dilangkau — tetapi ia
    kelihatan seperti test sweep sebenar dalam output, dan sebab
    langkaunya tidak memberitahu sesiapa APA yang perlu dilakukan.

    Pada suite yang memandu production, "3 tests collected" apabila
    jawapan sebenarnya "kau belum pilih apa-apa" adalah output yang
    salah. Jadi kami melangkau secara eksplisit, dengan arahan.
    """
    if "set_kombo" not in metafunc.fixturenames:
        return
    sets = sets_loader.set_untuk(metafunc.config, huruf_borang)
    if not sets:
        if sets_loader.ada_penapis(metafunc.config):
            sebab = (f"tiada set borang {huruf_borang} sepadan dengan "
                     f"penapis yang diberi")
        else:
            sebab = ("TIADA SET DIPILIH — sweep memerlukan pemilihan "
                     "EKSPLISIT. Guna --kk / --set / --borang / "
                     "--jangkaan. Contoh: pytest tests --kk 01. "
                     "(330 set dalam skop tidak boleh bermula hanya "
                     "kerana `pytest` ditaip.)")
        metafunc.parametrize(
            "set_kombo",
            [pytest.param(None, marks=pytest.mark.skip(reason=sebab),
                          id="tiada-set-dipilih")])
        return
    metafunc.parametrize("set_kombo", sets, ids=[id_set(s) for s in sets])


def sedia_borang_kompaun(pages, jenis):
    """Bawa app ke borang Daftar Kompaun yang betul, sekali sahaja.

    Sweep memandu ratusan set berturut-turut pada borang yang SAMA.
    Membuka semula borang untuk setiap set akan menggandakan masa
    peranti tanpa menambah bukti — dropdown ditetapkan semula oleh
    pemilihan tingkat 1 yang seterusnya. Jadi kami hanya membuka kalau
    kami belum berada di sana.

    Tiada rekod dicipta oleh pembukaan borang: 'Daftar Kompaun' sebagai
    MENU dibenarkan secara eksplisit (arahan pemilik) — yang diharamkan
    ialah pengesahan akhir.

    >>> TAB PESALAH MESTI DIISI DAHULU — DISAHKAN PADA DEVICE
    2026-08-11. <<<
    Versi pertama membuka borang lalu menyerahkannya terus kepada
    dropdown, atas andaian bahawa dropdown tab KOMPAUN boleh dicapai
    tanpa melalui tab PESALAH. Pengesahan pra-sweep membuktikan
    sebaliknya, dengan app bercakap sendiri:

        (a) dropdown-terus tanpa Pesalah: DISEKAT
            (app: 'Maklumat Tidak Lengkap')

    App menguatkuasakan urutan tab. Tanpa langkah ini, sweep akan
    gagal 284 kali atas SATU sebab, dan 284 kegagalan itu akan
    kelihatan seperti 284 dapatan berasingan dalam matrix.

    Pesalah diisi dengan MINIMUM yang diperlukan, menggunakan sauh
    alamat berposkod yang dipilih automatik (lihat
    testdata/sauh_alamat.py). Poskod tidak pernah ditaip — ia mesti
    datang dari auto-isi app, yang merupakan sebahagian daripada apa
    yang sweep uji.
    """
    p = pages.daftar_kompaun
    if p.is_daftar_kompaun_screen_displayed():
        return
    pages.home.open_daftar_kompaun()
    if jenis == "Kompaun Letak Kereta":
        p.select_jenis_kompaun_letak_kereta()
    else:
        p.select_jenis_kompaun(jenis)
    isi_pesalah_minimum(p)


def data_pesalah_minimum(db=None):
    """Medan pesalah paling sedikit yang melepasi gerbang urutan tab.

    Jalan datang dari sauh berposkod-wujud; taman/poskod/bandar/negeri
    SENGAJA tiada — app mengisinya sendiri selepas jalan dipilih, dan
    menaipnya akan menopengkan bug auto-isi (keputusan pemilik
    2026-08-05).
    """
    import os
    from testdata import sauh_alamat
    if db is None:
        db = os.path.join("data", "tmp", "sauh.db")
    alamat, _ = sauh_alamat.pilih(db)
    return {
        "nama_pesalah": "AUTOTEST SWEEP",
        "no_kp_ssm_kereta": "000000000000",
        "jalan": alamat["jalan"],
        "poskod_dijangka": alamat["poskod_dijangka"],
        # Medan tab KOMPAUN. Diperlukan, bukan hiasan — lihat
        # isi_pesalah_minimum(). Jalan yang sama diguna semula supaya
        # hanya SATU sauh alamat wujud dalam keseluruhan laluan sweep.
        "jalan_premis": alamat["jalan"],
        "kompaun_jalan_partial": " ".join(alamat["jalan"].split()[:2]),
        "kompaun_jalan_suggestion": alamat["jalan"],
        "kompaun_jalan": alamat["jalan"],
        "lokasi_kesalahan": "AUTOTEST LOKASI",
        "butiran_kesalahan": "AUTOTEST BUTIRAN",
    }


def isi_pesalah_minimum(p, data=None):
    """Isi Pesalah, kemudian pindah ke tab KOMPAUN melalui BAR TAB.

    Bar tab, bukan SETERUSNYA: butang itu berada di bawah lipatan dan
    borang ini tidak boleh di-swipe untuk sampai kepadanya — swipe di
    sini menukar TAB, bukan menatal. Gerbang urutan tab app kekal
    dikuatkuasakan; kami tidak memintasnya.
    """
    import time
    data = data or data_pesalah_minimum()
    p.fill_pesalah_tab(data)
    p.wait_and_tap(p.TAB_KOMPAUN)
    time.sleep(1.5)

    # >>> TAB KOMPAUN JUGA MESTI DIISI. DISAHKAN 2026-08-11. <<<
    # Melangkaunya gagal DUA kali berturut-turut, kedua-duanya
    # identik:
    #     "borang tidak kembali selepas tingkat 3 (TIER3_CONFIRM
    #      tidak kelihatan walaupun selepas skrol)"
    # sedangkan P-001 — yang mengisi tab ini sebelum dropdown —
    # lulus penuh dengan ketiga-tiga dropdown disahkan baca-balik.
    #
    # Punca yang munasabah: dengan tab KOMPAUN kosong, penanda
    # pengesahan tingkat 3 berada di luar viewport, dan satu-satunya
    # cara kod cuba mencapainya ialah SKROL — yang pada borang ini
    # menukar TAB dan bukan menatal. Mengisi tab ini dahulu meletakkan
    # penanda itu dalam pandangan.
    p.fill_kompaun_tab(data)
    return data


@pytest.fixture(scope="session")
def matrix():
    m = Matrix(pengepala=TAJUK_MATRIX)
    yield m
    print(f"\n  [MATRIX] {m.ringkasan()}")


def jalankan_sweep(page, set_kombo, borang, matrix, nota_awal=""):
    """Satu set. Kegagalan set dicatat dan TIDAK menggagalkan test —
    kecuali DryRunViolation/RestoreGagal, yang menembusi dan membatalkan
    run (kedua-duanya BaseException, jadi `except Exception` di mana-mana
    tidak dapat menelannya).

    Kenapa set yang gagal tidak menggagalkan test: sweep ini pengumpul
    BUKTI, bukan gerbang lulus/gagal. Satu kombinasi yang app tolak
    adalah dapatan yang perlu direkod dalam MATRIX, bukan sebab untuk
    membuang 300 kombinasi yang belum diuji.
    """
    kep = sapu_satu_set(page, set_kombo, borang)
    if nota_awal:
        # Didahulukan supaya laluan navigasi kelihatan sebelum apa-apa
        # catatan kegagalan — pembaca MATRIX perlu tahu borang berada
        # dalam keadaan APA sebelum mentafsir keputusan.
        kep.catatan = (f"laluan={nota_awal}"
                       + (" | " + kep.catatan if kep.catatan else ""))
    matrix.tambah(kep.sebagai_baris())
    print(f"  [SWEEP {borang}] {kep.set_id} "
          f"kompaun={kep.kompaun_ok or '-'} akta={kep.akta_ok or '-'} "
          f"kesalahan={kep.kesalahan_ok or '-'} denda={kep.denda or '-'} "
          f"{kep.catatan}")
    return kep

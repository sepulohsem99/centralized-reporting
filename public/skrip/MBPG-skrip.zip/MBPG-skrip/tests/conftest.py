"""
conftest MBJB — fixture sesi dikongsi, susunan collection, dan jadual
ringkasan List-to-Test.

Diport dari MBIP v3 (terbukti pada puluhan run sebenar). Perbezaan MBJB
ditanda dengan komen "# MBJB:".

Rantaian fixture (skop sesi, semantik show-stopper v2/v3 dikekalkan):
    driver -> pages -> pelarasan_results -> logged_in
- pelarasan_results menjalankan keseluruhan urutan Menu Selaras SEKALI
  dan merekod verdict per-item untuk MBPG-TC-T-001..T-011; setiap fail
  test T meng-assert verdict itemnya sendiri, jadi satu sync yang gagal
  tidak menyembunyikan yang lain.
- logged_in melakukan login (dengan tangga retry/relaunch login()
  sendiri). Kalau ia raise, pytest melaporkan setiap test hiliran
  sebagai ERROR tanpa menjalankannya — tiada apa berfungsi tanpa sesi.

Verdict pelarasan ialah tuple (ok, mesej) dengan TIGA keadaan:
    ok is True   -> lulus
    ok is False  -> gagal
    ok is None   -> DILANGKAU (skip jujur), cth item sengaja tidak
                    dijalankan. PERATURAN KERAS #6: SKIP jujur > PASS
                    palsu — MBIP memalsukan PASS di sini, MBJB tidak.

Susunan collection = susunan 'List to Test' Excel MBJB V2.1.33
(testdata.excel_data.TC_ORDER), tanpa mengira abjad nama fail.

pytest_terminal_summary mencetak satu baris akhir
"MBPG-TC-X-00N | nama | OUTCOME" bagi setiap TC yang di-collect, dalam
susunan List-to-Test.
"""

import os
import re
import sys
import time as _time

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

import pytest

from appium import webdriver
from appium.options.android import UiAutomator2Options

from config import (
    APPIUM_URL,
    DEVICE_NAME,
    PLATFORM_NAME,
    APP_PACKAGE,
    APP_ACTIVITY,
    AUTOMATION_NAME,
    IMPLICIT_WAIT,
    TESTER_NAME,
    # Tetapan per-PBT: datang dari profil aktif (profiles/*.json), bukan
    # dari excel_data (yang kekal sebagai rekod apa yang Excel MBJB kata).
    LICENSE_SETTINGS,
    TEST_CREDENTIALS,
    PROFILE_NAME,
    PROFILE_LABEL,
    RECORD_PREFIX,
    PBT,
    ENV,
)
import profile as _profile
from device_utils import (resolve_udid, app_version, device_model,
                          lapor_lesen_dan_imei)

# Metadata run ditangkap semasa driver dicipta dan dipancarkan ke dalam
# results.json, supaya dashboard boleh melaporkan peranti MANA dan build
# app MANA yang menghasilkan sesuatu keputusan — bukan nombor build
# hardcode yang sudah basi.
_RUN_META = {}

# Sesi berkawal yang aktif, supaya pytest_terminal_summary boleh membaca
# kiraan corong tanpa fixture (ringkasan berjalan selepas fixture sesi
# sudah dirobohkan). Senarai, bukan pembolehubah global, supaya ia boleh
# ditulis dari dalam fungsi tanpa `global`.
_DRIVER_AKTIF = []

from pages.login_page import LoginPage
from pages.pelarasan_page import PelarasanPage
from pages.home_page import HomePage
from pages.notis_amaran_page import NotisAmaranPage
from pages.daftar_kompaun_page import DaftarKompaunPage
from pages.notis_kompaun_page import NotisKompaunPage
from pages.senarai_page import SenaraiPage
from pages.hantar_page import HantarPage
from pages.serah_page import SerahPage
from pages.kemaskini_page import KemaskiniPage
from pages.kompaun_lesen_page import KompaunLesenPage
from pages.bookmark_page import BookmarkPage
from pages.sitaan_page import SitaanPage
# >>> DIBETULKAN 2026-09-13. <<<
# Nota lama di sini (arahan pemilik 2026-08-07: pencetak luar skop,
# modul tidak disalin) SUDAH LAPUK -- pages/cetak_page.py WUJUD dalam
# fork ini sejak 2026-08-13/2026-09-10, dan pemilik mengesahkan 2026-
# 09-10 "printer sentiasa ready" (skop pencetak tidak lagi disekat).
# CetakPage diimport di sini bukan untuk mencetak (cetak_rekod() masih
# sengaja belum diport -- lihat nota dalam fail itu), tetapi kerana
# pastikan_di_home() (devtools/smoke_tangga.py, Fix #4) perlu
# tutup_popup_cetak() untuk menutup popup 'CETAK NOTIS AMARAN ?' yang
# tersekat selepas SERAH/kemaskini (bukti forensik 2026-09-10).
from pages.cetak_page import CetakPage

from guard import corong as _corong
from guard.dasar import DryRunViolation                       # noqa: F401

from testdata import skop
from testdata import sets_loader as _sets
from testdata.skop import (
    TC_LIST,
    TC_ORDER,
    TC_NAMES,
)


def pytest_addoption(parser):
    """Flag pemilihan set kombo (--kk / --set / --borang / --jangkaan /
    --n-penuh). Ditakrif dalam testdata/sets_loader.py supaya satu sahaja
    tempat mengetahui bentuknya."""
    _sets.tambah_opsyen(parser)


# ============================================================================
# GERBANG SASARAN STAGING — dalam conftest.py, bukan check_env.bat sahaja
#
# cuakKambing (audit 2026-07-31): gerbang IP lama hidup HANYA dalam
# check_env.bat:355-390. `python -m pytest tests\ -v -s` — arahan yang
# CLAUDE.md kita sendiri dokumenkan — memintasnya SEPENUHNYA. Risiko bukan
# ujian gagal: ia mencipta rekod kompaun SEBENAR pada epbt.mbjb.gov.my
# (production MBJB hidup), tidak boleh dibuat asal balik.
#
# v2, arahan Loh 2026-08-01 (mengatasi reka bentuk pagi 2026-07-31 di
# bawah): lapisan (3) LAMA (atestasi manusia MBPG_IP_DISAHKAN /
# MBPG_IP_DISAHKAN_PADA) DIBUANG SEPENUHNYA. Sebab tepat pemilik:
# "Manusia menaip MBPG_IP_DISAHKAN_PADA membuktikan sifar. Ia boleh
# ditaip tanpa memandang skrin langsung. Kita membina ritual dan
# menyangka kita membina bukti." Gantinya BUKAN pengecualian/flag
# memintas — ia BUKTI: baca dua medan TETAPAN ALAMAT IP TERUS dari
# device melalui pelarasan_page (Appium), betulkan melalui app sendiri
# kalau salah/kosong, baca SEMULA selepas simpan, dan HANYA lulus kalau
# bacaan AKHIR itu == profile.IP_PRODUCTION_MBPG. Tiada tempat untuk
# manusia berjanji tanpa melihat skrin.
#
# Gerbang ini dipanggil dari create_driver() — dipanggil oleh fixture
# `driver`, yang SETIAP test transitif bergantung padanya tidak kira
# bagaimana pytest dilancarkan (raw, -k, .bat, IDE). Ia TIDAK berjalan
# semasa --collect-only (create_driver() tidak pernah dipanggil ketika
# itu), jadi gerbang audit kod (py_compile/collect-only) yang kita
# jalankan berulang kali dalam sesi ini tidak terjejas.
#
# TIGA LAPISAN, gagal-tertutup pada SETIAP satu:
#   (1) Profil — profile.is_production_target() + profile.IP_PRODUCTION_MBPG
#       (didedahkan syakhram; DIPANGGIL sahaja, TIDAK ditulis semula di
#       sini). Automatik, tiada manusia, tiada device — hanya nilai yang
#       profil AKTIF isytiharkan. Profil production/tercemar mati di sini.
#       Dipanggil SEBELUM webdriver.Remote() (tidak perlukan sesi Appium).
#   (2) Imbasan BEST-EFFORT storan peribadi app (adb run-as, APK 'Dev' =
#       debuggable) mencari petanda production epbt.mbjb.gov.my. Boleh
#       mengesan production secara POSITIF (isyarat kukuh -> GAGAL
#       serta-merta); TIDAK boleh mengesahkan staging secara positif
#       (skema storan RN belum disahkan). KEKAL atas arahan Loh — "itu
#       memang bukti". Juga SEBELUM webdriver.Remote().
#   (3) BUKTI DEVICE (gantian lapisan atestasi manusia lama) — MESTI
#       guna sesi Appium (pelarasan_page menavigasi skrin TETAPAN ALAMAT
#       IP sebenar), jadi ia berjalan SEJURUS SELEPAS webdriver.Remote()
#       dalam create_driver() — bukan sebelum. Nota kejujuran: brief asal
#       minta gerbang ini "sebelum webdriver.Remote()"; itu tidak boleh
#       dicapai serentak dengan "baca skrin sebenar" kerana membaca skrin
#       MEMERLUKAN sesi. Yang dikekalkan ialah SEMANGAT arahan itu:
#       gerbang tetap SATU-SATUNYA laluan dalam create_driver() (fungsi
#       yang --collect-only tidak pernah panggil), berjalan SEBELUM
#       create_driver() memulangkan driver kepada fixture `driver` —
#       jadi tiada test/fixture lain PERNAH memegang driver yang IP-nya
#       belum disahkan dari bacaan device. Kalau gerbang (3) gagal,
#       driver yang baru dicipta di-quit() sebelum RuntimeError dilempar
#       — tiada sesi bocor dalam keadaan tidak disahkan.
#
# TIADA FLAG MEMINTAS pada lapisan (3) — arahan Loh eksplisit: "Tiada
# pengecualian, tiada flag untuk memintas." Kalau IP yang dibaca akhirnya
# == server MBJB ATAU apa-apa selain IP_PRODUCTION_MBPG, RuntimeError
# serta-merta, tidak kira apa pemboleh ubah persekitaran diset.
# ============================================================================


def _imbas_petanda_mbjb(udid):
    """Cari petanda server MBJB dalam storan peribadi app.

    >>> POLARITI DIBALIKKAN daripada suite MBJB, DAN GAGAL-TERTUTUP. <<<

    Versi MBJB (_imbas_petanda_production) mencari petanda PRODUCTION dan
    memulangkan False pada sebarang pengecualian. Di sana itu konservatif:
    "tidak dapat mengesahkan production" bermakna run staging diteruskan,
    dan staging selamat.

    Di sini polaritinya terbalik. Kalau fungsi yang sama memulangkan False
    pada ralat, maksudnya menjadi "tidak dapat mengesahkan kita di server
    yang salah — teruskan sahaja" pada sistem PRODUCTION hidup. Itu
    gagal-TERBUKA, dan ia risiko R15 yang dikesan semasa recon fork ini.

    Jadi fungsi ini memulangkan tiga keadaan, bukan dua:
        True  — petanda MBJB DIJUMPAI (berhenti: server salah)
        False — imbasan berjaya dan TIADA petanda MBJB (teruskan)
        None  — imbasan TIDAK DAPAT dijalankan (pemanggil mesti berhenti)
    """
    import sqlite3
    import subprocess
    import tempfile

    # (1) Buktikan run-as boleh dijalankan LANGSUNG. Ini dipisahkan
    #     daripada semakan sebenar kerana kegagalan kedua-duanya
    #     bermaksud perkara yang sama sekali berbeza.
    try:
        r = subprocess.run(
            ["adb", "-s", udid, "shell", "run-as", APP_PACKAGE, "echo", "OK"],
            capture_output=True, text=True, timeout=10)
        if r.returncode != 0 or "OK" not in r.stdout:
            print(f"  [GERBANG-IP] run-as tidak tersedia "
                  f"(rc={r.returncode}): {(r.stderr or r.stdout).strip()[:200]}")
            return None
    except Exception as e:                                   # noqa: BLE001
        print(f"  [GERBANG-IP] run-as tidak dapat dijalankan "
              f"({type(e).__name__}: {e})")
        return None

    # (2) Baca TETAPAN SEBENAR dari DB tempatan app, bukan grep atas
    #     direktori app.
    #
    #     Versi pertama gerbang ini melakukan `grep -rlE ... /data/data/PKG`.
    #     Dua masalah, kedua-duanya ditemui pada run sebenar 2026-08-07:
    #       (a) `grep -r` keluar dengan rc=2 apabila ia bertemu
    #           subdirektori yang tidak boleh dibaca — yang SENTIASA
    #           berlaku di sini — jadi gerbang membaca "tidak dapat
    #           mengesahkan" dan menghentikan run yang sempurna sihat.
    #       (b) Lebih penting: ia memadan fail CACHE HTTP. Cache
    #           mengandungi setiap host yang app pernah hubungi, bukan
    #           host yang app KONFIGURASI untuk gunakan. Peranti yang
    #           betul dikonfigurasi tetapi pernah menyentuh server lain
    #           akan gagal; peranti yang salah dikonfigurasi dengan cache
    #           kosong akan lulus. Ia mengukur perkara yang salah.
    #
    #     `local_connection_details.ip_address` ialah tetapan itu sendiri.
    laluan = None
    try:
        fh = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
        laluan = fh.name
        p = subprocess.run(
            ["adb", "-s", udid, "exec-out", "run-as", APP_PACKAGE, "cat",
             f"/data/data/{APP_PACKAGE}/files/SQLite/e_kompaunV1.db"],
            stdout=fh, stderr=subprocess.PIPE, timeout=60)
        fh.close()
        if p.returncode != 0 or os.path.getsize(laluan) == 0:
            print(f"  [GERBANG-IP] DB tempatan app tidak dapat dibaca "
                  f"(rc={p.returncode})")
            return None
        con = sqlite3.connect(laluan)
        baris = con.execute("SELECT ip_address FROM "
                            "local_connection_details").fetchall()
        con.close()
    except Exception as e:                                   # noqa: BLE001
        print(f"  [GERBANG-IP] Bacaan tetapan app gagal "
              f"({type(e).__name__}: {e})")
        return None
    finally:
        if laluan and os.path.exists(laluan):
            try:
                os.remove(laluan)
            except OSError:
                pass

    if not baris:
        # >>> PUNCA RUN 5b (2026-08-20) — DIBAIKI. <<<
        # Selepas `pm clear` (fasa 3.5 --bersih), app dicipta semula
        # dengan DB kosong: local_connection_details ADA tetapi SIFAR
        # baris. Versi lama memulangkan None ("imbasan tidak dapat
        # dijalankan") dan gerbang lapisan 2 mematikan sesi bootstrap.
        #
        # Itu salah klasifikasi. None bermakna imbasan GAGAL BERJALAN
        # (run-as tiada, DB tak boleh dibaca). Di sini imbasan BERJAYA
        # sepenuhnya dan buktinya muktamad: app tidak menuding ke
        # SEBARANG server — maka pasti tidak menuding ke MBJB. Ini
        # keadaan yang bootstrap memang wujud untuk baiki (T-001 akan
        # menulis IP production MBPG dari profil, yang lapisan 1 sudah
        # sahkan). Jadi: False = "imbasan berjaya, tiada petanda MBJB".
        print("  [GERBANG-IP] local_connection_details KOSONG — app "
              "belum dikonfigurasi (keadaan pasca pm-clear). Imbasan "
              "BERJAYA: tiada sebarang server dikonfigurasi, maka tiada "
              "petanda MBJB. Bootstrap DIBENARKAN untuk menulis IP "
              "production MBPG.")
        return False

    nilai = [str(b[0]).strip().lower() for b in baris]
    print(f"  [GERBANG-IP] IP dikonfigurasi dalam app: {nilai}")
    for v in nilai:
        if any(mbjb in v for mbjb in _profile._IP_MBJB):
            return True
    return False


def _gerbang_sasaran_produksi(udid):
    """Lapisan (1) + (2) SAHAJA — kedua-duanya adb-based, tidak perlukan
    sesi Appium, jadi dipanggil SEBELUM webdriver.Remote(). Raise
    RuntimeError untuk membatalkan SESI SEBELUM driver Appium dicipta —
    tiada app dilancar selepas gerbang ini gagal.

    >>> POLARITI DIBALIKKAN daripada suite MBJB. <<<
    Di sana gerbang ini mengesahkan kita BUKAN pada production. Tiada
    staging MBPG wujud, jadi di sini ia mengesahkan kita MEMANG pada
    production MBPG YANG BETUL — dan bukan tersasar ke server majlis lain.

    Keselamatan terhadap penulisan datang dari corong tap dry-run
    (guard/corong.py), bukan dari gerbang ini. Gerbang ini hanya
    memastikan kita memandu majlis yang betul.
    """
    if not _profile.is_production_target():
        p = _profile.load()
        raise RuntimeError(
            "GERBANG SASARAN GAGAL (lapisan 1 — profil): profil aktif "
            f"'{p.get('_name', '?')}' TIDAK mengisytiharkan IP production "
            f"MBPG. internal_ip={p.get('internal_ip')!r} "
            f"external_ip={p.get('external_ip')!r}, dijangka kedua-duanya "
            f"{_profile.IP_PRODUCTION_MBPG!r}.")

    petanda = _imbas_petanda_mbjb(udid)
    if petanda is None:
        raise RuntimeError(
            "GERBANG SASARAN GAGAL (lapisan 2 — imbasan tidak dapat "
            "dijalankan): kami TIDAK dapat mengesahkan app pada peranti "
            "ini tidak menuding ke server MBJB.\n"
            "  Pada MBJB kegagalan imbasan diteruskan sebagai selamat, "
            "kerana sasarannya staging. Di sini sasarannya PRODUCTION "
            "hidup, jadi 'tidak dapat mengesahkan' dilayan sebagai "
            "BERHENTI, bukan sebagai OK (risiko R15).\n"
            "  Semak: adb tersambung? `adb -s <udid> shell run-as "
            f"{APP_PACKAGE}` berfungsi (app perlu debuggable)?\n"
            "  Kalau run-as memang tidak tersedia pada build ini, sahkan "
            "IP dari skrin TETAPAN ALAMAT IP dengan mata sendiri dan "
            "rekodkan keputusan itu dalam PAPAN.md sebelum meneruskan.")
    if petanda:
        raise RuntimeError(
            "GERBANG SASARAN GAGAL (lapisan 2 — imbasan device): petanda "
            "server MBJB DIJUMPAI dalam storan peribadi app pada peranti "
            "walaupun profil mengisytiharkan MBPG. Peranti ini mungkin "
            "masih dikonfigurasi untuk majlis LAIN. IP app TIDAK KEKAL "
            "merentas restart — tetapkan semula di skrin TETAPAN ALAMAT "
            "IP sebelum run.")

    print("  [GERBANG-IP] Lapisan 1+2 lulus (profil MBPG production, tiada "
          "petanda MBJB dalam storan app). Lapisan 3 (bukti bacaan device) "
          "menyusul selepas sesi Appium dicipta.")


# ----------------------------------------------------------------------
# Lapisan (3) — BUKTI DEVICE, bukan janji manusia (Loh, 2026-08-01)
# ----------------------------------------------------------------------

def _baca_dua_medan_ip(p):
    """Baca text SEMASA kedua-dua medan `text-input-outlined` (indeks 0=
    INTERNAL, 1=EXTERNAL) pada skrin TETAPAN ALAMAT IP yang SUDAH terbuka.
    TIDAK menaip apa-apa — bacaan sahaja.

    Guna HANYA permukaan AWAM PelarasanPage/BasePage (`INPUT_OUTLINED`,
    `find_element`) + `.text` terus atas elemen (API Appium/Selenium awam,
    bukan kaedah projek). `pelarasan_page.py` bukan fail kami — TIDAK
    memanggil `_safe_text`/`_isi_input_outlined` (privat, dalaman fail
    itu). Kalau bacaan gagal (elemen tiada dalam tempoh menunggu), ralat
    dibiar naik terus — gagal-tertutup: "tidak dapat baca" mesti GAGAL
    gerbang, bukan disamarkan sebagai rentetan kosong yang kelihatan
    seperti "medan kosong, boleh auto-betulkan".

    INTERIM: pelarasan_page belum ada kaedah baca-sahaja rasmi untuk skrin
    ini — permintaan didaftar dalam recon/PAPAN.md untuk pemilik fail itu.
    Gantikan fungsi ini dengan panggilan terus kalau ia mendarat.
    """
    from appium.webdriver.common.appiumby import AppiumBy
    nilai = []
    for indeks in (0, 1):
        loc = (AppiumBy.ANDROID_UIAUTOMATOR,
               f'{p.INPUT_OUTLINED}.instance({indeks})')
        el = p.find_element(loc, timeout=15)
        nilai.append((el.text or "").strip())
    return nilai[0], nilai[1]


def _buka_skrin_tetapan_alamat_ip(p):
    """Tap item menu TETAPAN ALAMAT IP dari popup Menu Selaras (SUDAH
    terbuka) dan sahkan sub-skrinnya benar-benar terbuka (kehadiran
    butang Simpan — sub-skrin ini TIADA penanda lain).

    v2 (insiden 2026-07-31, recon\\PAPAN.md "AMARAN" — satu larian
    mencetuskan SELARAS MAKLUMAT BARANG SITA tanpa satu kaedah selaras
    pun dipanggil, semasa navigasi Menu Selaras ini). Reimplementasi
    tempatan LAMA (wait_and_tap + tap-semula membuta) DIBUANG — kini
    panggil terus `p.tap_menu_item_disahkan()`, kaedah AWAM baharu
    pelarasan_page.py (BUKAN underscore/privat, jadi selamat dipanggil
    dari sini) yang mengekalkan kontrak "cari-elemen -> log sasaran ->
    tap -> jaringan keselamatan SELARAS -> sahkan skrin berubah" SATU
    tempat, dikongsi dengan open_menu_selaras() fail itu sendiri.
    RuntimeError dilempar terus oleh kaedah itu — konsisten dengan
    kontrak gerbang ini, tiada pembungkusan diperlukan di sini.
    """
    p.tap_menu_item_disahkan(
        p.MENU_TETAPAN_ALAMAT_IP, "buka TETAPAN ALAMAT IP",
        verifikasi_locators=p.SIMPAN_LOCATORS,
        percubaan_maksimum=2,
    )


def _capai_skrin_tetapan_ip_tanpa_relaunch(p, driver):
    """BACA DULU, JANGAN SENTUH (Loh, K-9 2026-07-31 — pembetulan atas
    gerbang v2 pertama). IP TIDAK KEKAL merentas restart app (CLAUDE.md,
    "PENEMUAN DEVICE SEBENAR" — disahkan dua kali), jadi sebarang
    force-relaunch/force-stop SEBELUM bacaan pertama MEMUSNAHKAN nilai
    yang cuba dibaca.

    Pepijat sebenar yang ditemui: draf pertama gerbang ini memanggil
    `p.ensure_on_login_screen()` sebelum bacaan pertama — kaedah itu
    force-relaunch (`terminate_app` + `activate_app`) BILA ia rasa skrin
    "tidak bersih". Pemilik baru sahaja menetapkan IP dengan tangan;
    relaunch itu memadamnya SEBELUM sempat dibaca, lalu gerbang membaca
    SISA dan menyalah lapor sisa itu sebagai "production" — buntu,
    kerana satu-satunya cara membetulkan IP ialah melalui sesi yang
    gerbang itu sendiri baru bunuh.

    Kontrak baharu, TIADA `ensure_on_login_screen()` di sini:
      - Kalau skrin login SUDAH kelihatan (app sedia ada di sana) ->
        TERUS navigasi (hamburger -> Menu Selaras -> Tetapan Alamat IP)
        dari keadaan SEDIA ADA. TIADA panggilan relaunch/terminate.
      - Kalau skrin login TIDAK kelihatan (mungkin app langsung tidak
        berjalan) -> `driver.activate_app()` SEKALI SAHAJA — BUKAN
        `terminate_app()` dahulu, jadi kalau app SUDAH hidup ia hanya
        dibawa ke hadapan (tiada proses baharu, tiada kehilangan
        keadaan), dan kalau app memang belum berjalan ia dilancarkan
        bersih (skrin pertama = login, tiada apa untuk hilang). Cuba
        SEKALI sahaja.
      - Kalau selepas itu skrin login MASIH tidak kelihatan (app
        berada pada skrin LAIN, cth sudah log masuk) -> RuntimeError
        terus. Gerbang ini TIDAK log keluar/relaunch untuk "membetulkan"
        keadaan itu sendiri — itulah tindakan yang memusnahkan bukti.
        Manusia mesti sahkan dengan mata dan log keluar secara MANUAL.
    """
    if not p.is_element_present(p.LOGIN_SCREEN_TITLE, timeout=5):
        print("  [GERBANG-IP] Skrin login tidak kelihatan pada semakan "
              "pertama — activate_app() SEKALI sahaja (BUKAN terminate_app, "
              "TIADA force-stop) dan semak lagi...")
        try:
            driver.activate_app(APP_PACKAGE)
        except Exception as e:                                   # noqa: BLE001
            raise RuntimeError(
                "GERBANG SASARAN GAGAL (lapisan 3 — bukti device): "
                f"activate_app() gagal ({type(e).__name__}: {e}).")
        if not p.is_element_present(p.LOGIN_SCREEN_TITLE, timeout=10):
            # >>> DITAMBAH 2026-07-31, run device 20:1x <<<
            # App sudah LOG MASUK (keadaan biasa selepas run sebelumnya).
            # LOG KELUAR ialah NAVIGASI DALAM APP — ia BUKAN restart, bukan
            # force-stop, dan ia TIDAK memusnahkan tetapan IP (IP hilang pada
            # restart PROSES, bukan pada logout). Jadi ia selamat di sini,
            # sedangkan relaunch tidak. Tanpa ini, gerbang menemui buntu
            # operasi: setiap run yang BERJAYA meninggalkan app dalam keadaan
            # log masuk, yang menghalang run seterusnya daripada membaca IP.
            try:
                import time as _t
                from pages.home_page import HomePage
                h = HomePage(driver)
                # >>> LOG KELUAR DIBUANG — keputusan pemilik 2026-08-07. <<<
                # Versi MBJB cuba pulang ke skrin utama lalu log_out().
                # Dua sebab ia dibuang di sini:
                #   1. log_out() menekan butang YA, dan YA ialah TRIP-WIRE.
                #      Suite ini secara struktur tidak boleh log keluar.
                #   2. Log keluar dari sesi production yang sedang hidup
                #      ialah kesan sampingan yang tiada siapa minta.
                # Sebaliknya kami undur SEKADAR untuk melihat sama ada
                # skrin login muncul dengan sendirinya, dan kalau tidak,
                # jatuh kepada bukti DB (lihat pemanggil).
                print("  [GERBANG-IP] App sudah log masuk — TIDAK log "
                      "keluar (butang YA ialah trip-wire). Cuba undur "
                      "sahaja untuk melihat skrin login...")
                for _ in range(3):
                    h.dismiss_native_alerts(context="gerbang-ip: undur")
                    if p.is_element_present(p.LOGIN_SCREEN_TITLE, timeout=1):
                        break
                    h.press_back()
                    _t.sleep(1.0)
            except Exception as e:                               # noqa: BLE001
                print(f"  [GERBANG-IP] undur gagal ({type(e).__name__}: {e})")
        if not p.is_element_present(p.LOGIN_SCREEN_TITLE, timeout=10):
            raise SkrinLoginTakTercapai(
                "skrin login tidak tercapai tanpa log keluar")

    p.open_menu_selaras()
    _buka_skrin_tetapan_alamat_ip(p)


class SkrinLoginTakTercapai(Exception):
    """Skrin login tidak tercapai tanpa log keluar.

    BUKAN kegagalan gerbang. Ia keadaan biasa: `no_reset=True` bermakna
    sesi app bertahan antara run, jadi app selalunya SUDAH log masuk.
    Log keluar bukan pilihan (butang YA ialah trip-wire), jadi pemanggil
    beralih kepada bukti DB — lihat _sahkan_ip_dari_db().
    """


def _sahkan_ip_dari_db(udid):
    """Bukti IP dari tetapan app yang PERSISTED, bukan dari skrin.

    Diluluskan pemilik 2026-08-07 sebagai laluan sah lapisan 3 apabila
    skrin login tidak tercapai.

    Kenapa ini bukan pelonggaran:

      * `local_connection_details.ip_address` IALAH tetapan itu sendiri.
        Skrin TETAPAN ALAMAT IP hanya memaparkan nilai yang sama. Membaca
        punca lebih kukuh daripada membaca paparannya.
      * Premis MBJB yang mewajarkan laluan-skrin-sahaja ialah "IP TIDAK
        KEKAL merentas restart app". Itu DIUJI pada MBPG 2026-08-07 dan
        TERBUKTI SALAH: selepas 6 back-press dan driver.quit(), nilai
        kekal 113.211.155.174. Ia persisted dalam SQLite.
      * Ia baca-sahaja. Tiada apa pada peranti berubah.

    Pulangkan senarai IP yang dikonfigurasi. Melempar kalau tidak dapat
    dibaca — gagal-tertutup dikekalkan.
    """
    import sqlite3
    import subprocess
    import tempfile
    laluan = None
    try:
        fh = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
        laluan = fh.name
        p = subprocess.run(
            ["adb", "-s", udid, "exec-out", "run-as", APP_PACKAGE, "cat",
             f"/data/data/{APP_PACKAGE}/files/SQLite/e_kompaunV1.db"],
            stdout=fh, stderr=subprocess.PIPE, timeout=60)
        fh.close()
        if p.returncode != 0 or os.path.getsize(laluan) == 0:
            raise RuntimeError(f"adb exec-out rc={p.returncode}")
        con = sqlite3.connect(laluan)
        baris = con.execute(
            "SELECT ip_address FROM local_connection_details").fetchall()
        con.close()
    finally:
        if laluan and os.path.exists(laluan):
            try:
                os.remove(laluan)
            except OSError:
                pass
    return [str(b[0]).strip() for b in baris]


def _ip_diterima(internal, external, jangka):
    """(ok, sebab, internal_kosong) — takrifan TUNGGAL "IP boleh diterima".

    Dikongsi oleh bacaan pertama dan bacaan muktamad supaya kedua-duanya
    tidak boleh menyimpang.

    >>> MEDAN INTERNAL KOSONG DILAYAN BERBEZA DARIPADA SALAH. <<<
    Keputusan pemilik 2026-08-10, selepas bacaan device menunjukkan
    internal='' external='113.211.155.174' sedangkan
    local_connection_details membawa satu baris sahaja dengan
    status='Ext'. App MBPG nampaknya memandu melalui alamat External;
    medan Internal tidak pernah diisi pada peranti ini.

    KOSONG bermakna "belum ditetapkan". NILAI SALAH bermakna "peranti
    menuding ke tempat lain". Hanya yang kedua itu berbahaya, dan hanya
    yang kedua menghentikan run.

    Medan Internal akan diisi oleh T-001 (diluluskan pemilik sebagai
    perubahan konfigurasi), selepas itu kedua-dua medan sepadan dan
    cabang ini tidak lagi digunakan pada run akan datang.
    """
    ex = (external or "").strip()
    it = (internal or "").strip()
    if not ex and not it:
        # >>> PUNCA RUN 5b (2026-08-20) — DIBAIKI. <<<
        # Keadaan pasca pm-clear (fasa 3.5 --bersih): KEDUA-DUA medan
        # kosong. Ini BUKAN "peranti menuding ke tempat lain" — ia
        # peranti yang tidak menuding ke MANA-MANA. Prinsip gerbang
        # sendiri (komen atas): hanya NILAI SALAH berbahaya; "medan
        # kosong yang selamat ditimpa" bukan bahaya. Lapisan 2 sudah
        # membuktikan tiada petanda MBJB. Bootstrap/T-001 akan mengisi
        # kedua-dua medan dengan IP production MBPG dari profil.
        return (True,
                "KEDUA-DUA medan KOSONG (keadaan pasca pm-clear / app "
                "baru) — bukan menuding ke tempat lain; bootstrap/T-001 "
                "akan mengisinya", True)
    if ex != jangka:
        return (False,
                f"external={external!r} bukan {jangka!r} — peranti "
                f"menuding ke tempat lain", False)
    if it == jangka:
        return True, "kedua-dua medan sepadan", False
    if not it:
        return (True,
                "external sepadan; internal KOSONG (belum ditetapkan) — "
                "T-001 akan mengisinya, diluluskan pemilik 2026-08-10",
                True)
    return (False,
            f"internal={internal!r} bukan {jangka!r} dan bukan kosong — "
            f"nilai yang tidak dijangka, bukan medan yang belum diisi",
            False)


def _log_bacaan_ip(label, internal, external, keputusan):
    print(f"  [GERBANG-IP] baca ({label}): internal={internal!r} "
          f"external={external!r} -> keputusan: {keputusan}")


def _sub_skrin_ip_terbuka(p):
    """Adakah sub-skrin TETAPAN ALAMAT IP masih terbuka?

    Simetri sengaja dengan `_buka_skrin_tetapan_alamat_ip()`, yang
    MENGESAHKAN pembukaan melalui `SIMPAN_LOCATORS` yang SAMA: kalau
    butang SIMPAN kelihatan, kita berada DALAM sub-skrin itu.
    """
    return any(p.is_element_present(loc, timeout=1)
               for loc in p.SIMPAN_LOCATORS)


def _tutup_gerbang_ip_terbaik(p, wajib=False):
    """Pulang ke skrin login yang DISAHKAN bersih selepas gerbang (3).

    >>> PEPIJAT YANG DIBETULKAN 2026-08-01 — punca TUNGGAL semua
    >>> kegagalan malam 2026-07-31. <<<

    Versi lama memanggil `close_menu_selaras()` SAHAJA. Tetapi pada titik
    panggilan yang penting (selepas bacaan MUKTAMAD) kita berada SATU
    TINGKAT LEBIH DALAM — sub-skrin TETAPAN ALAMAT IP baru sahaja dibuka
    SEMULA untuk bacaan itu. Tiada sesiapa menutupnya.

    Ia lolos tanpa disedari kerana sub-skrin ini ialah modal RN yang
    dilukis DI ATAS skrin login: `LOGIN_SCREEN_TITLE` KEKAL dalam pokok
    view di bawahnya, jadi semakan kehadiran dalam `close_menu_selaras()`
    dipenuhi dan ia mencetak "Login screen visible — popup closed"
    sedangkan DUA lapisan masih terbuka. Bukti dari skrin akhir larian
    E2E terakhir:

        EditText : ['admin', 'KATA LALUAN',
                    '219.93.38.103:8880', '219.93.38.103:8880']
        teks     : ... 'MENU SELARAS', 'TETAPAN ALAMAT IP', ...,
                   'TETAPAN ALAMAT IP'

    Dua medan IP + tajuk sub-skrin DUA KALI (item menu + tajuk skrin).
    Itu menerangkan setiap gejala malam itu: popup MENU SELARAS yang
    "terbuka semula", tap tersasar ke kawasan Selaras, dan popup
    `DATA MAKLUMAT BARANG SITAAN BERJAYA DISIMPAN` yang berulang.

    Ini kelas pepijat yang SAMA seperti `login_page.is_login_screen_
    displayed()`: mempercayai semakan kehadiran semasa overlay menutupi
    skrin. Ubatnya juga sama — bersihkan DAHULU, kemudian sahkan.

    Kontrak baharu, tiga lapis, ikut susunan tutup yang betul:
      1. tutup sub-skrin TETAPAN ALAMAT IP (Back), SAHKAN ia hilang
      2. tutup popup MENU SELARAS (`close_menu_selaras()`)
      3. SAHKAN skrin login sebenar: `pastikan_bersih()` melaporkan tiada
         overlay DAN `APP_TITLE` kelihatan

    `wajib=True` (laluan LULUS sahaja): kegagalan mana-mana lapisan =
    `RuntimeError` DI SINI. Arahan pemilik: *"Kalau tidak boleh — GAGAL
    di situ, jangan serahkan skrin bersepah kepada `login()`."*

    `wajib=False` (laluan GAGAL): best-effort, dibalut sepenuhnya —
    kegagalan di sini TIDAK PERNAH menelan/menggantikan ralat gerbang
    sebenar yang pemanggil akan lempar sebentar lagi.
    """
    # --- Lapisan 1: sub-skrin TETAPAN ALAMAT IP -------------------------
    for _ in range(4):
        if not _sub_skrin_ip_terbuka(p):
            break
        # Alert asli BERATUR dan MENELAN Back (CLAUDE.md "PENEMUAN DEVICE
        # SEBENAR") — kosongkan dahulu atau Back hilang ke dalam alert.
        try:
            p.dismiss_native_alerts(first_timeout=2,
                                    context="gerbang-ip: tutup sub-skrin")
            p.press_back()
        except Exception as e:                               # noqa: BLE001
            print(f"  [GERBANG-IP] AMARAN: Back pada sub-skrin gagal ({e})")
            break
        _time.sleep(1.2)

    if _sub_skrin_ip_terbuka(p):
        msg = ("sub-skrin TETAPAN ALAMAT IP TIDAK dapat ditutup selepas 4 "
               "cubaan Back (butang SIMPAN masih kelihatan)")
        if wajib:
            raise RuntimeError(
                "GERBANG SASARAN GAGAL (lapisan 3 — pulang ke skrin login): "
                f"{msg}. IP DISAHKAN staging, tetapi gerbang enggan "
                "menyerahkan skrin bersepah kepada login(): itulah punca "
                "TUNGGAL kegagalan 2026-07-31 (tap mendarat di kawasan "
                "Menu Selaras, di mana SELARAS MAKLUMAT PELESEN >4 jam "
                "berada). Sahkan skrin device dengan mata.")
        print(f"  [GERBANG-IP] AMARAN: {msg}")
    else:
        print("  [GERBANG-IP] sub-skrin TETAPAN ALAMAT IP ditutup dan "
              "disahkan hilang")

    # --- Lapisan 2: popup MENU SELARAS ----------------------------------
    try:
        p.close_menu_selaras()
    except Exception as e:                                   # noqa: BLE001
        print(f"  [GERBANG-IP] AMARAN: close_menu_selaras() gagal "
              f"({e}) — login() ada tangga relaunch sendiri")

    # --- Lapisan 3: SAHKAN skrin login sebenar --------------------------
    # `close_menu_selaras()` melaporkan kejayaan berdasarkan kehadiran
    # LOGIN_SCREEN_TITLE, yang KEKAL kelihatan di bawah modal RN — jadi
    # laporannya BUKAN bukti. Sahkan dengan pengesan overlay khusus dalam
    # login_page (ia menamakan popup MENU SELARAS, modal-surface, dan
    # alert asli) sebelum mengisytiharkan skrin bersih.
    lp = LoginPage(p.driver)
    bersih = lp.pastikan_bersih()
    tajuk = lp.is_element_present(lp.APP_TITLE, timeout=10)
    if bersih and tajuk:
        print("  [GERBANG-IP] skrin login DISAHKAN bersih (tiada overlay, "
              "APP_TITLE kelihatan) — selamat diserahkan kepada login()")
        return

    sebab = []
    if not bersih:
        sebab.append("overlay masih ada: {}".format(
            lp.overlay_menutup_skrin() or "(tidak dikenal pasti)"))
    if not tajuk:
        sebab.append("APP_TITLE tidak kelihatan")
    msg = "; ".join(sebab)
    if wajib:
        raise RuntimeError(
            "GERBANG SASARAN GAGAL (lapisan 3 — pulang ke skrin login): "
            f"{msg}. IP DISAHKAN staging, jadi ini BUKAN isu sasaran — "
            "gerbang tidak berjaya memulangkan skrin login yang bersih. "
            "Menyerahkan skrin bersepah kepada login() ialah punca "
            "TUNGGAL kegagalan 2026-07-31; ia tidak diulang.")
    print(f"  [GERBANG-IP] AMARAN: skrin login TIDAK disahkan bersih ({msg})")


def _gerbang_ip_muktamad_dari_device(driver):
    """Lapisan (3), gantian PENUH atestasi manusia lama. Baca IP TERUS
    dari skrin TETAPAN ALAMAT IP (bukti device) SEBELUM menyentuh
    apa-apa — dan "sebelum menyentuh" di sini termasuk TIADA relaunch/
    force-stop untuk "membersihkan" skrin (lihat
    _capai_skrin_tetapan_ip_tanpa_relaunch(); K-9 2026-07-31: draf
    pertama gerbang ini memanggil ensure_on_login_screen() dahulu, yang
    force-relaunch app dan MEMADAM IP yang baru sahaja ditetapkan
    pemilik dengan tangan — bacaan sisa selepas itu tersalah lapor
    sebagai "production"). Kalau bacaan BERSIH itu == petanda production
    yang DIKENALI, RuntimeError SERTA-MERTA — TIDAK cuba "membaiki"
    secara senyap, kerana device menuding production daripada bacaan
    tidak dicemari ialah isyarat sesuatu yang lebih asas tersasar
    (device salah / profil salah), bukan sekadar medan kosong yang
    selamat ditimpa (arahan Loh: "Tiada pengecualian, tiada flag untuk
    memintas").

    Kalau bacaan bukan production tetapi juga bukan staging (salah,
    kosong, atau separuh-padam), betulkan melalui APP SENDIRI
    (`pelarasan_page.set_tetapan_alamat_ip` SEDIA ADA — baca-semasa +
    langkau-jika-sama + taip + baca-balik per medan, sudah dipercayai
    T-001), BACA SEMULA selepas Simpan sebagai bukti MUKTAMAD (bukan
    mempercayai sahaja yang set() tidak melempar ralat), dan TUTUP
    kembali ke skrin login yang bersih supaya `pelarasan_results`
    bermula dari keadaan yang ia jangkakan.

    Dipanggil dari create_driver() SEJURUS SELEPAS webdriver.Remote() —
    kalau ia raise, create_driver() men-quit() driver sebelum melempar,
    supaya tiada sesi "separuh disahkan" bocor ke fixture `driver`.
    """
    p = PelarasanPage(driver)
    jangka = _profile.IP_PRODUCTION_MBPG
    # >>> PRINSIP GERBANG — DITULIS SEMULA UNTUK MBPG <<<
    #
    # Versi MBJB gerbang ini boleh MENULIS: kalau IP device salah, ia
    # menaip IP staging dan menekan SIMPAN, dengan alasan yang sah bahawa
    # menulis staging MENJAUHKAN device daripada production.
    #
    # Logik itu TIDAK boleh dibawa ke sini, kerana ia bergantung
    # sepenuhnya pada wujudnya sasaran yang lebih selamat untuk ditulis.
    # Untuk MBPG, nilai yang akan ditulis IALAH production. Menulisnya
    # bermakna menekan SIMPAN pada skrin tetapan production — satu tulisan
    # sebenar, sebelum sebarang test berjalan, sebelum sebarang penanda
    # skop dinilai, dan (dalam suite MBJB) ia mencetuskan penyelarasan
    # semula data rujukan yang menenggelamkan skrin dengan alert.
    #
    # Arahan pemilik untuk T-001 ialah "masuk semula IP YANG SAMA sahaja".
    # Gerbang ini oleh itu MEMBACA dan MENGESAHKAN sahaja. Kalau IP salah,
    # ia BERHENTI dan meminta manusia membetulkannya. Lihat blok
    # "TIADA PEMBETULAN AUTOMATIK" di bawah.
    #
    # Petanda maut kini ialah server MBJB — majlis LAIN. Kehadirannya
    # bermakna device/profil tersasar sepenuhnya.
    produksi_dikenali = tuple(sorted(_profile._IP_MBJB))

    try:
        _capai_skrin_tetapan_ip_tanpa_relaunch(p, driver)
    except SkrinLoginTakTercapai as e:
        # LALUAN BUKTI DB — diluluskan pemilik 2026-08-07.
        #
        # Sesi app masih hidup (no_reset=True), jadi skrin login tiada,
        # dan log keluar dilarang (butang YA = trip-wire). Sahkan IP dari
        # tetapan yang persisted dan bukan dari skrin.
        #
        # Nota T-012: sesi yang bertahan merentas activate_app() ITU
        # SENDIRI bukti remember-me/persistence. Laluan ini merekodnya
        # sebagai kaedah verifikasi T-012, menggantikan aliran login
        # penuh dari skrin login (yang tidak boleh dicapai tanpa log
        # keluar yang dilarang).
        print(f"  [GERBANG-IP] {e} — beralih kepada BUKTI DB "
              f"(tetapan persisted, baca-sahaja)")
        udid = driver.capabilities.get("udid") or \
            driver.capabilities.get("deviceUDID")
        try:
            nilai = _sahkan_ip_dari_db(udid)
        except Exception as e2:                              # noqa: BLE001
            raise RuntimeError(
                f"GERBANG SASARAN GAGAL (lapisan 3 — bukti DB): tetapan "
                f"IP tidak dapat dibaca dari DB app ({type(e2).__name__}: "
                f"{e2}). Kedua-dua laluan bukti tertutup — BERHENTI.")
        if not nilai:
            raise RuntimeError(
                "GERBANG SASARAN GAGAL (lapisan 3 — bukti DB): "
                "local_connection_details KOSONG.")
        salah = [v for v in nilai if v != jangka]
        if salah:
            raise RuntimeError(
                f"GERBANG SASARAN GAGAL (lapisan 3 — bukti DB): app "
                f"dikonfigurasi kepada {nilai}, dijangka {jangka!r}. "
                f"Betulkan dengan tangan pada peranti sebelum meneruskan.")
        print(f"  [GERBANG-IP] LULUS melalui bukti DB: {nilai} == "
              f"{jangka!r}")
        print("  [GERBANG-IP] T-012: sesi kekal aktif merentas "
              "activate_app() — bukti remember-me/persistence.")
        _RUN_META["gerbang_ip_kaedah"] = "bukti-DB (sesi aktif, tiada logout)"
        _RUN_META["t012_kaedah"] = ("sesi bertahan merentas activate_app; "
                                    "aliran login penuh TIDAK dijalankan "
                                    "(log keluar dilarang — YA trip-wire)")
        return
    except RuntimeError:
        raise
    except Exception as e:                                   # noqa: BLE001
        raise RuntimeError(
            "GERBANG SASARAN GAGAL (lapisan 3 — bukti device): tidak "
            f"dapat mencapai skrin TETAPAN ALAMAT IP untuk bacaan pertama "
            f"({type(e).__name__}: {e}). Gagal-tertutup: tidak dapat "
            "membaca IP = GAGAL, bukan lulus.")

    internal0, external0 = _baca_dua_medan_ip(p)

    petanda_jumpa = [s for s in produksi_dikenali
                     if s and (s in internal0 or s in external0)]
    if petanda_jumpa:
        _log_bacaan_ip("SEBELUM apa-apa disentuh", internal0, external0,
                       f"GAGAL — petanda production dikenali {petanda_jumpa}")
        _tutup_gerbang_ip_terbaik(p)
        raise RuntimeError(
            "GERBANG SASARAN GAGAL (lapisan 3 — bukti device): bacaan "
            f"BERSIH (tiada relaunch/force-stop sebelum bacaan ini) "
            f"menunjukkan device MENUDING PRODUCTION YANG DIKENALI "
            f"({petanda_jumpa}) — internal={internal0!r} "
            f"external={external0!r}. TIDAK ditimpa secara senyap: "
            "device menuding production daripada bacaan tidak dicemari "
            "ialah isyarat sesuatu yang lebih asas tersasar (device "
            "salah / profil salah), bukan sekadar medan kosong. TIADA "
            "pengecualian, TIADA flag untuk memintas — ini satu-satunya "
            "perlindungan antara suite dan rekod kompaun SEBENAR pada "
            "epbt.mbjb.gov.my. Sahkan device DAN profil dengan mata "
            "sebelum cuba lagi.")

    perlu_betul = not (internal0 == jangka and external0 == jangka)
    if perlu_betul:
        _log_bacaan_ip("SEBELUM apa-apa disentuh", internal0, external0,
                       "bukan staging, bukan production dikenali — "
                       "selamat dibetulkan melalui set_tetapan_alamat_ip()")
    else:
        _log_bacaan_ip("SEBELUM apa-apa disentuh", internal0, external0,
                       "sudah == staging, tiada pembetulan diperlukan")

    # Kembali ke popup Menu Selaras dalam KEDUA-DUA kes (perlu_betul atau
    # tidak) -- kita sedang berada DALAM sub-skrin TETAPAN ALAMAT IP
    # (dibuka untuk bacaan SEBELUM di atas), dan set_tetapan_alamat_ip()
    # DAN _buka_skrin_tetapan_alamat_ip() kedua-duanya menjangkakan
    # bermula dari popup Menu Selaras (item menu TETAPAN ALAMAT IP
    # kelihatan), bukan dari dalam sub-skrin itu sendiri.
    p.press_back()
    if not p.is_element_present(p.MENU_TETAPAN_ALAMAT_IP, timeout=5):
        _tutup_gerbang_ip_terbaik(p)
        raise RuntimeError(
            "GERBANG SASARAN GAGAL (lapisan 3 — navigasi): tidak dapat "
            "kembali ke popup Menu Selaras selepas bacaan pertama (Back "
            "tidak menutup sub-skrin TETAPAN ALAMAT IP seperti "
            "dijangka). Gagal-tertutup: tidak dapat meneruskan = GAGAL, "
            "bukan lulus.")

    # set_tetapan_alamat_ip() dipanggil TANPA SYARAT (perlu_betul atau
    # tidak) -- per medan ia baca-semasa + langkau-jika-sama, jadi laluan
    # "sudah betul" hanya menyebabkan dua no-op + satu tap Simpan (murah,
    # dan mengembalikan kita ke popup Menu Selaras dengan cara yang SAMA
    # tidak kira laluan mana diambil -- "Bukti MUKTAMAD" di bawah tidak
    # perlu tahu yang mana berlaku).
    # >>> DIUBAH 2026-08-01 — panggilan TANPA SYARAT dibuang. <<<
    # Ia bukan "murah" seperti yang disangka: laluan "sudah betul" melangkau
    # TAIP tetapi TETAP menekan SIMPAN, dan SIMPAN nampaknya mencetuskan
    # penyelarasan semula data rujukan app. Setiap run kemudiannya menghadapi
    # ribut alert `BERJAYA | DATA JENIS KENDERAAN SAVED SUCCESSFULLY!` yang
    # menenggelamkan skrin login — gerbang menghasilkan sendiri keadaan yang
    # membunuhnya.
    #
    # Bukti (eksperimen semula jadi, 2026-08-01):
    #   run 1  IP salah  -> taip + SIMPAN            -> 7+ alert
    #   ukuran adb       -> HANYA tolak OK + Back    -> TIADA alert baharu,
    #                                                   skrin login kekal bersih
    #   run 2  IP betul  -> tiada taip, SIMPAN juga  -> 6+ alert
    #   run 3  IP betul  -> tiada taip, SIMPAN juga  -> 6+ alert
    #
    # HIPOTESIS, BELUM DISAHKAN: SIMPAN mencetuskan sync data rujukan. Run
    # selepas perubahan ini ialah ujiannya — kalau ribut itu hilang bila
    # SIMPAN tidak ditekan, hipotesis disokong; kalau ia kekal, hipotesis
    # MATI dan puncanya di tempat lain. Jangan tulis ia sebagai fakta
    # sebelum itu.
    #
    # Melangkau tulis-semula bila nilai SUDAH betul adalah betul dengan
    # sendirinya: gerbang ini wujud untuk MENGESAHKAN sasaran, bukan untuk
    # menulis semula nilai yang sudah sepadan. Perlindungan tidak berubah —
    # baca-balik MUKTAMAD di bawah masih dituntut pada KEDUA-DUA laluan.
    # ------------------------------------------------------------------
    # TIADA PEMBETULAN AUTOMATIK  (risiko R3, dibuang untuk MBPG)
    # ------------------------------------------------------------------
    # Suite MBJB memanggil p.set_tetapan_alamat_ip(jangka, jangka) di sini
    # apabila IP tidak sepadan. Panggilan itu menaip ke dalam medan dan
    # menekan SIMPAN.
    #
    # Pada MBPG itu tulisan ke production, dan ia berlaku SEBELUM test
    # pertama, sebelum penanda skop, sebelum apa-apa yang boleh
    # menghentikannya. Ia juga akan dihalang oleh corong tap sekarang
    # (SIMPAN disekat di luar dialog bookmark) — jadi mengekalkannya
    # bermakna gerbang membatalkan run sendiri dengan pelanggaran
    # dry-run, iaitu cara yang mengelirukan untuk melaporkan "IP salah".
    #
    # Sebaliknya: BERHENTI dan minta manusia. Membetulkan IP ialah
    # tindakan yang seseorang patut lakukan dengan sedar pada production,
    # bukan kesan sampingan senyap ketika memulakan suite ujian.
    ok0, sebab0, kosong0 = _ip_diterima(internal0, external0, jangka)
    if not ok0:
        _tutup_gerbang_ip_terbaik(p)
        raise RuntimeError(
            "GERBANG SASARAN GAGAL (lapisan 3 — IP device tidak sepadan): "
            f"{sebab0}\n"
            f"  Dibaca: internal={internal0!r} external={external0!r}; "
            f"dijangka {jangka!r}.\n"
            "\n"
            "  Suite ini TIDAK akan membetulkannya sendiri. Suite MBJB "
            "membetulkan IP secara automatik kerana ia menulis nilai "
            "STAGING — menjauhkan device dari bahaya. Di sini nilai yang "
            "sama IALAH production, jadi 'pembetulan automatik' bermakna "
            "menekan SIMPAN pada production sebelum sebarang test "
            "berjalan.\n"
            "\n"
            "  BETULKAN DENGAN TANGAN pada peranti:\n"
            "    Menu Selaras > TETAPAN ALAMAT IP > isi kedua-dua medan\n"
            f"    dengan {jangka} > SIMPAN\n"
            "  Kemudian jalankan semula suite.")

    if kosong0:
        print(f"  [GERBANG-IP] {sebab0}")
        _RUN_META["ip_internal_kosong_pada_mula"] = True
    print("  [GERBANG-IP] IP device DITERIMA — TIADA tulis, TIADA SIMPAN "
          "oleh gerbang. Terus ke bacaan MUKTAMAD.")

    # Bukti MUKTAMAD: buka SEMULA (bukan mempercayai read-back SEBELUM
    # Simpan ditekan) dan baca lagi. Kita berada di popup Menu Selaras di
    # sini sama ada laluan "sudah betul" (tiada apa disentuh) atau
    # laluan "dibetulkan" (set_tetapan_alamat_ip() kembali ke situ
    # selepas Simpan) -- _buka_skrin_tetapan_alamat_ip() konsisten dalam
    # kedua-dua kes.
    try:
        _buka_skrin_tetapan_alamat_ip(p)
    except RuntimeError:
        raise
    except Exception as e:                                   # noqa: BLE001
        raise RuntimeError(
            "GERBANG SASARAN GAGAL (lapisan 3 — bukti device pasca-simpan): "
            f"tidak dapat membuka semula skrin TETAPAN ALAMAT IP untuk "
            f"pengesahan muktamad ({type(e).__name__}: {e}).")
    internal1, external1 = _baca_dua_medan_ip(p)
    _sepadan, _sebab1, _kosong1 = _ip_diterima(internal1, external1, jangka)
    _log_bacaan_ip("AKHIR, muktamad", internal1, external1,
                   f"LULUS — {_sebab1}" if _sepadan
                   else f"GAGAL — {_sebab1}")

    # `wajib=_sepadan`: pada laluan LULUS, gagal-tertutup kalau skrin login
    # tidak dapat disahkan bersih. Pada laluan GAGAL (IP tidak sepadan),
    # best-effort — ralat sasaran di bawah ini yang mesti sampai kepada
    # pemilik, bukan ralat pembersihan yang menutupinya.
    _tutup_gerbang_ip_terbaik(p, wajib=_sepadan)

    if not _sepadan:
        petunjuk = ""
        if any(sig and (sig in internal1 or sig in external1)
              for sig in produksi_dikenali):
            petunjuk = " (PADAN PETANDA PRODUCTION YANG DIKENALI)"
        raise RuntimeError(
            "GERBANG SASARAN GAGAL (lapisan 3 — pengesahan muktamad): "
            f"bacaan AKHIR device internal={internal1!r} "
            f"external={external1!r}{petunjuk} TIDAK DITERIMA — "
            f"{_sebab1}. TIADA pengecualian, TIADA flag untuk memintas — "
            "ini satu-satunya perlindungan antara suite dan rekod kompaun "
            "SEBENAR pada production MBPG. Sahkan skrin TETAPAN ALAMAT "
            "IP dengan mata sebelum meneruskan.")

    print(f"  [GERBANG-IP] Sasaran production MBPG DISAHKAN dari BACAAN "
          f"DEVICE (bukan janji manusia): {jangka}")
    if _kosong1:
        print("  [GERBANG-IP] Medan Internal masih kosong — T-001 akan "
              "mengisinya (perubahan konfigurasi diluluskan pemilik).")


# ============================================================================
# Driver / page objects
# ============================================================================

def create_driver():
    print("\n" + "=" * 70)
    print("  IES APP — SUITE REGRESI MBJB (Excel V2.1.33, 54 TC)")
    print("=" * 70)
    # Cetak profil SEBELUM apa-apa berlaku: kalau seseorang tersilap
    # pilih production sedangkan staging yang dimaksudkan, ini peluang
    # terakhir untuk perasan sebelum data sebenar orang awam disentuh.
    print(_profile.describe(), flush=True)
    print("-" * 70)

    # Dilerai pada masa run, tidak pernah hardcode -- suite ini berjalan
    # tanpa diubah pada peranti mana-mana ahli pasukan (lihat
    # device_utils). Raise di sini disengajakan: peranti yang salah atau
    # tiada mesti menghentikan sesi SERTA-MERTA dengan mesej yang boleh
    # ditindaki, bukan 54 ERROR yang mengelirukan.
    udid = resolve_udid(APP_PACKAGE)

    # GERBANG SASARAN STAGING — mesti lulus SEBELUM baris ini pergi lebih
    # jauh (webdriver.Remote() di bawah melancarkan app sebenar). Lihat
    # blok komen "GERBANG SASARAN STAGING" di atas fungsi ini.
    _gerbang_sasaran_produksi(udid)

    # Dibaca sekali di sini (adb boleh dicapai dan peranti sudah
    # disahkan baik pada titik ini) dan disimpan untuk ringkasan --
    # dikawal sepenuhnya, kerana gagal membaca label kosmetik tidak
    # sekali-kali boleh membatalkan run.
    try:
        _RUN_META.update({
            "tester": TESTER_NAME,
            "device_udid": udid,
            "device_model": device_model(udid),
            "app_version": app_version(udid, APP_PACKAGE),
            "profile": PROFILE_NAME,
            "profile_label": PROFILE_LABEL,
            "pbt": PBT,
            "env": ENV,
            # MBJB: awalan nombor rekod yang DIJANGKA (JB015/JBM50…).
            # Direkod supaya laporan menunjukkan apa yang suite cari
            # apabila read_record_number() gagal.
            "record_prefix": RECORD_PREFIX,
        })
    except Exception:                                    # noqa: BLE001
        _RUN_META.setdefault("tester", TESTER_NAME)

    options = UiAutomator2Options()
    options.device_name = DEVICE_NAME
    options.set_capability("udid", udid)
    options.platform_name = PLATFORM_NAME
    options.app_package = APP_PACKAGE
    options.app_activity = APP_ACTIVITY
    # JANGAN set 'options.app' — APK sudah dipasang (lihat
    # tools/pasang_apk.md).
    options.no_reset = True
    options.full_reset = False
    options.automation_name = AUTOMATION_NAME
    options.set_capability("disableAndroidWatchers", True)

    print(f"  Appium       : {APPIUM_URL}")
    print(f"  Peranti      : {DEVICE_NAME} ({udid})")
    print(f"  App          : {APP_PACKAGE}/{APP_ACTIVITY}")
    print(f"  Tester       : {TESTER_NAME}")
    print("=" * 70 + "\n")

    driver = webdriver.Remote(APPIUM_URL, options=options)

    # ------------------------------------------------------------------
    # CORONG DRY-RUN — dipasang di sini, dan HANYA di sini.
    # ------------------------------------------------------------------
    # Titik ini dipilih dengan teliti. Ia SEJURUS selepas sesi wujud dan
    # SEBELUM apa-apa lain memegangnya — termasuk sebelum
    # implicitly_wait, dan sebelum gerbang IP di bawah. Gerbang IP itu
    # sendiri menavigasi skrin Tetapan production, jadi tapnya mesti
    # dicorongkan juga; ia bukan pengecualian istimewa.
    #
    # Selepas baris ini, `driver` ialah proksi. Tiada kod ujian dalam
    # projek ini pernah memegang sesi Appium yang tidak berkawal, dan
    # setiap WebElement yang diagihkan olehnya dibungkus semula. Itu
    # sebabnya 64 tapak panggilan tap yang diwarisi tidak perlu ditampal
    # satu per satu, dan tapak panggilan ke-65 yang ditulis esok
    # dilindungi pada hari ia ditulis.
    #
    # Baca guard/corong.py sebelum mengubah baris ini.
    driver = _corong.pasang(driver)
    _DRIVER_AKTIF[:] = [driver]

    driver.implicitly_wait(IMPLICIT_WAIT)

    # GERBANG SASARAN STAGING — lapisan (3), bukti bacaan device. Mesti
    # lulus SEBELUM baris ini pulangkan `driver` kepada fixture `driver`
    # — tiada test/fixture lain pernah memegang sesi yang IP-nya belum
    # disahkan dari skrin sebenar. Kegagalan di sini quit() driver dahulu
    # supaya tiada sesi separuh disahkan bocor. Lihat blok komen "GERBANG
    # SASARAN STAGING" di atas fungsi ini untuk kenapa lapisan ini TIDAK
    # boleh dijalankan sebelum webdriver.Remote() (ia perlukan sesi Appium
    # untuk membaca skrin TETAPAN ALAMAT IP sebenar).
    try:
        _gerbang_ip_muktamad_dari_device(driver)
    except Exception:
        print("  [GERBANG-IP] GAGAL — menutup sesi Appium yang baru "
              "dicipta sebelum melempar (tiada sesi separuh disahkan "
              "dibiarkan hidup)...")
        try:
            driver.quit()
        except Exception as e2:                              # noqa: BLE001
            print(f"  [GERBANG-IP] AMARAN: driver.quit() sendiri gagal "
                  f"({e2}) — sesi mungkin masih hidup pada Appium server")
        raise

    return driver


class Pages:
    """Satu bundle page object yang berkongsi driver sesi."""

    def __init__(self, driver):
        self.login = LoginPage(driver)
        self.pelarasan = PelarasanPage(driver)
        self.home = HomePage(driver)
        self.notis_amaran = NotisAmaranPage(driver)
        self.daftar_kompaun = DaftarKompaunPage(driver)
        self.notis_kompaun = NotisKompaunPage(driver)
        self.senarai = SenaraiPage(driver)
        self.hantar = HantarPage(driver)
        self.serah = SerahPage(driver)
        self.kemaskini = KemaskiniPage(driver)
        self.lesen = KompaunLesenPage(driver)
        self.bookmark = BookmarkPage(driver)
        self.sitaan = SitaanPage(driver)
        # self.printer DIBUANG — pencetak (sambungan Bluetooth) masih
        # di luar skop MBPG. self.cetak DITAMBAH 2026-09-13 (Fix #4) --
        # BUKAN untuk mencetak, hanya untuk tutup_popup_cetak() dalam
        # pastikan_di_home(). Lihat nota di import CetakPage di atas.
        self.cetak = CetakPage(driver)


@pytest.fixture(scope="session")
def driver():
    drv = create_driver()
    yield drv
    print("\n  [CLEANUP] Menutup driver...")
    drv.quit()


@pytest.fixture(scope="session")
def pages(driver):
    return Pages(driver)


# ============================================================================
# Pelarasan (Menu Selaras) — satu pas, verdict per-item T-001..T-011
# ============================================================================

# MBJB: T-008 (Selaras Maklumat Pelesen) — OPERASI >4 JAM.
#
# 2026-08-01, Loh: Loh sendiri mencetuskan T-008 SECARA TIDAK SENGAJA
# walaupun 121,871 rekod SUDAH ada pada device (run 2026-07-31), memaksa
# force-kill app + tetap semula IP dengan tangan. Laporan run lepas
# sendiri sudah berkata "guna MBPG_SKIP_T008=1 selepas ini" — dan ia
# dibiarkan boleh tercetus tanpa flag itu. Dokumentasi bukan gerbang;
# kod mesti jadi gerbang. LALAI DITERBALIKKAN di sini (bukan hanya
# didokumenkan): operasi 4 jam tidak boleh menjadi kelakuan lalai.
#
# MBIP melangkau T-008 atas arahan pemilik yang KHUSUS MBIP (dan kerana
# sync 52k rekod Pelesen memakan ~sejam masa peranti). Sheet
# MBPG-TC-T-008 WUJUD dalam workbook V2.1.33, jadi keputusan MBIP itu
# TIDAK berpindah dengan sendirinya ke sini — T-008 tetap TERSEDIA untuk
# dijalankan, cuma tidak lagi SECARA LALAI.
#
# LALAI BAHARU: T-008 DILANGKAU melainkan MBPG_JALANKAN_T008=1 diset
# SECARA EKSPLISIT. MBPG_SKIP_T008=1 DIKEKALKAN sebagai ALIAS supaya
# skrip/kebiasaan lama tidak pecah — ia SENTIASA bermakna langkau, tidak
# kira apa MBPG_JALANKAN_T008 kata.
_SKIP_T008 = os.environ.get("MBPG_SKIP_T008") == "1"          # alias lama
_JALANKAN_T008 = os.environ.get("MBPG_JALANKAN_T008") == "1"  # lalai baharu
# Override sedar SAHAJA untuk gerbang data di bawah (device baharu/
# direset) — MBPG_JALANKAN_T008=1 MASIH wajib bersama; dua isyarat
# berasingan, bukan satu.
_PAKSA_T008 = os.environ.get("MBPG_PAKSA_T008") == "1"

_T_IDS = [f"MBPG-TC-T-{n:03d}" for n in range(1, 12)]    # T-001..T-011


# ----------------------------------------------------------------------
# AMARAN 10 SAAT — pembantu boleh guna semula untuk MANA-MANA operasi
# >10 minit (bukan hanya T-008). Kos 10 saat murah berbanding kos silap
# ~4 JAM (insiden Loh 2026-08-01 di atas). Panggil SEBELUM operasi
# bermula, bukan selepas.
# ----------------------------------------------------------------------

def amaran_operasi_panjang(nama, anggaran, saat=10):
    """Cetak amaran dan BENAR-BENAR tunggu `saat` saat (lalai 10) sebelum
    operasi panjang bermula, supaya manusia ada tetingkap Ctrl+C nyata
    sebelum kos masa besar ditanggung. Guna `_time` modul-peringkat yang
    sudah diimport (import time as _time) — TIADA import kedua di sini.
    """
    print("\n" + "!" * 70)
    print(f">>> OPERASI PANJANG: {nama}, anggaran {anggaran}.")
    print(f"    Ctrl+C dalam {saat} saat untuk batal. <")
    print("!" * 70 + "\n")
    _time.sleep(saat)


# ----------------------------------------------------------------------
# GERBANG DATA — semak sama ada Pelesen SUDAH disegerak pada device
# SEBELUM T-008 dibenarkan berjalan, walaupun MBPG_JALANKAN_T008=1
# diset. Manusia tidak perlu ingat satu pemboleh ubah; kod yang ingat.
#
# Sumber bukti: penanda tempatan reports/pelesen_sync_marker.json yang
# DITULIS OLEH conftest.py sendiri sebaik T-008 BERJAYA (lihat pemanggil
# _tulis_penanda_pelesen() dalam gelung pelarasan_results di bawah).
# device_utils.py TIDAK ada kaedah untuk mengesan bilangan rekod Pelesen
# tersimpan pada device (satu-satunya bukti device langsung ialah
# menjalankan sync itu sendiri dan membaca overlay kemajuan/mesej akhir
# — iaitu operasi yang gerbang ini wujud untuk MENGELAKKAN) — permintaan
# fungsi didaftar dalam recon/PAPAN.md untuk syakhram.
#
# GAGAL-SELAMAT KE ARAH MELANGKAU: SEBARANG ketidakpastian (fail tiada,
# rosak, profil tidak sepadan) memulangkan TIDAK_PASTI, BUKAN "TIADA".
# Ketiadaan bukti bukan bukti ketiadaan. TIDAK_PASTI TIDAK menghalang
# T-008 berjalan dengan sendirinya (lalai kod #1 di atas sudah wajibkan
# manusia set MBPG_JALANKAN_T008=1 secara eksplisit sebelum sampai ke
# sini) — ia hanya bermakna gerbang DATA ini tidak dapat menambah
# perlindungan ekstra untuk kes itu. Hanya status ADA (bukti positif
# sync lepas BERJAYA untuk profil AKTIF ini) yang menghalang, dan itu
# pun boleh dipintas SECARA SEDAR dengan MBPG_PAKSA_T008=1.
# ----------------------------------------------------------------------

_PENANDA_PELESEN_PATH = os.path.abspath(os.path.join(
    os.path.dirname(__file__), "..", "reports", "pelesen_sync_marker.json"))


def _baca_penanda_pelesen():
    """Baca penanda sync T-008 lepas. Pulangkan dict atau None.
    Gagal-selamat: SEBARANG masalah (fail tiada, JSON rosak, medan
    wajib hilang) -> None ("tidak dapat ditentukan"), TIDAK PERNAH raise.
    """
    import json
    try:
        with open(_PENANDA_PELESEN_PATH, "r", encoding="utf-8") as fh:
            data = json.load(fh)
        if not isinstance(data, dict) or not data.get("profile") \
                or not data.get("ts"):
            return None
        return data
    except Exception:                                        # noqa: BLE001
        return None


def _tulis_penanda_pelesen(mesej):
    """Tulis penanda T-008 BERJAYA untuk profil AKTIF, dipanggil HANYA
    selepas ok is True dalam gelung pelarasan_results di bawah.
    Kegagalan tulis TIDAK PERNAH menjejaskan keputusan TC semasa — ini
    forensik/gerbang MASA DEPAN sahaja, padanan falsafah ledger forensik
    _tulis_forensik_nombor_rekod() di atas."""
    import json
    import datetime
    entry = {
        "profile": PROFILE_NAME,
        "device_udid": _RUN_META.get("device_udid"),
        "ts": datetime.datetime.now().isoformat(timespec="seconds"),
        "mesej": mesej,
    }
    try:
        os.makedirs(os.path.dirname(_PENANDA_PELESEN_PATH), exist_ok=True)
        with open(_PENANDA_PELESEN_PATH, "w", encoding="utf-8") as fh:
            json.dump(entry, fh, ensure_ascii=False, indent=2)
        print(f"  [T-008] Penanda sync ditulis -> {_PENANDA_PELESEN_PATH}")
    except Exception as e:                                   # noqa: BLE001
        print(f"  [T-008] AMARAN: gagal tulis penanda sync "
              f"({type(e).__name__}: {e}) — gerbang data run akan datang "
              f"tidak akan nampak bukti run ini")


def _semak_data_pelesen_sudah_ada():
    """GERBANG DATA. Pulangkan (status, mesej); status ialah 'ADA' atau
    'TIDAK_PASTI' (TIDAK PERNAH 'TIADA' — lihat nota gagal-selamat di
    atas blok ini)."""
    penanda = _baca_penanda_pelesen()
    if penanda is None:
        return ("TIDAK_PASTI",
                "tiada penanda tempatan reports/pelesen_sync_marker.json "
                "(sync lepas belum direkod oleh kod ini, atau ini "
                "profil/device baharu)")
    if penanda.get("profile") != PROFILE_NAME:
        return ("TIDAK_PASTI",
                f"penanda wujud tetapi untuk profil "
                f"{penanda.get('profile')!r}, bukan profil aktif "
                f"{PROFILE_NAME!r} — tidak dipercayai merentas profil")
    return ("ADA",
            f"penanda tempatan menunjukkan T-008 sudah BERJAYA pada "
            f"profil {PROFILE_NAME!r} pada {penanda.get('ts')} "
            f"({penanda.get('mesej')})")


class RestoreGagal(BaseException):
    """Tetapan diubah untuk ujian dan TIDAK dapat dipulihkan.

    BaseException atas sebab yang sama seperti DryRunViolation: ia tidak
    boleh ditelan oleh gelung cuba-semula. Peranti kini berada dalam
    keadaan yang BUKAN keadaan asalnya, dan tiada apa yang patut
    diteruskan sehingga manusia melihatnya.
    """


def _t001_ip_masuk_semula_sama(p):
    """MBPG-TC-T-001 — masuk semula IP YANG SAMA + SIMPAN.

    Diluluskan pemilik 2026-08-07. Tiada nilai berubah: kita menulis
    113.211.155.174 ke atas 113.211.155.174. Tiada langkah restore
    diperlukan kerana tiada apa yang beralih.

    SIMPAN dibenarkan di sini oleh pengecualian konteks-Tetapan dalam
    corong (guard/dasar.konteks_tetapan) — ia menulis config LOKAL
    device, bukan rekod production.
    """
    jangka = _profile.IP_PRODUCTION_MBPG
    asal_int, asal_ext = p.baca_tetapan_alamat_ip()
    print(f"  [T-001] Nilai asal: internal={asal_int!r} external={asal_ext!r}")
    if asal_int != jangka or asal_ext != jangka:
        # Gerbang IP sepatutnya sudah menangkap ini sebelum sebarang test.
        print(f"  [T-001] GAGAL: IP device bukan {jangka!r} — TIDAK menulis "
              f"apa-apa. Betulkan dengan tangan.")
        return False
    p.set_tetapan_alamat_ip(jangka, jangka)
    semak_int, semak_ext = p.baca_tetapan_alamat_ip()
    if semak_int == jangka and semak_ext == jangka:
        print(f"  [T-001] IP diterima dan kekal {jangka!r} selepas SIMPAN "
              f"— PASS")
        return True
    print(f"  [T-001] GAGAL selepas SIMPAN: internal={semak_int!r} "
          f"external={semak_ext!r}")
    return False


def _t002_lesen_ubah_dan_restore(p):
    """MBPG-TC-T-002 — baca asal, ubah, SIMPAN, verify, RESTORE, SIMPAN.

    Diluluskan pemilik 2026-08-07. Restore adalah WAJIB: kalau ia gagal,
    peranti tinggal membawa lesen ujian dan setiap run selepas ini (dan
    setiap penggunaan sebenar peranti itu) rosak.

    Nilai ujian sengaja dijana daripada nilai asal dengan menukar SATU
    digit terakhir, supaya ia kekal panjang/format yang sah dan jelas
    sementara.
    """
    asal = p.baca_tetapan_pelbagai()
    print(f"  [T-002] Lesen asal: {asal!r}")
    if not asal:
        print("  [T-002] GAGAL: tidak dapat membaca lesen asal — TIDAK "
              "mengubah apa-apa (tanpa nilai asal, restore mustahil).")
        return False

    ujian = asal[:-1] + ("0" if asal[-1] != "0" else "1")

    try:
        p.set_tetapan_pelbagai(ujian)
        selepas = p.baca_tetapan_pelbagai()
        diterima = (selepas == ujian)
        print(f"  [T-002] Selepas SIMPAN nilai ujian: {selepas!r} "
              f"({'diterima' if diterima else 'TIDAK diterima'})")
    finally:
        # RESTORE dalam `finally`: walaupun langkah ujian melempar, kita
        # tetap cuba memulangkan peranti kepada keadaan asalnya.
        try:
            p.set_tetapan_pelbagai(asal)
            pulih = p.baca_tetapan_pelbagai()
        except BaseException as e:                           # noqa: BLE001
            raise RestoreGagal(
                f"T-002: RESTORE lesen GAGAL dengan {type(e).__name__}: "
                f"{e}\n"
                f"  Nilai ASAL yang perlu dikembalikan : {asal!r}\n"
                f"  Nilai UJIAN yang mungkin tertinggal: {ujian!r}\n"
                f"  HENTI. Betulkan dengan tangan di Menu Selaras > "
                f"TETAPAN PELBAGAI sebelum apa-apa run seterusnya.")

    if pulih != asal:
        raise RestoreGagal(
            f"T-002: RESTORE lesen TIDAK SAH.\n"
            f"  Dijangka : {asal!r}\n"
            f"  Sebenar  : {pulih!r}\n"
            f"  HENTI. Peranti kini membawa lesen yang SALAH. Betulkan "
            f"dengan tangan di Menu Selaras > TETAPAN PELBAGAI.")

    print(f"  [T-002] Lesen dipulihkan kepada {asal!r} — disahkan baca-balik")
    return diterima


def _t010_skrin_utama_ubah_dan_restore(p):
    """MBPG-TC-T-010 — pilih pilihan lain, verify, RESTORE pilihan asal.

    Popup PILIHAN SKRIN UTAMA menyimpan pada pemilihan (tiada butang
    SIMPAN berasingan diperhatikan pada MBJB), jadi "restore" bermakna
    memilih semula pilihan asal.

    Dilaksanakan oleh pelarasan_page.tetapan_skrin_utama(), yang memilih
    DEFAULT dan tidak mengubah skrin pendaratan app. Pembungkus ini wujud
    supaya niat restore direkod di satu tempat dengan T-001/T-002, dan
    supaya kegagalan dilaporkan dengan perbendaharaan kata yang sama.
    """
    ok = p.tetapan_skrin_utama()
    if ok:
        print("  [T-010] Pilihan skrin utama boleh dibuka dan dipilih; "
              "DEFAULT dipilih supaya skrin pendaratan tidak berubah — PASS")
    return ok


def _keputusan_t008():
    """Pulangkan (patut_langkau: bool, sebab: str) untuk item T-008 dalam
    gelung pelarasan_results. Susunan semakan (gagal-tertutup ke arah
    LANGKAU pada setiap peringkat):
      1. MBPG_SKIP_T008=1 (alias lama) -> langkau, tidak kira apa-apa lagi.
      2. LALAI BAHARU: MBPG_JALANKAN_T008 tidak diset -> langkau.
      3. MBPG_JALANKAN_T008=1 diset (manusia EKSPLISIT mahu jalan) ->
         GERBANG DATA: penanda tempatan kata data profil ini SUDAH ada
         -> langkau JUGA, melainkan MBPG_PAKSA_T008=1 turut diset.
    """
    if _SKIP_T008:
        return True, ("MBPG_SKIP_T008=1 — Selaras Maklumat Pelesen sengaja "
                      "dilangkau (alias eksplisit)")
    if not _JALANKAN_T008:
        return True, (
            "LALAI: T-008 dilangkau (operasi >4 JAM diperhati, 121,871 "
            "rekod pada run 2026-07-31 — lihat CLAUDE.md 'SELARAS "
            "PELESEN'). Data KEKAL pada device antara run (no_reset=True), "
            "jadi ini BUKAN membazir kerja — ia mengelakkan sync SEMULA "
            "yang tidak perlu. Untuk menjalankannya dengan SENGAJA: set "
            "MBPG_JALANKAN_T008=1")
    status, mesej = _semak_data_pelesen_sudah_ada()
    if status == "ADA" and not _PAKSA_T008:
        return True, (
            f"GERBANG DATA: {mesej}. MBPG_JALANKAN_T008=1 diset tetapi "
            f"dilangkau JUGA kerana data nampak sudah ada — set "
            f"MBPG_PAKSA_T008=1 (BERSAMA MBPG_JALANKAN_T008=1) untuk "
            f"paksa jalan semula (cth device direset/dipasang semula APK)")
    if status == "TIDAK_PASTI":
        print(f"  [T-008] Gerbang data: {mesej} — MBPG_JALANKAN_T008=1 "
              f"diset secara eksplisit, jadi T-008 diteruskan")
    else:
        print(f"  [T-008] Gerbang data: {mesej}, TETAPI MBPG_PAKSA_T008=1 "
              f"diset — meneruskan atas arahan sedar")
    return False, ""


@pytest.fixture(scope="session")
def pelarasan_results(pages):
    """Jalankan keseluruhan urutan Menu Selaras sekali, sebelum login,
    merekod verdict (ok, mesej) per-item berkunci ID TC. Item yang gagal
    TIDAK menghentikan urutan: aliran pulih (kosongkan alert, buka semula
    menu) dan bergerak ke item seterusnya, supaya setiap test T mendapat
    verdictnya sendiri yang sebenar.

    ok is None bermakna DILANGKAU — test akan pytest.skip, bukan pass.
    """
    p = pages.pelarasan
    results = {}

    # Escape hatch untuk rerun bersasar: MBPG_SKIP_PELARASAN=1 melangkau
    # keseluruhan urutan Menu Selaras (~6-8 minit masa peranti DENGAN
    # T-008 dilangkau -- itu lalai kod sejak 2026-08-01. Kalau
    # MBPG_JALANKAN_T008=1 turut diset, anggaran ini SALAH >40x --
    # T-008 sendiri >4 JAM, lihat blok komen di atas _keputusan_t008()).
    # HANYA untuk menjalankan semula test bukan-T semasa pembangunan/
    # debug — run regresi penuh TIDAK boleh mensetnya.
    #
    # MBJB: MBIP memulangkan (True, ...) di sini, iaitu LAPAN PASS PALSU.
    # Di sini ia (None, ...) -> SKIPPED. PERATURAN KERAS #6.
    if os.environ.get("MBPG_SKIP_PELARASAN") == "1":
        print("  [PELARASAN] MBPG_SKIP_PELARASAN=1 — urutan Menu Selaras "
              "dilangkau (mod rerun bersasar); T-001..T-011 = SKIPPED")
        return {tc: (None, "dilangkau oleh MBPG_SKIP_PELARASAN=1 — "
                           "bukan keputusan ujian") for tc in _T_IDS}

    print("\n" + "-" * 60)
    print("  FASA 0: PELARASAN (MENU SELARAS) — T-001..T-011")
    if _SKIP_T008:
        print("  (T-008 Pelesen dilangkau: MBPG_SKIP_T008=1 — alias)")
    elif not _JALANKAN_T008:
        print("  (T-008 Pelesen dilangkau: LALAI -- set MBPG_JALANKAN_T008=1 "
              "untuk menjalankannya dengan sengaja)")
    else:
        print("  (T-008 Pelesen: MBPG_JALANKAN_T008=1 diset -- gerbang "
              "data akan disemak sebelum ia benar-benar bermula)")
    print("-" * 60)

    try:
        p.ensure_on_login_screen()
        p.open_menu_selaras()
    except Exception as e:
        msg = f"Menu Selaras tidak dapat dibuka: {type(e).__name__}: {e}"
        print(f"  [PELARASAN] {msg}")
        for tc in _T_IDS:
            results[tc] = (False, msg)
        return results

    steps = [
        # ------------------------------------------------------------
        # T-001 / T-002 — SIMPAN DIBENARKAN (keputusan pemilik 2026-08-07)
        # ------------------------------------------------------------
        # Skrin Tetapan menulis KONFIGURASI LOKAL peranti (alamat server,
        # lesen aplikasi), bukan rekod kompaun. Corong membenarkan SIMPAN
        # di sini melalui pengecualian konteks-Tetapan yang disahkan
        # secara berstruktur — lihat guard/dasar.konteks_tetapan().
        #
        # T-001 tidak mengubah apa-apa (IP sama ditulis semula), jadi ia
        # tidak perlu restore. T-002 MENGUBAH, jadi restorenya WAJIB dan
        # kegagalan restore membangkitkan RestoreGagal (BaseException) —
        # bukan kegagalan test biasa, kerana peranti tinggal salah.
        ("MBPG-TC-T-001", lambda: _t001_ip_masuk_semula_sama(p)),
        ("MBPG-TC-T-002", lambda: _t002_lesen_ubah_dan_restore(p)),
        ("MBPG-TC-T-003", p.selaras_pengguna_apps),
        ("MBPG-TC-T-004", p.selaras_maklumat_alamat),
        ("MBPG-TC-T-005", p.selaras_maklumat_kompaun),
        ("MBPG-TC-T-006", p.selaras_jenis_kenderaan),
        ("MBPG-TC-T-007", p.selaras_maklumat_warna),
        # T-008 (Selaras Maklumat Pelesen) SENGAJA TIADA DALAM SENARAI
        # INI. Arahan pemilik 2026-08-07 ialah melangkaunya, dan operasi
        # itu >4 JAM. Menyimpan `p.selaras_maklumat_pelesen` di sini
        # sebagai rujukan mati yang dilindungi oleh satu `continue` di
        # bawah adalah perangkap: buang `continue` itu suatu hari dan
        # operasi 4 jam menyala pada peranti production. Verdict
        # langkaunya ditetapkan sebelum gelung ini bermula.
        ("MBPG-TC-T-009", p.selaras_barang_sita),
        # MBJB: T-010/T-011 tiada padanan test dalam MBIP v3 yang
        # dimuat naik. Kedua-duanya item Menu Selaras — dijalankan dalam
        # pas yang sama supaya menu hanya dibuka sekali.
        ("MBPG-TC-T-010", lambda: _t010_skrin_utama_ubah_dan_restore(p)),
        ("MBPG-TC-T-011", p.semak_kemaskini),
    ]

    # ----------------------------------------------------------------
    # T-008 DILANGKAU TANPA SYARAT untuk MBPG.
    # ----------------------------------------------------------------
    # Arahan terus pemilik 2026-08-07: "kena skipped juga tc yang selaras
    # pelesen".
    #
    # Gerbang opt-in MBJB (_keputusan_t008 / MBPG_JALANKAN_T008 /
    # MBPG_PAKSA_T008) SENGAJA TIDAK dirujuk. Kalau ia dirujuk, satu
    # pembolehubah persekitaran yang tertinggal dalam satu terminal sudah
    # cukup untuk mencetuskan operasi >4 JAM pada peranti production.
    # Arahan pemilik bukan sesuatu yang env var patut boleh batalkan.
    results["MBPG-TC-T-008"] = (None, skop.sebab_rasmi("MBPG-TC-T-008"))
    print("  [PELARASAN] T-008 Selaras Pelesen DILANGKAU (arahan pemilik) "
          "— tidak dijalankan langsung.")

    for tc_id, fn in steps:
        try:
            ret = fn()
            if ret is False:
                # _run_selaras_item pulangkan False bila tiada popup
                # pengesahan muncul — expected result Excel MEMANG mesej
                # pengesahan itu, jadi itu kegagalan per-item.
                results[tc_id] = (
                    False,
                    "tiada popup pengesahan dalam tempoh menunggu")
            else:
                results[tc_id] = (True, "OK")
                # Cabang penanda-pelesen MBJB DIBUANG: T-008 tiada dalam
                # `steps` lagi, jadi ia tidak akan pernah dicapai. Kod
                # mati yang menyebut Pelesen dalam gelung ini hanya akan
                # mengelirukan pembaca seterusnya tentang sama ada ia
                # boleh berjalan.
        except Exception as e:
            results[tc_id] = (False, f"{type(e).__name__}: {e}")
            print(f"  [PELARASAN] {tc_id} GAGAL ({e}) — memulihkan untuk "
                  f"item seterusnya...")
            # Pemulihan: kosongkan alert yang menutup skrin; kalau popup
            # Menu Selaras sudah hilang (cth mati pada sub-skrin), buka
            # semula.
            try:
                pages.home.dismiss_native_alerts(
                    first_timeout=2, context="pemulihan pelarasan")
                if not p.is_element_present(p.MENU_TETAPAN_ALAMAT_IP,
                                            timeout=3):
                    p.ensure_on_login_screen()
                    p.open_menu_selaras()
            except Exception as e2:
                print(f"  [PELARASAN] Pemulihan gagal ({e2}) — item "
                      f"seterusnya akan melapor kegagalannya sendiri")

    try:
        p.close_menu_selaras()
    except Exception as e:
        print(f"  [PELARASAN] AMARAN: Menu Selaras tidak dapat ditutup "
              f"dengan bersih ({e}) — login() ada tangga relaunchnya "
              f"sendiri")

    for tc_id in _T_IDS:
        ok, msg = results.get(tc_id, (False, "tidak dijalankan"))
        label = "SKIP" if ok is None else ("PASS" if ok else "FAIL")
        print(f"  [PELARASAN] {tc_id}: {label} — {msg}")
    return results


# ============================================================================
# Login — show-stopper suite
# ============================================================================

@pytest.fixture(scope="session")
def logged_in(pages, pelarasan_results):
    """FASA 1: Login. Kalau ini raise (login() sudah retry dengan tap
    mentah dan relaunch bersih secara dalaman), pytest melaporkan setiap
    test yang bergantung padanya sebagai ERROR dan tidak menjalankannya.

    LESEN BUKAN IMEI — dakwaan lama DITARIK BALIK oleh pemilik.
    Sumber: recon/PAPAN.md Seksyen 1.1 dan reports/fasa2-bootstrap.md
    Seksyen 2.2. `lesen_aplikasi` ialah TOKEN yang didaftarkan di portal
    PBT dan disahkan di SERVER; ia BUKAN IMEI peranti. Bukti: lesen MBIP
    `352405067769401` (mbip-testing/v3/profiles/mbip-staging.json;
    mbip-testing/v3/HANDOFF-2026-07-29.md:12,:36) berjaya berpuluh run
    pada Ulefone Armor 27 yang IMEI-nya `357616400186856` — dua nilai
    yang BERBEZA. Excel MBPG-TC-T-002!C8 menyokong: "the IMEI must be
    inserted at the PBT portal". `m50`/`m51` hanyalah label peranti di
    pejabat, BUKAN syarat padanan. Jadi kalau login ditolak, JANGAN buang
    masa membandingkan lesen dengan IMEI tempatan — mintakan admin PBT
    mendaftarkan token itu untuk MBJB.

    ALERT SELEPAS LOGIN BUKAN KEGAGALAN LOGIN — fakta peranti, disahkan
    Loh 2026-07-30 (reports/fasa2-bootstrap.md Seksyen 2.3): sejurus
    selepas login BERJAYA, alert `Alert` / `Error: Unable to connect
    device` muncul. Itu kegagalan menyambung printer Bluetooth (printer
    kini DALAM SKOP PENUH — penangguhan DIBATALKAN 2026-07-30, lihat
    PAPAN.md §1.5) dan ia akan muncul pada SETIAP login selagi printer
    belum bersambung — akan berhenti muncul sebaik printer disambungkan.
    Selepas alert ditolak, skrin utama terpapar penuh
    dan login memang sah. Oleh itu pengesahan di bawah berasaskan
    KEHADIRAN SKRIN UTAMA (kad content-desc 'NOTIS AMARAN',
    base_page.py:80), BUKAN ketiadaan alert. Alert dikosongkan DAHULU
    kerana selagi satu alert asli terpapar, UiAutomator hanya melihat
    tetingkap dialog dan grid di belakangnya kelihatan "tiada" — itulah
    cara kod boleh salah lapor "login gagal" sepanjang Fasa 5.

    JANGAN tukar semakan ini kepada tajuk skrin utama. Tajuk itu ialah
    `KOMPUAN e-PBT` (resource-id 'appbar-content-title-text') — EJAAN APP
    SALAH, disahkan pada dump device `ui_dumps/40_skrin_utama.xml`, jadi
    mana-mana locator yang mencari "KOMPAUN e-PBT" pada skrin utama TIDAK
    akan padan dan akan salah lapor "login gagal" pada setiap TC.
    (`APLIKASI KOMPAUN e-PBT` — ejaan BETUL — ialah tajuk skrin LOGIN,
    `ui_dumps/30_skrin_login.xml`; pages/login_page.py:41 memang guna nilai
    itu untuk mengesan skrin login dan ia BETUL, jangan "selaraskan"
    kedua-duanya.) Kad `NOTIS AMARAN` (base_page.py:80) hanya wujud pada
    grid utama — itulah sebab ia yang dipakai.

    Akaun: `admin` / `<kata-laluan: profil>` BERJAYA pada percubaan pertama
    (reports/fasa2-bootstrap.md Seksyen 2.3). Kredensial diambil dari
    profil aktif, tidak pernah ditulis di sini.
    """
    print("\n" + "-" * 60)
    print("  FASA 1: LOGIN")
    print("-" * 60)
    # Kosongkan alert DAHULU. Kalau satu alert (hasil Selaras yang lewat,
    # atau alert printer) masih terpapar, semakan "sudah log masuk" di
    # bawah membaca tetingkap dialog, bukan skrin app — dan ia akan
    # menaip kredensial ke dalam medan yang tidak wujud.
    pages.home.drain_printer_alert()
    pages.home.dismiss_native_alerts(first_timeout=2,
                                     context="sebelum login")
    # T-012 (Remember Me) berjalan sebelum pengguna pertama fixture ini
    # dan boleh meninggalkan app dalam keadaan sudah log masuk pada skrin
    # utama — terima keadaan itu, jangan menaip membuta ke dalam medan
    # yang tidak wujud.
    if pages.home.is_element_present(pages.home.HOME_SCREEN_INDICATOR,
                                     timeout=5):
        print("  [LOGIN] Sudah log masuk (skrin utama kelihatan) — PASS\n")
        return True
    pages.login.login(
        TEST_CREDENTIALS["username"],
        TEST_CREDENTIALS["password"],
    )
    # Alert printer tiba SELEPAS login berjaya, dan alert asli MBJB
    # BERATUR (fasa2-bootstrap.md "PENEMUAN TEKNIKAL BAHARU" #2: satu
    # alert muncul SEMULA selepas ditolak sekali). Kosongkan di sini;
    # is_home_screen_displayed() menguras sekali lagi kalau perlu
    # (home_page.py:51-54). Dua lapisan, bukan satu.
    pages.home.drain_printer_alert()
    pages.home.dismiss_native_alerts(first_timeout=2,
                                     context="selepas login")
    home_ok = pages.home.is_home_screen_displayed()
    if not home_ok:
        # KEGAGALAN LOGIN SEBENAR — cetak diagnostik lesen/IMEI SEKARANG,
        # bukan hanya melalui laluan `device_utils.py --check` berasingan
        # (jurang yang syakhram jumpa semasa mengaudit device_utils,
        # 2026-07-31). Tanpa ini, dua punca yang kelihatan SAMA dari luar
        # tidak dibezakan dalam log:
        #   (1) BLOCKER LUARAN — IMEI peranti belum didaftarkan di portal
        #       MBJB, server tolak lesen. Bukan bug kita.
        #   (2) bug automation — locator/autofill/aksara tercicir/alert
        #       beratur.
        # Tanpa cetakan ini sesi seterusnya memburu pepijat automation
        # yang tidak wujud selama berjam-jam — sudah berlaku dalam projek
        # ini. lapor_lesen_dan_imei() milik device_utils (syakhram) —
        # DIPANGGIL sahaja, TIDAK disalin. Ia sengaja TIDAK memberi
        # verdict: lesen disahkan di SERVER, jadi `lesen_aplikasi` ialah
        # TOKEN portal PBT, BUKAN IMEI tempatan — ketidakpadanan adalah
        # NORMAL. Bukti: lesen MBIP 352405067769401 berjaya berpuluh run
        # pada device INI dan itu bukan IMEI device ini (recon/PAPAN.md
        # Seksyen 1.1; Excel MBPG-TC-T-002!C8: "the IMEI must be inserted
        # at the PBT portal").
        try:
            print("\n" + "-" * 60)
            print("  [LOGIN GAGAL] Diagnostik lesen + IMEI (BUKAN "
                  "perbandingan — lihat nota di bawah):")
            print(lapor_lesen_dan_imei(_RUN_META.get("device_udid"),
                                       LICENSE_SETTINGS["lesen_aplikasi"]))
            print("-" * 60 + "\n")
        except Exception as e:                               # noqa: BLE001
            print(f"  [LOGIN GAGAL] AMARAN: diagnostik lesen/IMEI sendiri "
                  f"gagal ({type(e).__name__}: {e}) — tidak menghalang "
                  f"kegagalan login di bawah daripada dilaporkan")
    assert home_ok, (
        "FAIL: skrin utama tidak dipaparkan selepas login. NOTA: alert "
        "'Error: Unable to connect device' SAHAJA BUKAN bukti login "
        "gagal — itu kegagalan sambung printer Bluetooth (printer kini "
        "DALAM SKOP PENUH, PAPAN.md §1.5; alert ini muncul selagi printer "
        "belum bersambung dan berhenti sebaik ia bersambung) dan "
        "ia sudah dikosongkan sebelum semakan ini. Kalau kad 'NOTIS "
        "AMARAN' tetap tiada selepas alert dikosongkan, barulah login "
        "benar-benar gagal. Diagnostik lesen/IMEI dicetak di atas — kalau "
        "kedua-dua lesen ditolak SERVER, itu BLOCKER LUARAN (daftar IMEI "
        "peranti di portal MBJB), BUKAN bug automation.")
    print("  [ASSERTION PASS] Skrin utama dipaparkan selepas login\n")
    return True


# Lejar nombor rekod yang benar-benar dicipta semasa run ini.
#
# Bila sesuatu gagal, soalan pertama ialah "rekod mana?" -- tanpa nombor
# sebenar (contoh JB015N260227001) tiada cara mencari baris itu dalam
# pangkalan data untuk menyiasat puncanya. Status sahaja tidak memadai.
_ARTIFACTS = {}


def record_artifact(tc_id, **values):
    """Simpan nilai yang dicipta oleh sesuatu TC, cth no_kompaun/no_notis.

    Dipanggil dari lapisan pages sebaik nombor kelihatan di skrin.
    Selamat dipanggil berulang kali; nilai digabung.

    Guna: artifacts("MBPG-TC-N-001", no_notis="JB015N260227001")
    """
    if not tc_id:
        return
    slot = _ARTIFACTS.setdefault(tc_id, {})
    for k, v in values.items():
        if v:
            slot[k] = str(v).strip()


# ============================================================================
# Ledger forensik atas cakera — SATU-HALA, HANYA TULIS
#
# Matlamat hari ini ialah SATU KERTAS TERCETAK, dan rantaian yang mesti
# dibuktikan ialah "nombor dicipta = nombor pada popup = nombor pada
# kertas". Sebelum ini nombor itu hidup HANYA dalam _ARTIFACTS/
# created_records dalam ingatan proses pytest. Persekitaran ini menyapu
# proses latar pada ~40 minit (disahkan — satu run E2E terbunuh separuh
# jalan, PAPAN.md "SELARAS PELESEN"). Kalau itu berlaku SELEPAS satu
# nombor rekod dicipta tetapi SEBELUM run tamat, nombor itu hilang buat
# selama-lamanya dan rekod baharu terpaksa dicipta pada staging semata
# untuk mendapatkannya semula — arahan Loh 2026-07-31 (kerja ketiga).
#
# >>> PERANGKAP — BACA SEBELUM UBAH <<<
# Fail ini FORENSIK SAHAJA. Ia TIDAK PERNAH dibaca semula secara automatik
# ke dalam created_records. Kalau ia dibaca semula, kita menghidupkan
# semula pepijat TERBESAR MBIP: TC Cetak/Serah/Kemaskini "lulus" kerana
# menjumpai rekod LAMA dari run yang sudah mati, bukan rekod run SEMASA
# — tepat perkara Peraturan Keras #7 wujud untuk menghalang. Ledger
# dalam-ingatan (created_records, di bawah) kekal SATU-SATUNYA sumber
# untuk keputusan TC. Kalau seseorang menambah cara memuatkan fail ini
# semula, ia MESTI opt-in eksplisit manusia, beramaran lantang, dan
# direkod dalam results.json supaya laporan tidak boleh mendakwa rekod
# itu dicipta oleh run semasa. TIADA kod pemuatan-semula automatik
# ditambah di sini — sengaja.
# ============================================================================

_RUN_ID = [None]           # diisi dalam pytest_sessionstart
_CURRENT_TC_ID = [None]    # diisi dalam pytest_runtest_setup, per test

_FORENSIK_LEDGER_PATH = os.path.abspath(os.path.join(
    os.path.dirname(__file__), "..", "reports",
    "record_ledger_forensik.jsonl"))


def _tulis_forensik_nombor_rekod(jenis, no):
    """SATU baris JSON Lines ke reports/record_ledger_forensik.jsonl,
    flush + fsync SERTA-MERTA supaya baris ini terselamat walaupun proses
    dibunuh sebaik panggilan ini pulang (sapuan persekitaran ~40 minit /
    kill -9). append-only; tiada pembaca automatik di mana-mana dalam
    fail ini (lihat amaran "PERANGKAP" di atas).

    Kegagalan menulis TIDAK PERNAH menghentikan run — created_records
    dalam ingatan kekal authoritative untuk keputusan TC walau apa pun
    berlaku di sini.
    """
    import json
    import datetime
    entry = {
        "ts": datetime.datetime.now().isoformat(timespec="milliseconds"),
        "run_id": _RUN_ID[0],
        "profile": PROFILE_NAME,
        "tc_id": _CURRENT_TC_ID[0],
        "jenis": jenis,
        "no_rekod": no,
    }
    try:
        os.makedirs(os.path.dirname(_FORENSIK_LEDGER_PATH), exist_ok=True)
        with open(_FORENSIK_LEDGER_PATH, "a", encoding="utf-8") as fh:
            fh.write(json.dumps(entry, ensure_ascii=False) + "\n")
            fh.flush()
            os.fsync(fh.fileno())
    except Exception as e:                                   # noqa: BLE001
        print(f"  [FORENSIK] AMARAN: gagal tulis nombor rekod ke cakera "
              f"({type(e).__name__}: {e}) — nombor {no!r} ({jenis}) HANYA "
              f"ada dalam ingatan proses buat masa ini")


class _PersistentRecordLedger(dict):
    """created_records, dengan SATU sisipan pada __setitem__: setiap kali
    satu JENIS diberi nombor SEBENAR (bukan "" / bukan tiada kunci), ia
    ditulis ke ledger forensik atas cakera SERTA-MERTA dan dicetak
    menonjol ke terminal — sebelum test seterusnya sempat berjalan, jauh
    sebelum penghujung sesi.

    Gelagat dalam-ingatan (get/set/in/.get()/dsb — semua 28 fail test
    *-002/-003/-004 yang bergantung padanya) TIDAK berubah walau se-inci:
    ini dict biasa dengan satu baris tambahan. Kunci "" (create jadi,
    nombor tak terbaca) SENGAJA tidak menulis forensik — tiada nombor
    sebenar untuk disimpan, dan menulis "" akan mengelirukan pembaca fail
    forensik kelak menyangka ada nombor.
    """

    def __setitem__(self, jenis, no):
        super().__setitem__(jenis, no)
        if no:
            _tulis_forensik_nombor_rekod(jenis, no)
            print(f"\n  >>> NOMBOR REKOD DICIPTA: {no} <\n")


@pytest.fixture(scope="session")
def created_records():
    """Lejar sesi: NOMBOR rekod yang dicipta oleh setiap aliran *-001.

    PERATURAN KERAS #7 — rekod dibuka IKUT NOMBOR, bukan kedudukan baris.
    Tiga keadaan yang TIDAK PERNAH dicampur:
        kunci TIADA   -> create gagal (assert dalam *-001 sudah raise)
        kunci = ""    -> create berjaya tetapi nombor tak terbaca (bug
                         read_record_number tersendiri)
        kunci = nombor-> baik
    Test hiliran (*-002/-003/-004/-006/-007) pytest.skip bila tiada
    nombor. Tiada fallback "baris pertama/terakhir" di mana-mana.

    2026-07-31: sekarang _PersistentRecordLedger, bukan dict kosong —
    setiap nombor SEBENAR yang ditetapkan di sini ditulis SERTA-MERTA ke
    reports/record_ledger_forensik.jsonl (forensik sahaja, lihat amaran
    di atas kelas ini). created_records kekal SATU-SATUNYA sumber untuk
    keputusan TC; fail forensik tidak pernah dibaca semula automatik.
    """
    return _PersistentRecordLedger()


# ============================================================================
# Kontrak by-number — helper yang dikongsi 28 fail test
# recon/kontrak_by_number.md §5: C-1, C-3, C-4a, C-4b
# ============================================================================

def _require_record(created_records, jenis, tc_asal):
    """Pulangkan nombor rekod jenis ini, atau pytest.skip dengan sebab
    yang MEMBEZAKAN keadaan (a) daripada (c).

    Kontrak C-1 (recon/kontrak_by_number.md §5). Sebelum ini 28 fail test
    menulis `created_records.get(JENIS)` + `if not no:` — `.get()` pulang
    `None` untuk (a) "create GAGAL" dan `""` untuk (c) "create JADI tetapi
    nombor tidak terbaca", dan `if not no` menganggap kedua-duanya sama.
    Mesej skip yang terhasil menggabungkannya, jadi pembaca log tidak
    dapat tahu sama ada perlu membaiki borang create atau membetulkan
    `record_prefix`. Dua puncanya menghala ke dua pembetulan yang berbeza
    sepenuhnya, dan kos tersalah pilih ialah berjam-jam.

    Satu salinan sahaja: 28 fail test tidak boleh masing-masing menulis
    logik ini (kontrak C-1, "Semakan penerimaan: grep created_records.get(
    dalam tests/ -> 0").
    """
    # >>> SKOP DAHULU. 2026-08-06. <<<
    # Kalau TC create itu sendiri LUAR SKOP MBJB (jenis L dan S — keputusan
    # pemilik 2026-08-05), maka rekodnya memang TIDAK AKAN ADA, dan
    # melaporkannya sebagai "show stopper: create GAGAL" ialah sebab yang
    # SALAH: tiada borang create untuk dibaiki, tiada apa yang rosak.
    # Sebab yang salah dalam laporan menghantar orang membaiki benda yang
    # tidak patah — kelas kerosakan yang sama seperti melaporkan medan
    # BELUM_DISAHKAN untuk TC yang PBT ini tidak guna. H-004/H-005 ialah
    # satu-satunya TC hiliran yang terjejas hari ini, tetapi semakan ini
    # diletakkan DI SINI (bukan dalam dua fail test itu) supaya mana-mana
    # TC hiliran jenis luar skop pada masa depan betul secara automatik.
    try:
        from testdata.excel_data import sebab_luar_skop as _luar
        _sebab = _luar(tc_asal)
    except Exception:                                        # noqa: BLE001
        _sebab = None
    if _sebab:
        pytest.skip(f"LUAR SKOP: {_sebab} — TC create {tc_asal} tidak "
                    f"dijalankan, jadi rekod {jenis} memang tiada. Ini "
                    f"BUKAN kegagalan create.")
    if jenis not in created_records:
        pytest.skip(f"show stopper dari {tc_asal}: rekod {jenis} TIDAK "
                    f"DICIPTA dalam run ini (create GAGAL — baiki borang "
                    f"create; ini BUKAN isu awalan nombor)")
    no = created_records[jenis]
    if not no:
        pytest.skip(f"show stopper dari {tc_asal}: rekod {jenis} BERJAYA "
                    f"DICIPTA tetapi NOMBORNYA tidak terbaca — rekod wujud "
                    f"dalam DB, automasi buta terhadapnya. Semak "
                    f"record_prefix dalam profiles/mbpg-staging.json dan "
                    f"baris [AWALAN] dalam log; borang create BERFUNGSI")
    return no


@pytest.fixture()
def require_record():
    """Kontrak C-1. Guna: `no = require_record(created_records, JENIS,
    TC_CREATE)` sebagai baris pertama badan ujian selepas sebab_skip()."""
    return _require_record


def _tokens_baris_untuk_nombor(senarai_page, no_rekod):
    """Token ringkasan baris Senarai BAGI `no_rekod` SAHAJA.

    Pulangkan `(toks, sumber)`:
        toks   -> list[str], atau None bila nombor itu tidak kelihatan
        sumber -> nama kaedah POM yang benar-benar menjawab

    Kontrak C-3 memerlukan pengesahan STATUS HANTAR diikat kepada nombor
    rekod yang run INI cipta, bukan kepada "mana-mana baris jenis itu"
    (`rows_for_jenis()`, senarai_page.py:215-219) — staging penuh rekod
    LAMA yang sudah berstatus 'H', jadi bentuk lama itu LULUS walaupun
    sync run ini gagal sepenuhnya. Itu bug MBIP yang sama.

    KENAPA `sumber` dipulangkan, dan mengapa ia bukan hiasan: kontrak C-2
    membuktikan `get_row_status_tokens(no_rekod)`
    (senarai_page.py:447-459) TIDAK MUNGKIN memadan — ia mencari nombor
    di dalam content-desc baris (`if no_rekod in d`, :457) sedangkan
    nombor rekod hidup dalam elemen BERASINGAN (sel NO AKAUN,
    senarai_page.py:192-213, locator yang saling eksklusif dengan
    ROW_LOCATOR). Jadi `None` dari laluan itu bermakna "KOD KITA belum
    boleh membaca", BUKAN "app tidak memaparkan status". Kaedah gantinya
    `tokens_for_number()` (kontrak §1.1, pemilik makmingg siput) belum
    mendarat semasa fail ini ditulis; tanpa `sumber` dalam mesej
    kegagalan, satu kecacatan kod kita akan dilaporkan sebagai penemuan
    tentang app.
    """
    fn = getattr(senarai_page, "tokens_for_number", None)
    if callable(fn):
        return fn(no_rekod), "tokens_for_number"
    print("  [KONTRAK] AMARAN: pages/senarai_page.tokens_for_number() "
          "belum ada — kontrak C-2 belum mendarat. Jatuh ke "
          "row_status_for_number(), yang C-2 buktikan sentiasa pulang "
          "None. Kalau assert di bawah gagal, puncanya KOD KITA, bukan "
          "app.")
    return (senarai_page.row_status_for_number(no_rekod),
            "row_status_for_number (C-2 BELUM MENDARAT)")


@pytest.fixture()
def senarai_tokens():
    """Kontrak C-3. Guna: `toks, sumber = senarai_tokens(pages.senarai,
    no)`."""
    return _tokens_baris_untuk_nombor


def _snapshot_nombor_jenis(senarai_page, jenis):
    """Snapshot semua nombor rekod jenis ini, ATAS hingga HUJUNG senarai.

    Kontrak C-4b langkah 1-2: TC `-004` menangkap `before` SEBELUM
    kemaskini supaya, kalau kemaskini mengeluarkan nombor rekod BAHARU
    (bukti BERCANGGAH — lihat kontrak C-4b Bukti A vs Bukti B), Laluan B
    boleh mengenal pasti nombor baharu itu melalui delta set, TANPA
    pemilihan ikut kedudukan.

    `senarai_page.numbers_for_jenis()` ialah bahagian POM (pemilik
    makmingg siput) dan BELUM mendarat semasa fail ini ditulis
    (recon/locator_sahkan_device.md belum mendokumenkan tandatangannya).
    Kontrak §1.1 sudah menetapkan tandatangannya, jadi tiada tekaan di
    sini — tetapi memanggilnya secara membuta akan menukar kelima-lima TC
    `-004` menjadi AttributeError. Jadi ketiadaannya DILAPORKAN dan
    Laluan B diisytihar tidak tersedia; Laluan A (jangkaan N/K/L/S)
    tetap diuji sepenuhnya. Tiada assert dilonggarkan di mana-mana.
    """
    fn = getattr(senarai_page, "numbers_for_jenis", None)
    if callable(fn):
        return fn(jenis)
    print("  [KONTRAK] AMARAN: pages/senarai_page.numbers_for_jenis() "
          "belum ada — kontrak C-4b bahagian POM belum mendarat. Snapshot "
          "'before' TIDAK diambil, jadi Laluan B ('nombor rekod bertukar "
          "selepas kemaskini') TIDAK tersedia run ini. Laluan A tetap "
          "diuji; kalau nombor memang bertukar, TC ini akan GAGAL dengan "
          "mesej 'rekod ... TIDAK dijumpai' — itu penemuan sebenar, bukan "
          "sesuatu yang patut ditampung dengan pemilihan ikut kedudukan.")
    return None


@pytest.fixture()
def snapshot_nombor_jenis():
    """Kontrak C-4b. Guna: `before = snapshot_nombor_jenis(pages.senarai,
    JENIS)` selepas ensure_records_listed(), sebelum rekod dibuka."""
    return _snapshot_nombor_jenis


def _verify_kemaskini(pages, jenis, new_value, no_rekod,
                      before_numbers=None, created_records=None):
    """Pulih ke skrin Senarai secara EKSPLISIT, kemudian sahkan kemaskini
    IKUT NOMBOR. Pulangkan nombor rekod yang disahkan dikemaskini.

    Kontrak C-4a, bahagian TEST. `proceed_and_submit()`
    (kemaskini_page.py:289-341) berakhir pada skrin yang TIDAK DIKETAHUI
    — borang kemaskini, popup HANTAR, atau skrin utama — dan
    `verify_updated()` terus memanggil `open_record_by_number()`
    (kemaskini_page.py:384) tanpa memastikan Senarai terbuka. Kalau kita
    bukan di Senarai, carian menyapu 20 kali tanpa melihat apa-apa lalu
    melempar mesej yang MENUDUH PERKARA YANG SALAH ("kemaskini menukar
    nombor rekod / kemaskini merosakkan rekod", :388-394). Kelima-lima TC
    `-004` akan gagal dengan diagnosis yang mengelirukan. Bandingkan
    laluan Cetak yang betul: cetak_page.py:205-209 melakukan ketiga-tiga
    langkah pemulihan.

    Kontrak C-15: alert asli MBJB BERATUR dan Back TIDAK menutupnya
    (disahkan Loh 2026-07-30). Satu alert yang tinggal di atas Senarai
    menelan setiap tap dan menyembunyikan tabel — carian akan melapor
    "rekod tidak dijumpai" dan menuduh create atau awalan. Dikosongkan
    di sini sebelum Senarai dibuka.

    Kontrak C-4b: `before_numbers` / `created_records` dihantar HANYA
    kalau `verify_updated()` benar-benar menerimanya. Bahagian POM milik
    makmingg siput dan belum mendarat; menghantar kata kunci yang belum
    ada akan menjadi TypeError pada kelima-lima TC `-004`. Introspeksi,
    bukan tekaan — dan ketiadaannya dilaporkan, tidak ditelan.
    """
    import inspect

    assert pages.home.go_back_to_home(), \
        "FAIL: tidak dapat kembali ke skrin utama selepas kemaskini"
    pages.home.drain_printer_alert()
    pages.home.dismiss_native_alerts(first_timeout=1,
                                     context="sebelum Senarai (pengesahan "
                                             "kemaskini)")
    pages.home.open_senarai()
    assert pages.senarai.is_senarai_screen_displayed(), \
        "FAIL: skrin Senarai tidak dipaparkan untuk pengesahan kemaskini"
    assert pages.senarai.ensure_records_listed(), \
        "FAIL: tiada baris dalam Senarai untuk pengesahan kemaskini"

    kw = {}
    try:
        params = inspect.signature(pages.kemaskini.verify_updated).parameters
    except (TypeError, ValueError):                          # noqa: BLE001
        params = {}
    if "before_numbers" in params:
        kw["before_numbers"] = before_numbers
    if "created_records" in params:
        kw["created_records"] = created_records
    if before_numbers is not None and "before_numbers" not in params:
        print("  [KONTRAK] AMARAN: verify_updated() belum menerima "
              "before_numbers (kontrak C-4b bahagian POM belum mendarat) "
              "— snapshot yang sudah diambil TIDAK diguna. Laluan B tidak "
              "aktif run ini.")
    return pages.kemaskini.verify_updated(pages.senarai, jenis, new_value,
                                          no_rekod=no_rekod, **kw)


@pytest.fixture()
def verify_kemaskini():
    """Kontrak C-4a + C-4b. Guna: `verify_kemaskini(pages, JENIS,
    nilai_baharu, no, before, created_records)`."""
    return _verify_kemaskini


@pytest.fixture()
def artifacts():
    """Fixture untuk test merekod nombor yang dicipta."""
    return record_artifact


# Berapa kali overlay ralat skrin-merah React Native muncul dan terpaksa
# dikosongkan run ini. Dilapor pada akhir: ini isyarat build/persekitaran
# (APK debug menghala ke Metro dev server yang mati), bukan bug ujian.
_RN_REDSCREEN_COUNT = [0]

# Penanda overlay ralat RN ("Could not connect to development server" /
# "Unable to load script"). Ia modal skrin penuh yang menelan setiap
# elemen di belakangnya, jadi satu kemunculan akan menukar setiap TC
# hiliran menjadi ERROR.
_RN_RED_MARKERS = [
    ('new UiSelector().textContains("development server")'),
    ('new UiSelector().textContains("Unable to load script")'),
    ('new UiSelector().textContains("Could not connect")'),
]


def _handle_rn_redscreen(pages):
    """Kesan + kosongkan skrin-merah debug React Native. Tekan DISMISS;
    kalau tidak hilang, relaunch app. Pulangkan True kalau satu
    dikendalikan."""
    import time
    from appium.webdriver.common.appiumby import AppiumBy

    def _present():
        for ui in _RN_RED_MARKERS:
            if pages.home.is_element_present(
                    (AppiumBy.ANDROID_UIAUTOMATOR, ui), timeout=1):
                return True
        return False

    if not _present():
        return False
    _RN_REDSCREEN_COUNT[0] += 1
    print(f"  [RN-REDSCREEN] Overlay ralat React Native dikesan "
          f"(#{_RN_REDSCREEN_COUNT[0]}) — menekan DISMISS")
    for loc in ((AppiumBy.ANDROID_UIAUTOMATOR,
                 'new UiSelector().textMatches("(?i)dismiss")'),
                (AppiumBy.ACCESSIBILITY_ID, "Dismiss")):
        if pages.home.is_element_present(loc, timeout=1):
            try:
                pages.home.tap_element(pages.home.find_element(loc, timeout=2))
                time.sleep(1)
                break
            except Exception:                                # noqa: BLE001
                pass
    if _present():
        print("  [RN-REDSCREEN] Masih ada selepas DISMISS — relaunch app")
        try:
            pages.login._force_relaunch_to_login()
            pages.login.login(TEST_CREDENTIALS["username"],
                              TEST_CREDENTIALS["password"])
        except Exception as e:                               # noqa: BLE001
            print(f"  [RN-REDSCREEN] relaunch/login gagal ({e})")
    return True


def _recover_to_home(pages):
    """Pemulihan skrin utama yang dikeraskan. Disahkan pada run v3 MBIP:
    gelung tekan-Back membuta tidak boleh menutup popup "KEMASKINI DATA"
    rekod Senarai — modal RN itu menelan kekunci Back peranti, jadi satu
    popup tersekat menukar setiap test hiliran menjadi ERROR.

    Tangga setiap pusingan: kosongkan alert asli -> sudah di home? ->
    tutup sebarang popup melalui ikon X dengan tap MENTAH (pressable RN
    app ini senyap no-op pada el.click(); close popup ialah content-desc
    U+2715) -> kalau tersasar ke skrin login, log masuk semula -> Back
    peranti. Pilihan terakhir: relaunch sejuk + login (data app kekal,
    tiada apa hilang).

    ANDAIAN SATU-SKRIN DIBETULKAN 2026-07-31 (recon/PAPAN.md, blok "MULA
    DI SINI"): `uiautomator dump` MEMBUANG setiap node `visible:false` —
    "ikon X tidak dijumpai" bukan bukti ia tiada, ia mungkin sekadar di
    bawah paparan semasa. Pemulihan ini dipanggil PALING KERAP tepat
    selepas kegagalan pada borang panjang (Kemaskini / HantarSemula /
    Notis-ke-Kompaun — sama tiga borang yang reveal_below_fold() dibina
    untuknya, base_page.py), yang memanjang y~4100 berbanding viewport
    y~1596 (>2.5 skrin). Bentuk lama hanya `is_element_present(loc,
    timeout=1)` pada kedudukan skrol SEMASA sahaja — kalau ikon X berada
    di luar paparan itu (borang tergulung ke bawah semasa kegagalan
    test), semakan silap lapor "tiada X" dan terus ke press_back(),
    walhal ikon itu memang wujud beberapa skrol ke atas. Sebelum
    mengalah pada satu locator, cuba dedahkan ia dahulu melalui
    reveal_below_fold() (helper base_page sedia ada — TIDAK disalin
    logik skrol/TAB baharu di sini) supaya "tidak dijumpai" bermaksud
    "sudah dicari merentas keseluruhan borang", bukan "tidak kelihatan
    pada satu tetingkap skrin".
    """
    import time
    from appium.webdriver.common.appiumby import AppiumBy

    x_locators = [
        (AppiumBy.ACCESSIBILITY_ID, "✕"),
        (AppiumBy.ACCESSIBILITY_ID, "X"),
    ]
    for _ in range(8):
        # Kosongkan skrin-merah RN dan alert sambungan printer dahulu —
        # kedua-duanya akan duduk di atas skrin utama dan mengalahkan
        # setiap langkah pemulihan di bawah. drain_printer_alert dikira
        # secara global.
        _handle_rn_redscreen(pages)
        pages.home.drain_printer_alert()
        pages.home.dismiss_native_alerts(first_timeout=1,
                                         context="pemulihan home")
        if pages.home.is_element_present(pages.home.HOME_SCREEN_INDICATOR,
                                         timeout=2):
            print("  [RECOVERY] Skrin utama dicapai")
            return True
        closed = False
        for loc in x_locators:
            found = pages.home.is_element_present(loc, timeout=1)
            if not found:
                # Laluan cepat gagal -- jangan simpulkan "tiada" dari satu
                # tetingkap skrin sahaja (lihat nota andaian satu-skrin di
                # atas). max_tabs rendah: ini pemulihan, bukan borang yang
                # kita sengaja mengisi, jadi kos traversal mesti kecil.
                found = pages.home.reveal_below_fold(loc, max_tabs=3)
            if found:
                try:
                    el = pages.home.find_element(loc, timeout=2)
                    pages.home.tap_element(el)
                    print("  [RECOVERY] Popup ditutup melalui ikon X")
                    closed = True
                    time.sleep(1)
                    break
                except Exception:
                    pass
        if closed:
            continue
        # Tersasar sampai ke skrin login? (Grid home sudah disahkan
        # tiada di atas.)
        if pages.login.is_element_present(pages.login.APP_TITLE, timeout=1):
            print("  [RECOVERY] Berada pada skrin login — log masuk semula")
            pages.login.login(TEST_CREDENTIALS["username"],
                              TEST_CREDENTIALS["password"])
            return pages.home.is_element_present(
                pages.home.HOME_SCREEN_INDICATOR, timeout=10)
        pages.home.press_back()
        time.sleep(1)

    print("  [RECOVERY] Masih bukan home — relaunch sejuk + login baharu")
    pages.login._force_relaunch_to_login()
    pages.login.login(TEST_CREDENTIALS["username"],
                      TEST_CREDENTIALS["password"])
    return pages.home.is_element_present(pages.home.HOME_SCREEN_INDICATOR,
                                         timeout=10)


@pytest.fixture()
def home_reset(logged_in, pages):
    """Pengasingan kegagalan: pulih ke skrin utama tanpa mengira di mana
    test sebelumnya berakhir (tengah borang, popup/alert tertinggal,
    ...), supaya satu TC yang gagal tidak boleh meracuni titik mula TC
    seterusnya."""
    assert _recover_to_home(pages), \
        "FAIL: Tidak dapat pulih ke skrin utama"
    return True


# ============================================================================
# Susunan collection — susunan List-to-Test Excel
# ============================================================================

# MBJB: regex ini MESTI sepadan dengan nama fail test. Kalau ia tidak
# sepadan, _tc_id_for_item() pulangkan None untuk SEMUA fail -> susunan
# collection rawak, jadual ringkasan kosong, DAN results.json kosong.
# Kegagalan senyap — sebab itu ia diuji oleh test_mbpg_tc_* itu sendiri
# melalui jadual ringkasan.
_TC_FILE_RE = re.compile(r"test_mbpg_tc_([a-z]+)_(\d+)_")

# Diisi semasa collection; diguna oleh jadual ringkasan.
_COLLECTED = []  # senarai (tc_id, nodeid)

# Masa mula jam dinding, hanya untuk medan duration dashboard.
_SESSION_START = [None]


# ---------------------------------------------------------------------------
# CAP MASA SEJAGAT PADA SETIAP BARIS LOG — dipasang 2026-08-06
# ---------------------------------------------------------------------------
# Analisis rakaman skrin pemilik (552 frame, 9m12s) mengukur 79% masa run
# sebagai skrin BEKU, dengan tiga beku 121s/133s/183s. Satu TC mengambil
# 17-18 minit; pada kadar itu 39 TC ialah lebih 11 jam.
#
# Percubaan pertama menyasarkan beku itu pada `fill_field_by_label()` dan
# memasang amaran `[TIMING] BEKU` di situ. Run berikutnya membuktikan
# TEKAAN ITU SALAH: sifar amaran dicetak, jadi carian medan BUKAN puncanya.
# Itulah sebab pengukuran ini dibuat SEJAGAT dan bukan setempat — meletakkan
# pengukur di tempat yang kita SANGKA mahal hanya mengesahkan sangkaan kita
# sendiri.
#
# Bentuknya paling murah yang mungkin: setiap baris log dicap dengan masa
# berlalu sejak run bermula DAN jurang dari baris sebelumnya. Beku menjadi
# KELIHATAN sebagai satu nombor besar dalam lajur kedua, tanpa perlu tahu
# lebih awal di mana ia berada.
#
#   [   12.3s +0.4] [NOTIS AMARAN] Filling Pesalah tab...
#   [  145.7s +133.4] [DROPDOWN] tingkat 1 ...        <-- beku bernama sendiri
#
# Matikan dengan MBPG_TIADA_CAP_MASA=1 kalau ia menyusahkan pembacaan log.
class _StdoutBercap:
    """Balut stdout dan cap setiap baris dengan masa berlalu + jurang.

    Menulis ke strim ASAL tanpa mengubah bait kandungan (konsol Windows
    sudah mencacatkan UTF-8; pembalut ini TIDAK boleh memburukkannya).
    Tiada apa dalam suite bergantung pada bentuk baris log, jadi ini
    selamat — tetapi kalau satu-satunya perkara yang boleh dipercayai
    dalam log ialah bentuknya, matikan dengan env di atas."""

    def __init__(self, asal, mula):
        self._asal = asal
        self._mula = mula
        self._akhir = [mula]
        self._awal_baris = True

    def write(self, s):
        try:
            if not s:
                return 0
            keluar = []
            for bahagian in s.splitlines(True):
                if self._awal_baris and bahagian.strip():
                    kini = _time.time()
                    jurang = kini - self._akhir[0]
                    self._akhir[0] = kini
                    keluar.append(f"[{kini - self._mula:7.1f}s "
                                  f"+{jurang:.1f}] ")
                keluar.append(bahagian)
                self._awal_baris = bahagian.endswith(("\n", "\r"))
            return self._asal.write("".join(keluar))
        except Exception:                                # noqa: BLE001
            # Pengukuran TIDAK boleh memecahkan run. Kalau apa-apa gagal,
            # tulis mentah.
            try:
                return self._asal.write(s)
            except Exception:                            # noqa: BLE001
                return 0

    def __getattr__(self, nama):
        return getattr(self._asal, nama)


def pytest_sessionstart(session):
    del session
    _SESSION_START[0] = _time.time()
    if os.environ.get("MBPG_TIADA_CAP_MASA") != "1":
        try:
            sys.stdout = _StdoutBercap(sys.stdout, _SESSION_START[0])
            print("  [TIMING] cap masa setiap baris HIDUP "
                  "([jumlah +jurang]); matikan dengan "
                  "MBPG_TIADA_CAP_MASA=1")
        except Exception as e:                           # noqa: BLE001
            print(f"  [TIMING] cap masa tidak dapat dipasang "
                  f"({type(e).__name__}) — run diteruskan tanpa ia")
    # id run untuk ledger forensik (_tulis_forensik_nombor_rekod di atas)
    # — satu id stabil per proses pytest supaya baris forensik daripada
    # run yang berlainan boleh dikumpulkan/dibezakan oleh manusia yang
    # membaca fail itu kelak, walaupun proses dibunuh separuh jalan.
    import datetime
    _RUN_ID[0] = datetime.datetime.now().strftime("run-%Y%m%dT%H%M%S")


def _short_reason(rep):
    """Satu baris sebab kegagalan/skip dari laporan pytest.

    Untuk skip, pytest menyimpan (fail, baris, mesej) -- mesej itulah yang
    berguna. Untuk gagal/ralat, baris ringkasan pengecualian (baris "E ...")
    membawa maklumat sebenar; keseluruhan traceback terlalu panjang untuk
    sel jadual, jadi diambil baris terakhir yang bermakna.
    """
    try:
        if getattr(rep, "outcome", "") == "skipped":
            lr = getattr(rep, "longrepr", None)
            if isinstance(lr, tuple) and len(lr) == 3:
                return str(lr[2]).replace("Skipped: ", "").strip()[:300]
        text = getattr(rep, "longreprtext", "") or str(
            getattr(rep, "longrepr", "") or "")
        if not text:
            return ""
        elines = [l[2:].strip() for l in text.splitlines()
                  if l.startswith("E ") and l[2:].strip()]
        if elines:
            # Baris E terakhir ialah pengecualian sebenar; yang sebelumnya
            # selalunya konteks assert.
            return elines[-1][:300]
        last = [l.strip() for l in text.splitlines() if l.strip()]
        return last[-1][:300] if last else ""
    except Exception:                                    # noqa: BLE001
        return ""


def _tc_id_for_item(item):
    m = _TC_FILE_RE.search(os.path.basename(str(item.fspath)))
    if not m:
        return None
    series, num = m.group(1).upper(), int(m.group(2))
    return f"MBPG-TC-{series}-{num:03d}"


def pytest_runtest_setup(item):
    """Jejak TC yang SEDANG berjalan, untuk ledger forensik
    (_tulis_forensik_nombor_rekod / _PersistentRecordLedger di atas) —
    supaya setiap baris nombor rekod yang ditulis ke cakera boleh dikait
    ke nama TC yang mencipta/membacanya, bukan sekadar JENIS + nombor.
    Guna semula _tc_id_for_item() yang sama dengan jadual ringkasan —
    satu sumber sahaja, tiada regex kedua yang boleh terpesong daripadanya.
    """
    _CURRENT_TC_ID[0] = _tc_id_for_item(item)


def pytest_collection_modifyitems(config, items):
    del config
    items.sort(key=lambda it: TC_ORDER.get(_tc_id_for_item(it) or "", 999))
    _COLLECTED.clear()
    for it in items:
        tc = _tc_id_for_item(it)
        if tc:
            _COLLECTED.append((tc, it.nodeid))
    # Amaran awal kalau bilangan tidak sepadan dengan Excel: 54 TC.
    if len(_COLLECTED) != len(TC_LIST):
        print(f"\n  [COLLECT] AMARAN: {len(_COLLECTED)} TC di-collect, "
              f"Excel V2.1.20 menyenaraikan {len(TC_LIST)}. Fail test "
              f"hilang atau namanya tidak sepadan dengan corak "
              f"test_mbpg_tc_<siri>_<nnn>_*.py\n")


# ============================================================================
# Jadual ringkasan List-to-Test
# ============================================================================

def pytest_terminal_summary(terminalreporter, exitstatus, config):
    del exitstatus
    stats = terminalreporter.stats
    outcome_by_nodeid = {}
    # Sebab kegagalan sebenar, bukan sekadar status.
    #
    # Tanpa ini dashboard hanya tahu "FAILED" dan terpaksa bergantung pada
    # nota yang ditulis tangan -- yang akan terus memaparkan sebab LAMA
    # walaupun TC itu kini gagal atas sebab yang berbeza sama sekali.
    reason_by_nodeid = {}
    # Keutamaan: ERROR > FAILED > SKIPPED > PASSED (ralat setup tidak
    # boleh ditutup oleh apa-apa yang lain).
    for key, label in (("passed", "PASSED"), ("skipped", "SKIPPED"),
                       ("failed", "FAILED"), ("error", "ERROR")):
        for rep in stats.get(key, []):
            nodeid = getattr(rep, "nodeid", None)
            if not nodeid:
                continue
            outcome_by_nodeid[nodeid] = label
            if label != "PASSED":
                r = _short_reason(rep)
                if r:
                    reason_by_nodeid[nodeid] = r

    if not _COLLECTED:
        return

    tr = terminalreporter
    tr.write_sep("=", "RINGKASAN LIST-TO-TEST MBJB (Excel V2.1.33)")
    name_width = max(len(TC_NAMES.get(tc, "?")) for tc, _ in _COLLECTED)
    ordered = sorted(_COLLECTED, key=lambda x: TC_ORDER.get(x[0], 999))
    counts = {}
    for tc_id, nodeid in ordered:
        outcome = outcome_by_nodeid.get(nodeid, "NOT RUN")
        counts[outcome] = counts.get(outcome, 0) + 1
        name = TC_NAMES.get(tc_id, "?")
        tr.write_line(f"  {tc_id:<15} | {name:<{name_width}} | {outcome}")
    total = " | ".join(f"{k}: {v}" for k, v in sorted(counts.items()))
    tr.write_line("  " + "-" * (15 + name_width + 16))
    tr.write_line(f"  {len(ordered)} test case — {total}")

    # Kiraan bunyi persekitaran (bukan keputusan ujian): kiraan alert
    # printer yang tinggi bermakna "jaga printer supaya tidak tidur", dan
    # sebarang skrin-merah RN bermakna build debug kehilangan Metro dev
    # servernya.
    # Baris "alert pencetak" DIBUANG — pencetak di luar skop MBPG dan
    # penyalirnya dilumpuhkan (pages/base_page.drain_printer_alert).
    # Digantikan dengan kiraan corong dry-run, yang JAUH lebih penting
    # untuk run ini: berapa banyak tap dinilai, dan berapa disekat.
    printer_alerts = 0
    try:
        _c = getattr(_DRIVER_AKTIF[0], "corong", None) if _DRIVER_AKTIF else None
    except Exception:                                        # noqa: BLE001
        _c = None
    if _c is not None:
        tr.write_line(f"  Corong dry-run: {_c.bil_tap} tap dinilai, "
                      f"{_c.bil_sekat} DISEKAT"
                      + (f"  |  RUN DIBATALKAN: {_c.dibatalkan}"
                         if _c.dibatalkan else "")
                      + f"  |  Skrin-merah RN dikendali: "
                        f"{_RN_REDSCREEN_COUNT[0]}")
    else:
        tr.write_line(f"  Corong dry-run: tiada sesi (tiada tap dibuat)  "
                      f"|  Skrin-merah RN dikendali: {_RN_REDSCREEN_COUNT[0]}")

    # ---- Hook auto-dashboard: buang data per-TC yang sama ke JSON
    # supaya reports/generate_report.py boleh menyegarkan laporan tanpa
    # sebarang salin/tampal manual. Tambahan semata-mata dan dikawal
    # sepenuhnya -- kegagalan di sini tidak boleh menjejaskan keputusan
    # run. ----
    try:
        import json
        import datetime

        results = {tc_id: outcome_by_nodeid.get(nodeid, "NOT RUN")
                   for tc_id, nodeid in ordered}
        # JANGAN tulis results.json bila tiada test benar-benar berjalan.
        #
        # Sebelum pengawal ini: `pytest --collect-only` (dan mana-mana run
        # yang gagal pada peringkat preflight) menulis results.json penuh
        # 54 "NOT RUN" ke atas results.json run SEBENAR yang terdahulu.
        # generate_report.py kemudian mengarkibkannya ke reports/history/
        # sebagai satu run — sejarah tercemar oleh run yang tidak pernah
        # menyentuh peranti. Ini kes 'PASS palsu' pada lapisan laporan.
        #
        # Run separa (-k / deselect) MASIH ditulis dengan sengaja: TC yang
        # tidak dipilih dilapor "NOT RUN", iaitu keadaan sebenar run itu.
        if getattr(getattr(config, "option", None), "collectonly", False):
            tr.write_line("  [dashboard] --collect-only: results.json TIDAK "
                          "ditulis (tiada test dijalankan)")
            return
        if not any(v != "NOT RUN" for v in results.values()):
            tr.write_line("  [dashboard] tiada satu pun TC berjalan: "
                          "results.json TIDAK ditulis (results.json "
                          "terdahulu dikekalkan)")
            return
        reasons = {tc_id: reason_by_nodeid[nodeid]
                   for tc_id, nodeid in ordered if nodeid in reason_by_nodeid}
        summary = {}
        for outcome in results.values():
            summary[outcome] = summary.get(outcome, 0) + 1
        payload = {
            "generated_at": datetime.datetime.now().isoformat(
                timespec="seconds"),
            "duration_seconds": (round(_time.time() - _SESSION_START[0], 2)
                                 if _SESSION_START[0] else None),
            "total": len(results),
            "summary": summary,
            "results": results,
            # Siapa/apa yang menghasilkan run ini. Jatuh balik kepada
            # nilai config bila driver tidak pernah start (cth kegagalan
            # peringkat preflight), supaya medan ini sentiasa ada.
            "tester": _RUN_META.get("tester", TESTER_NAME),
            "device_udid": _RUN_META.get("device_udid"),
            "device_model": _RUN_META.get("device_model"),
            "app_version": _RUN_META.get("app_version"),
            # Sebab kegagalan sebenar per TC, dan nombor rekod yang
            # dicipta -- kedua-duanya untuk menjejak balik ke pangkalan
            # data apabila sesuatu gagal.
            "reasons": reasons,
            "artifacts": _ARTIFACTS,
            "printer_alerts": printer_alerts,
            "rn_redscreens": _RN_REDSCREEN_COUNT[0],
            # PBT/persekitaran yang diuji. Wajib ada walaupun driver tak
            # sempat start, supaya laporan tidak boleh tersalah kaitkan
            # keputusan ini dengan PBT lain.
            "profile": _RUN_META.get("profile", PROFILE_NAME),
            "profile_label": _RUN_META.get("profile_label", PROFILE_LABEL),
            "pbt": _RUN_META.get("pbt", PBT),
            "env": _RUN_META.get("env", ENV),
            "record_prefix": _RUN_META.get("record_prefix", RECORD_PREFIX),
        }
        out = os.path.abspath(os.path.join(
            os.path.dirname(__file__), "..", "reports", "results.json"))
        os.makedirs(os.path.dirname(out), exist_ok=True)
        with open(out, "w", encoding="utf-8") as fh:
            json.dump(payload, fh, indent=2, ensure_ascii=False)
        tr.write_line(f"  [dashboard] results.json ditulis -> {out}")
    except Exception as e:  # noqa: BLE001 - jangan sekali-kali rosakkan run
        tr.write_line(f"  [dashboard] AMARAN: results.json tidak ditulis "
                      f"({type(e).__name__}: {e})")

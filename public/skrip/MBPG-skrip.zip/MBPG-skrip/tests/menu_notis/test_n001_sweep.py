"""SWEEP N — Daftar Notis Amaran, tiga dropdown sahaja.

Skop lalai ialah SAMPEL 26 set, bukan kesemuanya. Seksyen Kompaun pada
borang ini dipercayai IDENTIK dengan Kompaun Pelbagai; sampel ini menguji
dakwaan itu. Kalau mana-mana daripada 26 berbeza daripada hasil P yang
sepadan, dakwaan itu mati dan `--n-penuh` membuka kesemua 256.

    pytest tests/menu_notis --kk 01
    pytest tests/menu_notis --kk 01 --n-penuh

MENCAPAI TAB NOTIS — TIGA PERINGKAT (diluluskan pemilik 2026-08-07)
------------------------------------------------------------------
Tiga dropdown kod kompaun TIDAK berada pada skrin pertama borang N. Ia
hidup pada tab NOTIS, dicapai dari tab PESALAH melalui SETERUSNYA. Kalau
SETERUSNYA mengesahkan medan wajib, sweep tidak boleh sampai tanpa
mengisi sesuatu.

Pemilik meluluskan isi-minimum. Kami menaik peringkat, bukan terus
mengisi:

  Peringkat 0  SETERUSNYA terus, borang kosong.
  Peringkat 1  isi nama + no KP (oracle N-001), cuba lagi.
  Peringkat 2  tambah alamat pesalah penuh (oracle N-001), cuba lagi.

Naik peringkat hanya bila peringkat sebelumnya DITOLAK. Kalau borang
membenarkan tab kosong, kami tidak menaip apa-apa langsung — itu
sentuhan paling sedikit pada production, dan ia juga mengukur apa yang
borang sebenarnya tuntut, yang merupakan dapatan tersendiri.

Laluan yang dipakai DIREKOD dalam MATRIX (lajur `catatan`) supaya
pembaca tahu sama ada baris N datang dari borang kosong atau borang
yang diisi separa. Nilai datang dari oracle sahaja — lihat
testdata/pesalah_minimum.py.

Borang tetap TIDAK diserah dan tiada rekod dicipta.
"""

import pytest

from testdata import pesalah_minimum
from tests.sweep_kongsi import (jalankan_sweep, matrix,   # noqa: F401
                                parametrize_sets)

# Keadaan sesi: hasil probe sekali sahaja untuk keseluruhan run.
_TAB_NOTIS = {"cuba": False, "ok": False, "sebab": "", "laluan": ""}


def pytest_generate_tests(metafunc):
    parametrize_sets(metafunc, "N")


def _tab_notis_terpapar(p):
    return p.is_element_present(p.LABEL_TIER1, timeout=6)


def _cuba_seterusnya(p):
    """(ok, sebab) — cuba SETERUSNYA dan sahkan tab Notis benar-benar
    terpapar. 'Tidak melempar' BUKAN bukti ia berjaya: borang RN boleh
    menelan ketukan tanpa ralat, jadi kami menuntut LABEL_TIER1."""
    try:
        p.click_seterusnya_from_pesalah()
    except Exception as e:                                    # noqa: BLE001
        return False, f"{type(e).__name__}: {e}"
    if _tab_notis_terpapar(p):
        return True, ""
    return False, ("SETERUSNYA tidak melempar tetapi tab Notis tidak "
                   "terpapar (LABEL_TIER1 tidak dijumpai)")


def _capai_tab_notis(pages):
    """(ok, sebab, laluan). Naik peringkat hanya bila perlu."""
    p = pages.notis_amaran
    pages.home.open_notis_amaran()
    if not p.is_notis_amaran_screen_displayed():
        return False, "borang Notis Amaran tidak terpapar selepas dibuka", ""

    ok, sebab = _cuba_seterusnya(p)
    if ok:
        return True, "", "terus-tanpa-isi"

    for n in (1, 2):
        medan = pesalah_minimum.peringkat(n)
        print(f"  [SWEEP N] SETERUSNYA ditolak ({sebab}) — mengisi "
              f"Pesalah minimum peringkat {n}: {sorted(medan)}")
        try:
            p.fill_pesalah_tab(medan)
        except Exception as e:                                # noqa: BLE001
            return (False,
                    f"isi Pesalah peringkat {n} gagal "
                    f"({type(e).__name__}: {e})",
                    f"isi-minimum-p{n}-gagal")
        ok, sebab = _cuba_seterusnya(p)
        if ok:
            return True, "", f"isi-minimum-p{n}"

    return (False,
            f"tab Notis tidak tercapai walaupun selepas mengisi Pesalah "
            f"penuh dari oracle N-001 — {sebab}",
            "isi-minimum-p2-gagal")


def test_sweep_kombo_notis(logged_in, pages, set_kombo, matrix):
    st = _TAB_NOTIS
    if not st["cuba"]:
        st["cuba"] = True
        st["ok"], st["sebab"], st["laluan"] = _capai_tab_notis(pages)
        if st["ok"]:
            print(f"\n  [SWEEP N] tab Notis dicapai melalui: {st['laluan']}")
        else:
            print(f"\n  [SWEEP N] HALANGAN: {st['sebab']}")
    if not st["ok"]:
        pytest.skip(f"tab Notis tidak tercapai — {st['sebab']}")
    jalankan_sweep(pages.notis_amaran, set_kombo, "N", matrix,
                   nota_awal=st["laluan"])

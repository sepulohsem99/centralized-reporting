"""SWEEP K — Daftar Kompaun Letak Kereta, tiga dropdown sahaja.

Nota yang perlu dibaca sebelum mentafsir MATRIX: kesemua 74 set K berada
di bawah akta id=2 'AKTA 171 - AKTA KERAJAAN TEMPATAN 1976', dan nama itu
BERULANG dalam mapping (id 2 dan ACT2025000005). Maka 29 daripada 74
ditanda AMBIGU — kami tidak boleh tahu dari mapping sahaja akta yang mana
menyumbang senarai kesalahan. Apa yang app papar ialah jawapannya.

    pytest tests/menu_letak_kereta --kk 03
"""

from tests.sweep_kongsi import (jalankan_sweep, matrix,   # noqa: F401
                                parametrize_sets, sedia_borang_kompaun)


def pytest_generate_tests(metafunc):
    parametrize_sets(metafunc, "K")


def test_sweep_kombo_letak_kereta(logged_in, pages, set_kombo, matrix):
    sedia_borang_kompaun(pages, "Kompaun Letak Kereta")
    jalankan_sweep(pages.daftar_kompaun, set_kombo, "K", matrix)

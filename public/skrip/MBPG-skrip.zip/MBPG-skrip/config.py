"""
Tetapan Appium untuk suite ujian KOMPAUN e-PBT (app IES) — MBJB.

SUMBER KEBENARAN
----------------
Oracle data ujian ialah  MBPG_V2.1.33_PRODUCTION.xlsx  (57 sheet, 54 TC,
awalan MBPG-TC-*). Fail ini TIDAK mengandungi data ujian; ia hanya tetapan
sambungan. Data ujian ada dalam testdata/.

AMARAN WORKBOOK TERCEMAR: "IES-MBJB Testing Script V2.1.35_2_(PRODUCTION)
.xlsx" dan "...V2.1.36_PRODUCTION.xlsx" bernama MBJB tetapi kandungan
sheetnya MBPG-TC-*. Ia BUKAN MBJB. Jangan jana apa-apa daripadanya.

MUDAH ALIH (PORTABILITY)
------------------------
Suite ini diedar sebagai zip kepada satu pasukan; setiap ahli menjalankannya
atas peranti Android sendiri, dan tiada siapa mengedit fail .py. Jadi tiada
apa di sini boleh terikat kepada satu mesin tertentu:

  - Serial peranti TIDAK dihardcode. Ia dileraikan pada waktu run oleh
    device_utils.resolve_udid() -- lihat modul itu untuk peraturannya.
    Tindih dengan pembolehubah persekitaran MBPG_UDID kalau auto-detect
    tidak dapat memutuskan. Ia tidak dapat memutuskan bila LEBIH DARIPADA
    SATU peranti yang tersambung membawa pakej yang sama; dalam keadaan itu
    ia BERHENTI dan meminta MBPG_UDID, kerana memilih sendiri bermakna
    separuh rekod tercipta atas peranti yang salah tanpa sesiapa perasan.
  - Identiti penguji datang dari nama pengguna Windows (tindih dengan
    MBPG_TESTER), supaya sejarah run boleh diatribut tanpa setup.
  - Laluan APK TIDAK dihardcode. Lihat APK_NAME/APK_PATH di bawah.

TETAPAN PER-ENVIRONMENT
-----------------------
Alamat server, lesen aplikasi, akaun login dan awalan nombor rekod TIDAK
berada dalam fail ini. Ia datang dari profil aktif dalam profiles/ (lihat
profile.py). Tukar environment = tukar satu pembolehubah persekitaran.

LESEN ADALAH TOKEN SERVER, BUKAN IMEI
-------------------------------------
`lesen_aplikasi` ialah TOKEN yang didaftarkan di portal PBT, dan ia disahkan
di SERVER -- bukan terhadap IMEI peranti tempatan. Maka satu nilai lesen
boleh melayani semua peranti pasukan, sama seperti suite MBIP.

Fail ini dahulunya mendakwa sebaliknya ("nilai lesen_aplikasi ialah IMEI
peranti itu sendiri"). Dakwaan itu SALAH dan pemilik sudah menariknya balik
pada 2026-07-29. Buktinya, pada device fizikal yang SAMA seperti yang kita
pandu: lesen 352405067769401 berjaya berpuluh run MBIP pada Ulefone Armor 27
(mbip-testing\\v3\\profiles\\mbip-staging.json baris 14;
mbip-testing\\v3\\HANDOFF-2026-07-29.md baris 12 dan 36), sedangkan IMEI
Armor 27 ialah 357616400186856 / 357616400186864. Lesen yang berjaya itu
bukan IMEI device itu.

Ikutannya:
  - Ketidakpadanan lesen vs IMEI adalah NORMAL. Ia BUKAN perkara pertama
    yang perlu disemak bila login gagal, dan tiada kod di sini melaporkannya
    sebagai amaran. Bukti penuh + urutan cuba token: baca komen
    `_comment_lesen_*` dalam profiles/mbpg-staging.json, dan keputusan
    muktamad dalam recon\\PAPAN.md Seksyen 1.1-1.2.
  - `m50` / `m51` ialah label device di pejabat pemilik, bukan syarat
    padanan. Device yang kita pandu bukan m50 dan bukan m51.
  - Bila lesen ditolak server, itu isu PENDAFTARAN PORTAL. IMEI diperlukan
    untuk memberitahu admin peranti mana perlu didaftarkan, jadi ia dibaca
    dan dilaporkan sebagai MAKLUMAT oleh:
        python device_utils.py --check
        python device_utils.py --imei
"""

import os
import sys

# Root projek diletak di hadapan sys.path SEBELUM `import profile`.
# Pustaka standard Python juga ada modul bernama `profile` (profiler); tanpa
# baris ini, kandungan sys.path yang berbeza (contoh: dijalankan dari folder
# lain, atau di bawah runner yang menyusun semula path) boleh memuatkan
# profiler itu dan gagal dengan KeyError yang mengelirukan, bukan dengan
# ProfileError yang menerangkan apa perlu dibuat.
HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

import profile as _profile            # noqa: E402  (selepas pembetulan path)
import device_utils as _device_utils  # noqa: E402  (stdlib sahaja di aras modul)

# Profil aktif — pilih dengan MBPG_PROFILE, atau melalui menu dalam
# tests\run_and_report.bat. Gagal serta-merta (dengan mesej jelas) kalau
# taksa, belum lengkap, atau menyasarkan production tanpa izin.
PROFILE = _profile.load()
PROFILE_NAME = PROFILE["_name"]
PROFILE_LABEL = _profile.label(PROFILE)
PBT = PROFILE["pbt"]
ENV = PROFILE["env"]

# Tetapan app — datang dari profil.
APP_PACKAGE = PROFILE["app_package"]
APP_ACTIVITY = PROFILE.get("app_activity", ".MainActivity")

# Build APK yang dijangka. Hanya NAMA disimpan, bukan laluan penuh: laluan
# pada mesin pemilik ialah
#   C:\Users\mrsai\Desktop\MBJB MATERIALS AUTOMATION TESTING\
# iaitu nilai khusus mesin, dan menghardcodenya akan memecahkan suite untuk
# setiap ahli pasukan lain. APK dipasang secara manual sebelum run; suite
# tidak memasangnya. Set MBPG_APK kalau ada alat yang perlukan laluan penuh.
#
# >>> DIKEMASKINI 2026-10-01 — KEPUTUSAN PEMILIK (mrsai, MCQ) <<<
# Sejarah: nilai asal "2.1.20" (ditetapkan 2026-08-07, dari oracle
# "IES-MBPG Testing Script V2.1.20_PRODUCTION.xlsx") DIBIARKAN SENGAJA
# tidak diselaraskan walaupun peranti sudah melangkaui 2.1.20 -> 2.1.21
# -> 2.1.23, kerana percanggahan oracle-vs-peranti itu sendiri perlu
# keputusan pemilik, bukan diselaraskan senyap oleh skrip/agen.
#
# 2026-10-01: pemilik mengesahkan APK BAHARU 2.1.25 kini dipasang pada
# peranti ujian dan diarah test regresi penuh (NPK) terhadap build ini.
# Nilai di bawah dikemaskini kepada 2.1.25 ATAS ARAHAN EKSPLISIT pemilik
# (bukan diselaraskan senyap oleh agen) -- ini keputusan yang sama jenis
# yang nota asal 2026-08-07 minta pemilik buat.
#
# NOTA PENTING yang masih TERBUKA: kemaskini ini hanya merekodkan build
# APK yang pemilik mahu diuji SEKARANG. Ia TIDAK mengesahkan sama ada
# oracle/workbook TC rasmi (sheet-sheet MBPG-TC-*) turut sudah dikemas
# kini untuk 2.1.25 -- setakat rekod terakhir (gap_mbpg_pending,
# orchestrator.json) oracle/baseline human masih dibaca drpd workbook
# berlabel V2.1.23. Kalau tingkah laku app berbeza antara 2.1.23 dan
# 2.1.25 pada mana-mana TC, itu masih persoalan "pepijat baharu vs
# perubahan build yang disengajakan" -- JANGAN anggap senyap salah satu;
# rekod & tanya pemilik macam D-06/D-09/D-10 yang lalu.
#
# JANGAN "betulkan" nilai ini pada masa depan supaya ia sepadan dengan
# peranti tanpa arahan pemilik -- corak yang sama berulang: setiap
# penyelarasan senyap menjadikan gerbang versi sentiasa lulus dan
# menyembunyikan soalan sebenar tentang build mana yang sedang diuji.
APK_NAME = "MBPG_2.1.25.apk"
APK_VERSI_DIJANGKA = "2.1.25"       # arahan pemilik 2026-10-01 (lihat nota atas)
APK_PATH = os.environ.get("MBPG_APK", "").strip()

# Awalan nombor rekod, contoh 'JB015' dalam JB015P260227001.
#
# Dibaca oleh lapisan pages untuk mengekstrak nombor rekod selepas simpan.
# Ia WAJIB betul: Peraturan Keras #7 menetapkan rekod dibuka IKUT NOMBOR
# dan open_record_by_number() tiada fallback, jadi awalan yang salah
# bermakna created_records kekal kosong dan setiap TC Cetak/Serah/Kemaskini
# pytest.skip. Suite hijau palsu bertukar menjadi suite skip penuh -- jujur,
# tetapi 0 TC berguna berjalan.
#
# BELUM DISAHKAN: awalan sebenar pada server staging. Excel merekod run
# production (JB015...), sementara sheet lama menunjukkan JBM50.../JBM51...
# yang mencadangkan awalan berubah ikut peranti. Sahkan pada rekod pertama
# yang dicipta di device, kemudian betulkan profiles/mbpg-staging.json.
RECORD_PREFIX = PROFILE["record_prefix"]

# Tetapan yang diuji oleh T-001 (Tetapan Alamat IP) dan T-002 (Lesen
# Aplikasi). Nota: alamat IP dimasukkan KE DALAM app semasa T-001 diikuti
# butang Selaras -- ia bukan tetapan sambungan di sebelah sini.
LICENSE_SETTINGS = {
    "internal_ip": PROFILE["internal_ip"],
    "external_ip": PROFILE["external_ip"],
    "lesen_aplikasi": PROFILE["lesen_aplikasi"],
}

TEST_CREDENTIALS = {
    "username": PROFILE["username"],
    "password": PROFILE["password"],
}

# Akaun ganti untuk dicuba secara MANUAL bila akaun utama ditolak. Bukan
# auto-retry: mencuba akaun lain secara automatik akan menyembunyikan fakta
# bahawa akaun utama gagal, dan kegagalan itu sendiri satu penemuan.
# Senarai (username, password, sumber).
AKAUN_ALTERNATIF = _profile.akaun_alternatif(PROFILE)

# Server Appium
APPIUM_URL = "http://127.0.0.1:4723"

# Tetapan peranti
DEVICE_NAME = "Android"
PLATFORM_NAME = "Android"
AUTOMATION_NAME = "UiAutomator2"

# no_reset=True bermakna keadaan app KEKAL antara run: rekod yang dicipta
# run sebelum masih ada, dan placeholder medan hilang selepas simpan
# pertama. Ini disengajakan (login + tetapan IP tidak perlu diulang), tetapi
# ia sebab utama assert berasaskan placeholder tidak boleh dipercayai.
#
# AMARAN, JANGAN TERPERANGKAP: mengubah dua nilai di bawah TIDAK mengubah
# apa-apa. Sesi Appium sebenar menetapkan bendera ini sendiri secara literal
# dalam tests/conftest.py baris 147-148 (`options.no_reset = True`,
# `options.full_reset = False`) dan tidak mengimport dari sini. Dua pemalar
# ini kekal semata-mata sebagai dokumentasi bagi nota di atas -- fail
# conftest.py bukan milik agent ini, jadi ia tidak disambungkan di sini.
NO_RESET = True
FULL_RESET = False

# Siapa menjalankan suite ini — diatribut dalam sejarah run dashboard,
# supaya run seorang ahli tidak disalahanggap sebagai run orang lain.
# Auto-detect dari nama pengguna OS; set MBPG_TESTER untuk menindihnya.
TESTER_NAME = _device_utils.tester_name()

# ---------------------------------------------------------------------------
# Nota warisan: TIADA TEST_DATA di sini, dan itu disengajakan.
#
# Suite MBIP dahulunya membawa dict TEST_DATA berisi nilai yang direka
# sendiri -- nama orang, alamat, plat -- yang TIDAK datang dari mana-mana
# skrip ujian Excel. Satu nilai palsu ("Buruh En Saiful") bertahan berbulan
# sebelum tertangkap, kerana kod mati yang kelihatan seperti data ujian sah
# adalah perangkap: ia disalin ke setiap PBT baharu dan suatu hari
# seseorang mengimportnya semula tanpa sedar nilainya tiada asas.
#
# Satu-satunya sumber data ujian ialah:
#   testdata/excel_data.py   (dijana dari MBPG_V2.1.33_PRODUCTION.xlsx)
#   testdata/overrides.py    (medan yang Excel tidak bekalkan)
# Medan yang Excel senyap tentangnya DIISI dengan penanda BLANK_BY_DESIGN,
# bukan dibiar kosong -- supaya penanda itu keluar pada kertas cetak dan
# sesiapa yang melihatnya tahu nilai itu tiada asas dalam Excel.
# ---------------------------------------------------------------------------

# Timeout (saat)
#
# IMPLICIT_WAIT diturunkan 10 -> 2 (prestasi): is_element_present()
# menambah WebDriverWait di atas implicit wait, jadi dengan implicit=10
# setiap probe elemen-tiada menyekat SEPENUH 10s sebelum melapor tidak
# jumpa -- is_element_present(timeout=1) sebenarnya memakan ~10s, dan
# banyak probe sebegitu dalam reveal_below_fold() menukar satu TC tersekat
# menjadi berminit-minit masa mati. Bukan 0: ~25 panggilan
# driver.find_element/find_elements telanjang dalam pages bergantung pada
# implicit wait (kebanyakannya didahului pengawal is_element_present jadi
# selamat, tetapi find_elements akan memulangkan senarai kosong SERTA-MERTA
# pada 0, memecahkan semakan berasaskan kiraan); 2s mengekalkan ia betul
# sambil memotong masa mati ~5x.
IMPLICIT_WAIT = 2

# EXPLICIT_WAIT_SHORT / _LONG / _UPLOAD dahulunya diisytiharkan di sini,
# dibawa masuk dari suite MBIP. Ketiga-tiganya DIBUANG: carian merentas
# seluruh projek (kecuali _to_delete\) mendapati SIFAR pembaca -- lapisan
# pages menggunakan BasePage.timeout = 15 dan hujah `timeout=` per panggilan,
# bukan pemalar ini. Pemalar timeout yang tidak dibaca lebih buruk daripada
# tiada: seseorang yang menaikkannya untuk membaiki test yang flaky akan
# menyangka dia sudah mencuba sesuatu, sedangkan tiada apa berubah.

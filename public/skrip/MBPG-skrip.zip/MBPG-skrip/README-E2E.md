# Runner E2E — panduan pemilik

1. **Tulis kebenaran.** Cipta `IZIN-E2E.txt` di root repo (digitignore,
   tidak pernah dicommit):

   ```
   tarikh_luput=2026-08-13
   kuota_N=1
   kuota_P=1
   kuota_K=1
   kuota_NK=0
   ```

   `kuota_NK` ialah Notis→Kompaun — kuota **berasingan**, kerana ia
   menjana kompaun BARU daripada notis sedia ada.

2. **Sambung peranti** (USB + Appium jalan) dan **hidupkan printer**
   Bixolon SPP-R410.

3. **Jalankan.** Satu command:

   ```
   python tools/run_e2e.py --borang K --kuota 1
   python tools/run_e2e.py --borang NPK --kuota 3
   ```

4. **Taip `YA`** pada ringkasan yang dipaparkan. (`--terus` melangkaunya
   — hanya guna kalau anda sedar risiko larian berganda.)

5. **Ambil nombor rekod** dari skrin, `reports/E2E.jsonl`, dan
   `docs/FASA-C-REKOD.md`. Itu senarai untuk pembatalan melalui portal
   ePBT.

---

## Yang runner enggan buat

- berjalan tanpa `IZIN-E2E.txt`, atau selepas `tarikh_luput`
- berjalan bila kuota borang itu 0
- mencipta rekod kedua selepas kuota habis — setiap rekod **berjaya**
  menolak kuota dalam fail, jadi gerbang menutup dirinya sendiri
  walaupun runner dijalankan sepuluh kali
- menerima `--set` yang tidak wujud
- menekan CETAK lebih daripada **sekali** setiap rekod
- meneruskan ke borang seterusnya selepas apa-apa kegagalan
- menekan **ePBT** (ia memadam data) atau mencetuskan **MySIKAP** pada
  rekod yang diserah (lookup memulangkan PII orang sebenar)

## Bendera

| Bendera | Kesan |
|---|---|
| `--borang N\|P\|K\|NPK` | borang mana; gabungan dijalankan mengikut urutan anda taip |
| `--kuota N` | had untuk larian ini (kuota dalam fail izin sentiasa terpakai juga) |
| `--set SET-...` | guna satu set tertentu; ditolak kalau set tidak wujud |
| `--terus` | langkau pengesahan `YA` |
| `--tanpa-printer` | teruskan walaupun printer tidak sedia |

## Kalau gagal separuh jalan

Runner berhenti dan **tidak** mencuba borang seterusnya. Rekod yang
sudah dicipta tetap wujud dan sudah ditulis ke `reports/E2E.jsonl` +
`docs/FASA-C-REKOD.md` — kuotanya juga sudah ditolak. Baca nombornya di
situ sebelum menjalankan semula.


---

# Peringkat selepas rekod dicipta

```
python tools/run_e2e_menu.py --peringkat senarai
python tools/run_e2e_menu.py --peringkat senarai,hantar,tarik
python tools/run_e2e_menu.py --peringkat semua
```

| Peringkat | TC | Buat apa | Cipta rekod? |
|---|---|---|---|
| `senarai` | SK-001 | sahkan rekod kita tersenarai | tidak |
| `hantar` | H-001..003 | sahkan status H/M; hantar-semula **hanya** kalau ada status M | tidak |
| `tarik` | TN-001..003 | tarik notis dari server | tidak |
| `nk` | NK-001/002 | Notis→Kompaun | **ya** — perlu `kuota_NK` |

Nombor rekod diambil dari jejak audit (`reports/LEDGER-E2E.jsonl` +
`reports/E2E.jsonl`), jadi peringkat ini betul walaupun rekod dicipta
berhari-hari lalu.

**Masa setiap peringkat dicetak** pada penghujung — itu benchmark untuk
pasukan anda.

Selepas setiap peringkat, kiraan rekod disemak. Kalau peringkat
baca-sahaja menyebabkan rekod bertambah, runner **berhenti**.

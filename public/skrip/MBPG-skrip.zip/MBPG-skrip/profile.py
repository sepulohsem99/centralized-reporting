"""
Profil MBPG — pemuat tetapan per-environment.

KENAPA WUJUD
------------
APK IES yang sama dipasang untuk banyak PBT, dan setiap PBT ada staging +
production sendiri. Nilai yang berbeza antara mereka (alamat server, lesen
aplikasi, akaun login, awalan nombor rekod) dahulunya bertaburan sebagai
pemalar hardcoded dalam config.py — bermakna menukar environment memerlukan
seseorang mengedit fail Python.

Sekarang setiap environment ialah SATU fail JSON dalam profiles/. Tukar
sasaran = tukar satu pembolehubah persekitaran. Tiada kod berubah.

Projek ini MBPG SAHAJA. Profil PBT lain (mbip/mbjb/mdkt) sengaja tidak
dibawa masuk: kalau ia ada dalam profiles/, menu run akan menawarkannya
dan suatu hari seseorang akan tersalah pilih.

TIADA STAGING MBPG. Satu-satunya sasaran ialah production
113.211.155.174, dan itu sebabnya keselamatan di sini bergantung pada
corong tap dry-run (guard/corong.py), bukan pada memilih server yang
lebih selamat.

CARA PROFIL DIPILIH (ikut keutamaan)
-------------------------------------
  1. Pembolehubah persekitaran MBPG_PROFILE (contoh: mbpg-staging)
     -- digunakan oleh menu dalam run_and_report.bat, dan oleh sesiapa
     yang mahu automasi tanpa menu.
  2. Jika hanya SATU profil wujud, ia digunakan terus tanpa soal.
  3. Selain itu: ralat yang menyenaraikan pilihan yang ada.

Tiada nilai default yang diam-diam dipilih apabila ada lebih daripada satu
profil. Menjalankan ujian terhadap server production sedangkan staging yang
dimaksudkan adalah kesilapan yang mahal dan TIDAK BOLEH DIUNDUR -- rekod
kompaun sebenar akan tercipta atas nama pesalah yang direka. Jadi ketaksaan
mesti berhenti serta-merta, bukan diteka.

PAGAR PRODUCTION
----------------
Selain itu, sebarang profil dengan env == "production" ditolak melainkan
MBPG_IZIN_PRODUCTION=1 diset dalam persekitaran yang sama. Ini pagar kedua
di atas ketidaklengkapan sengaja profiles/mbpg-production.json. Dua-dua
pagar itu kawalan, bukan kecacatan.

NOTA NAMA FAIL
--------------
Modul ini bernama `profile`, sama seperti modul profiler dalam pustaka
standard Python. config.py memastikan root projek berada di hadapan
sys.path sebelum mengimportnya, supaya fail INI yang dimuatkan.
"""

import json
import os
import re

HERE = os.path.dirname(os.path.abspath(__file__))
PROFILES_DIR = os.path.join(HERE, "profiles")

# Medan yang mesti ada nilai sebenar sebelum sebarang ujian dijalankan.
#
# `record_prefix` ada dalam senarai ini kerana ia bukan hiasan: ia awalan
# nombor rekod (MBJB: 'JB015...') yang dibaca oleh read_record_number().
# Kalau ia kosong atau salah, setiap nombor rekod dibaca sebagai None,
# created_records tinggal kosong, dan SETIAP TC Cetak/Serah/Kemaskini/
# Bookmark pytest.skip -- suite yang kelihatan berjalan tetapi tidak
# menguji apa-apa. Lebih baik gagal di sini, dalam satu saat.
REQUIRED = [
    "pbt", "env", "app_package", "internal_ip", "external_ip",
    "lesen_aplikasi", "username", "password", "record_prefix",
]

# Penanda dalam fail templat yang bermaksud "belum diisi".
PLACEHOLDER = "ISI-SINI"

# Pembolehubah persekitaran yang mesti diset sebelum profil production
# boleh dimuatkan.
IZIN_PRODUCTION_ENV = "MBPG_IZIN_PRODUCTION"

# Pembolehubah persekitaran yang memilih profil.
PROFILE_ENV = "MBPG_PROFILE"


class ProfileError(RuntimeError):
    """Profil tiada, tak sah, taksa, atau tidak diizinkan -- mesej
    menerangkan tindakan yang perlu diambil."""


def available():
    """Nama semua profil yang ada, mengikut abjad."""
    if not os.path.isdir(PROFILES_DIR):
        return []
    return sorted(
        os.path.splitext(f)[0]
        for f in os.listdir(PROFILES_DIR)
        if f.endswith(".json")
    )


def _load_file(name):
    path = os.path.join(PROFILES_DIR, f"{name}.json")
    if not os.path.isfile(path):
        raise ProfileError(
            f"Profil '{name}' tidak wujud.\n"
            f"  Profil yang ada: {', '.join(available()) or '(tiada)'}"
        )
    try:
        with open(path, encoding="utf-8") as fh:
            data = json.load(fh)
    except json.JSONDecodeError as e:
        raise ProfileError(
            f"Profil '{name}' rosak (bukan JSON sah): {e}\n"
            f"  Fail: {path}"
        )
    data["_name"] = name
    data["_path"] = path
    return data


def _medan_kosong(p):
    """Medan REQUIRED yang masih kosong atau masih penanda templat."""
    return [
        k for k in REQUIRED
        if not str(p.get(k, "")).strip()
        or str(p.get(k)).strip() == PLACEHOLDER
    ]


def _validate(p):
    """Tolak profil yang belum lengkap, dengan menamakan medan yang kosong.

    Sengaja gagal awal: kalau internal_ip masih 'ISI-SINI', ujian akan
    tetap berjalan selama dua jam sebelum gagal dengan sebab yang
    mengelirukan.
    """
    kosong = _medan_kosong(p)
    if kosong:
        raise ProfileError(
            f"Profil '{p['_name']}' belum lengkap.\n"
            f"  Medan yang belum diisi: {', '.join(kosong)}\n"
            f"  Isi nilai sebenar dalam: {p['_path']}\n"
            f"  Jangan isi dengan tekaan -- nilai salah pada lesen_aplikasi "
            f"atau record_prefix menghasilkan kegagalan yang kelihatan "
            f"seperti bug app."
        )
    return p


def _pagar_production(p):
    """Halang profil production dimuatkan secara tidak sengaja."""
    if str(p.get("env", "")).strip().lower() != "production":
        return p
    if os.environ.get(IZIN_PRODUCTION_ENV, "").strip() == "1":
        return p
    raise ProfileError(
        f"Profil '{p['_name']}' menyasarkan PRODUCTION "
        f"({p.get('internal_ip', '?')}) dan DIHALANG.\n"
        "  Run terhadap production boleh MENCIPTA rekod kompaun SEBENAR\n"
        "  dalam pangkalan data majlis. Rekod itu tidak boleh dipadam\n"
        "  dari app.\n"
        "\n"
        "  TIADA STAGING MBPG WUJUD. Tidak seperti MBJB, tiada sasaran\n"
        "  yang lebih selamat untuk dialihkan -- production ialah\n"
        "  satu-satunya server. Itulah sebabnya suite ini berjalan dalam\n"
        "  mod DRY-RUN dengan corong tap (guard/corong.py) yang menyekat\n"
        "  setiap butang penghantaran, dan bukan sebab pagar ini boleh\n"
        "  dilangkau dengan selamat.\n"
        "\n"
        "  Kalau pemilik memang memberi kebenaran bertulis, set:\n"
        f"    set {IZIN_PRODUCTION_ENV}=1\n"
        "    set MBPG_DRY_RUN=1"
    )


# ---------------------------------------------------------------------------
# Pagar pencemaran MBJB   —   POLARITI DIBALIKKAN daripada suite MBJB
# ---------------------------------------------------------------------------
#
# >>> BACA SEBELUM MENYUNTING. Menyalin semula versi MBJB ke sini akan
# >>> MEMECAHKAN suite sepenuhnya. <<<
#
# Suite MBJB mempunyai gerbang bernama _pagar_pencemaran_mbpg() yang
# MENOLAK token MBPG (satu lesen tertentu + akaun user3), kerana di sana
# token itu bukti profil MBJB telah dijana daripada workbook MBPG yang
# dinamakan semula.
#
# Di sini MBPG ialah PBT yang SAH. Token yang sama itu betul sepenuhnya.
# Kalau gerbang MBJB dibawa masuk tanpa dibalikkan, SETIAP profil MBPG
# yang betul gagal dimuatkan dengan "PENCEMARAN MBPG dikesan" dan suite
# tidak boleh bermula langsung. Itu bukan risiko teori: ia dikesan semasa
# recon fork ini (risiko R16).
#
# Bahaya di sini ialah arah BERTENTANGAN — nilai MBJB yang tertinggal
# dalam profil MBPG. Server MBJB ialah pangkalan data majlis LAIN;
# menghalakan run MBPG kepadanya bermakna memandu sistem yang salah
# sambil menyangka kita di Pasir Gudang.
_IP_MBJB = {"epbt.mbjb.gov.my", "219.93.38.103", "219.93.38.103:8880"}
_AWALAN_MBJB = ("JB015", "JBM50", "JBM51")

# IP production MBPG — satu-satunya sasaran sah untuk suite ini.
IP_PRODUCTION_MBPG = "113.211.155.174"


def _pagar_pencemaran_mbjb(p):
    """Tolak profil kalau ia membawa nilai MBJB sebagai NILAI AKTIF.

    Tiga kelas semakan:
      1. internal_ip / external_ip menuding ke server MBJB -- run akan
         memandu pangkalan data majlis yang salah.
      2. record_prefix ialah awalan MBJB (JB015/JBM50/JBM51) -- awalan
         MBPG ialah PGP03. Awalan yang salah bermakna setiap nombor
         rekod dibaca sebagai None dan post-check "tiada rekod baharu"
         akan LULUS secara palsu walaupun rekod memang tercipta.
      3. pbt bukan MBPG langsung.
    """
    nama = p.get("_name", "?")
    laluan = p.get("_path", "?")

    for medan in ("internal_ip", "external_ip"):
        nilai = str(p.get(medan, "")).strip().lower()
        if nilai in _IP_MBJB:
            raise ProfileError(
                f"PENCEMARAN MBJB dikesan dalam profil '{nama}': "
                f"{medan} = {nilai} ialah server MBJB (Johor Bahru), "
                f"bukan MBPG.\n"
                f"  Run akan memandu pangkalan data majlis yang SALAH.\n"
                f"  Sasaran MBPG yang sah: {IP_PRODUCTION_MBPG}\n"
                f"  Betulkan {laluan} dengan tangan -- gerbang ini sengaja "
                f"TIDAK membaiki sendiri (Peraturan Keras #5)."
            )

    awalan = str(p.get("record_prefix", "")).strip().upper()
    if awalan.startswith(_AWALAN_MBJB):
        raise ProfileError(
            f"PENCEMARAN MBJB dikesan dalam profil '{nama}': "
            f"record_prefix = '{awalan}' ialah awalan MBJB, bukan MBPG.\n"
            f"  Awalan MBPG ialah PGP02, DISAHKAN dari peranti pada\n"
            f"  2026-08-13 (rekod PGP02N260813007 dijana oleh app\n"
            f"  sendiri). PGP03 memang wujud tetapi pada notis sisi\n"
            f"  SERVER yang dimuat turun, bukan yang peranti ini jana.\n"
            f"  Ini BUKAN kesilapan kosmetik:\n"
            f"  awalan yang salah menjadikan setiap nombor rekod dibaca\n"
            f"  sebagai None, dan post-check 'tiada rekod baharu' akan\n"
            f"  LULUS secara palsu walaupun rekod memang tercipta.\n"
            f"  Betulkan {laluan} dengan tangan."
        )

    pbt = str(p.get("pbt", "")).strip().upper()
    if pbt and pbt != "MBPG":
        raise ProfileError(
            f"Profil '{nama}' mengisytiharkan pbt='{pbt}'. Suite ini "
            f"MBPG sahaja.\n  Betulkan {laluan} dengan tangan."
        )
    return p


# ---------------------------------------------------------------------------
# Pengesahan record_prefix -- risiko senyap terbesar yang tinggal (2026-07-31)
# ---------------------------------------------------------------------------
#
# `record_prefix` ("JB015" dalam kedua-dua profil) ialah TEKAAN: sifar rekod
# pernah dicipta pada device MBJB, jadi ia tidak pernah disahkan terhadap
# nombor rekod SEBENAR. 15 TC hiliran (Cetak/Serah/Kemaskini/Bookmark)
# bergantung padanya melalui read_record_number() + Peraturan Keras #7
# (rekod dibuka IKUT NOMBOR, tiada fallback). Kalau awalan salah,
# read_record_number() memulangkan None senyap, ledger kekal kosong, dan
# 15 TC itu pytest.skip dengan mesej "show stopper" -- yang KELIHATAN macam
# create gagal, padahal rekod mungkin BERJAYA dicipta pada staging dan kita
# cuma tidak dapat membaca nombornya. Membezakan dua kemungkinan itu SELEPAS
# satu run yang gagal bermakna mencipta lagi rekod pada sistem staging.
#
# Status "belum disahkan" mesti boleh dibaca KOD, bukan hanya komen untuk
# manusia -- medan JSON `record_prefix_disahkan` (bool) + dua medan bukti
# `record_prefix_disahkan_pada` / `record_prefix_disahkan_dari_nombor`.
# Ketiadaan medan (skema lama) dilayan sebagai TEKAAN -- lalai selamat.
#
# JANGAN tulis record_prefix atau tandakan disahkan=true secara automatik
# di sini atau di mana-mana kod lain. Nombor rekod tercetak pada kompaun
# SEBENAR; menulis nilai yang diteka daripada SATU sampel ialah tepat jenis
# "reka nilai data" yang Peraturan Keras #5 larang. Manusia yang menukar
# profiles\*.json dengan tangan selepas MELIHAT nombor sebenar -- fungsi di
# bawah hanya membaca dan membandingkan, tidak pernah menulis.

# Bentuk hujung nombor rekod IES yang diperhati merentas 3 sampel sejarah
# (sheet 'List to Test' V2.1.33 + workbook lama, BUKAN device MBJB kita):
#     JB015N260227001  JB015P260227001  JBM50N251106001  JBM51N250926002
# Kesemuanya <awalan><1 huruf jenis><6 digit tarikh YYMMDD><3 digit urutan>.
# record_prefix ITU SENDIRI (bahagian depan) ialah SEBAB fungsi ini wujud --
# bentuk hujung yang tetap sahaja yang membenarkan pengekstrakan.
_REKOD_HUJUNG = re.compile(
    r"^(?P<awalan>.+?)(?P<jenis>[A-Z])(?P<tarikh>\d{6})(?P<urutan>\d{3})$")


class HasilSahkanAwalan:
    """Keputusan sahkan_awalan() -- tiga keadaan yang MESTI dibezakan.

    Sengaja TIDAK mentakrif __bool__/__eq__: pemanggil dipaksa semak
    `.status` terhadap salah satu pemalar kelas secara eksplisit, supaya
    TIDAK_BOLEH_DITENTUKAN tidak boleh tersilap dilayan sebagai "OK,
    teruskan" oleh `if hasil:` yang malas.
    """
    SEPADAN = "SEPADAN"
    TIDAK_SEPADAN = "TIDAK_SEPADAN"
    TIDAK_BOLEH_DITENTUKAN = "TIDAK_BOLEH_DITENTUKAN"

    def __init__(self, status, awalan_sebenar=None, mesej=""):
        self.status = status
        self.awalan_sebenar = awalan_sebenar
        self.mesej = mesej

    def __repr__(self):
        return (f"HasilSahkanAwalan(status={self.status!r}, "
                f"awalan_sebenar={self.awalan_sebenar!r})")


def sahkan_awalan(nombor, p=None):
    """Bandingkan SATU nombor rekod sebenar (dibaca dari device selepas
    create) dengan record_prefix profil aktif. Pulangkan HasilSahkanAwalan.

    Bacaan sahaja -- lihat blok komen di atas untuk sebab ia tidak pernah
    menulis apa-apa.

    `nombor` = rentetan penuh contoh 'JB015N260227001', ATAU None/"" kalau
    read_record_number() tidak terbaca -- kes itu **TIDAK_BOLEH_DITENTUKAN**,
    BUKAN TIDAK_SEPADAN, kerana ketiadaan bukti bukan bukti awalan salah
    (rekod mungkin berjaya dicipta; kita cuma tidak dapat membaca nombornya).

    Bila `nombor` tidak bermula dengan record_prefix profil, fungsi cuba
    ekstrak awalan sebenar melalui _REKOD_HUJUNG (bentuk hujung tetap yang
    diperhati merentas sampel sejarah). Kalau `nombor` tidak berbentuk itu
    langsung, pengekstrakan GAGAL SELAMAT ke TIDAK_BOLEH_DITENTUKAN --
    fungsi ini tidak pernah meneka awalan yang ia tidak yakin.
    """
    p = p or load()
    awalan_profil = str(p.get("record_prefix", "")).strip()
    nombor = (nombor or "").strip()

    if not nombor:
        return HasilSahkanAwalan(
            HasilSahkanAwalan.TIDAK_BOLEH_DITENTUKAN,
            mesej="Tiada nombor rekod dibekalkan (None/kosong) -- "
                  "read_record_number() tidak terbaca. Ini BUKAN bukti "
                  "awalan salah: rekod mungkin BERJAYA dicipta pada "
                  "staging dan kita cuma tidak dapat membaca nombornya."
        )

    if nombor.startswith(awalan_profil):
        return HasilSahkanAwalan(
            HasilSahkanAwalan.SEPADAN,
            mesej=f"'{nombor}' bermula dengan record_prefix profil "
                  f"'{awalan_profil}'."
        )

    m = _REKOD_HUJUNG.match(nombor)
    if not m:
        return HasilSahkanAwalan(
            HasilSahkanAwalan.TIDAK_BOLEH_DITENTUKAN,
            mesej=f"'{nombor}' tidak bermula dengan record_prefix profil "
                  f"'{awalan_profil}', DAN tidak berbentuk "
                  "<awalan><huruf><tarikh6><urutan3> yang dijangka -- "
                  "tidak dapat ekstrak awalan sebenar dengan yakin. "
                  "Semak nombor ini dengan tangan sebelum membuat "
                  "kesimpulan."
        )

    awalan_sebenar = m.group("awalan")
    laluan = p.get("_path", "profiles\\<profil-aktif>.json")
    return HasilSahkanAwalan(
        HasilSahkanAwalan.TIDAK_SEPADAN,
        awalan_sebenar=awalan_sebenar,
        mesej=(
            f"'{nombor}' TIDAK bermula dengan record_prefix profil "
            f"'{awalan_profil}'. Awalan sebenar nampaknya "
            f"'{awalan_sebenar}'.\n"
            f"  Pembetulan: tukar \"record_prefix\" dalam {laluan} "
            f"daripada \"{awalan_profil}\" kepada \"{awalan_sebenar}\",\n"
            "  kemudian tetapkan \"record_prefix_disahkan\": true dan isi "
            "\"record_prefix_disahkan_pada\" /\n"
            "  \"record_prefix_disahkan_dari_nombor\" dengan tarikh + "
            f"'{nombor}' sebagai bukti.\n"
            "  JANGAN ditulis automatik -- tukar dengan tangan selepas "
            "manusia mengesahkan nombor ini."
        ),
    )


def record_prefix_ialah_tekaan(p=None):
    """True kalau record_prefix profil aktif MASIH belum disahkan daripada
    rekod sebenar pada device.

    Dibaca daripada medan JSON `record_prefix_disahkan` -- boleh disemak
    KOD, bukan hanya komen untuk manusia. Ketiadaan medan (skema sebelum
    2026-07-31) dilayan sebagai TEKAAN (True) -- lalai selamat, sepadan
    prinsip gagal-tertutup suite ini: senyap tentang status pengesahan
    bermakna BELUM disahkan, bukan sebaliknya.
    """
    p = p or load()
    return not bool(p.get("record_prefix_disahkan", False))


def _pagar_pengesahan_awalan(p):
    """Kalau record_prefix_disahkan=true, WAJIB ada bukti (bila + dari
    nombor rekod apa) -- kebolehjejakan yang sama seperti nilai Excel
    (Peraturan Keras #5). Menandakan "disahkan" TANPA bukti sama bahaya
    dengan menulis nilai reka: kedua-duanya kelihatan sah pada pandangan
    pertama tetapi tiada asas yang boleh disemak semula.
    """
    if not p.get("record_prefix_disahkan"):
        return p
    # `.get(k, "")` TIDAK cukup: JSON null dinyahkod sebagai Python None,
    # dan kunci itu WUJUD (nilainya None), jadi lalai "" tidak terpakai --
    # str(None) = "None", bukan kosong, dan semakan `not bila` akan
    # tersilap lulus. Nyahkod None -> "" secara eksplisit dahulu.
    _bila_raw = p.get("record_prefix_disahkan_pada")
    _dari_raw = p.get("record_prefix_disahkan_dari_nombor")
    bila = str(_bila_raw).strip() if _bila_raw is not None else ""
    dari = str(_dari_raw).strip() if _dari_raw is not None else ""
    if not bila or not dari:
        raise ProfileError(
            f"Profil '{p.get('_name', '?')}': record_prefix_disahkan=true "
            "tetapi record_prefix_disahkan_pada / "
            "record_prefix_disahkan_dari_nombor kosong.\n"
            "  Menanda disahkan TANPA bukti (bila + nombor rekod sebenar) "
            "sama bahaya dengan reka nilai data\n"
            "  (Peraturan Keras #5) -- kedua-duanya kelihatan sah tetapi "
            "tiada asas boleh disemak semula.\n"
            f"  Isi kedua-dua medan dalam {p.get('_path', '?')}, atau "
            "kembalikan record_prefix_disahkan kepada false."
        )
    return p


def resolve_name():
    """Nama profil yang patut digunakan — lihat docstring modul."""
    env = os.environ.get(PROFILE_ENV, "").strip()
    if env:
        return env

    names = available()
    if not names:
        raise ProfileError(
            "Tiada profil dijumpai dalam profiles/.\n"
            "  Setiap environment perlukan satu fail JSON di situ.\n"
            f"  Dijangka sekurang-kurangnya: {PROFILES_DIR}"
            + os.sep + "mbpg-staging.json"
        )
    if len(names) == 1:
        return names[0]

    senarai = "\n".join(f"    set {PROFILE_ENV}={n}" for n in names)
    raise ProfileError(
        "Lebih daripada satu profil wujud — pilih satu secara jelas.\n"
        "  Menjalankan ujian terhadap environment yang salah boleh\n"
        "  merosakkan data sebenar, jadi tiada yang dipilih automatik.\n"
        "  Pilih dengan salah satu daripada:\n" + senarai + "\n"
        "  Atau jalankan tests\\run_and_report.bat dan pilih dari menu."
    )


_CACHE = {}


def load(name=None):
    """Profil aktif sebagai dict. Di-cache untuk satu proses.

    Turutan pagar: production (izin) -> pencemaran MBPG -> pengesahan
    awalan (bukti kalau disahkan=true) -> medan lengkap. Production
    disemak dahulu supaya profil production yang sengaja tidak lengkap
    gagal dengan mesej production yang betul dahulu, bukan mesej "medan
    kosong" yang mengelirukan.
    """
    name = name or resolve_name()
    if name not in _CACHE:
        _CACHE[name] = _validate(
            _pagar_pengesahan_awalan(
                _pagar_pencemaran_mbjb(_pagar_production(_load_file(name)))))
    return _CACHE[name]


def is_production_target(p=None):
    """True kalau internal_ip DAN external_ip profil aktif ==
    IP_PRODUCTION_MBPG (113.211.155.174).

    >>> POLARITI DIBALIKKAN daripada suite MBJB. <<<
    Di sana, fungsi setara (is_staging_target) mengesahkan kita BUKAN
    pada production, dan True bermakna selamat. Di sini tiada staging
    MBPG wujud: production ialah satu-satunya sasaran yang sah, jadi
    fungsi ini mengesahkan kita MEMANG berada di sana. False bermakna
    profil menuding ke suatu tempat yang tidak dijangka -- BERHENTI,
    jangan teruskan.

    Pagar TAMBAHAN, bukan gantian, kepada _pagar_pencemaran_mbjb() dan
    _pagar_production() yang sudah berjalan automatik dalam load().
    Fungsi ini semak nilai yang profil AKTIF ISYTIHARKAN -- ia TIDAK
    boleh mengesahkan IP yang app sedang guna SEBENARNYA pada device
    (itu keadaan runtime app selepas T-001 + Selaras, bukan sesuatu
    profile.py/device_utils.py dapat baca tanpa dump UI). Pengesahan
    dari skrin sebenar dilakukan oleh gerbang IP dalam
    tests/conftest.py. Gagal profil = gagal fungsi ini juga
    (ProfileError menular).
    """
    p = p or load()
    return (str(p.get("internal_ip", "")).strip() == IP_PRODUCTION_MBPG
            and str(p.get("external_ip", "")).strip() == IP_PRODUCTION_MBPG)


def label(p=None):
    """Label mesra manusia, contoh: 'MBJB — staging'."""
    p = p or load()
    return f"{p.get('pbt', '?')} — {p.get('env', '?')}"


def akaun_alternatif(p=None):
    """Akaun ganti yang boleh dicuba bila akaun utama ditolak.

    Dikembalikan sebagai senarai (username, password, sumber). Kosong kalau
    profil tidak menyenaraikan apa-apa. Ini BUKAN mekanisme auto-retry:
    memilih akaun secara automatik akan menyembunyikan fakta bahawa akaun
    utama gagal. Ia untuk dibaca oleh manusia (atau dicetak dalam mesej
    kegagalan login) supaya semakan seterusnya jelas.
    """
    p = p or load()
    keluar = []
    for a in p.get("_akaun_alternatif") or []:
        if isinstance(a, dict) and a.get("username"):
            keluar.append((a["username"], a.get("password", ""),
                           a.get("sumber", "")))
    return keluar


def describe(p=None):
    """Ringkasan satu blok untuk dicetak pada permulaan run."""
    p = p or load()

    # Status awalan DIBACA daripada record_prefix_disahkan, bukan
    # dihardcode -- sebelum 2026-07-31 baris ini SELALU mencetak "BELUM
    # DISAHKAN" walaupun selepas seseorang mengesahkannya, kerana ia teks
    # tetap. Sekarang ia ikut record_prefix_ialah_tekaan() setiap kali.
    if record_prefix_ialah_tekaan(p):
        status_awalan = "TEKAAN, BELUM DISAHKAN pada device"
    else:
        status_awalan = (
            f"disahkan {p.get('record_prefix_disahkan_pada', '?')} "
            f"drpd rekod {p.get('record_prefix_disahkan_dari_nombor', '?')}"
        )

    baris = [
        f"  Profil       : {p['_name']}  ({label(p)})",
        f"  Server       : {p['internal_ip']} / {p['external_ip']}",
        f"  Pakej APK    : {p['app_package']}",
        f"  Akaun        : {p['username']}",
        # BUKAN IMEI. Lesen ialah token portal PBT yang disahkan di server;
        # ia tidak sepatutnya sama dengan IMEI peranti dan tidak dibandingkan
        # dengannya. Label pejabat (m50/m51) sengaja tidak dicetak di sini --
        # ia pernah disalah baca sebagai syarat padanan peranti.
        f"  Lesen        : {p['lesen_aplikasi']}  (token portal PBT, "
        f"disahkan di server)",
        f"  Awalan rekod : {p['record_prefix']}  ({status_awalan})",
    ]
    alt = akaun_alternatif(p)
    if alt:
        nama = ", ".join(u for u, _, _ in alt)
        baris.append(f"  Akaun ganti  : {nama}  (cuba hanya bila login gagal)")
    return "\n".join(baris)


if __name__ == "__main__":
    import sys
    if "--list" in sys.argv:
        # Digunakan oleh menu dalam run_and_report.bat. Menyemak SEMUA
        # profil (termasuk production) untuk pencemaran MBPG walaupun
        # MBPG_IZIN_PRODUCTION tidak diset -- ini AUDIT baca-sahaja, bukan
        # "load() untuk digunakan", jadi ia sengaja memanggil
        # _pagar_pencemaran_mbjb() terus tanpa melalui _pagar_production().
        for n in available():
            try:
                p = _load_file(n)
                nota = ""
                if _medan_kosong(p):
                    nota = "  [BELUM LENGKAP]"
                if str(p.get("env", "")).lower() == "production":
                    nota += "  [PRODUCTION -- DIHALANG]"
                try:
                    _pagar_pencemaran_mbjb(p)
                except ProfileError:
                    nota += "  [PENCEMARAN MBPG DIKESAN]"
                print(f"{n}|{p.get('pbt','?')} — {p.get('env','?')}{nota}")
            except ProfileError:
                print(f"{n}|(rosak)")
        sys.exit(0)
    if "--scan-pencemaran" in sys.argv:
        # Semakan mesin berdiri sendiri untuk pencemaran MBPG, exit code
        # gagal-tertutup (1 kalau MANA-MANA profil tercemar ATAU rosak --
        # bukan hanya profil yang sedang aktif). Untuk dipanggil dari
        # check_env.bat atau dijalankan manual selepas menyunting profil.
        gagal = False
        for n in available():
            try:
                _pagar_pencemaran_mbjb(_load_file(n))
                print(f"[OK]    {n}: bersih daripada nilai MBPG dikenali")
            except ProfileError as e:
                print(f"[GAGAL] {n}: {e}")
                gagal = True
        sys.exit(1 if gagal else 0)
    try:
        print(describe())
    except ProfileError as e:
        print(e)
        sys.exit(1)

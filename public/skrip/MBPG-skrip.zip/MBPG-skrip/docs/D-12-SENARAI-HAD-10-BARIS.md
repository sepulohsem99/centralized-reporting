# D-12 — Senarai Kompaun: HAD 10 BARIS TANPA PAGINATION

**Tarikh sahkan:** 2026-10-09
**Build:** 2.1.25 (peranti 5008TF2010009401, Ulefone Armor 27)
**Status:** OPEN — disahkan live, 4 kaedah ujian, semua negatif
**Klasifikasi:** **APP** (bukan skrip)

---

## Ringkasan

Skrin **Senarai Kompaun** memaparkan **tepat 10 baris** rekod yang
**PERTAMA (terlama)** dalam julat tarikh yang ditapis — dan **tiada
sebarang mekanisme** untuk melihat baris ke-11 dan seterusnya:

- Tiada pagination (komponen `pagination-container` **wujud dalam DOM
  tetapi KOSONG** — sifar anak, 162px tinggi)
- Tiada skrol (jadual bukan `scrollable`; swipe diterima, 0px anjakan)
- Tiada susunan (3 header `NO` / `NO AKAUN` / `KETERANGAN` semuanya
  `clickable=true` tetapi tap tidak mengubah susunan)
- Panel carian (`No Kompaun / Notis`, `Tarikh Mula`, `Tarikh Akhir`,
  `Pilih Kompaun`, `Pilih Status`, butang `CARI`) **menerima input
  tetapi mengabaikannya** — 3 kes ujian pulang 10 baris identik

Akibatnya, sebarang rekod yang jatuh pada kedudukan 11+ dalam julat
tarikh **TIDAK BOLEH DICAPAI LANGSUNG** melalui UI.

---

## Bukti (dump XML + probe)

### 1. Bilangan baris = 10 tepat

Julat penuh `1..9 Okt`:
```
10 baris: P,2026-10-05,14:23 / K,14:41 / K,14:42 / K,14:58 / K,15:00
          / K,15:16 / K,15:17 / P,2026-10-08,10:45 / K,11:13 / K,11:15
```

Julat `8..8 Okt` (30 rekod wujud pada hari itu):
```
10 baris: PGP02P261008015, K016, K017, K018, K019, N007, P020, K021, K022, N008
```
Rekod sebenar pada 2026-10-08 termasuk **N023, K024, K025, K026** dan
lain-lain — **kesemuanya tersembunyi** (kedudukan 11+).

Reka bentuk skrin: baris bermula `y=908`, tinggi `141px` setiap satu;
`908 + 10×141 = 2318` = **tepat pinggir bawah skrin** (`2316`).
Tiada ruang untuk baris ke-11. Verified melalui screenshot + UI dump.

### 2. `pagination-container` kosong

```xml
<android.view.ViewGroup bounds="[0,908][1080,1070]"
    content-desc="pagination-container" clickable="false">
  <!-- SIFAR ANAK -->
</android.view.ViewGroup>
```
Komponen React wujud dalam pokok aksesibiliti tetapi **tidak dirender**.

### 3. Skrol gagal

```
(a) sp._scroll_senarai_down()   -> ok=False; 10 baris; tidak berubah
(b) swipe mentah (540,2000 -> 540,1000) -> 10 baris; tidak berubah
(c) swipe x3 (540,2200 -> 540,950)      -> 10 baris; tidak berubah
[SKROL] AMARAN: swipe DIHANTAR tetapi ANJAKAN 0px
```
Tiada elemen `scrollable="true"` untuk jadual dalam dump.

### 4. Susunan gagal

```
tap 'NO' @ (108,834)         -> tidak berubah
tap 'NO AKAUN' @ (438,834)   -> tidak berubah
tap 'KETERANGAN' @ (894,834) -> tidak berubah
tap 'NO AKAUN' 2x (toggle)   -> tidak berubah
```

### 5. Carian diabaikan

Panel carian (ikon `\uf002`) — medan disahkan wujud dan menerima teks:
```xml
EditText [126,616][954,760]   'No Kompaun / Notis'   -> 'PGP02K261008025'
EditText [126,784][954,928]   'Tarikh Mula'          -> '2026-10-08'
EditText [126,952][954,1096]  'Tarikh Akhir'         -> '2026-10-08'
ViewGroup [141,1818][939,1935] 'CARI' (clickable)
```

Keputusan 3 kes:
```
A: PGP02P261008015 (dalam 10) -> 10 baris  [SAMA]
B: PGP02K261008025 (ke-11)    -> 10 baris  [SAMA]
C: PGP02K261008026 (ke-12)    -> 10 baris  [SAMA]
```

---

## Kesan kepada ujian automasi

| TC | Kesan |
|---|---|
| **SK-001** Senarai Kompaun | Laporan larian: "rekod kita 1/101 dijumpai" — hanya 1 rekod boleh dibuka |
| **N-004 / P-004 / K-004** Kemaskini | Rekod dicipta dalam larian yang SAMA tidak dapat dibuka semula untuk kemaskini |
| **N-003 / P-003 / K-003** Serah (pengesahan) | Pengesahan dalam Senarai tersekat (sebahagian) |
| `ensure_records_for` | Mengembalikan `True` (10 baris wujud) sedangkan rekod sasaran **tidak** dalam paparan → diagnosis lapuk melaporkan "tiada baris" |

---

## Kesan kepada penguatkuasaan sebenar

Pengguna yang menapis satu hari dengan lebih 10 rekod **tidak boleh
melihat atau membuka 10 rekod terbaru** (yang paling penting untuk
tindakan susulan). Tiada cara untuk mencari nombor tertentu melalui
carian. Ini bukan sekadar isu ujian — ia had operasi sebenar.

Bagi **pembatalan rekod ujian**: rekod yang dicipta selepas 10 yang
pertama pada hari itu **tidak boleh dibuka dalam app**; pembatalan
mesti dibuat melalui portal ePBT.

---

## Cara elak (sementara, dalam skrip)

Memandangkan app tidak boleh menyelesaikan had-10, langkah mitigasi
terbaik ialah **kurangkan bilangan rekod sehari** supaya kesemua
rekod ujian berada dalam 10 teratas, atau **selang selang hari**
(jangan cipta >10 rekod pada satu tarikh).

Alternatif jangka panjang hanya boleh diselesaikan oleh pasukan app:
tambah pagination ≥25 baris, atau baiki tapisan carian supaya medan
`No Kompaun / Notis` benar-benar menapis.

---

## Cadangan kepada pasukan app

1. **PRIORITI TINGGI** — Tingkatkan had baris (25/50) **DAN** aktifkan
   pagination (`pagination-container` sudah ada dalam DOM, cuma kosong).
2. **PRIORITI TINGGI** — Baiki carian: medan `No Kompaun / Notis`
   mesti benar-benar menapis senarai (bukti: 3 kes ujian pulang 10
   baris identik).
3. **SEDERHANA** — Benarkan susunan lajur (menaik/menurun) supaya
   rekod terbaru boleh dibawa ke atas.
4. **SEDERHANA** — Benarkan skrol jadual bila baris melebihi paparan.

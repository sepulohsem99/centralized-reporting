# SPEC FASA C — E2E SEBENAR MBPG (CREATE → PRINT → SUBMIT KE PRODUCTION)

**Status:** DRAF · BERKUNCI · menunggu kelulusan bertulis PM + MBPG
**Tarikh:** 2026-08-12
**Untuk:** perbincangan pemilik ↔ PM ↔ MBPG sebelum sebarang pelaksanaan

> ⚠️ Fasa C adalah satu-satunya fasa yang mencipta REKOD SEBENAR pada
> production MBPG. Fasa 1 (49 TC fill-only) dan Fasa 2 (sweep 284 set)
> dua-duanya SIFAR rekod. Fasa C mematahkan sempadan itu secara sedar
> dan terkawal — ia tidak boleh bermula atas kelulusan lisan sahaja.

---

## 1. APA YANG BERUBAH DARI FASA 1 & 2

| Perkara | Fasa 1+2 (siap) | Fasa C (dicadang) |
|---|---|---|
| Butang SERAH/HANTAR | HARAM (tripwire) | DIBENARKAN untuk set terpilih |
| Rekod PGP03 | 0 dicipta | rekod SEBENAR dicipta |
| Printer | dibuang dari kod | dipasang semula (TSC) |
| Gate | MBPG_DRY_RUN=1 dikunci | MBPG_IZIN_SERAH diisi manual pemilik |
| Kelulusan | pemilik (sesi) | PM + MBPG bertulis |

---

## 2. PRA-SYARAT (SEMUA WAJIB SEBELUM MULA)

1. **Kelulusan bertulis** dari PM DAN wakil MBPG — emel/dokumen, bukan
   lisan. Nyatakan dengan jelas: kompaun SEBENAR akan dicipta pada
   production.
2. **Senarai kod kompaun dibenarkan** — MBPG tetapkan kod/akta/kesalahan
   MANA yang boleh dicipta untuk ujian (jangan borong 284). Cadangan:
   1–3 set wakil sahaja.
3. **Plan lupus rekod ujian** — selepas cipta, rekod tu ada dalam sistem
   MBPG sebenar. Tetapkan: biarkan (dengan penanda ujian), atau batalkan
   melalui proses pembatalan rasmi MBPG (proses itu sendiri = kelulusan
   berasingan). JANGAN hard-delete DB.
4. **Printer TSC** dipasang, dihidupkan, kertas dimuatkan, dan diuji
   cetak sekali secara manual dulu.
5. **Data pesalah SAH** — nama/IC/plat sebenar atau data ujian rasmi yang
   MBPG luluskan (bukan rekaan — ia jadi rekod kompaun sebenar).
6. **Gate MBPG_IZIN_SERAH** diisi manual oleh pemilik + medan ISI-SINI
   pada masa run, bukan disimpan dalam repo.

---

## 3. KAWALAN KESELAMATAN (KEKAL WALAUPUN SERAH DIBENARKAN)

- **Whitelist set**: hanya set dalam senarai MBPG-luluskan yang boleh
  diserah. Set lain kekal tripwire.
- **Kiraan maksimum**: had keras N rekod per run (cth 3). Lepas N, abort.
- **Satu-per-satu + pengesahan**: setiap serah papar ringkasan penuh
  (kod, kesalahan, denda, pesalah) → pemilik sahkan secara manual dalam
  chat SEBELUM tap pengesahan akhir. Tiada auto-serah pukal.
- **Popup validation**: kekal — baca + screenshot semua teks sebelum
  sebarang butang pengesahan.
- **Post-check setiap serah**: sahkan TEPAT 1 rekod baru dicipta dengan
  nombor PGP03 yang dijangka; kalau lebih/kurang → HENTI.
- **Ledger penuh**: setiap rekod dicipta direkod (nombor, masa, set,
  denda, screenshot resit) untuk jejak audit + plan lupus.

---

## 4. URUTAN LANGKAH (per set terpilih)

1. Login → Daftar Kompaun (jenis ikut set).
2. Isi Pesalah (data SAH) + read-back.
3. Pilih 3 dropdown (kod→akta→kesalahan) ikut set + read-back.
4. **PAPAR RINGKASAN → TUNGGU sahkan pemilik dalam chat.**
5. Serah → popup validation → screenshot → tap pengesahan akhir.
6. Post-check: 1 rekod baru, nombor PGP03 betul, denda betul.
7. **Cetak** resit (printer TSC) → sahkan output fizikal.
8. Rekod dalam ledger E2E.
9. (Kemudian, jika plan = batal) proses pembatalan rasmi — kelulusan
   berasingan.

---

## 5. RISIKO & MITIGASI

| Risiko | Mitigasi |
|---|---|
| Rekod sebenar tercipta silap | Whitelist + sahkan manual per serah + had N |
| Data pesalah rekaan jadi rekod rasmi | Guna data SAH/diluluskan MBPG sahaja |
| Rekod ujian kekal dalam statistik MBPG | Plan lupus + penanda ujian dipersetujui awal |
| Printer gagal separuh jalan | Uji cetak manual dulu; kegagalan cetak ≠ ulang serah |
| Popup pengesahan ambigu | Screenshot + henti + tanya, jangan teka |
| Auto-serah terlepas | Tiada mod pukal; satu-per-satu + sahkan chat wajib |

---

## 6. APA YANG DIPERLUKAN DARI PM (RINGKASAN 1 BARIS UNTUK MESYUARAT)

> "Kami nak jalankan 1–3 kompaun UJIAN SEBENAR (create+print+submit) pada
> production MBPG untuk sahkan aliran hujung-ke-hujung. Perlu: (a)
> kelulusan bertulis, (b) senarai kod dibenarkan, (c) data pesalah sah,
> (d) plan lupus rekod ujian. Fill-only 49 TC + sweep 284 set dah siap,
> sifar rekod. Fasa C mencipta rekod sebenar — jadi ia perlu kelulusan
> formal, bukan lisan."

---

**Sebelum apa-apa dijalankan:** dokumen ini dibawa ke PM, keputusan
direkod, dan pemilik bagi arahan eksplisit + isi gate MBPG_IZIN_SERAH.
Sehingga itu — Fasa C KEKAL BERKUNCI.

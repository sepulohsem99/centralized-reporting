# FASA C — rekod production sebenar yang dicipta

> Setiap nombor di bawah ialah rekod HIDUP pada production MBPG.
> Pembatalan melalui portal ePBT oleh pihak berautoriti.

| Jenis | No. rekod | No. siri | Masa | Pesalah (data ujian) | Cetak |
|---|---|---|---|---|---|
| N-001 | `PGP02N260813007` | 8 | 2026-08-13 | AMIRUL (oracle N-001) | **DISAHKAN FIZIKAL** (larian pemilik) |
| N-001 | `PGP02N260813006` | 6 | 2026-08-13 | AMIRUL (oracle N-001) | **DISAHKAN FIZIKAL** |

## E2E N-001 — LENGKAP

| Peringkat | Bukti |
|---|---|
| Cipta | `PGP02N260813006`, siri 6, `namapesalah=AMIRUL`, `statusnotis=A` |
| Hantar | `SEMUA DATA BERJAYA DIHANTAR`; 4 gambar, semua `statushantar=H` |
| Cetak | Satu tekan CETAK; kertas keluar dari `SPP-R410_110095` |
| Sahkan | Pemilik menyemak kertas: no. notis, pesalah, dan kesalahan (letak kereta / PMTLK) SEMUA padan |

Disahkan oleh pemilik 2026-08-13. TC berkaitan: N-001 (cipta), N-002
(cetak), N-003 (lampiran/kamera) — ketiga-tiga kini terbukti hujung ke
hujung pada production.

## Nota P-001 — nama pesalah BUKAN dari oracle P001

Rekod `PGP02P260813001` membawa `namapesalah = AUTOTEST SWEEP`, bukan
`AFIQ` seperti dalam oracle P001.

Puncanya: laluan `sedia_borang_kompaun()` mengisi tab Pesalah melalui
`isi_pesalah_minimum()` — data minimum sweep — dan bukan dari oracle.
Oracle P001 hanya membekalkan tiga dropdown kod kompaun dan medan
Penerima. Itu laluan yang sama yang sweep 284 gunakan, dan ia tidak
pernah menjadi masalah sebelum ini kerana sweep tidak pernah menyerah.

Kesan: identiti pada rekod tetap **sintetik** (tiada PII orang sebenar),
tetapi ia bukan identiti yang arahan pemilik nyatakan. Direkod di sini
dan bukan dibetulkan senyap.

## Nota K-001 — identiti ditimpa oleh pencerminan plat (D-05)

Rekod `PGP02K260813002` membawa nombor PLAT dalam medan `namapesalah`,
bukan nama oracle.

Puncanya **D-05**, defek pencerminan plat yang sudah didokumenkan:
menaip No. Kereta mencerminkan plat ke medan identiti. Urutan isian
saya ialah Nama → No K/P/SSM → **No. Kereta**, jadi langkah terakhir
menimpa dua yang pertama.

Pembetulan untuk lain kali: isi **No. Kereta DAHULU**, kemudian Nama
dan IC, supaya pencerminan berlaku sebelum nilai sebenar ditaip.

Kesan: **tiada PII orang sebenar** pada rekod — nilai itu hanyalah
nombor plat ujian. Tetapi identiti bukan identiti oracle seperti arahan 3(a)
nyatakan. Direkod di sini, bukan dibetulkan senyap. Kuota K kekal 1/1;
tiada ulangan tanpa arahan pemilik.

Jaring PII tidak menangkapnya kerana ia memeriksa BENTUK PII (nama
dengan penghubung keturunan, IC bersengkang) — bukan "adakah identiti
ini identiti oracle". Itu semakan berbeza yang tidak wujud.

## Kos sampingan

| Siri | Perkara |
|---|---|
| `PGP02N260813005` | Siri YATIM. Percubaan serah dibunuh had-masa alat semasa mengisi borang, selepas gambar ditulis. Baris `local_ekpn_notis_amaran_details` wujud tanpa rekod notis. Tidak dipadam. Penomboran notis melompat 005 -> 006. |
| `PGP02N260807001` – `PGP02N260812004` | Empat baris details yatim dari recon terdahulu, sebelum Fasa C diluluskan. |
| P-001 | `PGP02P260813001` | 2 | 2026-08-13 12:24 | **AUTOTEST SWEEP** (lihat nota) | dihantar ke printer |
| K-001 | `PGP02K260813002` | 3 | 2026-08-13 13:25 | nombor plat ujian (lihat nota K) | dihantar ke printer |
| N-001 | `None` | 8 | 2026-08-13 16:01:03 | AMIRUL | dihantar |
| N-001 | `PGP02N260817008` | 9 | 2026-08-17 13:43:23 | UJIAN AUTOMASI E2E N-001 20260817-1335 | dihantar |
| P-001 | `PGP02P260818003` | 4 | 2026-08-18 09:44:59 | UJIAN AUTOMASI E2E P-001 20260818-0937 | dihantar |
| P-001 | `PGP02P260818004` | 5 | 2026-08-18 10:12:52 | UJIAN AUTOMASI E2E P-001 20260818-1005 | dihantar |
| P-001 | `PGP02P260818005` | 6 | 2026-08-18 10:36:11 | UJIAN AUTOMASI E2E P-001 20260818-1029 | dihantar |
| P-001 | `PGP02P260818006` | 7 | 2026-08-18 11:00:15 | UJIAN AUTOMASI E2E P-001 20260818-1053 | dihantar |
| K-001 | `PGP02K260818008` | 9 | 2026-08-18 12:05:07 | UJIAN AUTOMASI E2E K-001 20260818-1157 | dihantar |
| N-001 | `PGP02N260818001` | 2 | 2026-08-18 17:00:18 | UJIAN AUTOMASI E2E N-001 20260818-1652 | dihantar |
| P-001 | `PGP02P260818001` | 2 | 2026-08-18 17:08:48 | UJIAN AUTOMASI E2E P-001 20260818-1701 | dihantar |
| N-001 | `PGP02N260819002` | 3 | 2026-08-19 16:36:42 | UJIAN AUTOMASI E2E N-001 20260819-1628 | dihantar |
| P-001 | `PGP02P260819003` | 4 | 2026-08-19 16:46:52 | UJIAN AUTOMASI E2E P-001 20260819-1639 | dihantar |
| K-001 | `PGP02K260819004` | 5 | 2026-08-19 16:59:10 | UJIAN AUTOMASI E2E K-001 20260819-1649 | dihantar |
| K-001 | `PGP02K260819005` | 6 | 2026-08-19 17:11:19 | UJIAN AUTOMASI E2E K-001 20260819-1702 | dihantar |
| K-001 | `PGP02K260819006` | 7 | 2026-08-19 17:23:30 | UJIAN AUTOMASI E2E K-001 20260819-1714 | dihantar |
| N-001 | `PGP02N260820001` | 2 | 2026-08-20 12:54:40 | UJIAN AUTOMASI E2E N-001 20260820-1246 | dihantar |
| N-001 | `PGP02N260820002` | 3 | 2026-08-20 15:50:39 | UJIAN AUTOMASI E2E N-001 20260820-1542 | dihantar |
| P-001 | `PGP02P260820001` | 2 | 2026-08-20 16:01:06 | UJIAN AUTOMASI E2E P-001 20260820-1554 | dihantar |
| K-001 | `PGP02K260820003` | 4 | 2026-08-20 16:12:55 | UJIAN AUTOMASI E2E K-001 20260820-1603 | dihantar |
| K-001 | `PGP02K260820005` | 6 | 2026-08-20 16:25:38 | UJIAN AUTOMASI E2E K-001 20260820-1616 | dihantar |
| K-001 | `PGP02K260820007` | 8 | 2026-08-20 16:38:13 | UJIAN AUTOMASI E2E K-001 20260820-1629 | dihantar |
| N-001 | `PGP02N260910001` | 2 | 2026-09-10 12:37:08 | UJIAN AUTOMASI E2E N-001 20260910-1228 | dihantar |
| P-001 | `PGP02P260910001` | 2 | 2026-09-10 12:47:33 | UJIAN AUTOMASI E2E P-001 20260910-1240 | dihantar |
| K-001 | `PGP02K260910003` | 4 | 2026-09-10 12:59:08 | UJIAN AUTOMASI E2E K-001 20260910-1250 | dihantar |
| K-001 | `PGP02K260910005` | 6 | 2026-09-10 13:11:43 | UJIAN AUTOMASI E2E K-001 20260910-1302 | dihantar |
| K-001 | `PGP02K260910007` | 8 | 2026-09-10 13:24:17 | UJIAN AUTOMASI E2E K-001 20260910-1315 | dihantar |
| N-001 | `PGP02N260910003` | 4 | 2026-09-10 14:22:23 | UJIAN AUTOMASI E2E N-001 20260910-1414 | dihantar |
| N-001 | `PGP02N260910004` | 5 | 2026-09-10 15:20:12 | UJIAN AUTOMASI E2E N-001 20260910-1511 | dihantar |
| P-001 | `PGP02P260910008` | 9 | 2026-09-10 15:36:43 | UJIAN AUTOMASI E2E P-001 20260910-1529 | dihantar |
| K-001 | `PGP02K260910010` | 11 | 2026-09-10 15:54:50 | UJIAN AUTOMASI E2E K-001 20260910-1545 | dihantar |
| K-001 | `PGP02K260910012` | 13 | 2026-09-10 16:13:53 | UJIAN AUTOMASI E2E K-001 20260910-1604 | dihantar |
| K-001 | `PGP02K260910014` | 15 | 2026-09-10 16:32:54 | UJIAN AUTOMASI E2E K-001 20260910-1623 | dihantar |
| P-001 | `PGP02P260913001` | 2 | 2026-09-13 20:53:35 | UJIAN AUTOMASI E2E P-001 20260913-2046 | dihantar |
| K-001 | `PGP02K260913003` | 4 | 2026-09-13 21:12:05 | UJIAN AUTOMASI E2E K-001 20260913-2102 | dihantar |
| K-001 | `PGP02K260913005` | 6 | 2026-09-13 21:31:32 | UJIAN AUTOMASI E2E K-001 20260913-2122 | dihantar |
| K-001 | `PGP02K260913007` | 8 | 2026-09-13 21:50:50 | UJIAN AUTOMASI E2E K-001 20260913-2141 | dihantar |
| N-001 | `PGP02N260914001` | 2 | 2026-09-14 00:40:35 | UJIAN AUTOMASI E2E N-001 20260914-0032 | dihantar |
| N-001 | `PGP02N260914002` | 3 | 2026-09-14 09:58:08 | UJIAN AUTOMASI E2E N-001 20260914-0949 | dihantar |
| N-001 | `PGP02N261001001` | 2 | 2026-10-01 14:04:27 | UJIAN AUTOMASI E2E N-001 20261001-1355 | dihantar |
| P-001 | `PGP02P261001001` | 2 | 2026-10-01 14:17:55 | UJIAN AUTOMASI E2E P-001 20261001-1409 | dihantar |
| K-001 | `PGP02K261001002` | 3 | 2026-10-01 14:37:42 | UJIAN AUTOMASI E2E K-001 20261001-1427 | dihantar |
| K-001 | `PGP02K261001004` | 5 | 2026-10-01 14:53:54 | UJIAN AUTOMASI E2E K-001 20261001-1443 | dihantar |
| K-001 | `PGP02K261001006` | 7 | 2026-10-01 15:10:20 | UJIAN AUTOMASI E2E K-001 20261001-1459 | dihantar |
| N-001 | `PGP02N261005001` | 2 | 2026-10-05 10:29:15 | UJIAN AUTOMASI E2E N-001 20261005-1020 | dihantar |
| N-001 | `PGP02N261005003` | 4 | 2026-10-05 11:09:34 | UJIAN AUTOMASI E2E N-001 20261005-1100 | dihantar |
| N-001 | `PGP02N261005005` | 6 | 2026-10-05 11:55:36 | UJIAN AUTOMASI E2E N-001 20261005-1146 | dihantar |
| P-001 | `PGP02P261005001` | 2 | 2026-10-05 12:11:34 | UJIAN AUTOMASI E2E P-001 20261005-1203 | dihantar |
| K-001 | `PGP02K261005002` | 3 | 2026-10-05 12:37:11 | UJIAN AUTOMASI E2E K-001 20261005-1227 | dihantar |
| K-001 | `PGP02K261005004` | 5 | 2026-10-05 12:54:43 | UJIAN AUTOMASI E2E K-001 20261005-1244 | dihantar |
| K-001 | `PGP02K261005006` | 7 | 2026-10-05 13:12:21 | UJIAN AUTOMASI E2E K-001 20261005-1302 | dihantar |
| P-001 | `PGP02P261005008` | 9 | 2026-10-05 14:25:14 | UJIAN AUTOMASI E2E P-001 20261005-1417 | dihantar |
| K-001 | `PGP02K261005009` | 10 | 2026-10-05 14:41:57 | UJIAN AUTOMASI E2E K-001 20261005-1431 | dihantar |
| K-001 | `PGP02K261005011` | 12 | 2026-10-05 14:59:39 | UJIAN AUTOMASI E2E K-001 20261005-1449 | dihantar |
| K-001 | `PGP02K261005013` | 14 | 2026-10-05 15:17:22 | UJIAN AUTOMASI E2E K-001 20261005-1507 | dihantar |
| P-001 | `PGP02P261008015` | 16 | 2026-10-08 10:47:35 | UJIAN AUTOMASI E2E P-001 20261008-1039 | dihantar |
| K-001 | `PGP02K261008016` | 17 | 2026-10-08 11:14:22 | UJIAN AUTOMASI E2E K-001 20261008-1103 | dihantar |
| K-001 | `PGP02K261008018` | 19 | 2026-10-08 11:33:27 | UJIAN AUTOMASI E2E K-001 20261008-1123 | dihantar |
| K-001 | `PGP02K261008019` | 20 | 2026-10-08 11:48:48 | UJIAN AUTOMASI E2E K-001 20261008-1138 | dihantar |

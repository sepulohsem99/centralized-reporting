# D-03 — Rekod jalan production tanpa poskod menyekat borang Kompaun

**Dijumpai:** 2026-08-10, peringkat 6, MBPG-TC-P-001 dan MBPG-TC-K-001.
**Build:** 2.1.21 (oracle ditulis untuk 2.1.20).
**Kategori:** data production, bukan kod app — tetapi kesannya menyekat
sepenuhnya.

## Apa yang berlaku

P-001 gagal maju dari tab PESALAH ke tab KOMPAUN. Kegagalan pertama
kelihatan seperti masalah locator:

```
SETERUSNYA TIDAK DIJUMPAI selepas KEDUA-DUA laluan dicuba
```

Ia bukan. Beberapa langkah kemudian app bercakap sendiri:

```
Maklumat Tidak Lengkap
Sila lengkapkan maklumat di tab Pesalah dahulu.
```

## Rantaian sebab

1. Suite memilih `JALAN GUNUNG 12` dari cadangan (seperti oracle).
2. App mengisi sendiri taman/bandar/negeri — dan meninggalkan **poskod
   KOSONG**:

   ```
   [AUTO-ISI] selepas pilih 'JALAN GUNUNG 12':
       taman  = 'BANDAR SERI ALAM'
       poskod = (KOSONG)
       bandar = 'MASAI'
       negeri = 'JOHOR'
   ```

3. Suite TIDAK menaip ganti (keputusan pemilik 2026-08-05 — menaip
   ganti akan menopengkan tepat bug kelas ini).
4. Tab PESALAH kekal tidak lengkap.
5. App menguatkuasakan urutan tab dan enggan membuka tab KOMPAUN.

## Bukti DB — app tiada apa untuk diisi

Dibaca dari DB peranti production (`local_ekpn_jalan`, `local_ekpn_taman`):

| Jalan | poskod jalan | taman | poskod taman | Keputusan |
|---|---|---|---|---|
| `JALAN KALOI 13` (N-001) | **81700** | TANJONG PUTERI RESORT | *(kosong)* | N-001 **LULUS** |
| `JALAN NURI 3` (P-001 notis) | **81700** | TAMAN SCIENTEX | *(kosong)* | — |
| `JALAN GUNUNG 12` (P-001 pesalah) | *(kosong)* | BANDAR SERI ALAM | *(kosong)* | P-001 **TERSEKAT** |
| `JALAN RIMBA 2` (K-001) | *(kosong)* | BANDAR SERI ALAM | *(kosong)* | K-001 **TERSEKAT** |

Ini bukan kes terpencil:

* **1276 daripada 3493** rekod jalan (**36.5%**) tiada poskod.
* **40 daripada 76** rekod taman tiada poskod.

Sebab N-001 lulus dan P/K-001 tidak, akhirnya, hanya kerana jalan yang
oracle pilih untuk N kebetulan mempunyai poskod dan yang untuk P dan K
tidak.

## Percanggahan oracle vs production

Oracle mengharapkan poskod `81750` dan bandar `PASIR GUDANG` untuk
`JALAN GUNUNG 12`. DB production memberi bandar `MASAI` dan tiada
poskod langsung. Alamat oracle, seperti yang tertulis, **tidak wujud**
dalam data production.

## Kenapa ini penting melebihi dua TC

Mana-mana kompaun yang seorang penguatkuasa cuba daftarkan pada
mana-mana daripada 1276 jalan itu akan berhenti pada dinding yang sama.
Bukan mesej ralat yang menerangkan puncanya — hanya "Maklumat Tidak
Lengkap" pada tab yang kelihatan sudah diisi, kerana medan poskod
berada di bawah lipatan.

## Status selepas keputusan pemilik 2026-08-10

**DEFEK KEKAL TERBUKA.** Pemilik memilih pilihan (a): suite kini
memilih sendiri sauh alamat yang poskodnya WUJUD
(`testdata/sauh_alamat.py`, dipilih `JALAN ALAMANDA 1`). Itu
menyahsekat P-001, yang kemudian **LULUS PENUH** dengan app mengisi
`poskod = 81700` sendiri — mengesahkan bahawa mekanisme auto-isi
berfungsi dan yang rosak ialah DATA.

Poskod tidak pernah ditaip oleh suite, jadi auto-isi kekal diuji.

Perubahan itu untuk ujian. Ia tidak mengubah apa-apa untuk
penguatkuasa di lapangan: 1276 jalan itu masih tidak boleh didaftarkan
kompaun.

## Apa yang TIDAK terbukti

* Sama ada app **sepatutnya** menerima poskod kosong. Mungkin
  pengesahannya betul dan datanya yang tidak lengkap.
* Sama ada 2.1.20 berkelakuan sama.
* Sama ada poskod boleh ditaip secara manual dan diterima — suite tidak
  menaipnya atas arahan pemilik, jadi laluan itu tidak dicuba.
* Dari mana 1276 rekod tanpa poskod itu datang (sync dari server,
  atau memang begitu di hulu).

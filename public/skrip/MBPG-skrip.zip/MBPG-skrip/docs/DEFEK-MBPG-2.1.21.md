# DEFEK APP — IES/KOMPAUN e-PBT 2.1.21 (MBPG)

> Diperhati pada peranti Ulefone Armor 27 (`5008TF2010009401`),
> production `113.211.155.174`, 2026-08-10.
> Build device **2.1.21**; oracle ditulis untuk **2.1.20** — setiap
> dapatan di bawah ditanda versi 2.1.21, dan beza versi kekal sebagai
> punca yang mungkin sehingga disemak terhadap 2.1.20.

Defek di bawah diklasifikasikan **CALON DEFEK APP** oleh pemilik. Ia
BUKAN kegagalan skrip: dalam setiap kes automasi melakukan apa yang
diminta dan mengesahkan hasilnya; appnya yang berkelakuan lain
daripada yang didokumenkan.

| ID | Ringkas | Ditambah |
|---|---|---|
| D-01 | Selaras tidak idempotent; app tercampak keluar | 2026-08-10 |
| D-02 | Medan Internal IP tidak dipersist | 2026-08-10 |
| D-07 | Nombor siri dibakar bila borang dibuka, tanpa serahan | 2026-08-13 |
| D-08 | Selaras Maklumat Kompaun (T-005) meranapkan app — BERSELANG-SELI (5 gagal, 1 lulus) | 2026-08-18 |

---

## D-01 — Selaras TIDAK IDEMPOTENT; app tercampak keluar

**Keterukan:** tinggi. Ia menamatkan sesi pengguna dan menghalang
mana-mana ujian selanjutnya sehingga app dimulakan semula.

**Langkah:**
1. Jalankan Selaras Maklumat Alamat sekali — BERJAYA
   (`Berjaya | Data Alamat Berjaya Disimpan!`).
2. Jalankan Selaras Maklumat Alamat SEKALI LAGI atas data yang sama.

**Jangkaan** (nota MBJB: "selaras boleh diulang dengan selamat"):
sync kedua selesai, atau tidak melakukan apa-apa.

**Sebenar:** toast ralat
- `Duplicate entry for local_ekpn_bandar`
- `Duplicate entry for local_ekpn_jalan`

kemudian **app tercampak keluar ke skrin utama Android**.

**Bukti:** video pemilik 2026-08-10 11:44 — toast pendua jelas pada
~57s dan ~72s; app keluar pada 11:39; telefon melopong pada skrin utama
selama 4 minit.

**Analisis (dari salinan DB baca-sahaja selepas kejadian):**

```
PRAGMA integrity_check   -> ok
PRAGMA foreign_key_check -> bersih
local_ekpn_bandar        baris=7     unik(kod)=7      tiada pendua
local_ekpn_jalan         baris=3493  unik(kod)=3493   tiada pendua
local_ekpn_taman         baris=76    unik(kod)=76     tiada pendua
```

Datanya SIHAT. Tiada baris pendua wujud. Maka ralat itu bukan data yang
rosak — ia sync yang melakukan `INSERT` mentah dan bukan upsert, jadi
larian kedua berlanggar dengan barisnya SENDIRI daripada larian pertama.
Pengendalian pengecualian yang hilang di sekitarnya menjadikan
perlanggaran itu ranap, bukan mesej ralat.

**Kesan pada suite:** T-004 (dan berkemungkinan setiap TC Selaras) hanya
boleh dipercayai pada peranti yang BELUM disync. Selepas itu, mengulangi
sync ialah operasi yang merosakkan sesi.

**Keputusan pemilik:** jangan ulang T-004 semata-mata untuk
menstabilkannya. Guna snapshot dari sync yang BERJAYA
(`data/snapshot-20260807/`). Pengesanan alert-lewat boleh diperbaiki
kemudian tanpa peranti.

**Pemulihan yang dilaksanakan:** selepas ranap — relaunch, kemudian
sahkan DB tidak korup (`PRAGMA integrity_check` + kiraan pendua +
kiraan rekod) SEBELUM menyambung. Dijalankan 2026-08-10: bersih.

---

## D-02 — Medan Internal IP tidak dipersist

**Keterukan:** sederhana. Nilai diterima dan dipaparkan, jadi pengguna
percaya ia tersimpan.

**Langkah:**
1. Menu Selaras > Tetapan Alamat IP. Internal kosong, External
   `113.211.155.174`.
2. Isi Internal `113.211.155.174`. SIMPAN.
3. Buka semula skrin — kedua-dua medan menunjukkan
   `113.211.155.174`. **Read-back LULUS.**
4. Mulakan semula app. Buka semula skrin.

**Jangkaan:** Internal kekal `113.211.155.174`.

**Sebenar:** Internal **kosong semula**. Disahkan pada DUA run berturut,
setiap satu selepas SIMPAN yang berjaya dan read-back yang lulus.

**Analisis:**

```
local_connection_details -> [('113.211.155.174', 'Ext')]     satu baris sahaja
```

Jadual tetapan hanya memegang SATU alamat, ditanda `status='Ext'`. Tiada
lajur atau baris untuk alamat Internal, jadi nilai yang ditaip tidak
mempunyai tempat untuk disimpan. Ia hidup dalam keadaan skrin sehingga
skrin itu dilupuskan.

**Kesan:** medan Internal ialah tempat masuk yang mengesahkan dirinya
sendiri lalu membuang input. Sesiapa yang mengkonfigurasi peranti akan
mempercayai read-back itu.

**Keputusan pemilik:** rekod dan BERHENTI mengisinya semula. Jangan
tambah tulisan config kepada peranti production untuk mengejar nilai
yang app sendiri buang. Gerbang kekal menerima External + bukti DB.

**T-001 dikira LULUS** pada alamat yang app SEBENARNYA gunakan
(External, disahkan pada skrin dan dalam DB), dengan defek persistence
ini dilampirkan.

---

## Apa yang TIDAK terbukti tentang defek ini

- Sama ada kedua-duanya wujud pada **2.1.20** (build oracle). Kami tidak
  mempunyai 2.1.20 untuk dibandingkan — tiada APK MBPG pada mesin ini.
- Sama ada D-01 mempengaruhi modul Selaras yang lain. Hanya Alamat
  diperhati ranap; Pengguna dan Kompaun berjaya pada larian pertamanya.
- Sama ada Internal IP digunakan langsung oleh app pada mana-mana laluan
  rangkaian. Ia mungkin lohong tinggalan.

---

## D-07 — Nombor siri DIBAKAR bila borang dibuka, walaupun tiada serahan

**Keterukan:** sederhana-tinggi. Ia bukan kehilangan data, tetapi ia
**jurang audit**: penomboran rasmi berjurang tanpa apa-apa dalam sistem
yang menjelaskan jurang itu.

**Diperhati:** 2026-08-13, sepanjang Fasa C. Berulang, bukan sekali.

### Apa yang berlaku

Memandu borang Notis Amaran sampai peringkat gambar **memperuntukkan
nombor notis dan menaikkan kaunter siri** — walaupun borang itu tidak
pernah diserah, dibatalkan separuh jalan, atau prosesnya mati.

Kaunter `local_system_control.newserial` untuk
`local_ekpn_notis_amaran` bergerak **2 → 7** dalam satu hari, sedangkan
hanya **dua** notis benar-benar diserah.

### Bukti

Baris muncul dalam `local_ekpn_notis_amaran_details` dengan nombor
notis yang diperuntukkan, **tanpa** baris sepadan dalam jadual notis
induk:

| No. notis diperuntukkan | Rekod notis wujud? |
|---|---|
| `PGP02N260807001` | tidak |
| `PGP02N260812002` | tidak |
| `PGP02N260812003` | tidak |
| `PGP02N260812004` | tidak |
| `PGP02N260813005` | tidak |
| `PGP02N260813006` | **ya** — diserah |
| `PGP02N260813007` | **ya** — diserah |

Lima nombor diperuntukkan kepada borang yang tidak pernah menjadi
rekod. `PGP02N260813005` khususnya terhasil daripada satu proses yang
dibunuh had-masa alat semasa mengisi borang.

### Kenapa ini penting untuk PM

1. **Penomboran notis rasmi berjurang.** Sesiapa yang mengaudit
   turutan nombor akan menjumpai nombor hilang dan tiada rekod, tiada
   pembatalan, dan tiada catatan menjelaskannya.
2. **Baris yatim terkumpul** dalam `..._details` tanpa induk. Ia tidak
   kelihatan dalam mana-mana senarai app, jadi ia tidak boleh dilihat
   atau dibersihkan oleh pengguna.
3. Ia berlaku dalam **penggunaan biasa**, bukan hanya automasi:
   mana-mana penguatkuasa yang membuka borang, mengambil gambar,
   kemudian berpatah balik akan membakar satu nombor.

### Kesan pada ujian

Post-check yang hanya memerhati jadual rekod induk melaporkan "bersih"
sedangkan kaunter dan jadual `..._details` sudah bergerak. Senarai
jadual yang dipantau suite ini diluaskan daripada 3 kepada 15 kerana
ini; lihat `devtools/smoke_tangga.py::JADUAL_REKOD`.

### Apa yang TIDAK terbukti

- Titik **tepat** nombor diperuntukkan. Ia berlaku pada atau sebelum
  peringkat gambar; sama ada ia berlaku sebaik borang dibuka belum
  diasingkan.
- Sama ada borang **Kompaun Pelbagai** dan **Letak Kereta**
  berkelakuan sama. Kaunter kompaun bergerak 1 → 3 untuk dua kompaun
  yang diserah, yang **konsisten** dengan tiada pembaziran — tetapi
  tiada borang kompaun pernah dibatalkan separuh jalan untuk mengujinya.
- Sama ada nombor yang dibakar boleh dituntut semula oleh server.

---

## D-08 — Selaras Maklumat Kompaun (T-005) meranapkan app

**Keterukan:** rendah dalam praktik. Data yang sync ini muat turun sudah
wujud dan sudah disahkan sah, jadi kegagalannya tidak menghalang
mana-mana borang.

**Diperhati:** 2026-08-17 malam dan 2026-08-18 pagi — lima larian
berturut GAGAL, kemudian **LULUS** pada larian keenam (2026-08-18
10:30, 24.5s).

> **PEMBETULAN 2026-08-18.** Laporan awal saya menyatakan kegagalan
> ini *konsisten, bukan rawak*. Itu SALAH — ia berselang-seli. Lima
> kegagalan berturut membuatkan ia kelihatan tetap; larian keenam
> menunjukkan ia tidak. Sifat berselang-seli itu penting kerana ia
> mengubah apa yang boleh disimpulkan: ini BUKAN 'T-005 sentiasa
> ranap', tetapi 'T-005 kadang-kadang ranap' — dan puncanya kekal
> tidak diketahui.

### Apa yang berlaku

Menjalankan **Selaras Maklumat Kompaun** dari Menu Selaras (skrin
login) menyebabkan app tercampak keluar ke skrin utama Android:

```
AssertionError: [_scroll_down] App TERKELUAR dari latar hadapan
                (package semasa 'com.android.launcher...')
```

Lima modul Selaras yang lain — T-003, T-004, T-006, T-007, T-009 —
lulus pada larian yang SAMA. Hanya T-005 ranap.

### Hubungan dengan D-01

Gejalanya sama seperti D-01 (Selaras tidak idempotent → `Duplicate
entry` → app ranap), tetapi D-01 direkod untuk **Selaras Maklumat
Alamat**. Yang menarik: T-004 — modul yang D-01 sebenarnya
dokumenkan — **lulus setiap larian** pagi 2026-08-18 (126s).

Sama ada ini D-01 yang muncul pada modul lain, atau punca berasingan,
**TIDAK disiasat** — keputusan pemilik 2026-08-18: "abaikan, just noted
sebagai failed je".

### Kenapa kesannya rendah

Data yang T-005 muat turun ialah kod kompaun 3 tingkat. Ia sudah wujud
pada peranti dan sudah disahkan terhadap oracle:

| | |
|---|---|
| `local_ekpn_kod_kompaun` | 9 baris |
| `local_ekpn_akta` | 23 baris |
| `local_ekpn_kesalahan_kompaun` | 120 baris |

Kesemua 9 nilai dropdown untuk N-001, P-001 dan K-001 wujud, rantaian
T1→T2→T3 sah, dan kadar denda berada dalam julat min/max
(`tests_offline/test_dropdown_vs_production.py`).

### Apa yang TIDAK terbukti

- Sama ada toast `Duplicate entry` muncul (tidak ditangkap).
- Sama ada ia berlaku pada peranti yang BELUM disync.
- Sama ada ia wujud pada build 2.1.20.

---

## D-09 — mySIKAP: carian gagal senyap, dan identiti PEMILIK LAMA melekat

**Sumber:** pemeriksaan manusia (intern), dilaporkan lisan kepada pemilik
2026-08-18, butiran diterima 2026-08-18 malam. **Disahkan bebas** oleh
DB peranti — lihat bukti di bawah.

**Dua kelakuan, dan yang kedua jauh lebih serius:**

**(a) Butang mySIKAP berhenti berfungsi.** Selepas kira-kira 2 kompaun
letak kereta dicipta, memasukkan nombor kenderaan dan menekan mySIKAP
tidak memaparkan maklumat pemilik langsung.

**(b) Butiran pemilik TERDAHULU dipaparkan.** Selepas 3–4 kompaun,
borang menunjukkan pemilik kompaun sebelumnya untuk nombor kenderaan
yang BERBEZA.

(b) tidak menghasilkan mesej ralat. Ia menghasilkan kompaun yang sah
pada rupanya, membawa nama dan no. KP orang yang SALAH. Itu bukan
kegagalan UI; itu kompaun penguatkuasaan yang dikeluarkan terhadap warga
yang tidak berkaitan.

### Bukti dalam DB kita sendiri — sudah ada sejak 2026-08-13

```
PGP02K260813002   nokereta=JYX6605   namapesalah=JYX6605   <-- (a)
                  jeniskereta=''     warnakereta=''
PGP02K260818008   nokereta=JYX6605   namapesalah=<nama sebenar>
                  jeniskereta='TOYOTA COROLLA CROSS 1.8V A/T'
```

Pada rekod 2026-08-13, `namapesalah` **sama dengan nombor plat**. Carian
mySIKAP tidak memulangkan apa-apa, jadi nombor plat ditulis ke medan nama
pesalah dan rekod diserahkan begitu. Jenis dan warna kenderaan kosong —
ketiga-tiga medan itu diisi oleh respons mySIKAP yang sama.

Tanda tangan ini wujud dalam data kita selama lima hari tanpa disedari,
kerana tiada apa-apa yang membandingkan `namapesalah` dengan `nokereta`.

### Kesan pada rekod production

`PGP02K260818008` dicipta selepas beberapa kompaun K lain dalam sesi
yang sama. Di bawah (b), identiti yang dibawanya **mungkin bukan milik
JYX6605**. Ia tidak boleh diandaikan betul.

### Kenapa automasi melaporkan LULUS

Skrip mengesahkan medan **terisi**, bukan medan **betul**. Nama yang
melekat dari rekod terdahulu ialah nama yang sah pada setiap semakan
yang skrip buat. Tiada penegasan membandingkan identiti terhadap plat
yang dipohon.

### Semakan regresi untuk 2.1.23

Satu kompaun K TIDAK menguji ini. Perlu **4 kompaun K berturut-turut,
plat BERBEZA**, dan bandingkan `namapesalah` + `noakaun` merentas
keempat-empatnya:

- mana-mana `namapesalah == nokereta`  -> (a) masih ada
- mana-mana identiti berulang pada plat berbeza -> (b) masih ada

---

## D-10 — Tandatangan pada cetakan kompaun letak kereta

**Status: BUTIRAN TIDAK JELAS.** Laporan yang diterima berbunyi "The
printed kompaun letak kereta does show the signature", tetapi K-002
disenaraikan sebagai GAGAL. Kedua-duanya tidak boleh benar serentak.

Kemungkinan bacaan:
- tandatangan **tidak** dicetak sedangkan ia sepatutnya; atau
- tandatangan **dicetak** sedangkan ia tidak sepatutnya.

Tidak diandaikan mana-mana. Perlu pengesahan pemilik sebelum ia menjadi
rekod defek.

---

## D-11 — Kemaskini K: "Jenis Kereta" tidak dimuatkan semula ke borang

**Sumber:** pemeriksaan manusia, 2026-08-18.

Pada borang kemaskini kompaun letak kereta, medan **Jenis Kereta**
dipaparkan KOSONG walaupun rekod asal memilikinya. Pemeriksa terpaksa
memasukkannya semula.

**Tetapi:** apabila ia TIDAK dimasukkan semula dan kemaskini diserahkan,
cetakan dan Senarai Kompaun **tetap memaparkan Jenis Kereta**.

Jadi nilai itu tidak hilang — ia hanya tidak dimuatkan ke dalam kawalan
borang. Ini defek **paparan**, bukan kehilangan data. Perbezaan itu
penting: ia bermakna rekod sedia ada tidak rosak oleh kemaskini.

Risikonya berbeza: pemeriksa yang mengisi semula medan itu mungkin
memasukkan nilai yang BERBEZA daripada asal, dan itu akan ditulis.

### Berasingan daripada kegagalan automasi K-004

Automasi gagal K-004 dengan `SETERUSNYA MAHUPUN MENYERAHKAN tidak
dijumpai` — ia tidak sampai pun ke medan itu. Kedua-dua isu wujud dan
tidak sama.

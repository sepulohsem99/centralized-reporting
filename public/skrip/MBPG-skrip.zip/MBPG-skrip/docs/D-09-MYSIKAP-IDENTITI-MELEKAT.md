# D-09 — mySIKAP: carian gagal senyap / identiti pesalah melekat

**Status:** DISAHKAN — defek app (bukan bug skrip ujian). Kini dengan
pasangan rekod/plat/identiti TEPAT (lihat larian 2026-09-13 di bawah).
**Dijumpai/disahkan semula:** 2026-08-13 (port awal), 2026-09-10 (3 larian
langsung berasingan pada hari yang sama, gerbang automatik `semak_d09()`
menghalang setiap kali), 2026-09-13 (larian penuh `--borang NPK --bersih
--terus`, gerbang menghalang sekali lagi — kali ini dengan butiran
rekod/plat/identiti penuh yang sebelum ini tiada).
**Build:** MBPG 2.1.23 (2026-08/09-10), disahkan semula 2026-09-13 —
build tepat larian ini belum direkodkan berasingan daripada 2.1.23.
**Modul terjejas:** Daftar Kompaun Letak Kereta (borang K) — carian
mySIKAP ikut nombor plat kenderaan.

---

## Apa yang berlaku

Borang K memanggil mySIKAP untuk cari maklumat pemilik berdasarkan nombor
plat kenderaan. Dua cara ia gagal SENYAP (tiada ralat, borang kelihatan
sah sepenuhnya, kompaun boleh diserah):

**(a) Carian gagal, plat ditulis sebagai nama.** Apabila mySIKAP tidak
memulangkan apa-apa, app menulis nombor plat itu sendiri ke dalam medan
nama pesalah (`namapesalah == nokereta`). Bukti asal (2026-08-13),
`PGP02K260813002`: `namapesalah='JYX6605', jeniskereta='', warnakereta=''`.

**(b) Lebih serius — identiti MELEKAT dari rekod terdahulu.** Apabila dua
rekod K berturutan guna plat BERBEZA, kadangkala kedua-duanya membawa
IDENTITI PEMILIK YANG SAMA (nama/no. akaun) walaupun plat tidak sama.
Tiada ralat, kompaun kelihatan sah sepenuhnya — dan ia **menamakan orang
yang salah** pada notis kompaun rasmi.

Ini bukan spekulasi skrip: ia dikesan oleh gerbang automatik
`semak_mysikap.lapor()` (`tools/semak_mysikap.py`) yang membaca terus dari
DB peranti (`local_ekpn_tawaran_kompaun`) selepas setiap rekod K dicipta,
dan membandingkan identiti tersimpan MERENTAS rekod dengan plat yang
dipohon — bukan menyemak sama ada medan sekadar "terisi" (yang mana
identiti melekat itu sendiri turut LULUS).

---

## Bukti — larian langsung 2026-09-10

Tiga larian langsung berasingan pada hari yang sama, dengan run_penuh.py
`--borang NPK`, semuanya SILANG gerbang `semak_d09()`:

| Larian | Masa | Dapatan gerbang |
|---|---|---|
| #1 (`--bersih`) | pagi | "D-09 mySIKAP identiti melekat DISAHKAN (2/3 rekod K bawa identiti plat lain)" — halt selamat ikut reka bentuk |
| #3 (`--bersih --terus`) | 16:42 | `RuntimeError: D-09 MASIH ADA pada build ini - 1 dapatan merentas 6 rekod K` (forensik: `reports/forensik/20260910-164241-semak-D-09.txt`) |

Gerbang ini direka **tidak boleh gagal senyap**: ia hanya menguji tanda
(b) apabila larian benar-benar guna ≥2 plat BERBEZA yang sah
(`boleh_uji_b` dalam kod), jadi ia tidak boleh melaporkan "bersih" sebab
kebetulan semua rekod guna plat sama.

---

## Bukti — larian langsung 2026-09-13 (pasangan rekod/plat TEPAT)

`python tools\run_penuh.py --borang NPK --bersih --terus`, 96m 38s,
gerbang `semak_d09()` menghalang sekali lagi:
`RuntimeError: D-09 MASIH ADA pada build ini - 1 dapatan merentas 6 rekod
K` (forensik: `reports/forensik/20260913-220051-semak-D-09.txt`; nombor
rekod rasmi disahkan silang dengan
`reports/REKOD-SEBENAR-DICIPTA-2026-09-13.md`).

Tiga set K dicipta (cipta baru -> kemaskini, setiap set plat berbeza):

| Set | Plat | Rekod baru | Rekod hasil-kemaskini |
|---|---|---|---|
| K [1/3] | JYX6605 | `PGP02K260913003` | `PGP02K260913004` |
| K [2/3] | JUA3276 | `PGP02K260913005` | `PGP02K260913006` |
| K [3/3] | JRT2649 | `PGP02K260913007` | `PGP02K260913008` |

Dapatan tanda (b) daripada konsol larian ini: `PGP02K260913003` dan
`PGP02K260913004` (plat JYX6605) berkongsi SATU identiti tersembunyi
`93********05` dengan `PGP02K260913005` / `PGP02K260913006` (plat
JUA3276) — dua plat BERBEZA, satu identiti pemilik. Ini mengesahkan
tanda (b) dengan pasangan rekod TEPAT buat kali pertama (larian 9/10
hanya ada kiraan "1 dapatan merentas 6 rekod", bukan nombor rekod).
Set K [3/3] (JRT2649, `PGP02K260913007`/`008`) tidak disahkan terjejas
secara langsung dalam dapatan (b) di atas — **jangan anggap ia bersih**
semata-mata kerana tiada dalam senarai ini; log konsol penuh larian ini
belum disimpan ke fail (had yang sama seperti larian 9/10, lihat bawah),
jadi kedudukan set 3 berbanding gerbang tidak boleh disahkan semula
tanpa rerun atau capture log penuh.

---

## Apa yang TIDAK terbukti / belum disertakan di sini

* **Nombor rekod/plat tepat untuk larian #3 (2026-09-10).** MASIH tidak
  tersedia — had yang sama seperti sebelum ini (fail forensik hanya
  menyimpan mesej ralat akhir, bukan baris `[D-09b] ...` penuh). Ini
  KEKAL untuk larian 9/10 sahaja; larian **2026-09-13** di atas KINI ADA
  pasangan rekod/plat/identiti tepat, jadi caveat ini tidak lagi
  terpakai kepada larian terkini.
* **Sama ada set K [3/3] (JRT2649, larian 9/13) turut terjejas tanda
  (b).** Dapatan konsol yang ditangkap hanya menamakan set 1 & 2;
  status set 3 berbanding gerbang BELUM disahkan — rujuk PM cancel di
  bawah yang mengambil pendekatan berhemat (batalkan KESEMUA 3 set,
  bukan hanya yang disahkan).
* **Sama ada ia turut berlaku pada borang N/P** (Notis Amaran, Kompaun
  Pelbagai) — `semak_mysikap.py` sengaja skop kepada jadual
  `local_ekpn_tawaran_kompaun` (borang K sahaja); tidak disiasat untuk
  modul lain.
* **Punca tepat pada sisi app** (cache/state mySIKAP tidak dikosongkan
  antara carian, atau race condition pada respons API) — di luar
  keupayaan ujian kotak-hitam untuk tentukan; perlu akses log
  sisi-server/kod app.

---

## Kesan

Kompaun didaftar dengan nama/butiran pemilik yang SALAH pada plat yang
BETUL. Notis rasmi kemudiannya membawa identiti yang tidak sepadan
dengan kenderaan sebenar — risiko operasi (notis tersilap alamat) dan
risiko privasi (butiran pemilik lain terdedah pada rekod yang bukan
miliknya).

## Langkah seterusnya yang dicadangkan

1. Dev sisi app: siasat kenapa respons carian mySIKAP terdahulu boleh
   kekal/melekat pada carian plat seterusnya (cache tidak dikosongkan?
   race condition?).
2. PM: batalkan rekod K yang disahkan terjejas (senarai berasingan
   disediakan mengikut larian — lihat ORBIT `orchestrator.json`
   `run_e2e_mbpg_20260910`), dan sahkan semula secara manual sebelum
   sebarang notis rasmi dikeluarkan berdasarkan rekod tersebut.

   **Larian 2026-09-13 — VERDIK automasi sendiri:** "Batalkan
   kesemuanya. Jangan serahkan kepada penguatkuasaan." Senarai penuh
   (semua 6 rekod K larian ini, KESEMUA 3 set — bukan hanya set 1 & 2
   yang disahkan tanda (b), kerana status set 3 belum disahkan bersih):

   | No. rekod | Plat | Peranan |
   |---|---|---|
   | `PGP02K260913003` | JYX6605 | baru |
   | `PGP02K260913004` | JYX6605 | hasil-kemaskini |
   | `PGP02K260913005` | JUA3276 | baru |
   | `PGP02K260913006` | JUA3276 | hasil-kemaskini |
   | `PGP02K260913007` | JRT2649 | baru |
   | `PGP02K260913008` | JRT2649 | hasil-kemaskini |

   Rekod borang P/N larian yang sama (`PGP02P260913001/002`) TIDAK
   termasuk arahan batal ini — kegagalan pada borang P larian 9/13
   ialah Fix #5 (overlay "MENGHANTAR DATA" tidak dikesan skrip,
   bukan isu integriti data), data itu sendiri disahkan berjaya
   dicipta. Keputusan sama ada tetap membatalkannya demi kebersihan
   adalah budi bicara PM, bukan arahan gerbang automatik.
3. Ujian: sertakan tangkapan log konsol PENUH (bukan hanya forensik
   akhir) pada larian akan datang supaya baris `[D-09b] ...` boleh
   disemak terus tanpa perlu rerun.

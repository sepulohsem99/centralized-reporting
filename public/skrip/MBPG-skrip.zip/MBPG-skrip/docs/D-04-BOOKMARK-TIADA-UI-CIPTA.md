# D-04 — Build 2.1.21 tiada UI untuk MENCIPTA bookmark

**Dijumpai:** 2026-08-10, peringkat 6, MBPG-TC-N-005.
**Build:** 2.1.21. **Oracle:** ditulis untuk 2.1.20.
**Kategori:** beza-versi / ciri hilang — bukan kegagalan skrip.

## Bukti

Ikon buku (`U+E866`) pada tab NOTIS borang Notis Amaran ditemui dan
diketuk. Popup terbuka dan mengesahkan dirinya melalui tajuknya,
`PILIHAN KEGEMARAN`. Keseluruhan kandungan popup
(`ui_dumps/bookmark_name_field_missing.xml`):

```
✕        No bookmark found        [ HAPUS ]   [ PILIH ]
```

Tiada medan nama. Tiada butang SIMPAN. Sembilan `EditText` dalam dump
itu semuanya milik borang di BELAKANG modal, bukan di dalam popup —
disahkan dengan memeriksa nod di dalam `modal-surface`.

## Maksudnya

Popup Pilihan Kegemaran pada build ini ialah **pemilih sahaja**: ia
boleh MEMILIH bookmark sedia ada dan MENGHAPUS-nya. Tiada satu pun
affordance untuk MENCIPTA. Dengan senarai kosong ("No bookmark found"),
kedua-dua butang yang ada pun tidak mempunyai apa-apa untuk dikendalikan.

Sheet -005 memerlukan langkah "simpan bookmark". Langkah itu **tidak
boleh dilaksanakan pada build ini** — bukan gagal, tetapi tiada jalan.

## Kesan kepada TC

Keputusan pemilik 2026-08-10: dapatan N-005 diterima sebagai mewakili
ketiga-tiganya.

| TC | Status |
|---|---|
| MBPG-TC-N-005 | TIDAK BOLEH DILAKSANA PADA BUILD INI |
| MBPG-TC-P-005 | TIDAK BOLEH DILAKSANA PADA BUILD INI |
| MBPG-TC-K-005 | TIDAK BOLEH DILAKSANA PADA BUILD INI |

Ketiga-tiganya **bukan FAIL skrip**. Memburu ikon pada borang P dan K
dihentikan atas arahan pemilik.

## Sepadan dengan recon terdahulu

Recon MBIP 2.1.17 merekodkan bentuk popup yang sama (pemilih sahaja).
Jadi ini bukan regresi baharu pada 2.1.21 — ia jurang yang sudah lama
wujud antara apa yang oracle jangka dan apa yang build sediakan.

## Apa yang TIDAK terbukti

* Sama ada bookmark boleh dicipta melalui laluan LAIN — ikon berbeza,
  tekan-lama, menu, atau hanya selepas sekurang-kurangnya satu rekod
  wujud. Hanya popup Pilihan Kegemaran diperiksa.
* Sama ada 2.1.20 (build oracle) mempunyai UI cipta. Tiada APK 2.1.20
  pada mesin ini untuk dibandingkan.
* Sama ada butang PILIH/HAPUS berfungsi — senarai kosong, jadi tiada
  apa untuk diketuk. (SIMPAN dalam dialog bookmark kekal dibenarkan
  oleh corong sekiranya UI itu muncul pada build lain.)

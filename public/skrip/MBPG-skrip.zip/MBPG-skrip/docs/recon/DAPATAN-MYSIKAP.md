# DAPATAN — butang mySIKAP, tab PESALAH borang Letak Kereta

**Recon:** 2026-08-12, disahkan semula **2026-08-17**, MBPG production,
build 2.1.21, `devtools/recon_mysikap.py`
**Plat ujian:** plat rasmi pemilik, `testdata/oracle_pk.py`
**Dump mentah:** `docs/recon/mysikap-B-tab-pesalah.xml` / `.png` — **digitignore**
(ia membawa kandungan medan sebenar).

---

## 0. PENGESAHAN SEMULA 2026-08-17 — arahan pemilik

Pemilik mengarahkan recon diulang pada device SEBENAR untuk mengesahkan
mySIKAP wujud sebagai butang berasingan di sebelah ePBT. Recon dijalankan
semula pada hari itu. **Susun atur tidak berubah**, bait demi bait:

```
ViewGroup   klik=false  [105,1212][525,1332]   rid='button-container'
  Button    klik=true   [141,1212][489,1332]   desc='ePBT'   rid='button'
    TextView klik=false [256,1242][374,1302]   text='ePBT'   rid='button-text'
ViewGroup   klik=true   [555,1212][975,1332]   <- mySIKAP
  ImageView klik=false  [585,1230][945,1314]
```

Bukti larian: `docs/recon/mysikap-B-tab-pesalah.xml` + `.png` (2026-08-17).
Post-check bersih — **0 rekod dicipta**, kaunter siri tidak berubah
(`notis_amaran` 2, `tawaran_kompaun` 2, sama seperti baseline).
Corong: **15 tap dinilai, 0 disekat**. **ePBT TIDAK ditekan.**

### Nota sampingan yang layak direkod

Membuka borang Letak Kereta sehingga tab PESALAH **tidak** menaikkan
kaunter siri kompaun dalam larian ini. Itu berbeza daripada tingkah laku
borang Notis yang D-07 rakam (kaunter notis bergerak 2 → 7 tanpa
serahan). Satu larian bukan bukti muktamad, tetapi ia titik data pertama
untuk soalan yang D-07 tinggalkan terbuka: *"Sama ada borang Kompaun
Pelbagai dan Letak Kereta berkelakuan sama — belum diuji."*

### DAPATAN: locator dalam objek halaman MASIH SALAH pada 2026-08-17

Recon 2026-08-12 membetulkan `devtools/peringkat6._cari_mysikap()`.
Ia **tidak** membetulkan objek halaman. `DaftarKompaunPage` masih
membawa:

```python
BUTTON_MYSIKAP_IMAGE = ImageView.instance(0)      # ImageView PERTAMA pada skrin
```

dan `fill_pesalah_tab_trafik()` masih menggunakannya. Ia lulus setiap
kali kerana borang ini kebetulan mempunyai **tepat satu** ImageView —
disahkan pada empat dump berasingan. Tiada apa dalam locator itu yang
menyauhnya kepada mySIKAP; ia menyauh kepada nasib susun atur.

Dibetulkan 2026-08-17: locator dibuang, digantikan dengan
`cari_mysikap_dari_xml()` — fungsi TULEN, disauh pada ePBT secara
struktur, dikongsi oleh objek halaman DAN devtools supaya kedua-duanya
tidak boleh menyimpang. 28 ujian gerbang dalam
`tests_offline/test_mysikap_locator.py` menjalankannya terhadap setiap
dump borang dalam repo, termasuk satu dump yang barisnya beralih 111px
(`k001-siasat-02-selepas-kosong.xml`) — koordinat tetap akan lulus pada
lima dump dan menyesatkan pada yang keenam.

---

## 1. Butang itu MEMANG wujud — pemilik betul

Laporan awal saya ("hanya `content-desc="ePBT"` dijumpai") adalah
**salah**. Puncanya bukan butang itu tiada, tetapi saya mencari
mengikut NAMA, dan butang ini **tidak membawa nama langsung**.

Dua butang berkongsi satu baris, ePBT di **kiri**, mySIKAP di **kanan**:

```
Button     klik=true  [141,1212][489,1332]  desc='ePBT'  rid='button'
  TextView klik=false [256,1242][374,1302]  text='ePBT'  rid='button-text'
ViewGroup  klik=true  [555,1212][975,1332]  <- mySIKAP: TIADA text,
  ImageView klik=false [585,1230][945,1314]    TIADA desc, TIADA rid
```

Ia dirender sebagai **logo mySIKAP** (disahkan pada screenshot), jadi
tiada teks untuk dipadankan. Anak `ImageView`-nya melaporkan
`clickable="false"`; yang boleh ditekan ialah `ViewGroup` induk.

## 2. Locator

Tiada locator mengikut nama yang mungkin. Ia mesti disauh pada ePBT:

| Syarat | Nilai |
|---|---|
| kelas | `android.view.ViewGroup` |
| clickable | `true` |
| anak | mengandungi `ImageView` |
| baris-y | sama dengan butang ePBT (±80px) |
| kedudukan-x | bermula pada/selepas tepi **kanan** ePBT |

Dilaksanakan dalam `devtools/peringkat6.py::_cari_mysikap()`. Kalau
padanan bukan **tepat satu**, fungsi memulangkan `None` dan **tidak
meneka** — kerana tekaan yang salah pada baris ini bermakna menekan
ePBT.

## 3. Kenapa versi lama berbahaya

Versi sebelum ini memilih `ImageView` pertama yang sebaris dengan
ePBT, dan **kalau ePBT tidak dijumpai ia jatuh balik kepada `ImageView`
pertama pada seluruh skrin**. Kedua-dua cabang boleh memulangkan
kawalan yang bukan mySIKAP. Pada borang ini kesilapan itu bermakna
menekan **ePBT — yang pemilik amarkan MEMADAM data**.

## 4. Nota: plat dicerminkan (D-05)

Selepas mengisi No. Kereta, **tiga** medan identiti di atas butang
semuanya memaparkan plat yang sama:

```
EditText [108,639][978,789]    '<plat>'
EditText [108,825][978,975]    '<plat>'
EditText [108,1011][978,1161]  '<plat>'
```

Ini pencerminan yang sudah direkod dalam `docs/D-05-EPBT-DAN-CERMIN-PLAT.md`,
bukan dapatan baharu. Ia bermakna keputusan lookup mySIKAP mesti diukur
sebagai **beza sebelum/selepas**, bukan "medan tidak lagi kosong" —
medan itu sudah tidak kosong sebelum lookup bermula.

## 5. ePBT

**TIDAK DITEKAN** dalam recon ini. Amaran pemilik kekal: ePBT memadam
data, dan ePBT **bukan** mySIKAP.

---

## 6. Hasil lookup — LULUS, melalui TAP BIASA

Dijalankan `devtools/k001_mysikap.py` (plat dari oracle).

**Kaedah yang berkesan: tap biasa (`clickGesture`).** Tekan-tahan
dikodkan sebagai sandaran dan **tidak pernah diperlukan**. Rekod lama
yang menyatakan mySIKAP perlu tekan-tahan adalah **salah** dan sudah
dibetulkan.

Tujuh medan berubah dalam tempoh tunggu:

| # | Sebelum | Selepas (diredact) |
|---|---|---|
| 0 | plat (dicerminkan) | nama penuh, 28 aksara |
| 1 | plat (dicerminkan) | no. KP 12 digit |
| 4 | placeholder `Jenis Kereta` | alamat baris 1 |
| 5 | placeholder `Warna Kereta` | teks 21 aksara |
| 6 | placeholder `No. Petak` | poskod |
| 7 | placeholder `No. Kupon` | bandar |
| 8 | *(medan tidak wujud)* | negeri |

Post-check: **bersih, 0 rekod.** Corong: 15 tap dinilai, 0 disekat.

## 7. SOALAN TERBUKA — kenapa saya tidak memanggilnya defek

Medan 4–7 ialah medan **kenderaan dan petak**, tetapi selepas lookup ia
memegang komponen **alamat**. Dua tafsiran muat pada bukti yang ada:

1. lookup menulis alamat ke medan yang salah — **defek**, dan kompaun
   yang diserah selepas lookup akan membawa data karut dalam Jenis
   Kereta / Warna Kereta / No. Petak / No. Kupon; atau
2. app **menukar set medan** sebaik identiti diketahui — kelakuan betul,
   dan medan-medan itu bukan lagi medan kenderaan.

Saya tidak boleh memisahkan kedua-duanya daripada dump. Pada borang ini
**placeholder ialah satu-satunya label**, dan ia tersembunyi sebaik
medan berisi — jadi selepas lookup tiada apa pada skrin yang menyatakan
medan itu sepatutnya apa. Bounds hampir tidak berubah (±3px), yang
menyokong (1); tetapi satu medan **baharu** muncul (indeks 8), yang
menyokong (2).

Untuk memisahkannya perlu satu tindakan **mengubah**: kosongkan satu
medan dan lihat placeholder mana yang kembali. Tidak dibuat tanpa
kebenaran pemilik.

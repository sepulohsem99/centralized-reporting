# DAPATAN — aliran Notis → Kompaun (NK)

**Recon:** 2026-08-13, `devtools/recon_nk.py`. **BACA SAHAJA.**
Butang `[KOMPAUN]` **tidak ditekan**. Delta jadual: **tiada perubahan**.
Corong: 14 tap dinilai, 0 disekat.

## Laluan sehingga titik keputusan

```
Skrin utama
  └─ Notis Kompaun
       ├─ [TARIK NOTIS]            ViewGroup [66,324][1014,444]
       │    └─ dialog "TARIK NOTIS TAMAT TEMPOH"
       │         ID Penguatkuasa   EditText [205,956][875,1076]
       │         No Notis          EditText [205,1136][875,1256]
       │         Tarikh            ikon kalendar U+F073 [761,1325]
       │         [TARIK]           [183,1511][897,1631]
       │         [✕]               [852,764][942,854]
       └─ jadual hasil: No | No. Notis | Alamat  (+ pagination)
```

## Penemuan yang menentukan: NK hanya untuk notis TAMAT TEMPOH

Tajuk dialog ialah **`TARIK NOTIS TAMAT TEMPOH`**. Ia menarik notis
yang sudah **luput tempoh**, bukan semua notis.

Tarikan pada 2026-08-13 memulangkan **0 notis**, dan senarai kosong
bermakna tiada popup untuk dibuka.

Sebabnya bukan skrip. Kedua-dua notis kita:

| No. notis | Tarikh | Tempoh | Layak ditukar |
|---|---|---|---|
| `PGP02N260813006` | 2026-08-13 | 14 hari | **2026-08-27** |
| `PGP02N260813007` | 2026-08-13 | 14 hari | **2026-08-27** |

**NK tidak boleh diuji pada notis kita sebelum 2026-08-27.** Ini
sekatan app, bukan kekurangan skrip.

Nota: `local_ekpn_notis_to_kompaun` mengandungi 58 baris dalam DB
tetapi skrin memaparkan 0 — jadi senarai skrin **bukan** cerminan terus
jadual itu; ia hasil tarikan yang ditapis.

## Kenapa recon berhenti di popup notis

Page object sudah mengenali `BUTTON_NK_KOMPAUN` (teks `KOMPAUN`),
`BUTTON_NK_PATUH` (`PATUH`), dan `NK_FORM_TITLE` (`NOTIS TO KOMPAUN`).
Jadi butang `[KOMPAUN]` membuka borang penukaran.

Recon berhenti sebelum menekannya, dan sebabnya **khusus** — bukan
berhati-hati am. Dalam app ini, **membuka borang sudah terbukti
membakar nombor siri walaupun tiada rekod diserah**: kaunter notis
bergerak 2 → 7 pada 2026-08-13 semata-mata kerana borang dipandu
sampai peringkat gambar. Kalau borang penukaran berkelakuan sama,
membukanya membakar nombor **kompaun** — sedangkan `kuota_NK` kekal 0
dan pemilik menyatakan pelaksanaan NK perlukan kelulusan berasingan.

## Apa yang masih TIDAK DIKETAHUI

Segala-galanya di sebalik `[KOMPAUN]`: medan borang penukaran, sama ada
ia memperuntukkan nombor kompaun sebaik dibuka, butang serahnya, dan
teks dialog pengesahannya.

Peringkat `nk` dalam runner **mengatakan ini** dan bukan berpura-pura:
ia membangkit dengan sebab yang tepat, **sebelum** menggunakan kuota.

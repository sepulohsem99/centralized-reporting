# D-05 — Borang Letak Kereta: plat dicerminkan ke medan identiti, dan apa yang ePBT lakukan

**Diperhati:** 2026-08-10/11, MBPG-TC-K-001, build 2.1.21.
**Plat ujian:** `JYX6605` (dibekalkan pemilik, data oracle rasmi).
**Status:** pemerhatian berbukti + satu soalan terbuka untuk pemilik.

---

## 1. ePBT MEMANG melakukan lookup

Diperhati langsung (log `reports/log/k001epbt2.log`):

```
ePBT -> AUTO-ISI: ["[4] 'Jenis Kereta' -> 'TOYOTA COROLLA'"]
```

Selepas mengetuk ePBT sekali dengan `JYX6605` dalam borang, medan
**JENIS KERETA berubah dari placeholder kepada `TOYOTA COROLLA`**
dalam masa tunggu 45 saat. Pemilik betul: ePBT ialah kawalan lookup
pada MBPG.

Turut diperhati pada larian yang sama:

* **Plat TIDAK terpadam** oleh ePBT.
* **Nama Pesalah dan No K/P/SSM TIDAK diisi** oleh ePBT — tetapi lihat
  bahagian 2; ia sudah berisi sebelum tap, jadi ini BUKAN bukti bahawa
  ePBT gagal mengisinya.

Bukti: `reports/forensik/k001_sebelum_epbt.png/.xml`,
`k001_selepas_epbt.png/.xml`; ledger `epbt-tap` / `epbt-hasil`.

---

## 2. Menaip plat SEKALI mengisi TIGA medan

Ini yang menghalang eksperimen bersih yang pemilik minta.

Urutan pemilik (b) ialah "Isi No. Kereta = JYX6605 SAHAJA (jangan isi
nama/IC dulu)". Suite kini menyasarkan medan itu melalui
**placeholder-nya** (`EditText` yang `text`-nya `No. Kereta`) — bukan
melalui label atau indeks — supaya tiada kemungkinan tersasar ke medan
jiran. Satu `send_keys`, satu medan disasarkan.

Hasilnya, dibaca semula dari pokok skrin:

```
text=JYX6605           bounds=[108,639][978,789]      <- Nama Pesalah
text=JYX6605           bounds=[108,825][978,975]      <- No K/P/SSM
text=JYX6605           bounds=[108,1011][978,1161]    <- No. Kereta
text=No. Cukai Jalan   bounds=[105,1377][975,1527]
text=Jenis Kereta      bounds=[105,1560][975,1710]
...
```

Tiga **nod berasingan**, pada kedudukan berasingan, semuanya memegang
plat. Baki medan kekal pada placeholder masing-masing, jadi ini bukan
kerosakan bacaan menyeluruh.

**Tafsiran yang munasabah** (belum disahkan): borang Letak Kereta
mencerminkan plat ke medan identiti pesalah sebagai nilai sementara —
munasabah untuk kompaun letak kereta, di mana pesalah pada mulanya
hanya diketahui melalui platnya, sehingga lookup menggantikannya.

**Kenapa ia belum disahkan:** saya tidak dapat menolak sepenuhnya
kemungkinan artifak pemacu. Yang boleh saya katakan dengan pasti:
tiga nod berbeza, satu panggilan taip, 18 tap keseluruhan larian itu,
dan tiada taipan lain berlaku.

---

## 3. Kesan kepada urutan yang pemilik tetapkan

Gerbang prasyarat kini membatalkan eksperimen apabila plat berada
dalam lebih daripada satu medan:

```
prasyarat gagal: plat JYX6605 berada dalam 3 medan (sepatutnya TEPAT 1).
Eksperimen ePBT DIBATALKAN — keputusannya tidak akan bermakna.
```

Gerbang itu sengaja. Kalau nama dan IC sudah berisi sebelum ePBT
diketuk, maka "ePBT tidak mengisi nama" tidak boleh dibezakan daripada
"ePBT enggan menimpa medan berisi". Melaporkan yang pertama sedangkan
yang kedua yang benar ialah kesimpulan palsu tentang app.

**Soalan untuk pemilik:** kalau pencerminan itu memang kelakuan app,
prasyarat "TEPAT 1 medan" **tidak boleh dicapai** pada borang ini, dan
gerbang saya akan menyekat K-001 selama-lamanya. Pilihan:

| Pilihan | Maksud |
|---|---|
| (i) Longgarkan prasyarat kepada "plat ada dalam medan No. Kereta", teruskan tap ePBT | K-001 boleh disiapkan; had tafsirannya dinyatakan dalam laporan |
| (ii) Kosongkan Nama/IC secara manual dahulu, kemudian ePBT | Menguji ePBT pada medan kosong sebenar — tetapi mungkin app mengisinya semula |
| (iii) Terima dapatan bahagian 1 sebagai memadai | ePBT terbukti melakukan lookup; butiran medan mana kekal tidak terbukti |

Saya tidak memilih sendiri kerana pemilik yang menetapkan prasyarat
itu, dan pilihan (ii) melibatkan mengosongkan medan pada borang
production.

---

## Apa yang TIDAK terbukti

* Sama ada pencerminan tiga-medan itu kelakuan app atau artifak
  pemacu. Belum disahkan dengan pemerhatian manual pada peranti.
* Sama ada ePBT mengisi Nama Pesalah / No K/P/SSM apabila medan itu
  benar-benar kosong.
* Sama ada `TOYOTA COROLLA` sepadan dengan rekod JPJ sebenar untuk
  `JYX6605` — oracle tidak membekalkan jenis kenderaan yang dijangka
  untuk plat itu, jadi hanya "sesuatu telah diisi" yang terbukti,
  bukan "nilai yang betul telah diisi".
* Sama ada ePBT memadam medan berisi (amaran kod lama). Pada larian
  ini ia tidak memadam apa-apa — tetapi ia juga tidak mengisi medan
  yang sudah berisi, jadi laluan "timpa" tidak pernah dicuba.

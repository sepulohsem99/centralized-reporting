# D-06 — Baca-balik gagal pada kesalahan 148 (SEK 74)

> **Nota penomboran.** Pemilik merujuk isu ini sebagai "D-04" dalam
> keputusan 2026-08-12. D-04 sudah dipakai untuk *bookmark tiada UI
> cipta* (`D-04-BOOKMARK-TIADA-UI-CIPTA.md`), jadi ia direkod di sini
> sebagai **D-06** untuk mengelak dua isu berkongsi satu nombor.
> Rujukan pemilik "D-04 (kesalahan 148)" = dokumen ini.

**Status:** CALON ISU — **punca belum dicirikan** (arahan pemilik:
tidak perlu disiasat sekarang).
**Dijumpai:** 2026-08-12, sweep 284 set.
**Build:** 2.1.21.

---

## Apa yang berlaku

Empat daripada 284 set gagal. **Tiga** berkongsi kesalahan yang sama:

| Set | Borang | Kod kompaun |
|---|---|---|
| `SET-KK01-AKT2-148` | P | KK01 |
| `SET-KK05-AKT2-148` | P | KK05 |
| `SET-KK06-AKT2-148` | P | KK06 |

Kesalahan **148**, `SEK 74`, di bawah AKTA KERAJAAN TEMPATAN 1976.

Mesej dalam MATRIX:

```
tingkat3 gagal: 'KESALAHAN KOMPAUN': modal ditutup tetapi TIADA
pressable memaparkan 'MANA-MANA PEMUNYA, PENDUDUK ATAU PENYEWA
MANA-MANA RUMAH, BANGUNAN ATAU TANAH, SAMA ADA LAYAK DIDUDUKI…'
```

**Modal DITUTUP** — jadi baris itu dijumpai dan diketuk, dan pemilihan
nampaknya berlaku. Yang gagal ialah **baca-balik**: selepas modal
tertutup, tiada pressable pada borang yang memaparkan nilai itu.

Ketiga-tiganya disahkan **selepas borang dibina semula** (relaunch +
persediaan baharu), jadi ia bukan borang tersangkut.

---

## Hipotesis yang sudah DITOLAK

**"Teks terlalu panjang."** Salah. Kesalahan 148 ialah 320 aksara.
Kesalahan **111 ialah 434 aksara** — lebih panjang — dan ia LULUS
(ia set pathfinder, lulus berulang kali dengan baca-balik disahkan).

Panjang teks bukan pembeza. Puncanya khusus kepada kandungan 148.

Data DB untuk rujukan:

```
kod 148 | SEK 74 | 320 aksara | amounmin 100.0 | amounmax 1000.0
```

---

## Kegagalan keempat (berasingan)

`SET-KK03-AKTACT2026000024-OFF2026000032` pada borang K — akta dan
kesalahan berjana-ID (`ACT2026000024` / `OFF2026000032`), bukan kod
angka biasa. Gagal pada tingkat 3 dengan "modal dropdown tidak
terbuka". Mungkin kelas berbeza daripada 148; belum dicirikan.

---

## Apa yang TIDAK terbukti

* Sama ada nilai itu benar-benar TERSIMPAN pada borang walaupun
  baca-balik tidak menjumpainya. Modal ditutup, yang biasanya
  bermakna pemilihan diterima — tetapi kami tidak mengesahkannya
  melalui laluan lain.
* Sama ada puncanya pada aksara tertentu dalam teks 148, cara app
  memaparkannya (pemotongan?), atau padanan `descriptionContains`
  suite.
* Sama ada ia menjejaskan pegawai sebenar. Kalau nilai TERSIMPAN,
  kesannya sifar untuk pengguna dan ini hanya isu alat. Kalau ia
  TIDAK tersimpan, kompaun di bawah SEK 74 tidak boleh didaftarkan —
  itu jauh lebih serius. **Perbezaan itu belum ditentukan.**

## Langkah seterusnya yang dicadangkan (bila diarahkan)

1. Pilih satu set 148, pilih tingkat 3, kemudian dump `page_source`
   penuh dan periksa apa yang pressable SEBENARNYA papar.
2. Bandingkan dengan set 111 (lulus) pada titik yang sama.
3. Kalau app memaparkan teks terpotong, longgarkan baca-balik kepada
   padanan awalan berlabuh — bukan `contains` penuh.

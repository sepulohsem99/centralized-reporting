# Bukti demo Fasa C — 2026-08-12

Larian: `python devtools/demo_fasa_c.py` (set `SET-KK01-AKT2-111`).
Log penuh: `reports/log/demo_fasa_c2.log`.

Screenshot dan page source **tidak dijejaki git** (skrin production
penuh; lihat `.gitignore`). Ia ada pada cakera dalam direktori ini.

## Urutan yang dirakam

| # | Peringkat | Apa yang ditunjukkan |
|---|---|---|
| 01 | `skrin-utama` | selepas log masuk |
| 02 | `pesalah-diisi-tab-kompaun` | Pesalah diisi guna sauh alamat berposkod (elak D-03), tab Kompaun terbuka |
| 03 | `tiga-dropdown-dipilih` | kod → akta → kesalahan, ketiga-tiga baca-balik disahkan |
| 04 | `ringkasan-pra-serah` | apa yang AKAN diserah kalau Fasa C hidup |
| 05 | `gerbang-menyekat-sebelum-serah` | gerbang menolak pada titik serah |
| 06 | `back-out-skrin-utama` | keluar tanpa serah |

## Keputusan

```
kompaun_ok=YA  akta_ok=YA  kesalahan_ok=YA  denda='1000'

[DEMO] serah_mungkin=False -> berhenti di ringkasan, back out
[GERBANG] LAPISAN 1 GAGAL — MBPG_DRY_RUN bukan '0'.
          Mod dry-run masih aktif; tiada serah boleh berlaku.

post-check DEMO-FASA-C: bersih {notis:0, kompaun:0, sita:0}
CORONG: 31 tap dinilai, 0 disekat
```

Gerbang kekal `serah_mungkin=False` sebelum, semasa, dan selepas demo.
`reports/LEDGER-E2E.jsonl` kekal 0 bait.

# D-10 — Ralat "SILA PILIH KOMPAUN, AKTA DAN KESALAHAN" selepas
tutup popup CETAK pasca-KEMASKINI (borang N)

**Status:** CALON DEFEK — **punca belum disahkan** (black-box; tiada
akses kod sisi-app). Automasi berhenti SELAMAT ikut reka bentuk gerbang
dry-run (`guard/dasar.py` trip-wire OK) — bukan crash, bukan tap
tersasar.
**Dijumpai:** 2026-09-14, larian `run_penuh.py --borang NPK --bersih
--terus` (pemilik, pagi, mula ~09:49).
**Build:** MBPG 2.1.23.
**Modul terjejas:** Notis Amaran (borang N) — peringkat KEMASKINI
(kemaskini rekod sedia ada), selepas kemaskini BERJAYA.

---

## Apa yang berlaku

Ini kali PERTAMA KEMASKINI borang N pernah berjaya sampai peringkat
ini dalam sejarah larian suite ini (larian-larian terdahulu sentiasa
gagal lebih awal — printer tidak sedia, atau SETERUSNYA/MENYERAHKAN
tidak dijumpai).

Jujukan tepat:

1. KEMASKINI `PGP02N260914002` berjaya → rekod baharu
   `PGP02N260914003` (306.8s, disahkan LULUS).
2. App memaparkan modal React Native **"CETAK NOTIS AMARAN ?"** (No
   Notis: `PGP02N260914003`, butang CETAK + butang X merah) — **DI
   ATAS** skrin `KemaskiniNotisAmaran` yang **MASIH TERBUKA** di
   belakangnya (disahkan dari tangkapan skrin: borang edit — gambar,
   "Arahan Tindakan", "Maklumat Pegawai", "Nama Penerima" — kelihatan
   penuh di belakang popup).
3. Automasi menutup popup itu melalui **butang X merah** (ikut reka
   bentuk Fix #4, 13/9 — sengaja TIDAK tekan CETAK). Popup CETAK
   sendiri disahkan hilang.
4. **Serta-merta selepas itu**, satu alert NATIF Android muncul:
   `alertTitle="RALAT"`, `message="SILA PILIH KOMPAUN, AKTA DAN
   KESALAHAN"`, satu butang OK sahaja.
5. Gerbang dry-run (`guard/dasar.py`, trip-wire OK — kekal, tiada
   pengecualian dalam SEMUA mod) **menyekat** tap OK pada alert ini
   kerana teksnya TIDAK pernah disenaraikan sebagai dialog selamat.
   Run dibatalkan bersih (`DryRunViolation`), **0 tap dihantar ke
   peranti**.

---

## Bukti

* Tangkapan skrin:
  `reports/e2e-screenshots/N-001-03-selepas-kemaskini-20260914-100315.png`
  — popup CETAK di atas skrin `KemaskiniNotisAmaran` yang masih hidup.
* Forensik pelanggaran gerbang:
  `reports/forensik/20260914-100332__tiada__OK.{txt,xml,png}` dan
  `reports/forensik/20260914-100332-borang-N.txt` (traceback penuh).
* Dump XML pada masa pelanggaran mengesahkan alert NATIF (bukan modal
  RN) — satu `android.widget.TextView` `alertTitle="RALAT"`, satu
  `android:id/message` bertulis `"SILA PILIH KOMPAUN, AKTA DAN
  KESALAHAN"`, satu `android:id/button1` bertulis `"OK"`.

---

## Siasatan kod dilakukan (14/9, TANPA ubah kod)

Dibaca penuh: `devtools/smoke_tangga.py:pastikan_di_home()`,
`pages/cetak_page.py:tutup_popup_cetak()`,
`pages/home_page.py:is_home_screen_displayed()`/
`dismiss_native_alerts()`, dan seluruh `pages/kemaskini_page.py`.

Dapatan:

1. `tutup_popup_cetak()` **hanya** tap elemen X, kemudian sahkan popup
   CETAK itu sendiri hilang. Ia **tidak** tekan back, **tidak**
   navigasi, **tidak** semak skrin di belakangnya.
2. `dismiss_native_alerts()` (dipanggil serta-merta selepas oleh
   `is_home_screen_displayed()`) **hanya** bertindak balas pada alert
   yang **sudah wujud** — ia tidak boleh menyebabkan alert baharu
   muncul. Jadi alert RALAT mesti sudah ada di skrin sebaik sahaja
   tap-X pada popup CETAK selesai.
3. `kemaskini_page.py` (seluruh fail, termasuk `proceed_and_submit()`)
   **langsung tidak menyentuh/memilih semula** dropdown Kompaun/Akta/
   Kesalahan — KEMASKINI hanya mengedit medan "keterangan" pada SATU
   skrin ringkas (`KemaskiniNotisAmaran`), bukan borang bertab penuh
   (Pesalah/Notis/Penerima) yang dipakai semasa CIPTA asal. Skrin
   `KemaskiniNotisAmaran` itu sendiri (kelihatan dalam tangkapan skrin,
   di belakang popup CETAK) **tidak memaparkan** sebarang medan
   Kompaun/Akta/Kesalahan pun.

---

## Hipotesis (BELUM disahkan 100%)

Tindakan tap-X pada modal "CETAK NOTIS AMARAN ?" — dalam konteks
skrin `KemaskiniNotisAmaran` — nampaknya mencetuskan satu laluan
pengesahan/hantar-semula **dalaman aplikasi** (bukan skrip ujian) yang
menyemak medan Kompaun/Akta/Kesalahan borang, medan yang skrin
KEMASKINI ini sendiri tidak pun paparkan atau sentuh, dan mendapatinya
kosong dalam konteks ini.

Ini kelihatan seperti **defek sisi app**: butang X pada popup CETAK
tersalah-wayar kepada satu laluan submit/validate, bukan dismiss
tulen — pada konteks skrin KEMASKINI khususnya (belum pernah dilihat
pada P/K kerana KEMASKINI P/K tidak pernah sampai sejauh ini dalam
larian terdahulu).

**Had siasatan:** ini ujian kotak-hitam — tiada akses kod sumber
sisi-app. Hipotesis di atas TIDAK dapat disahkan 100% tanpa (a) akses
kod/log sisi-server-app, atau (b) replika manual berulang di peranti.

---

## Apa yang TIDAK terbukti

* Sama ada rekod `PGP02N260914003` (hasil KEMASKINI) sendiri
  **tersimpan dengan betul** di backend walaupun alert ini muncul
  selepas itu — KEMASKINI itu sendiri dilaporkan LULUS SEBELUM popup
  CETAK/RALAT muncul, tetapi tiada pengesahan bebas (cth. baca balik
  dari Senarai) dilakukan selepas jujukan penuh ini.
* Sama ada gejala ini konsisten/berulang pada setiap KEMASKINI+CETAK,
  atau ia sekali sahaja (race condition bergantung masa). Baru SATU
  pemerhatian setakat ini — ini kali pertama KEMASKINI N sampai
  peringkat ini.
* Sama ada ia turut berlaku pada borang P/K (KEMASKINI P/K pada
  larian-larian lalu tidak pernah sampai peringkat popup CETAK ini —
  selalu tersekat lebih awal oleh symptom SK-001 yang kini dibaiki
  Fix #5, jadi belum ada peluang uji).
* Punca tepat pada sisi app (di luar keupayaan ujian kotak-hitam untuk
  tentukan tanpa akses kod/log sisi-app).

---

## Kesan

Kalau hipotesis (defek app) betul: mana-mana pegawai yang KEMASKINI
Notis Amaran di peranti sebenar (bukan mod dry-run) dan menutup popup
CETAK melalui X akan tersekat pada alert RALAT palsu ini — walaupun
kemaskini sebenarnya sudah BERJAYA. Ini boleh mengelirukan pegawai
(fikir kemaskini gagal, cuba lagi / abai notis) walaupun rekod sudah
kemas kini di backend.

## Langkah seterusnya yang dicadangkan

1. **Dev sisi app:** siasat pengendali (handler) butang X pada modal
   "CETAK [JENIS] ?" — khususnya dalam konteks skrin KEMASKINI —
   pastikan ia HANYA dismiss popup, tidak mencetuskan semula
   validasi/submit borang di belakangnya.
2. **Pemilik (bila sesuai):** replika manual di peranti — KEMASKINI
   Notis Amaran → bila popup CETAK muncul → tutup guna X → perhatikan
   sama ada RALAT sama muncul. Ini satu-satunya cara sahkan
   konsistensi/punca tanpa akses kod app.
3. **Ujian:** apabila KEMASKINI P/K (sekali gus Fix #5 menghalang
   symptom SK-001) akhirnya sampai peringkat popup CETAK yang sama,
   rekod sama ada gejala ini turut berlaku di sana.
4. **Skrip (tidak dicadangkan buat masa ini):** jika disahkan defek
   app tulen (bukan boleh dibetulkan dari sisi app dengan segera),
   satu mitigasi skrip yang mungkin ialah menavigasi keluar dari skrin
   KEMASKINI (cth. BACK eksplisit) SEBELUM menutup popup CETAK,
   bukannya tutup popup dahulu. Ini BELUM dicadang sebagai fix —
   perlu kelulusan pemilik dan bukti lanjut dahulu, ikut amalan sedia
   ada projek ini.

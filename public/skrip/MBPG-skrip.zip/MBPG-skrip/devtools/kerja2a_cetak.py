"""
KERJA 2A (cetak) — tekan CETAK pada popup kejayaan PGP02N260813006.

SATU percubaan. Tiada cuba-semula: setiap ketukan CETAK yang berjaya
mengeluarkan sehelai kertas, dan gelung yang tidak dapat membezakan
"tidak dihantar" daripada "dihantar tetapi respons tidak dibaca" akan
mengeluarkan salinan bertindan.

Popup kejayaan mesti SUDAH terbuka. Skrip ini melekat pada sesi app
yang sedia ada (create_driver, BUKAN peringkat_2 yang me-relaunch) —
relaunch akan memusnahkan popup dan bersamanya satu-satunya laluan
cetak yang diketahui.

    python devtools/kerja2a_cetak.py
"""

import os
import sys
import time
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
AKAR = os.path.dirname(HERE)
sys.path.insert(0, AKAR)

from devtools import fasa_c as FC                              # noqa: E402
from guard.gerbang_serah import Izin, diagnosis, semak         # noqa: E402

NO_REKOD = "PGP02N260813006"
SET_ID = "C1-N-001"
DIR_BUKTI = os.path.join(AKAR, "docs", "demo-fasa-c", "kerja2a")
DOK = os.path.join(AKAR, "docs", "FASA-C-REKOD.md")


def bukti(drv, tag):
    os.makedirs(DIR_BUKTI, exist_ok=True)
    asas = os.path.join(DIR_BUKTI, tag)
    try:
        drv.get_screenshot_as_file(asas + ".png")
    except Exception:                                           # noqa: BLE001
        pass
    try:
        with open(asas + ".xml", "w", encoding="utf-8") as fh:
            fh.write(drv.page_source)
    except Exception:                                           # noqa: BLE001
        pass
    print(f"    [BUKTI] {tag}")


def main():
    from tests.conftest import create_driver
    from pages.cetak_page import CetakPage, PrinterTidakSedia
    from guard.dasar import PermitSerah

    print("=" * 70)
    print(f"== KERJA 2A (cetak) — {NO_REKOD}")
    print("== SATU percubaan. Tiada cuba-semula.")
    print("=" * 70)

    izin = Izin.dari_persekitaran(AKAR)
    d = diagnosis(izin)
    print(f"  serah_mungkin = {d['serah_mungkin']}")
    if not d["serah_mungkin"]:
        print("HENTI: gerbang tertutup.")
        return 1
    # Gerbang dinilai untuk rekod yang SAMA. Cetakan berada dalam skop
    # kebenaran yang sama seperti serahnya.
    semak(izin, SET_ID, 0, borang="N", kiraan_borang=0)

    drv = create_driver()
    hasil = None
    try:
        cetak = CetakPage(drv)

        terbuka, pada_popup = cetak.popup_cetak_terbuka(NO_REKOD)
        if not terbuka:
            print("\nHENTI: popup cetak TIDAK terbuka. Laluan Senarai "
                  "belum diport — tidak improvise, seperti diarahkan.")
            bukti(drv, "05-popup-HILANG")
            return 1
        print(f"  popup terbuka, rekod pada popup = {pada_popup!r}")
        bukti(drv, "05-popup-cetak")

        # Printer disahkan SEBELUM menekan. Kalau ia tidak sedia,
        # ketukan hanya membuang popup tanpa kertas keluar.
        st = cetak.baca_status_printer()
        print(f"  status printer dari popup semasa: bluetooth="
              f"{st['bluetooth']} tersambung={st['tersambung']}")

        # CETAK ialah trip-wire. Permit berskop, had 1, ditanggalkan
        # dalam finally.
        tetapan = drv.corong.tetapan
        tetapan.permit_serah = PermitSerah(SET_ID, had=1)
        try:
            hasil = cetak.cetak_dari_popup(NO_REKOD)
        finally:
            tetapan.permit_serah = None
            print("  [CETAK] permit DITANGGALKAN")

        time.sleep(2)
        bukti(drv, "06-selepas-cetak")

        FC.catat_ledger({
            "peristiwa": "cetak-dicuba", "set_id": SET_ID,
            "no_rekod": NO_REKOD, "percubaan": 1,
            "popup_tutup": hasil["popup_tutup"],
            "teks_baharu": hasil["teks_baharu"],
            "printer": st.get("nama"),
            "catatan": "satu percubaan sahaja; pengesahan fizikal oleh "
                       "pemilik",
        })

        print("\n" + "=" * 70)
        print("== CETAK DIHANTAR — menunggu pengesahan mata manusia")
        print("=" * 70)
        print(f"  rekod         : {NO_REKOD}")
        print(f"  printer       : {st.get('nama')}")
        print(f"  popup tertutup: {hasil['popup_tutup']}")
        print(f"  teks baharu   : {hasil['teks_baharu'] or '(tiada)'}")
        print(f"  skrin selepas : {hasil['teks_selepas'][:8]}")
        return 0
    except BaseException as e:                                  # noqa: BLE001
        print(f"\n{'!' * 70}\n!! BERHENTI — {type(e).__name__}\n{'!' * 70}")
        print(str(e)[:2000])
        if not isinstance(e, PrinterTidakSedia):
            traceback.print_exc()
        try:
            bukti(drv, "06-cetak-ABORT")
        except Exception:                                       # noqa: BLE001
            pass
        FC.catat_ledger({"peristiwa": "cetak-gagal", "set_id": SET_ID,
                         "no_rekod": NO_REKOD,
                         "punca": f"{type(e).__name__}: "
                                  f"{str(e).splitlines()[0][:200]}"})
        return 1
    finally:
        c = getattr(drv, "corong", None)
        if c is not None:
            print(f"\n  [CORONG] {c.bil_tap} tap dinilai, "
                  f"{c.bil_sekat} disekat")
        try:
            drv.quit()
        except Exception:                                       # noqa: BLE001
            pass


if __name__ == "__main__":
    sys.exit(main())

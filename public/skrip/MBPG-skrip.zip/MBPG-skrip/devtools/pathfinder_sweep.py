"""
PATHFINDER SWEEP — SATU set sebenar melalui laluan sweep SEBENAR.

Tujuannya bukan menguji kombinasi itu. Tujuannya menjawab tiga soalan
yang mesti dijawab SEBELUM 284 set dilepaskan pada peranti production:

  1. Adakah laluan sweep semasa — sedia_borang_kompaun() lompat terus
     ke dropdown TANPA mengisi tab Pesalah — benar-benar berfungsi?
  2. Kalau app menyekatnya, adakah laluan sandaran (isi Pesalah
     minimum dengan sauh alamat berposkod) berfungsi?
  3. Berapa lama SATU set mengambil masa, diukur — bukan dianggar?

Kenapa ini penting: kalau (1) disekat dan kami melepaskan 284 set pada
laluan itu, sweep akan gagal 284 kali atas SATU sebab, dan 284
kegagalan itu akan kelihatan seperti 284 dapatan berasingan dalam
matrix. Satu larian di sini menghapuskan risiko itu.

Set dipilih dari testdata/sets — data production sebenar, bukan
fixture. TANPA Serah. Post-check selepas borang.

    set MBPG_IZIN_PRODUCTION=1
    python devtools/pathfinder_sweep.py [--set SET-ID]
"""

import argparse
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
AKAR = os.path.dirname(HERE)
sys.path.insert(0, AKAR)

from guard.dasar import DryRunViolation                       # noqa: E402
from devtools import peringkat6 as P6                         # noqa: E402


def pilih_set(set_id=None):
    """Satu set P yang BOLEH_GUNA. Deterministik: yang pertama mengikut
    isihan set_id, supaya larian berulang menguji perkara yang sama."""
    from testdata import sets_loader as SL
    semua = SL.tapis(SL.muat_semua(), borang=("P",))
    boleh = sorted((s for s in semua if s["jangkaan"] == "BOLEH_GUNA"),
                   key=lambda s: s["set_id"])
    if set_id:
        padan = [s for s in boleh if s["set_id"] == set_id]
        if not padan:
            raise SystemExit(f"set {set_id} tiada dalam senarai BOLEH_GUNA P")
        return padan[0], len(boleh)
    return boleh[0], len(boleh)


def laluan_a_lompat_terus(drv, pages):
    """Buka borang P dan pergi terus ke tab KOMPAUN. TIADA Pesalah.

    Ini laluan yang sweep GUNA hari ini kalau tiada apa berubah.
    Pulangkan (berjaya, nota).
    """
    from devtools.smoke_tangga import pastikan_di_home
    p = pages.daftar_kompaun
    if not pastikan_di_home(drv, pages):
        return False, "tidak sampai ke skrin utama"
    pages.home.open_daftar_kompaun()
    p.select_jenis_kompaun("Kompaun Pelbagai")
    try:
        p.wait_and_tap(p.TAB_KOMPAUN)
        time.sleep(2)
    except Exception as e:                                    # noqa: BLE001
        return False, f"tab KOMPAUN tidak boleh diketuk: {type(e).__name__}"

    sumber = p.driver.page_source
    ditolak = "Maklumat Tidak Lengkap" in sumber
    sampai = "KETERANGAN KOD KOMPAUN" in sumber
    if ditolak:
        return False, ("app menolak: 'Maklumat Tidak Lengkap' — gerbang "
                       "urutan tab dikuatkuasakan")
    if not sampai:
        return False, "tab KOMPAUN tidak terbuka dan TIADA alert"
    return True, "tab KOMPAUN dicapai tanpa mengisi Pesalah"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--set", dest="set_id", default=None)
    a = ap.parse_args()

    from device_utils import resolve_udid
    from config import APP_PACKAGE
    from devtools.smoke_tangga import peringkat_1, peringkat_2

    s, jumlah_boleh = pilih_set(a.set_id)
    serial = resolve_udid(APP_PACKAGE, verbose=False)

    print("=" * 70)
    print("== PATHFINDER SWEEP — SATU set, laluan sweep sebenar")
    print("=" * 70)
    print(f"  set     : {s['set_id']}  ({s['jangkaan']})")
    print(f"  tingkat1: {s['kod_kompaun']['nama']}")
    print(f"  tingkat2: {s['akta']['nama']}")
    print(f"  tingkat3: [{s['kesalahan']['kod']}] "
          f"{s['kesalahan']['keterangan'][:60]}...")
    print(f"  kolam   : {jumlah_boleh} set P BOLEH_GUNA")
    print("  SWEEP 284 PENUH TIDAK DIJALANKAN — ini satu set sahaja.")

    p1 = peringkat_1(serial)
    if not p1["ok"]:
        print("\nHENTI: gerbang peranti gagal.")
        return 1
    baseline = p1["baseline"]
    P6.baseline_global = baseline

    drv = pages = None
    hasil = {}
    try:
        t_login = time.time()
        drv, pages = peringkat_2()
        hasil["login_s"] = time.time() - t_login

        # ---- SOALAN 1: lompat terus ----
        print("\n-- LALUAN A: lompat terus ke dropdown (tanpa Pesalah) --")
        t_a = time.time()
        ok_a, nota_a = laluan_a_lompat_terus(drv, pages)
        hasil["laluan_a"] = ok_a
        hasil["laluan_a_nota"] = nota_a
        hasil["laluan_a_s"] = time.time() - t_a
        print(f"  [A] {'BERJAYA' if ok_a else 'DISEKAT'} — {nota_a}")
        P6._simpan_bukti(pages.daftar_kompaun, "pathfinder_laluan_a")
        P6._keluar_ke_home(pages, "pathfinder-A")

        # ---- SOALAN 2: sandaran (isi Pesalah minimum) ----
        laluan_guna = "A (lompat terus)"
        t_sedia = t_dropdown = 0.0
        if not ok_a:
            print("\n-- LALUAN B: isi Pesalah minimum -> dropdown --")
            laluan_guna = "B (isi Pesalah minimum)"
            from tests.sweep_kongsi import sedia_borang_kompaun
            from devtools.smoke_tangga import pastikan_di_home
            P6.relaunch(drv, pages, "pathfinder B: borang bersih")
            if not pastikan_di_home(drv, pages):
                print("\nHENTI: tidak sampai ke skrin utama.")
                return 1
            t0 = time.time()
            sedia_borang_kompaun(pages, "Kompaun Pelbagai")
            t_sedia = time.time() - t0
            print(f"  [B] persediaan (Pesalah + tab Kompaun): {t_sedia:.0f}s")
        else:
            from tests.sweep_kongsi import sedia_borang_kompaun
            sedia_borang_kompaun(pages, "Kompaun Pelbagai")

        # ---- SOALAN 3: satu set melalui BADAN SWEEP SEBENAR ----
        print(f"\n-- SET {s['set_id']} melalui sapu_satu_set() --")
        from pages.sweep_kombo import sapu_satu_set
        t0 = time.time()
        kep = sapu_satu_set(pages.daftar_kompaun, s, "P")
        t_dropdown = time.time() - t0
        hasil["set_s"] = t_dropdown
        print(f"  set selesai dalam {t_dropdown:.0f}s")
        for medan in ("kompaun_ok", "akta_ok", "kesalahan_ok", "denda",
                      "catatan"):
            print(f"    {medan:14}: {getattr(kep, medan, '')!r}")
        tiga_ok = all(getattr(kep, m, "") == "YA" for m in
                      ("kompaun_ok", "akta_ok", "kesalahan_ok"))
        hasil["set_ok"] = tiga_ok

        # ---- BACK OUT + post-check ----
        print("\n-- BACK OUT tanpa Serah + post-check --")
        P6._keluar_ke_home(pages, "pathfinder")
        bersih = P6.post_check(serial, baseline, "PATHFINDER")
        if not bersih:
            return 1

        # ---- unjuran ----
        print("\n" + "=" * 70)
        print("== KEPUTUSAN PATHFINDER")
        print("=" * 70)
        print(f"  Laluan berjaya    : {laluan_guna}")
        print(f"  Laluan A          : "
              f"{'BERJAYA' if ok_a else 'DISEKAT'} — {nota_a}")
        if t_sedia:
            print(f"  Persediaan (1x)   : {t_sedia:.0f}s")
        print(f"  SATU set          : {t_dropdown:.0f}s")

        # Unjuran: persediaan dibayar SEKALI (borang kekal terbuka
        # merentas set), kos marginal = masa set.
        for n in (284, jumlah_boleh):
            jam = (t_sedia + n * t_dropdown) / 3600.0
            print(f"  Unjuran {n:3d} set   : {jam:.1f} jam berterusan")
        print("\n  Unjuran mengandaikan borang kekal terbuka merentas set")
        print("  dan TIADA kegagalan/pemulihan. Larian sebenar akan lebih")
        print("  lama: setiap relaunch pemulihan menambah login penuh.")
        print("\n  SWEEP 284 PENUH MASIH BELUM DILULUSKAN.")
        return 0
    except DryRunViolation:
        raise
    finally:
        if drv is not None:
            c = getattr(drv, "corong", None)
            if c is not None:
                print(f"\n  [CORONG] {c.bil_tap} tap dinilai, "
                      f"{c.bil_sekat} disekat"
                      + (f" | DIBATALKAN: {c.dibatalkan}"
                         if c.dibatalkan else ""))
            try:
                drv.quit()
            except Exception:                                 # noqa: BLE001
                pass


if __name__ == "__main__":
    sys.exit(main())

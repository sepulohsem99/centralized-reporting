"""
PERINGKAT 6 — luaskan skop melepasi N-001.

Berbeza daripada peringkat 1-5, peringkat ini TIDAK berhenti pada
kegagalan TC biasa. Setiap TC direkod dan yang seterusnya diteruskan
(arahan pemilik 2026-08-10: "TANPA HENTI antara TC — berhenti hanya pada
kegagalan yang perlukan keputusan pemilik").

Dua perkara SAHAJA menembusi dan membatalkan run:
  * DryRunViolation  — corong menyekat tap; sesuatu cuba menghantar.
  * RestoreGagal     — tetapan production ditinggalkan terubah.
Kedua-duanya BaseException supaya `except Exception` di sini tidak
menelannya.

Post-check senarai dijalankan selepas SETIAP borang. Post-check yang
gagal MENGHENTIKAN segalanya — itu bermakna rekod mungkin wujud.
"""

import os
import time

from guard.dasar import DryRunViolation


class RestoreGagal(BaseException):
    """Tetapan production diubah dan TIDAK berjaya dipulangkan.

    BaseException, bukan Exception: meninggalkan peranti penguatkuasa
    dengan tetapan ujian ialah kerosakan sebenar, dan ia tidak boleh
    hilang di dalam `except Exception` mana-mana pemanggil.
    """


HASIL = []


def rekod(tc, status, nota=""):
    HASIL.append({"tc": tc, "status": status, "nota": nota})
    tanda = {"PASS": "OK   ", "FAIL": "GAGAL", "SKIP": "SKIP ",
             "BLOK": "BLOK "}.get(status, status)
    print(f"  [{tanda}] {tc}" + (f" — {nota}" if nota else ""))


def post_check(serial, baseline, tc):
    """Tiada rekod baharu, kaunter siri tidak bergerak. False = HENTI."""
    from devtools.smoke_tangga import tarik_db, keadaan_rekod, AKAR
    tag = tc.replace("-", "").replace(" ", "")[:24]
    try:
        db = tarik_db(serial, os.path.join(AKAR, "data", "tmp",
                                           f"pc_{tag}.db"))
        kira, siri = keadaan_rekod(db)
    except Exception as e:                                    # noqa: BLE001
        rekod(f"post-check {tc}", "FAIL", f"DB tidak boleh dibaca: {e}")
        return True
    k0, s0 = baseline
    if kira == k0 and siri == s0:
        print(f"         post-check {tc}: bersih {kira}")
        return True
    print(f"\nHENTI: post-check {tc} GAGAL — rekod mungkin tercipta.")
    print(f"  kiraan  : {kira}   (baseline {k0})")
    print(f"  kaunter : {siri}   (baseline {s0})")
    print("  JANGAN sentuh apa-apa lagi pada peranti. Lapor pemilik.")
    return False


def _catat_ledger(drv, peristiwa, butiran):
    """Tulis peristiwa bukan-tap ke ledger yang sama.

    Relaunch ialah campur tangan pada peranti production. Ia mesti
    kelihatan dalam bukti utama bersama setiap tap, bukan hanya dalam
    log cetakan yang boleh hilang — arahan pemilik 2026-08-10.
    """
    c = getattr(drv, "corong", None)
    if c is None:
        return
    try:
        import json as _json
        import time as _time
        with open(c.laluan_ledger, "a", encoding="utf-8") as fh:
            fh.write(_json.dumps({
                "masa": _time.strftime("%Y-%m-%dT%H:%M:%S"),
                "tc": getattr(c, "tc_semasa", None),
                "asal": "peristiwa",
                "peristiwa": peristiwa,
                "butiran": butiran,
            }, ensure_ascii=False) + "\n")
    except OSError:
        pass


def ada_draf(pages):
    """Adakah borang memegang draf dari larian terdahulu?

    Bukti = placeholder medan Pesalah SUDAH HILANG sedangkan kami belum
    menaip apa-apa dalam sesi ini. Itu tepat keadaan yang menolak
    isian ke laluan fallback-dan-skrol, dan skrol pada borang ini
    mencuba TUKAR TAB, yang app tolak dengan 'Maklumat Tidak Lengkap'.
    """
    from appium.webdriver.common.appiumby import AppiumBy
    na = pages.notis_amaran
    try:
        el = na.find_element(
            (AppiumBy.ANDROID_UIAUTOMATOR,
             'new UiSelector().className("android.widget.EditText")'
             '.instance(0)'), timeout=6)
        kosong, semasa = na._medan_kosong(el)
        if not kosong:
            print(f"  [RECOVERY] draf dikesan: medan pertama = {semasa!r}")
        return not kosong
    except Exception:                                         # noqa: BLE001
        # Tidak dapat membaca bukan bermakna bersih. Fail-selamat ke
        # arah memulihkan: relaunch tidak merosakkan apa-apa, manakala
        # meneruskan pada borang kotor merosakkan TC seterusnya.
        return True


def relaunch(drv, pages, sebab):
    """Laluan recovery RASMI (diluluskan pemilik 2026-08-10).

    terminate + activate, kemudian SAHKAN skrin utama bersih. Bukan
    force-stop dan bukan pemasangan semula: pakej tidak disentuh.
    Setiap relaunch dicatat dalam ledger.
    """
    from config import APP_PACKAGE
    print(f"  [RECOVERY] relaunch app — sebab: {sebab}")
    _catat_ledger(drv, "relaunch-mula", sebab)
    try:
        drv.terminate_app(APP_PACKAGE)
        time.sleep(2)
        drv.activate_app(APP_PACKAGE)
        time.sleep(4)
    except Exception as e:                                    # noqa: BLE001
        _catat_ledger(drv, "relaunch-ralat", f"{type(e).__name__}: {e}")
        print(f"  [RECOVERY] relaunch gagal: {type(e).__name__}: {e}")
        return False

    from devtools.smoke_tangga import pastikan_di_home
    ok = pastikan_di_home(drv, pages)
    bersih = ok and not ada_draf(pages)
    _catat_ledger(drv, "relaunch-selesai",
                  f"skrin_utama={ok} draf_hilang={bersih}")
    print(f"  [RECOVERY] skrin utama={ok}  draf hilang={bersih}")
    return bersih


def pulih_jika_perlu(drv, pages, tc):
    """Panggil SEBELUM setiap borang.

    >>> KENAPA TANPA SYARAT, BUKAN KESAN-DAHULU. 2026-08-10. <<<
    Versi pertama membuka borang NOTIS dan memeriksa medan pertamanya.
    Ia melaporkan "tiada draf dikesan" sejurus sebelum K-001 —
    kemudian K-001 gagal atas draf yang P-001 tinggalkan pada borang
    KOMPAUN PELBAGAI. Pemeriksaan itu melihat borang yang SALAH, dan
    draf adalah per-borang.

    Memeriksa SETIAP borang bermakna membuka setiap satu, yang mengambil
    masa lebih lama daripada relaunch itu sendiri dan membawa risiko
    yang sama seperti menyentuhnya. Jadi kami relaunch tanpa syarat
    antara TC borang. Relaunch ialah laluan recovery RASMI yang
    diluluskan pemilik dan setiap satu dicatat dalam ledger, jadi
    kosnya ketelusan sifar dan ia menghapuskan seluruh kelas
    pencemaran silang-TC.
    """
    return relaunch(drv, pages, f"{tc}: pemulihan wajib antara borang")


def _keluar_ke_home(pages, tc, cubaan=10):
    """BACK sahaja — TIADA dismiss_native_alerts() dalam laluan ini.

    >>> KENAPA. <<< Run pertama peringkat 6 mati di SINI, bukan dalam
    sebarang ujian: dismiss_native_alerts() menekan OK pada dialog
    "Maklumat Tidak Lengkap" dan corong membatalkan run semasa
    PEMBERSIHAN. Laluan pembersihan tidak sepatutnya mampu melanggar
    trip-wire langsung.

    Kekunci BACK Android menolak dialog asli tanpa menekan butang
    positifnya, jadi ia melakukan kerja yang sama tanpa pendedahan.
    """
    for _ in range(cubaan):
        if pages.home.is_home_screen_displayed():
            return True
        pages.home.press_back()
        time.sleep(1.0)
    return pages.home.is_home_screen_displayed()


def _readback(p, data, medan_medan, awalan, gagal):
    """Baca balik dari page_source — TANPA sebarang gerak isyarat.

    >>> KENAPA BUKAN cari_dua_arah(). 2026-08-10. <<<
    cari_dua_arah() menatal dengan swipe. Pada borang Kompaun, swipe
    TIDAK menatal — ia menukar TAB. Log larian membuktikannya secara
    langsung: sejurus selepas swipe pertama, kandungan bertukar kepada
    'Maklumat Jalan / Lokasi Kesalahan / Maklumat Kompaun', iaitu tab
    KOMPAUN. Jadi read-back itu sendiri MENAVIGASI KELUAR dari tab yang
    sedang disemaknya, kemudian melaporkan medan sebagai hilang, dan
    SETERUSNYA yang dicari selepas itu memang sudah tiada.

    Membaca page_source melihat pokok yang sama tanpa menyentuh
    apa-apa. Kalau nod tiada dalam pokok, itu jawapan jujur — bukan
    kesan sampingan alat ukur.
    """
    try:
        sumber = p.driver.page_source
    except Exception as e:                                    # noqa: BLE001
        gagal.append(f"{awalan}: page_source tidak boleh dibaca: "
                     f"{type(e).__name__}")
        return
    for medan in medan_medan:
        jangka = data.get(medan)
        if not jangka:
            continue
        if str(jangka) not in sumber:
            gagal.append(f"{awalan}.{medan}={jangka!r}")


# =========================================================================
# P-001 / K-001 — laluan borang kompaun, fill-only
# =========================================================================
def borang_kompaun(drv, pages, jenis, data, rb_pesalah, rb_kompaun, tc,
                   extras=False, plat=None, sudah_dibuka=False):
    """Isi -> baca balik -> BACK OUT tanpa Serah. Serah tidak disentuh;
    kalau sesuatu cuba, corong membunuh run.

    `sudah_dibuka=True` melangkau relaunch-wajib DAN pembukaan borang:
    pemanggil sudah membuka borang dan sudah membuktikannya bersih.
    Digunakan oleh mod demo-pantas sahaja. Lalainya False, jadi laluan
    audit tidak berubah langsung.
    """
    from devtools.smoke_tangga import pastikan_di_home

    p = pages.daftar_kompaun
    if not sudah_dibuka:
        pulih_jika_perlu(drv, pages, tc)
        if not pastikan_di_home(drv, pages):
            rekod(tc, "FAIL", "tidak sampai ke skrin utama")
            return
        pages.home.open_daftar_kompaun()
        if jenis == "letak_kereta":
            p.select_jenis_kompaun_letak_kereta()
        else:
            p.select_jenis_kompaun(jenis)

    gagal = []
    nota = []

    if plat:
        ok_ms, nota_ms = mysikap(pages, plat, tc)
        nota.append(f"MySIKAP: {nota_ms}")
        print(f"         MySIKAP {'OK' if ok_ms else 'GAGAL'} — {nota_ms}")
        if not ok_ms:
            # Arahan pemilik: gagal/timeout -> fallback isi manual +
            # catat. Fallback bukan menyembunyikan kegagalan; ia
            # membolehkan BAKI borang diuji, dan kegagalan lookup
            # dilaporkan berasingan.
            nota.append("fallback: pesalah diisi manual dari oracle")

    p.fill_pesalah_tab(data)
    if extras:
        try:
            p.fill_letak_kereta_extras(data)
        except Exception as e:                                # noqa: BLE001
            gagal.append(f"extras_letak_kereta: {type(e).__name__}: {e}")
    _readback(p, data, rb_pesalah, "pesalah", gagal)

    # Auto-isi alamat: poskod TIDAK PERNAH ditaip, jadi kehadirannya
    # ialah ukuran langsung sama ada app mengisinya. Sauh dipilih
    # kerana snapshot DB mengatakan poskod ADA untuk jalan ini; kalau
    # ia tetap kosong, itu dapatan baharu dan bukan D-03.
    jangka = data.get("poskod_dijangka")
    if jangka:
        try:
            ada = str(jangka) in p.driver.page_source
        except Exception:                                     # noqa: BLE001
            ada = False
        nota.append(f"auto-isi poskod {jangka}: "
                    f"{'ADA' if ada else 'TIDAK ADA'}")
        if not ada:
            gagal.append(f"auto-isi poskod {jangka!r} tidak muncul")
    print(f"         Pesalah: {'OK' if not gagal else 'ada gagal'}")

    # SETERUSNYA dicuba, tetapi kegagalannya BUKAN pengakhiran cerita.
    # Bila tab PESALAH tidak lengkap, app menguatkuasakan urutan tab dan
    # butang itu tidak dapat dicapai — kegagalan berbentuk "locator tidak
    # dijumpai" yang menuding ke tempat yang SALAH. fill_kompaun_tab()
    # memanggil _sahkan_skrin_kompaun(), yang menolak dialog penolakan
    # app dan membangkitkan sebab SEBENAR. Jadi teruskan ke situ.
    # >>> TAB DAHULU, SETERUSNYA KEMUDIAN. <<<
    # SETERUSNYA berada di BAWAH tab Pesalah, dan borang ini tidak
    # boleh di-swipe untuk sampai kepadanya (swipe = tukar tab). Bar
    # tab pula sentiasa kelihatan. Jadi ketuk tab KOMPAUN terus; ia
    # laluan yang app sendiri sediakan, dan gerbang urutan-tab masih
    # dikuatkuasakan oleh app (kami tidak memintasnya — kalau Pesalah
    # tidak lengkap, app tetap menolak).
    maju = False
    try:
        p.wait_and_tap(p.TAB_KOMPAUN)
        time.sleep(1.5)
        maju = True
    except Exception as e:                                    # noqa: BLE001
        print(f"         tab KOMPAUN tidak boleh diketuk "
              f"({type(e).__name__}) — cuba SETERUSNYA")
    if not maju:
        try:
            p.click_seterusnya_from_pesalah()
        except Exception as e:                                # noqa: BLE001
            print(f"         SETERUSNYA juga tidak dicapai "
                  f"({type(e).__name__}) — diteruskan supaya "
                  f"fill_kompaun_tab melaporkan sebabnya")
    p.fill_kompaun_tab(data)
    _readback(p, data, rb_kompaun, "kompaun", gagal)

    # Tiga dropdown — panggilan BERASINGAN daripada fill_kompaun_tab().
    # (Pelajaran N-001: menganggap ia termasuk menghasilkan lulus palsu.)
    p.fill_kompaun_code_fields(data)
    for nama, kunci in (("kod", "keterangan_kod_kompaun"),
                        ("akta", "kod_akta")):
        jangka = data[kunci]
        try:
            ada = p.cari_dua_arah(
                (p.LABEL_TIER1[0],
                 f'new UiSelector().textContains("{jangka}")'))
        except Exception:                                     # noqa: BLE001
            ada = False
        if not ada:
            gagal.append(f"dropdown.{nama}={jangka!r}")
    print(f"         dropdown: {'OK' if not gagal else 'ada gagal'}")

    print(f"  [{tc}] BACK OUT — borang ditinggalkan tanpa diserah")
    if not _keluar_ke_home(pages, tc):
        gagal.append("tidak kembali ke skrin utama")

    ekor = (" | " + " | ".join(nota)) if nota else ""
    if gagal:
        rekod(tc, "FAIL", ("; ".join(gagal)[:340]) + ekor)
    else:
        rekod(tc, "PASS",
              "semua medan + 3 dropdown, keluar tanpa Serah" + ekor)


def mysikap(pages, plat, tc):
    """Masuk No. Kereta -> tap MySIKAP -> sahkan auto-isi.

    Pulangkan (berjaya, nota). Kegagalan BUKAN pengecualian: arahan
    pemilik ialah gagal/timeout -> fallback isi manual + catat. Jadi
    pemanggil meneruskan borang, dan laporan menyatakan yang mana
    laluan diambil.

    `warna_kereta` TIDAK ditaip — ia tiada dalam oracle dan dijangka
    datang dari MySIKAP. Menaipnya akan menopengkan sama ada lookup
    benar-benar berfungsi, iaitu satu-satunya perkara yang langkah ini
    wujud untuk mengukur. Ini berbeza daripada fill_pesalah_tab_trafik(),
    yang menaip warna dahulu.
    """
    import time as _t
    p = pages.daftar_kompaun

    # Rakam borang SEBELUM menyentuhnya. Larian terdahulu gagal dengan
    # "butang MySIKAP tidak dijumpai" dan TIADA dump — jadi tiada cara
    # mengetahui sama ada butang itu tiada, bernama lain, atau borang
    # yang salah terbuka. Bukti dahulu, teori kemudian.
    try:
        laluan = os.path.join("ui_dumps", "mbpg_letak_kereta_pesalah.xml")
        os.makedirs("ui_dumps", exist_ok=True)
        with open(laluan, "w", encoding="utf-8") as fh:
            fh.write(p.driver.page_source)
        print(f"         dump borang: {laluan}")
    except Exception:                                         # noqa: BLE001
        pass

    print(f"  [{tc}] MySIKAP: plat {plat}")

    # >>> DEDAH DENGAN TRAVERSAL, JANGAN BIAR IA MENYWIPE. <<<
    # fill_field_by_label() menatal dengan swipe apabila label berada
    # di bawah lipatan. Pada borang ini swipe TIDAK menatal — ia
    # menukar TAB, dan selepas itu butang MySIKAP memang sudah tiada
    # kerana kita berada pada tab KOMPAUN. Itu tepat kegagalan yang
    # diperhati: "Jenis selected PASS" diikuti "butang MySIKAP tidak
    # dijumpai".
    #
    # reveal_below_fold() ialah traversal TAB/DPAD — satu-satunya
    # mekanisme yang terbukti menggerakkan borang kelas ini (pelajaran
    # N-001), dan ia tidak menukar tab.
    try:
        p._dedah_sebelum_cari(p._ci_label_locator(p.LABEL_TRAFIK_NO_KERETA),
                              p.LABEL_TRAFIK_NO_KERETA)
    except Exception as e:                                    # noqa: BLE001
        print(f"         pendedahan traversal NO. KERETA tidak berjaya "
              f"({type(e).__name__}) — meneruskan carian biasa")
    try:
        p.fill_field_by_label(p.LABEL_TRAFIK_NO_KERETA, plat)
    except Exception as e:                                    # noqa: BLE001
        return False, (f"medan '{p.LABEL_TRAFIK_NO_KERETA}' tidak dijumpai "
                       f"({type(e).__name__}) — lihat "
                       f"ui_dumps/mbpg_letak_kereta_pesalah.xml")

    for cubaan in range(3):
        try:
            titik = _cari_mysikap(p)
            if titik is None:
                return False, ("MySIKAP tidak dapat dikenal pasti secara "
                               "struktur (sauh ePBT) — TIADA tekaan dibuat")
            p.driver.tap([titik])
        except Exception as e:                                # noqa: BLE001
            return False, (f"butang MySIKAP tidak dijumpai/tidak boleh "
                           f"diketuk: {type(e).__name__}")
        tamat = _t.monotonic() + 25
        while _t.monotonic() < tamat:
            if p._mysikap_populated(plat):
                try:
                    nama = p.driver.find_element(
                        *p.FIELD_TRAFIK_NAMA_PESALAH).text
                except Exception:                             # noqa: BLE001
                    nama = "(tidak dapat dibaca)"
                return True, f"auto-isi BERJAYA — pemilik: {nama!r}"
            _t.sleep(1)
        p.dismiss_native_alerts(first_timeout=2, context=f"{tc}: MySIKAP")
        print(f"         MySIKAP belum mengisi (cubaan {cubaan + 1}/3)")
    return False, "lookup tidak pernah mengisi NAMA PESALAH dalam 3x25s"


def _isi_medan_tepat(p, placeholder, nilai):
    """Taip `nilai` ke dalam EditText yang memaparkan `placeholder`.

    Medan kosong dalam app ini membawa placeholder-nya dalam atribut
    `text`, jadi ini mengenal pasti satu medan dengan tepat — tiada
    aritmetik kedudukan, tiada sandaran indeks yang boleh tersasar ke
    medan jiran.
    """
    from appium.webdriver.common.appiumby import AppiumBy
    sel = ('new UiSelector().className("android.widget.EditText")'
           f'.text("{placeholder}")')
    try:
        el = p.find_element((AppiumBy.ANDROID_UIAUTOMATOR, sel), timeout=8)
    except Exception:                                         # noqa: BLE001
        return False
    try:
        p.tap_element(el)
        time.sleep(0.4)
        el.send_keys(nilai)
        time.sleep(0.4)
        try:
            p.driver.hide_keyboard()
            time.sleep(0.4)
        except Exception:                                     # noqa: BLE001
            pass
        return True
    except Exception:                                         # noqa: BLE001
        return False


def _tulis_medan_indeks(p, idx, nilai):
    """Timpa EditText ke-`idx` dengan `nilai`.

    Untuk medan yang SUDAH berisi, di mana carian ikut placeholder
    mustahil kerana placeholder itu sudah digantikan. Pembersihan
    melalui _force_clear() — corong pembersihan tunggal yang membaca
    dahulu dan tidak menekan backspace pada medan kosong.
    """
    from appium.webdriver.common.appiumby import AppiumBy
    sel = ('new UiSelector().className("android.widget.EditText")'
           f'.instance({idx})')
    try:
        el = p.find_element((AppiumBy.ANDROID_UIAUTOMATOR, sel), timeout=8)
        p.tap_element(el)
        time.sleep(0.3)
        p._force_clear(el)
        el.send_keys(nilai)
        time.sleep(0.3)
        try:
            p.driver.hide_keyboard()
            time.sleep(0.3)
        except Exception:                                     # noqa: BLE001
            pass
        return True
    except Exception as e:                                    # noqa: BLE001
        print(f"         tulis EditText[{idx}] gagal: {type(e).__name__}")
        return False


def _redact_pii(baris_beza):
    """Tukar nilai hasil lookup kepada penerangan bentuk.

    '[0] 'JYX6605' -> 'MOHAMAD ...'' menjadi
    '[0] plat -> <nama, 28 aksara>'. Yang kami perlu buktikan ialah
    MEDAN ITU TERISI dan bentuknya munasabah — bukan siapa orangnya.
    """
    import re
    keluar = []
    for b in baris_beza:
        m = re.match(r"^(\[\d+\]) (.*) -> (.*)$", b)
        if not m:
            keluar.append(b)
            continue
        idx, lama, baru = m.groups()
        nilai = baru.strip().strip("'")
        if re.fullmatch(r"\d{12}", nilai):
            bentuk = "<no. KP 12 digit>"
        elif re.fullmatch(r"\d{5}", nilai):
            bentuk = f"<poskod {nilai}>"      # poskod bukan pengenal diri
        elif nilai == "<tiada>":
            bentuk = "<medan baharu>"
        else:
            bentuk = f"<teks {len(nilai)} aksara>"
        keluar.append(f"{idx} {lama} -> {bentuk}")
    return keluar


def _cari_mysikap(p):
    """(x, y) tengah butang mySIKAP, atau None.

    >>> SATU IMPLEMENTASI SAHAJA — 2026-08-17. <<<
    Logik sebenar kini duduk dalam
    `pages.daftar_kompaun_page.cari_mysikap_dari_xml()` supaya objek
    halaman dan devtools tidak boleh menyimpang. Ia juga fungsi TULEN
    di sana, jadi ia diuji terhadap dump device sebenar tanpa peranti
    (tests_offline/test_mysikap_locator.py).

    Butang itu ialah elemen BERASINGAN daripada ePBT — bukan sandaran,
    bukan alias. Ia tiada text, content-desc, mahupun resource-id, jadi
    ia disauh pada kedudukan relatif kepada ePBT. Padanan yang bukan
    TEPAT SATU memulangkan None dan TIDAK meneka: kawalan bersebelahan
    pada baris itu ialah ePBT, yang pemilik amarkan MEMADAM data.

    Lihat docs/recon/DAPATAN-MYSIKAP.md.
    """
    from pages.daftar_kompaun_page import cari_mysikap_dari_xml

    try:
        src = p.driver.page_source
    except Exception:                                         # noqa: BLE001
        return None
    titik = cari_mysikap_dari_xml(src, getattr(p, "MYSIKAP_TOLERANSI_Y", 80))
    if titik is None:
        print("  [MySIKAP] tidak dapat dikenal pasti secara struktur "
              "(sauh ePBT tiada, atau padanan bukan tepat satu) — "
              "tiada tekaan dibuat")
    return titik


def _snapshot_medan(p):
    """{indeks: teks} bagi setiap EditText, dari page_source.

    Tanpa gerak isyarat — pada borang ini sebarang swipe menukar tab.
    Ini cara kita membuktikan APA yang ePBT lakukan: bandingkan
    snapshot sebelum dan selepas, dan biarkan perbezaan bercakap.
    """
    import xml.etree.ElementTree as ET
    try:
        akar = ET.fromstring(p.driver.page_source)
    except Exception:                                         # noqa: BLE001
        return {}
    keluar = {}
    i = 0
    for n in akar.iter():
        if (n.get("class") or "") == "android.widget.EditText":
            keluar[i] = (n.get("text") or "").strip()
            i += 1
    return keluar


def _beza_medan(sebelum, selepas):
    baris = []
    for k in sorted(set(sebelum) | set(selepas)):
        a, b = sebelum.get(k, "<tiada>"), selepas.get(k, "<tiada>")
        if a != b:
            baris.append(f"[{k}] {a!r} -> {b!r}")
    return baris


def k001_epbt(drv, pages, serial, baseline, data, plat, pantas=False):
    """K-001 mengikut urutan yang pemilik tetapkan 2026-08-10.

    >>> AYAT "ePBT ialah kawalan MySIKAP" DIBUANG 2026-08-12. <<<
    Ia SALAH dan ia berbahaya. Recon langsung membuktikan kedua-duanya
    kawalan BERASINGAN yang duduk bersebelahan pada baris yang sama:
    ePBT di kiri (`desc='ePBT'`), mySIKAP di kanan (logo, tanpa nama).
    Lihat docs/recon/DAPATAN-MYSIKAP.md dan `_cari_mysikap()`.

    Untuk lookup identiti guna `devtools/k001_mysikap.py`, yang menekan
    mySIKAP. Fungsi INI menekan ePBT, dan amaran pemilik tentang ePBT
    memadam medan terisi kekal terpakai — sebab itu urutannya: borang
    bersih -> No. Kereta SAHAJA -> ePBT sekali -> rekod apa yang
    berlaku -> baru isi selebihnya.

    Setiap tiga hasil yang mungkin (populate / padam / tiada apa)
    ialah dapatan SAH dan dirakam dengan screenshot + dump.
    """
    tc = "MBPG-TC-K-001"
    from devtools.smoke_tangga import pastikan_di_home
    from appium.webdriver.common.appiumby import AppiumBy

    # (a) borang BERSIH.
    # Laluan audit: relaunch tanpa syarat. Laluan demo-pantas
    # (`pantas=True`): buka dahulu, semak draf pada borang INI, dan
    # relaunch hanya kalau ia betul-betul kotor.
    p = pages.daftar_kompaun
    if pantas:
        from devtools.demo_pantas import buka_borang_bersih
        ok, _ = buka_borang_bersih(
            drv, pages,
            lambda: (pages.home.open_daftar_kompaun(),
                     p.select_jenis_kompaun_letak_kereta()),
            tc)
        if not ok:
            rekod(tc, "FAIL", "borang Letak Kereta tidak boleh dibuka "
                              "dalam keadaan bersih")
            return post_check(serial, baseline, tc)
    else:
        relaunch(drv, pages, f"{tc}: borang bersih sebelum ePBT")
        if not pastikan_di_home(drv, pages):
            rekod(tc, "FAIL", "tidak sampai ke skrin utama")
            return True
        pages.home.open_daftar_kompaun()
        p.select_jenis_kompaun_letak_kereta()

    nota = []
    # (b) No. Kereta SAHAJA — tiada nama, tiada IC.
    #
    # >>> SASARKAN PLACEHOLDER, BUKAN LABEL. <<<
    # fill_field_by_label() menyelesaikan label kepada medan melalui
    # kedudukan dan jatuh kepada "EditText instance(N) dalam bekas
    # aktif". Dengan fokus traversal bergerak, penyelesaian itu
    # tersasar: larian pertama meletakkan 'JYX6605' ke dalam TIGA
    # medan (Nama Pesalah, No K/P/SSM, No. Kereta) — mencemarkan
    # eksperimen yang urutan pemilik reka khas untuk mengasingkan.
    #
    # Medan kosong dalam app ini memaparkan placeholder-nya sebagai
    # `text`, jadi 'No. Kereta' mengenal pasti medan itu SAHAJA dengan
    # tepat, tanpa aritmetik kedudukan.
    if not _isi_medan_tepat(p, "No. Kereta", plat):
        rekod(tc, "FAIL", "medan 'No. Kereta' tidak dijumpai melalui "
                          "placeholder-nya")
        _keluar_ke_home(pages, tc)
        return post_check(serial, baseline, tc)

    # >>> KEMBALI KE TAB PESALAH SEBELUM MENCARI ePBT. <<<
    # Percubaan pertama gagal dengan "butang ePBT tidak boleh diketuk",
    # dan snapshot membuktikan kenapa: medan yang kelihatan ialah
    # 'Maklumat Jalan / Taman / Poskod / Lokasi Kesalahan' — itu tab
    # KOMPAUN. Mengisi No. Kereta (traversal + IME) telah menyeberang
    # tab. ePBT hidup pada tab PESALAH, jadi ia memang tiada di situ.
    try:
        p.driver.hide_keyboard()
        time.sleep(0.5)
    except Exception:                                         # noqa: BLE001
        pass
    try:
        p.wait_and_tap(p.TAB_PESALAH)
        time.sleep(1.5)
    except Exception as e:                                    # noqa: BLE001
        print(f"         tab PESALAH tidak boleh diketuk semula: "
              f"{type(e).__name__}")

    sebelum = _snapshot_medan(p)
    _simpan_bukti(p, "k001_sebelum_epbt")
    print(f"         medan sebelum ePBT: {sebelum}")

    # >>> GERBANG EKSPERIMEN DIBUANG — keputusan pemilik 2026-08-11,
    # pilihan (iii). <<<
    # Versi terdahulu membatalkan K-001 apabila plat muncul dalam lebih
    # daripada satu medan, kerana keputusan ePBT tidak akan bermakna
    # untuk medan yang sudah berisi. Soalan itu kini ditutup: lookup
    # TERBUKTI berfungsi (Jenis Kereta <- TOYOTA COROLLA, plat kekal),
    # dan keanehan plat-dalam-3-kotak direkod sebagai D-05 untuk
    # pasukan app — bukan sesuatu yang suite ini perlu selesaikan.
    #
    # Jadi kami teruskan: kotak Nama/IC ditimpa dengan data oracle
    # melalui aliran isi biasa di bawah.
    bil = sum(1 for v in sebelum.values()
              if plat.upper() == (v or "").upper().replace(" ", ""))
    if bil != 1:
        nota.append(f"D-05: plat dicerminkan ke {bil} medan; Nama/IC "
                    f"ditimpa dengan data oracle selepas ini")

    # (c) MySIKAP — TEKAN-TAHAN pada ImageView, BUKAN tap pada ePBT.
    #
    # >>> DIBETULKAN 2026-08-11 selepas recon terkawal. <<<
    # Versi terdahulu mengetuk butang berlabel `ePBT` dan mendapat
    # SATU medan (Jenis Kereta <- TOYOTA COROLLA). Itu bukan MySIKAP.
    # Maklumat staf lapangan mencetuskan ujian terkawal
    # (devtools/recon_mysikap.py), dan dua percubaan berasingan pada
    # borang bersih membuktikan kedua-dua kawalan itu BERBEZA dan
    # kedua-duanya BERFUNGSI:
    #
    #   TAP butang 'ePBT'      -> Jenis Kereta sahaja
    #   TEKAN-TAHAN ImageView  -> Nama Pesalah, No K/P/SSM, dan
    #     jiran (MySIKAP)         seluruh BLOK ALAMAT pemilik
    #
    # MySIKAP ialah pertanyaan pemilik JPJ; ePBT ialah carian jenis
    # kenderaan majlis. Yang K-001 perlukan ialah MySIKAP.
    #
    # ImageView itu melaporkan clickable="false" — sebab itulah tap
    # biasa padanya tidak berkesan dan kenapa ia terlepas pandang
    # begitu lama. Ia bersebelahan butang ePBT pada baris-y yang sama,
    # jadi ia dikenal pasti mengikut kedudukan, bukan nama.
    ms = _cari_mysikap(p)
    if not ms:
        rekod(tc, "FAIL", "kawalan MySIKAP (ImageView jiran ePBT) tidak "
                          "dijumpai pada borang")
        _keluar_ke_home(pages, tc)
        return post_check(serial, baseline, tc)
    try:
        drv.execute_script("mobile: longClickGesture",
                           {"x": ms[0], "y": ms[1], "duration": 1200})
        _catat_ledger(drv, "mysikap-longpress",
                      f"{tc}: plat {plat} @ {ms[0]},{ms[1]}")
    except DryRunViolation:
        raise
    except Exception as e:                                    # noqa: BLE001
        rekod(tc, "FAIL", f"long-press MySIKAP gagal: {type(e).__name__}")
        _keluar_ke_home(pages, tc)
        return post_check(serial, baseline, tc)

    # (c) tunggu response — beri masa network sebenar.
    print("         menunggu response ePBT (sehingga 45s)...")
    selepas = sebelum
    tamat = time.time() + 45
    while time.time() < tamat:
        time.sleep(3)
        selepas = _snapshot_medan(p)
        if _beza_medan(sebelum, selepas):
            break
    p.dismiss_native_alerts(first_timeout=2, context=f"{tc}: ePBT")
    selepas = _snapshot_medan(p)
    _simpan_bukti(p, "k001_selepas_epbt")

    # (d) rekod APA yang berlaku — ketiga-tiga hasil adalah dapatan.
    #
    # >>> HASIL LOOKUP DIREDACT SEBELUM DIREKOD. <<<
    # MySIKAP memulangkan pertanyaan JPJ SEBENAR: nama penuh, nombor
    # kad pengenalan, dan alamat rumah seorang rakyat yang tiada
    # kaitan dengan ujian ini selain memiliki plat yang pemilik
    # bekalkan. Pertanyaan itu dibenarkan; MENYEBARKAN hasilnya tidak
    # pernah diminta oleh sesiapa.
    #
    # Ringkasan berbentuk sahaja yang direkod. Nilai penuh kekal dalam
    # dump forensik, yang .gitignore sudah kecualikan.
    beza = _redact_pii(_beza_medan(sebelum, selepas))
    plat_kekal = any(plat.upper().replace(" ", "") ==
                     (v or "").upper().replace(" ", "")
                     for v in selepas.values())
    if not beza:
        hasil = "TIADA KESAN — tiada medan berubah dalam 45s"
    elif not plat_kekal:
        hasil = f"PLAT TERPADAM oleh lookup. Perubahan: {beza}"
    else:
        hasil = f"AUTO-ISI: {beza}"
    nota.append(f"MySIKAP: {hasil}")
    print(f"         MySIKAP -> {hasil}")
    _catat_ledger(drv, "mysikap-hasil", hasil)

    # (f) plat terpadam -> taip semula sebelum meneruskan.
    if not plat_kekal:
        try:
            p.fill_field_by_label(p.LABEL_TRAFIK_NO_KERETA, plat)
            nota.append("plat ditaip semula selepas lookup memadamnya")
        except Exception:                                     # noqa: BLE001
            nota.append("plat tidak dapat ditaip semula")

    # (e) habiskan K-001 fill-only.
    #
    # fill_pesalah_tab() TIDAK digunakan di sini: ia direka untuk tab
    # Pesalah borang Pelbagai, yang mempunyai blok alamat. Tab Pesalah
    # borang Letak Kereta tiada alamat langsung — medannya ialah
    # Nama / No K/P/SSM / No. Kereta / Cukai Jalan / Jenis / Warna /
    # Petak / Kupon (dump disahkan). Memanggilnya akan memburu medan
    # jalan yang memang tiada.
    #
    # >>> HASIL MySIKAP TIDAK DITIMPA. Dibetulkan 2026-08-11. <<<
    # Bila lookup berjaya, Nama Pesalah dan No K/P/SSM membawa data
    # pemilik JPJ SEBENAR bagi plat itu. Menulis nama oracle di
    # atasnya akan memadam satu-satunya bukti bahawa lookup berfungsi
    # — dan menghasilkan borang yang mendakwa seorang pesalah yang
    # BUKAN pemilik kenderaan itu.
    #
    # Oracle K-001 menamakan orang yang berbeza. Itu bukan
    # percanggahan: oracle ditulis untuk senario lain, dan plat ujian
    # ini datang daripada pemilik kemudian. Aliran penguatkuasa
    # sebenar ialah "cari plat, dapat pemilik" — itu yang diuji.
    gagal = []
    selepas_kini = _snapshot_medan(p)
    lookup_isi_identiti = (
        selepas_kini.get(0, "") not in ("", "Nama Pesalah", plat)
        and selepas_kini.get(1, "") not in ("", "No K/P/SSM", plat))
    if lookup_isi_identiti:
        nota.append("Nama/IC daripada MySIKAP DIKEKALKAN (tidak ditimpa "
                    "data oracle)")
        print("         Nama/IC diisi oleh MySIKAP — dikekalkan")
    else:
        for idx, kunci in ((0, "nama_pesalah"), (1, "no_kp_ssm_kereta")):
            if not _tulis_medan_indeks(p, idx, str(data[kunci])):
                gagal.append(f"tidak dapat menulis {kunci} ke "
                             f"EditText[{idx}]")

    # >>> BACA BALIK SEKARANG, SEBELUM APA-APA LAGI. <<<
    # Percubaan terdahulu membaca balik selepas fill_letak_kereta_extras()
    # dan melaporkan nama/IC 'hilang'. Dump membuktikan sebabnya:
    # snapshot ketika itu memaparkan medan tab KOMPAUN ('Maklumat Jalan',
    # 'Maklumat Taman', ...) — extras telah menggerakkan borang ke tab
    # lain, jadi read-back memeriksa skrin yang salah. Sekali lagi: alat
    # ukur yang menggerakkan perkara yang diukurnya.
    _simpan_bukti(p, "k001_pesalah_siap")
    if not lookup_isi_identiti:
        _readback(p, data, ("nama_pesalah", "no_kp_ssm_kereta"),
                  "pesalah", gagal)

    # Extras hidup pada tab PESALAH juga; pastikan kita masih di sana
    # sebelum memanggilnya.
    try:
        p.wait_and_tap(p.TAB_PESALAH)
        time.sleep(1.0)
    except Exception:                                         # noqa: BLE001
        pass
    try:
        p.fill_letak_kereta_extras(data)
    except Exception as e:                                    # noqa: BLE001
        gagal.append(f"extras: {type(e).__name__}: {str(e)[:120]}")

    try:
        p.wait_and_tap(p.TAB_KOMPAUN)
        time.sleep(1.5)
        p.fill_kompaun_tab(data)
        p.fill_kompaun_code_fields(data)
        for kunci in ("keterangan_kod_kompaun", "kod_akta"):
            if str(data[kunci]).rstrip(" .") not in p.driver.page_source:
                gagal.append(f"dropdown.{kunci}")
    except Exception as e:                                    # noqa: BLE001
        gagal.append(f"kompaun: {type(e).__name__}: {str(e)[:150]}")

    print(f"  [{tc}] BACK OUT tanpa Serah")
    _keluar_ke_home(pages, tc)
    ekor = " | " + " | ".join(nota)
    rekod(tc, "FAIL" if gagal else "PASS",
          ("; ".join(gagal)[:300] + ekor) if gagal
          else ("fill-only lengkap, keluar tanpa Serah" + ekor))
    return post_check(serial, baseline, tc)


def _simpan_bukti(p, tag):
    """Screenshot + dump. Bukti dahulu; tafsiran kemudian."""
    os.makedirs("reports/forensik", exist_ok=True)
    asas = os.path.join("reports", "forensik", tag)
    try:
        p.driver.get_screenshot_as_file(asas + ".png")
    except Exception:                                         # noqa: BLE001
        pass
    try:
        with open(asas + ".xml", "w", encoding="utf-8") as fh:
            fh.write(p.driver.page_source)
    except Exception:                                         # noqa: BLE001
        pass
    print(f"         bukti: {asas}.png / .xml")


def pra_sweep(drv, pages, serial, data):
    """Sahkan laluan yang sweep 284-set akan gunakan. SATU percubaan.

    (a) Lompat terus ke dropdown tanpa mengisi PESALAH — itu yang
        sedia_borang_kompaun() lakukan hari ini.
    (b) Kalau app menyekatnya (gerbang urutan tab), ukur laluan
        ganti: isi-pesalah-MINIMUM dengan sauh alamat berposkod,
        kemudian dropdown.

    Kenapa ini penting sebelum 284 set: kalau (a) disekat, sweep akan
    gagal 284 kali atas satu sebab yang sama, dan kegagalan itu akan
    kelihatan seperti 284 dapatan berasingan.
    """
    from devtools.smoke_tangga import pastikan_di_home
    from tests.sweep_kongsi import sedia_borang_kompaun
    hasil = {}

    # ---- (a) laluan sweep semasa: dropdown terus ----
    relaunch(drv, pages, "pra-sweep (a): borang bersih")
    if not pastikan_di_home(drv, pages):
        rekod("PRA-SWEEP", "FAIL", "tidak sampai ke skrin utama")
        return True
    p = pages.daftar_kompaun
    # (a) diuji secara MENTAH — buka borang dan lompat terus ke tab
    # KOMPAUN. sedia_borang_kompaun() TIDAK digunakan di sini kerana
    # ia kini mengisi Pesalah, iaitu tepat perkara yang (a) sepatutnya
    # membuktikan tidak diperlukan.
    pages.home.open_daftar_kompaun()
    p.select_jenis_kompaun("Kompaun Pelbagai")
    try:
        p.wait_and_tap(p.TAB_KOMPAUN)
        time.sleep(2)
    except Exception as e:                                    # noqa: BLE001
        print(f"         tab KOMPAUN tidak boleh diketuk: "
              f"{type(e).__name__}")
    sumber = p.driver.page_source
    ditolak = "Maklumat Tidak Lengkap" in sumber
    sampai = "KETERANGAN KOD KOMPAUN" in sumber
    hasil["a_terus"] = "LULUS" if (sampai and not ditolak) else "DISEKAT"
    print(f"  [PRA-SWEEP] (a) dropdown-terus tanpa Pesalah: "
          f"{hasil['a_terus']}"
          + ("  (app: 'Maklumat Tidak Lengkap')" if ditolak else ""))
    _simpan_bukti(p, "pra_sweep_a_dropdown_terus")
    _keluar_ke_home(pages, "pra-sweep-a")

    if hasil["a_terus"] == "LULUS":
        rekod("PRA-SWEEP laluan sweep", "PASS",
              "sedia_borang_kompaun() -> tab KOMPAUN -> dropdown "
              "BOLEH tanpa mengisi Pesalah; laluan sweep sedia")
        return post_check(serial, baseline_global, "PRA-SWEEP")

    # ---- (b) laluan ganti: pesalah MINIMUM dahulu ----
    print("  [PRA-SWEEP] (b) mengukur laluan ganti: pesalah minimum "
          "-> tab KOMPAUN -> dropdown")
    relaunch(drv, pages, "pra-sweep (b): borang bersih")
    pastikan_di_home(drv, pages)
    t0 = time.time()
    try:
        # Laluan sweep SEBENAR, tanpa pengubahsuaian: persediaan kini
        # mengisi Pesalah dan berpindah ke tab KOMPAUN dengan
        # sendirinya. Mengisi sekali lagi di sini akan mengukur
        # sesuatu yang sweep tidak lakukan.
        sedia_borang_kompaun(pages, "Kompaun Pelbagai")
        t_pesalah = time.time() - t0
        t1 = time.time()
        p.fill_kompaun_code_fields(data)
        t_dropdown = time.time() - t1
        ok = str(data["kod_akta"]).rstrip(" .") in p.driver.page_source
    except Exception as e:                                    # noqa: BLE001
        _simpan_bukti(p, "pra_sweep_b_gagal")
        rekod("PRA-SWEEP laluan ganti", "FAIL",
              f"{type(e).__name__}: {str(e)[:200]}")
        _keluar_ke_home(pages, "pra-sweep-b")
        return post_check(serial, baseline_global, "PRA-SWEEP")

    _keluar_ke_home(pages, "pra-sweep-b")
    # Anggaran diukur, bukan diteka. Set ke-2 dan seterusnya TIDAK
    # perlu mengisi Pesalah semula (borang kekal terbuka), jadi kos
    # marginal per-set ialah masa dropdown sahaja.
    per_set = t_dropdown
    jumlah_jam = (t_pesalah + 284 * per_set) / 3600.0
    rekod("PRA-SWEEP laluan sweep", "PASS" if ok else "FAIL",
          f"laluan (a) DISEKAT oleh gerbang urutan tab; laluan ganti "
          f"(pesalah minimum + sauh alamat) BERFUNGSI. "
          f"Pesalah {t_pesalah:.0f}s sekali; dropdown {per_set:.0f}s "
          f"per set -> anggaran 284 set ~{jumlah_jam:.1f} jam berterusan")
    print(f"  [PRA-SWEEP] pesalah={t_pesalah:.0f}s  "
          f"dropdown/set={per_set:.0f}s  284 set ~{jumlah_jam:.1f} jam")
    return post_check(serial, baseline_global, "PRA-SWEEP")


baseline_global = None


def dropdown_sahaja(drv, pages, jenis, data, tc):
    """Borang SEGAR -> terus ke tab Kompaun -> tiga dropdown sahaja.

    Ini BUKAN P-001/K-001. Ia diagnostik yang memisahkan dua sebab
    kegagalan yang kelihatan sama dalam laporan:
        (a) enjin borang/dropdown rosak, lawan
        (b) rekod alamat production tiada poskod, jadi tab PESALAH tidak
            pernah lengkap dan app enggan membuka tab KOMPAUN.
    Tanpa pemisahan ini, "P-001 GAGAL" tidak memberitahu sesiapa yang
    mana satu, dan laluan sweep 265-set bergantung sepenuhnya pada
    laluan dropdown-terus yang sama ini.
    """
    from devtools.smoke_tangga import pastikan_di_home
    from tests.sweep_kongsi import sedia_borang_kompaun

    try:
        if not pastikan_di_home(drv, pages):
            raise RuntimeError("tidak sampai ke skrin utama")
        sedia_borang_kompaun(pages, jenis)
        p = pages.daftar_kompaun
        p.fill_kompaun_code_fields(data)
        gagal = []
        for nama, kunci in (("kod", "keterangan_kod_kompaun"),
                            ("akta", "kod_akta"),
                            ("kesalahan", "kesalahan_kompaun")):
            jangka = data[kunci]
            try:
                ada = p.cari_dua_arah(
                    (p.LABEL_TIER1[0],
                     f'new UiSelector().textContains("{jangka[:40]}")'))
            except Exception:                                 # noqa: BLE001
                ada = False
            if not ada:
                gagal.append(f"{nama}={jangka[:40]!r}")
        rekod(tc, "FAIL" if gagal else "PASS",
              "; ".join(gagal)[:300] if gagal
              else "3 dropdown dipilih + dibaca balik pada borang segar")
    except DryRunViolation:
        raise
    except Exception as e:                                    # noqa: BLE001
        rekod(tc, "FAIL", f"{type(e).__name__}: {str(e)[:220]}")
    _keluar_ke_home(pages, tc)


# =========================================================================
# T-002 — Tetapan Pelbagai
# =========================================================================
def t002(pages):
    """Isi lesen -> SIMPAN (konteks Tetapan) -> sahkan dialog.

    >>> KENAPA NILAI TIDAK DIUBAH KEPADA SESUATU YANG LAIN. <<<
    Arahan pemilik untuk T-002/T-010 ialah "ubah -> SIMPAN -> verify ->
    RESTORE wajib". Untuk T-010 itu selamat: pilihan skrin pendaratan
    boleh dipilih semula dalam saat yang sama.

    Untuk T-002 satu-satunya medan ialah LESEN APLIKASI, dan menulis
    nombor lesen yang SALAH kepada peranti penguatkuasa production
    boleh menyahaktifkan app. Kalau app mengunci selepas SIMPAN, blok
    `finally` tidak dapat memulihkan apa-apa — skrin untuk memulihkan
    tiada di sebalik kunci itu. Itu satu-satunya jenis "restore" yang
    tidak boleh dijamin, jadi ia tidak dicuba.

    Yang dijalankan: nilai SAH yang sama ditulis semula, SIMPAN ditekan,
    dialog keputusan disahkan. Laluan tulis + butang SIMPAN dalam
    konteks Tetapan diuji sepenuhnya; delta yang tidak diuji ialah
    "nilai BERBEZA diterima dan kekal". Itu direkod sebagai TIDAK
    TERBUKTI, bukan sebagai lulus.
    """
    from config import LICENSE_SETTINGS
    lesen = LICENSE_SETTINGS["lesen_aplikasi"]

    pages.pelarasan.ensure_on_login_screen()
    pages.pelarasan.open_menu_selaras()
    sedia_ada = pages.pelarasan.baca_tetapan_pelbagai()
    print(f"         lesen tersimpan sekarang: {sedia_ada!r}")
    if sedia_ada and sedia_ada.strip() != str(lesen).strip():
        rekod("MBPG-TC-T-002", "BLOK",
              f"lesen pada peranti {sedia_ada!r} != profil {lesen!r}. "
              f"Tidak ditulis — menulis nilai profil akan MENGUBAH "
              f"lesen production. Keputusan pemilik diperlukan.")
        return
    pages.pelarasan.set_tetapan_pelbagai(lesen)
    semula = pages.pelarasan.baca_tetapan_pelbagai()
    ok = bool(semula) and semula.strip() == str(lesen).strip()
    rekod("MBPG-TC-T-002", "PASS" if ok else "FAIL",
          f"SIMPAN dalam konteks Tetapan + dialog + baca balik {semula!r}"
          if ok else f"baca balik {semula!r} != {lesen!r}")


# =========================================================================
# T-010 — Pilihan Skrin Utama
# =========================================================================
def t010(pages):
    """DEFAULT dipilih: membuktikan boleh-pilih tanpa mengubah skrin
    pendaratan app. Restore tidak perlu kerana DEFAULT ialah keadaan
    sedia ada — disahkan dengan membaca semula selepasnya."""
    pages.pelarasan.ensure_on_login_screen()
    pages.pelarasan.open_menu_selaras()
    ok = pages.pelarasan.tetapan_skrin_utama()
    rekod("MBPG-TC-T-010", "PASS" if ok else "FAIL",
          "popup PILIHAN SKRIN UTAMA dibuka + DEFAULT dipilih "
          "(skrin pendaratan tidak diubah)")


# =========================================================================
# Selaras read-only + semak kemaskini
# =========================================================================
def selaras_sekali(pages, hanya=None):
    """T-006 / T-007 / T-009 / T-011 — SEKALI setiap satu.

    D-01: selaras kali-kedua = Duplicate entry lalu app ranap. Jadi
    tiada cuba-semula di sini; kegagalan direkod dan diteruskan.
    SELARAS PELESEN (T-008) TIDAK muncul dalam senarai ini dan tidak
    akan ditambah.
    """
    p = pages.pelarasan
    for tc, nama, fn in (
        ("MBPG-TC-T-006", "Selaras Jenis Kenderaan",
         lambda: p.selaras_jenis_kenderaan()),
        ("MBPG-TC-T-007", "Selaras Maklumat Warna",
         lambda: p.selaras_maklumat_warna()),
        ("MBPG-TC-T-009", "Selaras Barang Sita",
         lambda: p.selaras_barang_sita()),
        ("MBPG-TC-T-011", "Semak Kemaskini Versi",
         lambda: p.semak_kemaskini()),
    ):
        # `hanya` wujud kerana D-01: sync kali-kedua = Duplicate entry
        # lalu app ranap. Menyambung selepas pembetulan corong MESTI
        # boleh melangkau modul yang sudah berjaya sekali.
        if hanya and tc not in hanya:
            continue
        try:
            p.ensure_on_login_screen()
            p.open_menu_selaras()
            ok = fn() is not False
            rekod(tc, "PASS" if ok else "FAIL", nama)
        except DryRunViolation:
            raise
        except Exception as e:                                # noqa: BLE001
            rekod(tc, "FAIL", f"{nama}: {type(e).__name__}: "
                              f"{str(e)[:200]}")
        try:
            p.close_menu_selaras()
        except Exception:                                     # noqa: BLE001
            pass


# =========================================================================
# N-003 — lampiran / kamera
# =========================================================================
def n003(drv, pages, serial, baseline):
    """Had keras 15 minit (arahan pemilik). Melebihi = SKIP jujur
    dengan bukti skrin, bukan FAIL yang dikaburkan."""
    from devtools.smoke_tangga import pastikan_di_home, _diagnosis_skrin
    from testdata import oracle_n001 as O

    mula = time.time()
    try:
        if not pastikan_di_home(drv, pages):
            raise RuntimeError("tidak sampai ke skrin utama")
        pages.home.open_notis_amaran()
        na = pages.notis_amaran
        na.fill_pesalah_tab(O.SEMUA)
        na.click_seterusnya_from_pesalah()
        baki = 900 - (time.time() - mula)
        if baki <= 0:
            raise TimeoutError("had 15 minit habis sebelum kamera dibuka")
        na.take_photos(count=1)
        rekod("MBPG-TC-N-003", "PASS", "lampiran diterima")
    except DryRunViolation:
        raise
    except Exception as e:                                    # noqa: BLE001
        try:
            _diagnosis_skrin(drv, "n003_kamera")
        except Exception:                                     # noqa: BLE001
            pass
        rekod("MBPG-TC-N-003", "SKIP",
              f"kamera tidak boleh diskrip dalam had 15 min: "
              f"{type(e).__name__}: {str(e)[:150]} — bukti skrin dalam "
              f"reports/forensik/")
    _keluar_ke_home(pages, "N-003")
    return post_check(serial, baseline, "MBPG-TC-N-003")


# =========================================================================
# N/P/K-005 — bookmark
# =========================================================================
def bookmark(drv, pages, serial, baseline):
    """SIMPAN dibenarkan HANYA dalam dialog bookmark (konteks_bookmark).

    Jangkaan pemilik: FAIL mungkin SAH di sini — oracle merekod bahawa
    menukar bookmark tidak mengemas kini medan borang. FAIL pada langkah
    itu ialah dapatan, bukan bug skrip, dan dinota sedemikian.
    """
    from devtools.smoke_tangga import pastikan_di_home

    hanya = os.environ.get("MBPG_BOOKMARK_HANYA", "")
    for tc, jenis, nama_bm in (
        ("MBPG-TC-N-005", "notis", "AUTOTEST-N"),
        ("MBPG-TC-P-005", "Kompaun Pelbagai", "AUTOTEST-P"),
        ("MBPG-TC-K-005", "letak_kereta", "AUTOTEST-K"),
    ):
        if hanya and tc not in hanya.split(","):
            continue
        try:
            pulih_jika_perlu(drv, pages, tc)
            if not pastikan_di_home(drv, pages):
                raise RuntimeError("tidak sampai ke skrin utama")
            if jenis == "notis":
                # >>> IKON BUKU TIDAK BERADA PADA TAB PENDARATAN. <<<
                # Larian pertama membuka borang lalu terus memanggil
                # open_bookmark_popup() dan mendapat "ikon buku U+E866
                # tidak dijumpai". Itu kegagalan HARNES, bukan dapatan:
                # ikon hidup pada tab NOTIS. Borang N boleh dilepasi
                # tab Pesalah (N-001 LULUS PENUH), jadi maju dahulu.
                from testdata import oracle_n001 as O
                pages.home.open_notis_amaran()
                na = pages.notis_amaran
                na.fill_pesalah_tab(O.SEMUA)
                na.click_seterusnya_from_pesalah()
            else:
                pages.home.open_daftar_kompaun()
                if jenis == "letak_kereta":
                    pages.daftar_kompaun.select_jenis_kompaun_letak_kereta()
                else:
                    pages.daftar_kompaun.select_jenis_kompaun(jenis)
            bm = pages.bookmark
            bm.open_bookmark_popup()
            bm.save_bookmark(nama_bm)
            bm.select_bookmark(nama_bm)
            rekod(tc, "PASS", f"{nama_bm} disimpan + dipilih semula")
        except DryRunViolation:
            raise
        except Exception as e:                                # noqa: BLE001
            rekod(tc, "FAIL", f"{type(e).__name__}: {str(e)[:220]}")
        _keluar_ke_home(pages, tc)
        if not post_check(serial, baseline, tc):
            return False
    return True


# =========================================================================
# Pemandu peringkat
# =========================================================================
def _pakai_sauh_alamat(serial, *dicts):
    """Ganti jalan PESALAH dengan sauh yang poskodnya WUJUD.

    Keputusan pemilik 2026-08-10 pilihan (a). Hanya medan JALAN pesalah
    ditukar; alamat KOMPAUN (jalan premis) kekal dari oracle, dan
    poskod tidak pernah ditaip di mana-mana.
    """
    from devtools.smoke_tangga import tarik_db, AKAR
    from testdata import sauh_alamat
    db = tarik_db(serial, os.path.join(AKAR, "data", "tmp", "sauh.db"))
    alamat, jejak = sauh_alamat.pilih(db)
    sauh_alamat.cetak(alamat, jejak)
    for d in dicts:
        d["jalan_asal_oracle"] = d["jalan"]
        d["jalan"] = alamat["jalan"]
        d["poskod_dijangka"] = alamat["poskod_dijangka"]
        # Blok alamat pesalah ialah OUTPUT app, bukan input kami: app
        # mengisinya dari jalan yang dipilih. Menukar jalan mesti
        # menukar jangkaan bersamanya, kalau tidak read-back menyemak
        # poskod oracle (81750) terhadap borang yang app isi dengan
        # 81700 dan melaporkan GAGAL pada tingkah laku yang BETUL.
        d["poskod"] = alamat["poskod_dijangka"]
        d["taman"] = alamat["taman_dijangka"]
        d["bandar"] = alamat["bandar_dijangka"]
        d["negeri"] = alamat["negeri_dijangka"]
    return alamat, jejak


def jalan(drv, pages, serial, baseline, langkau_pk=False, mula="tetapan",
          hanya=None):
    global baseline_global
    baseline_global = baseline
    from testdata import oracle_pk as OPK

    if hanya == "k001":
        _pakai_sauh_alamat(serial, OPK.P001, OPK.K001)
        print("\n== K-001 melalui ePBT (urutan pemilik 2026-08-10) ==")
        try:
            if not k001_epbt(drv, pages, serial, baseline, OPK.K001,
                             OPK.K001["no_kereta"]):
                return False
        except DryRunViolation:
            raise
        except Exception as e:                                # noqa: BLE001
            rekod("MBPG-TC-K-001", "FAIL",
                  f"{type(e).__name__}: {str(e)[:220]}")
        _ringkasan()
        return True

    if hanya == "pra-sweep":
        _pakai_sauh_alamat(serial, OPK.P001, OPK.K001)
        print("\n== PENGESAHAN PRA-SWEEP ==")
        try:
            if not pra_sweep(drv, pages, serial, OPK.P001):
                return False
        except DryRunViolation:
            raise
        except Exception as e:                                # noqa: BLE001
            rekod("PRA-SWEEP", "FAIL", f"{type(e).__name__}: {str(e)[:220]}")
        _ringkasan()
        return True

    print("\n" + "=" * 68)
    print("== PERINGKAT 6: luaskan skop (TANPA HENTI antara TC)")
    print("=" * 68)

    if langkau_pk:
        # Bukan pilihan gaya. Larian 2026-08-10 membuktikan borang P/K
        # tidak boleh dilepasi tab PESALAH pada data production (D-03),
        # dan setiap percubaan meninggalkan alert penolakan yang
        # merosakkan TC seterusnya. Menjalankannya semula hanya
        # membakar masa peranti dan menghalang baki peringkat 6
        # daripada diuji langsung — itulah yang berlaku pada larian itu.
        rekod("MBPG-TC-P-001", "FAIL",
              "tersekat pada gerbang tab PESALAH (D-03: poskod kosong "
              "untuk JALAN GUNUNG 12 dalam DB production). Dilangkau "
              "dalam larian ini; keputusan dari larian p6c.log.")
        rekod("MBPG-TC-K-001", "FAIL",
              "sama (D-03: JALAN RIMBA 2 tiada poskod) + bahagian "
              "MySIKAP TERSEKAT tiada no_kereta dalam oracle.")
        return _selepas_borang(drv, pages, serial, baseline, mula)

    _pakai_sauh_alamat(serial, OPK.P001, OPK.K001)

    print("\n-- P-001 Daftar Kompaun Pelbagai --")
    try:
        borang_kompaun(drv, pages, "Kompaun Pelbagai", OPK.P001,
                       OPK.P001_READBACK_PESALAH, OPK.P001_READBACK_KOMPAUN,
                       "MBPG-TC-P-001")
    except DryRunViolation:
        raise
    except Exception as e:                                    # noqa: BLE001
        rekod("MBPG-TC-P-001", "FAIL", f"{type(e).__name__}: {str(e)[:220]}")
    _keluar_ke_home(pages, "P-001")
    if not post_check(serial, baseline, "MBPG-TC-P-001"):
        return False

    print("\n-- K-001 Daftar Kompaun Letak Kereta (MySIKAP: JYX6605) --")
    try:
        borang_kompaun(drv, pages, "letak_kereta", OPK.K001,
                       OPK.K001_READBACK_PESALAH, OPK.K001_READBACK_KOMPAUN,
                       "MBPG-TC-K-001", extras=True,
                       plat=OPK.K001["no_kereta"])
    except DryRunViolation:
        raise
    except Exception as e:                                    # noqa: BLE001
        rekod("MBPG-TC-K-001", "FAIL",
              f"{type(e).__name__}: {str(e)[:220]}")
    _keluar_ke_home(pages, "K-001")
    if not post_check(serial, baseline, "MBPG-TC-K-001"):
        return False

    # DIAGNOSTIK dropdown-terus DIBUANG dari laluan biasa.
    # Ia wujud untuk memisahkan "enjin dropdown rosak" daripada "data
    # menyekat borang". Soalan itu kini terjawab: gerbang tab ialah
    # sebabnya, dan sauh alamat menyahsekatnya. Diagnostik itu sendiri
    # tidak pernah lulus kerana ia melompat terus ke dropdown tanpa
    # bertukar ke tab KOMPAUN — mengekalkannya hanya menambah masa
    # peranti dan satu GAGAL yang mengelirukan dalam laporan.
    # dropdown_sahaja() kekal dalam fail ini untuk kegunaan manual.

    return _selepas_borang(drv, pages, serial, baseline)


def _selepas_borang(drv, pages, serial, baseline, mula="tetapan"):
    """`mula` membolehkan sambung semula tanpa mengulang apa yang sudah
    LULUS. T-002 menulis kepada production setiap kali ia berjalan;
    mengulanginya semata-mata untuk sampai ke TC seterusnya ialah tulisan
    production tanpa nilai bukti."""
    urutan = ["tetapan", "selaras", "kamera", "bookmark"]
    buat = urutan[urutan.index(mula):]

    if "tetapan" in buat:
        print("\n-- T-002 Tetapan Pelbagai --")
        try:
            t002(pages)
        except (DryRunViolation, RestoreGagal):
            raise
        except Exception as e:                                # noqa: BLE001
            rekod("MBPG-TC-T-002", "FAIL",
                  f"{type(e).__name__}: {str(e)[:220]}")

        print("\n-- T-010 Pilihan Skrin Utama --")
        try:
            t010(pages)
        except DryRunViolation:
            raise
        except Exception as e:                                # noqa: BLE001
            rekod("MBPG-TC-T-010", "FAIL",
                  f"{type(e).__name__}: {str(e)[:220]}")
        try:
            pages.pelarasan.close_menu_selaras()
        except Exception:                                     # noqa: BLE001
            pass

    if "selaras" in buat:
        print("\n-- T-006 / T-007 / T-009 / T-011 (SEKALI setiap satu) --")
        print("   D-01: selaras kali-kedua = Duplicate entry + app ranap.")
        print("   SELARAS PELESEN (T-008) TIDAK DISENTUH.")
        selaras_sekali(pages, hanya=os.environ.get("MBPG_SELARAS_HANYA",
                                                   "").split(",") or None
                       if os.environ.get("MBPG_SELARAS_HANYA") else None)

    if "kamera" in buat:
        print("\n-- N-003 lampiran/kamera (had 15 minit) --")
        if not n003(drv, pages, serial, baseline):
            return False

    if "bookmark" in buat:
        print("\n-- N/P/K-005 bookmark --")
        if not bookmark(drv, pages, serial, baseline):
            return False

    _ringkasan()
    return True


def _ringkasan():
    print("\n" + "=" * 68)
    print("== RINGKASAN PERINGKAT 6")
    print("=" * 68)
    for h in HASIL:
        print(f"  {h['status']:5} {h['tc']}")
        if h["nota"]:
            print(f"        {h['nota'][:220]}")

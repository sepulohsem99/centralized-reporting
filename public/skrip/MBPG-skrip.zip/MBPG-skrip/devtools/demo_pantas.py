"""
MOD DEMO-PANTAS — laluan demo Fasa 1 dengan overhead dibuang.

>>> INI TAMBAHAN, BUKAN GANTIAN. <<<
devtools/demo_fasa1.py dan tangga smoke penuh KEKAL tidak berubah; ia
laluan AUDIT dan ia yang menjalankan selaras. Fail ini hanya wujud di
belakang MBPG_DEMO_PANTAS=1 dan tidak diimport oleh mana-mana laluan
audit.

Apa yang berubah, dan apa yang TIDAK:

  BERUBAH
    A. Relaunch BERSYARAT. Borang dibuka dahulu, draf disemak pada
       borang ITU, dan relaunch hanya berlaku kalau draf betul-betul
       ada. TC read-only tidak pernah mencetuskannya.
    B. Selepas relaunch, Remember Me diberi peluang memulihkan sesi
       sebelum sebarang log masuk dicuba. Kalau app tetap jatuh ke
       skrin login, sebabnya DILOG (ia bukti langsung untuk T-012).
    C. Selaras read-only (T-003/005/006/007/009) dilangkau.

  TIDAK BERUBAH
    - Corong, trip-wire, gerbang IP, post-check selepas setiap borang.
    - Jeda RN (_JEDA_R), enjin dropdown, read-back. Diukur pada larian
      demo 2026-08-11: _JEDA_R tidak tercetus SEKALI pun (0 saat).
      Melonggarkannya menambah risiko reload RN di tengah taipan
      untuk gain yang diukur sebagai sifar.
    - Data ujian, sauh alamat, dan setiap pengesahan.
"""

import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
AKAR = os.path.dirname(HERE)
sys.path.insert(0, AKAR)

from guard.dasar import DryRunViolation                       # noqa: E402
from devtools import peringkat6 as P6                         # noqa: E402


MASA = []


def _catat_masa(label, t0):
    saat = time.time() - t0
    MASA.append((label, saat))
    print(f"  [MASA] {label}: {saat:.0f}s")
    return saat


# ===========================================================================
# A — draf per-borang, relaunch bersyarat
# ===========================================================================
def borang_ada_draf(pages, p):
    """Adakah borang YANG KINI TERBUKA memegang draf?

    >>> DIPERIKSA PADA BORANG YANG SAMA, bukan borang lain. <<<
    Percubaan terdahulu memeriksa borang NOTIS dan melaporkan 'tiada
    draf' sejurus sebelum K-001, yang kemudian gagal atas draf yang
    P-001 tinggalkan pada borang KOMPAUN PELBAGAI. Draf bersifat
    PER-BORANG; satu pemeriksaan tidak boleh mewakili yang lain.

    Kosnya sifar tambahan: borang perlu dibuka untuk diisi, jadi
    semakan ini berlaku pada borang yang memang sudah di hadapan mata.

    Kaedah: medan kosong dalam app ini memaparkan placeholder-nya
    sebagai `text`, dan `hint` membawa placeholder yang sama. Jadi
    text == hint bermakna kosong. Itu tepat yang _medan_kosong() uji,
    dan ia satu-satunya tempat dalam suite yang menjawab soalan ini.
    """
    from appium.webdriver.common.appiumby import AppiumBy
    try:
        el = p.find_element(
            (AppiumBy.ANDROID_UIAUTOMATOR,
             'new UiSelector().className("android.widget.EditText")'
             '.instance(0)'), timeout=6)
        kosong, semasa = p._medan_kosong(el)
        if not kosong:
            print(f"         draf dikesan pada borang ini: {semasa!r}")
        return not kosong
    except Exception as e:                                    # noqa: BLE001
        # Tidak dapat membaca bukan bermakna bersih. Fail ke arah
        # memulihkan: relaunch tidak merosakkan apa-apa, meneruskan
        # pada borang kotor merosakkan TC.
        print(f"         semakan draf gagal ({type(e).__name__}) — "
              f"dianggap kotor")
        return True


def buka_borang_bersih(drv, pages, buka, tc, p=None):
    """Buka borang, dan JAMIN ia bersih — dengan relaunch hanya kalau
    perlu. Pulangkan (ok, bil_relaunch)."""
    from devtools.smoke_tangga import pastikan_di_home
    p = p or pages.daftar_kompaun

    if not pastikan_di_home(drv, pages):
        return False, 0
    buka()
    if not borang_ada_draf(pages, p):
        print(f"         [{tc}] borang bersih — TIADA relaunch")
        return True, 0

    print(f"         [{tc}] draf ada — relaunch (laluan recovery rasmi)")
    relaunch_pantas(drv, pages, f"{tc}: draf dikesan pada borang ini")
    if not pastikan_di_home(drv, pages):
        return False, 1
    buka()
    masih = borang_ada_draf(pages, p)
    if masih:
        print(f"         [{tc}] AMARAN: draf KEKAL selepas relaunch")
    return not masih, 1


# ===========================================================================
# B — sesi kekal: beri Remember Me peluang sebelum log masuk
# ===========================================================================
def relaunch_pantas(drv, pages, sebab):
    """terminate + activate, kemudian TUNGGU sesi pulih sendiri.

    Suite audit memanggil pastikan_di_home() terus, yang log masuk
    penuh sebaik sahaja ia nampak skrin login. Di sini kami beri
    Remember Me peluang dahulu: app selalunya memaparkan splash lalu
    memulihkan ke skrin utama, dan menyerbu masuk dengan log masuk
    mengalahkan pemulihan itu.

    Kalau ia tetap berakhir pada skrin login, itu DILOG sebagai
    penemuan — ia bukti langsung untuk T-012 (Remember Me), yang
    laporan tandakan TIDAK TERBUKTI.
    """
    from config import APP_PACKAGE
    t0 = time.time()
    print(f"  [RECOVERY] relaunch — {sebab}")
    P6._catat_ledger(drv, "relaunch-mula", sebab)
    try:
        drv.terminate_app(APP_PACKAGE)
        time.sleep(1.5)
        drv.activate_app(APP_PACKAGE)
    except Exception as e:                                    # noqa: BLE001
        P6._catat_ledger(drv, "relaunch-ralat", f"{type(e).__name__}: {e}")
        return False

    # Tunggu app menetap: skrin utama (Remember Me pulih) ATAU skrin
    # login (tidak pulih). Tinjau, jangan tidur sepanjang tempoh.
    pulih = jatuh_ke_login = False
    tamat = time.time() + 30
    while time.time() < tamat:
        time.sleep(1.5)
        try:
            if pages.home.is_home_screen_displayed():
                pulih = True
                break
            if pages.login.is_login_screen_displayed(bersihkan=False):
                jatuh_ke_login = True
                break
        except Exception:                                     # noqa: BLE001
            continue

    saat = time.time() - t0
    if pulih:
        print(f"  [SESI] Remember Me MEMULIHKAN sesi — skrin utama "
              f"dalam {saat:.0f}s, TIADA log masuk")
        P6._catat_ledger(drv, "relaunch-selesai",
                         f"sesi pulih tanpa login, {saat:.0f}s")
        return True

    if jatuh_ke_login:
        # PENEMUAN, bukan sekadar keadaan. Direkod di kedua-dua tempat.
        print(f"  [SESI] app jatuh ke SKRIN LOGIN selepas relaunch "
              f"({saat:.0f}s) walaupun Remember Me — log masuk penuh "
              f"diperlukan. Ini bukti T-012.")
        P6._catat_ledger(drv, "sesi-tidak-pulih",
                         "skrin login selepas relaunch walau Remember Me")
        P6.rekod("MBPG-TC-T-012 (Remember Me merentas relaunch)", "FAIL",
                 "app jatuh ke skrin login selepas terminate+activate; "
                 "sesi TIDAK dipulihkan. Diperhati dalam mod demo-pantas.")
    else:
        print(f"  [SESI] keadaan tidak jelas selepas {saat:.0f}s")
    return False


# ===========================================================================
# Pemandu
# ===========================================================================
def main():
    if os.environ.get("MBPG_DEMO_PANTAS") != "1":
        print("Mod ini di belakang flag. Jalankan dengan:")
        print("  set MBPG_DEMO_PANTAS=1")
        return 2

    from device_utils import resolve_udid
    from config import APP_PACKAGE
    from devtools.smoke_tangga import (peringkat_1, peringkat_2,
                                       peringkat_t001, peringkat_5)

    mula = time.time()
    serial = resolve_udid(APP_PACKAGE, verbose=False)
    bil_relaunch = 0

    print("=" * 70)
    print("== DEMO-PANTAS FASA 1 — tanpa Serah, 0 rekod, guard penuh")
    print("=" * 70)
    print("  Selaras read-only DILANGKAU (mod demo). Suite audit penuh")
    print("  kekal menjalankannya: devtools/demo_fasa1.py")
    print("  Sweep 279 set TIDAK disentuh.")

    t0 = time.time()
    p1 = peringkat_1(serial)
    if not p1["ok"]:
        print("\nHENTI: gerbang peranti gagal.")
        return 1
    baseline = p1["baseline"]
    P6.baseline_global = baseline
    _catat_masa("1 gerbang peranti", t0)

    drv = pages = None
    try:
        t0 = time.time()
        drv, pages = peringkat_2()
        P6.rekod("MBPG-TC-T-012", "PASS", "log masuk sampai skrin utama")
        _catat_masa("2 login", t0)

        # ---- Tetapan (read-only + T-002 tulis-dan-pulih) ----
        # TIADA relaunch di sini: skrin ini tidak mempunyai draf borang.
        t0 = time.time()
        print("\n-- Tetapan: T-001 / T-002 / T-010 / T-011 --")
        try:
            ok = peringkat_t001(pages, serial)
            P6.rekod("MBPG-TC-T-001", "PASS" if ok else "FAIL",
                     "BACA-SAHAJA (D-02, keputusan pemilik 2026-08-10)")
        except DryRunViolation:
            raise
        except Exception as e:                                # noqa: BLE001
            P6.rekod("MBPG-TC-T-001", "FAIL", f"{type(e).__name__}")
        for fn, tc in ((P6.t002, "MBPG-TC-T-002"),
                       (P6.t010, "MBPG-TC-T-010")):
            try:
                fn(pages)
            except (DryRunViolation, P6.RestoreGagal):
                raise
            except Exception as e:                            # noqa: BLE001
                P6.rekod(tc, "FAIL", f"{type(e).__name__}: {str(e)[:150]}")
        try:
            pages.pelarasan.close_menu_selaras()
        except Exception:                                     # noqa: BLE001
            pass
        P6.selaras_sekali(pages, hanya=("MBPG-TC-T-011",))
        _catat_masa("3 tetapan T-001/002/010/011", t0)

        P6.rekod("Selaras T-003/005/006/007/009", "SKIP",
                 "mod demo-pantas — dilangkau atas arahan pemilik. "
                 "Suite audit penuh kekal menjalankannya.")

        # ---- N-001 ----
        t0 = time.time()
        print("\n-- N-001 --")
        ok, r = buka_borang_bersih(
            drv, pages, lambda: pages.home.open_notis_amaran(),
            "MBPG-TC-N-001", p=pages.notis_amaran)
        bil_relaunch += r
        if ok:
            # peringkat_5 membuka borang sendiri; kami sudah di sana dan
            # ia mengendalikan itu (is_notis_amaran_screen_displayed).
            try:
                hasil = peringkat_5(pages, serial, baseline, drv)
                P6.rekod("MBPG-TC-N-001", "PASS" if hasil else "FAIL",
                         "fill + read-back + BACK OUT tanpa Serah")
                if not hasil:
                    return 1
            except DryRunViolation:
                raise
        else:
            P6.rekod("MBPG-TC-N-001", "FAIL", "borang tidak boleh dibuka "
                                              "dalam keadaan bersih")
        _catat_masa("4 N-001", t0)

        # ---- P-001 dan K-001 ----
        from testdata import oracle_pk as OPK
        P6._pakai_sauh_alamat(serial, OPK.P001, OPK.K001)

        t0 = time.time()
        print("\n-- P-001 --")
        ok, r = buka_borang_bersih(
            drv, pages,
            lambda: (pages.home.open_daftar_kompaun(),
                     pages.daftar_kompaun.select_jenis_kompaun(
                         "Kompaun Pelbagai")),
            "MBPG-TC-P-001")
        bil_relaunch += r
        try:
            P6.borang_kompaun(drv, pages, "Kompaun Pelbagai", OPK.P001,
                              OPK.P001_READBACK_PESALAH,
                              OPK.P001_READBACK_KOMPAUN, "MBPG-TC-P-001",
                              sudah_dibuka=True)
        except DryRunViolation:
            raise
        except Exception as e:                                # noqa: BLE001
            P6.rekod("MBPG-TC-P-001", "FAIL", f"{type(e).__name__}: "
                                              f"{str(e)[:180]}")
        P6._keluar_ke_home(pages, "P-001")
        if not P6.post_check(serial, baseline, "MBPG-TC-P-001"):
            return 1
        _catat_masa("5 P-001", t0)

        t0 = time.time()
        print("\n-- K-001 + ePBT --")
        try:
            if not P6.k001_epbt(drv, pages, serial, baseline, OPK.K001,
                                OPK.K001["no_kereta"], pantas=True):
                return 1
        except DryRunViolation:
            raise
        except Exception as e:                                # noqa: BLE001
            P6.rekod("MBPG-TC-K-001", "FAIL", f"{type(e).__name__}: "
                                              f"{str(e)[:180]}")
        _catat_masa("6 K-001", t0)

        # ---- ringkasan ----
        jumlah = time.time() - mula
        print("\n" + "=" * 70)
        print("== RINGKASAN DEMO-PANTAS")
        print("=" * 70)
        kira = {}
        for h in P6.HASIL:
            kira[h["status"]] = kira.get(h["status"], 0) + 1
            print(f"  {h['status']:5} {h['tc']}")
            if h["nota"]:
                print(f"        {h['nota'][:170]}")
        print(f"\n  {kira}")
        print("\n  Pecahan masa:")
        for label, saat in MASA:
            print(f"    {label:34} {saat:6.0f}s")
        print(f"    {'JUMLAH':34} {jumlah:6.0f}s  "
              f"({jumlah / 60:.1f} minit)")
        print(f"\n  Relaunch: {bil_relaunch}  (demo penuh: 3)")
        return 0
    finally:
        if drv is not None:
            c = getattr(drv, "corong", None)
            if c is not None:
                print(f"\n  [CORONG] {c.bil_tap} tap dinilai, "
                      f"{c.bil_sekat} disekat"
                      + (f" | DIBATALKAN: {c.dibatalkan}"
                         if c.dibatalkan else ""))
            try:
                drv.quit()
            except Exception:                                 # noqa: BLE001
                pass


if __name__ == "__main__":
    sys.exit(main())

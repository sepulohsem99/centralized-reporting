"""
FASA C — E2E satu rekod: cipta -> serah -> hantar -> cetak.

    python devtools/fasa_c_e2e.py --borang P     # Kompaun Pelbagai
    python devtools/fasa_c_e2e.py --borang K     # Letak Kereta

Satu rekod setiap larian. Kuota dikuatkuasakan dari LEDGER-E2E.jsonl,
jadi menjalankan semula selepas berjaya akan DISEKAT, bukan mencipta
rekod kedua.

>>> BORANG K: MySIKAP TIDAK DICETUS. <<<
Lookup mySIKAP memulangkan nama penuh, IC, dan alamat rumah orang
SEBENAR (docs/recon/DAPATAN-MYSIKAP.md). Peraturan identiti pemilik
melarang PII orang sebenar pada rekod yang diserah, jadi plat ditaip
dan identiti diisi dari oracle. Butang ePBT kekal tidak disentuh: ia
memadam data dan ia BUKAN mySIKAP.

>>> CETAK: SATU TEKAN, TIADA ULANGAN. <<<
Peraturan kekal pemilik. Setiap ketukan yang berjaya mengeluarkan
sehelai kertas.
"""

import argparse
import os
import sys
import time
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
AKAR = os.path.dirname(HERE)
sys.path.insert(0, AKAR)

from devtools import peringkat6 as P6                          # noqa: E402
from devtools import fasa_c as FC                              # noqa: E402
from guard.gerbang_serah import (Izin, SerahTidakDiizinkan,    # noqa: E402
                                 diagnosis, semak)

DOK = os.path.join(AKAR, "docs", "FASA-C-REKOD.md")
DIR_BUKTI = os.path.join(AKAR, "docs", "demo-fasa-c", "e2e")

SPEC = {
    "P": {"tag": "P-001", "set_id": "C2-P-001",
          "jenis": "Kompaun Pelbagai", "oracle": "P001",
          "jadual": "local_ekpn_tawaran_kompaun"},
    "K": {"tag": "K-001", "set_id": "C3-K-001",
          "jenis": "Kompaun Letak Kereta", "oracle": "K001",
          "jadual": "local_ekpn_tawaran_kompaun"},
}


def bukti(drv, tag):
    os.makedirs(DIR_BUKTI, exist_ok=True)
    asas = os.path.join(DIR_BUKTI, tag)
    try:
        drv.get_screenshot_as_file(asas + ".png")
    except Exception:                                           # noqa: BLE001
        pass
    try:
        with open(asas + ".xml", "w", encoding="utf-8") as fh:
            fh.write(drv.page_source)
    except Exception:                                           # noqa: BLE001
        pass
    print(f"    [BUKTI] {tag}")


def tulis_dok(baris):
    with open(DOK, "a", encoding="utf-8") as fh:
        fh.write(baris + "\n")
        fh.flush()
        os.fsync(fh.fileno())
    print("    [DOK] docs/FASA-C-REKOD.md dikemas kini")


def jaring_pii(drv, data):
    """PII berbentuk sebenar yang kita TIDAK taip.

    >>> KENAPA `data` PENTING. <<<
    Versi pertama jaring ini menanda apa-apa yang berbentuk PII. Data
    oracle K-001 sendiri berbentuk begitu ('... A/P ...'), jadi jaring
    itu akan membatalkan rekod K atas data ujian KITA SENDIRI — dan
    memberi amaran yang kelihatan serius sedangkan tiada orang sebenar
    terlibat. Amaran palsu yang menghalang kerja sah akan diabaikan,
    dan jaring yang diabaikan tidak melindungi sesiapa.

    Yang sebenarnya berbahaya ialah PII yang MUNCUL tanpa kita
    menaipnya — iaitu hasil lookup. Jadi nilai yang kita bekalkan
    dikecualikan, dan apa-apa yang lain kekal ditanda.
    """
    from devtools.imbas_pii import imbas_teks
    milik_kita = {str(v).strip().upper() for v in data.values()
                  if isinstance(v, str) and v.strip()}
    jumpa = []
    for nama, nilai in imbas_teks(" | ".join(FC._teks_skrin(drv)), had=40):
        if nama not in ("nama_bin_binti", "no_kp_bersengkang"):
            continue
        # Padanan SERPIHAN, bukan padanan penuh: corak nama memadan
        # bahagian TENGAH nama (segmen sekitar BIN/BINTI/A-L/A-P),
        # bukan rentetan penuh. Semakan kesamaan tepat akan terlepas
        # itu dan membatalkan rekod atas nama oracle kita sendiri.
        n = nilai.strip().upper()
        if any(n in v for v in milik_kita):
            continue                      # sebahagian nilai yang kita taip
        jumpa.append((nama, nilai))
    return jumpa


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--borang", required=True, choices=("P", "K"))
    a = ap.parse_args()
    s = SPEC[a.borang]

    from devtools.smoke_tangga import (peringkat_1, peringkat_2,
                                       pastikan_di_home, tarik_db)
    from tests.sweep_kongsi import sedia_borang_kompaun
    from device_utils import resolve_udid
    from config import APP_PACKAGE, RECORD_PREFIX
    from testdata import oracle_pk as OPK
    from pages.cetak_page import CetakPage, PrinterTidakSedia
    from guard.dasar import PermitSerah

    data = getattr(OPK, s["oracle"])
    print("=" * 70)
    print(f"== FASA C E2E — {s['tag']} ({s['jenis']})")
    print(f"== prefix {RECORD_PREFIX} | satu rekod | satu tekan cetak")
    print("=" * 70)

    izin = Izin.dari_persekitaran(AKAR)
    d = diagnosis(izin)
    print(f"  serah_mungkin = {d['serah_mungkin']}  luput={d['lapisan_5_sebab']}")
    if not d["serah_mungkin"]:
        print("HENTI: gerbang tertutup.")
        return 1
    sudah = FC.kiraan_borang_dari_ledger(a.borang)
    print(f"  rekod borang {a.borang} dari ledger: {sudah}")
    semak(izin, s["set_id"], sudah, borang=a.borang, kiraan_borang=sudah)
    print("  gerbang: LULUS\n")

    serial = resolve_udid(APP_PACKAGE, verbose=False)
    p1 = peringkat_1(serial)
    if not p1["ok"]:
        return 1
    P6.baseline_global = p1["baseline"]

    drv = None
    try:
        drv, pages = peringkat_2()
        P6.relaunch(drv, pages, f"{s['tag']}: borang bersih")
        if not pastikan_di_home(drv, pages):
            print("HENTI: tidak sampai skrin utama")
            return 1

        # --- printer DAHULU: jangan cipta rekod yang tak boleh dicetak
        print(f"\n{'-' * 68}\n-- 0. PRINTER\n{'-' * 68}")
        cetak = CetakPage(drv)
        lap = cetak.sahkan_printer_sedia(wajib=True)

        # --- isi borang ---
        print(f"\n{'-' * 68}\n-- 1. ISI BORANG (oracle sintetik)\n"
              f"{'-' * 68}")
        print(f"  pesalah = {data.get('nama_pesalah')!r}")
        P6._pakai_sauh_alamat(serial, data, OPK.K001)
        sedia_borang_kompaun(pages, s["jenis"])
        p = pages.daftar_kompaun

        if a.borang == "K":
            # Plat DITAIP. mySIKAP tidak disentuh; ePBT tidak disentuh.
            plat = data["no_kereta"]
            print(f"  menaip No. Kereta = {plat!r} (mySIKAP TIDAK dicetus)")
            P6._isi_medan_tepat(p, "No. Kereta", plat)

        p.fill_kompaun_code_fields(data)
        p.take_photos(count=3)
        p.click_seterusnya_from_kompaun()
        p.fill_penerima_tab(data)
        bukti(drv, f"{s['tag']}-01-pra-serah")

        jumpa = jaring_pii(drv, data)
        if jumpa:
            bukti(drv, f"{s['tag']}-ABORT-PII")
            raise SerahTidakDiizinkan(
                f"Skrin pra-serah membawa PII yang KITA TIDAK taip: "
                f"{[j[0] for j in jumpa]}. Itu bermakna satu lookup "
                f"berlaku. Rekod DIBATALKAN.")
        print("  jaring PII: bersih (hanya nilai oracle kita sendiri)")

        # --- serah ---
        print(f"\n{'-' * 68}\n-- 2. SERAH — rekod SEBENAR\n{'-' * 68}")
        db1 = tarik_db(serial, os.path.join(AKAR, "data", "tmp",
                                            f"pra_{s['tag']}.db"))
        sebelum = FC.kira_rekod(db1)
        hasil = FC.serah_dan_tangkap(drv, pages, p, s["set_id"],
                                     s["jadual"], serial, sebelum)
        bukti(drv, f"{s['tag']}-02-selepas-serah")
        no_rekod = hasil["no_rekod"]

        tulis_dok(f"| {s['tag']} | `{no_rekod}` | {hasil['no_siri']} | "
                  f"{time.strftime('%Y-%m-%d %H:%M')} | "
                  f"{data.get('nama_pesalah')} (oracle {s['oracle']}) | "
                  f"dihantar ke printer |")

        # --- cetak: satu tekan ---
        print(f"\n{'-' * 68}\n-- 3. CETAK (satu tekan, tiada ulangan)\n"
              f"{'-' * 68}")
        tetapan = drv.corong.tetapan
        tetapan.permit_serah = PermitSerah(s["set_id"], had=1)
        try:
            hc = cetak.cetak_dari_popup(no_rekod)
        finally:
            tetapan.permit_serah = None
            print("  [CETAK] permit DITANGGALKAN")
        bukti(drv, f"{s['tag']}-03-selepas-cetak")

        FC.catat_ledger({"peristiwa": "cetak-dicuba",
                         "set_id": s["set_id"], "no_rekod": no_rekod,
                         "percubaan": 1, "popup_tutup": hc["popup_tutup"],
                         "printer": lap.get("nama")})

        print("\n" + "=" * 70)
        print(f"== {s['tag']} — REKOD DICIPTA + CETAK DIHANTAR")
        print("=" * 70)
        print(f"  No. rekod : {no_rekod}")
        print(f"  No. siri  : {hasil['no_siri']}")
        print(f"  Kejayaan  : {hasil['kejayaan']}")
        print(f"  Printer   : {lap.get('nama')}")
        print(f"  Popup tutup selepas CETAK: {hc['popup_tutup']}")
        print("\n  MENUNGGU PENGESAHAN KERTAS OLEH PEMILIK.")
        return 0
    except BaseException as e:                                  # noqa: BLE001
        print(f"\n{'!' * 70}\n!! BERHENTI — {type(e).__name__}\n{'!' * 70}")
        print(str(e)[:2500])
        if not isinstance(e, (SerahTidakDiizinkan, PrinterTidakSedia)):
            traceback.print_exc()
        if drv is not None:
            bukti(drv, f"{s['tag']}-ABORT")
        FC.catat_ledger({"peristiwa": "e2e-gagal", "set_id": s["set_id"],
                         "punca": f"{type(e).__name__}: "
                                  f"{str(e).splitlines()[0][:200]}"})
        return 1
    finally:
        if drv is not None:
            c = getattr(drv, "corong", None)
            if c is not None:
                print(f"\n  [CORONG] {c.bil_tap} tap dinilai, "
                      f"{c.bil_sekat} disekat")
            try:
                drv.quit()
            except Exception:                                   # noqa: BLE001
                pass


if __name__ == "__main__":
    sys.exit(main())

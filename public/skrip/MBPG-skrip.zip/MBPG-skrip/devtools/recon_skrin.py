"""
Recon skrin — dump SETIAP elemen pada skrin semasa, dengan codepoint glif.

    python devtools/recon_skrin.py

BACA-SAHAJA. Ia mencipta sesi Appium, membaca page_source, dan keluar.
Ia TIDAK mengetuk apa-apa.

Kenapa ia memintas gerbang IP: gerbang menavigasi Menu Selaras, dan alat
ini wujud tepat untuk kes di mana navigasi itu GAGAL kerana locator tidak
memadan. Menjalankan gerbang dahulu bermakna alat diagnosis mati atas
sebab yang sama seperti perkara yang cuba didiagnosis. Corong dry-run
TETAP dipasang — memintas gerbang bukan alasan untuk memandu tanpa
kawalan, walaupun alat ini tidak mengetuk.

Glif ikon dicetak sebagai U+XXXX. MBJB dan MBPG menggunakan codepoint
yang BERBEZA untuk ikon yang sama, jadi membandingkan glif mentah antara
suite adalah sia-sia — codepoint yang perlu dipadankan.
"""

import os
import re
import sys
import xml.etree.ElementTree as ET

HERE = os.path.dirname(os.path.abspath(__file__))
AKAR = os.path.dirname(HERE)
sys.path.insert(0, AKAR)


def papar(nilai):
    """Rentetan boleh baca; glif Private Use Area jadi U+XXXX."""
    if not nilai:
        return ""
    keluar = []
    for ch in nilai:
        o = ord(ch)
        if 0xE000 <= o <= 0xF8FF or 0xF0000 <= o <= 0xFFFFD:
            keluar.append(f"<U+{o:04X}>")
        else:
            keluar.append(ch)
    return "".join(keluar)


def main():
    from appium import webdriver
    from appium.options.android import UiAutomator2Options
    from config import (APPIUM_URL, APP_PACKAGE, APP_ACTIVITY, DEVICE_NAME,
                        PLATFORM_NAME, AUTOMATION_NAME)
    from device_utils import resolve_udid
    from guard import corong as _corong

    udid = resolve_udid(APP_PACKAGE, verbose=False)
    o = UiAutomator2Options()
    o.device_name = DEVICE_NAME
    o.set_capability("udid", udid)
    o.platform_name = PLATFORM_NAME
    o.app_package = APP_PACKAGE
    o.app_activity = APP_ACTIVITY
    o.no_reset = True
    o.full_reset = False
    o.automation_name = AUTOMATION_NAME
    o.set_capability("disableAndroidWatchers", True)

    drv = webdriver.Remote(APPIUM_URL, options=o)
    drv = _corong.pasang(drv)
    try:
        drv.activate_app(APP_PACKAGE)
        import time
        time.sleep(2)
        print(f"\nactivity: {drv.current_activity}")
        src = drv.page_source
        akar = ET.fromstring(src)
        print(f"{'kelas':34} {'clickable':9} {'bounds':26} teks / desc")
        print("-" * 118)
        for n in akar.iter():
            t = (n.get("text") or "").strip()
            d = (n.get("content-desc") or "").strip()
            rid = (n.get("resource-id") or "").strip()
            if not (t or d or rid):
                continue
            kelas = (n.get("class") or "").replace("android.widget.", "")
            kelas = kelas.replace("android.view.", "v.")
            label = papar(t) or papar(d)
            if rid:
                label = f"{label}   [id={rid}]"
            print(f"{kelas[:34]:34} {n.get('clickable', ''):9} "
                  f"{n.get('bounds', ''):26} {label[:60]}")
        # Simpan XML penuh untuk rujukan.
        d = os.path.join(AKAR, "recon")
        os.makedirs(d, exist_ok=True)
        p = os.path.join(d, "skrin_semasa.xml")
        with open(p, "w", encoding="utf-8") as fh:
            fh.write(src)
        print(f"\nXML penuh: {p}")
    finally:
        drv.quit()


if __name__ == "__main__":
    sys.exit(main() or 0)

"""
RECON — cari butang MySIKAP pada tab PESALAH borang Letak Kereta.

>>> KENAPA RECON INI WUJUD. <<<
Pemilik mengesahkan butang MySIKAP MEMANG WUJUD dan duduk betul-betul
di sebelah butang ePBT. Kod sedia ada (`peringkat6._cari_mysikap`)
tidak pernah mencarinya mengikut NAMA: ia memilih ImageView pertama
yang berkongsi baris-y dengan ePBT, dan kalau ePBT tidak dijumpai ia
jatuh balik kepada ImageView PERTAMA pada skrin -- iaitu ia boleh
memulangkan apa sahaja, dan melaporkan "MySIKAP" untuk kawalan yang
belum tentu MySIKAP.

Recon ini tidak meneka. Ia membongkar SETIAP node dan melaporkan apa
yang benar-benar ada, supaya locator direkod dari bukti.

>>> ePBT TIDAK DITEKAN. <<<
Amaran pemilik: ePBT MEMADAM data. Skrip ini hanya MEMBACA. Satu-satunya
tap ialah ke medan No. Kereta dan tab PESALAH.

    python devtools/recon_mysikap.py
"""

import os
import re
import sys
import time
import xml.etree.ElementTree as ET

HERE = os.path.dirname(os.path.abspath(__file__))
AKAR = os.path.dirname(HERE)
sys.path.insert(0, AKAR)

from devtools import peringkat6 as P6                          # noqa: E402

DIR_RECON = os.path.join(AKAR, "docs", "recon")
PLAT = "JYX6605"
MINAT = re.compile(r"sikap|epbt|semak|carian|cari|jpj|lookup", re.I)


def tengah(b):
    m = re.match(r"\[(\d+),(\d+)\]\[(\d+),(\d+)\]", b or "")
    if not m:
        return None
    x1, y1, x2, y2 = map(int, m.groups())
    return (x1 + x2) // 2, (y1 + y2) // 2


def semua_node(drv):
    """Setiap node + setiap atribut yang boleh mengenal pasti kawalan."""
    try:
        akar = ET.fromstring(drv.page_source.encode("utf-8"))
    except Exception as e:                                      # noqa: BLE001
        print(f"  page source tidak boleh dihurai: {e}")
        return []
    keluar = []
    for n in akar.iter():
        keluar.append({
            "kelas": (n.get("class") or "").split(".")[-1],
            "text": (n.get("text") or "").strip(),
            "desc": (n.get("content-desc") or "").strip(),
            "rid": (n.get("resource-id") or "").strip(),
            "clickable": (n.get("clickable") or ""),
            "bounds": n.get("bounds") or "",
            "pusat": tengah(n.get("bounds")),
        })
    return keluar


def lapor(nod, tajuk, tapis):
    print(f"\n  ---- {tajuk} ----")
    n = 0
    for d in nod:
        if not tapis(d):
            continue
        n += 1
        print(f"    {d['kelas']:<14} klik={d['clickable']:<5} "
              f"{d['bounds']:<24}")
        if d["text"]:
            print(f"        text = {d['text']!r}")
        if d["desc"]:
            print(f"        desc = {d['desc']!r}")
        if d["rid"]:
            print(f"        rid  = {d['rid']!r}")
    if n == 0:
        print("    (tiada)")
    return n


def main():
    from devtools.smoke_tangga import peringkat_1, peringkat_2, \
        pastikan_di_home
    from device_utils import resolve_udid
    from config import APP_PACKAGE

    print("=" * 70)
    print("== RECON MySIKAP — tab PESALAH, borang Letak Kereta")
    print("== BACA SAHAJA. ePBT TIDAK DITEKAN.")
    print("=" * 70)

    serial = resolve_udid(APP_PACKAGE, verbose=False)
    p1 = peringkat_1(serial)
    if not p1["ok"]:
        return 1
    baseline = p1["baseline"]
    P6.baseline_global = baseline

    drv = pages = None
    try:
        drv, pages = peringkat_2()
        P6.relaunch(drv, pages, "recon mysikap: borang bersih")
        if not pastikan_di_home(drv, pages):
            print("HENTI: tidak sampai skrin utama")
            return 1

        p = pages.daftar_kompaun
        pages.home.open_daftar_kompaun()
        p.select_jenis_kompaun_letak_kereta()

        print(f"\n  mengisi No. Kereta = {PLAT}")
        if not P6._isi_medan_tepat(p, "No. Kereta", PLAT):
            print("  AMARAN: medan No. Kereta tidak dijumpai — teruskan "
                  "dump juga")
        try:
            drv.hide_keyboard()
            time.sleep(0.5)
        except Exception:                                       # noqa: BLE001
            pass

        os.makedirs(DIR_RECON, exist_ok=True)

        for fasa, sebelum_tab in (("A-sebelum-tab-pesalah", True),
                                  ("B-tab-pesalah", False)):
            if not sebelum_tab:
                print("\n  menukar ke tab PESALAH...")
                try:
                    p.wait_and_tap(p.TAB_PESALAH)
                    time.sleep(1.5)
                except Exception as e:                          # noqa: BLE001
                    print(f"  tab PESALAH gagal: {e}")

            print(f"\n{'=' * 66}\n== FASA {fasa}\n{'=' * 66}")
            nod = semua_node(drv)
            print(f"  {len(nod)} node dalam pokok view")

            laluan = os.path.join(DIR_RECON, f"mysikap-{fasa}.xml")
            try:
                with open(laluan, "w", encoding="utf-8") as fh:
                    fh.write(drv.page_source)
                print(f"  page source penuh -> {laluan}")
            except Exception:                                   # noqa: BLE001
                pass
            try:
                drv.get_screenshot_as_file(
                    os.path.join(DIR_RECON, f"mysikap-{fasa}.png"))
            except Exception:                                   # noqa: BLE001
                pass

            # 1. Apa-apa yang NAMANYA membayangkan lookup kenderaan.
            lapor(nod, "NODE yang namanya membayangkan lookup/SIKAP/ePBT",
                  lambda d: MINAT.search(
                      f"{d['text']} {d['desc']} {d['rid']}"))

            # 2. ePBT dan SEMUA yang berkongsi baris-y dengannya.
            epbt = [d for d in nod
                    if "epbt" in f"{d['text']} {d['desc']}".lower()
                    and d["pusat"]]
            if epbt:
                ey = epbt[0]["pusat"][1]
                print(f"\n  ePBT dijumpai pada y={ey} "
                      f"({epbt[0]['bounds']})")
                lapor(nod, f"SEMUA node dalam baris ePBT (y {ey}+-150)",
                      lambda d: d["pusat"]
                      and abs(d["pusat"][1] - ey) < 150)
            else:
                print("\n  ePBT TIDAK dijumpai pada fasa ini")

            # 3. Setiap kawalan yang boleh ditekan, tanpa tapisan nama.
            lapor(nod, "SEMUA node clickable",
                  lambda d: d["clickable"] == "true")

            # 4. Imej -- kawalan tanpa nama sering ImageView.
            lapor(nod, "SEMUA ImageView / ImageButton / Button",
                  lambda d: d["kelas"] in ("ImageView", "ImageButton",
                                           "Button"))

        print("\n" + "=" * 70)
        print("== Tiada tap dibuat ke ePBT. Tiada tap dibuat ke MySIKAP.")
        print("== Langkah seterusnya bergantung pada apa yang di atas.")
        print("=" * 70)
        P6.post_check(serial, baseline, "recon-mysikap")
        return 0
    finally:
        if drv is not None:
            c = getattr(drv, "corong", None)
            if c is not None:
                print(f"\n  [CORONG] {c.bil_tap} tap dinilai, "
                      f"{c.bil_sekat} disekat")
            try:
                drv.quit()
            except Exception:                                   # noqa: BLE001
                pass


if __name__ == "__main__":
    sys.exit(main())

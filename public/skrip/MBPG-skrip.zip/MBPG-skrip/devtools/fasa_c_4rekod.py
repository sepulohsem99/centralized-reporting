"""
FASA C — 4 REKOD PRODUCTION SEBENAR, TANPA PENGAWASAN.

    (1) N   Notis Amaran
    (2) P   Kompaun Pelbagai
    (3) K   Kompaun Letak Kereta   (plat ujian; MySIKAP TIDAK dicetus)
    (4) NK  Notis-ke-Kompaun       (menukar notis (1), tiada notis baharu)

>>> KENAPA MySIKAP TIDAK DICETUS PADA REKOD K. <<<
Arahan pemilik menamakan MySIKAP untuk K, TETAPI peraturan identiti
pemilik dalam arahan yang SAMA berkata "bukan identiti pihak ketiga
sebenar", dan arahan sebelumnya berkata "JANGAN cetus MySIKAP pada
rekod yang diserah". Lookup itu DISAHKAN memulangkan nama penuh, IC,
dan alamat rumah orang sebenar (docs/recon/DAPATAN-MYSIKAP.md). Jadi
plat ujian ditaip dan identiti diisi dari oracle; MySIKAP tidak
disentuh. Itu satu-satunya bacaan yang memenuhi kedua-dua peraturan.

Kalau mana-mana medan identiti secara automatik terisi dengan sesuatu
yang kelihatan seperti PII sebenar, rekod itu DIBATALKAN sebelum serah.

>>> RAIL FAIL-CLOSED (menggantikan pengawasan manusia). <<<
  HAD KERAS 4        dikuatkuasakan oleh kaunter, bukan oleh disiplin
  gerbang ditutup    dalam `finally` — laluan keluar TERMASUK crash
  +1 tepat           selepas SETIAP serah, merentas 15 jadual
  tulis-dahulu       docs/FASA-C-REKOD.md ditulis selepas setiap rekod,
                     di-fsync, supaya ranap tidak menghilangkan nombor
  ABORT = tutup      sebarang anomali menutup gerbang dan berhenti

    python devtools/fasa_c_4rekod.py
"""

import os
import sys
import time
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
AKAR = os.path.dirname(HERE)
sys.path.insert(0, AKAR)

from devtools import peringkat6 as P6                          # noqa: E402
from devtools import fasa_c as FC                              # noqa: E402
from guard.gerbang_serah import (Izin, SerahTidakDiizinkan,    # noqa: E402
                                 diagnosis, semak)

HAD_KERAS = 4
DOK = os.path.join(AKAR, "docs", "FASA-C-REKOD.md")
DIR_BUKTI = os.path.join(AKAR, "docs", "demo-fasa-c", "4rekod")
FAIL_IZIN = os.path.join(AKAR, "izin.json")

DICIPTA = []


# ---------------------------------------------------------------------------
# Rail: tutup gerbang
# ---------------------------------------------------------------------------
def tutup_gerbang(sebab):
    """Tutup gerbang secara KEKAL, bukan sekadar dalam proses ini.

    Menetapkan os.environ tidak mencukupi: ia mati bersama proses.
    Yang benar-benar menutup gerbang ialah ketiadaan fail kebenaran,
    jadi ia dinamakan semula. Larian seterusnya — oleh sesiapa pun —
    bermula tertutup.
    """
    os.environ["MBPG_IZIN_SERAH"] = "0"
    os.environ["MBPG_DRY_RUN"] = "1"
    dinamakan = False
    if os.path.exists(FAIL_IZIN):
        try:
            os.replace(FAIL_IZIN, FAIL_IZIN + ".DITUTUP-AUTO")
            dinamakan = True
        except OSError as e:                                    # noqa: BLE001
            print(f"  [RAIL] AMARAN: fail izin tidak dapat dinamakan "
                  f"semula: {e}")
    print(f"\n  [RAIL] GERBANG DITUTUP — {sebab}")
    print(f"  [RAIL] MBPG_IZIN_SERAH=0  MBPG_DRY_RUN=1  "
          f"fail_izin_dinamakan={dinamakan}")
    try:
        d = diagnosis(Izin.dari_persekitaran(AKAR))
        print(f"  [RAIL] serah_mungkin selepas tutup = {d['serah_mungkin']}")
    except Exception as e:                                      # noqa: BLE001
        print(f"  [RAIL] diagnosis gagal: {e}")


def bukti(drv, tag):
    os.makedirs(DIR_BUKTI, exist_ok=True)
    asas = os.path.join(DIR_BUKTI, tag)
    try:
        drv.get_screenshot_as_file(asas + ".png")
    except Exception:                                           # noqa: BLE001
        pass
    try:
        with open(asas + ".xml", "w", encoding="utf-8") as fh:
            fh.write(drv.page_source)
    except Exception:                                           # noqa: BLE001
        pass
    print(f"    [BUKTI] {tag}")


def tulis_dok(entri):
    """Tambah satu rekod ke docs/FASA-C-REKOD.md dan fsync.

    Ditulis selepas SETIAP rekod, bukan pada penghujung: kalau proses
    ranap pada rekod ke-3, nombor rekod 1 dan 2 mesti tetap ada — ia
    rekod production sebenar yang seseorang perlu batalkan.
    """
    baharu = not os.path.exists(DOK)
    os.makedirs(os.path.dirname(DOK), exist_ok=True)
    with open(DOK, "a", encoding="utf-8") as fh:
        if baharu:
            fh.write("# FASA C — rekod production sebenar yang dicipta\n\n"
                     "> Setiap nombor di bawah ialah rekod HIDUP pada "
                     "production MBPG.\n"
                     "> Pemilik/PM perlu membatalkannya melalui portal.\n\n"
                     "| # | Jenis | No. rekod | No. siri | Masa | Nota |\n"
                     "|---|---|---|---|---|---|\n")
        fh.write("| {n} | {jenis} | `{no_rekod}` | {no_siri} | {masa} "
                 "| {nota} |\n".format(**entri))
        fh.flush()
        os.fsync(fh.fileno())
    print(f"    [DOK] {entri['jenis']} {entri['no_rekod']} ditulis ke "
          f"docs/FASA-C-REKOD.md")


PII = None


def ada_pii(drv):
    """True kalau skrin memaparkan sesuatu yang berbentuk PII sebenar.

    Jaring terakhir sebelum serah. Data oracle kita sendiri (AMIRUL,
    AFIQ, IC ujian) tidak sepatutnya mencetuskannya; nama penuh dengan
    BIN/BINTI/A-L atau alamat berposkod yang muncul TANPA kita menaipnya
    bermakna lookup berlaku dan orang sebenar terlibat.
    """
    global PII
    if PII is None:
        from devtools.imbas_pii import imbas_teks
        PII = imbas_teks
    teks = " | ".join(FC._teks_skrin(drv))
    jumpa = [j for j in PII(teks) if j[0] in ("nama_bin_binti",
                                              "no_kp_bersengkang")]
    return jumpa


# ---------------------------------------------------------------------------
# Aliran
# ---------------------------------------------------------------------------
def sedia(drv, pages, tag):
    from devtools.smoke_tangga import pastikan_di_home
    P6.relaunch(drv, pages, f"{tag}: borang bersih")
    if not pastikan_di_home(drv, pages):
        raise RuntimeError(f"{tag}: tidak sampai skrin utama")


def aliran_n(drv, pages, serial, izin, kiraan):
    from testdata import oracle_n001 as O
    tag = "N-001"
    print(f"\n{'=' * 70}\n== REKOD {kiraan + 1}/{HAD_KERAS} — {tag} "
          f"Notis Amaran\n{'=' * 70}")
    sedia(drv, pages, tag)
    p = pages.notis_amaran
    pages.home.open_notis_amaran()
    p.fill_pesalah_tab(O.SEMUA)
    p.click_seterusnya_from_pesalah()
    p.fill_notis_tab(O.SEMUA)
    p.fill_kompaun_code_fields(O.SEMUA)
    p.take_photos(count=3)
    p.click_seterusnya_from_notis()
    p.fill_penerima_tab(O.SEMUA)
    bukti(drv, f"{tag}-01-pra-serah")
    return _serah(drv, pages, p, tag, "C1-N-001",
                  "local_ekpn_notis_amaran", serial, izin, kiraan)


def aliran_p(drv, pages, serial, izin, kiraan):
    from tests.sweep_kongsi import sedia_borang_kompaun
    from testdata import oracle_pk as OPK
    tag = "P-001"
    print(f"\n{'=' * 70}\n== REKOD {kiraan + 1}/{HAD_KERAS} — {tag} "
          f"Kompaun Pelbagai\n{'=' * 70}")
    sedia(drv, pages, tag)
    P6._pakai_sauh_alamat(serial, OPK.P001, OPK.K001)
    sedia_borang_kompaun(pages, "Kompaun Pelbagai")
    p = pages.daftar_kompaun
    p.fill_kompaun_code_fields(OPK.P001)
    p.take_photos(count=3)
    p.click_seterusnya_from_kompaun()
    p.fill_penerima_tab(OPK.P001)
    bukti(drv, f"{tag}-01-pra-serah")
    return _serah(drv, pages, p, tag, "C2-P-001",
                  "local_ekpn_tawaran_kompaun", serial, izin, kiraan)


def aliran_k(drv, pages, serial, izin, kiraan):
    from tests.sweep_kongsi import sedia_borang_kompaun
    from testdata import oracle_pk as OPK
    tag = "K-001"
    print(f"\n{'=' * 70}\n== REKOD {kiraan + 1}/{HAD_KERAS} — {tag} "
          f"Letak Kereta (TANPA MySIKAP)\n{'=' * 70}")
    sedia(drv, pages, tag)
    P6._pakai_sauh_alamat(serial, OPK.K001, OPK.K001)
    sedia_borang_kompaun(pages, "Kompaun Letak Kereta")
    p = pages.daftar_kompaun
    # Plat ditaip. Butang mySIKAP TIDAK disentuh — lihat nota modul.
    P6._isi_medan_tepat(p, "No. Kereta", OPK.K001["no_kereta"])
    p.fill_kompaun_code_fields(OPK.K001)
    p.take_photos(count=3)
    p.click_seterusnya_from_kompaun()
    p.fill_penerima_tab(OPK.K001)
    bukti(drv, f"{tag}-01-pra-serah")
    return _serah(drv, pages, p, tag, "C3-K-001",
                  "local_ekpn_tawaran_kompaun", serial, izin, kiraan)


def _serah(drv, pages, p, tag, set_id, jadual, serial, izin, kiraan):
    """Gerbang -> jaring PII -> serah -> post-check -> dokumen."""
    from devtools.smoke_tangga import tarik_db
    if kiraan >= HAD_KERAS:
        raise SerahTidakDiizinkan(f"HAD KERAS {HAD_KERAS} dicapai")
    semak(izin, set_id, kiraan)

    jumpa = ada_pii(drv)
    if jumpa:
        bukti(drv, f"{tag}-ABORT-PII")
        raise SerahTidakDiizinkan(
            f"{tag}: skrin pra-serah membawa sesuatu berbentuk PII "
            f"sebenar ({[j[0] for j in jumpa]}). Rekod DIBATALKAN, tidak "
            f"diserah. Ini jaring terakhir peraturan identiti pemilik.")

    db1 = tarik_db(serial, os.path.join(AKAR, "data", "tmp",
                                        f"pra_{tag}.db"))
    sebelum = FC.kira_rekod(db1)
    hasil = FC.serah_dan_tangkap(drv, pages, p, set_id, jadual, serial,
                                 sebelum)
    bukti(drv, f"{tag}-02-selepas-serah")

    entri = {"n": kiraan + 1, "jenis": tag,
             "no_rekod": hasil["no_rekod"], "no_siri": hasil["no_siri"],
             "masa": time.strftime("%Y-%m-%d %H:%M:%S"),
             "nota": "cetak: modul cetak belum diport"}
    tulis_dok(entri)
    DICIPTA.append(entri)
    return hasil


def aliran_nk(drv, pages, serial, izin, kiraan, no_notis):
    """Notis -> Kompaun, menggunakan notis dari rekod (1).

    Aliran ini TIDAK PERNAH dipandu sebelum ini dan tiada recon wujud.
    Ia diletakkan terakhir dengan sengaja: kalau skrin tidak sepadan
    dengan jangkaan, ia dibatalkan tanpa menjejaskan tiga rekod yang
    sudah berjaya.
    """
    tag = "NK-001"
    print(f"\n{'=' * 70}\n== REKOD {kiraan + 1}/{HAD_KERAS} — {tag} "
          f"Notis-ke-Kompaun (notis {no_notis})\n{'=' * 70}")
    sedia(drv, pages, tag)
    bukti(drv, f"{tag}-00-skrin-utama")
    print("  [NK] aliran ini belum pernah dipandu dan tiada recon.")
    print("  [NK] membongkar skrin utama untuk mencari laluan masuk...")
    teks = FC._teks_skrin(drv)
    print(f"  [NK] teks skrin utama: {teks}")
    calon = [t for t in teks
             if "kompaun" in t.lower() and "notis" in t.lower()]
    if not calon:
        raise SerahTidakDiizinkan(
            f"{tag}: tiada laluan masuk 'Notis ke Kompaun' dikenal pasti "
            f"pada skrin utama. Aliran ini tidak pernah direcon. "
            f"DIBATALKAN tanpa serah — tiga rekod pertama tidak "
            f"terjejas. Teks skrin direkod dalam bukti.")
    raise SerahTidakDiizinkan(
        f"{tag}: calon laluan masuk dijumpai {calon}, tetapi aliran "
        f"penuh (pilih notis -> tukar -> serah) belum dibina atau "
        f"direcon. Menyerah melalui laluan yang tidak diketahui secara "
        f"tanpa pengawasan tidak selamat. DIBATALKAN.")


# ---------------------------------------------------------------------------
def main():
    from devtools.smoke_tangga import peringkat_1, peringkat_2
    from device_utils import resolve_udid
    from config import APP_PACKAGE, RECORD_PREFIX

    print("=" * 70)
    print(f"== FASA C — {HAD_KERAS} REKOD PRODUCTION SEBENAR")
    print(f"== prefix {RECORD_PREFIX} | tanpa pengawasan | rail "
          f"fail-closed")
    print("=" * 70)

    izin = Izin.dari_persekitaran(AKAR)
    d = diagnosis(izin)
    for k, v in d.items():
        print(f"  {k:<28} = {v}")
    if not d["serah_mungkin"]:
        print("\nHENTI: serah_mungkin=False. Gerbang tertutup.")
        return 1

    serial = resolve_udid(APP_PACKAGE, verbose=False)
    p1 = peringkat_1(serial)
    if not p1["ok"]:
        tutup_gerbang("peringkat 1 gagal")
        return 1
    P6.baseline_global = p1["baseline"]

    drv = pages = None
    sebab_tutup = "selesai"
    try:
        drv, pages = peringkat_2()
        kiraan = 0

        hasil_n = aliran_n(drv, pages, serial, izin, kiraan)
        kiraan += 1

        aliran_p(drv, pages, serial, izin, kiraan)
        kiraan += 1

        aliran_k(drv, pages, serial, izin, kiraan)
        kiraan += 1

        aliran_nk(drv, pages, serial, izin, kiraan,
                  hasil_n.get("no_rekod"))
        kiraan += 1
        return 0
    except BaseException as e:                                  # noqa: BLE001
        sebab_tutup = f"{type(e).__name__}: {str(e).splitlines()[0][:90]}"
        print(f"\n{'!' * 70}")
        print(f"!! BERHENTI — {type(e).__name__}")
        print(f"{'!' * 70}")
        print(str(e)[:2000])
        if not isinstance(e, SerahTidakDiizinkan):
            traceback.print_exc()
        if drv is not None:
            bukti(drv, "ABORT")
        return 1
    finally:
        tutup_gerbang(sebab_tutup)
        print(f"\n{'=' * 70}")
        print(f"== REKOD DICIPTA: {len(DICIPTA)}/{HAD_KERAS}")
        print("=" * 70)
        for e in DICIPTA:
            print(f"  {e['n']}. {e['jenis']:<8} {e['no_rekod']}  "
                  f"siri {e['no_siri']}  {e['masa']}")
        if DICIPTA:
            print(f"\n  Nombor di atas ialah rekod HIDUP pada production.")
            print(f"  Senarai penuh: docs/FASA-C-REKOD.md")
        if drv is not None:
            c = getattr(drv, "corong", None)
            if c is not None:
                print(f"\n  [CORONG] {c.bil_tap} tap dinilai, "
                      f"{c.bil_sekat} disekat")
            try:
                drv.quit()
            except Exception:                                   # noqa: BLE001
                pass


if __name__ == "__main__":
    sys.exit(main())

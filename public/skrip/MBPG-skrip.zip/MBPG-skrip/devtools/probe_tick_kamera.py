"""
PROBE — kenapa tick kamera tidak menutup kamera.

Keadaan yang disiasat (disahkan pada peranti, 2026-08-12):
  - snap (U+F1BA) BERFUNGSI: 3 tap -> 3 fail dalam cache/Camera/
  - tick (U+F1FD) TIDAK: 1 tap wait_and_click, kemudian 3 tap tap_element,
    kamera kekal terbuka ('FLASH OFF' masih pada pokok view)
  - koordinat betul: pusat bounds tick (880,2181) sepadan dengan tanda ✓
    pada screenshot

Jadi masalahnya BUKAN locator dan BUKAN koordinat. Probe ini mencuba
mekanisme tap yang berbeza satu demi satu dan berhenti pada yang
pertama menutup kamera, supaya pembetulan berdasarkan bukti dan bukan
tekaan.

Skrin kamera tidak membawa satu pun butang trip-wire (hanya flash,
tutup X, galeri, snap, tick), jadi probe ini tidak boleh menyerahkan
apa-apa. X SENGAJA tidak disentuh: gambar dari sesi yang ditutup
dengan X tidak memenuhi validasi GAMBAR MESTI DIAMBIL.

    python devtools/probe_tick_kamera.py
"""

import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
AKAR = os.path.dirname(HERE)
sys.path.insert(0, AKAR)

from appium.webdriver.common.appiumby import AppiumBy          # noqa: E402

TICK = (AppiumBy.ACCESSIBILITY_ID, "")
SNAP = (AppiumBy.ACCESSIBILITY_ID, "")
FLASH = (AppiumBy.ANDROID_UIAUTOMATOR,
         'new UiSelector().textMatches("(?i)\\s*FLASH\\s+OFF\\s*")')


def kamera_terbuka(drv):
    """True kalau 'FLASH OFF' masih dalam pokok view."""
    try:
        drv.find_element(*FLASH)
        return True
    except Exception:                                           # noqa: BLE001
        return False


def atribut_tick(drv):
    """Cetak setiap atribut tick yang boleh menjelaskan tap yang diabaikan."""
    try:
        el = drv.find_element(*TICK)
    except Exception as e:                                      # noqa: BLE001
        print(f"  tick TIDAK DIJUMPAI: {e}")
        return None
    for a in ("enabled", "clickable", "displayed", "focusable",
              "bounds", "class", "package", "content-desc"):
        try:
            print(f"    {a:<14} = {el.get_attribute(a)}")
        except Exception:                                       # noqa: BLE001
            pass
    return el


def main():
    # create_driver(), BUKAN peringkat_2(): peringkat_2 menuntut skrin
    # utama, dan kamera yang terbuka menghalangnya (ia menelan BACK).
    # Probe ini memang perlu melekat pada skrin kamera sedia ada.
    from tests.conftest import create_driver
    print("=" * 68)
    print("== PROBE TICK KAMERA")
    print("=" * 68)

    drv = create_driver()
    try:
        if not kamera_terbuka(drv):
            print("\nHENTI: kamera TIDAK terbuka. Probe ini menjangka skrin "
                  "kamera sedia terbuka daripada run sebelum.")
            return 1
        print("\n  kamera DISAHKAN terbuka.")
        print("\n  -- atribut tick --")
        el = atribut_tick(drv)
        if el is None:
            return 1

        r = el.rect
        cx = r["x"] + r["width"] // 2
        cy = r["y"] + r["height"] // 2
        print(f"\n  pusat tick dikira: ({cx}, {cy})")

        def kaedah_clickgesture():
            drv.execute_script("mobile: clickGesture",
                               {"elementId": el.id})

        def kaedah_elclick():
            el.click()

        def kaedah_longclick():
            drv.execute_script("mobile: longClickGesture",
                               {"elementId": el.id, "duration": 200})

        def kaedah_w3c_tahan():
            """Tap dengan jeda turun/naik 150ms.

            Sesetengah Pressable RN mendaftar pada onPressOut selepas
            ambang; tap sifar-tempoh boleh dijatuhkan sepenuhnya.
            """
            from selenium.webdriver.common.action_chains import ActionChains
            from selenium.webdriver.common.actions import interaction
            from selenium.webdriver.common.actions.action_builder import \
                ActionBuilder
            from selenium.webdriver.common.actions.pointer_input import \
                PointerInput
            a = ActionChains(drv)
            jari = PointerInput(interaction.POINTER_TOUCH, "jari")
            a.w3c_actions = ActionBuilder(drv, mouse=jari)
            a.w3c_actions.pointer_action.move_to_location(cx, cy)
            a.w3c_actions.pointer_action.pointer_down()
            a.w3c_actions.pointer_action.pause(0.15)
            a.w3c_actions.pointer_action.release()
            a.perform()

        kaedah = [
            ("mobile: clickGesture", kaedah_clickgesture),
            ("el.click()", kaedah_elclick),
            ("W3C tap tahan 150ms", kaedah_w3c_tahan),
            ("mobile: longClickGesture 200ms", kaedah_longclick),
        ]

        for nama, fn in kaedah:
            print(f"\n  -- cuba: {nama}")
            try:
                fn()
            except Exception as e:                              # noqa: BLE001
                print(f"     RALAT: {type(e).__name__}: {e}")
                continue
            time.sleep(2.5)
            if not kamera_terbuka(drv):
                print(f"     >>> BERJAYA: kamera TERTUTUP melalui {nama} <<<")
                return 0
            print("     kamera masih terbuka")

        print("\n  SEMUA kaedah Appium gagal menutup kamera.")
        print("  Kamera ini menerima tap pada SNAP tetapi mengabaikan tap "
              "pada TICK melalui setiap mekanisme Appium.")
        return 2
    finally:
        try:
            drv.quit()
        except Exception:                                       # noqa: BLE001
            pass


if __name__ == "__main__":
    sys.exit(main())

"""
FASA C — laluan E2E (create → print → submit). BERKUNCI.

Dibina mengikut docs/SPEC-FASA-C-E2E-MBPG.md. Ia TIDAK boleh menyerah
dalam keadaan repo semasa, dan itu bukan kebetulan konfigurasi — ia
empat kunci berasingan yang setiap satu lalai kepada DISEKAT:

    1. MBPG_DRY_RUN mesti '0'                    (lalai '1')
    2. MBPG_IZIN_SERAH + medan ISI-SINI diisi    (lalai kosong)
    3. set_id dalam whitelist                    (lalai KOSONG)
    4. kiraan < had N                            (lalai N=0)

Di atas keempat-empatnya, dua lagi:
    5. pengesahan manusia per-serah, TTY wajib   (guard/sahkan_manual)
    6. corong tap — SERAH/HANTAR kekal trip-wire

Menjalankan fail ini hari ini akan mencetak diagnosis dan keluar.
Ia TIDAK menyentuh peranti melainkan keempat-empat lapisan lulus.

    python devtools/fasa_c.py --diagnosis    # cetak keadaan kunci
    python devtools/fasa_c.py --set SET-ID   # akan ditolak lapisan 3
"""

import argparse
import json
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
AKAR = os.path.dirname(HERE)
sys.path.insert(0, AKAR)

from guard.gerbang_serah import (Izin, SerahTidakDiizinkan,   # noqa: E402
                                 diagnosis, semak)
from guard import sahkan_manual                               # noqa: E402
from pages import printer_tsc                                 # noqa: E402

LEDGER = os.path.join(AKAR, "reports", "LEDGER-E2E.jsonl")


class PostCheckGagal(BaseException):
    """Post-check selepas serah tidak menemui TEPAT 1 rekod baharu."""


# ---------------------------------------------------------------------------
# Post-check: TEPAT satu rekod
# ---------------------------------------------------------------------------
def kira_rekod(db):
    """Kiraan baris bagi SETIAP jadual transaksi.

    >>> DILUASKAN 2026-08-12 daripada tiga jadual kepada lima belas. <<<
    Senarai tiga-jadual lama melaporkan "bersih" sepanjang hari
    sedangkan `local_ekpn_notis_amaran_details` mengumpul baris dengan
    nombor notis yang diperuntukkan. Post-check yang mendakwa "0 rekod"
    mesti memeriksa setiap tempat rekod boleh muncul.
    """
    import sqlite3
    from devtools.smoke_tangga import JADUAL_REKOD
    c = sqlite3.connect(db)
    kira = {}
    for t in JADUAL_REKOD:
        try:
            kira[t] = c.execute(f'SELECT COUNT(*) FROM "{t}"').fetchone()[0]
        except sqlite3.Error:
            pass                    # jadual tiada pada build ini
    c.close()
    return kira


def semak_satu_rekod(sebelum, selepas, jadual_dijangka):
    """Sahkan TEPAT satu rekod baharu, dalam jadual yang dijangka.

    Spec §4.6: "1 rekod baru, nombor PGP03 betul". Fungsi ini
    mengendalikan bahagian KIRAAN; nombor disemak oleh pemanggil
    daripada DB.

    Tiga cara ini boleh gagal, dan ketiga-tiganya dibezakan kerana
    maknanya sangat berlainan:
      0 baharu  -> serah tidak menjadi. Rekod TIADA. Jangan ulang buta.
      >1 baharu -> serah menjadi LEBIH sekali. Itu paling teruk:
                   rekod tambahan wujud pada production dan seseorang
                   perlu melupuskannya.
      jadual lain berubah -> sesuatu selain yang dijangka tersentuh.
    """
    delta = {t: selepas.get(t, 0) - sebelum.get(t, 0)
             for t in set(sebelum) | set(selepas)}

    # >>> JADUAL IRINGAN — DIUKUR, BUKAN DIANDAIKAN. <<<
    # Serah pertama yang sebenar (PGP02N260813006, 2026-08-13)
    # menunjukkan satu notis TIDAK menulis satu baris. Ia menulis:
    #     local_ekpn_notis_amaran          +1   rekod itu sendiri
    #     local_ekpn_notis_amaran_details  +1   baris butiran
    #     local_ekpn_tawaran_kompaun_doc   +4   satu setiap gambar
    #     local_ekpn_penerima_cetakan      +1   penerima/cetakan
    # Versi pertama semakan ini menuntut HANYA jadual notis berubah,
    # jadi ia menghentikan run selepas rekod sudah dicipta dengan
    # betul -- melaporkan bentuk NORMAL sebagai anomali. Itu kegagalan
    # ke arah selamat, tetapi ia tetap salah, dan ia berhenti tepat
    # sebelum cetakan.
    #
    # Jadual iringan dibenarkan BERTAMBAH; ia masih tidak boleh
    # BERKURANG, dan jadual di luar senarai ini masih menghentikan run.
    IRINGAN = {
        "local_ekpn_notis_amaran_details",
        "local_ekpn_tawaran_kompaun_details",
        "local_ekpn_sita_details",
        "local_ekpn_tawaran_kompaun_doc",
        "local_ekpn_notis_amaran_patuh_doc",
        "local_ekpn_sita_doc",
        "local_ekpn_penerima_cetakan",
    }
    lain = {t: d for t, d in delta.items()
            if t != jadual_dijangka and d != 0
            and not (t in IRINGAN and d > 0)}
    if lain:
        raise PostCheckGagal(
            f"jadual TIDAK DIJANGKA berubah: {lain}. Dijangka hanya "
            f"{jadual_dijangka} bertambah 1. HENTI — jangan sentuh "
            f"apa-apa lagi.")
    n = delta.get(jadual_dijangka, 0)
    if n == 1:
        return True
    if n == 0:
        raise PostCheckGagal(
            f"TIADA rekod baharu dalam {jadual_dijangka}. Serah tidak "
            f"menjadi. JANGAN ulang secara buta — periksa dahulu sama "
            f"ada rekod separa wujud.")
    raise PostCheckGagal(
        f"{n} rekod baharu dalam {jadual_dijangka}, dijangka TEPAT 1. "
        f"Rekod berlebihan wujud pada production dan perlu dilupuskan. "
        f"HENTI serta-merta.")


# ---------------------------------------------------------------------------
# Ledger E2E
# ---------------------------------------------------------------------------
def kiraan_borang_dari_ledger(borang, ledger=None):
    """Berapa rekod borang `borang` sudah SEBENARNYA dicipta.

    >>> KENAPA INI WUJUD. <<<
    Lapisan 6 gerbang menguatkuasakan kuota terhadap `kiraan_borang`
    yang dihantar oleh PEMANGGIL, dan lalainya 0. Jadi kuota itu hanya
    bermakna dalam satu proses: menjalankan semula pemandu selepas
    rekod pertama berjaya akan lulus gerbang sekali lagi dan mencipta
    rekod KEDUA, walaupun kuota berkata satu.

    Itu bukan hipotetikal — selepas PGP02N260813006 dicipta, satu
    `python devtools/kerja2a_n001.py` lagi akan menciptanya lagi.

    Ledger ialah sumber yang betul: ia append-only, di-fsync selepas
    setiap baris, dan ia merekod apa yang kita benar-benar cipta —
    bukan apa yang kita bercadang untuk cipta.
    """
    import json
    ledger = ledger or LEDGER
    if not os.path.exists(ledger):
        return 0
    n = 0
    with open(ledger, encoding="utf-8") as fh:
        for baris in fh:
            baris = baris.strip()
            if not baris:
                continue
            try:
                e = json.loads(baris)
            except ValueError:
                continue
            if e.get("peristiwa") != "rekod-dicipta":
                continue
            # set_id berbentuk C1-N-001 / C2-P-001 / C3-K-001; huruf
            # borang ialah segmen tengah.
            bahagian = str(e.get("set_id", "")).split("-")
            if len(bahagian) >= 2 and bahagian[1].upper() == borang.upper():
                n += 1
    return n


def catat_ledger(entri):
    """Satu baris per rekod SEBENAR yang dicipta. fsync — jejak audit
    tidak boleh hilang kerana proses mati."""
    os.makedirs(os.path.dirname(LEDGER), exist_ok=True)
    with open(LEDGER, "a", encoding="utf-8") as fh:
        fh.write(json.dumps(entri, ensure_ascii=False) + "\n")
        fh.flush()
        os.fsync(fh.fileno())


# ---------------------------------------------------------------------------
# Laluan serah (setiap langkah di belakang gerbang)
# ---------------------------------------------------------------------------
def serah_satu_set(drv, pages, s, data, izin, kiraan, serial):
    """Satu serah, hujung ke hujung. Setiap gerbang SEBELUM tap.

    Urutan mengikut spec §4. Langkah 1-3 (isi + dropdown) ialah laluan
    fill-only yang sudah terbukti dalam Fasa 1/2 — ia tidak mencipta
    apa-apa. Gerbang berada tepat sebelum langkah 5, di mana rekod
    sebenar mula wujud.
    """
    from devtools import peringkat6 as P6
    from devtools.smoke_tangga import tarik_db

    set_id = s["set_id"]

    # --- gerbang DAHULU. Tiada borang dibuka kalau serah mustahil. ---
    semak(izin, set_id, kiraan)
    printer_tsc.sahkan_terkunci()

    # --- langkah 1-3: isi (fill-only, tiada rekod) ---
    P6.borang_kompaun(drv, pages, s.get("jenis", "Kompaun Pelbagai"),
                      data, (), (), f"FASA-C-{set_id}")

    # --- langkah 4: RINGKASAN + pengesahan manusia ---
    ringkasan = {
        "set_id": set_id,
        "kod_kompaun": s["kod_kompaun"]["nama"],
        "akta": s["akta"]["nama"],
        "kesalahan": s["kesalahan"]["keterangan"][:70],
        "denda": data.get("kadar_denda", "-"),
        "nama_pesalah": data.get("nama_pesalah", "-"),
        "no_kp": data.get("no_kp_ssm_kereta", "-"),
        "AMARAN": "rekod SEBENAR akan dicipta pada production",
    }
    sahkan_manual.sahkan(set_id, ringkasan)

    # --- baseline sebelum serah ---
    db_sebelum = tarik_db(serial, os.path.join(AKAR, "data", "tmp",
                                               f"fasac_pra_{set_id}.db"))
    sebelum = kira_rekod(db_sebelum)

    # --- langkah 5: serah sebenar ---
    return serah_dan_tangkap(drv, pages, pages.daftar_kompaun, set_id,
                             "local_ekpn_tawaran_kompaun", serial,
                             sebelum)


# ---------------------------------------------------------------------------
# Serah sebenar — SATU tempat dalam seluruh suite yang mencipta rekod
# ---------------------------------------------------------------------------
def serah_dan_tangkap(drv, pages, p, set_id, jadual, serial, sebelum,
                      kunci_nombor=None):
    """Tekan MENYERAHKAN -> HANTAR, kemudian buktikan TEPAT satu rekod.

    >>> INILAH SATU-SATUNYA KOD DALAM SUITE YANG MENCIPTA REKOD. <<<

    Permit dipasang TEPAT sebelum tap dan ditanggalkan dalam `finally`,
    walaupun berlaku exception. Ia bukan suis global: `PermitSerah`
    dinamakan kepada satu set_id dan berhad kepada SATU rekod, jadi
    walaupun kod selepas ini tersilap menekan butang serah sekali lagi,
    permit sudah habis dan corong menyekatnya.

    Dialog pengesahan DISAHKAN pada peranti (2026-08-12):

        X  /  SIMPAN MAKLUMAT INI ?  /  HANTAR

    Hanya DUA kawalan: [X] dan [HANTAR]. TIADA BATAL. MENYERAHKAN
    membuka dialog dan TIDAK menyimpan; HANTAR yang mencipta rekod.

    Nombor rekod dibaca dari DB, bukan dari popup kejayaan. Popup
    bergantung pada `RECORD_PREFIX` yang betul dan pada teks yang boleh
    berubah antara build; DB ialah tempat rekod itu benar-benar wujud.
    """
    import time
    from guard.dasar import PermitSerah
    from devtools.smoke_tangga import tarik_db

    tetapan = drv.corong.tetapan
    print(f"\n  [SERAH] {set_id}: memasang permit berskop (had 1)")
    tetapan.permit_serah = PermitSerah(set_id, had=1)
    teks_dialog = []
    try:
        p.click_menyerahkan()
        time.sleep(2.5)
        teks_dialog = _teks_skrin(drv)
        print(f"  [SERAH] dialog: {teks_dialog}")
        catat_ledger({"peristiwa": "dialog-serah", "set_id": set_id,
                      "teks": teks_dialog})
        # >>> Rekod dicipta pada baris ini. <<<
        p.confirm_and_submit()
        time.sleep(5)
    finally:
        tetapan.permit_serah = None
        print("  [SERAH] permit DITANGGALKAN")

    # >>> TUNGGU MUAT NAIK SELESAI SEBELUM MEMBACA DB. <<<
    # Larian pemilik memulangkan no_rekod=None kerana DB dibaca semasa
    # skrin masih menunjukkan 'MEMUAT NAIK GAMBAR... 70%'. Baris rekod
    # belum ditulis pada ketika itu, jadi bacaan mendapat None dan
    # nombor rekod HILANG walaupun rekod kemudiannya wujud pada
    # production. Nombor yang hilang bermakna tiada siapa tahu apa yang
    # perlu dibatalkan.
    hasil = _tunggu_muat_naik(drv)
    print(f"  [SERAH] skrin selepas hantar: {hasil}")

    # --- post-check: TEPAT satu rekod, dalam jadual yang dijangka ---
    db2 = tarik_db(serial, os.path.join(AKAR, "data", "tmp",
                                        f"fasac_pasca_{set_id}.db"))
    selepas = kira_rekod(db2)
    semak_satu_rekod(sebelum, selepas, jadual)

    no_rekod, no_siri = _baca_nombor(db2, jadual, kunci_nombor)
    if not no_rekod:
        # Sandaran: popup cetak menyatakan nombornya sendiri.
        # 'No Notis: PGP02N260813007' / 'No Kompaun: PGP02P260813001'.
        no_rekod = _nombor_dari_popup(hasil)
        if no_rekod:
            print(f"  [SERAH] DB belum menulis nombor; diambil dari "
                  f"popup cetak: {no_rekod}")
            catat_ledger({"peristiwa": "nombor-dari-popup",
                          "set_id": set_id, "no_rekod": no_rekod,
                          "sebab": "DB memulangkan None selepas muat naik"})
    print(f"  [SERAH] {set_id}: rekod {no_rekod!r}  siri {no_siri!r}")
    if not no_rekod:
        raise PostCheckGagal(
            f"{set_id}: rekod DICIPTA (post-check lulus) tetapi "
            f"nombornya TIDAK dapat dibaca dari DB mahupun dari popup. "
            f"Skrin: {hasil}. Nombor yang hilang bermakna tiada siapa "
            f"tahu apa yang perlu dibatalkan — cari secara manual dalam "
            f"Senarai SEBELUM menjalankan apa-apa lagi.")
    catat_ledger({"peristiwa": "rekod-dicipta", "set_id": set_id,
                  "jadual": jadual, "no_rekod": no_rekod,
                  "no_siri": no_siri, "teks_kejayaan": hasil})
    return {"set_id": set_id, "no_rekod": no_rekod, "no_siri": no_siri,
            "jadual": jadual, "dialog": teks_dialog, "kejayaan": hasil}


import re as _re

# Muat naik gambar berjalan SELEPAS HANTAR dan baris rekod belum
# ditulis sehingga ia selesai. Skrin menunjukkan 'MEMUAT NAIK
# GAMBAR...' dengan peratusan yang menaik.
MUAT_NAIK = _re.compile(r"memuat\s*naik|uploading|\b\d{1,3}\s*%", _re.I)
_NOMBOR_POPUP = _re.compile(
    r"no\s+(?:notis|kompaun)\s*:\s*([A-Z0-9]+)", _re.I)


def _tunggu_muat_naik(drv, saat=180, senyap=6):
    """Tunggu sehingga penunjuk muat naik HILANG. Pulangkan teks akhir.

    `senyap` ialah berapa saat berturut-turut skrin mesti bebas
    daripada penunjuk sebelum kami percaya ia selesai — peratusan
    boleh melompat 100% seketika di tengah jalan, dan membaca DB pada
    saat itu memberi None yang sama seperti membaca pada 70%.
    """
    tamat = time.time() + saat
    bersih_sejak = None
    teks = _teks_skrin(drv)
    while time.time() < tamat:
        teks = _teks_skrin(drv)
        sedang = any(MUAT_NAIK.search(t) for t in teks)
        if sedang:
            bersih_sejak = None
            petunjuk = [t for t in teks if MUAT_NAIK.search(t)]
            print(f"  [SERAH] muat naik berjalan: {petunjuk}")
            time.sleep(3)
            continue
        if bersih_sejak is None:
            bersih_sejak = time.time()
        elif time.time() - bersih_sejak >= senyap:
            return teks
        time.sleep(2)
    print(f"  [SERAH] AMARAN: penunjuk muat naik masih ada selepas "
          f"{saat}s — meneruskan, nombor mungkin belum ditulis")
    return teks


def _nombor_dari_popup(teks):
    """Nombor rekod dari popup cetak, atau None."""
    for t in teks:
        m = _NOMBOR_POPUP.search(t)
        if m:
            return m.group(1)
    return None


def _teks_skrin(drv):
    import xml.etree.ElementTree as ET
    keluar = []
    try:
        akar = ET.fromstring(drv.page_source.encode("utf-8"))
    except Exception:                                         # noqa: BLE001
        return keluar
    for n in akar.iter():
        for atr in ("text", "content-desc"):
            v = (n.get(atr) or "").strip()
            if v and v not in keluar:
                keluar.append(v)
    return keluar


# Lajur nombor rekod bagi setiap jadual, DISAHKAN dari skema peranti.
KUNCI_NOMBOR = {
    "local_ekpn_notis_amaran": "nonotis",
    "local_ekpn_tawaran_kompaun": "nokompaun",
    "local_ekpn_sita": "nosita",
}


def _baca_nombor(db, jadual, kunci=None):
    """(no_rekod, no_siri) bagi baris TERBARU dalam `jadual`.

    no_siri diambil dari `local_system_control.newserial`, iaitu
    pembilang yang app gunakan untuk menjana nombor itu.
    """
    import sqlite3
    kunci = kunci or KUNCI_NOMBOR.get(jadual)
    c = sqlite3.connect(db)
    no_rekod = None
    try:
        kol = [r[1] for r in c.execute(f'PRAGMA table_info("{jadual}")')]
        if kunci and kunci in kol:
            baris = c.execute(
                f'SELECT "{kunci}" FROM "{jadual}" ORDER BY rowid DESC '
                f'LIMIT 1').fetchone()
            no_rekod = baris[0] if baris else None
    except sqlite3.Error:
        pass
    no_siri = None
    try:
        baris = c.execute(
            "SELECT newserial FROM local_system_control WHERE tablename=?",
            (jadual,)).fetchone()
        no_siri = baris[0] if baris else None
    except sqlite3.Error:
        pass
    c.close()
    return no_rekod, no_siri


# ---------------------------------------------------------------------------
# Titik masuk
# ---------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--diagnosis", action="store_true")
    ap.add_argument("--set", dest="set_id", default=None)
    a = ap.parse_args()

    izin = Izin.dari_persekitaran(AKAR)
    d = diagnosis(izin)

    print("=" * 70)
    print("== FASA C — status kunci")
    print("=" * 70)
    for k, v in d.items():
        tanda = "OK " if (v is True or (isinstance(v, int) and v > 0)) \
            else "KUNCI"
        print(f"  [{tanda}] {k:<28} = {v}")
    print(f"\n  printer: ", end="")
    try:
        printer_tsc.sahkan_terkunci()
        print("TERKUNCI (hantar() membangkitkan PayloadTerkunci)")
    except SerahTidakDiizinkan as e:
        print(f"TIDAK TERKUNCI — {e}")
        return 1
    print(f"  ledger : {LEDGER} "
          f"({'wujud' if os.path.exists(LEDGER) else 'belum dicipta'})")

    if d["serah_mungkin"]:
        print("\n  AMARAN: keempat-empat lapisan LULUS. Serah MUNGKIN "
              "pada run ini.")
    else:
        print("\n  Serah MUSTAHIL dengan konfigurasi ini. Ini keadaan "
              "yang dijangka.")

    if a.diagnosis or not a.set_id:
        return 0

    # Percubaan sebenar — akan ditolak oleh lapisan yang gagal.
    try:
        semak(izin, a.set_id, 0)
    except SerahTidakDiizinkan as e:
        print(f"\n  DITOLAK:\n  {e}")
        return 2
    print("\n  Keempat-empat lapisan lulus untuk set ini. Laluan serah "
          "sebenar belum ditulis — lihat serah_satu_set().")
    return 0


if __name__ == "__main__":
    sys.exit(main())

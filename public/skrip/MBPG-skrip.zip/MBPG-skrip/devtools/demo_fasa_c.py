"""
DEMO FASA C — pandu laluan, berhenti sebelum serah.

Pemilik memerhati perangai pada peranti production. TIADA serah,
TIADA cetak, TIADA rekod.

>>> KENAPA FAIL INI WUJUD BERASINGAN DARIPADA fasa_c.serah_satu_set(). <<<
Dalam laluan SEBENAR, gerbang dipanggil PERTAMA — sebelum borang
dibuka. Itu betul: kalau serah mustahil, tiada sebab menyentuh
peranti langsung.

Tetapi demo ini perlu menunjukkan laluan DIPANDU dahulu, kemudian
gerbang menyekat pada titik serah. Kalau saya menyusun semula
`serah_satu_set()` untuk memindahkan gerbang ke belakang supaya demo
kelihatan lebih baik, saya akan melemahkan laluan sebenar demi
persembahan. Jadi demo tinggal di sini, dan laluan sebenar kekal
gerbang-dahulu.

Apa yang demo ini buktikan:
  * laluan isi + 3 dropdown + read-back berfungsi pada peranti
  * skrin ringkasan memaparkan apa yang AKAN diserah
  * gerbang menyekat pada titik serah — LANGSUNG pada peranti,
    bukan mock
  * back out bersih, 0 rekod baharu

    python devtools/demo_fasa_c.py [--set SET-ID]
"""

import argparse
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
AKAR = os.path.dirname(HERE)
sys.path.insert(0, AKAR)

from guard.gerbang_serah import (Izin, SerahTidakDiizinkan,   # noqa: E402
                                 diagnosis, semak)
from guard import sahkan_manual                               # noqa: E402
from pages import printer_tsc                                 # noqa: E402
from devtools import peringkat6 as P6                         # noqa: E402

DIR_BUKTI = os.path.join(AKAR, "docs", "demo-fasa-c")
SET_LALAI = "SET-KK01-AKT2-111"

URUTAN = []


def bukti(pages, tag):
    """Screenshot + dump setiap peringkat, dinomborkan mengikut urutan
    supaya rakaman boleh dibaca semula sebagai satu jujukan."""
    os.makedirs(DIR_BUKTI, exist_ok=True)
    n = len(URUTAN) + 1
    asas = os.path.join(DIR_BUKTI, f"{n:02d}-{tag}")
    drv = pages.daftar_kompaun.driver
    try:
        drv.get_screenshot_as_file(asas + ".png")
    except Exception:                                         # noqa: BLE001
        pass
    try:
        with open(asas + ".xml", "w", encoding="utf-8") as fh:
            fh.write(drv.page_source)
    except Exception:                                         # noqa: BLE001
        pass
    URUTAN.append(tag)
    print(f"  [BUKTI {n:02d}] {tag} -> docs/demo-fasa-c/{n:02d}-{tag}.png")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--set", dest="set_id", default=SET_LALAI)
    a = ap.parse_args()

    from device_utils import resolve_udid
    from config import APP_PACKAGE
    from devtools.smoke_tangga import (peringkat_1, peringkat_2,
                                       pastikan_di_home, tarik_db)
    from testdata import sets_loader as SL
    from tests.sweep_kongsi import sedia_borang_kompaun
    from pages.sweep_kombo import sapu_satu_set

    print("=" * 70)
    print("== DEMO FASA C — pandu laluan, BERHENTI sebelum serah")
    print("=" * 70)

    # ---- PRA-SYARAT: gerbang mesti TERKUNCI sepanjang demo ----
    izin = Izin.dari_persekitaran(AKAR)
    d = diagnosis(izin)
    for k, v in d.items():
        print(f"  [{'OK ' if v is True else 'KUNCI'}] {k:<28} = {v}")
    if d["serah_mungkin"]:
        print("\nHENTI: serah_mungkin=True. Demo ini menuntut gerbang "
              "KEKAL terkunci. Jangan jalankan demo dengan kebenaran "
              "hidup.")
        return 1
    printer_tsc.sahkan_terkunci()
    print("  printer TERKUNCI. serah_mungkin=False. Demo selamat "
          "diteruskan.\n")

    serial = resolve_udid(APP_PACKAGE, verbose=False)
    sets = [s for s in SL.muat_semua() if s["set_id"] == a.set_id]
    if not sets:
        print(f"HENTI: set {a.set_id} tidak dijumpai.")
        return 1
    s = sets[0]
    print(f"  set      : {s['set_id']}")
    print(f"  tingkat 1: {s['kod_kompaun']['nama']}")
    print(f"  tingkat 2: {s['akta']['nama']}")
    print(f"  tingkat 3: {s['kesalahan']['keterangan'][:58]}...\n")

    p1 = peringkat_1(serial)
    if not p1["ok"]:
        return 1
    baseline = p1["baseline"]
    P6.baseline_global = baseline

    drv = pages = None
    try:
        drv, pages = peringkat_2()
        bukti(pages, "skrin-utama")

        # ---- borang bersih ----
        P6.relaunch(drv, pages, "demo Fasa C: borang bersih")
        if not pastikan_di_home(drv, pages):
            print("HENTI: tidak sampai skrin utama.")
            return 1

        # ---- isi Pesalah (sauh alamat berposkod) + tab Kompaun ----
        print("\n-- isi Pesalah (sauh alamat berposkod) --")
        sedia_borang_kompaun(pages, "Kompaun Pelbagai")
        bukti(pages, "pesalah-diisi-tab-kompaun")

        # ---- 3 dropdown + read-back + baca denda ----
        print("\n-- pilih 3 dropdown + read-back --")
        kep = sapu_satu_set(pages.daftar_kompaun, s, "P")
        bukti(pages, "tiga-dropdown-dipilih")
        print(f"  kompaun_ok={kep.kompaun_ok} akta_ok={kep.akta_ok} "
              f"kesalahan_ok={kep.kesalahan_ok} denda={kep.denda!r}")
        if kep.catatan:
            print(f"  catatan: {kep.catatan[:150]}")

        # ---- RINGKASAN PRA-SERAH ----
        print("\n-- skrin ringkasan / pra-serah --")
        ringkasan = {
            "set_id": s["set_id"],
            "kod_kompaun": s["kod_kompaun"]["nama"],
            "akta": s["akta"]["nama"],
            "kesalahan": s["kesalahan"]["keterangan"][:60] + "...",
            "denda dipapar app": kep.denda or "(tidak dibaca)",
            "3 dropdown": f"{kep.kompaun_ok}/{kep.akta_ok}/"
                          f"{kep.kesalahan_ok}",
            "AMARAN": "inilah yang AKAN diserah kalau Fasa C hidup",
        }
        sahkan_manual.papar_ringkasan(ringkasan)
        bukti(pages, "ringkasan-pra-serah")

        # ---- TITIK SERAH: gerbang mesti menyekat, PADA PERANTI ----
        print("\n-- TITIK SERAH — gerbang dinilai pada peranti --")
        disekat = False
        try:
            semak(izin, s["set_id"], 0)
            print("  !!! gerbang LULUS — ini TIDAK dijangka dalam demo")
        except SerahTidakDiizinkan as e:
            disekat = True
            # ASCII sahaja pada baris ini: konsol Windows lalai
            # cp1252 dan '->' unicode meletupkan larian pada TITIK
            # PALING PENTING dalam demo — betul-betul selepas gerbang
            # menyekat. Diperhati 2026-08-12.
            print("  [DEMO] serah_mungkin=False -> berhenti di "
                  "ringkasan, back out")
            print(f"  [GERBANG] {str(e).splitlines()[0]}")
            P6._catat_ledger(drv, "demo-fasa-c-gerbang-menyekat",
                             str(e).splitlines()[0])
        bukti(pages, "gerbang-menyekat-sebelum-serah")

        if not disekat:
            print("\nHENTI: gerbang TIDAK menyekat. Jangan teruskan.")
            return 1

        # ---- BACK OUT tanpa serah ----
        print("\n-- BACK OUT tanpa serah --")
        P6._keluar_ke_home(pages, "demo-fasa-c")
        bukti(pages, "back-out-skrin-utama")

        # ---- POST-CHECK ----
        print("\n-- post-check --")
        bersih = P6.post_check(serial, baseline, "DEMO-FASA-C")

        print("\n" + "=" * 70)
        print("== RINGKASAN DEMO FASA C")
        print("=" * 70)
        print("  urutan skrin:")
        for i, t in enumerate(URUTAN, 1):
            print(f"    {i:02d}. {t}")
        print(f"\n  gerbang pada titik serah : DISEKAT (lapisan 1)")
        print(f"  serah_mungkin            : False sepanjang demo")
        print(f"  printer                  : TERKUNCI")
        print(f"  post-check               : "
              f"{'BERSIH — 0 rekod baharu' if bersih else 'GAGAL'}")
        print(f"  bukti                    : docs/demo-fasa-c/ "
              f"({len(URUTAN)} peringkat)")
        return 0 if bersih else 1
    finally:
        if drv is not None:
            c = getattr(drv, "corong", None)
            if c is not None:
                print(f"\n  [CORONG] {c.bil_tap} tap dinilai, "
                      f"{c.bil_sekat} disekat"
                      + (f" | DIBATALKAN: {c.dibatalkan}"
                         if c.dibatalkan else ""))
            try:
                drv.quit()
            except Exception:                                 # noqa: BLE001
                pass


if __name__ == "__main__":
    sys.exit(main())

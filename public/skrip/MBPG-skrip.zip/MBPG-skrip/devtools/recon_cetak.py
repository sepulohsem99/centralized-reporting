"""
RECON — skrin cetak / printer MBPG. BACA SAHAJA.

>>> KENAPA RECON DAHULU, BUKAN PORT TERUS. <<<
Modul cetak MBJB ialah 1,388 baris, dan ia tidak sekadar panjang: ia
menentukan sambungan printer dengan MEMBACA WARNA PIKSEL ikon,
menskrol popup Bluetooth, dan menaip kata laluan pasangan. Setiap
andaian itu disahkan pada perkakasan MBJB, bukan MBPG, dan skrin cetak
MBPG belum pernah dilihat sekali pun.

Port buta ke skrin yang tidak pernah dilihat akan mengulang tepat
kesilapan kamera: locator sebenarnya BETUL, tetapi dua andaian
tersembunyi memecahkannya, dan hanya larian sebenar mendedahkannya.

Skrip ini melihat dahulu.

TIADA CETAKAN. TIADA sambungan dibuat. Butang CETAK dan Connect TIDAK
ditekan — hanya popup dibuka dan dibongkar, kemudian ditutup.

    python devtools/recon_cetak.py
"""

import os
import re
import sys
import time
import xml.etree.ElementTree as ET

HERE = os.path.dirname(os.path.abspath(__file__))
AKAR = os.path.dirname(HERE)
sys.path.insert(0, AKAR)

from devtools import peringkat6 as P6                          # noqa: E402

DIR_RECON = os.path.join(AKAR, "docs", "recon")

# Glif ikon printer dari MBJB (printer_utils.IKON_PRINTER_GLIF).
# U+F042A. Ditulis sebagai escape supaya encoding console tidak boleh
# merosakkannya -- pelajaran dari glif kamera.
GLIF_PRINTER = "\U000f042a"


def nod(drv):
    try:
        akar = ET.fromstring(drv.page_source.encode("utf-8"))
    except Exception:                                           # noqa: BLE001
        return []
    keluar = []
    for n in akar.iter():
        keluar.append({
            "kelas": (n.get("class") or "").split(".")[-1],
            "text": (n.get("text") or "").strip(),
            "desc": (n.get("content-desc") or "").strip(),
            "rid": (n.get("resource-id") or "").strip(),
            "klik": (n.get("clickable") or ""),
            "bounds": n.get("bounds") or "",
        })
    return keluar


def papar(ns, tajuk, tapis):
    print(f"\n  ---- {tajuk} ----")
    n = 0
    for d in ns:
        if not tapis(d):
            continue
        n += 1
        kod = ""
        for f in ("text", "desc"):
            for ch in d[f]:
                if ord(ch) > 0x2000:
                    kod += f" [U+{ord(ch):04X}]"
        print(f"    {d['kelas']:<13} klik={d['klik']:<5} {d['bounds']:<24}"
              f"{kod}")
        for f, lbl in (("text", "text"), ("desc", "desc"), ("rid", "rid")):
            if d[f]:
                print(f"        {lbl} = {d[f]!r}")
    if not n:
        print("    (tiada)")
    return n


def bukti(drv, tag):
    os.makedirs(DIR_RECON, exist_ok=True)
    asas = os.path.join(DIR_RECON, f"cetak-{tag}")
    try:
        drv.get_screenshot_as_file(asas + ".png")
    except Exception:                                           # noqa: BLE001
        pass
    try:
        with open(asas + ".xml", "w", encoding="utf-8") as fh:
            fh.write(drv.page_source)
    except Exception:                                           # noqa: BLE001
        pass
    print(f"    [BUKTI] cetak-{tag}")


def main():
    from devtools.smoke_tangga import peringkat_1, peringkat_2, \
        pastikan_di_home
    from device_utils import resolve_udid
    from config import APP_PACKAGE

    print("=" * 70)
    print("== RECON SKRIN CETAK / PRINTER — MBPG 2.1.21")
    print("== BACA SAHAJA. Tiada cetakan, tiada sambungan.")
    print("=" * 70)

    serial = resolve_udid(APP_PACKAGE, verbose=False)
    p1 = peringkat_1(serial)
    if not p1["ok"]:
        return 1
    P6.baseline_global = p1["baseline"]

    drv = pages = None
    try:
        drv, pages = peringkat_2()
        P6.relaunch(drv, pages, "recon cetak")
        if not pastikan_di_home(drv, pages):
            print("HENTI: tidak sampai skrin utama")
            return 1

        # ---------------------------------------------------------------
        print(f"\n{'=' * 68}\n== A. SKRIN UTAMA — cari ikon printer\n"
              f"{'=' * 68}")
        bukti(drv, "A-skrin-utama")
        ns = nod(drv)
        print(f"  {len(ns)} node")

        papar(ns, "SEMUA node clickable", lambda d: d["klik"] == "true")
        papar(ns, "node dengan glif ikon (PUA)",
              lambda d: any(ord(c) > 0xE000
                            for c in d["text"] + d["desc"]))

        ada_glif = [d for d in ns
                    if GLIF_PRINTER in d["text"] + d["desc"]]
        if ada_glif:
            print(f"\n  >>> glif printer MBJB (U+F042A) DIJUMPAI: "
                  f"{ada_glif[0]['bounds']}")
        else:
            print(f"\n  >>> glif printer MBJB (U+F042A) TIDAK dijumpai "
                  f"pada MBPG — locator MBJB tidak boleh disalin terus")

        # ---------------------------------------------------------------
        print(f"\n{'=' * 68}\n== B. SENARAI — laluan cetak rekod sedia ada"
              f"\n{'=' * 68}")
        dibuka = False
        for nama in ("open_senarai_kompaun", "open_senarai", "open_senarai_notis"):
            fn = getattr(pages.home, nama, None)
            if callable(fn):
                try:
                    fn()
                    dibuka = True
                    print(f"  dibuka melalui pages.home.{nama}()")
                    break
                except Exception as e:                          # noqa: BLE001
                    print(f"  {nama}() gagal: {type(e).__name__}")
        if not dibuka:
            print("  tiada kaedah home.open_senarai* berjaya — "
                  "membongkar skrin semasa sahaja")
        time.sleep(2)
        bukti(drv, "B-senarai")
        ns2 = nod(drv)
        print(f"  {len(ns2)} node")
        papar(ns2, "teks pada skrin",
              lambda d: bool(d["text"]) and len(d["text"]) < 60)
        papar(ns2, "node clickable", lambda d: d["klik"] == "true")
        papar(ns2, "apa-apa menyebut CETAK/PRINT",
              lambda d: re.search(r"cetak|print",
                                  f"{d['text']} {d['desc']} {d['rid']}",
                                  re.I))

        print("\n" + "=" * 70)
        print("== RECON TAMAT — tiada cetakan, tiada sambungan dibuat")
        print("=" * 70)
        P6.post_check(serial, p1["baseline"], "recon-cetak")
        return 0
    finally:
        if drv is not None:
            c = getattr(drv, "corong", None)
            if c is not None:
                print(f"\n  [CORONG] {c.bil_tap} tap dinilai, "
                      f"{c.bil_sekat} disekat")
            try:
                drv.quit()
            except Exception:                                   # noqa: BLE001
                pass


if __name__ == "__main__":
    sys.exit(main())

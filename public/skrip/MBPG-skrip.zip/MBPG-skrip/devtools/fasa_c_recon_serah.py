"""
FASA C — RECON LALUAN SERAH (C1). **SIFAR REKOD.**

Membuktikan dua perkara yang belum pernah dibuktikan pada MBPG, dan
BERHENTI sebelum perkara ketiga:

    1. KAMERA berfungsi         -> kaunter borang 'GAMBAR TELAH DIAMBIL: N/6'
                                   mesti membaca N >= 3
    2. DIALOG SERAH teksnya apa -> tekan MENYERAHKAN, rakam teks SEBENAR
    3. (TIDAK DIBUAT) HANTAR    -> itu yang mencipta rekod; menunggu pemilik

>>> KENAPA RECON INI SELAMAT. <<<
Rekod dicipta oleh butang HANTAR di dalam dialog pengesahan, BUKAN oleh
MENYERAHKAN yang membukanya -- lihat notis_amaran_page.py:995
`confirm_and_submit()`, yang menegaskan dialog hadir dahulu kemudian
barulah menekan HANTAR. Skrip ini memandu sampai dialog itu terbuka,
merakamnya, dan keluar melalui BATAL. `confirm_and_submit()` TIDAK
PERNAH dipanggil dari fail ini.

Andaian itu tidak dipercayai secara buta: DB dikira sebelum dan selepas,
dan sebarang rekod baharu menghentikan larian serta-merta.

>>> KENAPA N-003 DITARIK BALIK. <<<
Laporan awal saya menyimpulkan kamera tidak boleh diskrip. Itu SALAH.
MBJB `DaftarKompaunPage.take_photos()` memandunya sepenuhnya; pemilik
menunjukkan kodnya. Port itu sudah ada dalam repo ini (glif ikon
disahkan byte-identik dengan MBJB: SNAP U+F1BA, TICK U+F1FD) --
yang tiada hanyalah bukti larian. Skrip ini yang mengambilnya.

    python devtools/fasa_c_recon_serah.py
"""

import os
import sys
import time
import xml.etree.ElementTree as ET

HERE = os.path.dirname(os.path.abspath(__file__))
AKAR = os.path.dirname(HERE)
sys.path.insert(0, AKAR)

from guard.gerbang_serah import Izin, diagnosis                # noqa: E402
from pages import printer_tsc                                  # noqa: E402
from devtools import peringkat6 as P6                          # noqa: E402

DIR_BUKTI = os.path.join(AKAR, "docs", "demo-fasa-c", "recon-serah")
TC = "C1-N-001"


def bukti(pages, tag):
    """Screenshot + page source. Kedua-duanya digitignore (docs/demo-fasa-c/**)."""
    os.makedirs(DIR_BUKTI, exist_ok=True)
    asas = os.path.join(DIR_BUKTI, f"{TC}-{tag}")
    drv = pages.notis_amaran.driver
    try:
        drv.get_screenshot_as_file(asas + ".png")
    except Exception:                                           # noqa: BLE001
        pass
    try:
        with open(asas + ".xml", "w", encoding="utf-8") as fh:
            fh.write(drv.page_source)
    except Exception:                                           # noqa: BLE001
        pass
    print(f"    [BUKTI] {TC}-{tag}")


def teks_skrin(drv):
    """Setiap rentetan text/content-desc pada skrin, ikut susunan pokok.

    Dialog serah ialah satu-satunya perkara dalam projek ini yang teksnya
    TIDAK pernah dilihat sesiapa -- MBJB tidak pernah mencipta rekod
    (PAPAN.md s4), jadi tiada siapa pernah sampai ke sini. Jangan padan
    corak; kutip semuanya dan biar pemilik baca.
    """
    keluar = []
    try:
        akar = ET.fromstring(drv.page_source.encode("utf-8"))
    except Exception as e:                                      # noqa: BLE001
        print(f"  [RECON] page source tidak boleh dihurai: {e}")
        return keluar
    for n in akar.iter():
        for atr in ("text", "content-desc"):
            v = (n.get(atr) or "").strip()
            if v and v not in keluar:
                keluar.append(v)
    return keluar


def butang_pada_skrin(drv):
    """[(teks, kelas, bounds)] bagi setiap node clickable yang ada teks."""
    keluar = []
    try:
        akar = ET.fromstring(drv.page_source.encode("utf-8"))
    except Exception:                                           # noqa: BLE001
        return keluar
    for n in akar.iter():
        if (n.get("clickable") or "").lower() != "true":
            continue
        t = (n.get("text") or n.get("content-desc") or "").strip()
        if t:
            keluar.append((t, (n.get("class") or "").split(".")[-1],
                           n.get("bounds") or ""))
    return keluar


def kaunter_gambar(p):
    """Baca 'GAMBAR TELAH DIAMBIL: N/6' -> int N, atau None."""
    import re
    for t in teks_skrin(p.driver):
        m = re.search(r"GAMBAR\s+TELAH\s+DIAMBIL\s*:?\s*(\d+)\s*/\s*(\d+)",
                      t, re.I)
        if m:
            print(f"  [RECON] kaunter borang: {t!r}")
            return int(m.group(1))
    return None


def keluar_dari_dialog(p, pages):
    """BATAL sahaja. Tidak sekali-kali HANTAR.

    Corong menilai `.text` elemen itu sendiri dahulu (corong.py:341), jadi
    tap ke atas BATAL dinilai sebagai 'BATAL' -- peraturan KELUAR, lulus --
    dan bukan sebagai teks badan dialog 'Simpan maklumat ini?', yang
    trip-wire SIMPAN akan sekat.
    """
    from appium.webdriver.common.appiumby import AppiumBy
    # >>> DISAHKAN pada peranti 2026-08-12: dialog ini TIADA BATAL. <<<
    # Kandungan penuhnya ialah TIGA rentetan sahaja --
    #     X  /  SIMPAN MAKLUMAT INI ?  /  HANTAR
    # dengan dua sahaja yang clickable:
    #     [X]       ViewGroup [906,961][996,1051]
    #     [HANTAR]  ViewGroup [99,1286][981,1413]
    # Jadi satu-satunya jalan keluar yang app sendiri sediakan ialah X
    # merah. Mencari BATAL/TIDAK/CANCEL dahulu (seperti versi pertama
    # fungsi ini) membazir tiga carian dan jatuh kepada BACK peranti.
    # BACK memang berjaya, tetapi X ialah kawalan app dan deterministik.
    for label in ("X", "BATAL", "TIDAK", "CANCEL"):
        lok = (AppiumBy.ANDROID_UIAUTOMATOR,
               f'new UiSelector().textMatches("(?i)\\s*{label}\\s*")')
        try:
            el = p.find_element(lok, timeout=3)
        except Exception:                                       # noqa: BLE001
            el = None
        if el is not None:
            print(f"  [RECON] keluar dialog melalui {label}")
            p.tap_element(el)
            time.sleep(1.5)
            return label
    print("  [RECON] tiada butang keluar dijumpai -- BACK peranti")
    p.press_back()
    time.sleep(1.5)
    return "BACK"


def main():
    print("=" * 70)
    print("== FASA C — RECON LALUAN SERAH C1 (kamera + teks dialog)")
    print("== SIFAR REKOD: confirm_and_submit() TIDAK dipanggil.")
    print("=" * 70)

    from device_utils import resolve_udid
    from config import APP_PACKAGE
    from devtools.smoke_tangga import peringkat_1, peringkat_2, pastikan_di_home
    from testdata import oracle_n001 as O

    izin = Izin.dari_persekitaran(AKAR)
    d = diagnosis(izin)
    for k, v in d.items():
        print(f"  [{'OK ' if v is True else '   '}] {k:<28} = {v}")
    # Gerbang TERBUKA dalam recon ini (pemilik membukanya untuk 3 rekod).
    # Itu tidak mengubah apa yang skrip ini buat: ia berhenti sebelum
    # butang yang mencipta rekod, bukan kerana gerbang menghalangnya,
    # tetapi kerana laluan itu tidak dikodkan di sini langsung.
    printer_tsc.sahkan_terkunci()
    print("  printer TERKUNCI.\n")

    serial = resolve_udid(APP_PACKAGE, verbose=False)
    p1 = peringkat_1(serial)
    if not p1["ok"]:
        return 1
    baseline = p1["baseline"]
    P6.baseline_global = baseline

    drv = pages = None
    hasil = {}
    try:
        drv, pages = peringkat_2()
        p = pages.notis_amaran

        P6.relaunch(drv, pages, f"{TC}: borang bersih")
        if not pastikan_di_home(drv, pages):
            print("HENTI: tidak sampai skrin utama")
            return 1

        pages.home.open_notis_amaran()
        p.fill_pesalah_tab(O.SEMUA)
        p.click_seterusnya_from_pesalah()
        p.fill_notis_tab(O.SEMUA)
        p.fill_kompaun_code_fields(O.SEMUA)
        bukti(pages, "01-borang-siap")

        # ---------------------------------------------------------------
        # BUKTI 1 — KAMERA
        # ---------------------------------------------------------------
        print(f"\n{'-' * 68}\n-- BUKTI 1: KAMERA\n{'-' * 68}")
        sebelum = kaunter_gambar(p)
        print(f"  kaunter sebelum: {sebelum}")
        p.take_photos(count=3)
        bukti(pages, "02-selepas-kamera")
        selepas = kaunter_gambar(p)
        hasil["kamera_sebelum"] = sebelum
        hasil["kamera_selepas"] = selepas
        if selepas is None:
            print("  [BUKTI 1] GAGAL: kaunter tidak boleh dibaca")
        elif selepas >= 3:
            print(f"  [BUKTI 1] LULUS: {selepas}/6 gambar dilampirkan")
        else:
            print(f"  [BUKTI 1] GAGAL: hanya {selepas}/6")
        if not selepas or selepas < 3:
            print("\nHENTI: kamera belum terbukti. Tiada gunanya meneruskan "
                  "ke dialog serah -- borang akan ditolak oleh validasi "
                  "GAMBAR MESTI DIAMBIL.")
            P6._keluar_ke_home(pages, TC)
            P6.post_check(serial, baseline, TC)
            return 1

        # ---------------------------------------------------------------
        # PENERIMA
        # ---------------------------------------------------------------
        print(f"\n{'-' * 68}\n-- TAB PENERIMA (belum pernah dicapai pada MBPG)"
              f"\n{'-' * 68}")
        p.click_seterusnya_from_notis()
        time.sleep(1)
        bukti(pages, "03-skrin-penerima")
        print("  teks skrin penerima:")
        for t in teks_skrin(drv)[:40]:
            print(f"    | {t[:72]}")

        p.fill_penerima_tab(O.SEMUA)
        bukti(pages, "04-penerima-diisi")

        # ---------------------------------------------------------------
        # BUKTI 2 — DIALOG SERAH. MENYERAHKAN membuka; ia TIDAK menyimpan.
        # ---------------------------------------------------------------
        print(f"\n{'-' * 68}\n-- BUKTI 2: DIALOG SERAH\n{'-' * 68}")
        p.click_menyerahkan()
        time.sleep(2)
        bukti(pages, "05-DIALOG-SERAH")

        teks = teks_skrin(drv)
        butang = butang_pada_skrin(drv)
        hasil["dialog_teks"] = teks
        hasil["dialog_butang"] = butang
        print("\n  >>> TEKS DIALOG SEBENAR (rakaman pertama dalam projek) <<<")
        for t in teks:
            print(f"    | {t}")
        print("\n  >>> BUTANG CLICKABLE PADA SKRIN INI <<<")
        for t, kelas, b in butang:
            print(f"    [{t}]  {kelas}  {b}")

        # ---------------------------------------------------------------
        # KELUAR — BATAL. Tidak sekali-kali HANTAR.
        # ---------------------------------------------------------------
        print(f"\n{'-' * 68}\n-- KELUAR TANPA SERAH\n{'-' * 68}")
        hasil["keluar"] = keluar_dari_dialog(p, pages)
        bukti(pages, "06-selepas-batal")

        P6._keluar_ke_home(pages, TC)
        bukti(pages, "07-back-out")
        bersih = P6.post_check(serial, baseline, TC)
        hasil["post_check_bersih"] = bersih

        print("\n" + "=" * 70)
        print("== RINGKASAN RECON")
        print("=" * 70)
        print(f"  kamera            : {hasil.get('kamera_sebelum')} -> "
              f"{hasil.get('kamera_selepas')}/6")
        print(f"  keluar dialog     : {hasil.get('keluar')}")
        print(f"  post-check        : {'BERSIH (0 rekod)' if bersih else 'GAGAL'}")
        print(f"  rekod dicipta     : 0 (confirm_and_submit tidak dipanggil)")

        laluan = os.path.join(DIR_BUKTI, "TEKS-DIALOG-SERAH.txt")
        with open(laluan, "w", encoding="utf-8") as fh:
            fh.write("TEKS DIALOG SERAH — MBPG 2.1.21, C1 Notis Amaran\n")
            fh.write("=" * 60 + "\n\nSemua teks pada skrin:\n")
            for t in teks:
                fh.write(f"  | {t}\n")
            fh.write("\nButang clickable:\n")
            for t, kelas, b in butang:
                fh.write(f"  [{t}]  {kelas}  {b}\n")
        print(f"\n  teks dialog ditulis: {laluan}")
        return 0 if bersih else 1
    finally:
        if drv is not None:
            c = getattr(drv, "corong", None)
            if c is not None:
                print(f"\n  [CORONG] {c.bil_tap} tap dinilai, "
                      f"{c.bil_sekat} disekat"
                      + (f" | DIBATALKAN: {c.dibatalkan}"
                         if c.dibatalkan else ""))
            try:
                drv.quit()
            except Exception:                                   # noqa: BLE001
                pass


if __name__ == "__main__":
    sys.exit(main())

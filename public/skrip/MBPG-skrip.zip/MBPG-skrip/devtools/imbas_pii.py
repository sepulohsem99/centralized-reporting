"""
IMBASAN PII PRA-COMMIT — imbas KELAS corak, bukan senarai nama fail.

>>> KENAPA INI WUJUD. <<<
Tiga kali dalam satu hari, corak .gitignore terlepas sesuatu dan data
peribadi masuk ke dalam commit:

    reports/log/            `reports/*.log` tidak menangkap subdirektori
    docs/demo-fasa-c/**     corak tidak rekursif
    izin.json               peraturan ditulis untuk `fasa_c_izin.json`

Setiap kali, puncanya sama: saya menulis peraturan untuk fail yang
saya TAHU wujud, bukan untuk kelas kandungan yang berbahaya. Alat ini
membalikkan itu — ia mencari CORAK dalam apa sahaja yang akan
dicommit, tanpa mengira nama.

Ia menyekat commit apabila PII dijumpai dalam fail yang BAKAL
dijejaki. Fail yang sudah digitignore diabaikan: ia memang tidak akan
masuk sejarah.

    python devtools/imbas_pii.py            # imbas yang dipentas
    python devtools/imbas_pii.py --semua    # imbas seluruh pokok kerja
"""

import argparse
import os
import re
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
AKAR = os.path.dirname(HERE)

# Corak dipilih supaya ia menangkap BENTUK, bukan nilai tertentu.
# Menyenaraikan IC sebenar di sini akan menjadikan alat ini gagal untuk
# orang seterusnya — dan meletakkan IC itu dalam repo.
CORAK = [
    ("no_kp_12_digit", re.compile(r"(?<!\d)\d{12}(?!\d)")),
    ("no_kp_bersengkang", re.compile(r"(?<!\d)\d{6}-\d{2}-\d{4}(?!\d)")),
    # Plat Malaysia: 1-3 huruf + 3-4 digit + 0-1 huruf. Corak longgar
    # (\d{1,4}, huruf ekor {0,2}) menangkap pengecam kod seperti KA01,
    # T001, C9C9, Z0Z0 — dan alat yang berbunyi pada setiap commit
    # akan diabaikan, jadi ia tidak melindungi apa-apa.
    # Satu huruf menuntut EMPAT digit, kalau tidak pengecam TC seperti
    # T001 / T011 ditandakan pada setiap fail ujian yang disunting.
    ("plat_kenderaan",
     re.compile(r"\b(?:[A-Z]{2,3}\d{3,4}|[A-Z]\d{4})[A-Z]?\b")),
    ("nama_bin_binti", re.compile(r"\b[A-Z][A-Za-z']+\s+(?:BIN|BINTI|A/L|A/P)"
                                  r"\s+[A-Z][A-Za-z']+", re.I)),
]

# Dua fail SAH mengandungi literal berbentuk PII: alat ini dan
# ujiannya. Ia mesti, kalau tidak ujian tidak boleh membuktikan
# pengesanan berfungsi.
#
# Pengecualian ini ikut LALUAN, bukan ikut NILAI. Mengecualikan nilai
# akan mematikan pengesanan di mana-mana sahaja nilai itu muncul —
# termasuk dalam dump sebenar. Mengecualikan dua fail yang diketahui
# tidak menyentuh pengesanan langsung.
FAIL_DIKECUALIKAN = {
    "devtools/imbas_pii.py",
    "tests_offline/test_imbas_pii.py",
}

# Nilai yang SAH muncul dalam repo dan bukan PII.
KECUALI = re.compile(
    r"^(?:0{12}|9{12}|1{12})$"           # IC penanda ujian
    r"|^(?:JALAN|TAMAN|BANDAR|SEK|UUK|AKTA|MPPG|PMTLK|RM|MIN|MAX)\b"
    r"|^(?:MBPG|MBJB|MBIP|PGP\d*|TSC|SQL|CSV|XML|PNG|API|URL|TTY|EOF)$"
    # Serpihan ID set: SET-KK01-AKT049-048. 'AKT049' mempunyai
    # bentuk plat Malaysia dan muncul dalam setiap arahan runner
    # yang pemilik taip. Alat yang berbunyi pada penggunaan biasa
    # akan diabaikan.
    r"|^(?:AKT|KK|SET)\d{1,4}$",
    re.I)

# Sambungan yang tidak berguna diimbas (binari).
LANGKAU_EXT = {".png", ".jpg", ".jpeg", ".gif", ".db", ".pyc", ".zip",
               ".xlsx", ".pdf", ".ico"}


def baris_ditambah():
    """[(fail, baris)] bagi setiap baris DITAMBAH dalam diff dipentas.

    >>> KENAPA DIFF, BUKAN FAIL PENUH. <<<
    Mengimbas fail penuh menandakan setiap IC ujian oracle yang sudah
    lama dijejaki, pada setiap commit. Alat yang berbunyi pada setiap
    commit akan diabaikan, dan alat yang diabaikan tidak melindungi
    apa-apa.

    Yang penting ialah apa yang MASUK sejarah pada commit INI. Baris
    yang ditambah ialah tepat itu.
    """
    # >>> UTF-8 EKSPLISIT, BUKAN LALAI PLATFORM. <<<
    # `text=True` menyahkod dengan codepage sistem (cp1252 pada Windows
    # ini). Diff repo ini membawa UTF-8 — sengkang em, anak panah, dan
    # glif ikon device — jadi sebaik satu daripadanya masuk ke dalam
    # baris yang dipentas, penyahkodan MELETUP dan alat mati dengan
    # `AttributeError: 'NoneType' has no attribute 'splitlines'`.
    #
    # Kesannya lebih buruk daripada ranap biasa: ini gerbang PII
    # pra-commit. Alat yang mati pada commit yang mengandungi teks
    # bukan-ASCII ialah alat yang tidak mengimbas commit itu langsung.
    # Diperhati 2026-08-17.
    #
    # `errors="replace"` supaya bait rosak menjadi U+FFFD dan bukan
    # pengecualian — corak PII tetap dipadankan pada baki barisnya.
    r = subprocess.run(["git", "diff", "--cached", "-U0"],
                       cwd=AKAR, capture_output=True, text=True,
                       encoding="utf-8", errors="replace")
    keluar, fail = [], "?"
    for baris in (r.stdout or "").splitlines():
        if baris.startswith("+++ b/"):
            fail = baris[6:].strip()
        elif baris.startswith("+") and not baris.startswith("+++"):
            keluar.append((fail, baris[1:]))
    return keluar


def _fail_pokok_kerja():
    # UTF-8 eksplisit atas sebab yang sama seperti baris_ditambah():
    # satu nama fail bukan-ASCII sudah cukup untuk mematikan gerbang.
    r = subprocess.run(["git", "ls-files", "--cached", "--others",
                        "--exclude-standard"],
                       cwd=AKAR, capture_output=True, text=True,
                       encoding="utf-8", errors="replace")
    return [f.strip() for f in (r.stdout or "").splitlines() if f.strip()]


def _relatif(f):
    """git melaporkan laluan relatif kepada akar repo, yang berada SATU
    peringkat di atas MBPG-testing."""
    if f.startswith("MBPG-testing/"):
        return f[len("MBPG-testing/"):]
    return f


# Arahan lint, bukan data. `# noqa: BLE001` mempunyai BENTUK yang sama
# persis seperti plat Malaysia (3 huruf + 3 digit) dan muncul 307 kali
# dalam repo ini, jadi setiap commit yang menyentuh kod dengan
# except-buta akan ditandakan. Alat yang berbunyi pada setiap commit
# akan diabaikan, dan alat yang diabaikan tidak melindungi apa-apa.
#
# Yang dibuang ialah TOKEN noqa, bukan nilai 'BLE001'. Mengecualikan
# nilai itu akan membutakan pengimbas kepada plat sebenar yang kebetulan
# berbunyi BLE001 di mana-mana sahaja ia muncul -- termasuk dalam dump
# peranti. Komen noqa tidak wujud dalam dump.
NOQA = re.compile(r"#\s*noqa:?[A-Z0-9,\s]*", re.I)


def imbas_teks(teks, had=6):
    teks = NOQA.sub(" ", teks)
    jumpa = []
    for nama, corak in CORAK:
        for m in corak.finditer(teks):
            nilai = m.group(0).strip()
            if KECUALI.match(nilai):
                continue
            jumpa.append((nama, nilai))
            if len(jumpa) >= had:
                return jumpa
    return jumpa


def imbas_fail(laluan):
    if os.path.splitext(laluan)[1].lower() in LANGKAU_EXT:
        return []
    try:
        with open(laluan, encoding="utf-8", errors="replace") as fh:
            return imbas_teks(fh.read())
    except OSError:
        return []


def main(argv=None):
    # argv disuntik supaya ujian boleh memanggil main() tanpa argparse
    # membaca argv pytest dan membunuh proses.
    ap = argparse.ArgumentParser()
    ap.add_argument("--semua", action="store_true",
                    help="Imbas seluruh pokok kerja, bukan hanya yang "
                         "dipentas.")
    a = ap.parse_args([] if argv is None and "pytest" in sys.modules
                      else argv)

    kotor = {}
    if a.semua:
        senarai = _fail_pokok_kerja()
        for f in senarai:
            rel = _relatif(f)
            penuh = os.path.join(AKAR, rel)
            if os.path.isfile(penuh):
                jumpa = imbas_fail(penuh)
                if jumpa:
                    kotor[rel] = jumpa
        unit = f"{len(senarai)} fail"
    else:
        baris = baris_ditambah()
        for f, teks in baris:
            if os.path.splitext(f)[1].lower() in LANGKAU_EXT:
                continue
            if _relatif(f) in FAIL_DIKECUALIKAN:
                continue
            jumpa = imbas_teks(teks)
            if jumpa:
                kotor.setdefault(_relatif(f), []).extend(jumpa)
        unit = f"{len(baris)} baris ditambah"
        if not baris:
            print("  [PII] tiada baris ditambah untuk diimbas.")
            return 0

    print(f"  [PII] {unit} diimbas, {len(kotor)} fail membawa corak PII")
    if not kotor:
        print("  [PII] BERSIH.")
        return 0

    print("\n  ============ COMMIT DIHALANG — PII DIJUMPAI ============")
    for f, jumpa in kotor.items():
        print(f"\n  {f}")
        for nama, nilai in jumpa:
            # Nilai DISAMARKAN. Alat yang melaporkan PII secara penuh
            # ke terminal dan log hanya menyebarkannya lagi.
            samar = nilai[:2] + "*" * max(0, len(nilai) - 4) + nilai[-2:]
            print(f"    {nama:<18} {samar}")
    print("\n  Pilihan: tambah fail ke .gitignore, atau redact "
          "kandungannya.")
    print("  ========================================================")
    return 1


if __name__ == "__main__":
    sys.exit(main())

"""
RECON — aliran Notis -> Kompaun (NK). BACA SAHAJA.

>>> DI MANA RECON INI BERHENTI, DAN KENAPA. <<<
Popup notis membawa dua butang: [KOMPAUN] dan [PATUH]. Menekan
[KOMPAUN] membuka borang bertajuk 'NOTIS TO KOMPAUN'.

Recon ini BERHENTI SEBELUM menekannya.

Sebabnya bukan berhati-hati secara umum. Dalam app INI, membuka borang
sudah terbukti MEMBAKAR NOMBOR SIRI walaupun tiada rekod diserah:
kaunter notis bergerak 2 -> 7 pada 2026-08-13 semata-mata kerana
borang dipandu sampai peringkat gambar. Kalau borang penukaran
berkelakuan sama, membukanya membakar nombor KOMPAUN — dan pemilik
menyatakan dengan jelas kuota_NK kekal 0 dan pelaksanaan NK sebenar
perlukan kelulusan berasingan.

Jadi yang dirakam ialah: skrin masuk, senarai notis, dan popup notis
dengan kedua-dua butangnya. Itu memberi laluan sehingga titik
keputusan. Apa yang di sebalik [KOMPAUN] kekal TIDAK DIKETAHUI, dan
peringkat `nk` akan mengatakannya dan bukan berpura-pura.

TIADA butang pengesahan / jana / sahkan ditekan.

    python devtools/recon_nk.py
"""

import os
import re
import sys
import time
import xml.etree.ElementTree as ET

HERE = os.path.dirname(os.path.abspath(__file__))
AKAR = os.path.dirname(HERE)
sys.path.insert(0, AKAR)

from devtools import peringkat6 as P6                          # noqa: E402

DIR_RECON = os.path.join(AKAR, "docs", "recon")

# Perkataan yang menandakan butang yang MENJANA atau MENGESAHKAN.
# Kalau salah satu daripadanya ialah satu-satunya jalan ke hadapan,
# recon berhenti di situ.
JANA = re.compile(r"jana|tukar|sahkan|hantar|simpan|\bya\b|kompaun", re.I)


def nod(drv):
    try:
        akar = ET.fromstring(drv.page_source.encode("utf-8"))
    except Exception:                                           # noqa: BLE001
        return []
    keluar = []
    for n in akar.iter():
        keluar.append({
            "kelas": (n.get("class") or "").split(".")[-1],
            "text": (n.get("text") or "").strip(),
            "desc": (n.get("content-desc") or "").strip(),
            "rid": (n.get("resource-id") or "").strip(),
            "klik": (n.get("clickable") or ""),
            "bounds": n.get("bounds") or "",
        })
    return keluar


def rakam(drv, tag, tajuk):
    os.makedirs(DIR_RECON, exist_ok=True)
    asas = os.path.join(DIR_RECON, f"nk-{tag}")
    try:
        drv.get_screenshot_as_file(asas + ".png")
    except Exception:                                           # noqa: BLE001
        pass
    try:
        with open(asas + ".xml", "w", encoding="utf-8") as fh:
            fh.write(drv.page_source)
    except Exception:                                           # noqa: BLE001
        pass
    ns = nod(drv)
    print(f"\n  ---- {tajuk}  ({len(ns)} node, bukti nk-{tag}) ----")
    for d in ns:
        if d["klik"] == "true" and (d["text"] or d["desc"]):
            label = d["text"] or d["desc"]
            tanda = "  <== JANA/SAHKAN" if JANA.search(label) else ""
            print(f"    KLIK  {d['bounds']:<24} {label[:44]!r}{tanda}")
    teks = []
    for d in ns:
        t = d["text"] or d["desc"]
        if t and t not in teks and len(t) < 70:
            teks.append(t)
    print(f"    teks: {teks[:18]}")
    return ns


def main():
    from devtools.smoke_tangga import (peringkat_1, peringkat_2,
                                       pastikan_di_home, tarik_db)
    from devtools import fasa_c as FC
    from device_utils import resolve_udid
    from config import APP_PACKAGE

    print("=" * 70)
    print("== RECON NOTIS -> KOMPAUN — BACA SAHAJA")
    print("== BERHENTI sebelum butang [KOMPAUN]. Tiada jana, tiada sahkan.")
    print("=" * 70)

    serial = resolve_udid(APP_PACKAGE, verbose=False)
    p1 = peringkat_1(serial)
    if not p1["ok"]:
        return 1
    P6.baseline_global = p1["baseline"]
    asas = p1["baseline"][0]

    drv = None
    try:
        drv, pages = peringkat_2()
        P6.relaunch(drv, pages, "recon NK")
        if not pastikan_di_home(drv, pages):
            print("HENTI: tidak sampai skrin utama")
            return 1

        nk = pages.notis_kompaun

        # --- A. skrin masuk ---
        pages.home.open_notis_kompaun()
        time.sleep(2)
        rakam(drv, "A-skrin-masuk", "A. SKRIN NOTIS KOMPAUN")

        # --- B. dialog Tarik Notis ---
        # TARIK membaca dari server ke cermin tempatan. Ia tidak
        # mencipta rekod pada server. Pemilik menskopkan TN sebagai
        # baca-sahaja.
        try:
            nk.click_tarik_notis()
            time.sleep(2)
            rakam(drv, "B-dialog-tarik", "B. DIALOG TARIK NOTIS")
        except Exception as e:                                  # noqa: BLE001
            print(f"  dialog Tarik Notis tidak dibuka: {type(e).__name__}")

        # --- C. senarai notis ---
        try:
            nk.click_tarik()
            time.sleep(8)
        except Exception as e:                                  # noqa: BLE001
            print(f"  TARIK tidak ditekan: {type(e).__name__}")
        rakam(drv, "C-senarai-notis", "C. SENARAI NOTIS DITARIK")
        nombor = nk.get_pulled_notice_numbers() or []
        print(f"    notis dalam senarai: {len(nombor)}")
        if nombor:
            print(f"    contoh (2 pertama): {nombor[:2]}")

        # --- D. popup notis: DI SINI recon berhenti ---
        if nombor:
            try:
                nk.open_notice_popup(index=0)
                time.sleep(2)
                ns = rakam(drv, "D-popup-notis",
                           "D. POPUP NOTIS — titik keputusan")
                jana = [d for d in ns if d["klik"] == "true"
                        and JANA.search(d["text"] or d["desc"] or "")]
                print("\n  >>> BUTANG YANG MENJANA — TIDAK DITEKAN <<<")
                for d in jana:
                    print(f"      {(d['text'] or d['desc'])!r} @ "
                          f"{d['bounds']}")
                if not jana:
                    print("      (tiada dikenal pasti pada popup ini)")
            except Exception as e:                              # noqa: BLE001
                print(f"  popup notis tidak dibuka: {type(e).__name__}: {e}")
        else:
            print("\n  Tiada notis dalam senarai — popup tidak boleh "
                  "dibuka. Aliran NK tidak dapat direcon lebih jauh.")

        # --- keluar ---
        print(f"\n{'-' * 68}\n-- BACK OUT\n{'-' * 68}")
        P6._keluar_ke_home(pages, "recon-NK")
        rakam(drv, "E-back-out", "E. SELEPAS BACK OUT")

        db = tarik_db(serial, os.path.join(AKAR, "data", "tmp",
                                           "pasca_recon_nk.db"))
        kini = FC.kira_rekod(db)
        delta = {k: kini.get(k, 0) - asas.get(k, 0)
                 for k in kini if kini.get(k, 0) != asas.get(k, 0)}
        print("\n" + "=" * 70)
        print("== RECON TAMAT — butang [KOMPAUN] TIDAK ditekan")
        print("=" * 70)
        print(f"  delta jadual: {delta or 'tiada perubahan'}")
        if delta:
            print("  (notis_to_kompaun bertambah = cermin server dari "
                  "TARIK, bukan rekod dicipta)")
        return 0
    finally:
        if drv is not None:
            c = getattr(drv, "corong", None)
            if c is not None:
                print(f"\n  [CORONG] {c.bil_tap} tap dinilai, "
                      f"{c.bil_sekat} disekat")
            try:
                drv.quit()
            except Exception:                                   # noqa: BLE001
                pass


if __name__ == "__main__":
    sys.exit(main())

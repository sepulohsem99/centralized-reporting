"""
K-001 — adakah lookup mySIKAP menulis ke medan yang SALAH?

Selepas lookup, empat medan kenderaan/petak memegang komponen alamat.
Dua tafsiran muat pada bukti dump, dan dump sahaja tidak boleh
memisahkannya kerana pada borang ini **placeholder ialah satu-satunya
label**, dan ia hilang sebaik medan berisi:

    (a) lookup menulis alamat ke medan yang salah      -> DEFEK app
    (b) app menukar set medan bila identiti diketahui  -> betul

Ujian yang memisahkannya, seperti diarahkan pemilik: KOSONGKAN satu
medan dan lihat placeholder mana yang kembali.

    placeholder kembali 'Jenis Kereta'  -> medan itu MASIH Jenis Kereta,
                                           jadi lookup menulis alamat ke
                                           dalamnya = (a) DEFEK
    placeholder lain (cth 'Alamat')     -> app menukar set medan = (b)

Tindakan LOKAL sahaja: taip ke satu medan borang. Tiada serah, tiada
simpan, tiada butang pengesahan. ePBT TIDAK DITEKAN.

    python devtools/k001_siasat_medan.py
"""

import os
import re
import sys
import time
import xml.etree.ElementTree as ET

HERE = os.path.dirname(os.path.abspath(__file__))
AKAR = os.path.dirname(HERE)
sys.path.insert(0, AKAR)

from devtools import peringkat6 as P6                          # noqa: E402
from testdata import oracle_pk as _OPK                         # noqa: E402

DIR_RECON = os.path.join(AKAR, "docs", "recon")
PLAT = _OPK.K001["no_kereta"]
TC = "K-001-siasat"

# Medan yang disiasat: yang SEBELUM lookup memaparkan placeholder ini.
MEDAN_UJI = "Jenis Kereta"


def bukti(drv, tag):
    os.makedirs(DIR_RECON, exist_ok=True)
    asas = os.path.join(DIR_RECON, f"k001-siasat-{tag}")
    try:
        drv.get_screenshot_as_file(asas + ".png")
    except Exception:                                           # noqa: BLE001
        pass
    try:
        with open(asas + ".xml", "w", encoding="utf-8") as fh:
            fh.write(drv.page_source)
    except Exception:                                           # noqa: BLE001
        pass
    print(f"    [BUKTI] k001-siasat-{tag}")


def medan_edittext(drv):
    """[(bounds, teks)] setiap EditText, ikut susunan pokok."""
    try:
        akar = ET.fromstring(drv.page_source.encode("utf-8"))
    except Exception:                                           # noqa: BLE001
        return []
    return [(n.get("bounds") or "", (n.get("text") or "").strip())
            for n in akar.iter()
            if (n.get("class") or "").endswith("EditText")]


def samar(t):
    if re.fullmatch(r"\d{12}", t):
        return "<IC 12 digit>"
    if re.fullmatch(r"[A-Z]{1,3}\d{3,4}[A-Z]?", t):
        return "<plat>"
    if len(t) > 24:
        return f"<teks {len(t)} aksara>"
    return repr(t)


def main():
    from devtools.smoke_tangga import peringkat_1, peringkat_2, \
        pastikan_di_home
    from device_utils import resolve_udid
    from config import APP_PACKAGE

    print("=" * 70)
    print(f"== {TC} — kosongkan '{MEDAN_UJI}', baca placeholder yang kembali")
    print("== TIADA serah. TIADA simpan. ePBT TIDAK DITEKAN.")
    print("=" * 70)

    serial = resolve_udid(APP_PACKAGE, verbose=False)
    p1 = peringkat_1(serial)
    if not p1["ok"]:
        return 1
    baseline = p1["baseline"]
    P6.baseline_global = baseline

    drv = pages = None
    try:
        drv, pages = peringkat_2()
        P6.relaunch(drv, pages, f"{TC}: borang bersih")
        if not pastikan_di_home(drv, pages):
            print("HENTI: tidak sampai skrin utama")
            return 1

        p = pages.daftar_kompaun
        pages.home.open_daftar_kompaun()
        p.select_jenis_kompaun_letak_kereta()

        if not P6._isi_medan_tepat(p, "No. Kereta", PLAT):
            print("HENTI: medan No. Kereta tidak dijumpai")
            return 1
        try:
            drv.hide_keyboard()
            time.sleep(0.5)
            p.wait_and_tap(p.TAB_PESALAH)
            time.sleep(1.5)
        except Exception:                                       # noqa: BLE001
            pass

        # --- keadaan SEBELUM lookup: rakam placeholder setiap medan ---
        sebelum = medan_edittext(drv)
        print("\n  -- SEBELUM lookup --")
        for i, (b, t) in enumerate(sebelum):
            print(f"    [{i}] {b:<24} {samar(t)}")
        idx_uji = next((i for i, (_b, t) in enumerate(sebelum)
                        if t.strip().lower() == MEDAN_UJI.lower()), None)
        if idx_uji is None:
            print(f"\nHENTI: medan berplaceholder '{MEDAN_UJI}' tidak "
                  f"dijumpai sebelum lookup.")
            bukti(drv, "GAGAL-placeholder-asal-tiada")
            return 1
        bounds_uji = sebelum[idx_uji][0]
        print(f"\n  medan diuji: indeks {idx_uji}, bounds {bounds_uji}")

        # --- lookup ---
        ms = P6._cari_mysikap(p)
        if ms is None:
            print("\nHENTI: butang mySIKAP tidak dapat disahkan. TIADA "
                  "tekaan (tekaan salah = tekan ePBT = padam data).")
            bukti(drv, "GAGAL-mysikap-tidak-pasti")
            return 1
        print(f"  mySIKAP @ {ms} — tap")
        snap = P6._snapshot_medan(p)
        drv.execute_script("mobile: clickGesture", {"x": ms[0], "y": ms[1]})
        tamat = time.time() + 45
        while time.time() < tamat:
            time.sleep(3)
            if P6._beza_medan(snap, P6._snapshot_medan(p)):
                break
        bukti(drv, "01-selepas-lookup")

        selepas = medan_edittext(drv)
        print("\n  -- SELEPAS lookup --")
        for i, (b, t) in enumerate(selepas):
            print(f"    [{i}] {b:<24} {samar(t)}")

        # Sauh pada BOUNDS, bukan indeks: satu medan baharu muncul
        # selepas lookup, jadi indeks beranjak dan perbandingan ikut
        # indeks akan membandingkan kawalan yang berlainan.
        padan = [(i, b, t) for i, (b, t) in enumerate(selepas)
                 if b == bounds_uji]
        if not padan:
            # bounds boleh beranjak beberapa piksel; terima yang terdekat
            def y(bb):
                m = re.match(r"\[(\d+),(\d+)\]", bb or "")
                return int(m.group(2)) if m else -10000
            y0 = y(bounds_uji)
            padan = sorted(((i, b, t) for i, (b, t) in enumerate(selepas)),
                           key=lambda r: abs(y(r[1]) - y0))[:1]
        i_sel, b_sel, t_sel = padan[0]
        print(f"\n  medan yang sama selepas lookup: indeks {i_sel}, "
              f"bounds {b_sel}, nilai {samar(t_sel)}")

        # --- KOSONGKAN medan itu ---
        print(f"\n  -- mengosongkan medan @ {b_sel} --")
        m = re.match(r"\[(\d+),(\d+)\]\[(\d+),(\d+)\]", b_sel)
        cx = (int(m.group(1)) + int(m.group(3))) // 2
        cy = (int(m.group(2)) + int(m.group(4))) // 2
        drv.execute_script("mobile: clickGesture", {"x": cx, "y": cy})
        time.sleep(1)
        el = None
        for kandidat in drv.find_elements("class name",
                                          "android.widget.EditText"):
            try:
                if kandidat.get_attribute("bounds") == b_sel:
                    el = kandidat
                    break
            except Exception:                                   # noqa: BLE001
                continue
        if el is None:
            print("  medan tidak dapat dipegang sebagai elemen — cuba "
                  "yang tumpuan semasa")
            try:
                el = drv.switch_to.active_element
            except Exception:                                   # noqa: BLE001
                el = None
        if el is None:
            print("\nHENTI: medan tidak boleh dikosongkan.")
            bukti(drv, "GAGAL-tidak-boleh-pegang")
            return 1
        try:
            el.clear()
        except Exception as e:                                  # noqa: BLE001
            print(f"  clear() gagal ({type(e).__name__}) — cuba backspace")
            for _ in range(40):
                drv.press_keycode(67)
        time.sleep(1.5)
        try:
            drv.hide_keyboard()
            time.sleep(0.8)
        except Exception:                                       # noqa: BLE001
            pass
        bukti(drv, "02-selepas-kosong")

        # --- baca placeholder yang kembali ---
        akhir = medan_edittext(drv)
        print("\n  -- SELEPAS dikosongkan --")
        for i, (b, t) in enumerate(akhir):
            print(f"    [{i}] {b:<24} {samar(t)}")

        def y(bb):
            mm = re.match(r"\[(\d+),(\d+)\]", bb or "")
            return int(mm.group(2)) if mm else -10000
        dekat = sorted(akhir, key=lambda r: abs(y(r[0]) - y(b_sel)))[:1]
        kembali = dekat[0][1] if dekat else ""

        print("\n" + "=" * 70)
        print("== KEPUTUSAN")
        print("=" * 70)
        print(f"  placeholder asal    : {MEDAN_UJI!r}")
        print(f"  placeholder kembali : {kembali!r}")
        if kembali.strip().lower() == MEDAN_UJI.lower():
            print("\n  >>> (a) DEFEK APP <<<")
            print("  Medan itu MASIH 'Jenis Kereta'. Lookup mySIKAP "
                  "menulis komponen")
            print("  alamat ke dalam medan kenderaan. Kompaun yang "
                  "diserah selepas")
            print("  lookup akan membawa data salah dalam medan itu.")
        elif kembali:
            print("\n  >>> (b) APP MENUKAR SET MEDAN <<<")
            print(f"  Placeholder yang kembali ialah {kembali!r}, bukan "
                  f"{MEDAN_UJI!r}.")
            print("  Medan itu bukan lagi medan kenderaan selepas "
                  "identiti diketahui.")
            print("  Bukan defek.")
        else:
            print("\n  >>> TIDAK MENENTU <<<")
            print("  Tiada placeholder kembali. Tidak boleh disimpulkan.")

        P6._keluar_ke_home(pages, TC)
        bersih = P6.post_check(serial, baseline, TC)
        print(f"\n  post-check: {'bersih' if bersih else 'PERHATIAN'}")
        return 0
    finally:
        if drv is not None:
            c = getattr(drv, "corong", None)
            if c is not None:
                print(f"\n  [CORONG] {c.bil_tap} tap dinilai, "
                      f"{c.bil_sekat} disekat")
            try:
                drv.quit()
            except Exception:                                   # noqa: BLE001
                pass


if __name__ == "__main__":
    sys.exit(main())

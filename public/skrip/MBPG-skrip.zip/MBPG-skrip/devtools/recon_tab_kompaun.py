"""
IMBASAN PENUH — tab KOMPAUN borang Pelbagai (MBPG 2.1.21).

>>> KENAPA IMBASAN, BUKAN TAMPALAN LAGI. <<<
Tiga larian P-001 (2026-08-17 15:11, 15:34, 15:5x) mati pada titik yang
SAMA. Dua hipotesis diuji, kedua-duanya SALAH:

  1. "medan di bawah lipatan"  -> reveal_below_fold. Tiada perubahan.
  2. "IME menolak borang"      -> tutup_ime_tanpa_back. Tiada perubahan.

Pemilik kemudian memerhati device secara fizikal dan melaporkan sesuatu
yang bercanggah dengan bacaan saya pada log: **butiran kesalahan MEMANG
terisi**, dan yang gagal ialah bahagian SELEPASNYA — tiga dropdown,
kadar denda, dan butang kamera.

Kedua-duanya boleh benar serentak kalau medan itu SUDAH BERISI:
`fill_field_by_label` mencari mengikut PLACEHOLDER, dan placeholder
hilang sebaik medan mempunyai nilai. Larian kemudian menunggu 15s untuk
teks yang tidak akan pernah kembali.

Isyarat yang menyokongnya muncul dalam SETIAP larian dan saya abaikan:

    [RECOVERY] skrin utama=True  draf hilang=False

Skrip ini tidak membetulkan apa-apa. Ia merakam FAKTA yang skrip baharu
akan dibina di atasnya:

  * keadaan draf sebelum dan selepas relaunch
  * setiap skrin/bahagian tab KOMPAUN, dengan tajuk app-bar masing-masing
  * untuk SETIAP medan yang dijangka: hadir? kosong atau berisi? nilai?
  * inventori kawalan: dropdown, medan denda, butang kamera, SETERUSNYA

>>> BACA SAHAJA. <<<
`MBPG_MOD_SEBENAR` TIDAK dihidupkan — corong menyekat setiap butang
mutasi seperti biasa. Tiada SERAH, tiada HANTAR, tiada CETAK. Keluar
melalui back + post-check.

    python devtools/recon_tab_kompaun.py
"""

import os
import sys
import time
import xml.etree.ElementTree as ET

HERE = os.path.dirname(os.path.abspath(__file__))
AKAR = os.path.dirname(HERE)
sys.path.insert(0, AKAR)

DIR_RECON = os.path.join(AKAR, "docs", "recon")

# Medan yang pemilik namakan, mengikut urutan yang dia lihat pada skrin.
# 'ok' = pemilik sahkan berjaya diisi; 'gagal' = pemilik sahkan gagal.
MEDAN_DIJANGKA = [
    ("Maklumat Jalan",        "ok"),
    ("Maklumat Taman",        "ok"),
    ("Maklumat Poskod",       "ok"),
    ("Maklumat Bandar",       "ok"),
    ("Maklumat Negeri",       "ok"),
    ("Lokasi Kesalahan",      "ok"),
    ("Butiran Kesalahan",     "ok"),
    ("Maklumat Kompaun",      "ok"),
    ("KETERANGAN KOD KOMPAUN", "gagal"),
    ("KOD AKTA",              "gagal"),
    ("KESALAHAN KOMPAUN",     "gagal"),
    ("PILIH KADAR DENDA",     "gagal"),
    ("OPEN CAMERA",           "gagal"),
]


def tulis(baris):
    try:
        sys.stdout.write(baris + "\n")
    except UnicodeEncodeError:
        sys.stdout.buffer.write((baris + "\n").encode("ascii",
                                                      "backslashreplace"))


def nod_berteks(src):
    try:
        akar = ET.fromstring(src)
    except Exception:                                           # noqa: BLE001
        return []
    keluar = []
    for n in akar.iter():
        t = (n.get("text") or "").strip()
        d = (n.get("content-desc") or "").strip()
        if not (t or d):
            continue
        keluar.append({
            "kelas": (n.get("class") or "").split(".")[-1],
            "bounds": n.get("bounds") or "",
            "text": t, "desc": d,
            "clickable": (n.get("clickable") or "") == "true",
            "focused": (n.get("focused") or "") == "true",
        })
    return keluar


def snapshot(drv, nama, tajuk_manusia):
    os.makedirs(DIR_RECON, exist_ok=True)
    asas = os.path.join(DIR_RECON, f"tabkompaun-{nama}")
    try:
        src = drv.page_source
    except Exception as e:                                      # noqa: BLE001
        tulis(f"    page_source gagal: {e}")
        return None, []
    with open(asas + ".xml", "w", encoding="utf-8") as fh:
        fh.write(src)
    try:
        drv.get_screenshot_as_file(asas + ".png")
    except Exception:                                           # noqa: BLE001
        pass

    from guard import dasar
    nod = nod_berteks(src)
    tulis("")
    tulis("  " + "=" * 66)
    tulis(f"  == {tajuk_manusia}")
    tulis("  " + "=" * 66)
    tulis(f"    tajuk app-bar  : {dasar.tajuk_appbar(src)!r}")
    tulis(f"    konteks mutasi : {dasar.konteks_mod_sebenar(src)!r}")
    tulis(f"    tab bar hadir  : "
          f"{any(n['desc'] in ('PESALAH', 'KOMPAUN', 'PENERIMA') for n in nod)}")
    tulis(f"    bil. node teks : {len(nod)}")
    tulis(f"    EditText       : "
          f"{sum(1 for n in nod if n['kelas'] == 'EditText')}")
    tulis(f"    -> {os.path.relpath(asas, AKAR)}.xml / .png")

    tulis("")
    tulis("    KANDUNGAN PENUH:")
    for n in nod:
        label = n["text"] or n["desc"]
        if len(label) > 44:
            label = label[:41] + "..."
        bendera = ("clk" if n["clickable"] else "   ")
        bendera += " FOKUS" if n["focused"] else ""
        tulis(f"      {n['kelas']:<11} {n['bounds']:<24} {bendera:<10} "
              f"{label!r}")
    return src, nod


def lapor_medan(nod):
    """Untuk setiap medan yang pemilik namakan: hadir? berisi? nilai?

    Ini soalan yang membezakan 'locator salah' daripada 'medan sudah
    berisi jadi placeholder hilang'. Yang kedua tidak boleh dilihat
    daripada log kegagalan langsung.
    """
    tulis("")
    tulis("    STATUS MEDAN (jangkaan pemilik lawan skrin sebenar):")
    tulis(f"      {'MEDAN':<24} {'PEMILIK':<8} {'PADA SKRIN':<12} NILAI")
    for nama, jangkaan in MEDAN_DIJANGKA:
        padan = [n for n in nod
                 if nama.lower() in (n["text"] + " " + n["desc"]).lower()]
        if not padan:
            tulis(f"      {nama:<24} {jangkaan:<8} {'TIADA':<12} -")
            continue
        n = padan[0]
        # Placeholder hadir bermakna medan KOSONG. Kalau teks node ialah
        # sesuatu yang lain, medan itu BERISI dan placeholdernya hilang —
        # dan carian ikut placeholder akan gagal walaupun medan elok.
        placeholder = n["text"].strip().lower() == nama.strip().lower()
        keadaan = "KOSONG" if placeholder else "BERISI"
        nilai = "-" if placeholder else (n["text"] or n["desc"])[:34]
        tulis(f"      {nama:<24} {jangkaan:<8} {keadaan:<12} {nilai!r}")


def main():
    from devtools import peringkat6 as P6
    from devtools.smoke_tangga import peringkat_1, peringkat_2, \
        pastikan_di_home
    from device_utils import resolve_udid
    from config import APP_PACKAGE
    from testdata import oracle_pk

    tulis("=" * 70)
    tulis("== IMBASAN tab KOMPAUN — borang Kompaun Pelbagai")
    tulis("== BACA SAHAJA. Mod sebenar TIDAK dihidupkan.")
    tulis("=" * 70)

    serial = resolve_udid(APP_PACKAGE, verbose=False)
    p1 = peringkat_1(serial)
    if not p1["ok"]:
        return 1
    P6.baseline_global = p1["baseline"]

    drv = pages = None
    try:
        drv, pages = peringkat_2()

        # >>> KEADAAN DRAF — hipotesis utama. <<<
        # `draf hilang=False` muncul dalam setiap larian gagal. Kalau
        # borang membawa draf, medannya sudah berisi dan setiap carian
        # ikut placeholder akan gagal.
        tulis("\n  [DRAF] relaunch untuk borang bersih...")
        P6.relaunch(drv, pages, "imbasan tab kompaun: borang bersih")
        if not pastikan_di_home(drv, pages):
            tulis("HENTI: tidak sampai skrin utama")
            return 1

        data = dict(oracle_pk.P001)
        p = pages.daftar_kompaun
        P6._pakai_sauh_alamat(serial, data, oracle_pk.K001)

        pages.home.open_daftar_kompaun()
        p.select_jenis_kompaun("Kompaun Pelbagai")
        _src, nod = snapshot(drv, "A-jenis-dipilih",
                             "A — sebaik jenis Pelbagai dipilih")
        lapor_medan(nod)

        tulis("\n  mengisi tab Pesalah (laluan sedia ada)...")
        p.fill_pesalah_tab(data)
        snapshot(drv, "B-pesalah-siap", "B — tab Pesalah selesai")

        tulis("\n  menekan SETERUSNYA -> tab Kompaun...")
        p.click_seterusnya_from_pesalah()
        time.sleep(2.5)
        _src, nod = snapshot(drv, "C-kompaun-mula",
                             "C — tab Kompaun, SEBELUM apa-apa disentuh")
        lapor_medan(nod)

        # >>> ISI MEDAN YANG PEMILIK SAHKAN BERFUNGSI. <<<
        # Kita mesti berada dalam keadaan SEBENAR sebelum menguji
        # mekanisme mencapai bahagian bawah — borang kosong berkelakuan
        # lain daripada borang terisi (IME, auto-isi, re-render).
        tulis("\n  mengisi medan atas (jalan..butiran) — laluan sedia ada...")
        try:
            p.fill_kompaun_tab(data)
            tulis("    fill_kompaun_tab SELESAI tanpa exception")
        except Exception as e:                                  # noqa: BLE001
            tulis(f"    fill_kompaun_tab membangkit {type(e).__name__}: "
                  f"{str(e).splitlines()[0][:140]}")
        _src, nod = snapshot(drv, "D-selepas-isi-atas",
                             "D — selepas mengisi medan atas")
        lapor_medan(nod)

        # >>> UJIAN MEKANISME: bagaimana mencapai OPEN CAMERA? <<<
        # OPEN CAMERA ialah sasaran yang BETUL-BETUL di bawah lipatan
        # (snapshot C: tingkat-1 dropdown sudah terpotong pada y=2316).
        # Imbasan pertama saya menyasarkan Butiran Kesalahan, yang MEMANG
        # sudah kelihatan — jadi reveal_below_fold pulang serta-merta dan
        # saya tersalah simpul "traversal tidak menggerakkan skrin ini".
        #
        # Dua mekanisme diuji, dan yang KEDUA membawa risiko yang sudah
        # direkod: base_page.py:3006 mencatat "scrolling the page
        # destroys form progress". Kita UKUR dakwaan itu — nilai medan
        # dibaca sebelum dan selepas.
        def nilai_medan_atas():
            keluar = {}
            for n in nod_berteks(drv.page_source):
                if n["kelas"] != "EditText":
                    continue
                keluar[n["bounds"]] = n["text"]
            return keluar

        # >>> BACA-BALIK: nilai BETUL masuk, bukan sekadar tiada ralat. <<<
        # `fill_kompaun_tab` yang selesai tanpa exception hanya bermakna
        # setiap medan DIJUMPAI. Ia tidak membuktikan nilai mendarat di
        # medan yang BETUL — dan projek ini sudah pernah tertipu oleh
        # beza itu (D-05: menaip No. Kereta mencerminkan plat ke medan
        # identiti, jadi rekod K-001 membawa plat sebagai nama pesalah).
        tulis("\n  BACA-BALIK medan atas (gulung ke atas dahulu)...")
        p.gulung_borang_ke_atas()
        time.sleep(1)
        _src, nod_atas = snapshot(drv, "D2-baca-balik-atas",
                                  "D2 — digulung ke atas untuk baca-balik")
        jangka = {
            "Lokasi Kesalahan": data.get("lokasi_kesalahan"),
            "Butiran Kesalahan": data.get("butiran_kesalahan"),
        }
        tulis("")
        tulis("    BACA-BALIK:")
        for label, dijangka in jangka.items():
            padan = [n for n in nod_atas if n["kelas"] == "EditText"
                     and dijangka and dijangka[:24].upper()
                     in (n["text"] or "").upper()]
            kosong = [n for n in nod_atas if n["kelas"] == "EditText"
                      and (n["text"] or "").strip().lower() == label.lower()]
            if padan:
                tulis(f"      {label:<20} TERISI BETUL  "
                      f"{padan[0]['text'][:40]!r}")
            elif kosong:
                tulis(f"      {label:<20} *** MASIH KOSONG *** "
                      f"(placeholder kekal)")
            else:
                tulis(f"      {label:<20} TIDAK PASTI — tiada padanan "
                      f"dan tiada placeholder")
        lapor_medan(nod_atas)

        tulis("\n  MEKANISME 1: reveal_below_fold -> OPEN CAMERA")
        sebelum = nilai_medan_atas()
        try:
            p.reveal_below_fold(p.BUTTON_OPEN_CAMERA, max_tabs=10)
            tulis("    traversal selesai tanpa exception")
        except Exception as e:                                  # noqa: BLE001
            tulis(f"    traversal membangkit {type(e).__name__}: "
                  f"{str(e).splitlines()[0][:140]}")
        _src, nod = snapshot(drv, "E-traversal-ke-kamera",
                             "E — selepas traversal menyasarkan OPEN CAMERA")
        selepas = nilai_medan_atas()
        tulis(f"    medan berubah selepas traversal: "
              f"{'TIADA' if sebelum == selepas else 'ADA'}")

        tulis("\n  MEKANISME 2: UiScrollable instance(0) -> OPEN CAMERA")
        tulis("    (base_page.py:3006 mendakwa ini memusnahkan isi borang"
              " — kita ukur)")
        sebelum2 = nilai_medan_atas()
        try:
            from appium.webdriver.common.appiumby import AppiumBy
            drv.find_element(
                AppiumBy.ANDROID_UIAUTOMATOR,
                'new UiScrollable(new UiSelector().scrollable(true)'
                '.instance(0)).scrollIntoView('
                'new UiSelector().descriptionMatches("(?i).*OPEN\\s*CAMERA.*"));')
            tulis("    scrollIntoView selesai tanpa exception")
        except Exception as e:                                  # noqa: BLE001
            tulis(f"    scrollIntoView membangkit {type(e).__name__}: "
                  f"{str(e).splitlines()[0][:140]}")
        _src, nod = snapshot(drv, "F-uiscrollable-ke-kamera",
                             "F — selepas UiScrollable instance(0)")
        selepas2 = nilai_medan_atas()
        hilang = [b for b, v in sebelum2.items()
                  if selepas2.get(b) not in (None, v)]
        tulis(f"    medan berubah selepas scroll: "
              f"{'TIADA' if sebelum2 == selepas2 else 'ADA'}")
        tulis(f"    dakwaan 'scrolling destroys form progress': "
              f"{'DISOKONG' if hilang else 'TIDAK DISOKONG dalam larian ini'}")
        lapor_medan(nod)

        tulis("\n" + "=" * 70)
        tulis("== Tiada serah, tiada cetak, tiada kamera. Keluar.")
        tulis("=" * 70)
        for _ in range(5):
            try:
                drv.back()
                time.sleep(1)
            except Exception:                                   # noqa: BLE001
                break
        P6.post_check(serial, p1["baseline"], "imbasan-tab-kompaun")
        return 0
    finally:
        if drv is not None:
            c = getattr(drv, "corong", None)
            if c is not None:
                tulis(f"\n  [CORONG] {c.bil_tap} tap dinilai, "
                      f"{c.bil_sekat} disekat")
            try:
                drv.quit()
            except Exception:                                   # noqa: BLE001
                pass


if __name__ == "__main__":
    sys.exit(main())

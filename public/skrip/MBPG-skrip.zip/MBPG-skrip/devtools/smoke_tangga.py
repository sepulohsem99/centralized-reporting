"""
TANGGA SMOKE MBPG — dijalankan berperingkat, berhenti pada kegagalan
PERTAMA.

    python devtools/smoke_tangga.py --sampai 2      # sampai login sahaja
    python devtools/smoke_tangga.py --sampai 3      # + selaras T-003/4/5
    python devtools/smoke_tangga.py --sampai 4      # + checkpoint sauh

Bukan pytest: tangga ini perlu berhenti KEMAS pada peringkat tertentu
dengan sesi masih hidup supaya peringkat seterusnya boleh diputuskan
oleh manusia. Fixture pytest akan merobohkan sesi antara peringkat, dan
membina semula sesi bermakna melalui gerbang IP (yang menavigasi skrin
Tetapan production) sekali lagi setiap kali.

Corong dry-run terpakai penuh — driver datang dari create_driver() yang
sama seperti suite.

SELARAS PELESEN TIDAK DISENTUH. Tiada butang selaras-semua digunakan;
setiap modul ditekan satu per satu.
"""

import argparse
import json
import os
import sqlite3
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
AKAR = os.path.dirname(HERE)
sys.path.insert(0, AKAR)

APP = "com.anonymous.react_ies_v1"
DB_DEV = f"/data/data/{APP}/files/SQLite/e_kompaunV1.db"

# Sauh oracle N-001 yang checkpoint mesti jumpa.
SAUH_JALAN = ("JALAN KALOI 13", "JALAN LEMBAH 19")
SAUH_TAMAN = ("TANJONG PUTERI RESORT", "BANDAR SERI ALAM")

# Jadual yang mesti KEKAL kosong sepanjang misi ini.
#
# >>> DILUASKAN 2026-08-12 selepas ia terlepas sesuatu yang nyata. <<<
# Senarai lama memantau TIGA jadual sahaja. DB peranti mempunyai EMPAT
# BELAS jadual transaksi, dan salah satu yang tidak dipantau —
# `local_ekpn_notis_amaran_details` — mengandungi 4 baris yang ditulis
# semasa memandu borang, lengkap dengan nombor notis yang diperuntukkan
# (`PGP02N2608120xx`). Post-check melaporkan "bersih" pada setiap
# larian kerana ia tidak pernah melihat ke sana.
#
# Baris itu BUKAN rekod notis — jadual notis induk kekal 0, tiada apa
# diserah, tiada apa muncul dalam senarai. Tetapi ia tetap kesan yang
# ditinggalkan pada DB production, dan alat yang mendakwa "0 rekod"
# mesti benar-benar memeriksa tempat rekod boleh muncul.
#
# Pengajaran yang sama seperti .gitignore: senaraikan KELAS (setiap
# jadual transaksi), bukan tiga nama yang kebetulan terlintas.
JADUAL_REKOD = (
    "local_ekpn_notis_amaran",
    "local_ekpn_notis_amaran_details",
    "local_ekpn_notis_amaran_patuh_doc",
    "local_ekpn_batal_notis_amaran",
    "local_ekpn_notis_to_kompaun",
    "local_ekpn_notis_to_complied_kompaun",
    "local_ekpn_tawaran_kompaun",
    "local_ekpn_tawaran_kompaun_details",
    "local_ekpn_tawaran_kompaun_doc",
    "local_ekpn_sita",
    "local_ekpn_sita_details",
    "local_ekpn_sita_doc",
    "local_ekpn_sita_batal",
    "local_ekpn_batal",
    "local_ekpn_penerima_cetakan",
)


def tarik_db(serial, ke):
    """Salinan DB tempatan app. Baca-sahaja: kami tidak pernah menulis
    balik. `exec-out` + `run-as cat` kerana adb pull tidak boleh membaca
    direktori peribadi app."""
    os.makedirs(os.path.dirname(ke), exist_ok=True)
    with open(ke, "wb") as fh:
        p = subprocess.run(["adb", "-s", serial, "exec-out",
                            f"run-as {APP} cat {DB_DEV}"],
                           stdout=fh, stderr=subprocess.PIPE)
    if p.returncode != 0 or os.path.getsize(ke) == 0:
        raise RuntimeError(f"tidak dapat menarik DB: "
                           f"{p.stderr.decode(errors='replace')[:200]}")
    return ke


def keadaan_rekod(db):
    """(kiraan_baris, kaunter_siri) — DUA ukuran, bukan satu.

    Kiraan baris sahaja TIDAK mencukupi sebagai tripwire. `local_system_
    control.newserial` sudah berada pada 2 untuk nonotis walaupun jadual
    notis kosong — bermakna satu rekod pernah wujud dan hilang dari
    jadual tempatan. Rekod yang dicipta lalu disegerakkan boleh
    meninggalkan kiraan 0 sambil menaikkan kaunter. Kami memerhati
    kedua-duanya."""
    c = sqlite3.connect(db)
    kira = {t: c.execute(f'SELECT COUNT(*) FROM "{t}"').fetchone()[0]
            for t in JADUAL_REKOD}
    siri = {r[0]: r[2] for r in
            c.execute("SELECT tablename, fieldname, newserial "
                      "FROM local_system_control")}
    c.close()
    return kira, siri


def lapor(tag, ok, mesej=""):
    print(f"  [{'OK ' if ok else 'GAGAL'}] {tag}" + (f" — {mesej}" if mesej else ""))
    return ok


# ---------------------------------------------------------------------------

def peringkat_1(serial):
    """adb + app + IP + baseline rekod. Semuanya baca-sahaja."""
    print("\n== PERINGKAT 1: device / app / IP / baseline ==")
    from config import APP_PACKAGE, APK_VERSI_DIJANGKA
    from device_utils import app_version, device_model

    ver = app_version(serial, APP_PACKAGE)
    lapor(f"device {serial} ({device_model(serial)})", True)
    padan = (ver == APK_VERSI_DIJANGKA)
    lapor(f"app build {ver}", padan,
          "" if padan else f"oracle menjangka {APK_VERSI_DIJANGKA} — "
                           f"setiap perbezaan nanti TAKSA (pepijat vs build)")

    db = tarik_db(serial, os.path.join(AKAR, "data", "tmp", "baseline.db"))
    c = sqlite3.connect(db)
    ip = c.execute("SELECT ip_address FROM local_connection_details").fetchone()
    c.close()
    ok_ip = ip and ip[0].strip() == "113.211.155.174"
    lapor(f"IP tetapan app = {ip[0] if ip else '?'}", bool(ok_ip))

    kira, siri = keadaan_rekod(db)
    # >>> BASELINE BUKAN-SIFAR DIBENARKAN, TETAPI TIDAK DISENYAPKAN. <<<
    # Sebelum ini gerbang ini menuntut SETIAP jadual sifar. Sebaik
    # senarai diluaskan kepada ke-15 jadual transaksi, ia mendedahkan 4
    # baris sedia ada dalam `local_ekpn_notis_amaran_details` — jadi
    # setiap larian berhenti sebelum bermula.
    #
    # Menuntut sifar bermakna satu-satunya cara meneruskan ialah MEMADAM
    # baris dari DB production. Itu lebih teruk daripada apa yang
    # gerbang ini cuba halang.
    #
    # Yang sebenarnya penting bukan "kosong" tetapi "TIDAK BERTAMBAH":
    # post_check() memang membandingkan terhadap baseline ini, bukan
    # terhadap sifar. Jadi baseline bukan-sifar direkod, dinamakan
    # dengan kuat, dan diluluskan — dan pertumbuhan sekecil satu baris
    # tetap menghentikan misi.
    tidak_kosong = {t: v for t, v in kira.items() if v}
    lapor(f"baseline rekod: {len(tidak_kosong)} jadual bukan-kosong", True)
    if tidak_kosong:
        print(f"         >>> BASELINE BUKAN-SIFAR: {tidak_kosong}")
        print("         Baris ini SUDAH ADA sebelum larian ini. Ia tidak "
              "dipadam.")
        print("         Post-check menuntut kiraan TIDAK BERTAMBAH dari "
              "titik ini.")
    else:
        print("         semua jadual transaksi KOSONG")
    print(f"         kaunter siri: {siri}")
    return {"ok": bool(ok_ip), "versi_padan": padan,
            "baseline": (kira, siri)}


def peringkat_2():
    """T-012 — sampai ke skrin utama.

    TIGA keadaan mungkin, dan hanya SATU daripadanya ialah log masuk:

      (a) app di latar belakang / pada skrin dalam, sesi MASIH AKTIF
          -> bawa ke depan, undur ke skrin utama. TIADA login.
             Ini keadaan biasa: no_reset=True + remember-me.
             Ia juga BUKTI T-012 (sesi bertahan) — direkod sedemikian.
      (b) sudah pada skrin utama -> tiada apa perlu dibuat.
      (c) benar-benar pada skrin login -> barulah log masuk.

    Versi pertama fungsi ini menganggap (c) sentiasa benar dan memanggil
    login() terus, yang gagal dengan "Login screen not displayed" apabila
    sesi sebenarnya masih hidup. Membezakan ketiga-tiga keadaan itu
    penting: log masuk semula bukan sekadar mubazir, ia memerlukan skrin
    login yang hanya boleh dicapai dengan LOG KELUAR — dan log keluar
    menekan YA, yang trip-wire.
    """
    print("\n== PERINGKAT 2: sampai ke skrin utama (T-012) ==")
    from tests.conftest import create_driver, Pages
    from config import TEST_CREDENTIALS, APP_PACKAGE

    drv = create_driver()
    pages = Pages(drv)
    lapor("sesi Appium + gerbang IP", True)

    # Bawa app ke depan tanpa restart (activate, BUKAN terminate).
    try:
        drv.activate_app(APP_PACKAGE)
        time.sleep(2)
    except Exception as e:                                    # noqa: BLE001
        print(f"         activate_app: {type(e).__name__}: {e}")

    if pages.home.is_home_screen_displayed():
        lapor("skrin utama (sesi kekal — bukti T-012)", True)
        return drv, pages

    if pages.login.is_login_screen_displayed(bersihkan=False):
        lapor("pada skrin login — melakukan log masuk penuh", True)
        pages.login.login(TEST_CREDENTIALS["username"],
                          TEST_CREDENTIALS["password"])
        ok = pages.home.is_home_screen_displayed()
        lapor("skrin utama selepas login", ok)
        if not ok:
            raise RuntimeError("login tidak sampai ke skrin utama")
        return drv, pages

    # Keadaan (a): sesi hidup, kita berada di suatu skrin dalam.
    #
    # Undur mesti SEDAR-KEADAAN-APP. Gerbang IP sudah menekan Back tiga
    # kali sebelum kami sampai ke sini; menambah lapan lagi secara membuta
    # menolak app KELUAR ke launcher, dan setiap Back selepas itu pergi
    # kepada Android, bukan kepada app. Itu yang berlaku pada percubaan
    # pertama: sebelas Back, dan pemeriksaan skrin utama menyemak
    # launcher.
    # Modal pressable yang tersekat: back tidak menutupnya, jadi cuba
    # backdrop dahulu (lihat nota dalam pastikan_di_home).
    try:
        if pages.daftar_kompaun._baris_modal_kini():
            print("         modal dropdown terbuka — menutup via backdrop")
            pages.daftar_kompaun._tutup_modal_pressable()
            time.sleep(1.0)
            if pages.home.is_home_screen_displayed():
                lapor("skrin utama selepas menutup modal", True)
                return drv, pages
    except Exception:                                         # noqa: BLE001
        pass

    print("         sesi aktif tetapi bukan pada skrin utama — undur "
          "(sedar-keadaan-app)...")
    for _ in range(10):
        if drv.query_app_state(APP_PACKAGE) < 4:      # 4 = di hadapan
            print("         app keluar ke latar — activate semula")
            drv.activate_app(APP_PACKAGE)
            time.sleep(2)
            if pages.home.is_home_screen_displayed():
                break
            continue
        pages.home.dismiss_native_alerts(context="peringkat-2: undur")
        if pages.home.is_home_screen_displayed():
            break
        if pages.login.is_login_screen_displayed(bersihkan=False):
            print("         skrin login muncul semasa undur — log masuk")
            pages.login.login(TEST_CREDENTIALS["username"],
                              TEST_CREDENTIALS["password"])
            break
        pages.home.press_back()
        time.sleep(1.0)

    ok = pages.home.is_home_screen_displayed()
    lapor("skrin utama (sesi kekal — bukti T-012)", ok)
    if not ok:
        _diagnosis_skrin(drv, "peringkat2_tidak_sampai_home")
        raise RuntimeError("tidak sampai ke skrin utama — lihat diagnosis "
                           "di atas dan screenshot dalam reports/forensik/")
    return drv, pages


def _diagnosis_skrin(drv, tag):
    """Apa yang SEBENARNYA di skrin. Melalui Appium, bukan `adb shell
    uiautomator dump` — dump adb berebut dengan pelayan UiAutomator2
    Appium dan boleh membunuh sesi (diperhatikan 2026-08-07)."""
    import re
    print(f"  [DIAGNOSIS] {tag}")
    try:
        print(f"         activity: {drv.current_activity}")
    except Exception:                                         # noqa: BLE001
        pass
    try:
        src = drv.page_source
        teks = sorted(set(re.findall(r'text="([^"]{2,60})"', src)))
        print(f"         {len(teks)} teks pada skrin:")
        for t in teks[:25]:
            print(f"           - {t}")
    except Exception as e:                                    # noqa: BLE001
        print(f"         page_source gagal: {type(e).__name__}: {e}")
    try:
        d = os.path.join(AKAR, "reports", "forensik")
        os.makedirs(d, exist_ok=True)
        p = os.path.join(d, f"{time.strftime('%Y%m%d-%H%M%S')}_{tag}.png")
        drv.get_screenshot_as_file(p)
        print(f"         screenshot: {p}")
    except Exception:                                         # noqa: BLE001
        pass


def peringkat_t001(pages, serial):
    """MBPG-TC-T-001 — BACA-SAHAJA. Tiada tulisan config lagi.

    >>> DIHENTIKAN MENULIS 2026-08-10, arahan pemilik. <<<
    Versi terdahulu mengisi medan Internal dan menekan SIMPAN. Ia
    BERJAYA setiap kali — taip, SIMPAN dibenarkan konteks Tetapan,
    read-back skrin sahkan, DB sahkan — tetapi nilainya HILANG selepas
    app dimulakan semula, dua run berturut-turut.

    `local_connection_details` hanya membawa satu baris, `status='Ext'`.
    App nampaknya memersist satu alamat sahaja; medan Internal tidak
    pernah disimpan. Itu DEFEK APP (lihat docs/DEFEK-MBPG-2.1.21.md),
    bukan sesuatu yang boleh diperbaiki dengan menulis semula.

    Maka kami berhenti menulisnya. Mengulang tulisan config pada peranti
    production untuk mengejar nilai yang app sendiri buang bukan ujian —
    ia cuma kebisingan pada sistem hidup.

    T-001 dikira LULUS: alamat yang app SEBENARNYA gunakan (External)
    disahkan betul pada skrin DAN dalam DB. Separuh 'Internal persist'
    direkod sebagai defek.
    """
    print("\n== T-001: Tetapan Alamat IP (BACA-SAHAJA) ==")
    from config import LICENSE_SETTINGS
    jangka = LICENSE_SETTINGS["internal_ip"]
    p = pages.pelarasan

    p.ensure_on_login_screen()
    p.open_menu_selaras()
    baca = p.baca_tetapan_alamat_ip()
    print(f"  [T-001] skrin: internal={baca[0]!r} external={baca[1]!r}")
    p.close_menu_selaras()

    db = tarik_db(serial, os.path.join(AKAR, "data", "tmp", "t001.db"))
    c = sqlite3.connect(db)
    baris = c.execute("SELECT ip_address, status FROM "
                      "local_connection_details").fetchall()
    c.close()

    ok_ext = baca[1] == jangka
    ok_db = bool(baris) and all(str(b[0]).strip() == jangka for b in baris)
    lapor(f"External pada skrin = {jangka}", ok_ext)
    lapor(f"DB tetapan = {baris}", ok_db)
    if not baca[0]:
        print("  [T-001] Internal KOSONG — defek persistence yang diketahui, "
              "TIDAK diisi semula (arahan pemilik 2026-08-10)")

    _RUN_META_T001.update({
        "internal_skrin": baca[0], "external_skrin": baca[1],
        "db": str(baris),
        "nota": ("LULUS pada alamat yang app gunakan (External). Internal "
                 "kekal kosong — defek persistence, tidak diisi semula."),
    })
    return ok_ext and ok_db


_RUN_META_T001 = {}


def peringkat_t001_pasca_relaunch(drv, pages, serial):
    """Post-verify: relaunch app, sahkan main menu normal + IP kekal."""
    print("\n== T-001 post-verify: relaunch app ==")
    from config import APP_PACKAGE, LICENSE_SETTINGS
    jangka = LICENSE_SETTINGS["internal_ip"]
    drv.terminate_app(APP_PACKAGE)
    time.sleep(2)
    drv.activate_app(APP_PACKAGE)
    time.sleep(5)

    db = tarik_db(serial, os.path.join(AKAR, "data", "tmp",
                                       "pasca_relaunch.db"))
    c = sqlite3.connect(db)
    baris = c.execute("SELECT ip_address, status FROM "
                      "local_connection_details").fetchall()
    c.close()
    ok_ip = bool(baris) and all(str(b[0]).strip() == jangka for b in baris)
    lapor(f"IP dalam DB kekal selepas relaunch: {baris}", ok_ip)

    di_home = pages.home.is_home_screen_displayed()
    di_login = pages.login.is_login_screen_displayed(bersihkan=False)
    lapor(f"app berkelakuan normal (home={di_home} login={di_login})",
          di_home or di_login)
    if not (di_home or di_login):
        _diagnosis_skrin(drv, "t001_pasca_relaunch_skrin_pelik")
        print("\nHENTI: app tidak berada pada skrin yang dikenali selepas "
              "relaunch.")
        return False
    if di_login:
        from config import TEST_CREDENTIALS
        pages.login.login(TEST_CREDENTIALS["username"],
                          TEST_CREDENTIALS["password"])
        lapor("log masuk semula ke skrin utama",
              pages.home.is_home_screen_displayed())
    return ok_ip


def peringkat_3(pages):
    """T-003 Selaras Pengguna -> T-004 Selaras Alamat -> T-005 Selaras
    Kompaun. SATU PER SATU. Pelesen tidak disentuh."""
    print("\n== PERINGKAT 3: selaras T-003 / T-004 / T-005 ==")
    p = pages.pelarasan
    p.ensure_on_login_screen()
    p.open_menu_selaras()
    hasil = {}
    for tc, nama, fn in (
        ("MBPG-TC-T-003", "Selaras Pengguna Apps", p.selaras_pengguna_apps),
        ("MBPG-TC-T-004", "Selaras Maklumat Alamat", p.selaras_maklumat_alamat),
        ("MBPG-TC-T-005", "Selaras Maklumat Kompaun", p.selaras_maklumat_kompaun),
    ):
        try:
            ok = fn() is not False
        except Exception as e:                                # noqa: BLE001
            ok = False
            print(f"         {type(e).__name__}: {e}")
        hasil[tc] = ok
        lapor(f"{tc} {nama}", ok)
        if not ok:
            break
    p.close_menu_selaras()
    return hasil


def peringkat_4(serial, tarikh):
    """CHECKPOINT: sauh oracle N-001 mesti wujud dalam snapshot jalan.

    Dibaca dari DB tempatan app, bukan diteka melalui autocomplete:
    autocomplete hanya memaparkan baris yang sepadan dengan apa yang
    ditaip, jadi 'tidak muncul' di sana taksa antara "tiada dalam DB"
    dan "carian tidak sepadan". DB memberi jawapan muktamad."""
    print("\n== PERINGKAT 4: CHECKPOINT sauh oracle N-001 ==")
    dir_snap = os.path.join(AKAR, "data", f"snapshot-{tarikh}")
    os.makedirs(dir_snap, exist_ok=True)
    db = tarik_db(serial, os.path.join(dir_snap, "e_kompaunV1.db"))
    c = sqlite3.connect(db)
    c.row_factory = sqlite3.Row

    jalan = [dict(r) for r in c.execute(
        "SELECT * FROM local_ekpn_jalan ORDER BY nama")]
    taman = [dict(r) for r in c.execute(
        "SELECT * FROM local_ekpn_taman ORDER BY nama")]
    with open(os.path.join(dir_snap, "jalan.json"), "w",
              encoding="utf-8") as fh:
        json.dump(jalan, fh, ensure_ascii=False, indent=1)
    with open(os.path.join(dir_snap, "taman.json"), "w",
              encoding="utf-8") as fh:
        json.dump(taman, fh, ensure_ascii=False, indent=1)
    print(f"         snapshot: {len(jalan)} jalan, {len(taman)} taman "
          f"-> {dir_snap}")

    peta_taman = {str(t["kod"]): t["nama"] for t in taman}
    semua_ok = True
    for nama in SAUH_JALAN:
        padan = [j for j in jalan if (j["nama"] or "").strip().upper() == nama]
        ok = len(padan) == 1
        semua_ok &= ok
        ket = ""
        if padan:
            t = peta_taman.get(str(padan[0]["taman"]), "?")
            ket = f"taman={t!r} poskod={padan[0]['poskod']!r}"
        lapor(f"jalan {nama!r}", ok, ket)
    for nama in SAUH_TAMAN:
        ok = any((t["nama"] or "").strip().upper() == nama for t in taman)
        semua_ok &= ok
        lapor(f"taman {nama!r}", ok)
    c.close()

    if not semua_ok:
        print("\n  SAUH TIDAK LENGKAP — semua baris jalan ada dalam "
              f"{dir_snap}/jalan.json untuk semakan pemilik.")
    return semua_ok


def pastikan_di_home(drv, pages):
    """Bawa app ke skrin utama dari mana-mana keadaan yang munasabah.

    Diperlukan kerana peringkat sebelum ini meninggalkan app di tempat
    berbeza: T-001 memanggil ensure_on_login_screen(), yang memaksa
    relaunch dan berakhir pada skrin LOGIN. Peringkat 5 kemudian cuba
    mengetuk kad skrin utama dan gagal — bukan kerana kad itu hilang,
    tetapi kerana kita berada pada skrin yang salah.

    Logik yang sama seperti peringkat_2; diasingkan supaya kedua-duanya
    tidak boleh menyimpang.
    """
    from config import APP_PACKAGE, TEST_CREDENTIALS

    # >>> DITAMBAH 2026-09-13 -- Fix #4 (blocker larian 10/9). <<<
    # Popup 'CETAK NOTIS AMARAN ?' yang tersekat MESTI ditutup PALING
    # AWAL, sebelum apa-apa lain. Bukti forensik 2026-09-10 (reports/
    # forensik/20260910-152937-borang-N.png dan 2 lagi identik untuk
    # borang P dan K): popup ini muncul selepas SERAH/kemaskini dan
    # KEKAL TERBUKA -- ia modal JS React Native, BUKAN alert native
    # Android, jadi dismiss_native_alerts() DAN 8 tekanan back di bawah
    # (~365s) kedua-duanya TIADA KESAN terhadapnya. Itulah sebabnya
    # gelung asal (tanpa semakan ini) gagal pulang ke skrin utama pada
    # SEMUA 5 percubaan borang (N/P/K x3) larian tersebut. Diletak
    # SEBELUM semakan modal dropdown kerana ura-ura ini boleh menutupi
    # SELURUH skrin (termasuk kad grid utama), jadi is_home_screen_
    # displayed() di bawah akan sentiasa palsu selagi ia belum ditutup.
    popup_cetak_ditutup = False
    try:
        popup_cetak_ditutup = pages.cetak.tutup_popup_cetak(timeout=2)
        if not popup_cetak_ditutup:
            print("         AMARAN: popup CETAK dikesan tetapi GAGAL "
                  "ditutup -- sambung cuba pemulihan lain di bawah")
    except Exception as e:                                        # noqa: BLE001
        print(f"         semakan popup CETAK: {type(e).__name__}: {e}")

    # >>> DITAMBAH 2026-09-14 -- Fix #7 (HIPOTESIS, D-10, BELUM
    # disahkan 100% -- lihat docs/D-10-CETAK-X-RALAT-KOMPAUN-SELEPAS-
    # KEMASKINI.md). <<<
    # Bukti forensik 2026-09-14 (reports/forensik/20260914-100332__
    # tiada__OK.*): selepas popup CETAK ditutup via X dlm konteks
    # skrin KEMASKINI, skrin di belakangnya (cth. KemaskiniNotisAmaran)
    # kelihatan MASIH TERBUKA (tangkapan skrin N-001-03-selepas-
    # kemaskini-20260914-100315.png) -- bukan dinavigasi keluar. Serta-
    # merta selepas itu, satu alert NATIF Android "RALAT | SILA PILIH
    # KOMPAUN, AKTA DAN KESALAHAN" muncul, yang disekat BETUL oleh
    # trip-wire OK gerbang (dialog tak dikenali) -- seluruh run
    # DIBATALKAN sebelum sempat cuba pulih.
    #
    # Tekan BACK peranti SEKALI di sini (bukan tap elemen, TIDAK
    # melalui laluan OK-intercept corong -- press_back() dipakai
    # berulang kali dlm fungsi INI SENDIRI, baris ~550, tanpa isu
    # gerbang) SEBELUM is_home_screen_displayed()/dismiss_native_
    # alerts() sempat cuba TAP OK pada alert yang mungkin sudah wujud.
    # Kalau alert RALAT itu native AlertDialog standard Android (bukan
    # modal RN), BACK patut menutupnya (cancel) tanpa melalui tap OK
    # sama sekali, mengelak DryRunViolation terus. Kalau tiada alert,
    # ini cuma satu langkah navigasi tambahan (selamat, konsisten
    # dengan gelung press_back() sedia ada di bawah).
    #
    # SAHKAN-DEVICE: hipotesis ini belum diuji live. Kalau alert masih
    # muncul selepas BACK ini (cth. AlertDialog itu sebenarnya modal RN
    # yang mengabaikan back, macam popup CETAK asal), gerbang akan
    # tetap menyekat OK dgn betul seperti biasa -- TIADA risiko
    # keselamatan drpd cubaan ini, ia hanya cuba SATU langkah pemulihan
    # tambahan lebih awal.
    if popup_cetak_ditutup:
        try:
            print("         [FIX#7] popup CETAK baru ditutup -- tekan "
                  "BACK sekali dahulu (elak alert lingering tertangkap "
                  "oleh semakan is_home_screen_displayed seterusnya)")
            pages.home.press_back()
            time.sleep(1.0)
        except Exception as e:                                    # noqa: BLE001
            print(f"         [FIX#7] BACK selepas tutup-CETAK: "
                  f"{type(e).__name__}: {e}")

    # Modal dropdown pressable yang TERSEKAT mesti ditutup DAHULU.
    #
    # Android back tidak menutupnya (disahkan pada device: 8 tekanan,
    # modal kekal). Jadi run yang bermula sementara satu modal terbuka
    # tidak akan pernah mencapai skrin utama — ia menekan back berulang
    # kali terhadap modal yang mengabaikannya, lalu menyerah. Itu berlaku
    # dua kali pada 2026-08-10, sekali selepas recon dan sekali selepas
    # run yang terhenti di tengah pemilihan.
    try:
        if pages.daftar_kompaun._baris_modal_kini():
            print("         modal dropdown TERBUKA dari run sebelum ini — "
                  "menutup melalui backdrop")
            pages.daftar_kompaun._tutup_modal_pressable()
            time.sleep(1.0)
    except Exception as e:                                    # noqa: BLE001
        print(f"         semakan modal: {type(e).__name__}: {e}")

    if pages.home.is_home_screen_displayed():
        return True
    try:
        drv.activate_app(APP_PACKAGE)
        time.sleep(2)
    except Exception:                                         # noqa: BLE001
        pass
    if pages.home.is_home_screen_displayed():
        return True
    if pages.login.is_login_screen_displayed(bersihkan=False):
        pages.login.login(TEST_CREDENTIALS["username"],
                          TEST_CREDENTIALS["password"])
        return pages.home.is_home_screen_displayed()
    for _ in range(8):
        if drv.query_app_state(APP_PACKAGE) < 4:
            drv.activate_app(APP_PACKAGE)
            time.sleep(2)
        pages.home.dismiss_native_alerts(context="pastikan-home")
        # Fix #4 (2026-09-13): semak semula dalam gelung juga -- kalau
        # popup CETAK baru muncul (cth. lepas activate_app), 8 tekanan
        # back di bawah tidak akan menutupnya sendiri.
        try:
            pages.cetak.tutup_popup_cetak(timeout=1)
        except Exception:                                          # noqa: BLE001
            pass
        if pages.home.is_home_screen_displayed():
            return True
        if pages.login.is_login_screen_displayed(bersihkan=False):
            pages.login.login(TEST_CREDENTIALS["username"],
                              TEST_CREDENTIALS["password"])
            return pages.home.is_home_screen_displayed()
        pages.home.press_back()
        time.sleep(1.0)
    if pages.home.is_home_screen_displayed():
        return True

    # >>> FIX#14 — DITAMBAH 2026-10-08 (run11: P-003, SK-001). <<<
    # BACK berulang kali TIDAK menutup modal RN yang tersekat. Bukti
    # transkrip: selepas kemaskini borang P gagal (popup 'MEMULAKAN
    # PROSES... 0%' beku), 9 tekanan BACK berturut-turut dicetak tanpa
    # satu pun mengubah skrin, lalu pastikan_di_home() pulang False dan
    # DUA TC berasingan (P-003 hantar, SK-001 senarai) dilaporkan gagal
    # atas sebab yang sama. Ia BUKAN dua kegagalan bebas dan bukan
    # masalah rekod — ia satu modal yang menelan BACK.
    #
    # Relaunch (terminate + activate) ialah laluan pemulihan RASMI yang
    # diluluskan pemilik (devtools/peringkat6.relaunch) dan sudah dipakai
    # di tempat lain. Ia tidak menyentuh pakej dan tidak memadam data —
    # ia cuma menutup modal yang tidak boleh ditutup dengan BACK.
    # Dipanggil HANYA di sini, selepas 8 BACK gagal, jadi laluan normal
    # (yang sentiasa pulang True lebih awal) tidak menanggung kosnya.
    print("         [FIX#14] 8x BACK gagal — modal tersekat; relaunch "
          "app sebagai pemulihan terakhir")
    try:
        from config import APP_PACKAGE as _PKG
        drv.terminate_app(_PKG)
        time.sleep(2)
        drv.activate_app(_PKG)
        time.sleep(5)
    except Exception as e:                                     # noqa: BLE001
        print(f"         [FIX#14] relaunch gagal: {type(e).__name__}: {e}")
        return False
    try:
        pages.home.dismiss_native_alerts(context="pasca-relaunch")
    except Exception:                                          # noqa: BLE001
        pass
    if pages.login.is_login_screen_displayed(bersihkan=False):
        pages.login.login(TEST_CREDENTIALS["username"],
                          TEST_CREDENTIALS["password"])
    ok = pages.home.is_home_screen_displayed()
    print(f"         [FIX#14] relaunch -> skrin utama: "
          f"{'YA' if ok else 'TIDAK'}")
    return ok


def peringkat_5(pages, serial, baseline, drv=None):
    """N-001 fill-only: isi -> baca balik -> BACK OUT tanpa Serah ->
    post-check.

    Butang SERAH tidak pernah disentuh. Kalau sesuatu dalam laluan ini
    cuba menekannya, corong membangkitkan DryRunViolation dan run mati —
    itu jaring, bukan rancangan.
    """
    print("\n== PERINGKAT 5: N-001 fill-only (TANPA Serah) ==")
    from testdata import oracle_n001 as O

    # T-001 memanggil ensure_on_login_screen(), yang berakhir pada skrin
    # LOGIN. Tanpa langkah ini, peringkat 5 mengetuk kad skrin utama pada
    # skrin login dan gagal dengan "element not clickable" — kegagalan
    # yang menuding ke locator sedangkan puncanya navigasi.
    if drv is not None and not lapor("di skrin utama sebelum buka borang",
                                     pastikan_di_home(drv, pages)):
        return False

    p = pages.notis_amaran
    pages.home.open_notis_amaran()
    if not lapor("borang Notis Amaran terbuka",
                 p.is_notis_amaran_screen_displayed()):
        return False

    # --- Pesalah ---
    p.fill_pesalah_tab(O.SEMUA)
    lapor("tab Pesalah diisi", True)

    gagal_readback = []
    for medan in O.READBACK_PESALAH:
        jangka = O.SEMUA[medan]
        try:
            ada = p.cari_dua_arah(
                (p.LABEL_TIER1[0],
                 f'new UiSelector().textContains("{jangka}")'))
        except Exception:                                     # noqa: BLE001
            ada = False
        if not ada:
            gagal_readback.append(f"pesalah.{medan}={jangka!r}")
    lapor(f"read-back Pesalah ({len(O.READBACK_PESALAH)} medan)",
          not gagal_readback, ", ".join(gagal_readback))

    # --- Notis: alamat kesalahan ---
    p.click_seterusnya_from_pesalah()
    p.fill_notis_tab(O.SEMUA)
    lapor("tab Notis (alamat + lokasi + butiran) diisi", True)

    # Baca balik SEKARANG, sebelum dropdown menatal borang.
    #
    # is_text_visible() melihat VIEWPORT SEMASA sahaja. Memilih tiga
    # dropdown menatal borang jauh ke bawah, jadi menyemak Lokasi/Butiran
    # selepas itu melaporkan GAGAL pada medan yang terisi dengan
    # sempurna — dump device mengesahkan 'DEPAN KEDAI' dan 'PARKING
    # KERETA DI TEMPAT OKU' memang ada. Itu artifak kedudukan, bukan
    # dapatan, dan melaporkannya sebagai kegagalan mengaburkan kegagalan
    # yang benar.
    gagal_notis = []
    for medan in O.READBACK_NOTIS:
        jangka = O.SEMUA[medan]
        # is_text_visible() melihat VIEWPORT SEMASA sahaja, jadi medan
        # yang terisi dengan sempurna tetapi berada di luar skrin
        # dilaporkan GAGAL. Diperhati: 'DEPAN KEDAI' gagal sementara
        # 'PARKING KERETA DI TEMPAT OKU' tepat di bawahnya lulus —
        # semata-mata kerana kedudukan. Read-back mesti MENCARI.
        try:
            ada = p.cari_dua_arah(
                (p.LABEL_TIER1[0],
                 f'new UiSelector().textContains("{jangka}")'))
        except Exception:                                     # noqa: BLE001
            ada = False
        if not ada:
            gagal_notis.append(f"notis.{medan}={jangka!r}")
    gagal_readback.extend(gagal_notis)
    lapor(f"read-back Notis ({len(O.READBACK_NOTIS)} medan)",
          not gagal_notis, ", ".join(gagal_notis))

    # --- Notis: TIGA DROPDOWN KOMPAUN ---
    #
    # >>> fill_notis_tab() TIDAK melakukan ini. <<<
    # Ia mengisi alamat, lokasi, butiran dan tempoh, kemudian pulang.
    # Dropdown kod kompaun ialah panggilan BERASINGAN.
    #
    # Larian pertama peringkat ini memanggil fill_notis_tab() sahaja lalu
    # mencetak "tab Notis + dropdown Kompaun diisi". Ledger corong
    # membuktikan sebaliknya: tap terakhir ialah 'Butiran Kesalahan' dan
    # TIADA tap spinner langsung. Itu lulus palsu — tepat kelas kegagalan
    # yang seluruh suite ini wujud untuk menghalang, dalam kod saya
    # sendiri. Dibetulkan dengan memanggilnya secara eksplisit DAN
    # membaca balik ketiga-tiga tingkat.
    # >>> TIADA PRA-SEMAKAN LABEL DI SINI. <<<
    # Dua percubaan pra-semakan gagal, kedua-duanya secara PALSU:
    #   is_element_present  — hanya melihat viewport; read-back baru
    #                         sahaja menatal borang ke atas.
    #   cari_dua_arah       — bergantung pada swipe, dan borang ini
    #                         MENOLAK swipe (anjakan 0px diukur
    #                         berulang kali). Ia kelas TRAVERSAL-FOKUS:
    #                         hanya traversal TAB/DPAD menggerakkannya.
    #
    # pilih_spinner_kod() sudah memanggil _dedah_sebelum_cari(), iaitu
    # mekanisme traversal yang MEMANG menggerakkan borang ini, dan ia
    # gagal dengan diagnosis penuh kalau label benar-benar tiada. Satu
    # pra-semakan yang menggunakan mekanisme yang LEBIH LEMAH daripada
    # yang sebenarnya digunakan hanya boleh menghasilkan negatif palsu.
    p.fill_kompaun_code_fields(O.SEMUA)
    lapor("tiga dropdown Kompaun dipilih", True)

    for nama, jangka in (("kod kompaun", O.SEMUA["keterangan_kod_kompaun"]),
                         ("akta", O.SEMUA["kod_akta"])):
        ada = p.cari_dua_arah(
            (p.LABEL_TIER1[0],
             f'new UiSelector().textContains("{jangka}")'))
        if not ada:
            gagal_readback.append(f"kompaun.{nama}={jangka!r}")
        lapor(f"read-back {nama}", ada)

    # --- BACK OUT. Tiada Serah, tiada Seterusnya ke Penerima. ---
    print("  [N-001] BACK OUT — borang ditinggalkan tanpa diserah")
    for _ in range(8):
        pages.home.dismiss_native_alerts(context="n001: back out")
        if pages.home.is_home_screen_displayed():
            break
        pages.home.press_back()
        time.sleep(1.0)
    keluar = pages.home.is_home_screen_displayed()
    lapor("kembali ke skrin utama", keluar)

    # --- POST-CHECK ---
    db = tarik_db(serial, os.path.join(AKAR, "data", "tmp", "pasca_n001.db"))
    kira, siri = keadaan_rekod(db)
    kira0, siri0 = baseline
    tiada_rekod = (kira == kira0)
    siri_sama = (siri == siri0)
    lapor(f"post-check kiraan rekod {kira} (baseline {kira0})", tiada_rekod)
    lapor(f"post-check kaunter siri {siri}", siri_sama,
          "" if siri_sama else f"baseline {siri0} — kaunter BERGERAK, "
                               f"bermakna rekod pernah dijana")
    if not (tiada_rekod and siri_sama):
        print("\nHENTI: post-check GAGAL — rekod mungkin tercipta. "
              "JANGAN sentuh apa-apa lagi pada peranti.")
        return False
    return not gagal_readback and keluar


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sampai", type=int, default=2)
    ap.add_argument("--serial", default=None)
    ap.add_argument("--langkau-selaras", action="store_true",
                    help="Jangan jalankan T-003/4/5. Guna snapshot dari "
                         "sync yang BERJAYA. T-004 tidak idempotent pada "
                         "2.1.21 (defek app) — mengulanginya mencampak app "
                         "keluar, jadi jangan ulang tanpa sebab.")
    ap.add_argument("--langkau-pk", action="store_true",
                    help="Langkau P-001/K-001/DIAG. Borang itu tersekat pada "
                         "gerbang tab PESALAH (D-03) dan setiap percubaan "
                         "meninggalkan alert penolakan yang merosakkan TC "
                         "seterusnya.")
    ap.add_argument("--p6-hanya", default=None,
                    choices=["k001", "pra-sweep"],
                    help="Jalankan SATU langkah peringkat 6 sahaja.")
    ap.add_argument("--p6-mula", default="tetapan",
                    choices=["tetapan", "selaras", "kamera", "bookmark"],
                    help="Mula peringkat 6 dari bahagian ini. Untuk "
                         "menyambung selepas pembetulan tanpa mengulang "
                         "TC yang sudah LULUS (T-002 menulis ke "
                         "production setiap kali ia berjalan).")
    ap.add_argument("--langkau-n001", action="store_true",
                    help="Jangan ulang peringkat 5. N-001 sudah LULUS "
                         "PENUH; mengulanginya hanya menambah masa borang "
                         "tanpa menambah bukti.")
    a = ap.parse_args()

    from device_utils import resolve_udid
    from config import APP_PACKAGE
    serial = a.serial or resolve_udid(APP_PACKAGE, verbose=False)
    tarikh = time.strftime("%Y%m%d")

    p1 = peringkat_1(serial)
    if not p1["ok"]:
        print("\nHENTI: peringkat 1 gagal.")
        return 1
    if not p1["versi_padan"]:
        print("\n  AMARAN DITERUSKAN: build device != oracle. Setiap "
              "keputusan selepas ini mesti dibaca dengan itu dalam ingatan.")
    if a.sampai < 2:
        return 0

    drv = pages = None
    try:
        drv, pages = peringkat_2()

        # T-001 mesti berjalan SEBELUM peringkat 3: ia yang mengisi medan
        # Internal, dan tanpa itu gerbang run akan datang masih melihat
        # medan kosong.
        if a.sampai >= 3:
            if not peringkat_t001(pages, serial):
                print("\nHENTI: T-001 gagal.")
                return 1
            # post-verify relaunch DIBUANG bersama tulisan config: tiada
            # apa untuk disahkan bertahan, dan kitaran terminate/activate
            # itulah yang kelihatan seperti bertukar app pada rakaman.

        if a.sampai >= 3 and not a.langkau_selaras:
            hasil = peringkat_3(pages)
            if not all(hasil.values()):
                print("\nHENTI: peringkat 3 gagal.")
                return 1
        elif a.sampai >= 3:
            print("\n== PERINGKAT 3 DILANGKAU (--langkau-selaras) ==")
            print("  Selaras sudah dijalankan; snapshot dari sync BERJAYA "
                  "digunakan.")
            print("  T-004 tidak idempotent pada 2.1.21 — mengulanginya "
                  "mencampak app keluar. Lihat docs/DEFEK-MBPG-2.1.21.md")
        if a.sampai >= 4:
            if not peringkat_4(serial, tarikh):
                print("\nTUNGGU: sauh oracle tidak lengkap — keputusan "
                      "pemilik diperlukan.")
                return 2
        if a.sampai >= 5 and not a.langkau_n001:
            if not peringkat_5(pages, serial, p1["baseline"], drv):
                print("\nHENTI: peringkat 5 gagal.")
                return 1
        elif a.sampai >= 5:
            print("\n== PERINGKAT 5 DILANGKAU (--langkau-n001) ==")
            print("  N-001 sudah LULUS PENUH pada run terdahulu.")
        if a.sampai >= 6:
            from devtools import peringkat6
            if not peringkat6.jalan(drv, pages, serial, p1["baseline"],
                                    langkau_pk=a.langkau_pk,
                                    mula=a.p6_mula,
                                    hanya=a.p6_hanya):
                print("\nHENTI: peringkat 6 dibatalkan (post-check).")
                return 1
        print("\nSAMBUNG: peringkat yang diminta selesai.")
        return 0
    finally:
        if drv is not None:
            c = getattr(drv, "corong", None)
            if c is not None:
                print(f"\n  [CORONG] {c.bil_tap} tap dinilai, "
                      f"{c.bil_sekat} disekat"
                      + (f" | DIBATALKAN: {c.dibatalkan}"
                         if c.dibatalkan else ""))
            try:
                drv.quit()
            except Exception:                                # noqa: BLE001
                pass


if __name__ == "__main__":
    sys.exit(main())

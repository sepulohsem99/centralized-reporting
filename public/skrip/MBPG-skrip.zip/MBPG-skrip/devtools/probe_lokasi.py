"""
PROBE — satu medan, setiap langkah dilog.

Soalan: `fill_field_by_label('LOKASI KESALAHAN', ...)` pulang tanpa
ralat, tetapi medan kekal KOSONG pada baca-balik. Di mana ia hilang?

Baca-balik dalam `fill_field_by_label` pulang `None`, dan kod menganggap
"type landed and move on" (base_page.py:2078-2089). Anggapan itu masuk
akal untuk medan autocomplete yang re-render — tetapi di sini ia
menyembunyikan kegagalan sebenar.

Probe ini tidak membetulkan apa-apa. Ia merakam, langkah demi langkah:

    1. bounds medan SEBELUM gulung
    2. adakah gulung_borang_ke_atas() BENAR-BENAR menggerakkan skrin
    3. bounds medan SELEPAS gulung
    4. apa yang berlaku pada click / clear / type
    5. teks medan SERTA-MERTA selepas type
    6. teks medan selepas gulung semula

BACA SAHAJA — tiada SERAH, tiada SETERUSNYA, keluar melalui back.

    python devtools/probe_lokasi.py
"""

import os
import sys
import time
import xml.etree.ElementTree as ET

HERE = os.path.dirname(os.path.abspath(__file__))
AKAR = os.path.dirname(HERE)
sys.path.insert(0, AKAR)


def tulis(s):
    try:
        sys.stdout.write(s + "\n")
    except UnicodeEncodeError:
        sys.stdout.buffer.write((s + "\n").encode("ascii", "backslashreplace"))
    sys.stdout.flush()


def medan_edittext(drv):
    """{bounds: teks} bagi setiap EditText — cukup untuk melihat
    pergerakan skrin DAN kandungan medan dalam satu bacaan."""
    try:
        akar = ET.fromstring(drv.page_source)
    except Exception:                                           # noqa: BLE001
        return {}
    keluar = {}
    for n in akar.iter():
        if (n.get("class") or "") == "android.widget.EditText":
            keluar[n.get("bounds")] = (n.get("text") or "").strip()
    return keluar


def cari(peta, label):
    for b, t in peta.items():
        if t.strip().lower() == label.strip().lower():
            return b, t
    return None, None


def main():
    from devtools import peringkat6 as P6
    from devtools.smoke_tangga import peringkat_1, peringkat_2, \
        pastikan_di_home
    from device_utils import resolve_udid
    from config import APP_PACKAGE
    from testdata import oracle_pk

    LABEL = "Lokasi Kesalahan"
    NILAI = "PROBE LOKASI 12345"

    tulis("=" * 70)
    tulis("== PROBE — satu medan: " + LABEL)
    tulis("== BACA SAHAJA. Tiada serah.")
    tulis("=" * 70)

    serial = resolve_udid(APP_PACKAGE, verbose=False)
    p1 = peringkat_1(serial)
    if not p1["ok"]:
        return 1
    P6.baseline_global = p1["baseline"]

    drv = pages = None
    try:
        drv, pages = peringkat_2()
        P6.relaunch(drv, pages, "probe lokasi: borang bersih")
        if not pastikan_di_home(drv, pages):
            tulis("HENTI: tidak sampai skrin utama")
            return 1

        data = dict(oracle_pk.P001)
        p = pages.daftar_kompaun
        P6._pakai_sauh_alamat(serial, data, oracle_pk.K001)
        pages.home.open_daftar_kompaun()
        p.select_jenis_kompaun("Kompaun Pelbagai")
        p.fill_pesalah_tab(data)
        p.click_seterusnya_from_pesalah()
        time.sleep(2.5)

        tulis("\n--- 1. keadaan awal tab Kompaun ---")
        peta = medan_edittext(drv)
        b, t = cari(peta, LABEL)
        tulis(f"    {LABEL} bounds={b} teks={t!r}")
        tulis(f"    jumlah EditText={len(peta)}")
        awal = dict(peta)

        tulis("\n--- 2. isi medan alamat (yang menggerakkan borang) ---")
        try:
            p._isi_jalan_kompaun(data) if hasattr(p, "_isi_jalan_kompaun") \
                else None
        except Exception as e:                                  # noqa: BLE001
            tulis(f"    (dilangkau: {type(e).__name__})")
        # Guna laluan sebenar supaya keadaan sama seperti larian penuh.
        peta = medan_edittext(drv)
        b2, t2 = cari(peta, LABEL)
        tulis(f"    {LABEL} bounds={b2} teks={t2!r}")
        tulis(f"    skrin bergerak? {'YA' if peta != awal else 'TIDAK'}")

        tulis("\n--- 3. gulung_borang_ke_atas() ---")
        sebelum = medan_edittext(drv)
        hasil = p.gulung_borang_ke_atas()
        time.sleep(1)
        selepas = medan_edittext(drv)
        tulis(f"    pulangan={hasil}")
        tulis(f"    skrin BERGERAK? "
              f"{'YA' if set(sebelum) != set(selepas) else 'TIDAK'}")
        b3, t3 = cari(selepas, LABEL)
        tulis(f"    {LABEL} bounds={b3} teks={t3!r}")

        if b3 is None:
            tulis("    *** medan TIDAK dijumpai selepas gulung ***")

        tulis("\n--- 4. LANGKAH DEMI LANGKAH (bukan fill_field_by_label) ---")

        def lapor(tag):
            m = medan_edittext(drv)
            bb, _tt = cari(m, LABEL)
            tulis(f"    [{tag}] EditText={len(m)}  {LABEL}="
                  f"{'HILANG' if bb is None else bb}")
            if len(m) <= 3:
                for k, v in m.items():
                    tulis(f"          {k:<26} {v[:36]!r}")
            return m

        lapor("sebelum-find")
        lok = p._ci_label_locator(p.LABEL_LOKASI_KESALAHAN)
        try:
            el = p.find_element(lok, timeout=10)
            tulis("    find_element OK")
        except Exception as e:                                  # noqa: BLE001
            tulis(f"    find_element MELONTAR {type(e).__name__}")
            el = None
        lapor("selepas-find")

        if el is not None:
            try:
                el.click()
                tulis("    el.click() OK")
            except Exception as e:                              # noqa: BLE001
                tulis(f"    el.click() MELONTAR {type(e).__name__}")
            time.sleep(1)
            lapor("selepas-click")
            try:
                tulis(f"    papan kekunci selepas click? "
                      f"{drv.is_keyboard_shown()}")
            except Exception:                                   # noqa: BLE001
                pass

            try:
                el.clear()
                tulis("    el.clear() OK")
            except Exception as e:                              # noqa: BLE001
                tulis(f"    el.clear() MELONTAR {type(e).__name__}")
            lapor("selepas-clear")

            try:
                el.send_keys(NILAI)
                tulis("    el.send_keys() OK")
            except Exception as e:                              # noqa: BLE001
                tulis(f"    el.send_keys() MELONTAR {type(e).__name__}")
            time.sleep(1)
            lapor("selepas-send_keys")

        # >>> UJIAN MENENTUKAN: adakah gulung MEMUSNAHKAN nilai? <<<
        # base_page.py:3006 mendakwa "scrolling the page destroys form
        # progress". Saya mengukurnya pada borang KOSONG dan menyimpulkan
        # dakwaan itu tidak disokong — ukuran yang tidak boleh menguji
        # perkara yang didakwa. Ini mengukurnya pada medan BERISI.
        tulis("\n--- 4b. UJIAN: gulung selepas medan BERISI ---")
        peta_b = medan_edittext(drv)
        ada_sebelum = [(b, t) for b, t in peta_b.items() if NILAI[:12] in t]
        tulis(f"    sebelum gulung: {ada_sebelum if ada_sebelum else 'TIADA'}")
        p.gulung_borang_ke_atas()
        time.sleep(1)
        peta_c = medan_edittext(drv)
        ada_selepas = [(b, t) for b, t in peta_c.items() if NILAI[:12] in t]
        tulis(f"    selepas gulung: {ada_selepas if ada_selepas else 'TIADA'}")
        if ada_sebelum and not ada_selepas:
            tulis("    >>> DISAHKAN: gulung MEMUSNAHKAN nilai medan <<<")
        elif ada_sebelum and ada_selepas:
            tulis("    >>> gulung SELAMAT pada medan berisi <<<")
        else:
            tulis("    >>> tidak dapat diuji: nilai tiada sebelum gulung <<<")

        tulis("\n--- 5. keadaan SERTA-MERTA selepas type ---")
        peta5 = medan_edittext(drv)
        jumpa = [(b, t) for b, t in peta5.items() if NILAI[:12] in t]
        tulis(f"    medan memegang {NILAI[:12]!r}: "
              f"{jumpa if jumpa else 'TIADA'}")
        b5, t5 = cari(peta5, LABEL)
        tulis(f"    {LABEL} placeholder masih ada? "
              f"{'YA (medan KOSONG)' if b5 else 'tidak'}")
        tulis("    SEMUA EditText SERTA-MERTA selepas type:")
        for bb, tt in peta5.items():
            tanda = "  <-- SASARAN" if bb == "[107,1452][977,1602]" else ""
            tulis(f"      {bb:<26} {tt[:44]!r}{tanda}")
        try:
            tulis(f"    papan kekunci terbuka? {drv.is_keyboard_shown()}")
        except Exception as e:                                  # noqa: BLE001
            tulis(f"    papan kekunci tidak dapat dibaca ({type(e).__name__})")
        try:
            _akar = ET.fromstring(drv.page_source)
            _fok = [(n.get("class"), n.get("bounds"), n.get("text"))
                    for n in _akar.iter()
                    if (n.get("focused") or "") == "true"]
            tulis(f"    elemen BERFOKUS: {_fok}")
        except Exception as e:                                  # noqa: BLE001
            tulis(f"    fokus tidak dapat dibaca ({type(e).__name__})")

        tulis("\n--- 6. gulung ke atas dan baca semula ---")
        p.gulung_borang_ke_atas()
        time.sleep(1)
        peta6 = medan_edittext(drv)
        jumpa6 = [(b, t) for b, t in peta6.items() if NILAI[:12] in t]
        tulis(f"    medan memegang nilai: {jumpa6 if jumpa6 else 'TIADA'}")
        tulis("\n    SEMUA EditText sekarang:")
        for b, t in peta6.items():
            tulis(f"      {b:<26} {t[:44]!r}")

        tulis("\n" + "=" * 70)
        for _ in range(5):
            try:
                drv.back()
                time.sleep(1)
            except Exception:                                   # noqa: BLE001
                break
        P6.post_check(serial, p1["baseline"], "probe-lokasi")
        return 0
    finally:
        if drv is not None:
            c = getattr(drv, "corong", None)
            if c is not None:
                tulis(f"\n  [CORONG] {c.bil_tap} tap dinilai, "
                      f"{c.bil_sekat} disekat")
            try:
                drv.quit()
            except Exception:                                   # noqa: BLE001
                pass


if __name__ == "__main__":
    sys.exit(main())

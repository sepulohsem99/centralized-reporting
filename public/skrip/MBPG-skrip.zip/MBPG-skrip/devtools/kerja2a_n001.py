"""
KERJA 2A — N-001 Notis Amaran: SATU rekod production SEBENAR.

Urutan:
    0. printer disahkan sedia SEBELUM serah — tiada guna mencipta rekod
       yang tidak boleh dicetak
    1. borang diisi penuh dengan data oracle SINTETIK
    2. jaring PII terakhir sebelum serah
    3. SERAH  -> rekod dicipta
    4. post-check 15 jadual: TEPAT +1
    5. nombor rekod + siri dibaca dari DB
    6. Senarai dibongkar DENGAN rekod hadir — inilah recon yang
       laluan CETAK akan diport daripadanya

BERHENTI selepas satu rekod. Kuota borang N ialah 1; gerbang menyekat
yang kedua walaupun kod cuba.

    python devtools/kerja2a_n001.py
"""

import os
import sys
import time
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
AKAR = os.path.dirname(HERE)
sys.path.insert(0, AKAR)

from devtools import peringkat6 as P6                          # noqa: E402
from devtools import fasa_c as FC                              # noqa: E402
from guard.gerbang_serah import (Izin, SerahTidakDiizinkan,    # noqa: E402
                                 diagnosis, semak)

TAG = "N-001"
SET_ID = "C1-N-001"
BORANG = "N"
JADUAL = "local_ekpn_notis_amaran"
DIR_BUKTI = os.path.join(AKAR, "docs", "demo-fasa-c", "kerja2a")
DOK = os.path.join(AKAR, "docs", "FASA-C-REKOD.md")


def bukti(drv, tag):
    os.makedirs(DIR_BUKTI, exist_ok=True)
    asas = os.path.join(DIR_BUKTI, tag)
    try:
        drv.get_screenshot_as_file(asas + ".png")
    except Exception:                                           # noqa: BLE001
        pass
    try:
        with open(asas + ".xml", "w", encoding="utf-8") as fh:
            fh.write(drv.page_source)
    except Exception:                                           # noqa: BLE001
        pass
    print(f"    [BUKTI] {tag}")


def tulis_dok(entri):
    baharu = not os.path.exists(DOK)
    os.makedirs(os.path.dirname(DOK), exist_ok=True)
    with open(DOK, "a", encoding="utf-8") as fh:
        if baharu:
            fh.write("# FASA C — rekod production sebenar yang dicipta\n\n"
                     "> Setiap nombor di bawah ialah rekod HIDUP pada "
                     "production MBPG.\n"
                     "> Pembatalan melalui portal ePBT oleh pihak "
                     "berautoriti.\n\n"
                     "| Jenis | No. rekod | No. siri | Masa | Pesalah "
                     "(data ujian) | Cetak |\n"
                     "|---|---|---|---|---|---|\n")
        fh.write("| {jenis} | `{no_rekod}` | {no_siri} | {masa} "
                 "| {pesalah} | {cetak} |\n".format(**entri))
        fh.flush()
        os.fsync(fh.fileno())
    print(f"    [DOK] {entri['no_rekod']} ditulis ke docs/FASA-C-REKOD.md")


def jaring_pii(drv):
    """Jaring terakhir: skrin pra-serah tidak boleh membawa PII sebenar."""
    from devtools.imbas_pii import imbas_teks
    teks = " | ".join(FC._teks_skrin(drv))
    return [j for j in imbas_teks(teks)
            if j[0] in ("nama_bin_binti", "no_kp_bersengkang")]


def main():
    from devtools.smoke_tangga import (peringkat_1, peringkat_2,
                                       pastikan_di_home, tarik_db)
    from device_utils import resolve_udid
    from config import APP_PACKAGE, RECORD_PREFIX
    from testdata import oracle_n001 as O
    from pages.cetak_page import CetakPage, PrinterTidakSedia

    print("=" * 70)
    print(f"== KERJA 2A — {TAG}: SATU rekod production SEBENAR")
    print(f"== prefix {RECORD_PREFIX} | pemilik di depan device")
    print("=" * 70)

    izin = Izin.dari_persekitaran(AKAR)
    d = diagnosis(izin)
    for k, v in d.items():
        print(f"  {k:<26} = {v}")
    if not d["serah_mungkin"]:
        print("\nHENTI: serah_mungkin=False.")
        return 1
    # >>> Kuota dikira dari LEDGER, bukan dari 0 yang dikodkan keras. <<<
    # Lalai 0 bermakna menjalankan semula pemandu ini selepas rekod
    # pertama berjaya akan mencipta rekod KEDUA, walaupun kuota berkata
    # satu. Selepas PGP02N260813006 dicipta, itu tepat apa yang akan
    # berlaku. Ledger append-only ialah satu-satunya kiraan yang
    # bertahan merentas proses.
    sudah = FC.kiraan_borang_dari_ledger(BORANG)
    print(f"  rekod borang {BORANG} sudah dicipta (dari ledger): {sudah}")
    semak(izin, SET_ID, sudah, borang=BORANG, kiraan_borang=sudah)
    print(f"  gerbang: LULUS untuk rekod borang {BORANG} seterusnya\n")

    serial = resolve_udid(APP_PACKAGE, verbose=False)
    p1 = peringkat_1(serial)
    if not p1["ok"]:
        return 1
    P6.baseline_global = p1["baseline"]

    drv = pages = None
    try:
        drv, pages = peringkat_2()
        P6.relaunch(drv, pages, f"{TAG}: borang bersih")
        if not pastikan_di_home(drv, pages):
            print("HENTI: tidak sampai skrin utama")
            return 1

        # --- 0. printer DAHULU ---
        print(f"\n{'-' * 68}\n-- 0. PRINTER\n{'-' * 68}")
        cetak = CetakPage(drv)
        lap = cetak.sahkan_printer_sedia(wajib=True)
        bukti(drv, "00-printer-sedia")

        # --- 1. isi borang ---
        print(f"\n{'-' * 68}\n-- 1. ISI BORANG (data oracle sintetik)\n"
              f"{'-' * 68}")
        print(f"  pesalah = {O.SEMUA['nama_pesalah']!r} / "
              f"{O.SEMUA['no_kp_ssm_kereta']!r}")
        p = pages.notis_amaran
        pages.home.open_notis_amaran()
        p.fill_pesalah_tab(O.SEMUA)
        p.click_seterusnya_from_pesalah()
        p.fill_notis_tab(O.SEMUA)
        p.fill_kompaun_code_fields(O.SEMUA)
        p.take_photos(count=3)
        p.click_seterusnya_from_notis()
        p.fill_penerima_tab(O.SEMUA)
        bukti(drv, "01-pra-serah")

        # --- 2. jaring PII ---
        jumpa = jaring_pii(drv)
        if jumpa:
            bukti(drv, "ABORT-PII")
            raise SerahTidakDiizinkan(
                f"Skrin pra-serah membawa sesuatu berbentuk PII sebenar "
                f"({[j[0] for j in jumpa]}). Rekod DIBATALKAN.")
        print("  jaring PII: bersih (data oracle sahaja)")

        # --- 3-5. SERAH ---
        print(f"\n{'-' * 68}\n-- 3. SERAH — rekod SEBENAR akan dicipta\n"
              f"{'-' * 68}")
        db1 = tarik_db(serial, os.path.join(AKAR, "data", "tmp",
                                            "pra_n001.db"))
        sebelum = FC.kira_rekod(db1)
        hasil = FC.serah_dan_tangkap(drv, pages, p, SET_ID, JADUAL,
                                     serial, sebelum)
        bukti(drv, "02-selepas-serah")

        no_rekod = hasil["no_rekod"]
        tulis_dok({
            "jenis": TAG, "no_rekod": no_rekod,
            "no_siri": hasil["no_siri"],
            "masa": time.strftime("%Y-%m-%d %H:%M:%S"),
            # Nama sahaja, bukan IC. Dokumen ini DIJEJAKI git, dan
            # menulis nombor 12 digit ke dalamnya mencetuskan pengimbas
            # PII -- selepas rekod sudah wujud, iaitu masa paling teruk
            # untuk terhalang. Nilai penuh ada dalam testdata/
            # oracle_n001.py, yang sudah dijejaki.
            "pesalah": f"{O.SEMUA['nama_pesalah']} (oracle N-001)",
            "cetak": "belum",
        })

        # --- 6. recon Senarai DENGAN rekod hadir ---
        print(f"\n{'-' * 68}\n-- 6. RECON SENARAI (rekod hadir) — untuk "
              f"port laluan CETAK\n{'-' * 68}")
        try:
            P6._keluar_ke_home(pages, TAG)
            pages.home.open_senarai()
            time.sleep(2)
            bukti(drv, "03-senarai-sebelum-semak")
            jumpa_rekod, teks = cetak.cari_rekod(no_rekod)
            bukti(drv, "04-senarai-dengan-rekod")
            print(f"  rekod dalam senarai: {jumpa_rekod}")
            print("  teks skrin Senarai:")
            for t in teks[:45]:
                print(f"    | {t[:70]}")
        except Exception as e:                                  # noqa: BLE001
            print(f"  recon Senarai gagal: {type(e).__name__}: {e}")
            bukti(drv, "04-senarai-GAGAL")

        print("\n" + "=" * 70)
        print("== KERJA 2A — REKOD DICIPTA")
        print("=" * 70)
        print(f"  No. rekod : {no_rekod}")
        print(f"  No. siri  : {hasil['no_siri']}")
        print(f"  Dialog    : {hasil['dialog']}")
        print(f"  Kejayaan  : {hasil['kejayaan']}")
        print(f"  Printer   : {lap['nama']} (tersambung={lap['tersambung']})")
        print(f"\n  CETAK BELUM DIBUAT — laluan CETAK diport dari dump di "
              f"atas.")
        return 0
    except BaseException as e:                                  # noqa: BLE001
        print(f"\n{'!' * 70}\n!! BERHENTI — {type(e).__name__}\n{'!' * 70}")
        print(str(e)[:2500])
        if not isinstance(e, (SerahTidakDiizinkan, PrinterTidakSedia)):
            traceback.print_exc()
        if drv is not None:
            bukti(drv, "ABORT")
        return 1
    finally:
        if drv is not None:
            c = getattr(drv, "corong", None)
            if c is not None:
                print(f"\n  [CORONG] {c.bil_tap} tap dinilai, "
                      f"{c.bil_sekat} disekat")
            try:
                drv.quit()
            except Exception:                                   # noqa: BLE001
                pass


if __name__ == "__main__":
    sys.exit(main())

"""
FASA C — E2E K (Letak Kereta). DUA FASA, satu rekod.

>>> KENAPA DUA FASA. <<<
Arahan pemilik menuntut dua perkara yang tidak boleh benar serentak
dalam satu borang:

    3(a) "identiti atas rekod K mesti identiti oracle"
    3(b) "tap butang MySIKAP -> verify auto-populate -> read-back"

MySIKAP mengisi nama, IC, DAN blok alamat penuh orang SEBENAR
(docs/recon/DAPATAN-MYSIKAP.md). Kalau lookup dibiarkan berdiri pada
borang yang diserah, rekod itu membawa PII orang sebenar dan melanggar
3(a) — dan jaring PII 3(c) akan membatalkannya, betul-betul seperti
direka.

Menimpa medan identiti selepas lookup TIDAK memadai: lookup turut
mengisi jalan / taman / poskod / bandar / negeri, jadi satu medan
terlepas bermakna alamat rumah orang sebenar kekal pada notis
penguatkuasaan production. Itu bukan risiko yang berbaloi untuk
menjimatkan satu relaunch.

Jadi:

    FASA 1  borang BUANGAN. Taip plat, tap MySIKAP, sahkan auto-isi,
            baca-balik, rakam bukti. Borang ini TIDAK PERNAH diserah.
    FASA 2  relaunch bersih. Isi PENUH dari oracle K-001 (bukan
            isi_pesalah_minimum). Jaring PII. Serah. Cetak.

MySIKAP terbukti, rekod membawa identiti oracle sahaja, dan tiada PII
orang sebenar pernah menghampiri rekod yang diserah.

ePBT TIDAK DITEKAN dalam mana-mana fasa. Ia memadam data dan ia BUKAN
MySIKAP.

    python devtools/fasa_c_e2e_k.py
"""

import os
import sys
import time
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
AKAR = os.path.dirname(HERE)
sys.path.insert(0, AKAR)

from devtools import peringkat6 as P6                          # noqa: E402
from devtools import fasa_c as FC                              # noqa: E402
from devtools.fasa_c_e2e import bukti, jaring_pii, tulis_dok   # noqa: E402
from guard.gerbang_serah import (Izin, SerahTidakDiizinkan,    # noqa: E402
                                 diagnosis, semak)

TAG = "K-001"
SET_ID = "C3-K-001"
BORANG = "K"
JADUAL = "local_ekpn_tawaran_kompaun"


# Isian tab Pesalah borang K kini hidup dalam page object:
#     DaftarKompaunPage.fill_pesalah_tab_letak_kereta()
# Salinan tempatan dibuang supaya urutan D-05 (No. Kereta
# DAHULU) wujud di SATU tempat sahaja. Dua salinan bermakna
# pembetulan boleh diterap pada satu dan terlepas pada satu
# lagi -- dan yang terlepas itu mencipta rekod production
# dengan nombor plat dalam medan nama.


def fasa1_mysikap(drv, pages, data):
    """Buktikan MySIKAP pada borang BUANGAN. Tiada serah."""
    print(f"\n{'=' * 68}\n== FASA 1 — MySIKAP (borang buangan, TIDAK "
          f"diserah)\n{'=' * 68}")
    p = pages.daftar_kompaun
    pages.home.open_daftar_kompaun()
    p.select_jenis_kompaun_letak_kereta()

    plat = data["no_kereta"]
    print(f"  menaip No. Kereta = {plat!r}")
    if not P6._isi_medan_tepat(p, "No. Kereta", plat):
        return {"ok": False, "nota": "medan No. Kereta tidak dijumpai"}
    try:
        drv.hide_keyboard()
        time.sleep(0.5)
        p.wait_and_tap(p.TAB_PESALAH)
        time.sleep(1.5)
    except Exception:                                           # noqa: BLE001
        pass

    ms = P6._cari_mysikap(p)
    if ms is None:
        bukti(drv, f"{TAG}-F1-mysikap-tidak-pasti")
        return {"ok": False,
                "nota": "butang MySIKAP tidak dapat disahkan secara "
                        "struktur; TIADA tekaan (tekaan salah = ePBT)"}
    print(f"  MySIKAP disahkan @ {ms} — ePBT TIDAK disentuh")

    sebelum = P6._snapshot_medan(p)
    P6._catat_ledger(drv, "mysikap-tap-fasa1", f"{TAG}: {plat} @ {ms}")
    drv.execute_script("mobile: clickGesture", {"x": ms[0], "y": ms[1]})
    tamat = time.time() + 45
    while time.time() < tamat:
        time.sleep(3)
        if P6._beza_medan(sebelum, P6._snapshot_medan(p)):
            break
    beza = P6._beza_medan(sebelum, P6._snapshot_medan(p))
    bukti(drv, f"{TAG}-F1-selepas-mysikap")

    # Nilai DIREDACT: ini hasil lookup orang sebenar.
    diredact = P6._redact_pii(beza) if beza else []
    print(f"  auto-isi (DIREDACT): {diredact}")
    return {"ok": bool(beza), "medan_berubah": len(beza or []),
            "auto_isi": diredact, "koordinat": list(ms),
            "nota": "auto-isi disahkan" if beza else "TIADA kesan"}


def fasa2_rekod(drv, pages, data, serial):
    """Borang BERSIH, isi PENUH dari oracle, serah, cetak."""
    from devtools.smoke_tangga import pastikan_di_home, tarik_db
    from pages.cetak_page import CetakPage
    from guard.dasar import PermitSerah

    print(f"\n{'=' * 68}\n== FASA 2 — rekod sebenar, identiti ORACLE\n"
          f"{'=' * 68}")
    P6.relaunch(drv, pages, f"{TAG}: borang BERSIH selepas fasa 1")
    if not pastikan_di_home(drv, pages):
        raise RuntimeError("tidak sampai skrin utama selepas relaunch")

    cetak = CetakPage(drv)
    lap = cetak.sahkan_printer_sedia(wajib=True)

    p = pages.daftar_kompaun
    pages.home.open_daftar_kompaun()
    p.select_jenis_kompaun_letak_kereta()

    # >>> Isi PENUH dari oracle. TIADA sedia_borang_kompaun(), TIADA
    # >>> isi_pesalah_minimum(). Rekod P membawa 'AUTOTEST SWEEP'
    # >>> kerana laluan itu; K tidak boleh mengulanginya.
    print(f"  pesalah (oracle) = {data['nama_pesalah']!r}")
    p.fill_pesalah_tab_letak_kereta(data)
    p.click_seterusnya_from_pesalah()
    p.fill_kompaun_tab(data)
    p.fill_kompaun_code_fields(data)
    p.take_photos(count=3)
    p.click_seterusnya_from_kompaun()
    p.fill_penerima_tab(data)
    bukti(drv, f"{TAG}-F2-01-pra-serah")

    jumpa = jaring_pii(drv, data)
    if jumpa:
        bukti(drv, f"{TAG}-F2-ABORT-PII")
        raise SerahTidakDiizinkan(
            f"Skrin pra-serah membawa PII yang KITA TIDAK taip: "
            f"{[j[0] for j in jumpa]}. Sisa lookup fasa 1 mungkin "
            f"terselamat daripada relaunch. Rekod DIBATALKAN.")
    print("  jaring PII: bersih (hanya nilai oracle kita sendiri)")

    db1 = tarik_db(serial, os.path.join(AKAR, "data", "tmp",
                                        f"pra_{TAG}.db"))
    sebelum = FC.kira_rekod(db1)
    hasil = FC.serah_dan_tangkap(drv, pages, p, SET_ID, JADUAL, serial,
                                 sebelum)
    bukti(drv, f"{TAG}-F2-02-selepas-serah")
    no_rekod = hasil["no_rekod"]

    tulis_dok(f"| {TAG} | `{no_rekod}` | {hasil['no_siri']} | "
              f"{time.strftime('%Y-%m-%d %H:%M')} | "
              f"{data['nama_pesalah']} (oracle K001) | "
              f"dihantar ke printer |")

    print(f"\n{'-' * 68}\n-- CETAK (satu tekan, tiada ulangan)\n{'-' * 68}")
    tetapan = drv.corong.tetapan
    tetapan.permit_serah = PermitSerah(SET_ID, had=1)
    try:
        hc = cetak.cetak_dari_popup(no_rekod)
    finally:
        tetapan.permit_serah = None
        print("  [CETAK] permit DITANGGALKAN")
    bukti(drv, f"{TAG}-F2-03-selepas-cetak")

    FC.catat_ledger({"peristiwa": "cetak-dicuba", "set_id": SET_ID,
                     "no_rekod": no_rekod, "percubaan": 1,
                     "popup_tutup": hc["popup_tutup"],
                     "printer": lap.get("nama")})
    return hasil, hc, lap


def main():
    from devtools.smoke_tangga import peringkat_1, peringkat_2, \
        pastikan_di_home
    from device_utils import resolve_udid
    from config import APP_PACKAGE, RECORD_PREFIX
    from testdata import oracle_pk as OPK
    from pages.cetak_page import PrinterTidakSedia

    data = OPK.K001
    print("=" * 70)
    print(f"== FASA C E2E — {TAG} (Letak Kereta), DUA FASA")
    print(f"== prefix {RECORD_PREFIX} | ePBT TIDAK DITEKAN")
    print("=" * 70)

    izin = Izin.dari_persekitaran(AKAR)
    d = diagnosis(izin)
    print(f"  serah_mungkin = {d['serah_mungkin']}  ({d['lapisan_5_sebab']})")
    if not d["serah_mungkin"]:
        print("HENTI: gerbang tertutup / izin luput.")
        return 1
    sudah = FC.kiraan_borang_dari_ledger(BORANG)
    print(f"  rekod borang {BORANG} dari ledger: {sudah}")
    semak(izin, SET_ID, sudah, borang=BORANG, kiraan_borang=sudah)
    print("  gerbang: LULUS\n")

    serial = resolve_udid(APP_PACKAGE, verbose=False)
    p1 = peringkat_1(serial)
    if not p1["ok"]:
        return 1
    P6.baseline_global = p1["baseline"]

    drv = None
    try:
        drv, pages = peringkat_2()
        P6.relaunch(drv, pages, f"{TAG}: fasa 1")
        if not pastikan_di_home(drv, pages):
            print("HENTI: tidak sampai skrin utama")
            return 1

        f1 = fasa1_mysikap(drv, pages, data)
        FC.catat_ledger({"peristiwa": "mysikap-disahkan", "set_id": SET_ID,
                         **{k: v for k, v in f1.items()
                            if k != "auto_isi"},
                         "auto_isi_redact": f1.get("auto_isi")})
        print(f"\n  FASA 1: {'LULUS' if f1['ok'] else 'GAGAL'} — "
              f"{f1['nota']}")
        if not f1["ok"]:
            print("  MySIKAP tidak terbukti. Rekod K TIDAK diserah.")
            return 1

        hasil, hc, lap = fasa2_rekod(drv, pages, data, serial)

        print("\n" + "=" * 70)
        print(f"== {TAG} — REKOD DICIPTA + CETAK DIHANTAR")
        print("=" * 70)
        print(f"  No. rekod : {hasil['no_rekod']}")
        print(f"  No. siri  : {hasil['no_siri']}")
        print(f"  Kejayaan  : {hasil['kejayaan']}")
        print(f"  MySIKAP   : terbukti fasa 1 "
              f"({f1['medan_berubah']} medan auto-isi)")
        print(f"  Printer   : {lap.get('nama')}")
        print(f"  Popup tutup selepas CETAK: {hc['popup_tutup']}")
        print("\n  MENUNGGU PENGESAHAN KERTAS OLEH PEMILIK.")
        return 0
    except BaseException as e:                                  # noqa: BLE001
        print(f"\n{'!' * 70}\n!! BERHENTI — {type(e).__name__}\n{'!' * 70}")
        print(str(e)[:2500])
        if not isinstance(e, (SerahTidakDiizinkan, PrinterTidakSedia)):
            traceback.print_exc()
        if drv is not None:
            bukti(drv, f"{TAG}-ABORT")
        FC.catat_ledger({"peristiwa": "e2e-gagal", "set_id": SET_ID,
                         "punca": f"{type(e).__name__}: "
                                  f"{str(e).splitlines()[0][:200]}"})
        return 1
    finally:
        if drv is not None:
            c = getattr(drv, "corong", None)
            if c is not None:
                print(f"\n  [CORONG] {c.bil_tap} tap dinilai, "
                      f"{c.bil_sekat} disekat")
            try:
                drv.quit()
            except Exception:                                   # noqa: BLE001
                pass


if __name__ == "__main__":
    sys.exit(main())

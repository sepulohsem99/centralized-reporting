"""
RECON dropdown pressable RN — BACA-SAHAJA, tiada nilai dipilih.

    python devtools/recon_dropdown.py

Untuk setiap satu daripada tiga tingkat:
  1. tap pressable '-- PILIH ... --'
  2. dump page_source + screenshot ke docs/recon/
  3. TUTUP dengan Android back SAHAJA

TIADA baris dipilih. Kesan memilih belum diketahui, dan pada production
"belum diketahui" bermakna jangan sentuh — arahan pemilik 2026-08-10.

Untuk sampai ke tab NOTIS, borang Pesalah perlu diisi (butang SETERUSNYA
mengesahkan medan wajib). Itu laluan N-001 fill-only yang memang sudah
diluluskan, dengan data oracle. Borang TIDAK diserah dan ditinggalkan
melalui Back.
"""

import os
import re
import sys
import time
import xml.etree.ElementTree as ET

HERE = os.path.dirname(os.path.abspath(__file__))
AKAR = os.path.dirname(HERE)
sys.path.insert(0, AKAR)

DIR_RECON = os.path.join(AKAR, "docs", "recon")

TINGKAT = [
    ("tier1", "KETERANGAN KOD KOMPAUN"),
    ("tier2", "KOD AKTA"),
    ("tier3", "KESALAHAN KOMPAUN"),
]


def papar(nilai):
    keluar = []
    for ch in nilai or "":
        o = ord(ch)
        keluar.append(f"<U+{o:04X}>" if (0xE000 <= o <= 0xF8FF
                                         or 0xF0000 <= o <= 0xFFFFD) else ch)
    return "".join(keluar)


def ringkas(drv, tajuk, had=60):
    """Cetak struktur skrin ringkas dan pulangkan XML mentah."""
    src = drv.page_source
    print(f"\n----- {tajuk} -----")
    try:
        akar = ET.fromstring(src)
    except ET.ParseError as e:
        print(f"  XML tidak boleh dihurai: {e}")
        return src
    n = 0
    for x in akar.iter():
        t = (x.get("text") or "").strip()
        d = (x.get("content-desc") or "").strip()
        rid = (x.get("resource-id") or "").strip()
        if not (t or d or rid):
            continue
        n += 1
        if n > had:
            continue
        kelas = (x.get("class") or "").replace("android.widget.", "") \
                                      .replace("android.view.", "v.")
        label = papar(t) or papar(d)
        if rid:
            label = f"{label}  [id={rid}]"
        print(f"  {kelas[:26]:26} clk={x.get('clickable',''):5} "
              f"{x.get('bounds',''):24} {label[:56]}")
    if n > had:
        print(f"  ... dan {n - had} nod berlabel lagi")
    return src


def simpan(drv, src, nama):
    os.makedirs(DIR_RECON, exist_ok=True)
    p_xml = os.path.join(DIR_RECON, f"{nama}.xml")
    with open(p_xml, "w", encoding="utf-8") as fh:
        fh.write(src)
    p_png = os.path.join(DIR_RECON, f"{nama}.png")
    try:
        drv.get_screenshot_as_file(p_png)
    except Exception as e:                                    # noqa: BLE001
        p_png = f"(screenshot gagal: {e})"
    print(f"  disimpan: {p_xml}")
    print(f"            {p_png}")


def main():
    from tests.conftest import create_driver, Pages
    from config import APP_PACKAGE, TEST_CREDENTIALS
    from testdata import oracle_n001 as O
    from devtools.smoke_tangga import pastikan_di_home

    drv = create_driver()
    pages = Pages(drv)
    try:
        if not pastikan_di_home(drv, pages):
            print("HENTI: tidak sampai ke skrin utama")
            return 1

        pages.home.open_notis_amaran()
        p = pages.notis_amaran
        if not p.is_notis_amaran_screen_displayed():
            print("HENTI: borang Notis Amaran tidak terpapar")
            return 1

        print("\n== mengisi Pesalah (data oracle) untuk mencapai tab NOTIS ==")
        p.fill_pesalah_tab(O.SEMUA)
        p.click_seterusnya_from_pesalah()
        if not p.is_element_present(p.LABEL_TIER1, timeout=10):
            print("HENTI: tab Notis tidak membawa LABEL_TIER1")
            return 1

        src = ringkas(drv, "TAB NOTIS sebelum sebarang tap dropdown")
        simpan(drv, src, "dropdown_00_sebelum")

        for tag, label_nama in TINGKAT:
            print(f"\n{'=' * 62}\n== {label_nama}\n{'=' * 62}")
            # Cari pressable SEGAR setiap kali — pokok RN re-render.
            lbl = p.find_element(
                (p.LABEL_TIER1[0],
                 f'new UiSelector().textMatches("(?i)\\\\s*'
                 f'{label_nama.replace(" ", chr(92) + chr(92) + "s+")}\\\\s*")'),
                timeout=10)
            r = lbl.rect
            calon = p._pressable_bawah_label(r["y"] + r["height"])
            if not calon:
                print(f"  TIADA pressable di bawah '{label_nama}' — "
                      f"melangkau")
                continue
            print(f"  {len(calon)} pressable di bawah label; mengetuk yang "
                  f"paling hampir (y={calon[0][0]})")
            p.tap_element(calon[0][1])
            time.sleep(2.0)

            src = ringkas(drv, f"SELEPAS tap {label_nama}")
            simpan(drv, src, f"dropdown_{tag}_terbuka")

            # TUTUP — Android back SAHAJA. Tiada baris dipilih.
            print("  menutup dengan Android back (TIADA baris dipilih)")
            p.press_back()
            time.sleep(1.5)
            masih = p.is_element_present(p.LABEL_TIER1, timeout=5)
            print(f"  kembali ke borang: {masih}")
            if not masih:
                print("  AMARAN: borang tidak dikenali selepas back — "
                      "berhenti supaya keadaan tidak diteka")
                simpan(drv, drv.page_source, f"dropdown_{tag}_selepas_back")
                return 1

        print("\nSELESAI — tiada nilai dipilih, borang tidak diserah.")
        return 0
    finally:
        c = getattr(drv, "corong", None)
        if c is not None:
            print(f"\n  [CORONG] {c.bil_tap} tap dinilai, {c.bil_sekat} disekat"
                  + (f" | DIBATALKAN: {c.dibatalkan}" if c.dibatalkan else ""))
        try:
            drv.quit()
        except Exception:                                     # noqa: BLE001
            pass


if __name__ == "__main__":
    sys.exit(main())

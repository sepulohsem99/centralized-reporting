"""
DEMO FASA 1 — larian hujung-ke-hujung untuk diperhati pemilik.

Bukan Fasa 3. TANPA Serah. 0 rekod. Semua guard dan trip-wire kekal
aktif; corong dipasang oleh create_driver() seperti biasa.

Urutan (arahan pemilik 2026-08-11):
  1. device + app 2.1.21 + IP production
  2. login msc (aliran T-012) -> skrin utama
  3. Selaras read-only: T-003, T-005, T-006, T-007, T-009 (SEKALI)
     - T-004 TIDAK dicetuskan (D-01). Snapshot sedia ada digunakan.
     - SELARAS PELESEN HARAM (disekat pada lapisan tap, bukan diingat)
  4. Tetapan: T-001, T-002, T-010, T-011
  5. N-001 fill-only + read-back + BACK OUT + post-check
  6. P-001 fill-only + post-check
  7. K-001 fill-only + ePBT + post-check

Berterusan antara TC; berhenti hanya pada DryRunViolation, kegagalan
post-check, atau keputusan yang perlukan pemilik.

    python devtools/demo_fasa1.py
"""

import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
AKAR = os.path.dirname(HERE)
sys.path.insert(0, AKAR)

from guard.dasar import DryRunViolation                       # noqa: E402
from devtools import peringkat6 as P6                         # noqa: E402
from devtools.smoke_tangga import (peringkat_1, peringkat_2,  # noqa: E402
                                   peringkat_t001, peringkat_5)


def tajuk(t):
    print("\n" + "=" * 70)
    print(f"== {t}")
    print("=" * 70)


def langkah_3_selaras(pages):
    """T-003, T-005 kemudian T-006/T-007/T-009. SEKALI setiap satu.

    >>> T-004 TIDAK DIJALANKAN. <<<
    peringkat_3() menjalankan T-003, T-004, T-005 sebagai satu blok.
    Ia tidak boleh digunakan di sini: T-004 (Selaras Alamat) tidak
    idempotent pada 2.1.21 — sync kali kedua memberi 'Duplicate entry
    for local_ekpn_bandar' dan app tercampak keluar (D-01). Arahan
    pemilik: guna snapshot sedia ada, jangan cetuskan sync.

    Jadi modul dipanggil satu-satu, dan T-004 sengaja tiada dalam
    senarai. SELARAS PELESEN juga tiada — dan lebih penting, ia
    disekat pada lapisan tap, jadi ketukan tersasar pun tidak boleh
    mencetuskannya.
    """
    tajuk("LANGKAH 3 — Selaras read-only (T-004 TIDAK dicetuskan)")
    p = pages.pelarasan
    for tc, nama, fn in (
        ("MBPG-TC-T-003", "Selaras Pengguna Apps",
         lambda: p.selaras_pengguna_apps()),
        ("MBPG-TC-T-005", "Selaras Maklumat Kompaun",
         lambda: p.selaras_maklumat_kompaun()),
    ):
        try:
            p.ensure_on_login_screen()
            p.open_menu_selaras()
            ok = fn() is not False
            P6.rekod(tc, "PASS" if ok else "FAIL", nama)
        except DryRunViolation:
            raise
        except Exception as e:                                # noqa: BLE001
            P6.rekod(tc, "FAIL", f"{nama}: {type(e).__name__}: "
                                 f"{str(e)[:180]}")
        try:
            p.close_menu_selaras()
        except Exception:                                     # noqa: BLE001
            pass

    P6.rekod("MBPG-TC-T-004", "SKIP",
             "sync TIDAK dicetuskan — D-01: Selaras Alamat tidak "
             "idempotent pada 2.1.21 (Duplicate entry, app ranap). "
             "Snapshot sedia ada digunakan. Arahan pemilik.")
    P6.rekod("MBPG-TC-T-008", "SKIP",
             "SELARAS PELESEN — arahan pemilik, sync 3-4 jam. Disekat "
             "pada lapisan tap, bukan sekadar dilangkau.")

    P6.selaras_sekali(pages, hanya=("MBPG-TC-T-006", "MBPG-TC-T-007",
                                    "MBPG-TC-T-009"))


def langkah_4_tetapan(pages, serial):
    tajuk("LANGKAH 4 — Tetapan: T-001 / T-002 / T-010 / T-011")

    # >>> T-001 BACA-SAHAJA. <<<
    # Arahan demo menyebut "masuk IP sama + SIMPAN". Keputusan pemilik
    # 2026-08-10 mengatasi itu: medan Internal TIDAK kekal (D-02, app
    # membuangnya), dan arahannya ialah BERHENTI mengisinya semula.
    # Menulis config ke peranti production untuk mengejar nilai yang
    # app sendiri buang bukan ujian.
    #
    # Nilai demo tidak hilang: T-002 di bawah menekan SIMPAN sebenar
    # dalam konteks Tetapan, jadi pengecualian corong tetap kelihatan
    # berfungsi secara langsung.
    try:
        ok = peringkat_t001(pages, serial)
        P6.rekod("MBPG-TC-T-001", "PASS" if ok else "FAIL",
                 "BACA-SAHAJA: External disahkan pada skrin + DB. "
                 "Internal tidak ditulis (D-02, keputusan pemilik "
                 "2026-08-10).")
    except DryRunViolation:
        raise
    except Exception as e:                                    # noqa: BLE001
        P6.rekod("MBPG-TC-T-001", "FAIL", f"{type(e).__name__}: "
                                          f"{str(e)[:180]}")

    try:
        P6.t002(pages)
    except (DryRunViolation, P6.RestoreGagal):
        raise
    except Exception as e:                                    # noqa: BLE001
        P6.rekod("MBPG-TC-T-002", "FAIL", f"{type(e).__name__}: "
                                          f"{str(e)[:180]}")

    try:
        P6.t010(pages)
    except DryRunViolation:
        raise
    except Exception as e:                                    # noqa: BLE001
        P6.rekod("MBPG-TC-T-010", "FAIL", f"{type(e).__name__}: "
                                          f"{str(e)[:180]}")
    try:
        pages.pelarasan.close_menu_selaras()
    except Exception:                                         # noqa: BLE001
        pass

    P6.selaras_sekali(pages, hanya=("MBPG-TC-T-011",))


def main():
    from device_utils import resolve_udid
    from config import APP_PACKAGE

    mula = time.time()
    serial = resolve_udid(APP_PACKAGE, verbose=False)

    tajuk("DEMO FASA 1 — TANPA SERAH, 0 REKOD, GUARD PENUH")
    print("  Sweep 279/284 set TIDAK disentuh (belum diluluskan).")
    print("  Selaras Pelesen HARAM. Serah/Hantar/Sahkan/Ya = trip-wire.")

    # ---- 1 ----
    tajuk("LANGKAH 1 — device / app / IP / baseline")
    p1 = peringkat_1(serial)
    if not p1["ok"]:
        print("\nHENTI: gerbang peranti gagal.")
        return 1
    baseline = p1["baseline"]
    P6.baseline_global = baseline

    drv = pages = None
    try:
        # ---- 2 ----
        tajuk("LANGKAH 2 — login msc (aliran T-012) -> skrin utama")
        drv, pages = peringkat_2()
        P6.rekod("MBPG-TC-T-012", "PASS", "log masuk sampai skrin utama")

        # ---- 3 ----
        langkah_3_selaras(pages)

        # ---- 4 ----
        langkah_4_tetapan(pages, serial)

        # ---- 5 ----
        tajuk("LANGKAH 5 — N-001 fill-only")
        P6.relaunch(drv, pages, "N-001: borang bersih")
        try:
            ok = peringkat_5(pages, serial, baseline, drv)
            P6.rekod("MBPG-TC-N-001", "PASS" if ok else "FAIL",
                     "fill + read-back + BACK OUT tanpa Serah")
            if not ok:
                print("\nHENTI: N-001 gagal.")
                return 1
        except DryRunViolation:
            raise

        # ---- 6 dan 7 ----
        from testdata import oracle_pk as OPK
        P6._pakai_sauh_alamat(serial, OPK.P001, OPK.K001)

        tajuk("LANGKAH 6 — P-001 fill-only")
        try:
            P6.borang_kompaun(drv, pages, "Kompaun Pelbagai", OPK.P001,
                              OPK.P001_READBACK_PESALAH,
                              OPK.P001_READBACK_KOMPAUN, "MBPG-TC-P-001")
        except DryRunViolation:
            raise
        except Exception as e:                                # noqa: BLE001
            P6.rekod("MBPG-TC-P-001", "FAIL", f"{type(e).__name__}: "
                                              f"{str(e)[:200]}")
        P6._keluar_ke_home(pages, "P-001")
        if not P6.post_check(serial, baseline, "MBPG-TC-P-001"):
            return 1

        tajuk("LANGKAH 7 — K-001 fill-only + ePBT (JYX6605)")
        try:
            if not P6.k001_epbt(drv, pages, serial, baseline, OPK.K001,
                                OPK.K001["no_kereta"]):
                return 1
        except DryRunViolation:
            raise
        except Exception as e:                                # noqa: BLE001
            P6.rekod("MBPG-TC-K-001", "FAIL", f"{type(e).__name__}: "
                                              f"{str(e)[:200]}")

        # ---- ringkasan ----
        tajuk("RINGKASAN DEMO FASA 1")
        kira = {}
        for h in P6.HASIL:
            kira[h["status"]] = kira.get(h["status"], 0) + 1
            print(f"  {h['status']:5} {h['tc']}")
            if h["nota"]:
                print(f"        {h['nota'][:170]}")
        print(f"\n  {kira}")
        print(f"  Masa: {(time.time() - mula) / 60:.1f} minit")
        return 0
    finally:
        if drv is not None:
            c = getattr(drv, "corong", None)
            if c is not None:
                print(f"\n  [CORONG] {c.bil_tap} tap dinilai, "
                      f"{c.bil_sekat} disekat"
                      + (f" | DIBATALKAN: {c.dibatalkan}"
                         if c.dibatalkan else ""))
            try:
                drv.quit()
            except Exception:                                 # noqa: BLE001
                pass


if __name__ == "__main__":
    sys.exit(main())

"""
SWEEP PENUH — 284 set melalui tiga dropdown. Fill-only, 0 rekod.

Diluluskan pemilik 2026-08-11 untuk larian tanpa pengawasan.

    set MBPG_IZIN_PRODUCTION=1
    python devtools/sweep_penuh.py            # sambung kalau CSV ada
    python devtools/sweep_penuh.py --had 10   # ujian pendek

APA YANG DILAKUKAN untuk setiap set:
    buka borang -> (Pesalah minimum kalau perlu) -> pilih 3 dropdown
    -> baca-balik -> baca kadar denda yang APP papar -> catat baris
    MATRIX -> teruskan. BACK OUT tanpa Serah pada penghujung setiap
    kumpulan borang. Post-check berkala.

APA YANG TIDAK PERNAH DILAKUKAN:
    Serah, Hantar, Simpan (luar konteks Tetapan), Sahkan, Kemaskini,
    cetak, tarik notis, Selaras Pelesen, dan butang ePBT. Corong
    menguatkuasakan ini pada lapisan tap — bukan dengan ingatan.

HENTI SERTA-MERTA hanya pada tiga keadaan:
    1. DryRunViolation (trip-wire tercetus)
    2. RestoreGagal
    3. Post-check menjumpai rekod BARU
Segala kegagalan set lain DICATAT dan sweep meneruskan — menghentikan
284 set kerana satu kombinasi gagal akan membuang bukti untuk 283
yang lain.
"""

import argparse
import csv
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
AKAR = os.path.dirname(HERE)
sys.path.insert(0, AKAR)

from guard.dasar import DryRunViolation                       # noqa: E402
from devtools import peringkat6 as P6                         # noqa: E402

LAJUR = ["set_id", "borang", "jangkaan", "kompaun_ok", "akta_ok",
         "kesalahan_ok", "denda", "saat", "laluan", "catatan"]

# Post-check setiap N set. Borang kekal terbuka merentas set, jadi
# "selepas setiap borang" bermakna selepas setiap kumpulan — bukan
# selepas setiap set. N=20 mengehadkan pendedahan kepada 20 set
# sementara mengelak 284 tarikan DB (~15 minit masa peranti).
SETIAP_POSTCHECK = 20
SETIAP_LAPOR = 10


class RekodBaruDikesan(BaseException):
    """Post-check menjumpai rekod. BaseException: tidak boleh ditelan."""


# ---------------------------------------------------------------------------
# MATRIX
# ---------------------------------------------------------------------------
def buka_matrix(laluan):
    """Pulangkan (fh, writer, set_id_yang_sudah_siap).

    Sambung, bukan tulis-ganti: larian yang terhenti di tengah tidak
    boleh kehilangan bukti yang sudah terkumpul.
    """
    siap = set()
    if os.path.exists(laluan):
        try:
            with open(laluan, newline="", encoding="utf-8") as fh:
                for r in csv.DictReader(fh):
                    if r.get("set_id"):
                        siap.add(r["set_id"])
        except OSError:
            pass
    baharu = not siap
    fh = open(laluan, "a", newline="", encoding="utf-8")
    w = csv.DictWriter(fh, fieldnames=LAJUR, extrasaction="ignore")
    if baharu:
        w.writeheader()
        fh.flush()
        os.fsync(fh.fileno())
    return fh, w, siap


def tulis_baris(fh, w, baris):
    """fsync SETIAP baris. Batal di tengah tidak boleh kehilangan
    kerja yang sudah dibayar dengan masa peranti."""
    w.writerow(baris)
    fh.flush()
    os.fsync(fh.fileno())


# ---------------------------------------------------------------------------
# Pemilihan borang
# ---------------------------------------------------------------------------
def agih_borang(sets):
    """Setiap set dipandu SEKALI, pada satu borang.

    236 set membawa 'P', 48 selebihnya hanya 'K' — bersama tepat 284.
    'N' bertindih sepenuhnya dengan 'P', jadi memandunya sekali lagi
    pada N hanya akan menggandakan masa peranti tanpa menambah
    kombinasi baharu.
    """
    p, k, lain = [], [], []
    for s in sets:
        b = s.get("borang") or []
        if "P" in b:
            p.append(s)
        elif "K" in b:
            k.append(s)
        else:
            lain.append(s)
    return p, k, lain


# ---------------------------------------------------------------------------
# Persediaan borang
# ---------------------------------------------------------------------------
def sedia_p(pages):
    from tests.sweep_kongsi import sedia_borang_kompaun
    sedia_borang_kompaun(pages, "Kompaun Pelbagai")


def sedia_k(pages):
    """Borang Letak Kereta: tab Pesalah tiada blok alamat, jadi
    sedia_borang_kompaun() (yang mengisi alamat) tidak sesuai.
    Minimum di sini ialah Nama + IC, kemudian tab KOMPAUN."""
    from tests.sweep_kongsi import data_pesalah_minimum
    p = pages.daftar_kompaun
    if not p.is_daftar_kompaun_screen_displayed():
        pages.home.open_daftar_kompaun()
        p.select_jenis_kompaun_letak_kereta()
    d = data_pesalah_minimum()
    P6._isi_medan_tepat(p, "Nama Pesalah", d["nama_pesalah"])
    P6._isi_medan_tepat(p, "No K/P/SSM", d["no_kp_ssm_kereta"])
    # >>> NO. KERETA WAJIB. Diperhati 2026-08-12. <<<
    # Nama + IC sahaja tidak memuaskan gerbang urutan tab pada borang
    # ini: app menolak dengan "Sila lengkapkan maklumat di tab Pesalah
    # dahulu". Masuk akal — ia kompaun LETAK KERETA; plat ialah
    # subjeknya.
    #
    # Plat ujian sah yang pemilik bekalkan digunakan. MySIKAP TIDAK
    # ditekan: sweep hanya perlukan gerbang dilepasi, dan menekan
    # lookup akan membuat pertanyaan JPJ sebenar 48 kali tanpa sebab.
    from testdata import oracle_pk as OPK
    P6._isi_medan_tepat(p, "No. Kereta", OPK.K001["no_kereta"])
    p.wait_and_tap(p.TAB_KOMPAUN)
    time.sleep(1.5)
    p.fill_kompaun_tab(d)


# ---------------------------------------------------------------------------
# Pemandu
# ---------------------------------------------------------------------------
def reset_viewport(p):
    """Bawa tab KOMPAUN kembali ke ATAS sebelum set seterusnya.

    >>> KENAPA INI WAJIB. Ujian 3-set 2026-08-11. <<<
    Set 1 lulus penuh. Set 2 GAGAL pada tingkat 1 dengan
    "label 'KETERANGAN KOD KOMPAUN' tidak dijumpai ... 0 Spinner
    dilihat keseluruhan".

    Sebabnya bukan kombinasi set 2: bacaan kadar denda pada set 1
    menggunakan traversal untuk menarik borang ke BAWAH, dan borang
    kekal di situ. Tingkat 1 kemudian berada di ATAS viewport, dan
    borang ini tidak boleh di-swipe kembali.

    Nota reka bentuk sweep yang lama menganggap "dropdown ditetapkan
    semula oleh pemilihan tingkat 1 yang seterusnya" — itu benar untuk
    NILAI dropdown, tetapi bukan untuk KEDUDUKAN tatal.

    >>> KITAR TAB TIDAK MENCUKUPI — diuji, gagal. <<<
    Percubaan pertama menukar PESALAH -> KOMPAUN. Set 2 tetap gagal
    dengan cara yang sama: RN mengekalkan offset tatal setiap tab,
    jadi kembali ke tab itu memulihkan kedudukan LAMA, bukan atas.

    Dan traversal biasa tidak boleh membantu di sini: `reveal_below_
    fold()` menekan TAB, yang hanya bergerak KE HADAPAN. Tingkat 1
    berada di BELAKANG kedudukan semasa, jadi tiada jumlah TAB akan
    sampai kepadanya. Itulah sebabnya laluan 2 juga gagal dalam log.

    Jalan yang berkesan ialah mekanisme yang SAMA dalam arah
    bertentangan: DPAD_UP (keycode 19) menarik fokus — dan viewport —
    ke atas. Ditekan berkelompok dan disemak antara kelompok, jadi ia
    berhenti sebaik sahaja tingkat 1 muncul dan bukan menekan buta.
    """
    SASARAN = "KETERANGAN KOD KOMPAUN"
    try:
        if SASARAN in p.driver.page_source:
            return True
    except Exception:                                         # noqa: BLE001
        pass
    for kelompok in range(6):
        try:
            for _ in range(8):
                p.driver.press_keycode(19)      # DPAD_UP
            time.sleep(0.4)
            if SASARAN in p.driver.page_source:
                print(f"  [RESET] viewport dipulihkan ke atas "
                      f"({(kelompok + 1) * 8} DPAD_UP)")
                return True
        except Exception as e:                                # noqa: BLE001
            print(f"  [RESET] traversal ke atas gagal "
                  f"({type(e).__name__})")
            return False
    print("  [RESET] tingkat 1 masih tidak kelihatan selepas 48 DPAD_UP")
    return False


def _tiga_ya(kep):
    return all(getattr(kep, m, "") == "YA" for m in
               ("kompaun_ok", "akta_ok", "kesalahan_ok"))


def pulih_borang(drv, pages, sedia, sebab):
    """Relaunch + bina semula borang. Laluan recovery rasmi."""
    from devtools.smoke_tangga import pastikan_di_home
    print(f"  [PULIH] membina semula borang — {sebab}")
    P6.relaunch(drv, pages, f"sweep: {sebab}")
    pastikan_di_home(drv, pages)
    sedia(pages)


def jalankan_kumpulan(drv, pages, sets, borang, sedia, w, fh, serial,
                      baseline, keadaan):
    """Pandu satu kumpulan set pada satu borang. Pulangkan bil selesai."""
    from pages.sweep_kombo import sapu_satu_set

    if not sets:
        return 0
    print(f"\n{'=' * 68}\n== BORANG {borang}: {len(sets)} set\n{'=' * 68}")

    P6.relaunch(drv, pages, f"sweep borang {borang}: borang bersih")
    from devtools.smoke_tangga import pastikan_di_home
    if not pastikan_di_home(drv, pages):
        raise RuntimeError(f"tidak sampai skrin utama sebelum borang {borang}")

    # Persediaan yang gagal TIDAK boleh meranapkan kumpulan. Kalau
    # borang ini tidak boleh disediakan, setiap setnya direkod dengan
    # sebab yang sama dan sweep meneruskan ke kumpulan seterusnya —
    # 48 baris bersebab jauh lebih berguna daripada satu traceback.
    try:
        sedia(pages)
    except (DryRunViolation, RekodBaruDikesan):
        raise
    except BaseException as e:                                # noqa: BLE001
        if not isinstance(e, Exception):
            raise
        sebab = (f"persediaan borang {borang} GAGAL: "
                 f"{type(e).__name__}: {str(e)[:160]}")
        print(f"  [GAGAL] {sebab}")
        for s in sets:
            keadaan["n"] += 1
            keadaan["gagal"] += 1
            tulis_baris(fh, w, {
                "set_id": s["set_id"], "borang": borang,
                "jangkaan": s["jangkaan"], "kompaun_ok": "", "akta_ok": "",
                "kesalahan_ok": "", "denda": "", "saat": "0",
                "laluan": keadaan["laluan"], "catatan": sebab})
        return 0

    bil = 0
    for s in sets:
        keadaan["n"] += 1
        n = keadaan["n"]
        t0 = time.time()
        try:
            if not reset_viewport(pages.daftar_kompaun):
                # Borang tidak boleh dipulihkan ke atas — ia tersangkut.
                # Bina semula sebelum memandu set, bukan selepas gagal.
                pulih_borang(drv, pages, sedia, f"reset gagal @{n}")
            kep = sapu_satu_set(pages.daftar_kompaun, s, borang)
            if not _tiga_ya(kep):
                # >>> BEZAKAN BORANG TERSANGKUT DARIPADA KOMBINASI
                # YANG MEMANG GAGAL. Diperhati 2026-08-12. <<<
                # Selepas set ~99 borang masuk keadaan di mana SETIAP
                # set gagal dengan StaleElementReferenceException, ~100s
                # setiap satu, enam berturut-turut. Pemulihan berkala
                # (setiap 20 set) terlalu jarang: sehingga 20 baris
                # MATRIX boleh diisi dengan kegagalan yang BUKAN
                # dapatan tentang data, cuma harnes yang rosak.
                #
                # Jadi setiap kegagalan mendapat SATU percubaan pada
                # borang yang baru dibina. Kalau ia gagal lagi di situ,
                # itu dapatan sebenar dan direkod sedemikian.
                pulih_borang(drv, pages, sedia, f"{s['set_id']} gagal")
                kep2 = sapu_satu_set(pages.daftar_kompaun, s, borang)
                if _tiga_ya(kep2):
                    kep = kep2
                    kep.catatan = ("lulus selepas borang dibina semula; "
                                   "kegagalan pertama = harnes, bukan data")
                else:
                    kep = kep2
                    kep.catatan = ("[disahkan selepas bina semula] "
                                   + (kep2.catatan or ""))
            baris = {
                "set_id": s["set_id"], "borang": borang,
                "jangkaan": s["jangkaan"],
                "kompaun_ok": kep.kompaun_ok, "akta_ok": kep.akta_ok,
                "kesalahan_ok": kep.kesalahan_ok, "denda": kep.denda,
                "saat": f"{kep.saat:.0f}", "laluan": keadaan["laluan"],
                "catatan": kep.catatan,
            }
        except (DryRunViolation, RekodBaruDikesan):
            raise
        except BaseException as e:                            # noqa: BLE001
            if not isinstance(e, Exception):
                raise
            baris = {
                "set_id": s["set_id"], "borang": borang,
                "jangkaan": s["jangkaan"], "kompaun_ok": "", "akta_ok": "",
                "kesalahan_ok": "", "denda": "",
                "saat": f"{time.time() - t0:.0f}",
                "laluan": keadaan["laluan"],
                "catatan": f"{type(e).__name__}: {str(e)[:200]}",
            }
        tulis_baris(fh, w, baris)
        bil += 1

        tiga = (baris["kompaun_ok"], baris["akta_ok"],
                baris["kesalahan_ok"])
        if all(x == "YA" for x in tiga):
            keadaan["lulus"] += 1
        else:
            keadaan["gagal"] += 1

        if n % SETIAP_LAPOR == 0 or baris["catatan"]:
            tanda = "OK " if all(x == "YA" for x in tiga) else "GAGAL"
            berlalu = (time.time() - keadaan["mula"]) / 60.0
            baki = (keadaan["jumlah"] - n) * (berlalu * 60 / max(n, 1)) / 60.0
            print(f"  [{n:3}/{keadaan['jumlah']}] {tanda} "
                  f"{s['set_id']:<22} denda={baris['denda']!r:>8} "
                  f"{baris['saat']}s | lulus={keadaan['lulus']} "
                  f"gagal={keadaan['gagal']} | {berlalu:.0f}m berlalu, "
                  f"~{baki:.0f}m lagi")
            if baris["catatan"]:
                print(f"        {baris['catatan'][:150]}")

        if n % SETIAP_POSTCHECK == 0:
            if not P6.post_check(serial, baseline, f"sweep-{n}"):
                raise RekodBaruDikesan(f"post-check gagal selepas set {n}")
            # Borang boleh hanyut selepas berpuluh kitaran modal;
            # pulihkan supaya set seterusnya bermula bersih.
            P6.relaunch(drv, pages, f"sweep: pemulihan berkala @{n}")
            pastikan_di_home(drv, pages)
            sedia(pages)
    return bil


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--had", type=int, default=None,
                    help="Hadkan bilangan set (ujian pendek).")
    ap.add_argument("--csv", default=None)
    a = ap.parse_args()

    from device_utils import resolve_udid
    from config import APP_PACKAGE
    from devtools.smoke_tangga import peringkat_1, peringkat_2
    from testdata import sets_loader as SL

    tarikh = time.strftime("%Y%m%d")
    laluan_csv = a.csv or os.path.join(AKAR, "reports",
                                       f"MATRIX-{tarikh}.csv")
    serial = resolve_udid(APP_PACKAGE, verbose=False)

    sets = [s for s in SL.muat_semua() if s.get("dalam_skop")]
    sets.sort(key=lambda s: s["set_id"])
    p_sets, k_sets, lain = agih_borang(sets)

    print("=" * 70)
    print("== SWEEP PENUH — fill-only, TANPA Serah, 0 rekod")
    print("=" * 70)
    print(f"  set dalam skop : {len(sets)}")
    print(f"  borang P       : {len(p_sets)}")
    print(f"  borang K       : {len(k_sets)}")
    if lain:
        print(f"  TIADA borang   : {len(lain)} (dilangkau)")
    print(f"  MATRIX         : {laluan_csv}")

    fh, w, siap = buka_matrix(laluan_csv)
    if siap:
        print(f"  SAMBUNG        : {len(siap)} set sudah ada dalam CSV")
        p_sets = [s for s in p_sets if s["set_id"] not in siap]
        k_sets = [s for s in k_sets if s["set_id"] not in siap]
    if a.had:
        p_sets, k_sets = p_sets[:a.had], k_sets[:max(0, a.had - len(p_sets))]
        print(f"  HAD            : {a.had} set")

    p1 = peringkat_1(serial)
    if not p1["ok"]:
        print("\nHENTI: gerbang peranti gagal.")
        return 1
    baseline = p1["baseline"]
    P6.baseline_global = baseline

    # Skrin kekal hidup sepanjang larian tanpa pengawasan.
    import subprocess
    try:
        subprocess.run(["adb", "-s", serial, "shell", "svc", "power",
                        "stayon", "true"], capture_output=True, timeout=15)
        print("  [PERANTI] svc power stayon true")
    except Exception:                                         # noqa: BLE001
        print("  [PERANTI] AMARAN: stayon tidak dapat ditetapkan")

    drv = pages = None
    keadaan = {"n": 0, "lulus": 0, "gagal": 0, "mula": time.time(),
               "jumlah": len(p_sets) + len(k_sets), "laluan": "?"}
    try:
        drv, pages = peringkat_2()

        # ---- LANGKAH 1: PATHFINDER ----
        print("\n-- PATHFINDER: bolehkah dropdown dicapai TANPA Pesalah? --")
        from devtools.pathfinder_sweep import laluan_a_lompat_terus
        ok_a, nota_a = laluan_a_lompat_terus(drv, pages)
        keadaan["laluan"] = ("A-dropdown-terus" if ok_a
                             else "B-pesalah-minimum")
        nama_laluan = ("A (lompat terus)" if ok_a
                       else "B (isi Pesalah minimum + sauh berposkod)")
        print(f"  PATHFINDER: {nama_laluan} — {nota_a}")
        P6._keluar_ke_home(pages, "pathfinder")

        # ---- LANGKAH 2: SWEEP ----
        jalankan_kumpulan(drv, pages, p_sets, "P", sedia_p, w, fh,
                          serial, baseline, keadaan)
        jalankan_kumpulan(drv, pages, k_sets, "K", sedia_k, w, fh,
                          serial, baseline, keadaan)

        print("\n-- post-check akhir --")
        P6._keluar_ke_home(pages, "sweep-akhir")
        bersih = P6.post_check(serial, baseline, "SWEEP-AKHIR")

        jam = (time.time() - keadaan["mula"]) / 3600.0
        print("\n" + "=" * 70)
        print("== SWEEP SELESAI")
        print("=" * 70)
        print(f"  set dipandu : {keadaan['n']}")
        print(f"  3 dropdown OK: {keadaan['lulus']}")
        print(f"  gagal        : {keadaan['gagal']}")
        print(f"  masa         : {jam:.1f} jam")
        print(f"  laluan       : {keadaan['laluan']}")
        print(f"  post-check   : {'BERSIH' if bersih else 'GAGAL'}")
        print(f"  MATRIX       : {laluan_csv}")
        return 0 if bersih else 1
    finally:
        try:
            fh.close()
        except Exception:                                     # noqa: BLE001
            pass
        try:
            subprocess.run(["adb", "-s", serial, "shell", "svc", "power",
                            "stayon", "false"], capture_output=True,
                           timeout=15)
        except Exception:                                     # noqa: BLE001
            pass
        if drv is not None:
            c = getattr(drv, "corong", None)
            if c is not None:
                print(f"\n  [CORONG] {c.bil_tap} tap dinilai, "
                      f"{c.bil_sekat} disekat"
                      + (f" | DIBATALKAN: {c.dibatalkan}"
                         if c.dibatalkan else ""))
            try:
                drv.quit()
            except Exception:                                 # noqa: BLE001
                pass


if __name__ == "__main__":
    sys.exit(main())

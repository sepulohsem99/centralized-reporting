"""
K-001 — lookup mySIKAP pada borang Letak Kereta.

Plat ujian rasmi pemilik dibaca dari testdata/oracle_pk.py.

Butang mySIKAP dikenal pasti oleh `peringkat6._cari_mysikap()`, yang
menyauh pada ePBT dan menuntut padanan TEPAT SATU di kanannya
(docs/recon/DAPATAN-MYSIKAP.md). ePBT TIDAK DITEKAN: pemilik
mengamarkan ia memadam data, dan ia BUKAN mySIKAP.

>>> KENAPA BEZA SEBELUM/SELEPAS, BUKAN "MEDAN TIDAK KOSONG". <<<
Borang ini mencerminkan plat ke tiga medan identiti sebaik No. Kereta
diisi (D-05). Jadi medan nama dan IC SUDAH berisi sebelum lookup
bermula, dan ujian "medan tidak lagi kosong" akan lulus tanpa lookup
berlaku langsung.

>>> PII. <<<
Lookup ini memulangkan nama, IC, dan alamat orang SEBENAR. Nilai
dicatat ke terminal dalam bentuk DIREDACT sahaja. Dump penuh ditulis
ke docs/recon/, yang digitignore secara rekursif.

    python devtools/k001_mysikap.py
"""

import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
AKAR = os.path.dirname(HERE)
sys.path.insert(0, AKAR)

from devtools import peringkat6 as P6                          # noqa: E402

DIR_RECON = os.path.join(AKAR, "docs", "recon")
TC = "K-001"

# Plat datang dari oracle, bukan literal di sini. Ia nombor
# pendaftaran kenderaan SEBENAR; menyalinnya ke setiap skrip baharu
# menyebarkannya dalam repo tanpa sebab, dan pengimbas PII menandakan
# setiap salinan itu -- betul-betul.
from testdata import oracle_pk as _OPK                       # noqa: E402

PLAT = _OPK.K001["no_kereta"]


def bukti(drv, tag):
    os.makedirs(DIR_RECON, exist_ok=True)
    asas = os.path.join(DIR_RECON, f"k001-{tag}")
    try:
        drv.get_screenshot_as_file(asas + ".png")
    except Exception:                                           # noqa: BLE001
        pass
    try:
        with open(asas + ".xml", "w", encoding="utf-8") as fh:
            fh.write(drv.page_source)
    except Exception:                                           # noqa: BLE001
        pass
    print(f"    [BUKTI] k001-{tag}")


def tunggu_beza(p, sebelum, saat=45):
    """Beza medan, atau {} kalau tiada dalam tempoh."""
    tamat = time.time() + saat
    while time.time() < tamat:
        time.sleep(3)
        beza = P6._beza_medan(sebelum, P6._snapshot_medan(p))
        if beza:
            return beza
    return P6._beza_medan(sebelum, P6._snapshot_medan(p))


def main():
    from devtools.smoke_tangga import peringkat_1, peringkat_2, \
        pastikan_di_home
    from device_utils import resolve_udid
    from config import APP_PACKAGE

    print("=" * 70)
    print(f"== {TC} — lookup mySIKAP, plat {PLAT}")
    print("== ePBT TIDAK DITEKAN.")
    print("=" * 70)

    serial = resolve_udid(APP_PACKAGE, verbose=False)
    p1 = peringkat_1(serial)
    if not p1["ok"]:
        return 1
    baseline = p1["baseline"]
    P6.baseline_global = baseline

    drv = pages = None
    hasil = {"kaedah": None, "auto_isi": None}
    try:
        drv, pages = peringkat_2()
        P6.relaunch(drv, pages, f"{TC}: borang bersih")
        if not pastikan_di_home(drv, pages):
            print("HENTI: tidak sampai skrin utama")
            return 1

        p = pages.daftar_kompaun
        pages.home.open_daftar_kompaun()
        p.select_jenis_kompaun_letak_kereta()

        if not P6._isi_medan_tepat(p, "No. Kereta", PLAT):
            print("HENTI: medan No. Kereta tidak dijumpai")
            bukti(drv, "GAGAL-medan-plat")
            return 1
        try:
            drv.hide_keyboard()
            time.sleep(0.5)
        except Exception:                                       # noqa: BLE001
            pass
        try:
            p.wait_and_tap(p.TAB_PESALAH)
            time.sleep(1.5)
        except Exception:                                       # noqa: BLE001
            pass
        bukti(drv, "01-sebelum-mysikap")

        ms = P6._cari_mysikap(p)
        if ms is None:
            print("\nHENTI: butang mySIKAP tidak dapat disahkan secara "
                  "struktur. TIADA tekaan dibuat (tekaan salah = tekan "
                  "ePBT = padam data). Dump disimpan.")
            bukti(drv, "GAGAL-mysikap-tidak-pasti")
            return 1
        print(f"\n  mySIKAP disahkan pada ({ms[0]}, {ms[1]})")

        # ---- kaedah 1: tap biasa ----
        sebelum = P6._snapshot_medan(p)
        print("  -- tap mySIKAP (menunggu sehingga 45s) --")
        P6._catat_ledger(drv, "mysikap-tap", f"{TC}: {PLAT} @ {ms}")
        drv.execute_script("mobile: clickGesture", {"x": ms[0], "y": ms[1]})
        beza = tunggu_beza(p, sebelum)
        if beza:
            hasil["kaedah"] = "tap"
        else:
            # ---- kaedah 2: tekan-tahan ----
            # Kakitangan lapangan melaporkan mySIKAP perlu tekan-tahan.
            # Dicuba hanya SELEPAS tap biasa gagal, supaya laporan
            # menyatakan kaedah mana yang sebenarnya berkesan.
            print("  tap biasa: TIADA kesan — mencuba tekan-tahan 1200ms")
            sebelum = P6._snapshot_medan(p)
            P6._catat_ledger(drv, "mysikap-longpress",
                             f"{TC}: {PLAT} @ {ms}")
            drv.execute_script("mobile: longClickGesture",
                               {"x": ms[0], "y": ms[1], "duration": 1200})
            beza = tunggu_beza(p, sebelum)
            if beza:
                hasil["kaedah"] = "tekan-tahan"

        bukti(drv, "02-selepas-mysikap")
        if beza:
            hasil["auto_isi"] = P6._redact_pii(beza)
            print(f"\n  [{TC}] mySIKAP LULUS melalui {hasil['kaedah']}")
            print(f"  auto-isi (DIREDACT): {hasil['auto_isi']}")
        else:
            # ---- sandaran: isi manual, dan KATAKAN ia sandaran ----
            print(f"\n  [{TC}] mySIKAP TIADA KESAN selepas tap DAN "
                  f"tekan-tahan (45s setiap satu)")
            print("  sandaran: isi manual — dicatat sebagai lookup GAGAL, "
                  "bukan lulus")
            from testdata import oracle_pk as OPK
            for label, kunci in (("Nama Pesalah", "nama_pesalah"),
                                 ("No. KP", "no_kp")):
                nilai = OPK.K001.get(kunci)
                if nilai:
                    P6._isi_medan_tepat(p, label, nilai)
            bukti(drv, "03-sandaran-manual")

        print("\n" + "=" * 70)
        print(f"== {TC} RINGKASAN")
        print("=" * 70)
        print(f"  butang mySIKAP  : dijumpai @ {ms}")
        print(f"  kaedah berkesan : {hasil['kaedah'] or 'TIADA'}")
        print(f"  auto-isi        : {hasil['auto_isi'] or 'tiada'}")
        print("  ePBT            : TIDAK DITEKAN")

        P6._keluar_ke_home(pages, TC)
        bersih = P6.post_check(serial, baseline, TC)
        print(f"  post-check      : {'bersih' if bersih else 'PERHATIAN'}")
        return 0
    finally:
        if drv is not None:
            c = getattr(drv, "corong", None)
            if c is not None:
                print(f"\n  [CORONG] {c.bil_tap} tap dinilai, "
                      f"{c.bil_sekat} disekat")
            try:
                drv.quit()
            except Exception:                                   # noqa: BLE001
                pass


if __name__ == "__main__":
    sys.exit(main())

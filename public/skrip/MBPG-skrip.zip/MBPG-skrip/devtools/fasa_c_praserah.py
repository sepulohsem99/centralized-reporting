"""
FASA C LANGKAH (a) — validasi PRA-SERAH untuk C1 / C2 / C3.

Memandu ketiga-tiga laluan sampai skrin pra-serah, mengesahkan gerbang
MENYEKAT pada titik serah, kemudian back out. **SIFAR REKOD.**

    C1-N-001  Notis Amaran     : KOMPAUN LETAK KERETA / PMTLK 2001
    C2-P-001  Kompaun Pelbagai : KOMPAUN PELBAGAI JP / UUK VANDALISME
    C3-K-001  Letak Kereta     : AKTA PENGANGKUTAN JALAN 1987 + MySIKAP

>>> KENAPA LANGKAH (a) TIDAK MENGGUNAKAN IDENTITI SEBENAR. <<<
Pemilik menetapkan identiti untuk Fasa C datang dari lookup MySIKAP
plat JYX6605 — nama, IC, dan alamat orang sebenar. Data itu TIDAK
dimasukkan ke dalam repo: `testdata/` dijejaki git, dan menyimpan IC
serta alamat kediaman seseorang di sana menjadikannya kekal.

Langkah (a) mencipta SIFAR rekod, jadi identiti tidak mengubah apa
yang ia buktikan: bahawa ketiga-tiga laluan boleh dipandu sampai
pra-serah dan gerbang menyekat. Untuk C3, lookup MySIKAP dijalankan
LANGSUNG, jadi identiti sebenar memang muncul pada borang — itu
laluan yang langkah (b) akan guna.

Untuk langkah (b), identiti dibaca dari fail izin (digitignore),
bukan dari repo.

    python devtools/fasa_c_praserah.py
"""

import argparse
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
AKAR = os.path.dirname(HERE)
sys.path.insert(0, AKAR)

from guard.gerbang_serah import (Izin, SerahTidakDiizinkan,   # noqa: E402
                                 diagnosis, semak)
from guard import sahkan_manual                               # noqa: E402
from pages import printer_tsc                                 # noqa: E402
from devtools import peringkat6 as P6                         # noqa: E402

DIR_BUKTI = os.path.join(AKAR, "docs", "demo-fasa-c", "praserah")
HASIL = []


def bukti(pages, tc, tag):
    os.makedirs(DIR_BUKTI, exist_ok=True)
    asas = os.path.join(DIR_BUKTI, f"{tc}-{tag}")
    drv = pages.daftar_kompaun.driver
    for ext, tulis in ((".png", lambda p: drv.get_screenshot_as_file(p)),
                       (".xml", None)):
        try:
            if ext == ".png":
                tulis(asas + ext)
            else:
                with open(asas + ext, "w", encoding="utf-8") as fh:
                    fh.write(drv.page_source)
        except Exception:                                     # noqa: BLE001
            pass
    print(f"    [BUKTI] {tc}-{tag}")


def titik_serah(drv, izin, tc, set_id, ringkasan, pages):
    """Papar ringkasan, kemudian nilai gerbang. Mesti DISEKAT."""
    sahkan_manual.papar_ringkasan(ringkasan)
    bukti(pages, tc, "04-ringkasan-pra-serah")
    print(f"\n  -- {tc}: TITIK SERAH — gerbang dinilai pada peranti --")
    try:
        semak(izin, set_id, 0)
    except SerahTidakDiizinkan as e:
        baris1 = str(e).splitlines()[0]
        print("  [PRA-SERAH] serah_mungkin=False -> berhenti di "
              "ringkasan, back out")
        print(f"  [GERBANG] {baris1}")
        P6._catat_ledger(drv, f"praserah-{tc}-gerbang-menyekat", baris1)
        bukti(pages, tc, "05-gerbang-menyekat")
        return True
    print("  !!! GERBANG LULUS — TIDAK DIJANGKA. HENTI.")
    bukti(pages, tc, "05-GERBANG-TIDAK-MENYEKAT")
    return False


# ---------------------------------------------------------------------------
# C1 — Notis Amaran
# ---------------------------------------------------------------------------
def c1_notis(drv, pages, izin, serial, baseline):
    from devtools.smoke_tangga import pastikan_di_home
    from testdata import oracle_n001 as O
    tc = "C1-N-001"
    print(f"\n{'=' * 68}\n== {tc} — Notis Amaran\n{'=' * 68}")
    P6.relaunch(drv, pages, f"{tc}: borang bersih")
    if not pastikan_di_home(drv, pages):
        return _gagal(tc, "tidak sampai skrin utama", serial, baseline)

    p = pages.notis_amaran
    pages.home.open_notis_amaran()
    bukti(pages, tc, "01-borang-dibuka")
    p.fill_pesalah_tab(O.SEMUA)
    bukti(pages, tc, "02-pesalah-diisi")
    p.click_seterusnya_from_pesalah()
    p.fill_notis_tab(O.SEMUA)
    p.fill_kompaun_code_fields(O.SEMUA)
    bukti(pages, tc, "03-tiga-dropdown")

    ringkasan = {
        "TC": tc, "borang": "Notis Amaran",
        "kod_kompaun": O.SEMUA["keterangan_kod_kompaun"],
        "akta": O.SEMUA["kod_akta"],
        "kesalahan": O.SEMUA["kesalahan_kompaun"][:60] + "...",
        "identiti": "langkah (b): dari fail izin (MySIKAP JYX6605)",
        "penanda": "UJIANAUTO",
        "AMARAN": "inilah yang AKAN diserah kalau Fasa C hidup",
    }
    ok = titik_serah(drv, izin, tc, "C1-N-001", ringkasan, pages)
    return _tutup(tc, ok, pages, serial, baseline)


# ---------------------------------------------------------------------------
# C2 — Kompaun Pelbagai
# ---------------------------------------------------------------------------
def c2_pelbagai(drv, pages, izin, serial, baseline):
    from devtools.smoke_tangga import pastikan_di_home
    from tests.sweep_kongsi import sedia_borang_kompaun
    from testdata import oracle_pk as OPK
    tc = "C2-P-001"
    print(f"\n{'=' * 68}\n== {tc} — Kompaun Pelbagai\n{'=' * 68}")
    P6.relaunch(drv, pages, f"{tc}: borang bersih")
    if not pastikan_di_home(drv, pages):
        return _gagal(tc, "tidak sampai skrin utama", serial, baseline)

    P6._pakai_sauh_alamat(serial, OPK.P001, OPK.K001)
    sedia_borang_kompaun(pages, "Kompaun Pelbagai")
    bukti(pages, tc, "02-pesalah-diisi")
    p = pages.daftar_kompaun
    p.fill_kompaun_code_fields(OPK.P001)
    bukti(pages, tc, "03-tiga-dropdown")

    ringkasan = {
        "TC": tc, "borang": "Kompaun Pelbagai",
        "kod_kompaun": OPK.P001["keterangan_kod_kompaun"],
        "akta": OPK.P001["kod_akta"],
        "kesalahan": OPK.P001["kesalahan_kompaun"][:60] + "...",
        "identiti": "langkah (b): dari fail izin (MySIKAP JYX6605)",
        "penanda": "UJIANAUTO",
        "AMARAN": "inilah yang AKAN diserah kalau Fasa C hidup",
    }
    ok = titik_serah(drv, izin, tc, "C2-P-001", ringkasan, pages)
    return _tutup(tc, ok, pages, serial, baseline)


# ---------------------------------------------------------------------------
# C3 — Letak Kereta + MySIKAP
# ---------------------------------------------------------------------------
def c3_letak_kereta(drv, pages, izin, serial, baseline):
    from devtools.smoke_tangga import pastikan_di_home
    from testdata import oracle_pk as OPK
    tc = "C3-K-001"
    print(f"\n{'=' * 68}\n== {tc} — Letak Kereta (MySIKAP)\n{'=' * 68}")
    P6.relaunch(drv, pages, f"{tc}: borang bersih")
    if not pastikan_di_home(drv, pages):
        return _gagal(tc, "tidak sampai skrin utama", serial, baseline)

    p = pages.daftar_kompaun
    pages.home.open_daftar_kompaun()
    p.select_jenis_kompaun_letak_kereta()
    bukti(pages, tc, "01-borang-dibuka")

    plat = OPK.K001["no_kereta"]
    if not P6._isi_medan_tepat(p, "No. Kereta", plat):
        return _gagal(tc, "medan No. Kereta tidak dijumpai", serial,
                      baseline)
    try:
        p.driver.hide_keyboard()
        time.sleep(0.4)
        p.wait_and_tap(p.TAB_PESALAH)
        time.sleep(1.2)
    except Exception:                                         # noqa: BLE001
        pass

    # MySIKAP: tekan-tahan ImageView jiran ePBT. ePBT TIDAK ditekan.
    ms = P6._cari_mysikap(p)
    nota_ms = "MySIKAP tidak dijumpai"
    if ms:
        sebelum = P6._snapshot_medan(p)
        drv.execute_script("mobile: longClickGesture",
                           {"x": ms[0], "y": ms[1], "duration": 1200})
        P6._catat_ledger(drv, "praserah-mysikap-longpress",
                         f"{tc}: plat {plat} @ {ms[0]},{ms[1]}")
        tamat = time.time() + 45
        while time.time() < tamat:
            time.sleep(3)
            if P6._beza_medan(sebelum, P6._snapshot_medan(p)):
                break
        beza = P6._redact_pii(P6._beza_medan(sebelum,
                                             P6._snapshot_medan(p)))
        nota_ms = f"auto-isi: {beza}" if beza else "TIADA kesan"
    print(f"    MySIKAP: {nota_ms}")
    bukti(pages, tc, "02-mysikap-auto-isi")

    try:
        p.wait_and_tap(p.TAB_KOMPAUN)
        time.sleep(1.5)
        p.fill_kompaun_tab(OPK.K001)
        p.fill_kompaun_code_fields(OPK.K001)
    except Exception as e:                                    # noqa: BLE001
        print(f"    tab Kompaun: {type(e).__name__}: {str(e)[:120]}")
    bukti(pages, tc, "03-tiga-dropdown")

    ringkasan = {
        "TC": tc, "borang": "Letak Kereta",
        "plat": plat,
        "kod_kompaun": OPK.K001["keterangan_kod_kompaun"],
        "akta": OPK.K001["kod_akta"],
        "kesalahan": OPK.K001["kesalahan_kompaun"][:60] + "...",
        "identiti": f"MySIKAP langsung — {nota_ms}",
        "penanda": "UJIANAUTO",
        "AMARAN": "inilah yang AKAN diserah kalau Fasa C hidup",
    }
    ok = titik_serah(drv, izin, tc, "C3-K-001", ringkasan, pages)
    return _tutup(tc, ok, pages, serial, baseline)


# ---------------------------------------------------------------------------
def _gagal(tc, sebab, serial, baseline):
    HASIL.append((tc, "GAGAL", sebab))
    print(f"  [GAGAL] {tc}: {sebab}")
    return P6.post_check(serial, baseline, tc)


def _tutup(tc, gerbang_ok, pages, serial, baseline):
    print(f"\n  -- {tc}: BACK OUT tanpa serah --")
    P6._keluar_ke_home(pages, tc)
    bukti(pages, tc, "06-back-out")
    bersih = P6.post_check(serial, baseline, tc)
    HASIL.append((tc, "OK" if (gerbang_ok and bersih) else "PERHATIAN",
                  f"gerbang={'SEKAT' if gerbang_ok else 'TIDAK SEKAT'} "
                  f"post-check={'bersih' if bersih else 'GAGAL'}"))
    return bersih and gerbang_ok


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--hanya", default=None, help="C1 / C2 / C3")
    a = ap.parse_args()

    from device_utils import resolve_udid
    from config import APP_PACKAGE
    from devtools.smoke_tangga import peringkat_1, peringkat_2

    print("=" * 70)
    print("== FASA C LANGKAH (a) — VALIDASI PRA-SERAH, SIFAR REKOD")
    print("=" * 70)

    izin = Izin.dari_persekitaran(AKAR)
    d = diagnosis(izin)
    for k, v in d.items():
        print(f"  [{'OK ' if v is True else 'KUNCI'}] {k:<28} = {v}")
    if d["serah_mungkin"]:
        print("\nHENTI: serah_mungkin=True. Langkah (a) menuntut gerbang "
              "KEKAL terkunci — ia tidak boleh mencipta rekod.")
        return 1
    printer_tsc.sahkan_terkunci()
    print("  printer TERKUNCI. serah_mungkin=False.\n")

    serial = resolve_udid(APP_PACKAGE, verbose=False)
    p1 = peringkat_1(serial)
    if not p1["ok"]:
        return 1
    baseline = p1["baseline"]
    P6.baseline_global = baseline

    drv = pages = None
    try:
        drv, pages = peringkat_2()
        pilih = (a.hanya or "C1,C2,C3").upper()
        if "C1" in pilih:
            c1_notis(drv, pages, izin, serial, baseline)
        if "C2" in pilih:
            c2_pelbagai(drv, pages, izin, serial, baseline)
        if "C3" in pilih:
            c3_letak_kereta(drv, pages, izin, serial, baseline)

        # Payload cetak — DIBINA, TIDAK DICETAK.
        contoh = {
            "pbt": "MBPG", "no_rekod": "(belum wujud — langkah b)",
            "tarikh": time.strftime("%d/%m/%Y"),
            "kod_kompaun": "KOMPAUN PELBAGAI JP",
            "akta": "UNDANG-UNDANG KECIL VANDALISME (MPPG) 2011",
            "kesalahan": "MEMBUAT APA-APA YANG BOLEH MENYEBABKAN "
                         "KEROSAKAN HARTA MPPG.",
            "denda": "1000", "nama_pesalah": "(dari fail izin)",
            "no_kp": "(dari fail izin)", "lokasi": "UJIANAUTO",
        }
        laluan_payload = os.path.join(DIR_BUKTI, "contoh-payload-resit.txt")
        os.makedirs(DIR_BUKTI, exist_ok=True)
        with open(laluan_payload, "w", encoding="utf-8") as fh:
            fh.write(printer_tsc.payload_teks(contoh))
        print(f"\n  payload resit CONTOH ditulis (TIDAK dicetak): "
              f"{laluan_payload}")

        print("\n" + "=" * 70)
        print("== RINGKASAN LANGKAH (a)")
        print("=" * 70)
        for tc, status, nota in HASIL:
            print(f"  {status:<10} {tc:<12} {nota}")
        akhir = diagnosis(Izin.dari_persekitaran(AKAR))
        print(f"\n  serah_mungkin selepas: {akhir['serah_mungkin']}")
        return 0
    finally:
        if drv is not None:
            c = getattr(drv, "corong", None)
            if c is not None:
                print(f"\n  [CORONG] {c.bil_tap} tap dinilai, "
                      f"{c.bil_sekat} disekat"
                      + (f" | DIBATALKAN: {c.dibatalkan}"
                         if c.dibatalkan else ""))
            try:
                drv.quit()
            except Exception:                                 # noqa: BLE001
                pass


if __name__ == "__main__":
    sys.exit(main())

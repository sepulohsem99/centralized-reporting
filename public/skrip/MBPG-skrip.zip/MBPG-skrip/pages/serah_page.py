"""
LAMPIRAN (clip-icon attachment) page — Page Object Model.

>>> FAIL INI TIDAK MENGUJI "SERAH". IA MENGUJI LAMPIRAN GAMBAR. <<<
Nama `serah_page.py` / `SerahPage` dikekalkan kerana ia sepadan dengan port
MBIP dan dengan nama TC dalam indeks `List to Test`. Nama itu SALAH LABEL,
dan salah label itu datang dari workbook, bukan dari kita.

Bukti (semua LIMA sheet `-003`, MBJB V2.1.33 — N-003, P-003, K-003, L-003,
S-003):
    C4  Objektif   : "Verify if that the user can attach picture"
    C10 Test Steps : "Click on the clip icon for take picture"
    C11 Dijangka   : aplikasi menerima lampiran itu

Tiada satu pun daripada lima sheet itu menyebut serahan, penerima, tanda
tangan, atau MENYERAHKAN. Suite MBIP membuat pilihan yang sama dan atas
sebab yang sama (`recon/PAPAN.md` §6, azharMadi: "MBJB `-003` ialah
LAMPIRAN, bukan Serah; indeks `List to Test` tersalah").

Akibat yang MESTI dihormati oleh sesiapa yang membaca hasilnya: `-003` yang
LULUS membuktikan **lampiran gambar diterima** dan TIDAK membuktikan
apa-apa tentang aliran Serah. Laporan yang berkata "Serah LULUS" atas dasar
TC ini menyatakan sesuatu yang tidak pernah diuji. Nama boleh kekal; dakwaan
tidak boleh.

PORT MBJB
---------
# SAHKAN-DEVICE / RISIKO DIKETAHUI: Excel MBPG-TC-N-003 C12 merekod
# "when selecting from gallery, popup shows 'Galeri Ralat'". Laluan
# GALERI ROSAK pada 2.1.33. Aliran ini kekal pada laluan KAMERA sahaja --
# jangan tukar kepada pemilih galeri walaupun DEV FIXING LIST baris 63
# menyatakan ciri pilih-dari-galeri telah ditambah pada APK 2.1.22.

Covers MBPG-TC-N/P/K/L/S-003: "Verify if that the user can attach
picture (lampiran)" — "Click on the clip icon for take picture";
expected: the application accepts the attachment.

FLOW — fully confirmed live (2026-07-17, location provided by the user,
locators from ui_dumps/lampiran_popup_bottom.xml, acceptance evidence
from ui_dumps/lampiran_cam_postsnap.*):
  1. Senarai -> tap the jenis' record row -> "KEMASKINI DATA" popup.
  2. The LAMPIRAN row sits below the popup's fold (past KADAR/GAMBAR/
     MAKLUMAT PENGUATKUASA/TANDA TANGAN, just above the pinned
     KEMASKINI/CETAK buttons). This popup's content is TextViews, so
     PLAIN swipes scroll it (unlike the EditText-heavy notice popup).
  3. The paperclip is a clickable ViewGroup with content-desc U+F0C6
     right after the "LAMPIRAN" label.
  4. Tapping it opens the in-app camera (FLASH OFF indicator, shutter
     U+F1BA — same component as the form camera) which AUTO-CLOSES
     after the capture settles; no tick-confirm exists in this variant
     (U+F1FD is absent; U+F353 is the gallery option).
  5. Acceptance evidence: back on the popup, the LAMPIRAN row gains a
     photo-thumbnail — a new clickable ViewGroup following the
     LAMPIRAN label (count increases by one).
"""

from appium.webdriver.common.appiumby import AppiumBy
from selenium.common.exceptions import TimeoutException
from pages.base_page import BasePage
from pages.daftar_kompaun_page import DaftarKompaunPage

_CLIP = ""


class SerahPage(BasePage):
    """Record-popup LAMPIRAN (clip-icon) attachment flow.

    Kelas ini menguji LAMPIRAN GAMBAR, bukan Serah — lihat docstring modul.
    """

    LAMPIRAN_LABEL = (AppiumBy.ANDROID_UIAUTOMATOR,
                      'new UiSelector().textMatches("(?i)\s*LAMPIRAN\s*")')
    # Glif klip kertas = U+F0C6 (FontAwesome `fa-paperclip`), dibawa oleh
    # content-desc. DISAHKAN hadir dalam dump MBIP di mana baris LAMPIRAN
    # benar-benar dirender: mbip-testing/v3/ui_dumps/lampiran_popup_bottom.xml
    # dan lampiran_cam_postsnap.xml.
    #
    # Nota penting tentang encoding, supaya tiada sesiapa "membetulkan" nilai
    # ini kepada satah 15: app ini menggunakan DUA font ikon. Bar atas skrin
    # utama ialah MaterialCommunityIcons BAHARU (satah 15 — U+F042A printer,
    # U+F0453 segar, U+F0343 log keluar; ui_dumps/40_skrin_utama.xml),
    # manakala popup rekod menggunakan FontAwesome BMP (U+F0C6 klip,
    # U+F1BA pengatup kamera, U+F353 galeri). Kedua-duanya betul untuk
    # tempatnya masing-masing.
    #
    # PERANGKAP BERSEJARAH: tiga dump MBIP bernama `serah_*_clip_not_found`
    # kelihatan seperti glif salah, tetapi ketiga-tiganya menunjukkan popup
    # pada KEDUDUKAN ATAS — tiada 'LAMPIRAN' langsung dalam pokok. Puncanya
    # ialah skrol, bukan locator. `_scroll_popup_to_lampiran()` kini menuntut
    # baris itu KELIHATAN PENUH sebelum meneruskan; jangan tukar glif ini
    # untuk mengejar gejala itu.
    # SAHKAN-DEVICE: belum dilihat pada MBJB 2.1.33 (tiada rekod pernah
    # dicipta, jadi popup rekod belum pernah dibuka di sini).
    CLIP_ICON = (AppiumBy.ACCESSIBILITY_ID, _CLIP)
    POPUP_TITLE = (AppiumBy.ANDROID_UIAUTOMATOR,
                   'new UiSelector().textMatches("(?i)\s*KEMASKINI\s+DATA\s*")')
    POPUP_X = (AppiumBy.ACCESSIBILITY_ID, "✕")
    # Photo thumbnails are clickable ViewGroups with an EMPTY
    # content-desc (all other popup clickables carry one: X, the clip
    # glyph, KEMASKINI, CETAK). NOTE: XPath `following::` queries return
    # nothing on this driver (confirmed live), hence UiSelector.
    DESCLESS_CLICKABLES = (AppiumBy.ANDROID_UIAUTOMATOR,
                           'new UiSelector().className('
                           '"android.view.ViewGroup").clickable(true)'
                           '.descriptionMatches("^$")')

    def _dump(self, name):
        try:
            import os
            os.makedirs("ui_dumps", exist_ok=True)
            path = os.path.join("ui_dumps", name)
            with open(path, "w", encoding="utf-8") as f:
                f.write(self.driver.page_source)
            print(f"  [SERAH] DEBUG: page source dumped to {path}")
            return path
        except Exception:
            return "(dump failed)"

    def _scroll_popup_to_lampiran(self):
        """Swipe the popup content down until the LAMPIRAN row is FULLY
        in view (content rows are TextViews, so plain swipes are not
        swallowed). Merely present is not enough -- confirmed live: the
        label can first appear as a ~26px sliver at the viewport edge,
        making every row measurement useless.

        PERATURAN KERAS #3 (kelas kecacatan yang sama seperti C-7 dalam
        senarai_page): versi lama menghardkod `swipe(540, 1750 -> 600)`
        dan sempadan "kelihatan penuh" `< 2020`. `540` mengandaikan lebar
        1080px dan `2020`/`1750` mengandaikan satu ketinggian tertentu —
        nilai MBIP, sedangkan peranti MBJB ialah Ulefone Armor 27 yang
        resolusinya BELUM disahkan. Pada peranti lain sapuan mendarat di
        luar popup (tiada pergerakan -> "LAMPIRAN row never rendered")
        atau sempadan 2020 menerima label yang sebenarnya terpotong.
        Semuanya kini diderivasi daripada driver.get_window_size()."""
        import time

        # >>> DIBETULKAN 2026-08-04 — DIUKUR, bukan diteka. <<<
        #
        # Bentuk lama mengira sapuan daripada geometri SKRIN:
        #     swipe(x, height*0.83  ->  x, height*0.29)
        # dan sempadan "kelihatan penuh" daripada `wh * 0.96`.
        #
        # Ukuran pada Ulefone Armor 27 (2026-08-04):
        #     get_window_size()  = {'width': 1080, 'height': 2460}
        #     0.83 * 2460        = 2041
        #     ScrollView popup   = [99,399][981,2022]      dasar = 2022
        # Sapuan bermula **19px DI BAWAH dasar ScrollView**, iaitu atas
        # baris butang KEMASKINI/CETAK. ScrollView itu tidak pernah
        # menerima sapuan langsung. Pecahan 0.83/0.96 diwarisi daripada
        # peranti dengan ketinggian LAIN.
        #
        # Puncanya bukan nilai 0.83 — puncanya mengira sapuan daripada
        # geometri SKRIN dan bukan daripada bounds elemen yang hendak
        # diskrol. Prinsip yang sama seperti
        # `base_page._tutup_modal_rn_melalui_backdrop()`, yang mengira
        # titik ketukan daripada bounds panel sebenar dan bukan pecahan
        # skrin. `base_page._kira_swipe()` sudah bounds-first; guna ia.
        def _bekas():
            """Bekas boleh-skrol popup, atau None."""
            from config import IMPLICIT_WAIT
            self.driver.implicitly_wait(0)
            try:
                for el in self.driver.find_elements(
                        AppiumBy.CLASS_NAME, "android.widget.ScrollView"):
                    try:
                        if el.rect["height"] > 200:
                            return el
                    except Exception:                        # noqa: BLE001
                        continue
                return None
            finally:
                self.driver.implicitly_wait(IMPLICIT_WAIT)

        def _fully_visible():
            """LAMPIRAN kelihatan PENUH di dalam bekas boleh-skrolnya.

            Sempadan diambil daripada dasar BEKAS, bukan 96% ketinggian
            skrin: satu baris boleh berada di bawah 96% skrin tetapi
            tetap terpotong oleh dasar ScrollView yang jauh lebih tinggi.
            """
            try:
                r = self.driver.find_element(*self.LAMPIRAN_LABEL).rect
                if r["height"] < 60:
                    return False
                c = _bekas()
                if c is None:
                    return True          # tiada bekas -> ketinggian sahaja
                cr = c.rect
                return (r["y"] + r["height"]) <= (cr["y"] + cr["height"])
            except Exception:                                # noqa: BLE001
                return False

        for _ in range(12):
            if self.is_element_present(self.LAMPIRAN_LABEL, timeout=2) \
                    and _fully_visible():
                return True
            try:
                x1, y1, x2, y2, ms = self._kira_swipe(
                    _bekas(), "down", None)
                self.driver.swipe(x1, y1, x2, y2, ms)
                time.sleep(0.8)
            except Exception:                                # noqa: BLE001
                break
        return self.is_element_present(self.LAMPIRAN_LABEL, timeout=2)

    def _lapor_calon_klip(self):
        """Cetak setiap elemen boleh-ketuk yang bertindih dengan baris
        LAMPIRAN, bersama content-desc mentahnya sebagai titik kod.

        Ia MELAPORKAN sahaja — ia tidak pernah mengetuk apa-apa dan tidak
        pernah memilih pengganti. Sebabnya: kalau glif klip MBJB berbeza,
        satu run mesti memberitahu kita NILAI SEBENARNYA supaya ia boleh
        direkod dengan sumber (R5). Mengetuk "apa-apa yang boleh diketuk
        berhampiran LAMPIRAN" akan membuka entah apa — galeri, thumbnail,
        atau baris jiran — dan melaporkannya sebagai lampiran berjaya.
        Meneka locator lebih teruk daripada gagal dengan jelas."""
        try:
            r = self.driver.find_element(*self.LAMPIRAN_LABEL).rect
            y0, y1 = r["y"], r["y"] + r["height"]
        except Exception:                                    # noqa: BLE001
            print("  [LAMPIRAN] baris LAMPIRAN tidak boleh diukur — tiada "
                  "calon boleh disenaraikan")
            return []
        calon = []
        try:
            els = self.driver.find_elements(
                AppiumBy.ANDROID_UIAUTOMATOR,
                'new UiSelector().clickable(true)')
        except Exception:                                    # noqa: BLE001
            els = []
        for el in els:
            try:
                er = el.rect
                if er["y"] >= y1 or er["y"] + er["height"] <= y0:
                    continue
                desc = el.get_attribute("content-desc") or ""
                kod = " ".join(f"U+{ord(c):04X}" for c in desc) or "(kosong)"
                calon.append((desc, kod, er))
            except Exception:                                # noqa: BLE001
                continue
        print(f"  [LAMPIRAN] {len(calon)} elemen boleh-ketuk bertindih "
              f"dengan baris LAMPIRAN:")
        for desc, kod, er in calon:
            print(f"    desc={desc!r}  titik kod={kod}  "
                  f"@ ({er['x']},{er['y']}) {er['width']}x{er['height']}")
        if not calon:
            print("    (tiada) — popup berkemungkinan tidak dirender "
                  "sepenuhnya pada kedudukan skrol ini")
        return calon

    def _lampiran_state(self):
        """(thumbnails-in-row count, LAMPIRAN label height). Thumbnails
        = descless clickable ViewGroups whose bounds vertically
        intersect the LAMPIRAN label's row -- a GLOBAL descless count is
        viewport-dependent (the record's GAMBAR photo box drifts in and
        out of the rendered tree between measurements; bit us live).
        Both metrics grow when an attachment lands (label 76->390px on
        the first photo; +1 thumbnail every time)."""
        height = 0
        y0 = y1 = None
        try:
            r = self.driver.find_element(*self.LAMPIRAN_LABEL).rect
            height = r["height"]
            y0, y1 = r["y"], r["y"] + r["height"]
        except Exception:
            pass
        count = 0
        thumb_hash = None
        if y0 is not None:
            try:
                for el in self.driver.find_elements(
                        *self.DESCLESS_CLICKABLES):
                    er = el.rect
                    ey0, ey1 = er["y"], er["y"] + er["height"]
                    if ey0 < y1 and ey1 > y0:  # vertical overlap
                        count += 1
                        if thumb_hash is None:
                            # The row holds exactly ONE photo -- a new
                            # attachment REPLACES the previous one
                            # (confirmed live: count/height flat on an
                            # already-attached record). The thumbnail's
                            # PIXELS are the only change then.
                            try:
                                import hashlib
                                png = el.screenshot_as_base64
                                thumb_hash = hashlib.md5(
                                    png.encode()).hexdigest()
                            except Exception:
                                pass
            except Exception:
                pass
        return count, height, thumb_hash

    def attach_lampiran(self, jenis_letter):
        """On the already-open KEMASKINI DATA popup: scroll to the
        LAMPIRAN row, tap the paperclip, take a photo, and assert the
        attachment registered (thumbnail added). Closes the popup on
        success.

        # SAHKAN-DEVICE: popup ini MESTI sudah dibuka melalui
        # senarai.open_record_by_number(no) + record_popup_shows_number(no)
        # — aliran -003 bergantung sepenuhnya pada rantaian by-number, dan
        # rantaian itu bergantung pada config.RECORD_PREFIX (`JB015`,
        # BELUM DISAHKAN; tiada rekod pernah dicipta pada device ini).
        # Kaedah ini TIDAK boleh mengesahkan rekod mana yang terbuka; ia
        # bertindak pada popup yang diberi. Pemanggil yang memikul
        # tanggungjawab itu."""
        import time
        assert self.is_element_present(self.POPUP_TITLE, timeout=8), \
            "KEMASKINI DATA popup not open"

        if not self._scroll_popup_to_lampiran():
            path = self._dump(f"serah_{jenis_letter}_no_lampiran_row.xml")
            raise TimeoutException(
                f"LAMPIRAN row never rendered in the record popup; "
                f"see {path}")
        print("  [SERAH] LAMPIRAN row visible")

        before_count, before_height, before_hash = self._lampiran_state()
        print(f"  [SERAH] baseline: thumbnails={before_count}, row "
              f"height={before_height}, thumb hash={before_hash}")

        # Tap the paperclip (verified: the in-app camera must open).
        if not self.is_element_present(self.CLIP_ICON, timeout=5):
            self._lapor_calon_klip()
            path = self._dump(f"serah_{jenis_letter}_clip_not_found.xml")
            raise TimeoutException(
                f"ikon klip (content-desc U+F0C6) TIDAK dijumpai walaupun "
                f"baris LAMPIRAN kelihatan penuh. Baca senarai calon yang "
                f"baru dicetak SEBELUM menukar glif: kalau senarai itu "
                f"kosong, popup tidak dirender sepenuhnya (masalah skrol); "
                f"kalau ia mengandungi satu content-desc lain, ITULAH glif "
                f"MBJB dan ia perlu direkod, bukan diteka. Lihat {path}")

        opened = False
        for attempt in range(3):
            el = self.find_element(self.CLIP_ICON, timeout=5)
            self.tap_element(el)
            time.sleep(2)
            if self.is_element_present(
                    DaftarKompaunPage.CAMERA_OPEN_INDICATOR, timeout=4):
                opened = True
                break
            print(f"  [SERAH] camera didn't open (attempt "
                  f"{attempt + 1}/3) -- re-tapping the clip...")
        if not opened:
            path = self._dump(f"serah_{jenis_letter}_camera_never_opened.xml")
            raise TimeoutException(
                f"camera never opened after tapping the paperclip; "
                f"see {path}")
        print("  [SERAH] camera open — snapping...")

        # One shutter tap; THIS camera variant auto-closes once the
        # capture settles (confirmed live: no tick-confirm exists).
        self.wait_and_click(DaftarKompaunPage.BUTTON_SNAP)
        deadline = time.monotonic() + 20
        while time.monotonic() < deadline:
            if not self.is_element_present(
                    DaftarKompaunPage.CAMERA_OPEN_INDICATOR, timeout=2):
                break
            time.sleep(1)
        else:
            # Shouldn't happen per recon; close via the camera's X as a
            # last resort so the run isn't stranded inside the camera.
            print("  [SERAH] WARNING: camera did not auto-close -- "
                  "closing via its X")
            try:
                x = (AppiumBy.ANDROID_UIAUTOMATOR,
                     'new UiSelector().description("✕")')
                el = self.find_element(x, timeout=4)
                self.tap_element(el)
            except Exception:
                self.press_back()
            time.sleep(1)
        print("  [SERAH] camera closed")

        self.dismiss_native_alerts(first_timeout=3, context="lampiran")
        time.sleep(1)

        # Acceptance: the LAMPIRAN row must have gained a thumbnail.
        assert self.is_element_present(self.POPUP_TITLE, timeout=8), \
            "record popup did not come back after the camera"
        if not self.is_element_present(self.LAMPIRAN_LABEL, timeout=3):
            self._scroll_popup_to_lampiran()
        after_count, after_height, after_hash = self._lampiran_state()
        print(f"  [SERAH] after: thumbnails={after_count}, row "
              f"height={after_height}, thumb hash={after_hash}")
        replaced = (before_hash is not None and after_hash is not None
                    and after_hash != before_hash)
        if not (after_count > before_count
                or after_height > before_height + 40
                or replaced):
            path = self._dump(f"serah_{jenis_letter}_not_registered.xml")
            raise AssertionError(
                f"attachment did not register: thumbnails "
                f"{before_count}->{after_count}, row height "
                f"{before_height}->{after_height}, thumbnail pixels "
                f"unchanged; see {path}")
        evidence = ("new thumbnail" if after_count > before_count
                    or after_height > before_height + 40
                    else "thumbnail replaced (pixels changed)")
        print(f"  [SERAH] Attachment accepted ({evidence}) — PASS")

        # Close the popup cleanly.
        #
        # >>> FIX #11 — DITAMBAH 2026-10-05 (run10, build 2.1.25). <<<
        # tap_element(X) = tap KOORDINAT. Ikon X ialah ViewGroup
        # clickable="false" (forensik 20261005-111805__tiada__KEMASKINI
        # .xml, bounds [891,248][981,338]) dan TextView tajuk popup
        # "KEMASKINI DATA" ([99,248][981,313]) BERTINDIH dengannya, jadi
        # teks_di_koordinat() panjat ke bekas clickable terdekat dan
        # memungut ['✕', 'KEMASKINI DATA'] -> trip-wire KEMASKINI ->
        # DryRunViolation -> SELURUH run dibatalkan, walaupun lampiran
        # SUDAH diterima (PASS dicetak di atas) dan tap itu cuma menutup
        # tingkap. el.click() dinilai corong melalui teks_elemen(): laluan
        # pantas membaca content-desc elemen sendiri = ['✕'] sahaja.
        # Fallback: backdrop RN (terbukti pada popup CETAK/Menu Selaras),
        # kemudian BACK. Gagal menutup TIDAK fatal -- peringkat P-001
        # seterusnya relaunch app. guard/ TIDAK disentuh.
        tertutup = False
        try:
            el = self.find_element(self.POPUP_X, timeout=4)
            el.click()
            tertutup = not self.is_element_present(self.POPUP_TITLE,
                                                   timeout=3)
            print(f"  [SERAH] tutup popup via X (el.click): "
                  f"{'DISAHKAN tertutup' if tertutup else 'masih ada'}")
        except Exception as e:                                # noqa: BLE001
            print(f"  [SERAH] X (el.click) gagal: {type(e).__name__}: {e}")
        if not tertutup:
            try:
                tertutup = bool(self._tutup_modal_rn_melalui_backdrop())
            except Exception as e:                            # noqa: BLE001
                print(f"  [SERAH] backdrop gagal: {type(e).__name__}: {e}")
        if not tertutup:
            self.press_back()
            tertutup = not self.is_element_present(self.POPUP_TITLE,
                                                   timeout=3)
            print(f"  [SERAH] tutup popup via BACK: "
                  f"{'DISAHKAN tertutup' if tertutup else 'MASIH ADA (tidak fatal)'}")
        return True

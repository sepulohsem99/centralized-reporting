"""
Daftar Kompaun (Kompaun Lesen) page — Page Object Model. v3-new (Phase 2).

Subclasses DaftarKompaunPage: the Kompaun/Penerima tabs, kompaun-code
tiers, kadar denda, camera and submission handling are identical in
approach to the Pelbagai flow; only the jenis selection and the Pesalah
tab differ (extra "No Akuan Lesen" field, per sheet MBPG-TC-L-001).

The Lesen Pesalah tab has NOT been recon'd -- field labels are tried via
candidate ladders (exact label variants from the sheet's wording), with
a page-source dump on entry and on any miss (never guess silently).

PORT MBJB
---------
# SAHKAN-DEVICE: Excel MBPG-TC-L-001 C10 langkah 4 berbunyi "List out
# seized items and upload photo" -- iaitu seksyen BARANG-BARANG pada
# borang LESEN, yang MBIP hanya jumpa pada borang Sitaan. Perkataan
# langkah itu IDENTIK dengan MBPG-TC-S-001 C10, jadi ia mungkin
# salin-tampal dalam Excel dan bukan ciri sebenar. Sahkan pada device:
# kalau borang Lesen MBJB memang ada seksyen BARANG-BARANG, panggil
# SitaanPage.fill_barang_items() dari sini (ia diwarisi melalui rantaian
# kelas); kalau tidak, jangan tambah apa-apa dan laporkan percanggahan
# Excel itu kepada pemilik.
#
# SAHKAN-DEVICE: toggle Operasi (Training Feedback A7, DONE 2.1.5)
# dilaporkan wujud pada borang Kompaun Lesen DAN Kompaun Pelbagai.
# DaftarKompaunPage.toggle_operasi() diwarisi di sini -- sahkan borang
# mana benar-benar membawanya.
"""

from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
from pages.daftar_kompaun_page import DaftarKompaunPage


class KompaunLesenPage(DaftarKompaunPage):
    """Daftar Kompaun — jenis KOMPAUN LESEN."""

    # Tidak sensitif huruf: app MEMAKSA HURUF BESAR (fasa2-bootstrap §2.4)
    # dan text() PEKA huruf. Padanan TEPAT dikekalkan supaya ia tidak
    # tersasar kepada 'KOMPAUN LESEN ...' yang lebih panjang.
    # SAHKAN-DEVICE: popup PILIH KOMPAUN MBJB belum di-dump; teks pilihan
    # 'KOMPAUN LESEN' diwarisi dari recon MBIP. Nota: 'KOMPAUN LESEN' juga
    # muncul sebagai nilai tingkat 1 dropdown kod
    # (ui_dumps\kesalahan_tier1_PENUH_v2.txt:7) — dua tempat berbeza, jangan
    # tersilap padan bila dialog dropdown terbuka.
    OPTION_KOMPAUN_LESEN = (AppiumBy.ANDROID_UIAUTOMATOR,
                            'new UiSelector().textMatches('
                            '"(?i)^\\s*kompaun\\s+lesen\\s*$")')

    def _dump(self, name):
        try:
            import os
            os.makedirs("ui_dumps", exist_ok=True)
            path = os.path.join("ui_dumps", name)
            with open(path, "w", encoding="utf-8") as f:
                f.write(self.driver.page_source)
            print(f"  [LESEN] DEBUG: page source dumped to {path}")
            return path
        except Exception:
            return "(dump failed)"

    def select_jenis_kompaun_lesen(self):
        """Select KOMPAUN LESEN from the jenis popup, with the same
        verified-tap protection as the Trafik variant.

        >>> DIBETULKAN: bukti POSITIF, bukan hanya bukti negatif. <<< Versi
        lama membina `nama_label` lalu `del nama_label` — locator itu tidak
        pernah digunakan, jadi satu-satunya bukti ialah "pilihan hilang".
        Pilihan boleh hilang kerana popup ditutup TANPA borang dibuka (cth
        alert asli beratur menelan tap — fasa2-bootstrap "PENEMUAN TEKNIKAL
        BAHARU" #2), dan itu akan dilaporkan sebagai PASS palsu. Sekarang
        kehadiran medan borang diterima dahulu; "pilihan hilang" hanya
        diterima bila borang juga muncul.
        """
        print("\n  [LESEN] Selecting jenis: Kompaun Lesen...")
        # SAHKAN-DEVICE: borang Kompaun Lesen MBJB belum pernah dibuka
        # (PAPAN.md §4), jadi label medan pertamanya BELUM DISAHKAN. Kedua
        # calon dicuba: 'NAMA PESALAH' (borang Notis Amaran, DISAHKAN) dan
        # 'NAMA PEMILIK/SYARIKAT' (recon Sitaan MBIP).
        bukti_borang = [self._ci_label_locator(self.LABEL_NAMA_PESALAH),
                        self._ci_label_locator("NAMA PEMILIK/SYARIKAT")]
        for attempt in range(3):
            self.wait_and_tap(self.OPTION_KOMPAUN_LESEN)
            import time
            time.sleep(1)
            self.drain_printer_alert()
            if any(self.is_element_present(loc, timeout=3)
                   for loc in bukti_borang):
                print("  [LESEN] Jenis Lesen selected — borang Pesalah "
                      "kelihatan — PASS")
                self._dump("lesen_pesalah_tab.xml")
                return
            if not self.is_element_present(self.OPTION_KOMPAUN_LESEN,
                                           timeout=3):
                print("  [LESEN] AMARAN: pilihan KOMPAUN LESEN hilang "
                      "tetapi tiada medan borang dikenali kelihatan — "
                      "meneruskan, dan kegagalan seterusnya akan "
                      "menunjukkan skrin sebenar (dump ditulis)")
                self._dump("lesen_pesalah_tab.xml")
                return
            print(f"  [LESEN] Jenis popup still open after tap "
                  f"(attempt {attempt + 1}/3) -- re-tapping...")
        self._dump("lesen_jenis_popup_stuck.xml")
        raise TimeoutException(
            "KOMPAUN LESEN option never registered a tap; see "
            "ui_dumps/lesen_jenis_popup_stuck.xml")

    def _fill_first_matching(self, candidates, value, optional=False,
                             use_mobile_type=False, _drained=False):
        """Fill the first field whose placeholder matches any candidate
        label (each tried with a short bounded lookup). Dump + raise on
        total miss unless optional.

        On a total miss, drains any native alert once and retries: this
        app raises alerts asynchronously (confirmed live on the Sitaan
        pesalah tab -- an "Error: Unable to connect device" alert pops
        ~1s after the form renders and covers every field, so the label
        lookups below find nothing). Draining reveals the form, per
        CLAUDE.md's dismiss-before-interaction rule.

        >>> DUA PEMBETULAN FAKTA DEVICE. <<<
        (1) Padanan DIHADKAN kepada android.widget.EditText. `text` sebuah
            EditText ialah PLACEHOLDER bila kosong (fasa2-bootstrap §2.4),
            jadi label dan medan boleh membawa teks yang SAMA. Locator lama
            (`_ci_label_locator`, tanpa kelas) boleh memulangkan TextView
            label; menaip ke dalamnya tidak berkesan dan kaedah ini akan
            mencetak "filled" — kejayaan PALSU. Borang Lesen belum di-dump
            (SAHKAN-DEVICE), jadi kemungkinan itu tidak boleh ditolak.
        (2) READ-BACK selepas menaip, dibandingkan TIDAK SENSITIF HURUF
            kerana app memaksa HURUF BESAR. Tanpa ini, taipan yang gagal
            secara senyap (RN re-render menelan kekunci — corak yang sama
            seperti fill_kadar_denda) dilaporkan sebagai berjaya.
        """
        for label in candidates:
            locator = (AppiumBy.ANDROID_UIAUTOMATOR,
                       f'new UiSelector().className("android.widget.EditText")'
                       f'.textMatches("(?i)^{self._regex_selamat(label)}$")')
            try:
                el = WebDriverWait(self.driver, 3).until(
                    EC.presence_of_element_located(locator))
            except TimeoutException:
                continue
            el.click()
            el.clear()
            # DIHALAKAN 2026-08-04: menduakan cabang _emit_text tanpa
            # fallback, dan memintas pengawal seaksara.
            self._emit_text(el, value, use_mobile_type)
            self._hide_keyboard_if_shown()
            got = self._safe_text(el)
            if got is not None and self._norm(got) != self._norm(value):
                print(f"  [LESEN] AMARAN: '{label}' menunjukkan {got!r} "
                      f"selepas menaip {value!r} — taipan TIDAK disahkan")
            else:
                print(f"  [LESEN] '{label}' filled (read-back {got!r})")
            return el
        if not _drained and self.drain_printer_alert():
            import time
            time.sleep(0.5)
            return self._fill_first_matching(candidates, value, optional,
                                             use_mobile_type, _drained=True)
        if optional:
            print(f"  [LESEN] WARNING: none of {candidates} found -- "
                  f"skipping (treated as optional)")
            return None
        path = self._dump("lesen_field_not_found.xml")
        raise TimeoutException(
            f"No field matched any of {candidates}; see {path}")

    def fill_pesalah_tab_lesen(self, data):
        """Fill the Lesen Pesalah tab per sheet MBPG-TC-L-001: nama,
        no K/P / SSM, no akuan lesen, then the address block (typed
        directly, same technique as the Pelbagai Pesalah tab)."""
        import time
        print("\n  [LESEN] Filling Pesalah tab (Lesen)...")
        time.sleep(1)
        # Drain the async "Unable to connect device" printer alert that
        # covers the Sitaan pesalah tab ~1s after it loads (counted globally
        # via drain_printer_alert; also handled centrally in find_element).
        self.drain_printer_alert()

        # >>> NAMA: Lesen/Sitaan guna `nama_pemilik_syarikat`. 2026-08-05. <<<
        # Oracle memberi `nama_pemilik_syarikat` untuk L-001 dan S-001
        # (sel: "Nama Pemilik/Syarikat"), BUKAN `nama_pesalah` — borang
        # ini memang tidak ada medan "pesalah". Selagi kedua-dua TC
        # SKIP, ketidakpadanan ini tidak pernah terserlah; ia meranap
        # dengan KeyError 'nama_pesalah' pada run 2026-08-05 sebaik
        # kedua-duanya dibuka.
        nama_pemilik = (data.get("nama_pemilik_syarikat")
                        or data.get("nama_pesalah"))
        assert nama_pemilik, (
            "borang Lesen/Sitaan perlukan nama_pemilik_syarikat (atau "
            "nama_pesalah); testdata tidak membekalkan satu pun")
        self._fill_first_matching(
            ["NAMA PESALAH", "NAMA PEMILIK/SYARIKAT",
             "NAMA PEMILIK / SYARIKAT", "NAMA PESALAH/SYARIKAT"],
            nama_pemilik)
        # Nama may be an autocomplete (sheet step 1: "Type and select
        # Nama Pemilik/Syarikat from the dropdown") -- if a suggestion
        # row rendered, pick the matching one; if none, typed text stays.
        row = (AppiumBy.ANDROID_UIAUTOMATOR,
               f'new UiSelector().className("android.widget.TextView")'
               f'.textContains("{nama_pemilik}")')
        if self.is_element_present(row, timeout=3):
            try:
                el = self.find_element(row, timeout=3)
                self.tap_element(el)
                print("  [LESEN] Picked nama suggestion row")
                time.sleep(1)
            except Exception:
                pass

        self._fill_first_matching(
            ["NO KP/ SSM/ NO KERETA", "NO K/P / SSM", "NO KP/SSM",
             "NO KP/ SSM"],
            data["no_kp_ssm"])
        self._fill_first_matching(
            # "NO AKAUN LESEN" (AKAUN, not AKUAN) is the on-screen label
            # confirmed via live recon of the Sitaan pesalah tab.
            ["NO AKAUN LESEN", "NO AKUAN LESEN", "NO. AKUAN LESEN",
             "NO LESEN"],
            data["no_akuan_lesen"], optional=True)

        # Blok alamat pada tab PESALAH: penulisan TANPA SYARAT adalah BETUL
        # di sini. Fakta device (ui_dumps\41_notis_amaran_borang.xml,
        # 46_borang_penuh.xml): pada tab PESALAH kelima-lima medan alamat
        # enabled="true". Yang DILUMPUHKAN ialah medan yang sama pada tab
        # NOTIS/KOMPAUN (dump 50) — di sana _if_editable digunakan.
        # SAHKAN-DEVICE: borang Kompaun Lesen MBJB belum dibuka, jadi
        # andaian "tab Pesalah Lesen berkelakuan seperti tab Pesalah Notis"
        # BELUM DISAHKAN.
        for label, key in ((self.LABEL_PESALAH_JALAN, "jalan"),
                           (self.LABEL_PESALAH_TAMAN, "taman"),
                           (self.LABEL_PESALAH_POSKOD, "poskod"),
                           (self.LABEL_PESALAH_BANDAR, "bandar"),
                           (self.LABEL_PESALAH_NEGERI, "negeri")):
            if label == self.LABEL_PESALAH_NEGERI:
                self._scroll_down()
            self.fill_field_by_label(label, data[key])

        print("  [LESEN] Pesalah tab (Lesen) filled — PASS")

"""
Page Object Model classes for KOMPAUN e-PBT (IES App).
"""
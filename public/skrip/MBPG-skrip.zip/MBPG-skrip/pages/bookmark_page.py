"""
Bookmark (Pilihan Kegemaran) flow — Page Object Model. v3-new (Phase 2).

Per the -005 sheets: on a kompaun form with the Kompaun section filled,
tap the book icon, name the bookmark, SIMPAN; then reopen the Pilihan
Kegemaran list, select the saved bookmark, and verify the fields
repopulate.

The book icon glyph is Material Icons U+E866 ("bookmark") -- confirmed
via live recon of the create form's Notis tab (recon_notistab_0.xml).
The bookmark popup itself has NOT been recon'd: this flow dumps page
source at each unknown step (same discipline as everywhere else).

PORT MBJB — SATU ANDAIAN MBIP DIBATALKAN DI SINI
------------------------------------------------
CLAUDE.md MBIP mengisytiharkan "UI simpan Bookmark tiada dalam build ini",
lalu menyekat kesemua TC -005. Andaian itu TIDAK terpakai pada MBJB
2.1.33: kelima-lima sheet MBPG-TC-N/P/K/L/S-005 memberi langkah lengkap
("Click on the book icon, enter bookmark name... click SIMPAN... Reopen
the Pilihan Kegemaran list"), data bookmark penuh dalam C9, dan Actual
Results yang menyebut auto-populate berjaya. DEV FIXING LIST baris 27
merekod pembaikan bookmark. Jadi aliran ini dijangka BOLEH dijalankan
pada MBJB dan TC -005 TIDAK boleh diskip atas alasan MBIP.

IKON BUKU — DISAHKAN PADA DEVICE MBJB (Loh, 2026-07-30)
-------------------------------------------------------
dump `ui_dumps\\50_selepas_seterusnya.xml` merakam tab NOTIS borang Notis
Amaran (tajuk skrin 'PAPARAN KOMPAUN') dan mengandungi
    <node text="\\ue866" class="android.widget.TextView" content-desc="" />
di bawah tajuk seksyen 'MAKLUMAT KESALAHAN', SEBELUM medan MAKLUMAT JALAN.
Jadi:
  * ikon buku U+E866 MEMANG WUJUD dalam build MBJB 2.1.33 — tidak seperti
    MBIP, di mana CLAUDE.md mengisytiharkan UI Bookmark tiada;
  * ia berada pada tab NOTIS / PAPARAN KOMPAUN, di ATAS borang (jadi
    _scroll_up() di bawah betul);
  * ia dirender sebagai `text`, dengan `content-desc` KOSONG -> calon
    ACCESSIBILITY_ID / description TIDAK akan padan. Urutan
    ICON_CANDIDATES disusun semula supaya calon `text` dicuba DAHULU;
    dua calon lain dikekalkan untuk varian skrin lain.
  * nod penuh: class='android.widget.TextView' bounds='[840,306][990,458]'
    **clickable="false"** -> `el.click()` pada nod ini TIDAK akan
    mendaftar apa-apa. Ketukan MESTI melalui `tap_element()` (tap
    koordinat mentah, yang mengenai bekas boleh-ketuk di atasnya) —
    itulah yang open_bookmark_popup() gunakan. Ini juga contoh terus
    BRIEF Seksyen 3 ("el.click() SENYAP tidak berkesan").

# SAHKAN-DEVICE: aliran penuh masih BELUM DISAHKAN pada MBJB — Loh belum
# mengetuk ikon ini pada device. Yang belum diketahui: (a) apa yang popup
# itu tawarkan (senarai PILIH/HAPUS sahaja seperti MBIP, atau medan nama +
# SIMPAN seperti yang dituntut sheet -005); (b) sama ada MBJB `-005` benar
# menuntut DUA bookmark seperti dilaporkan azharMadi (MBIP satu);
# (c) sama ada medan benar-benar terisi semula selepas dipilih.
# TIADA locator dipadam dan TIADA skip dicipta untuk menyembunyikan
# ketiadaannya — kalau UI itu tiada, kaedah di bawah melempar dengan
# diagnosis dan dump, dan TC gagal secara jujur.
"""

from appium.webdriver.common.appiumby import AppiumBy
from selenium.common.exceptions import TimeoutException
from pages.base_page import BasePage

_BOOK = ""


class BookmarkPage(BasePage):
    """Book icon -> save/select bookmark on a kompaun form."""

    # `text` DAHULU: pada device ikon ini ialah TextView dengan
    # content-desc KOSONG (dump ui_dumps\50_selepas_seterusnya.xml).
    ICON_CANDIDATES = [
        (AppiumBy.ANDROID_UIAUTOMATOR,
         f'new UiSelector().text("{_BOOK}")'),
        (AppiumBy.ACCESSIBILITY_ID, _BOOK),
        (AppiumBy.ANDROID_UIAUTOMATOR,
         f'new UiSelector().description("{_BOOK}")'),
    ]
    SIMPAN_LOCATORS = [
        (AppiumBy.ANDROID_UIAUTOMATOR,
         'new UiSelector().textMatches("(?i)\\s*simpan\\s*")'),
        (AppiumBy.ANDROID_UIAUTOMATOR,
         'new UiSelector().descriptionMatches("(?i)\\s*simpan\\s*")'),
    ]

    def _dump(self, name):
        try:
            import os
            os.makedirs("ui_dumps", exist_ok=True)
            path = os.path.join("ui_dumps", name)
            with open(path, "w", encoding="utf-8") as f:
                f.write(self.driver.page_source)
            print(f"  [BOOKMARK] DEBUG: page source dumped to {path}")
            return path
        except Exception:
            return "(dump failed)"

    def _scroll_up(self):
        """Scroll the form content UP (back toward the top). The book
        icon sits at the TOP of the Notis/Kompaun tab (confirmed via
        recon_notistab_0.xml), and after filling the kompaun codes the
        viewport is at the bottom -- confirmed live: the icon was
        'not found' until scrolling back up."""
        try:
            self._hide_keyboard_if_shown()
            size = self.driver.get_window_size()
            self.driver.execute_script('mobile: scrollGesture', {
                'left': int(size['width'] * 0.1),
                'top': int(size['height'] * 0.25),
                'width': int(size['width'] * 0.8),
                'height': int(size['height'] * 0.5),
                'direction': 'up',
                'percent': 0.8,
            })
            import time
            time.sleep(0.4)
            return True
        except Exception:
            return False

    def open_bookmark_popup(self):
        """Tap the book icon (verified: popup evidence = a new EditText
        count or a SIMPAN control appearing). Scrolls back to the top of
        the tab first if the icon isn't visible."""
        import time
        print("  [BOOKMARK] Opening the bookmark (book icon) popup...")
        icon = None
        for round_ in range(6):
            for loc in self.ICON_CANDIDATES:
                if self.is_element_present(loc, timeout=2):
                    icon = loc
                    break
            if icon is not None:
                break
            if not self._scroll_up():
                break
        if icon is None:
            path = self._dump("bookmark_icon_not_found.xml")
            raise TimeoutException(
                f"ikon buku U+E866 tidak dijumpai pada borang ini. Ia "
                f"DISAHKAN WUJUD dalam build MBJB 2.1.33 pada tab NOTIS / "
                f"'PAPARAN KOMPAUN' (ui_dumps\\50_selepas_seterusnya.xml), "
                f"jadi 'tidak dijumpai' bermakna tab yang SALAH atau skrol "
                f"belum kembali ke atas — bukan bukti ciri ini tiada; "
                f"lihat {path}")
        # Popup-open evidence: the PILIHAN KEGEMARAN title (recon MBIP --
        # the popup is the bookmark LIST with PILIH/HAPUS buttons; the
        # previous SIMPAN-based check re-tapped straight through the
        # modal's full-screen backdrop).
        # SAHKAN-DEVICE: belum disahkan pada MBJB — Loh belum mengetuk
        # ikon ini pada device (PAPAN.md §4). Tajuk popup MBJB mungkin
        # berbeza; kalau ia berbeza, kaedah ini melempar dengan dump dan
        # itu memang hasil yang dikehendaki (jujur), bukan skip.
        # Tidak sensitif huruf: app MEMAKSA HURUF BESAR dan text() PEKA
        # huruf (fasa2-bootstrap §2.4).
        popup_title = (AppiumBy.ANDROID_UIAUTOMATOR,
                       'new UiSelector().textMatches('
                       '"(?i)(?s).*pilihan\\s*kegemaran.*")')
        for attempt in range(3):
            el = self.find_element(icon, timeout=5)
            self.tap_element(el)
            time.sleep(1.5)
            if self.is_element_present(popup_title, timeout=3):
                print("  [BOOKMARK] Pilihan Kegemaran popup open — PASS")
                self._dump("bookmark_popup.xml")
                return
            print(f"  [BOOKMARK] popup didn't open (attempt "
                  f"{attempt + 1}/3) -- re-tapping...")
        path = self._dump("bookmark_popup_never_opened.xml")
        raise TimeoutException(
            f"bookmark popup never opened after 3 taps; see {path}")

    def save_bookmark(self, name):
        """Type the bookmark name into the popup's name field and SIMPAN.

        >>> AWAS — ASAL BUKTI DIBETULKAN 2026-07-30. <<< Versi lama
        docstring ini berbunyi "KNOWN BUILD LIMITATION ... on this build
        the PILIHAN KEGEMARAN popup offers ONLY a list with PILIH/HAPUS".
        Bukti itu ialah recon **MBIP 2.1.17** pada 2026-07-16 (dump
        `bm2_tap_popup` / `bookmark_popup_never_opened`), BUKAN MBJB.
        Menyebutnya sebagai "this build" menjadikan fakta APK LAIN
        kelihatan seperti fakta MBJB 2.1.33.

        # SAHKAN-DEVICE: belum disahkan pada MBJB. Loh belum pernah
        # mengetuk ikon buku pada device (PAPAN.md §4), jadi TIDAK
        # diketahui sama ada popup MBJB menawarkan medan nama + SIMPAN.
        # Bukti yang bercanggah DENGAN andaian MBIP: kelima-lima sheet
        # MBPG-TC-N/P/K/L/S-005 memberi langkah SIMPAN yang lengkap dan
        # DEV FIXING LIST baris 27 merekod pembaikan bookmark — jadi
        # jangan bawa masuk had MBIP itu sebagai muktamad.

        Kalau medan nama memang tiada pada MBJB, kaedah ini melempar
        dengan dump dan TC gagal secara jujur (Peraturan #6). Tiada skip
        dicipta dan tiada assert dilonggarkan.

        >>> PEPIJAT SEBENAR DIBETULKAN 2026-07-31 (dedah cuakKambing,
        diarah Loh) — CARIAN GLOBAL DIBUANG. <<<
        Versi sebelum ini mencari EditText secara GLOBAL
        (`self.driver.find_elements`). Dump `K9` membuktikan borang
        PESALAH (dengan medan NAMA PESALAH) KEKAL DALAM POKOK di
        belakang popup PILIHAN KEGEMARAN -- ia sama sekali TIDAK dibuang
        semasa modal dibuka (kelas pepijat B1 yang SAMA yang
        base_page.fill_field_by_label_or_instance() sudah dibetulkan
        untuk skrin Tetapan). Syarat pemilihan di bawah
        (`"nama" in t.lower()`) memadan PLACEHOLDER "NAMA PESALAH" sama
        mudah seperti medan nama bookmark sebenar -- jadi nama bookmark
        boleh menaip SENYAP ke dalam NAMA PESALAH, rekod disimpan, dan
        nama itu TERCETAK pada kompaun sebenar. Kelas pepijat yang sama
        seperti "Buruh En Saiful" yang bertahan berbulan dalam MBIP.

        Pembetulan: hadkan carian kepada modal-surface AKTIF
        (`base_page.MODAL_SURFACE_ID` / `_find_all_by_resource_id` --
        corak B1 yang SAMA, satu sumber kebenaran, TIDAK disalin semula
        ke sini). Kalau tiada 'modal-surface' dapat ditentukan, kaedah
        ini MENOLAK jatuh kembali kepada carian global -- sama seperti
        `_editext_in_active_container()` menolak pada skrin Tetapan:
        gagal BISING (AssertionError + dump) lebih baik daripada menaip
        ke medan borang yang salah secara senyap."""
        import time
        print(f"  [BOOKMARK] Saving bookmark: {name}")
        target = None
        surfaces = self._find_all_by_resource_id(self.MODAL_SURFACE_ID)
        if not surfaces:
            path = self._dump("bookmark_no_modal_surface.xml")
            raise AssertionError(
                f"popup PILIHAN KEGEMARAN tidak membawa "
                f"'{self.MODAL_SURFACE_ID}' -- skop carian EditText TIDAK "
                f"dapat ditentukan dengan yakin. MENOLAK carian global "
                f"(lihat nota B1 base_page.py): borang PESALAH kekal "
                f"dalam pokok di belakang popup ini (dump K9) dan carian "
                f"global boleh menaip nama bookmark ke medan borang yang "
                f"salah. Kalau popup ini memang TIDAK guna komponen modal "
                f"standard app, laporkan resource-id sebenar pembungkusnya "
                f"daripada {path} supaya skop carian boleh dibetulkan "
                f"dengan bukti, bukan diteka.")
        skop = surfaces[-1]  # modal TERATAS -- lihat nota B1 base_page.py
        try:
            edits = skop.find_elements(AppiumBy.CLASS_NAME,
                                       "android.widget.EditText")
            print(f"  [BOOKMARK] carian EditText dihadkan kepada "
                  f"'{self.MODAL_SURFACE_ID}' teratas ({len(edits)} medan, "
                  f"{len(surfaces)} surface tersarang) -- bukan carian "
                  f"global")
            for el in reversed(edits):
                t = el.text or ""
                # placeholder-ish or empty field = the name input
                if not t or "nama" in t.lower() or "name" in t.lower():
                    target = el
                    break
        except Exception:
            pass
        if target is None:
            path = self._dump("bookmark_name_field_missing.xml")
            raise AssertionError(
                f"UI simpan Bookmark tidak dijumpai: popup PILIHAN "
                f"KEGEMARAN tidak membekalkan medan nama DALAM "
                f"'{self.MODAL_SURFACE_ID}' ({len(surfaces)} surface), "
                f"jadi langkah SIMPAN sheet -005 tidak dapat dilakukan. "
                f"Ini padan dengan recon MBIP 2.1.17 (hanya PILIH/HAPUS) "
                f"TETAPI belum pernah disahkan pada MBJB 2.1.33 — dump "
                f"{path} ialah bukti PERTAMA untuk MBJB. Kalau ia "
                f"mengesahkan popup memang tiada medan nama, itu penemuan "
                f"kategori B untuk dev (sheet -005 menuntutnya), bukan "
                f"bug automation.")
        target.click()
        target.clear()
        # >>> DIBETULKAN 2026-08-04 — RISIKO KELAS SAMA seperti N-004. <<<
        # Medan ini teks bebas di dalam modal RN, sama persis dengan medan
        # SILA ISI KETERANGAN. Di situ, `mobile: type` dengan rentetan
        # panjang MERANAPKAN app ke skrin merah RN, disahkan dengan empat
        # varian pada rekod yang sama (app dilancar semula antara setiap):
        #     mobile: type "blank dari test script" -> REDBOX
        #     mobile: type "AB"                     -> OK
        #     send_keys    "blank dari test script" -> OK
        #     send_keys    "AB"                     -> OK
        # Teks yang SAMA lulus melalui send_keys, jadi puncanya kaedah
        # taipan, bukan teks — kategori A.
        # `_emit_text(el, nilai, use_mobile_type=False)` cuba send_keys
        # dahulu dan hanya jatuh ke `mobile: type` untuk medan bertopeng/
        # berangka yang menolak send_keys, jadi ia selamat kedua-dua arah.
        self._emit_text(target, name, False)
        # keep_keyboard semantics: this is a dismissible RN modal --
        # hide_keyboard can act like Back and close it (same lesson as
        # the Tarik Notis popup), so the keyboard stays up and SIMPAN is
        # tapped via raw coordinates.
        time.sleep(0.5)
        for simpan in self.SIMPAN_LOCATORS:
            if self.is_element_present(simpan, timeout=3):
                el = self.find_element(simpan, timeout=3)
                self.tap_element(el)
                time.sleep(1.5)
                # >>> KELAS B-1. <<< Versi lama memanggil terus
                # `dismiss_native_alerts()`, yang ketika itu MENELAN teks
                # alert: bookmark yang DITOLAK ("TIDAK BERJAYA") ditolak
                # secara senyap dan kaedah ini pulang seolah-olah SIMPAN
                # menjadi.
                # Teks dibaca melalui helper base_page (satu sumber
                # kebenaran — TIADA pembacaan alert ad-hoc di sini), dan
                # penafian disemak DAHULU melalui BERJAYA_DINAFI.
                # JANGAN klasifikasikan `teks` dengan `"BERJAYA" in teks`:
                # ia benar untuk "TIDAK BERJAYA".
                teks = self.read_native_alert_text(first_timeout=3)
                ditolak = self.is_element_present(self.BERJAYA_DINAFI,
                                                  timeout=2)
                dikumpul = self.dismiss_native_alerts(
                    first_timeout=3, context="bookmark save", kumpul=True)
                if dikumpul:
                    teks = " // ".join(dict.fromkeys(
                        ([teks] if teks else []) + dikumpul))
                if ditolak:
                    path = self._dump("bookmark_simpan_ditolak.xml")
                    raise AssertionError(
                        f"SIMPAN bookmark DITOLAK oleh app: alert "
                        f"{teks!r}. Bookmark TIDAK disimpan, jadi langkah "
                        f"PILIH/isi-semula sheet -005 selepas ini akan "
                        f"menguji bookmark yang tidak wujud. Dump: {path}")
                if teks:
                    print(f"  [BOOKMARK] alert selepas SIMPAN: {teks!r}")
                print("  [BOOKMARK] SIMPAN tapped")
                return
        path = self._dump("bookmark_simpan_missing.xml")
        raise TimeoutException(f"SIMPAN not found in the bookmark popup; "
                               f"see {path}")

    def select_bookmark(self, name):
        """Reopen the Pilihan Kegemaran list via the book icon and tap
        the saved bookmark row (verified tap: the row/popup must leave
        the screen)."""
        import time
        print(f"  [BOOKMARK] Reopening list and selecting: {name}")
        self.open_bookmark_popup()
        row = (AppiumBy.ANDROID_UIAUTOMATOR,
               f'new UiSelector().textContains("{name}")')
        if not self.is_element_present(row, timeout=5):
            path = self._dump("bookmark_row_missing.xml")
            raise TimeoutException(
                f"saved bookmark {name!r} not listed; see {path}")
        for attempt in range(3):
            try:
                el = self.find_element(row, timeout=3)
            except TimeoutException:
                return  # row gone -> selection registered
            self.tap_element(el)
            time.sleep(1.5)
            if not self.is_element_present(row, timeout=2):
                print("  [BOOKMARK] Bookmark selected — PASS")
                return
            print(f"  [BOOKMARK] row still showing (attempt "
                  f"{attempt + 1}/3) -- re-tapping...")
        # The list may keep the row visible while still applying the
        # selection -- close the popup and let the caller verify fields.
        print("  [BOOKMARK] WARNING: row still visible after taps -- "
              "closing popup and relying on field verification")
        if not self.close_popup_by_icon(timeout=3):
            self.press_back()

    def verify_fields_repopulated(self, expected_texts):
        """Assert each expected value is visible on the form again
        (find_element's scroll fallback handles values below the fold)."""
        import time
        time.sleep(1.5)
        missing = []
        for t in expected_texts:
            loc = (AppiumBy.ANDROID_UIAUTOMATOR,
                   f'new UiSelector().textContains("{t}")')
            try:
                self.find_element(loc, timeout=5)
            except TimeoutException:
                missing.append(t)
        if missing:
            path = self._dump("bookmark_fields_missing.xml")
            raise AssertionError(
                f"fields not repopulated from the bookmark: {missing}; "
                f"see {path}")
        print("  [BOOKMARK] All bookmarked fields repopulated — PASS")

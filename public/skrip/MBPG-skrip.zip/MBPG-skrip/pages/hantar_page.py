"""
Hantar (Send/Sync) page — Page Object Model.
Flow: Tab Belum Hantar (default) -> Hantar Data -> Hantar Gambar -> popup ->
click Semua -> wait -> switch to Tab Data Ralat -> Hantar Semula.

This is a separate menu from Senarai (previously incorrectly merged into
senarai_page.py).
"""

from appium.webdriver.common.appiumby import AppiumBy
from pages.base_page import BasePage
# C-15 — satu salinan sahaja bagi isyarat tunggu "SEDANG DIPROSES".
from pages.senarai_page import tunggu_selesai_diproses as senarai_tunggu


# PORT MBJB — nota risiko untuk H-001..H-005 (tiada perubahan kod):
#
# SAHKAN-DEVICE: DEV FIXING LIST baris 66 (status WIP, keutamaan High)
# mencatat "Kompaun tak berjaya hantar ke ePBT". Kalau Hantar Data gagal,
# semak isu itu dahulu sebelum menyalahkan automation. Baris 111 mencatat
# Hantar Semula tidak mengendalikan tempoh 0 hari (0 dianggap tiada data)
# -- elak nilai tempoh 0 dalam data MBJB. Baris 93 (NEW, High) mencatat
# loading sangat lama bila internet perlahan: _wait_and_dismiss_result()
# di bawah menunggu 30s secara lalai; kalau alert tiba lewat, itu isu
# rangkaian yang direkodkan, bukan locator yang salah.
#
# CLAUDE.md MBIP mendakwa "server menolak hantar-semula untuk jenis
# P/K/L". Dakwaan itu BELUM DISAHKAN untuk MBJB dan bukti bercanggah:
# Excel H-001..H-005 kesemuanya Status Pass dan menamakan rekod P/K/L
# yang berjaya. Jangan bawa masuk skip MBIP itu secara automatik.
class HantarPage(BasePage):
    """Hantar screen — data/photo sync and error retry."""

    def __init__(self, driver):
        super().__init__(driver)
        # FIX#29: ditetapkan True bila app memulangkan popup
        # 'Beberapa gambar tidak berjaya di muatnaik' — isyarat bahawa
        # muat naik gambar gagal di sebelah app. Pemanggil boleh membacanya
        # selepas sync_all() untuk verdik yang jujur.
        self.gambar_ralat = False

    # ---- Tabs ----
    # Confirmed via live UI dump: this app renders all tab/button labels
    # in upper case regardless of how they're worded in specs/manuals
    # (same convention as the "KOMPAUN PELBAGAI" dropdown options in
    # daftar_kompaun_page.py) -- the Title Case text() matches here
    # never matched anything, which is why is_hantar_screen_displayed()
    # always reported the Hantar screen as not displayed even when it
    # very clearly was. The "BELUM HANTAR" tab's real text/content-desc
    # also has a trailing space ("BELUM HANTAR "), so textContains is
    # used instead of an exact text() match to not depend on that.
    TAB_BELUM_HANTAR = (AppiumBy.ANDROID_UIAUTOMATOR,
                        'new UiSelector().textMatches("(?i).*BELUM\s+HANTAR.*")')
    TAB_DATA_RALAT = (AppiumBy.ANDROID_UIAUTOMATOR,
                      'new UiSelector().textMatches("(?i).*DATA\s+RALAT.*")')

    # ---- Belum Hantar tab ----
    BUTTON_HANTAR_DATA = (AppiumBy.ANDROID_UIAUTOMATOR,
                          'new UiSelector().textMatches("(?i).*HANTAR\s+DATA.*")')
    BUTTON_HANTAR_GAMBAR = (AppiumBy.ANDROID_UIAUTOMATOR,
                            'new UiSelector().textMatches("(?i).*HANTAR\s+GAMBAR.*")')
    # Popup that appears after clicking Hantar Gambar
    BUTTON_SEMUA = (AppiumBy.ANDROID_UIAUTOMATOR,
                    'new UiSelector().textMatches("(?i).*SEMUA.*")')

    # ---- Data Ralat tab ----
    BUTTON_HANTAR_SEMULA = (AppiumBy.ANDROID_UIAUTOMATOR,
                            'new UiSelector().textMatches("(?i).*HANTAR\s+SEMULA.*")')

    # Error popup that can appear after Hantar Data/Hantar Gambar if the
    # upload partially fails (e.g. "RALAT / BEBERAPA GAMBAR TIDAK
    # BERJAYA DI MUATNAIK." -- confirmed via live UI dump). It sits on
    # top of the Data Ralat tab and blocks it from being tapped if left
    # open, so it must be dismissed before navigating further. Matched
    # on "TIDAK BERJAYA" (not "RALAT" alone, which is also a substring
    # of the "DATA RALAT" tab label and would give a false positive).
    POPUP_RALAT = (AppiumBy.ANDROID_UIAUTOMATOR,
                   'new UiSelector().textMatches("(?i).*TIDAK\s+BERJAYA.*")')

    # ========================================================================
    # Actions
    # ========================================================================

    def is_hantar_screen_displayed(self):
        """Verify we are on the Hantar screen (Belum Hantar tab default)."""
        return self.is_element_present(self.TAB_BELUM_HANTAR, timeout=10)

    def _wait_and_dismiss_result(self, context, wait_timeout=30):
        """Wait for the native result alert a send operation ends with
        and dismiss it (plus anything queued behind it). Returns the list
        of alert texts seen (may be empty).

        The old version only looked for the RALAT ("TIDAK BERJAYA")
        variant with a 3s sleep -- confirmed via live run that a
        SUCCESS alert (same native "BERJAYA" dialog the Selaras syncs
        use, per debug_menu_selaras_close.xml) appears after the upload
        finishes, which can be well past 3s, and then sits there
        blocking the DATA RALAT tab from ever being tapped.

        >>> FIX#29 — 2026-10-09: JANGAN TELAN KEGAGALAN MUAT NAIK. <<<
        Alert "Ralat | Beberapa gambar tidak berjaya di muatnaik."
        muncul pada KELIMA-LIMA borang (N/P/K) di larian 2026-10-09
        (log baris 439/706/995/1244/1501) tetapi hanya dicetak sebagai
        '[ALERT] ... popup says:' dan DIBUANG — tiada kesan pada verdik.
        Itu menjadikan TC 'Hantar' seolah-olah bersih sedangkan muat naik
        gambar GAGAL di sebelah app. Sekarang teks alert DIKUMPUL
        (`kumpul=True`) dan klasifikasikan:
          - teks mengandungi 'tidak berjaya'  -> muat naik GAGAL
            (`self.gambar_ralat = True`, dicetak sebagai AMARAN).
        Perhatian: 'BERJAYA' ialah subrentetan 'TIDAK BERJAYA' — semak
        yang negatif DAHULU.
        """
        # C-15 — tunggu overlay sibuk HILANG dahulu. Sync ialah operasi
        # panjang (DEV FIXING LIST baris 93: loading sangat lama bila
        # internet perlahan); kehilangan "SEDANG DIPROSES" ialah isyarat
        # SEBENAR bahawa ia tamat, bukan sleep tetap.
        if not senarai_tunggu(self, tag="HANTAR"):
            print(f"  [HANTAR] AMARAN: overlay sibuk masih ada selepas "
                  f"{context} — keadaan yang diuji seterusnya mungkin "
                  f"belum wujud. Ini dilaporkan, bukan diabaikan.")
        teks = self.dismiss_native_alerts(first_timeout=wait_timeout,
                                          context=context, kumpul=True)
        if not teks:
            print(f"  [HANTAR] No result popup for {context} within "
                  f"{wait_timeout}s -- continuing")
            return teks
        # Klasifikasi — negatif DAHULU ('BERJAYA' ada dalam 'TIDAK BERJAYA').
        gagal = [t for t in teks if "tidak berjaya" in t.lower()]
        if gagal:
            self.gambar_ralat = True
            print(f"  [HANTAR] AMARAN APP: {context} memulangkan popup "
                  f"KEGAGALAN — {gagal[0]}")
            print("  [HANTAR]          Ini kegagalan muat naik di sebelah "
                  "app; TC 'Hantar' TIDAK boleh dikira bersih. Verdik "
                  "hendaklah mengambil kira isyarat ini (Fix#29).")
        return teks

    # ------------------------------------------------------------------
    # C-3 — H-001..H-005 mesti mengesahkan IKUT NOMBOR, bukan ikut jenis.
    # ------------------------------------------------------------------

    def verify_sent_by_number(self, senarai_page, no_rekod,
                              token_hantar="H"):
        """Sahkan bahawa REKOD `no_rekod` (yang run INI cipta) menunjukkan
        STATUS HANTAR `token_hantar` dalam Senarai. Melempar
        AssertionError pada setiap kegagalan; pulang senarai token pada
        kejayaan.

        TANDATANGAN KONTRAK untuk kelima-lima fail test H-* (bahagian
        Mustaqim) — ganti blok `rows_for_jenis(JENIS)` + `re.search(",\\s*H
        \\s*,")` + `assert sent` dengan SATU panggilan:

            toks = pages.hantar.verify_sent_by_number(pages.senarai, no)

        di mana `no = require_record(created_records, JENIS, TC_CREATE)`.

        MENGAPA: `senarai.rows_for_jenis()` ialah pemilihan IKUT JENIS /
        KEDUDUKAN, dan assert lama lulus apabila MANA-MANA baris jenis itu
        menunjukkan `H`. Staging penuh rekod LAMA yang SUDAH berstatus
        `H` daripada run terdahulu, jadi H-001 akan LULUS walaupun sync
        run ini GAGAL SEPENUHNYA — bug terbesar MBIP dalam modul yang
        berbeza. Fail-fail H-* itu sudah menulis alasan yang tepat mengapa
        ini salah, kemudian tetap melakukannya.

        # SAHKAN-DEVICE: token `H`/`M` ialah lajur STATUS HANTAR pada
        # bentuk baris MBIP ("P, 2026-07-01, 10:35, M, A, msc"). Baris
        # Senarai MBJB belum pernah di-dump — sahkan indeks/nilai token
        # sebenar sebelum mempercayai kesimpulan ini."""
        if not no_rekod:
            raise AssertionError(
                "verify_sent_by_number() dipanggil tanpa no_rekod. "
                "Pengesahan STATUS HANTAR ikut JENIS DILARANG (PERATURAN "
                "KERAS #7): rekod LAMA sudah bertanda 'H' dan akan "
                "menghasilkan PASS palsu walaupun sync run ini gagal.")
        toks = senarai_page.find_number_and_tokens(no_rekod)
        if toks is None:
            raise AssertionError(
                f"rekod {no_rekod} TIDAK kelihatan dalam Senarai selepas "
                f"Hantar — tidak boleh mengesahkan STATUS HANTAR tanpa "
                f"rekod itu sendiri. TIDAK membaca baris lain.")
        want = str(token_hantar).strip().upper()
        # App MEMAKSA HURUF BESAR pada input, tetapi token baris belum
        # disahkan casingnya -- bandingkan tidak sensitif huruf.
        if want not in [t.strip().upper() for t in toks]:
            raise AssertionError(
                f"rekod {no_rekod} TIDAK menunjukkan STATUS HANTAR "
                f"{want!r} selepas Hantar; token baris: {toks}")
        print(f"  [HANTAR] Rekod {no_rekod} disahkan terhantar "
              f"(STATUS HANTAR = {want}) — PASS")
        return toks

    def click_hantar_data(self):
        """Click Hantar Data and wait for it to finish."""
        print("  [HANTAR] Clicking Hantar Data...")
        self.wait_and_click(self.BUTTON_HANTAR_DATA)
        self._wait_and_dismiss_result("Hantar Data", wait_timeout=30)
        print("  [HANTAR] Hantar Data done")

    def click_hantar_gambar(self):
        """Click Hantar Gambar, then confirm via the 'Semua' popup option."""
        print("  [HANTAR] Clicking Hantar Gambar...")
        self.wait_and_click(self.BUTTON_HANTAR_GAMBAR)

        print("  [HANTAR] Confirming with 'Semua'...")
        if self.is_element_present(self.BUTTON_SEMUA, timeout=5):
            self.wait_and_click(self.BUTTON_SEMUA)

        # Photo uploads are the slow path -- allow more time.
        self._wait_and_dismiss_result("Hantar Gambar", wait_timeout=60)
        print("  [HANTAR] Hantar Gambar done")

    def switch_to_data_ralat_tab(self):
        """Switch to the Data Ralat tab."""
        print("  [HANTAR] Switching to Data Ralat tab...")
        self.wait_and_click(self.TAB_DATA_RALAT)

    def click_hantar_semula(self):
        """Click Hantar Semula and wait for it to finish, if the button
        is present (there may be nothing to resend)."""
        if self.is_element_present(self.BUTTON_HANTAR_SEMULA, timeout=5):
            print("  [HANTAR] Clicking Hantar Semula...")
            self.wait_and_click(self.BUTTON_HANTAR_SEMULA)
            import time
            time.sleep(3)
            print("  [HANTAR] Hantar Semula done")
        else:
            print("  [HANTAR] No error records to resend — skipping")

    def sync_all(self):
        """Complete full sync flow: Hantar Data -> Hantar Gambar ->
        Data Ralat tab -> Hantar Semula."""
        self.click_hantar_data()
        self.click_hantar_gambar()
        self.switch_to_data_ralat_tab()
        self.click_hantar_semula()
        return True

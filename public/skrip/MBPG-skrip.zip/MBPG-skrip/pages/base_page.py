"""
Base Page — shared methods for all Page Objects.
Provides common locator strategies and wait utilities.

PORT MBJB — SALIN BULAT dari MBIP v3 kecuali SATU perkara.
Fail ini mengandungi penemuan device yang diperoleh dengan susah payah
(tap_element, dismiss_native_alerts, reveal_below_fold, 'mobile: type',
retry pengesahan selepas setiap tap kritikal). Ia TIDAK ditulis semula dan
TIDAK "dikemas" semasa port. Satu-satunya perubahan berbanding MBIP ialah
awalan nombor rekod: MBIP menghardcode 'IPA' dalam read_record_number();
MBJB membacanya daripada profil aktif (config.RECORD_PREFIX, cth 'JB015').
Rujuk _record_prefix() di bawah.
"""

from appium.webdriver.common.appiumby import AppiumBy
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import (
    TimeoutException,
    NoSuchElementException,
    StaleElementReferenceException,
)

# --- Awalan nombor rekod, daripada profil aktif ---------------------------
# MBIP: 'IPA' (IPA3N260728054). MBJB: 'JB015' (JB015N260227001) mengikut
# profiles/mbjb-*.json. Dibaca MALAS (lazy) supaya modul pages/ masih boleh
# diimport oleh alat luar-suite yang tidak memuatkan config.
#
# Kalau config tidak dapat dimuatkan, kaedah ini MELEMPAR. Ia sengaja TIDAK
# jatuh ke nilai lalai: awalan yang salah/kosong menjadikan regex memadan
# apa-apa sahaja, dan read_record_number() akan memulangkan token karut yang
# kemudian disimpan dalam created_records. Peraturan Keras #7 (rekod dibuka
# ikut NOMBOR, tiada fallback) bergantung sepenuhnya pada nilai ini betul.
_RECORD_PREFIX_CACHE = None


def _record_prefix():
    """Awalan nombor rekod untuk PBT/profil aktif, cth 'JB015'."""
    global _RECORD_PREFIX_CACHE
    if _RECORD_PREFIX_CACHE:
        return _RECORD_PREFIX_CACHE
    try:
        from config import RECORD_PREFIX
    except Exception as e:                                   # noqa: BLE001
        raise RuntimeError(
            "RECORD_PREFIX tidak dapat dibaca daripada config.py "
            f"({type(e).__name__}: {e}). Nombor rekod TIDAK boleh diekstrak "
            "tanpa awalan yang sah -- lihat profiles/mbpg-staging.json kunci "
            "'record_prefix'.") from e
    prefix = (RECORD_PREFIX or "").strip()
    if not prefix:
        raise RuntimeError(
            "RECORD_PREFIX kosong dalam profil aktif. Awalan kosong akan "
            "menjadikan regex nombor rekod memadan apa-apa token -- "
            "menolak. Isi 'record_prefix' dalam profiles/mbjb-*.json.")
    _RECORD_PREFIX_CACHE = prefix
    return prefix


class BasePage:
    """Base class with common element interaction methods."""

    # Common locators that may be needed across pages
    BUTTON_BACK = (AppiumBy.ACCESSIBILITY_ID, "Back")
    BUTTON_YA = (AppiumBy.ANDROID_UIAUTOMATOR,
                  'new UiSelector().text("Ya")')
    BUTTON_TIDAK = (AppiumBy.ANDROID_UIAUTOMATOR,
                    'new UiSelector().text("Tidak")')
    BUTTON_OK = (AppiumBy.ANDROID_UIAUTOMATOR,
                 'new UiSelector().text("OK")')
    BUTTON_CLOSE = (AppiumBy.ANDROID_UIAUTOMATOR,
                    'new UiSelector().description("Close")')
    # >>> B2 \u2014 HAMBURGER HANYA ADA PADA SKRIN LOGIN <<<
    # Nota MBIP lama di sini berbunyi "the hamburger is NOT unique to the
    # home screen -- it's ALSO present on the login screen", yang membayangkan
    # ia ada pada KEDUA-DUA skrin. Pada MBJB 2.1.33 itu SALAH.
    #
    # FAKTA DEVICE, dikira Loh sendiri (glif U+F0C9):
    #   ui_dumps\01_skrin_awal.xml      (skrin LOGIN) -> 2 kemunculan
    #   ui_dumps\02_menu_hamburger.xml  (skrin LOGIN) -> 2 kemunculan
    #   ui_dumps\40_skrin_utama.xml     (skrin UTAMA) -> 0 kemunculan
    # (2 kemunculan = satu pasangan: ViewGroup content-desc='\uf0c9' PLUS
    #  anak TextView text='\uf0c9', kedua-duanya @ [960,306][1037,397].)
    #
    # \u21d2 MENU SELARAS dicapai dari skrin LOGIN sahaja. Pada skrin UTAMA tiada
    #   hamburger; tiga butang ikon bar atas ialah segar U+F0453, printer
    #   U+F042A, log keluar U+F0343 \u2014 semuanya resource-id='icon-button'
    #   TANPA content-desc (lihat home_page).
    # \u21d2 Sebarang kod yang menganggap hamburger boleh dicapai SELEPAS log masuk
    #   akan gagal. home_page.open_hamburger_menu() sudah melempar dengan
    #   diagnosis itu; jangan tambah laluan kedua.
    #
    # LOCATOR SENDIRI KEKAL BETUL dan device-proven (ACCESSIBILITY_ID memadan
    # ViewGroup content-desc pada skrin login) \u2014 hanya dakwaan dalam nota yang
    # dibetulkan. Ia TIDAK boleh digunakan sebagai bukti "home reached":
    # bukan kerana ia ada pada kedua-dua skrin, tetapi kerana ia TIADA pada
    # skrin utama sama sekali. NOTIS AMARAN (kad grid utama) ialah bukti yang
    # betul.
    HAMBURGER = (AppiumBy.ACCESSIBILITY_ID, "\uf0c9")
    # >>> DIBETULKAN UNTUK MBPG 2.1.21 — 2026-08-10. <<<
    # ACCESSIBILITY_ID ialah padanan content-desc TEPAT dan PEKA HURUF.
    # Kad skrin utama MBPG membawa content-desc Title Case
    # ('Notis Amaran'), bukan huruf besar, jadi locator MBJB tidak pernah
    # memadan dan is_home_screen_displayed() melaporkan False pada skrin
    # utama SEBENAR. Kesannya: login yang BERJAYA dilaporkan sebagai
    # "Home screen did not appear", diikuti re-tap dan relaunch yang
    # kesemuanya sia-sia — disahkan pada device 2026-08-10, di mana recon
    # menunjukkan grid utama terpapar sepanjang masa.
    #
    # Ini pemalar yang is_home_screen_displayed() benar-benar baca;
    # membetulkan home_page.MODULE_* sahaja TIDAK memadai.
    HOME_SCREEN_INDICATOR = (
        AppiumBy.ANDROID_UIAUTOMATOR,
        'new UiSelector().descriptionMatches("(?i)\\s*NOTIS\\s+AMARAN\\s*")')

    # Navigation
    BUTTON_SETERUSNYA = (AppiumBy.ANDROID_UIAUTOMATOR,
                         'new UiSelector().descriptionMatches("(?i)\s*SETERUSNYA\s*")')
    BUTTON_MENYERAHKAN = (AppiumBy.ANDROID_UIAUTOMATOR,
                          'new UiSelector().textMatches("(?i)\s*MENYERAHKAN\s*")')
    # Confirmed via live UI dump: the "Simpan maklumat ini?" popup's
    # button renders as "HANTAR" (all caps), not "Hantar".
    BUTTON_HANTAR = (AppiumBy.ANDROID_UIAUTOMATOR,
                     'new UiSelector().textMatches("(?i)\s*HANTAR\s*")')

    # ---- Printer-connection alert (auto-off Bluetooth printer) ----
    # The paired BT thermal printer sleeps after ~10 min; the app's connect
    # attempt then fails and pops a MODAL native alert ("Error: Unable to
    # connect device") that covers everything behind it. It appears on many
    # screens, not one -- so recovery lives here, in the shared retry paths
    # (find_element / find_clickable / wait_and_tap / dropdown picks), drained
    # ONCE before each retry. Counted globally and reported at end of run: a
    # high count means the real fix is keeping the printer awake, not draining
    # in code. MUST stay enabled everywhere EXCEPT the Cetak flow, where this
    # same alert is the genuine "printer unreachable" signal that recalls the
    # operator (cetak_page toggles _drain_printer_enabled off around printing).
    PRINTER_ALERT_TEXT = "Unable to connect device"
    _printer_alert_count = 0
    _drain_printer_enabled = True

    # ---- Tempoh (MAKLUMAT KOMPAUN section) numeric field, validity 0-21 ----
    # The on-screen SECTION LABEL "MAKLUMAT KOMPAUN" is a NON-editable
    # TextView; the real EditText is that header's next sibling and carries
    # hint="TEMPOH NOTIS" (confirmed ui_dumps/recon_notistab_0.xml line 70,
    # holding a preset "21"). So it MUST be located positionally / by hint,
    # NEVER by the "MAKLUMAT KOMPAUN" label -- that matches the header and
    # silently no-ops, leaving whatever value was already in the field (the
    # Notis tempoh was never actually set by automation, it just rode the
    # field's default, and a stale out-of-range value like "90" would then
    # block SETERUSNYA -- the bug-2 symptom / 17-min Sitaan hang).
    TEMPOH_SIBLING = (AppiumBy.XPATH,
                      '//android.widget.TextView[@text="MAKLUMAT KOMPAUN"]'
                      '/following-sibling::android.widget.EditText[1]')
    TEMPOH_BY_HINT = (AppiumBy.XPATH,
                      '//android.widget.EditText[@hint="TEMPOH NOTIS"]')

    def __init__(self, driver):
        self.driver = driver
        # Default explicit wait timeout
        self.timeout = 15
        # Last created record number read off a success/receipt screen
        # (e.g. JB015N260227001); consumed by the -001 tests for the DB
        # trace ledger. None until a create succeeds and it's read.
        self.last_record_number = None
        # Result dict of the most recent scroll_in_viewport() call (see
        # that method + device_utils.measure_scroll()). None until the
        # first scroll. find_with_scroll() reads this to tell "skrol
        # tidak berkesan" apart from "elemen tiada" -- Loh's 2026-07-31
        # finding that a swipe can report "sent" with zero pixel
        # movement, which used to be indistinguishable from a genuine
        # missing locator.
        self.last_scroll_result = None

    # ------------------------------------------------------------------
    # Element helpers
    # ------------------------------------------------------------------

    # ------------------------------------------------------------------
    # TAMBAHAN MBJB 2026-07-31 -- skrol selamat-viewport, IME bersyarat,
    # semakan app-di-hadapan, carian skrol-dan-cari.
    #
    # Punca: TIGA run K1 berturut-turut gagal dengan `Spinner: 0` walaupun
    # label sasaran kelihatan pada skrin (recon\PAPAN.md "MULA DI SINI").
    # Dua pepijat berasingan dalam ALAT KAMI SENDIRI, dibuktikan dengan
    # ukuran (devtools\sahkan_skrol.py), bukan locator:
    #   1. Swipe lama bermula pada y=1900 pada skrin 1080x2460 device itu,
    #      TETAPI viewport borang yang boleh diskrol tamat pada y~1596
    #      (boundsInScreen terpotong pada 1596 dalam logcat) -- swipe
    #      bermula DI LUAR kawasan boleh skrol, borang tidak pernah
    #      bergerak walau sekali.
    #   2. `tutup_ime()` (versi devtools lama) menekan BACK TANPA SYARAT.
    #      Bila IME tidak terbuka, BACK menjadi navigasi UNDUR -- dipanggil
    #      berkali dalam gelung skrol, ia mengundur keluar dari borang,
    #      keluar dari app, sampai ke skrin utama Android, dan skrip terus
    #      menaip/tap ke skrin yang salah tanpa sedar.
    #
    # PELAJARAN BERKAITAN untuk seluruh suite (CLAUDE.md, disahkan logcat):
    # `uiautomator dump` MEMBUANG setiap node `visible:false` daripada
    # pokok accessibility. `Spinner: 0` / elemen tidak dijumpai daripada
    # SATU carian BUKAN bukti elemen itu tiada -- ia mungkin sekadar di
    # bawah paparan semasa. find_with_scroll() di bawah wujud supaya
    # keputusan "tiada" kekal jujur: skrol dahulu, cari semula, barulah
    # mengaku gagal.
    # ------------------------------------------------------------------

    def is_app_in_foreground(self):
        """True kalau package app kita sedang di latar hadapan.

        Guna `driver.current_package` (endpoint Appium/UiAutomator2
        piawai, tiada keperluan relaxed-security) dan BUKAN menghurai
        `dumpsys window` sendiri: prototaip devtools\\buka_penerima.py
        (`dalam_app()`) membuktikan `dumpsys window` memulangkan
        BERBILANG baris `mCurrentFocus`, yang PERTAMA selalunya `null`,
        dan mencari nama package merentas OUTPUT PENUH memberi True
        palsu (nama package kekal ada walaupun app di latar belakang).
        Appium menguruskan penghuraian itu di pelayan; kaedah ini hanya
        membandingkan hasilnya dengan config.APP_PACKAGE.

        Pulang True (degradasi selamat, BUKAN raise) kalau package
        semasa tidak dapat ditentukan atau config.APP_PACKAGE tidak
        dapat dimuatkan -- supaya alat luar-suite yang import modul ini
        tanpa config tidak pecah, dan sesi driver yang tidak menyokong
        semakan ini tidak menyekat setiap skrol. Amaran dicetak dalam
        kedua-dua kes supaya degradasi itu KELIHATAN, bukan senyap.
        """
        try:
            pkg = self.driver.current_package
        except Exception as e:                               # noqa: BLE001
            print(f"  [APP] tidak dapat membaca current_package "
                  f"({type(e).__name__}: {e}) -- semakan app-di-hadapan "
                  f"dilangkau")
            return True
        try:
            from config import APP_PACKAGE as _expected
        except Exception:                                    # noqa: BLE001
            print("  [APP] config.APP_PACKAGE tidak dapat dimuatkan -- "
                  "semakan app-di-hadapan dilangkau")
            return True
        if not _expected or not pkg:
            return True
        return pkg == _expected

    def _pastikan_app_di_hadapan(self, context=""):
        """MELEMPAR dengan mesej JELAS dan BERHENTI kalau app bukan lagi
        di latar hadapan. Dipanggil selepas setiap skrol
        (scroll_in_viewport) -- punca sebenar tiga kegagalan K1
        2026-07-31 ialah skrip terus menaip/tap SELEPAS terkeluar dari
        app secara senyap. Berhenti bising di sini lebih murah daripada
        satu run penuh yang menaip ke skrin Android yang salah tanpa
        sesiapa perasan. TIDAK cuba memulihkan apa-apa sendiri -- itu
        keputusan pemanggil/manusia, bukan tekaan automatik."""
        if self.is_app_in_foreground():
            return
        try:
            pkg = self.driver.current_package
        except Exception:                                    # noqa: BLE001
            pkg = "?"
        tag = f"[{context}] " if context else ""
        raise AssertionError(
            f"{tag}App TERKELUAR dari latar hadapan (package semasa "
            f"{pkg!r}, dijangka config.APP_PACKAGE) -- BERHENTI, bukan "
            f"meneruskan skrol/tap ke skrin yang tidak diketahui. Punca "
            f"yang sudah disahkan 2026-07-31 (recon\\PAPAN.md 'MULA DI "
            f"SINI'): BACK tanpa syarat semasa gelung skrol boleh "
            f"mengundur keluar dari app. Semak sama ada alert asli "
            f"beratur (dismiss_native_alerts()) atau IME/BACK tersalah "
            f"guna sebelum skrol ini.")

    def tutup_ime(self):
        """Tutup papan kekunci HANYA kalau ia benar-benar terbuka.

        Pulang True kalau IME ditutup di sini, False kalau tiada apa
        dilakukan (IME memang sudah tertutup, atau status tidak dapat
        dibaca).

        BUG YANG DIBETULKAN 2026-07-31 (recon\\PAPAN.md "MULA DI SINI"):
        prototaip devtools lama menekan BACK UNTUK TUTUP IME TANPA
        SYARAT. Bila IME TIDAK terbuka, BACK menjadi NAVIGASI UNDUR --
        dipanggil berkali dalam gelung skrol, ia mengundur keluar dari
        borang, keluar dari app, sampai ke skrin utama Android, dan
        skrip terus berinteraksi dengan skrin yang salah tanpa sedar
        (disahkan dengan ukuran berasingan di devtools\\sahkan_skrol.py
        SEMAKAN 2: skrin kekal SAMA + app kekal di hadapan bila versi
        yang menyemak driver.is_keyboard_shown() dahulu tidak menekan
        apa-apa).

        Ini fungsi PUBLIK yang setara dengan _hide_keyboard_if_shown()
        (yang dikekalkan, tidak disentuh, untuk ~10 pemanggil sedia
        ada) -- disediakan di bawah nama ini supaya ia sepadan dengan
        prototaip devtools yang terbukti pada device, dan supaya
        page-object LAIN (bukan hanya kaedah dalaman base_page ini)
        ada satu nama jelas untuk "tutup IME dengan selamat".
        """
        try:
            if not self.driver.is_keyboard_shown():
                return False
        except Exception:                                    # noqa: BLE001
            return False
        try:
            self.driver.hide_keyboard()
            import time
            time.sleep(0.3)
            return True
        except Exception:                                    # noqa: BLE001
            return False

    def _device_serial(self):
        """Serial peranti sesi Appium semasa, atau None kalau tidak
        dapat ditentukan. Dibaca daripada capabilities SESI (bukan
        adb sendiri) -- conftest.py:141 menghantar `options.set_capability
        ("udid", udid)`, dan pelayan UiAutomator2 turut menggemakan
        peranti sebenar sebagai `deviceUDID`. Dicuba dalam urutan itu.
        Digunakan HANYA untuk menghantar `serial` kepada
        device_utils.measure_scroll()/screen_size() (lihat
        scroll_in_viewport) -- tidak sekali-kali menjalankan adb sendiri
        di sini."""
        try:
            caps = self.driver.capabilities or {}
        except Exception:                                    # noqa: BLE001
            return None
        for key in ("appium:udid", "udid", "deviceUDID"):
            val = caps.get(key)
            if val:
                return val
        return None

    # Locator RN modal, ditakrif DI BAWAH sebagai MODAL_SURFACE_ID/
    # MODAL_ROOT_ID (~baris 1458) -- dirujuk semula di sini, bukan
    # diulang. (Nota lama di sini tersalah cakap "di atas"; ia hanya
    # berfungsi kerana dirujuk lewat `self.` semasa PANGGILAN, bukan
    # semasa takrif kelas -- Python tidak kisah tertib atribut kelas
    # selagi kaedah tidak dijalankan sebelum __init__.)
    #
    # Locator baris cadangan autocomplete INLINE (tab NOTIS). Sengaja
    # SALINAN TERASING corak yang SUDAH device-proven dalam
    # type_and_select_suggestion() (pemboleh ubah tempatan
    # `generic_suggestion_locator` di situ), BUKAN rujukan kongsi --
    # supaya kaedah SEDIA ADA yang device-proven itu tidak perlu
    # disentuh untuk kerja overlay ini.
    SUGGESTION_ROW_LOCATOR = (
        AppiumBy.ANDROID_UIAUTOMATOR,
        'new UiSelector().className("android.widget.TextView")'
        '.textContains("|")')

    def _cari_baris_cadangan_inline(self):
        """Semua TextView pada skrin SEKARANG yang mengandungi "|" --
        format baris cadangan autocomplete ("JALAN X | TAMAN Y"
        DUA-bahagian tab PESALAH, "JALAN X | TAMAN Y | BANDAR Z"
        TIGA-bahagian tab NOTIS -- widget TIDAK SERAGAM antara tab,
        lihat catatan dalam _skrol_disekat_oleh_overlay()). Senarai
        kosong kalau tiada/carian gagal -- TIDAK melempar. Implicit
        wait dimatikan (pola sama _find_all_by_resource_id) supaya
        probe overlay ini tidak membakar tempoh tunggu penuh pada
        setiap semakan skrol."""
        from config import IMPLICIT_WAIT
        self.driver.implicitly_wait(0)
        try:
            return self.driver.find_elements(*self.SUGGESTION_ROW_LOCATOR)
        except Exception:                                    # noqa: BLE001
            return []
        finally:
            self.driver.implicitly_wait(IMPLICIT_WAIT)

    # ---- baris cadangan dalam DIALOG NATIF (tab PESALAH) -----------------
    # >>> PUNCA KEGAGALAN SMOKE 2026-08-06, DIJEJAK DARI DUMP TERSIMPAN. <<<
    # ui_dumps\43_pilih_jalan_senarai.xml: cadangan MAKLUMAT JALAN pada tab
    # PESALAH keluar sebagai dialog NATIF
    # (com.anonymous.react_ies_v1:id/select_dialog_listview) dan setiap
    # barisnya ialah android.widget.CheckedTextView (resource-id
    # android:id/text1) -- BUKAN android.widget.TextView.
    # UiSelector.className() memadan nama kelas SECARA TEPAT, jadi
    # SUGGESTION_ROW_LOCATOR di atas (className TextView) TIDAK PERNAH
    # boleh memadan baris tab PESALAH. Itulah sebab
    # textStartsWith("JALAN JAGONG 11") "tidak dijumpai".
    #
    # SENGAJA SALINAN TERASING daripada DaftarKompaunPage.DIALOG_BARIS
    # (locator yang SAMA, device-proven pada mesin dropdown kod kompaun) --
    # sebab sama seperti SUGGESTION_ROW_LOCATOR di atas: supaya mesin
    # dropdown yang sudah terbukti tidak perlu disentuh untuk kerja ini.
    DIALOG_BARIS_CHECKED = (
        AppiumBy.ANDROID_UIAUTOMATOR,
        'new UiSelector().className("android.widget.CheckedTextView")')

    # Baris PROMPT dialog ('PILIH JALAN | TAMAN' -- baris PERTAMA dalam
    # dump 43) dan LABEL Spinner dengan teks yang SAMA (dump 42,
    # clickable=false) BUKAN cadangan. Memilihnya tidak memilih apa-apa.
    AWALAN_BARIS_PROMPT = "PILIH "

    def _kutip_baris_cadangan(self):
        """[(teks, elemen)] setiap baris cadangan pada skrin SEKARANG,
        merentas KEDUA-DUA bentuk widget (CLAUDE.md 'Widget autocomplete
        TIDAK SERAGAM antara tab'):

          tab PESALAH : dialog natif, baris = CheckedTextView (dump 43)
          tab NOTIS   : baris teks INLINE dalam borang = TextView (dump 51)

        Baris PROMPT ('PILIH ...') dibuang -- ia bukan cadangan.
        TIDAK melempar; senarai kosong bermakna tiada baris SEKARANG."""
        from config import IMPLICIT_WAIT
        self.driver.implicitly_wait(0)
        try:
            els = []
            for loc in (self.DIALOG_BARIS_CHECKED,
                        self.SUGGESTION_ROW_LOCATOR):
                try:
                    els.extend(self.driver.find_elements(*loc))
                except Exception:                            # noqa: BLE001
                    pass
        finally:
            self.driver.implicitly_wait(IMPLICIT_WAIT)
        out, dilihat = [], set()
        for el in els:
            t = self._safe_text(el)
            if not t or not t.strip():
                continue
            t = t.strip()
            if self._norm(t).startswith(self.AWALAN_BARIS_PROMPT):
                continue
            if t in dilihat:
                continue
            dilihat.add(t)
            out.append((t, el))
        return out

    @staticmethod
    def _norm_baris(s):
        """Bentuk kanonik satu baris cadangan: HURUF BESAR, ruang
        dimampatkan, pemisah diseragamkan kepada ' | '.

        Perlu kerana bilangan BAHAGIAN baris berbeza antara tab dan
        jarak di sekeliling '|' tidak dijamin:
          tab PESALAH (dialog) : 'JALAN X | TAMAN'
          tab NOTIS  (inline)  : 'JALAN X | TAMAN | BANDAR'
        """
        import re
        t = (s or "").strip().upper()
        t = re.sub(r"\s+", " ", t)
        return re.sub(r"\s*\|\s*", " | ", t)

    def _padan_baris_cadangan(self, baris, sasaran):
        """Elemen baris yang memadan `sasaran`, atau None.

        Padanan dibuat dalam PYTHON, bukan melalui regex UiSelector: nama
        jalan membawa aksara meta ('(', ')', '/', '.') dan menyuntiknya ke
        dalam textMatches() bermakna melarikan diri dua lapisan (Python ->
        UiSelector -> Java) -- satu kelas pepijat yang tidak perlu wujud.

        SATU peraturan sauh untuk SEMUA bentuk sasaran: baris mesti SAMA
        dengan sasaran, ATAU bermula dengan sasaran diikuti pemisah '|'.
        Sasaran boleh menamakan satu bahagian atau lebih:
          "JALAN X"            -> mana-mana baris jalan itu
          "JALAN X | TAMAN Y"  -> hanya baris jalan itu DALAM taman itu

        >>> KENAPA BENTUK DUA-SAUH WUJUD (bukti video 2026-08-06). <<<
        'JALAN ULU TIRAM' muncul TIGA KALI dalam senarai cadangan, dengan
        taman BERBEZA (ULU TIRAM | PLENTONG, KAMPUNG BARU ULU TIRAM |
        TEBRAU, KAMPUNG OREN | ...). Sasaran satu-bahagian akan mengambil
        yang PERTAMA dijumpai -- baris selaras yang salah, poskod yang
        salah, secara SENYAP. Bila oracle membekalkan taman yang dijangka
        (JANGKAAN_AUTOISI), pemanggil menaikkan sasaran kepada bentuk dua
        sauh dan kekaburan itu HILANG.

        Sauh '|' wajib selepas nama, jadi 'JALAN JAGONG 11' TIDAK boleh
        memadan 'JALAN JAGONG 110'."""
        s = self._norm_baris(sasaran)
        for teks, el in baris:
            t = self._norm_baris(teks)
            if t == s or t.startswith(s + " |"):
                return el
        return None

    def _taman_dijangka(self, jalan):
        """TAMAN yang oracle jangka untuk `jalan`, atau None.

        Dicari ikut NAMA JALAN merentas JANGKAAN_AUTOISI (sama corak
        seperti _rekod_autoisi_pesalah): halaman tidak tahu TC mana ia
        jalankan, dan jangkaan itu memang sifat JALAN (baris selaras),
        bukan sifat TC. Nilai datang dari sel oracle, bukan direka."""
        try:
            from testdata.excel_data import (JANGKAAN_AUTOISI,
                                             TC_DATA as _TD)
        except Exception:                                    # noqa: BLE001
            return None
        n = self._norm(jalan)
        for _tc, _j in (JANGKAAN_AUTOISI or {}).items():
            for _medan, _nilai in (_j or {}).items():
                if self._norm(_TD.get(_tc, {}).get(_medan)) == n:
                    return (_nilai or {}).get("taman")
        return None

    def _skrol_disekat_oleh_overlay(self):
        """Nama overlay yang MENYEKAT skrol borang INDUK sekarang, atau
        "" kalau tiada.

        Fakta device (KERJA KEDUA, Loh 2026-07-31): bila dropdown /
        senarai cadangan autocomplete TERBUKA (`ListView` / modal-surface
        di atas), borang di bawahnya biasanya TIDAK boleh diskrol --
        senarai/modal itu sendiri ada skrolnya SENDIRI
        (select_dropdown_option._scroll_inner_to_option menskrol
        `UiScrollable(...).instance(1)`, BUKAN instance(0) / borang
        induk, atas sebab yang sama). Kalau scroll_in_viewport()
        melapor "anjakan 0px" semasa salah satu ini terbuka, sebab
        sebenar ialah overlay -- bukan hujung senarai / bukan bug
        skrol. Disemak SEBELUM cuba skrol supaya sebab itu boleh
        dinamakan terus, bukan diteka daripada anjakan 0px sahaja.

        >>> EMPAT kelas overlay diliputi, disemak dalam urutan ini
        (paling menyekat dahulu) -- arahan Loh 2026-07-31 selepas
        kolisi swipe-masuk-senarai-cadangan yang membakar empat run: <<<
          1. Alert asli (android:id/alertTitle + button1) -- meliputi
             SEGALANYA di belakangnya. KEYCODE_BACK TIDAK menutupnya
             (lihat dismiss_native_alerts()), dan alert app ini
             BERATUR -- tap ke skrin di belakang alert beratur hilang
             SEPENUHNYA (CLAUDE.md).
          2. Modal RN (`modal-surface`) -- popup Menu Selaras, Tetapan,
             dsb (lihat MODAL_SURFACE_ID/MODAL_ROOT_ID di bawah).
          3. Dialog/`ListView` -- tab PESALAH: cadangan MAKLUMAT JALAN
             keluar sebagai Spinner + dialog select_dialog_listview.
          4. Senarai cadangan INLINE -- tab NOTIS: cadangan BUKAN
             Spinner, ia baris teks biasa DALAM borang
             (_cari_baris_cadangan_inline()). Perlu >=2 baris sebelum
             diisytihar TERBUKA -- SATU baris berkemungkinan nilai yang
             SUDAH dipilih terpapar dalam borang, bukan bukti senarai
             cadangan aktif.
        Widget autocomplete TIDAK SERAGAM antara tab (PESALAH vs NOTIS),
        jadi kelas 3 dan 4 kedua-duanya perlu -- satu heuristik sahaja
        akan terlepas salah satu tab.

        TIDAK menutup/memilih apa-apa overlay yang dijumpai -- lihat
        overlay_blocking_scroll() untuk versi PUBLIK kaedah ini yang
        boleh dipanggil oleh page-object LAIN sebelum mereka menutup/
        memilih overlay sendiri."""
        try:
            if self.is_element_present(self.NATIVE_ALERT_OK, timeout=1):
                teks = self._baca_alert_semasa()
                butiran = f" ({teks})" if teks else ""
                return f"alert asli terbuka{butiran}"
        except Exception:                                    # noqa: BLE001
            pass
        try:
            if self._find_all_by_resource_id(self.MODAL_SURFACE_ID):
                return "modal (modal-surface) terbuka"
        except Exception:                                    # noqa: BLE001
            pass
        try:
            if self.is_element_present(
                    (AppiumBy.CLASS_NAME, "android.widget.ListView"),
                    timeout=1):
                return "senarai (ListView) terbuka"
        except Exception:                                    # noqa: BLE001
            pass
        try:
            baris = self._cari_baris_cadangan_inline()
            if len(baris) >= 2:
                return (f"senarai cadangan inline terbuka "
                        f"({len(baris)} baris)")
        except Exception:                                    # noqa: BLE001
            pass
        return ""

    def overlay_blocking_scroll(self):
        """Versi PUBLIK bagi _skrol_disekat_oleh_overlay() -- nama
        overlay yang SEKARANG menyekat skrol borang induk, atau ""
        kalau tiada. Untuk page-object LAIN (bukan hanya kaedah dalaman
        base_page ini) menyemak SEBELUM memanggil scroll_in_viewport()/
        find_with_scroll(), supaya mereka boleh menutup/memilih overlay
        itu SENDIRI dahulu.

        scroll_in_viewport() memanggil pemeriksaan yang SAMA secara
        dalaman dan MENOLAK dirinya sendiri (pulang False + melapor)
        bila overlay ada -- ia SENGAJA TIDAK menutup overlay itu
        (keputusan Loh 2026-07-31): menutup dialog/memilih baris ialah
        tindakan yang mengubah keadaan app, dan melakukannya sebagai
        kesan sampingan TERSEMBUNYI bagi "skrol" akan mencipta kelas
        pepijat baharu. Kaedah ini wujud supaya PEMANGGIL yang
        membuat keputusan itu, contoh corak guna:

            sebab = self.overlay_blocking_scroll()
            if sebab:
                # POM ini yang tahu caranya: dismiss_native_alerts(),
                # tap pilihan dropdown/baris cadangan, dsb.
                ...
            self.scroll_in_viewport(...)

        Pulang "" bermakna skrol selamat diteruskan SEKARANG (keadaan
        boleh berubah serta-merta selepas ini -- tiada jaminan
        merentas masa, sekadar semakan SATU-viewport seketika, sama
        seperti is_element_present())."""
        return self._skrol_disekat_oleh_overlay()

    def _kira_swipe(self, container, direction, serial):
        """(x1, y1, x2, y2, durasi_ms) untuk `device_utils.measure_scroll()`
        / fallback `mobile: scrollGesture`, dikira daripada bounds
        SEBENAR -- tiada nombor piksel tetap.

        Keutamaan SAMA seperti scroll_in_viewport(): rect bekas
        boleh-skrol Appium (kalau dijumpai) dahulu; jika tiada, saiz
        skrin sebenar (device_utils.screen_size(serial) kalau serial
        diketahui, jika tidak driver.get_window_size()). 'down' (skrol
        ke bawah, dedah kandungan DI BAWAH) bermakna sentuhan bermula
        DEKAT HUJUNG BAWAH bekas dan bergerak ke ATAS -- padanan
        `input swipe 540 1400 540 600` yang disahkan devtools\\
        sahkan_skrol.py menggerakkan borang; 'up' membalikkannya."""
        if container is not None:
            try:
                rect = container.rect
                x = rect['x'] + rect['width'] // 2
                top, bottom = rect['y'], rect['y'] + rect['height']
            except Exception:                                # noqa: BLE001
                container = None
        if container is None:
            size = None
            if serial:
                try:
                    from device_utils import screen_size
                    size = screen_size(serial)
                except Exception:                            # noqa: BLE001
                    size = None
            if not size:
                ws = self.driver.get_window_size()
                size = (ws['width'], ws['height'])
            width, height = size
            x = width // 2
            top, bottom = int(height * 0.20), int(height * 0.65)
        span = bottom - top
        y_start = top + int(span * 0.85)
        y_end = top + int(span * 0.15)
        if direction == "up":
            y_start, y_end = y_end, y_start
        return (x, y_start, x, y_end, 600)

    def cari_dua_arah(self, locator, max_skrol=8, timeout_each=2):
        """Adakah elemen ini wujud pada borang — di ATAS atau di BAWAH?

        >>> KENAPA SATU ARAH TIDAK MEMADAI. <<<
        `find_with_scroll` hanya menatal ke BAWAH. Itu betul untuk
        mencari medan yang belum dicapai, tetapi SALAH untuk baca-balik:
        selepas mengisi borang dan memilih tiga dropdown, kedudukan skrin
        berada JAUH DI BAWAH medan awal. Mencari 'DEPAN KEDAI' dengan
        menatal ke bawah tidak akan pernah menjumpainya — ia di atas.

        Diperhati pada device 2026-08-10: read-back melaporkan GAGAL pada
        medan yang dump skrin buktikan terisi. Kegagalan itu palsu, dan
        kegagalan palsu dalam read-back adalah bahaya khusus: ia melatih
        pembaca mengabaikan baris merah.

        Maka: periksa di sini, kemudian naik, kemudian turun melepasi
        titik mula. Pulangkan kedudukan skrin kepada anggaran asal supaya
        pemanggil seterusnya tidak mewarisi kedudukan yang beralih.

        Pulangkan True/False. False bermakna TIDAK DIJUMPAI dalam
        kedua-dua arah — itu kegagalan SEBENAR, dan pemanggil patut
        melayannya begitu.
        """
        if self.is_element_present(locator, timeout=timeout_each):
            return True

        naik = 0
        for _ in range(max_skrol):
            if not self.scroll_in_viewport(direction="up",
                                           context="cari-dua-arah (atas)"):
                break
            naik += 1
            if self.is_element_present(locator, timeout=timeout_each):
                return True
            # Skrol yang DIUKUR tidak bergerak = hujung senarai.
            h = getattr(self, "last_scroll_result", {}) or {}
            if h.get("status") == "TIDAK_BERGERAK":
                break

        # Turun semula melepasi titik mula.
        for i in range(naik + max_skrol):
            if not self.scroll_in_viewport(direction="down",
                                           context="cari-dua-arah (bawah)"):
                break
            if self.is_element_present(locator, timeout=timeout_each):
                return True
            h = getattr(self, "last_scroll_result", {}) or {}
            if h.get("status") == "TIDAK_BERGERAK" and i >= naik:
                break
        return False

    @staticmethod
    def _peta_label_y_dari_xml(xml_text):
        """{label: y1} bagi setiap node berlabel UNIK.

        Salinan semantik `device_utils._peta_label_y`, tetapi memakan XML
        yang kita sudah ada dan bukan dump adb. Label berulang DIGUGURKAN
        atas sebab yang sama: memadankannya merentas dua bacaan akan
        mereka-reka padanan instans, dan anjakan yang direka lebih teruk
        daripada tiada anjakan.
        """
        import re as _re
        import xml.etree.ElementTree as _ET
        try:
            akar = _ET.fromstring(xml_text)
        except Exception:                                    # noqa: BLE001
            return {}
        kira, peta = {}, {}
        for n in akar.iter():
            label = ((n.get("text") or "").strip()
                     or (n.get("content-desc") or "").strip())
            if not label:
                continue
            m = _re.match(r"\[(-?\d+),(-?\d+)\]\[(-?\d+),(-?\d+)\]",
                          n.get("bounds", "") or "")
            if not m:
                continue
            kira[label] = kira.get(label, 0) + 1
            peta[label] = int(m.group(2))
        return {k: v for k, v in peta.items() if kira[k] == 1}

    def _ukur_skrol_melalui_driver(self, swipe, settle=1.2, ambang_px=50):
        """Laksana satu swipe dan ukur anjakan SEBENAR melalui Appium.

        >>> KENAPA INI MENGGANTIKAN device_utils.measure_scroll(). <<<
        Yang lama mengukur dengan `adb shell uiautomator dump`. Android
        membenarkan SATU instans uiautomator sahaja, dan pelayan
        UiAutomator2 Appium sudah memegangnya sepanjang sesi — jadi dump
        itu SENTIASA gagal semasa kita dipandu Appium.

        Kesannya bukan kecil. Setiap skrol melaporkan "pergerakan TIDAK
        DAPAT DISAHKAN", `find_with_scroll` menghabiskan kesepuluh-sepuluh
        cubaannya tanpa bukti, dan elemen yang berada betul-betul di bawah
        lipatan dilaporkan sebagai tidak wujud. Itu yang menyekat tiga
        dropdown Kompaun N-001 pada 2026-08-10: label ada pada y=2283
        (skrin 2400), kawalannya belum dirender, dan skrol tidak pernah
        berlaku dengan berkesan.

        `driver.page_source` membaca pokok yang SAMA melalui saluran yang
        MEMANG kita pegang. Kontrak pulangan dikekalkan sama supaya
        pemanggil tidak perlu berubah.

        Swipe dilakukan melalui driver, jadi ia melalui corong dry-run —
        termasuk semakan swipe-degenerat.
        """
        import time as _time
        x1, y1, x2, y2, durasi = swipe
        try:
            sebelum = self._peta_label_y_dari_xml(self.driver.page_source)
        except Exception as e:                               # noqa: BLE001
            return {"ok": False, "sebab": f"page_source SEBELUM gagal: {e}"}

        try:
            self.driver.swipe(x1, y1, x2, y2, durasi)
        except Exception as e:                               # noqa: BLE001
            return {"ok": False, "sebab": f"swipe gagal: {e}"}
        _time.sleep(settle)

        try:
            selepas = self._peta_label_y_dari_xml(self.driver.page_source)
        except Exception as e:                               # noqa: BLE001
            return {"ok": False, "sebab": f"page_source SELEPAS gagal: {e}"}

        dikongsi = [k for k in sebelum if k in selepas]
        anjakan = {k: abs(selepas[k] - sebelum[k]) for k in dikongsi}
        bergerak = [k for k, v in anjakan.items() if v >= ambang_px]
        if not dikongsi:
            status = "TIDAK_DAPAT_DITENTUKAN"
        elif bergerak:
            status = "BERGERAK"
        else:
            status = "TIDAK_BERGERAK"
        return {
            "ok": True,
            "status": status,
            "dikongsi": len(dikongsi),
            "bergerak": len(bergerak),
            "anjakan_max_px": max(anjakan.values()) if anjakan else 0,
            "anjakan_purata_px": (sum(anjakan.values()) // len(anjakan))
                                 if anjakan else 0,
            "baru": [k for k in selepas if k not in sebelum][:10],
            "hilang": [k for k in sebelum if k not in selepas][:10],
        }

    def scroll_in_viewport(self, direction="down", percent=0.3,
                           context=""):
        """Swipe kandungan boleh-skrol DALAM viewport SEBENARNYA pada
        skrin semasa, dan MENGUKUR sama ada ia benar-benar bergerak --
        tidak sekadar menghantar gerak isyarat dan mempercayainya.

        PEMBAHAGIAN KERJA (jangan silap panggil): scroll_in_viewport()
        = skrol MENTAH, TIADA carian elemen, `direction` mesti
        'down'/'up'/'left'/'right'. find_with_scroll(locator, ...) =
        CARI elemen (skrol-dan-cari). Panggilan tersalah letak (cth
        `scroll_in_viewport(locator, timeout)`, hujah pertama sebenarnya
        tuple locator) MELEMPAR TypeError terus di bawah -- gagal
        bising dengan mesej yang menamakan pembetulan, bukan diam-diam
        menaip `percent` dari `timeout` orang lain (audit cuakKambing
        2026-07-31: py_compile/collect-only tidak dapat menangkap
        salah-panggil begini kerana kedua-duanya tidak memanggil
        kaedah).

        >>> KERJA KEDUA 2026-07-31 (Loh) -- SKROL YANG MENIPU <<<
        Versi pertama kaedah ini (KERJA PERTAMA hari yang sama) hanya
        mengesahkan `mobile: scrollGesture` DIHANTAR tanpa ralat, dan
        memulangkan True atas dasar itu. Loh mengukur alat devtools\\
        yang setara (`adb shell input swipe` koordinat mentah) pada
        DEVICE SEBENAR dan dapat **anjakan 0px** -- borang langsung
        tidak bergerak walaupun gerak isyarat "berjaya" dihantar. Itu
        TEPAT punca yang membakar tiga run K1: kegagalan skrol
        menyamar sebagai kegagalan locator kerana tiada siapa mengukur
        kesan sebenarnya. Sama ada `mobile: scrollGesture` (elementId)
        vs `input swipe` (koordinat mentah) yang menang PADA DEVICE
        BELUM DIUKUR -- jangan tulis salah satu sebagai fakta sebelum
        ini benar-benar dijalankan pada device.

        Kaedah ini kini TIDAK mempercayai penghantaran gerak isyarat
        sendiri:
          0. Semak dahulu `_skrol_disekat_oleh_overlay()` (empat kelas:
             alert asli / modal RN / dialog ListView / senarai cadangan
             INLINE tab NOTIS -- lihat docstring kaedah itu) -- kalau
             mana-mana terbuka, borang induk BIASANYA tidak boleh
             diskrol sama sekali. Ini dilaporkan DENGAN NAMA (bukan
             cuma "anjakan 0px") dan skrol dilangkau sepenuhnya --
             overlay itu sendiri ada skrol tersendiri (lihat
             select_dropdown_option). Kaedah ini SENGAJA TIDAK menutup
             overlay yang dijumpai -- pemanggil yang mahu menutup/
             memilih overlay dahulu (supaya skrol boleh diteruskan
             selepas itu) guna overlay_blocking_scroll(), versi PUBLIK
             semakan yang sama.
          1. Kira geometri swipe (_kira_swipe): rect bekas boleh-skrol
             Appium (`UiSelector().scrollable(true)`) dahulu, jatuh ke
             SATU JALUR PECAHAN saiz skrin sebenar kalau tiada bekas
             dikesan -- tiada nombor piksel tetap, sama seperti versi
             pertama.
          2. Kalau serial peranti sesi ini diketahui (_device_serial),
             LAKSANA + UKUR guna `device_utils.measure_scroll()` --
             KAEDAH KONGSI yang sama dengan devtools\\sahkan_skrol.py,
             bukan logik banding-y kedua yang ditulis semula di sini
             (arahan Loh eksplisit: "guna semula, jangan tulis logik
             kedua"). `bergerak` dikira BENAR HANYA kalau measure_scroll
             melapor >=1 label DIKONGSI beranjak >ambang_px. Label BARU
             (`hasil['baru']`) BUKAN bukti skrol -- ia turut muncul bila
             overlay/senarai cadangan TERTUTUP tanpa apa-apa menatal
             (K-7, lihat komen dalam kod), jadi dilaporkan berasingan
             sebagai "kandungan berubah", tidak pernah di-OR ke dalam
             `bergerak`. Anjakan 0px DICETAK sebagai amaran eksplisit,
             BUKAN ditelan senyap sebagai "True kerana gerak isyarat
             dihantar" (bug yang dibetulkan hari ini).
          3. Kalau serial TIDAK diketahui (mis. dipanggil luar sesi
             pytest penuh), jatuh kembali ke `mobile: scrollGesture`
             SAHAJA -- tetapi pergerakan sebenarnya DIISYTIHARKAN
             "TIDAK DISAHKAN" dengan jelas dalam log dan
             self.last_scroll_result, bukan dianggap berjaya.

        self.last_scroll_result direkodkan SETIAP panggilan (dict
        measure_scroll() + 'diukur': bool, atau {'ok', 'sebab',
        'diukur': False} untuk overlay/fallback) -- find_with_scroll()
        membacanya untuk membezakan "skrol tidak berkesan" daripada
        "elemen tiada".

        Menutup IME dahulu (tutup_ime()) dan menyemak app masih di
        latar hadapan SELEPAS cubaan (_pastikan_app_di_hadapan) --
        MELEMPAR AssertionError kalau tidak.

        Pulang True HANYA kalau pergerakan SAH (diukur bergerak, atau
        gerak isyarat dihantar dalam laluan fallback tak-terukur).
        False kalau overlay menyekat, pengukuran gagal, ATAU anjakan
        diukur 0px."""
        if direction not in ("down", "up", "left", "right"):
            raise TypeError(
                f"scroll_in_viewport() mengambil ARAH "
                f"('down'/'up'/'left'/'right'), bukan locator -- dapat "
                f"{direction!r} ({type(direction).__name__}). Untuk "
                f"MENCARI elemen (skrol-dan-cari), guna "
                f"find_with_scroll(locator, ...) sebagai ganti.")
        if not isinstance(percent, (int, float)):
            raise TypeError(
                f"scroll_in_viewport() 'percent' mesti nombor (0-1), "
                f"dapat {percent!r} ({type(percent).__name__}) -- tanda "
                f"kemungkinan hujah dihantar ke kedudukan salah (cth "
                f"locator/timeout tertukar dengan direction/percent).")
        import time
        self.tutup_ime()

        sebab_sekat = self._skrol_disekat_oleh_overlay()
        if sebab_sekat:
            print(f"  [SKROL] {context or 'scroll_in_viewport'}: TIDAK "
                  f"cuba skrol -- disekat oleh {sebab_sekat}")
            self.last_scroll_result = {"ok": False, "diukur": False,
                                       "sebab": f"disekat oleh {sebab_sekat}"}
            self._pastikan_app_di_hadapan(
                context=context or "scroll_in_viewport")
            return False

        container = None
        try:
            container = self.driver.find_element(
                AppiumBy.ANDROID_UIAUTOMATOR,
                'new UiSelector().scrollable(true).instance(0)')
        except Exception:                                    # noqa: BLE001
            container = None

        serial = self._device_serial()
        if True:
            # `serial` masih dikira: _kira_swipe menggunakannya untuk
            # saiz skrin apabila tiada bekas boleh-skrol dijumpai. Tetapi
            # pengukuran TIDAK lagi bergantung padanya — ia melalui
            # driver sekarang, jadi laluan ini berjalan walaupun serial
            # tidak dapat dilerai.
            swipe = self._kira_swipe(container, direction, serial)
            try:
                hasil = self._ukur_skrol_melalui_driver(swipe)
            except Exception as e:                           # noqa: BLE001
                hasil = {"ok": False,
                        "sebab": f"pengukuran melalui driver gagal "
                                 f"({type(e).__name__}: {e})"}
            hasil = dict(hasil, diukur=True)
            self.last_scroll_result = hasil
            if not hasil.get("ok"):
                # >>> DIBETULKAN 2026-07-31, run device 20:0x <<<
                # Dahulu baris ini menetapkan `bergerak = False`, iaitu keadaan
                # yang SAMA seperti "borang benar-benar tidak bergerak". Pemanggil
                # (`find_element`/`find_clickable`) melakukan `if not
                # self._scroll_down(): break` -- jadi SATU pengukuran yang gagal
                # membunuh kesemua 10 cubaan skrol selepas cubaan pertama, dan
                # kegagalannya dilaporkan sebagai "Element not clickable ...
                # scroll stopped moving content". Itu menuduh borang atas
                # kesalahan alat pengukur.
                #
                # `measure_scroll()` MELAKUKAN swipe itu sebelum ia cuba
                # mengukur, jadi swipe MEMANG berlaku; yang gagal hanyalah
                # `uiautomator dump` (kerap gagal semasa animasi RN dengan
                # "could not get idle state"). Keadaan jujur ialah
                # TIDAK_DAPAT_DITENTUKAN, bukan "tidak bergerak".
                #
                # Overlay yang menyekat KEKAL memulangkan False lebih awal dalam
                # fungsi ini -- itu memang "jangan cuba lagi". Bezanya penting:
                # DISEKAT = berhenti; TIDAK PASTI = teruskan mencuba.
                hasil["status"] = "TIDAK_DAPAT_DITENTUKAN"
                print(f"  [SKROL] pergerakan TIDAK DAPAT DISAHKAN ({hasil.get('sebab')})"
                      f" -- swipe TETAP dilakukan; meneruskan cubaan seterusnya."
                      f" JANGAN laporkan ini sebagai 'borang tidak bergerak'.")
                self.last_scroll_result = hasil
                return True
            else:
                # K-7 (audit cuakKambing 2026-07-31): BUKTI skrol ialah
                # ANJAKAN-Y elemen yang DIKONGSI antara dua dump SAHAJA
                # (medan 'bergerak' measure_scroll()) -- 'baru' (label
                # muncul HANYA SELEPAS) BUKAN bukti skrol. 'baru' turut
                # meningkat bila senarai cadangan/overlay/alert TERTUTUP
                # tanpa apa-apa menatal -- TEPAT senario yang menyekat
                # tiga run K1 (20 elemen dikongsi, 0 bergerak, anjakan
                # 0px, tetapi senarai tertutup mendedahkan medan di
                # bawah = 'baru' bukan kosong). Dua isyarat BERBEZA,
                # jangan dicampur: 'baru' > 0 bermakna "kandungan
                # berubah", BUKAN "kandungan menatal". NOTA SEJARAH
                # (boleh disemak -- diubah dalam SESI INI, 2026-07-31,
                # bukan dakwaan tentang kod sebelum hari ini yang tiada
                # bukti git untuknya): baris ini pada mulanya saya tulis
                # sebagai `bergerak = hasil.get("bergerak", 0) > 0 or
                # bool(hasil.get("baru"))` semasa draf pertama K-7 dalam
                # sesi ini, sebelum Loh menunjukkan ia akan melaporkan
                # "skrol berjaya" tepat dalam senario yang membakar K1 --
                # dibetulkan kepada baris di bawah dalam sesi yang sama.
                bergerak = hasil.get("bergerak", 0) > 0
                if not bergerak:
                    catatan = (f" (baru={hasil.get('baru')!r} muncul -- "
                              f"kandungan BERUBAH tetapi ini BUKAN bukti "
                              f"menatal)" if hasil.get("baru") else "")
                    print(f"  [SKROL] AMARAN: swipe DIHANTAR tetapi "
                          f"ANJAKAN 0px (dikongsi={hasil.get('dikongsi')}, "
                          f"bergerak=0){catatan} -- borang TIDAK bergerak. "
                          f"Ini BERBEZA daripada 'elemen tiada'; jangan "
                          f"simpulkan locator salah daripada ini sahaja.")
            self._pastikan_app_di_hadapan(
                context=context or "scroll_in_viewport")
            return bergerak

        # Tiada serial diketahui -- fallback mobile:scrollGesture SAHAJA,
        # pergerakan TIDAK DISAHKAN piksel.
        try:
            if container is not None:
                self.driver.execute_script('mobile: scrollGesture', {
                    'elementId': container.id,
                    'direction': direction,
                    'percent': percent,
                })
            else:
                size = self.driver.get_window_size()
                height = size['height']
                self.driver.execute_script('mobile: scrollGesture', {
                    'left': int(size['width'] * 0.1),
                    'top': int(height * 0.20),
                    'width': int(size['width'] * 0.8),
                    'height': int(height * 0.45),
                    'direction': direction,
                    'percent': percent,
                })
            time.sleep(0.3)
            sent = True
        except Exception:                                    # noqa: BLE001
            sent = False
        print(f"  [SKROL] AMARAN: serial peranti tidak diketahui daripada "
              f"sesi Appium -- gerak isyarat {'dihantar' if sent else 'GAGAL dihantar'} "
              f"tetapi pergerakan sebenar TIDAK DISAHKAN piksel")
        self.last_scroll_result = {"ok": sent, "diukur": False,
                                   "sebab": "serial tidak diketahui -- "
                                            "pergerakan tidak disahkan"}
        self._pastikan_app_di_hadapan(context=context or "scroll_in_viewport")
        return sent

    def find_with_scroll(self, locator, max_scrolls=10, timeout_each=3,
                         direction="down"):
        """Cari `locator`; kalau tiada, skrol DALAM viewport
        (scroll_in_viewport) dan cari semula, sehingga `max_scrolls`
        kali, barulah mengaku gagal. Pulang elemen atau `None` --
        TIDAK melempar TimeoutException sendiri (untuk itu guna
        find_element/find_clickable); helper ini untuk pemanggil yang
        perlu MEMUTUSKAN SENDIRI sama ada ketiadaan itu bermakna
        sesuatu (cth jurang kategori D) atau sekadar belum diskrol
        cukup jauh.

        PEMBAHAGIAN KERJA (jangan silap panggil): find_with_scroll() =
        CARI elemen (skrol-dan-cari); scroll_in_viewport(direction=...)
        = skrol MENTAH tanpa carian. `locator` mesti tuple 2-elemen
        (cth (AppiumBy.XPATH, "...")) -- hujah rentetan arah ("down")
        di sini MELEMPAR TypeError terus, gagal bising dan bukan senyap
        (audit cuakKambing 2026-07-31, kelas pepijat sama seperti
        scroll_in_viewport).

        >>> BACA DAHULU SEBELUM MEMPERCAYAI KEPUTUSAN "TIADA" <<<
        `adb shell uiautomator dump` (dan justeru page-source/
        find_element Appium sendiri di bawahnya) MEMBUANG setiap node
        `visible:false` daripada pokok accessibility sepenuhnya --
        disahkan terus daripada logcat device 2026-07-31
        (recon\\PAPAN.md "MULA DI SINI"):
            Skipping invisible child: className: android.widget.Spinner;
              clickable: true; enabled: true; visible: false;
              boundsInScreen: Rect(107, 3567 - 974, 1596)
        Satu keputusan `Spinner: 0` / elemen-tidak-dijumpai daripada
        SATU carian BUKAN bukti elemen itu tiada -- ia mungkin sekadar
        di bawah paparan semasa.

        >>> TETAPI "tiada" SELEPAS SKROL ITU SENDIRI BOLEH MENIPU <<<
        (KERJA KEDUA 2026-07-31, Loh) scroll_in_viewport() kini MENGUKUR
        pergerakan sebenar (device_utils.measure_scroll()), jadi
        gelung ini BERHENTI pada skrol PERTAMA yang gagal bergerak
        (bukan menghabiskan max_scrolls buta) dan melaporkan sebab
        SEBENAR -- BERBEZA daripada "elemen tiada selepas skrol
        berkesan". Menyamakan makna-makna ini ialah tepat kesilapan
        yang membakar tiga run K1.

        >>> TIGA KEADAAN GAGAL, BERBEZA SEPENUHNYA, DIBEZAKAN DALAM
        MESEJ LOG (bukan hanya nilai pulangan -- kedua-duanya `None`) <<<
          1. "SKROL DITOLAK KERANA OVERLAY (disekat oleh ...)" --
             _skrol_disekat_oleh_overlay() mengesan alert asli/modal/
             ListView/senarai cadangan inline SEBELUM skrol dicuba
             langsung. Punca: overlay, bukan borang/locator.
          2. "SKROL TIDAK BERKESAN (anjakan 0px (diukur) / pergerakan
             tidak disahkan)" -- gerak isyarat dihantar (tiada overlay
             dikesan) tetapi measure_scroll() dapat 0px, atau serial
             peranti tidak diketahui jadi pergerakan tidak dapat
             disahkan langsung. Punca: skrol, bukan overlay/locator.
          3. "elemen TIADA selepas N percubaan skrol, SETIAP satu
             BERKESAN" -- gelung menghabiskan max_scrolls, skrol
             bergerak SETIAP kali (measure_scroll() sahkan >0px), tetapi
             locator tidak pernah muncul. Punca paling berkemungkinan
             locator/data (cth jurang kategori D) -- HANYA keadaan ini
             yang menyokong dakwaan begitu.
        Sebelum sesi ini keadaan #3 SENYAP (return None tanpa log) --
        pembaca kegagalan tidak dapat membezakannya daripada #1/#2 tanpa
        membaca last_scroll_result sendiri. Kini ketiga-tiganya
        bercetak.

        Selepas SETIAP skrol ini juga menyemak app masih di latar
        hadapan (lihat scroll_in_viewport) -- gerak isyarat skrol yang
        gagal/tersasar tidak boleh diikuti dengan terus menaip/tap ke
        skrin yang device kebetulan mendarat padanya."""
        if not (isinstance(locator, tuple) and len(locator) == 2):
            raise TypeError(
                f"find_with_scroll() mengambil LOCATOR (tuple 2-elemen "
                f"macam (AppiumBy.XPATH, '...')), bukan arah rentetan -- "
                f"dapat {locator!r} ({type(locator).__name__}). Untuk "
                f"skrol MENTAH tanpa mencari elemen, guna "
                f"scroll_in_viewport(direction=...) sebagai ganti.")
        if self.is_element_present(locator, timeout=timeout_each):
            try:
                return self.driver.find_element(*locator)
            except Exception:                                # noqa: BLE001
                pass
        percubaan_dibuat = 0
        for percubaan in range(max_scrolls):
            percubaan_dibuat = percubaan + 1
            bergerak = self.scroll_in_viewport(direction=direction,
                                               context="find_with_scroll")
            if self.is_element_present(locator, timeout=timeout_each):
                try:
                    return self.driver.find_element(*locator)
                except Exception:                            # noqa: BLE001
                    continue
            if not bergerak:
                hasil = self.last_scroll_result or {}
                sebab = hasil.get("sebab") or ""
                # Tiga keadaan gagal (lihat docstring) -- dibezakan ikut
                # 'sebab' yang scroll_in_viewport() SUDAH rekod dalam
                # last_scroll_result, bukan diteka semula di sini.
                if sebab.startswith("disekat oleh"):
                    keadaan = "SKROL DITOLAK KERANA OVERLAY"
                else:
                    keadaan = "SKROL TIDAK BERKESAN"
                    sebab = sebab or (
                        "anjakan 0px (diukur)" if hasil.get("diukur")
                        else "pergerakan tidak disahkan")
                print(f"  [CARI] find_with_scroll: BERHENTI selepas "
                      f"{percubaan_dibuat} percubaan -- {keadaan} "
                      f"({sebab}), BUKAN 'elemen tiada'. locator={locator}")
                return None
        if percubaan_dibuat == 0:
            print(f"  [CARI] find_with_scroll: elemen tiada dan "
                  f"max_scrolls={max_scrolls} <= 0 -- TIADA skrol dicuba "
                  f"langsung, keputusan ini TIDAK bermakna 'elemen tiada "
                  f"selepas skrol berkesan'. locator={locator}")
        else:
            print(f"  [CARI] find_with_scroll: elemen TIADA selepas "
                  f"{percubaan_dibuat} percubaan skrol, SETIAP satu "
                  f"BERKESAN (pergerakan disahkan >0px) -- keputusan "
                  f"'elemen tiada' SEBENAR (locator/data), BUKAN "
                  f"skrol/overlay. locator={locator}")
        return None

    def _scroll_down(self):
        """Swipe the main content area down by a small increment.

        Thin wrapper kept for its existing internal callers
        (find_element / find_clickable retry loops) -- the real
        implementation is now scroll_in_viewport() (viewport-safe
        swipe via the scrollable container's own bounds, IME handled
        by tutup_ime(), app-foreground asserted after every swipe; see
        its docstring for the 2026-07-31 K1 bug this replaces: the old
        body here swiped a FIXED fraction of the full screen (0.25-0.75
        height), which is exactly the class of bug that stranded three
        K1 runs on a viewport that doesn't span the whole screen).
        Kept as a separate method, not inlined, so this historical name
        stays grep-able for anyone tracing the retry loops, and so
        find_element/find_clickable below don't need to change at all.
        """
        return self.scroll_in_viewport(direction="down", percent=0.3,
                                       context="_scroll_down")

    def find_element(self, locator, timeout=None):
        """Wait for element presence and return it.

        This app's form screens use a ScrollView that only renders
        fields once they've been scrolled into view -- fields below the
        fold are completely absent from the view hierarchy, not just
        off-screen, so a plain wait never finds them. If the element
        isn't present right away, swipe the content up a few times and
        retry before giving up.

        K-4 (audit cuakKambing 2026-07-31): the scroll loop below now
        stops on the FIRST scroll that doesn't move anything (see
        _scroll_down -> scroll_in_viewport, which MEASURES movement via
        device_utils.measure_scroll() instead of trusting a sent
        gesture) -- there's no point retrying a scroll that's already
        proven not to move anything. The final TimeoutException message
        reports how many scroll attempts actually ran, not a blanket
        "incl. scroll attempts" that would overstate it as always 10.

        Also NOTE: if the app leaves the foreground mid-scroll (alert
        stole focus, a stray BACK navigated out, etc.), _scroll_down()
        raises AssertionError (via _pastikan_app_di_hadapan) -- that is
        INTENTIONALLY NOT caught here and propagates straight out of
        find_element, ending the test immediately instead of reporting
        a misleading "element not found". This is a deliberate design
        choice (Loh 2026-07-31), not an oversight: continuing to poll a
        screen we've already left would just produce more confusing
        failures downstream.
        """
        t = timeout or self.timeout
        try:
            return WebDriverWait(self.driver, t).until(
                EC.presence_of_element_located(locator)
            )
        except TimeoutException:
            pass

        # A printer-connection alert may be covering the element -- drain it
        # once and retry before the (slower) scroll loop.
        if self.drain_printer_alert():
            try:
                return WebDriverWait(self.driver, 3).until(
                    EC.presence_of_element_located(locator)
                )
            except TimeoutException:
                pass

        tries = 0
        for _ in range(10):
            tries += 1
            if not self._scroll_down():
                break
            try:
                return WebDriverWait(self.driver, 5).until(
                    EC.presence_of_element_located(locator)
                )
            except TimeoutException:
                continue

        raise TimeoutException(
            f"Element not found after {t}s ({tries} scroll attempt(s) out "
            f"of up to 10 tried -- may have stopped early because a scroll "
            f"stopped moving content, see '[SKROL]' log lines above): "
            f"{locator}"
        )

    def find_clickable(self, locator, timeout=None):
        """Wait for element to be clickable and return it.

        Retries on StaleElementReferenceException by re-resolving the
        locator fresh, not just on TimeoutException. Confirmed via live
        run: the SENARAI menu button can go stale between being located
        and being clicked if the home screen is still settling right
        after go_back_to_home() -- WebDriverWait's own polling doesn't
        recover from a staleness exception on its own, it just propagates
        it, so without this the whole test aborts on what's really just
        a transient timing issue, not a real locator problem.
        """
        t = timeout or self.timeout
        end_time = __import__('time').monotonic() + t
        while True:
            try:
                return WebDriverWait(self.driver, t).until(
                    EC.element_to_be_clickable(locator)
                )
            except StaleElementReferenceException:
                if __import__('time').monotonic() >= end_time:
                    break
                continue
            except TimeoutException:
                break

        # A printer-connection alert may be covering the target -- drain it
        # once and retry before the keyboard/scroll fallbacks.
        if self.drain_printer_alert():
            try:
                return WebDriverWait(self.driver, 3).until(
                    EC.element_to_be_clickable(locator)
                )
            except (TimeoutException, StaleElementReferenceException):
                pass

        # The on-screen keyboard from a preceding type action can
        # cover buttons like SETERUSNYA (especially on smaller
        # screens or after the last field in a tab). Try dismissing
        # it and retrying once before giving up.
        try:
            if self.driver.is_keyboard_shown():
                print("  [INFO] Keyboard is covering the screen, "
                      "hiding it and retrying...")
                self.driver.hide_keyboard()
                import time
                time.sleep(0.5)
                return WebDriverWait(self.driver, t).until(
                    EC.element_to_be_clickable(locator)
                )
        except Exception:
            pass

        # Same lazy-render issue as find_element -- the target may
        # simply not exist in the hierarchy yet because it's below
        # the fold. Scroll and retry before giving up.
        #
        # K-4: same fix as find_element -- loop stops early on the first
        # scroll that measures no movement (see _scroll_down), message
        # below reports actual attempts, and an AssertionError from
        # _pastikan_app_di_hadapan (app left foreground mid-scroll) is
        # INTENTIONALLY left uncaught here -- see find_element's
        # docstring for why.
        tries = 0
        for _ in range(10):
            tries += 1
            if not self._scroll_down():
                break
            try:
                return WebDriverWait(self.driver, 5).until(
                    EC.element_to_be_clickable(locator)
                )
            except (TimeoutException, StaleElementReferenceException):
                continue

        raise TimeoutException(
            f"Element not clickable after {t}s ({tries} scroll attempt(s) "
            f"out of up to 10 tried -- may have stopped early because a "
            f"scroll stopped moving content, see '[SKROL]' log lines "
            f"above): {locator}"
        )

    def tap_element(self, el):
        """Tap the center of an element using a raw coordinate touch
        gesture instead of el.click() (which sends an accessibility
        ACTION_CLICK). Several custom RN Touchables/Pressables in this
        app don't wire up a real onClick accessibility action -- Appium
        finds them fine and click() reports success, but nothing happens
        in the app (confirmed via screen recording: the Jalan suggestion
        dropdown stayed open indefinitely across a full click() call).
        A genuine touch-down/up at the element's coordinates works where
        click() silently no-ops.
        """
        rect = el.rect
        x = rect['x'] + rect['width'] // 2
        y = rect['y'] + rect['height'] // 2
        self.driver.tap([(x, y)])

    def is_element_present(self, locator, timeout=5):
        """Check if an element is present without throwing.

        >>> AUDIT 2026-07-31 (cuakKambing, recon\\PAPAN.md) -- BACA DAHULU <<<
        SATU-VIEWPORT SAHAJA, SENGAJA -- kaedah ini TIDAK skrol. Banyak
        pemanggil bergantung tepat pada itu (pengesanan alert asli,
        pengesanan overlay 'SEDANG DIPROSES', semakan pantas dalam
        gelung retry/tap-sah) -- mereka bertanya "adakah ia KELIHATAN
        SEKARANG, tanpa kesan sampingan", dan menambah skrol di sini
        akan memperlahankan SETIAP satu daripada ~150 tapak panggilan
        DAN mengubah kedudukan skrin sebagai kesan sampingan yang tidak
        diminta -- pepijat baharu menimpa pepijat lama. Jangan "baiki"
        ini dengan menambah skrol terus di sini.

        SEBALIKNYA: `False` daripada kaedah ini BUKAN BUKTI KETIADAAN.
        `uiautomator dump` MEMBUANG setiap node `visible:false`
        sepenuhnya (CLAUDE.md; recon\\PAPAN.md "MULA DI SINI") -- elemen
        di bawah fold hilang terus daripada pokok yang WebDriverWait
        tunggu, bukan sekadar susah dicari. cuakKambing mengesan 47
        cabang `not ....is_element_present(...)` merentas pages\\ (base_
        _page.py termasuk) yang berpotensi menyalah-tafsir "di bawah
        paparan" sebagai "tiada dalam build/DB" -- disenaraikan +
        diklasifikasi ("kelihatan sekarang?" vs "wujud?") dalam
        recon\\PAPAN.md.

        Kalau soalan SEBENAR pemanggil ialah "adakah elemen ini WUJUD
        pada skrin/borang ini" (bukan "kelihatan sekarang tanpa
        berbuat apa-apa"), guna is_element_present_after_scroll() atau
        find_with_scroll() sebagai GANTI -- lihat kaedah itu."""
        try:
            WebDriverWait(self.driver, timeout).until(
                EC.presence_of_element_located(locator)
            )
            return True
        except (TimeoutException, NoSuchElementException):
            return False

    def is_element_present_after_scroll(self, locator, timeout=5,
                                        max_scrolls=10):
        """Pasangan EKSPLISIT bagi is_element_present() untuk soalan
        "adakah elemen ini WUJUD" (bukan "kelihatan sekarang").

        Sama tandatangan/pulangan (`bool`) dengan is_element_present()
        supaya ia drop-in pada tapak panggilan yang MEMANG bertanya
        wujud -- tetapi skrol dalam viewport (scroll_in_viewport, lewat
        find_with_scroll) dan cari semula sebelum mengaku False, supaya
        "tiada" tidak silap tafsir daripada "di bawah fold" (lihat
        amaran visible:false dalam docstring is_element_present()).

        JANGAN gunakan ini untuk pengesanan alert/overlay/keadaan pantas
        dalam gelung retry -- skrol di sini BERKESAN SAMPINGAN (mengubah
        kedudukan skrin) dan lebih perlahan; is_element_present() kekal
        betul untuk kes itu. Kaedah ini untuk soalan "wujud dalam
        borang/skrin ini" sahaja -- cth pengesahan medan/dropdown/baris
        wujud dalam build/DB semasa (audit cuakKambing 2026-07-31,
        senarai penuh tapak panggilan dalam recon\\PAPAN.md)."""
        return self.find_with_scroll(locator, max_scrolls=max_scrolls,
                                     timeout_each=timeout) is not None

    def is_text_visible(self, text, timeout=5):
        """Check if text is visible on screen."""
        locator = (AppiumBy.ANDROID_UIAUTOMATOR,
                   f'new UiSelector().textContains("{text}")')
        return self.is_element_present(locator, timeout)

    # ------------------------------------------------------------------
    # Pengesahan "Berjaya" — perangkap subrentetan
    # ------------------------------------------------------------------
    # "BERJAYA" ialah subrentetan "TIDAK BERJAYA". is_text_visible() guna
    # textContains, jadi `is_text_visible("Berjaya")` memulangkan True pada
    # alert "Penghantaran Tidak Berjaya" -> create yang GAGAL diisytihar
    # LULUS. Kelas pepijat yang sama sudah dibunuh dalam
    # printer_utils.classify_message() (semak token GAGAL dahulu); ia
    # terlepas pada laluan CREATE. Jangan sekali-kali guna
    # is_text_visible("Berjaya") secara langsung.
    #
    # C-14 (recon\kontrak_by_number.md §5) — EJAAN APP TIDAK KONSISTEN.
    # Fakta device, dibaca Loh sendiri 2026-07-30 pada APK 2.1.33-Dev /
    # Armor 27 (reports\fasa2-bootstrap.md §2.3, dump
    # ui_dumps\10_lesen_m50_selepas_simpan.xml):
    #     dialog LESEN   : tajuk text="BEJAYA"   <- TIADA huruf 'R'
    #     alert  Selaras : tajuk text="BERJAYA"  <- ejaan betul
    # Dua ejaan dalam BUILD YANG SAMA. Bug app (kategori B), bukan tekaan.
    # Regex '.*berjaya.*' TIDAK memadan "BEJAYA" -> gerbang create boleh
    # mati bagi kelima-lima -001 sekaligus (C-14).
    #
    # Toleransi = 'ber?jaya' SAHAJA (huruf R hilang, kerana itu yang
    # DILIHAT pada device). JANGAN longgarkan kepada '.*jaya.*' atau
    # '.*disimpan.*': "DATA TIDAK DISIMPAN" akan padan dan create yang
    # GAGAL menjadi LULUS.
    #
    # PENAFIAN dibawa naik dengan toleransi ejaan yang SAMA dan tetap
    # disemak DAHULU (lihat is_berjaya_message_visible). Tanpa itu,
    # "TIDAK BEJAYA" terlepas penafian dan padan BERJAYA_SAH -> PASS
    # palsu (Peraturan Keras #2). Bentuk negatif diperluas kepada
    # tidak|belum|gagal + \btak\b: sempadan perkataan pada 'tak' WAJIB
    # kerana "CETAK BERJAYA" mengandungi "TAK BERJAYA" sebagai
    # subrentetan — corak yang sama sudah diuji dalam
    # printer_utils.PENAFI_PATTERN.
    BERJAYA_DINAFI = (AppiumBy.ANDROID_UIAUTOMATOR,
                      'new UiSelector().textMatches('
                      '"(?i)(?s).*(tidak|\\\\btak\\\\b|belum|gagal)'
                      '\\\\s*ber?jaya.*")')
    BERJAYA_SAH = (AppiumBy.ANDROID_UIAUTOMATOR,
                   'new UiSelector().textMatches("(?i)(?s).*ber?jaya.*")')

    def is_berjaya_message_visible(self, timeout=5, context=""):
        """True hanya jika mesej kejayaan hadir DAN tiada penafian.

        Penafian disemak DAHULU. Kembali False (bukan True) apabila
        "Tidak Berjaya"/"Tidak Bejaya" kelihatan — itu kegagalan yang
        mesti dilaporkan, bukan kejayaan. JANGAN pecahkan susunan
        kegagalan-dahulu ini: "BERJAYA" ialah subrentetan
        "TIDAK BERJAYA".

        Casing badan alert kini DISAHKAN huruf besar pada device
        (`LESEN SAMA.`, `DATA PENGGUNA BERJAYA DISIMPAN!` —
        reports\\fasa2-bootstrap.md §2.3). textMatches di sini
        case-insensitive, jadi ia betul untuk kedua-dua casing.

        # SAHKAN-DEVICE: ejaan dialog kejayaan CREATE (Notis Amaran /
        # Daftar Kompaun) masih TIDAK diketahui — Loh mengesahkan
        # `BEJAYA` pada dialog LESEN dan `BERJAYA` pada alert Selaras,
        # bukan pada dialog create. Toleransi 'r?' menampung kedua-dua
        # kemungkinan, jadi pembetulan ini betul tanpa jawapan; tetapi
        # pada create PERTAMA, dump teks alert sebenar dan rekod ejaan
        # TEPATNYA di sini (kontrak C-14, semakan penerimaan).
        """
        tag = f"[{context}] " if context else ""
        if self.is_element_present(self.BERJAYA_DINAFI, timeout=timeout):
            print(f"  {tag}Alert MENAFIKAN kejayaan "
                  f"('tidak berjaya' kelihatan) — FAIL")
            return False
        if self.is_element_present(self.BERJAYA_SAH, timeout=1):
            print(f"  {tag}Mesej kejayaan kelihatan — PASS")
            return True
        return False

    def wait_and_click(self, locator, timeout=None):
        """Wait for element and click it."""
        el = self.find_clickable(locator, timeout)
        el.click()
        return el

    def wait_and_tap(self, locator, timeout=None):
        """Wait for element and tap it with a raw coordinate touch.
        Use instead of wait_and_click for this app's custom RN
        Pressables, which silently no-op on the accessibility
        ACTION_CLICK that el.click() sends (see tap_element).

        Re-resolves the locator on StaleElementReferenceException --
        confirmed via live run: a just-opened RN popup (Menu Selaras)
        can still be re-rendering when find_clickable returns, so the
        element handle dies in the gap before tap_element reads its
        rect. Same transient-staleness pattern already handled inside
        find_clickable itself, which can't help here because the
        staleness fires after it has already returned."""
        import time
        last_exc = None
        for _ in range(3):
            el = self.find_clickable(locator, timeout)
            try:
                self.tap_element(el)
                return el
            except StaleElementReferenceException as e:
                last_exc = e
                time.sleep(0.5)
        raise last_exc

    def wait_and_send_keys(self, locator, text, timeout=None):
        """Wait for element, clear, and type text."""
        el = self.find_element(locator, timeout)
        el.clear()
        if text:
            el.send_keys(text)
        return el

    def wait_for_text(self, text, timeout=None):
        """Wait for a text element to appear."""
        locator = (AppiumBy.ANDROID_UIAUTOMATOR,
                   f'new UiSelector().textContains("{text}")')
        return self.find_element(locator, timeout)

    def _ci_label_locator(self, label_text):
        """Build a case-insensitive UiAutomator locator for a field label.

        This app renders the same conceptual label in inconsistent casing
        depending on which screen it's on (e.g. Pesalah tab's fields are
        ALL CAPS, the Notis/Kompaun tab's Jalan/Taman/etc. are Title Case,
        and ID PENGUATKUASA on Notis Kompaun turned out to not match the
        assumed all-caps guess either). Rather than keep discovering this
        one field at a time, match case-insensitively via a regex so the
        actual on-screen casing never matters.
        """
        import re
        escaped = re.escape(label_text)
        return (AppiumBy.ANDROID_UIAUTOMATOR,
                f'new UiSelector().textMatches("(?i)^{escaped}$")')

    def _hide_keyboard_if_shown(self):
        """Proactively dismiss the keyboard, if present.

        Confirmed via live run: waiting for a keyboard-covered button to
        time out before checking for/hiding the keyboard (the old
        reactive pattern still used as a last-resort fallback in
        find_clickable) costs a real ~15-20s stall every time it happens
        -- most noticeably right after filling the last field in a tab
        (e.g. Maklumat Negeri) and immediately clicking Seterusnya.
        Hiding it right after typing avoids ever hitting that stall in
        the first place, for the common case where a fill really is the
        last interaction before a click.
        """
        try:
            if self.driver.is_keyboard_shown():
                self.driver.hide_keyboard()
        except Exception:
            pass

    def tutup_ime_tanpa_back(self):
        """Tutup papan kekunci TANPA semantik Back — selamat di dalam
        modal RN yang boleh ditutup.

        >>> KENAPA INI WUJUD (diukur 2026-08-04, N-004). <<<
        `_hide_keyboard_if_shown()` memanggil `driver.hide_keyboard()`,
        yang pada Android menghantar Back. CLAUDE.md sudah merekodnya:
        "hide_keyboard() bertindak macam Back -> ia menutup modal RN".
        Pada popup SILA ISI KETERANGAN, panggilan itu MEMUSNAHKAN popup,
        dan kod pemanggil kemudian melaporkan "keterangan popup got
        dismissed" — menyalahkan app atas kerosakan yang ia sendiri
        sebabkan. Kelas yang sama seperti gerbang IP yang dahulu
        melancarkan semula app lalu menolak bacaannya sendiri.

        `mobile: performEditorAction` menghantar tindakan IME (done/next)
        terus kepada medan input. Ia menutup papan kekunci tanpa
        melalui butang Back, jadi susunan modal tidak disentuh.

        Pulang True kalau IME memang terbuka dan satu tindakan dihantar.
        """
        try:
            if not self.driver.is_keyboard_shown():
                return False
        except Exception:                                    # noqa: BLE001
            pass
        for tindakan in ("done", "next"):
            try:
                self.driver.execute_script(
                    'mobile: performEditorAction', {'action': tindakan})
                return True
            except Exception:                                # noqa: BLE001
                continue
        # SENGAJA tiada fallback kepada hide_keyboard()/Back di sini:
        # pemanggil yang tahu skrinnya TIADA modal boleh memanggil
        # _hide_keyboard_if_shown() sendiri. Kaedah ini berjanji "tanpa
        # Back", dan janji itu tidak boleh dilanggar secara senyap.
        print("  [IME] performEditorAction gagal; IME dibiarkan terbuka "
              "(tidak menekan Back — itu akan menutup modal RN)")
        return False

    @staticmethod
    def _norm(s):
        """Normalize a field value for comparison (strip + upper)."""
        return (s or "").strip().upper()

    def _safe_text(self, el):
        """Read el.text without throwing (stale/detached -> None)."""
        try:
            return el.text
        except Exception:                                    # noqa: BLE001
            return None

    # ---- SATU-SATUNYA tapak 'mobile: type' dalam suite ------------------
    # >>> PUNCA DISAHKAN DENGAN UKURAN 2026-08-04: HURUF 'r'. <<<
    #
    # `mobile: type` meranapkan app dengan redbox RN
    # (`Could not connect to development server.` /
    # BundleDownloader.java:126). Puncanya BUKAN panjang rentetan.
    #
    # Rantaiannya: `mobile: type` menghantar peristiwa kekunci SEBENAR ->
    # dua 'r' dibaca sebagai KEYCODE_R, KEYCODE_R -> pintasan menu dev RN
    # (`DoubleTapReloadRecognizer`, tetingkap ~200ms) mencetuskan RELOAD ->
    # APK ini build Dev tetapi tiada Metro server berjalan -> muat turun
    # bundle GAGAL -> `BundleDownloader.onFailure` -> redbox.
    #
    # Bukti A — dump tersimpan `ui_dumps/jejak_redbox_akhir.xml` membawa
    # footer redbox `RELOAD\n(R,\xa0R)` (NBSP, bukan ruang biasa) bersama
    # `onFailure`, `BundleDownloader.java:126`, `RealCall.kt:525`.
    #
    # Bukti B — matriks pemisah `devtools/ukur_pencetus_redbox.py`,
    # dijalankan pada device, app dilancar semula antara setiap varian.
    # Lajur logcat = bilangan baris reload/bundle sejak logcat dikosongkan
    # tepat sebelum taipan:
    #
    #     rentetan                 len  'r'  keputusan  logcat
    #     blank dari test script    22   2   REDBOX       2
    #     RR                         2   2   REDBOX       2      <-- 2 aksara
    #     AB                         2   0   OK           0
    #     AAAAAAAAAAAAAAAAAAAAAA    22   0   OK           0      <-- 22 aksara
    #     blank dazi test scdipt    22   0   OK           0
    #     AAAAAAAAAA AAAAAAAAAAA    22   0   OK           0
    #
    # `RR` meranap pada DUA aksara dan 22 aksara tanpa 'r' LULUS: panjang
    # tersingkir dua kali. Ruang tersingkir (baris terakhir), huruf besar/
    # kecil tersingkir (dua baris tengah). Baris logcat muncul HANYA pada
    # percubaan yang meranap — korelasi sempurna, bukan kebetulan.
    #
    # >>> KATEGORI A. Kita menekan pintasan dev sendiri. BUKAN bug app. <<<
    # JANGAN laporkan kepada pembangun MBJB. Ia BERBEZA daripada redbox
    # NK-001 (`TypeError: Cannot read property 'props' of undefined`,
    # hermes) yang ralat JS tulen — itu kekal KATEGORI B.
    #
    # >>> DASAR <<<
    # 1. `send_keys` ialah laluan LALAI. Ia menetapkan teks melalui node
    #    dan TIDAK menghantar satu keycode pun, jadi ia tidak boleh
    #    mencetuskan pintasan dev. Itu sebab varian C lulus dengan teks
    #    yang SAMA.
    # 2. `mobile: type` hanya untuk medan yang MENOLAK `send_keys`
    #    (bertopeng/berangka) atau yang MEMERLUKAN peristiwa kekunci
    #    sebenar (carian langsung RN onChangeText). Setiap tapak sebegitu
    #    membawa sebabnya bertulis di tempatnya.
    # 3. Bila `mobile: type` wajib, rentetan dipecah supaya tiada satu
    #    panggilan membawa lebih daripada SATU 'r', dengan jeda
    #    `_JEDA_R` antara panggilan yang membawa 'r'. Dua KEYCODE_R
    #    dengan itu tidak boleh jatuh dalam tetingkap yang sama.
    #
    # Pemalar jeda seaksara 0.25s yang lama sudah DIBUANG. Ia tidak lagi
    # menjadi asas keselamatan, dan pemalar yang orang sangka melindungi
    # sesuatu lebih buruk daripada tiada pemalar. Rentetan TANPA 'r' kini
    # dihantar dalam SATU panggilan — tiada kos langsung.
    #
    # TIDAK dilakukan, dengan sebab: menyisipkan kekunci "tak berbahaya"
    # antara dua 'r'. Dalam app ini kekunci perkakasan MENGGERAKKAN FOKUS
    # — itulah tepatnya mekanisme `reveal_below_fold()` (TAB 61 / DPAD 20).
    # Menyuntik keycode di tengah taipan boleh memindahkan fokus keluar
    # dari medan dan menaip ke tempat lain. Ia juga tidak menyelesaikan
    # apa-apa: yang menutup tetingkap double-tap ialah MASA, bukan
    # kehadiran kekunci lain.
    #
    # PEMBUNUH KELAS SEBENAR (bukan pengelakan): APK **Release**, atau
    # sokongan dev dimatikan pada peranti ujian. Itu keputusan pemilik/
    # pembangun — tiada suis adb yang boleh dipercayai untuknya.
    _JEDA_R = 0.7              # > tetingkap ~200ms, dengan margin lebar

    def _mobile_type(self, value):
        """Satu-satunya laluan ke `mobile: type` dalam suite ini.

        Setiap tapak lain menghalakan ke sini. Lihat blok dasar di atas.
        """
        import time as _t
        value = "" if value is None else str(value)
        if value.lower().count("r") < 2:
            # 0 atau 1 'r' tidak boleh menjadi double-tap. Satu panggilan.
            self.driver.execute_script('mobile: type', {'text': value})
            return
        # Pecah supaya setiap kepingan membawa paling banyak SATU 'r',
        # dan 'r' itu berada di HUJUNG kepingan — jadi jarak masa antara
        # dua KEYCODE_R sekurang-kurangnya _JEDA_R.
        kepingan, semasa = [], ""
        for ch in value:
            semasa += ch
            if ch in ("r", "R"):
                kepingan.append(semasa)
                semasa = ""
        if semasa:
            kepingan.append(semasa)
        print(f"  [TAIP] {len(kepingan)} kepingan (mengandungi "
              f"{value.lower().count('r')} 'r'; pintasan RELOAD (R,R) RN)")
        for i, kep in enumerate(kepingan):
            self.driver.execute_script('mobile: type', {'text': kep})
            if i != len(kepingan) - 1:
                _t.sleep(self._JEDA_R)

    def _dedah_sebelum_cari(self, locator, nama, max_tabs=8):
        """Dedahkan `locator` melalui reveal_below_fold() SEBELUM
        mencarinya, kalau ia belum kelihatan pada viewport semasa.

        >>> KENAPA INI WUJUD (recon\\PAPAN.md "MULA DI SINI",
        ">>> PENEMUAN: BORANG NOTIS MENOLAK GESTURE SKROL, TERIMA
        TRAVERSAL FOKUS <<<") <<< Bukti dari SATU larian, borang yang
        SAMA:
            gesture skrol (base_page._scroll_down -> mobile: scrollGesture)
                'KOD AKTA'     10 cubaan -> TIDAK dijumpai
                'OPEN CAMERA'  10 cubaan -> TIDAK dijumpai
                'SETERUSNYA'   10 cubaan -> TIDAK dijumpai
                Spinner dilihat: 1
            reveal_below_fold()  (edits[-1].click() + TAB 61 / DPAD_DOWN 20)
                Spinner dilihat: 3, dengan pilihan PENUH
        Tab NOTIS Notis Amaran MBJB ialah borang kelas traversal-fokus,
        sama seperti Kemaskini / HantarSemula / Notis-to-Kompaun.
        find_element/find_clickable/find_with_scroll SEMUA bergantung
        pada gesture skrol biasa -- TIDAK BOLEH dipercayai pada borang
        ini. Pemanggil mesti dedahkan sasaran dengan kaedah ini DAHULU,
        sebelum mencarinya dengan cara biasa.

        Corak (Loh): cuba cara sedia ada dahulu (carian pada viewport
        semasa); kalau tiada, reveal_below_fold(), kemudian cari
        semula. Kalau MASIH tiada selepas traversal -- GAGAL dengan
        mesej yang menamakan KEDUA-DUA laluan yang dicuba, sama seperti
        _spinner_ikut_indeks() melaporkan kedua-dua laluan pengenalan
        Spinner (label DAN sandaran indeks) apabila kedua-duanya gagal.
        Mesej bermaklumat > mesej pendek.
        """
        # >>> A3, 2026-08-05: HADIR != KELIHATAN. <<<
        # Bentuk lama memulangkan True sebaik `is_element_present` benar.
        # Itu menjawab soalan yang SALAH: ia bermakna "ada dalam pokok
        # view", bukan "ada dalam viewport". Bookmark gagal DUA run
        # berturut-turut dengan mesej yang menamakan puncanya sendiri:
        #     label 'KETERANGAN KOD KOMPAUN' dijumpai (y=2257..2316)
        #     tetapi TIADA Spinner di bawahnya. 0 Spinner keseluruhan.
        # y=2257 jauh di bawah sempadan borang (~1596), jadi label itu
        # HADIR tetapi di luar paparan — pintasan awal menelan traversal,
        # dan Spinner adiknya yang lebih ke bawah tidak pernah didedahkan.
        # Menambah traversal pada pilih_spinner_kod() tidak membantu
        # kerana pintasan ini berlaku LEBIH AWAL.
        if self.is_element_present(locator, timeout=3) and                 self._dalam_paparan(locator):
            return True
        print(f"  [NOTIS AMARAN] {nama} tidak kelihatan pada viewport "
              f"semasa (laluan 1: carian biasa -- GAGAL) -- mencuba "
              f"reveal_below_fold() traversal fokus (laluan 2)...")
        self.reveal_below_fold(locator, max_tabs=max_tabs)
        if self.is_element_present(locator, timeout=3):
            print(f"  [NOTIS AMARAN] {nama} didedahkan oleh "
                  f"reveal_below_fold() -- laluan 2 BERJAYA")
            return True
        self._dump_mbjb(f"mbjb_{self._tag(nama)}_dedah_gagal.xml")
        raise AssertionError(
            f">>> {nama} TIDAK DIJUMPAI selepas KEDUA-DUA laluan dicuba "
            f"<<< (1) carian biasa pada viewport semasa -- tiada; "
            f"(2) reveal_below_fold() traversal fokus TAB(61)/"
            f"DPAD_DOWN(20), max_tabs={max_tabs} -- MASIH tiada selepas "
            f"traversal. Borang NOTIS menolak gesture skrol dan HANYA "
            f"menerima traversal fokus (recon\\PAPAN.md 'MULA DI SINI'). "
            f"Kalau traversal turut gagal, sama ada skrin belum sampai "
            f"ke tab NOTIS langsung, atau elemen ini benar-benar tiada "
            f"pada build ini -- dump disimpan untuk pengesahan manual. "
            f"locator={locator!r}")

    def _dalam_paparan(self, locator):
        """True kalau elemen itu bukan sahaja HADIR, tetapi berada dalam
        kawasan yang benar-benar dipaparkan.

        Sempadan diambil daripada bekas boleh-skrol kalau ada (itu yang
        mengeratkan borang RN ini), kalau tidak daripada tinggi skrin.
        Gagal-terbuka: kalau sempadan tidak dapat ditentukan, pulangkan
        True supaya kelakuan lama dikekalkan dan tiada laluan baharu
        diperkenalkan secara senyap.
        """
        try:
            el = self.find_element(locator, timeout=3)
            r = el.rect
        except Exception:                                    # noqa: BLE001
            return True
        bawah = None
        try:
            for b in self._find_all_by_resource_id(self.MODAL_SURFACE_ID):
                rb = b.rect
                if rb["height"] > 200:
                    bawah = rb["y"] + rb["height"]
                    break
        except Exception:                                    # noqa: BLE001
            pass
        if bawah is None:
            try:
                bawah = self.driver.get_window_size()["height"]
            except Exception:                                # noqa: BLE001
                return True
        tengah = r["y"] + r["height"] // 2
        kelihatan = 0 <= tengah <= bawah
        if not kelihatan:
            print(f"  [PAPARAN] elemen HADIR tetapi di luar paparan "
                  f"(tengah y={tengah}, sempadan={bawah}) — traversal "
                  f"tetap dijalankan")
        return kelihatan

    _jangkaan_autoisi = None      # diisi oleh conftest ikut TC

    # Label -> nama medan, untuk laporan auto-isi.
    _MEDAN_AUTOISI = ("taman", "poskod", "bandar", "negeri")

    def _rekod_autoisi_pesalah(self, jalan):
        """BACA taman/poskod/bandar/negeri selepas Jalan dipilih, dan
        rekod nilai SEBENAR yang app papar.

        Ini menggantikan taipan (keputusan pemilik 2026-08-05). Ia
        MENGUKUR, ia tidak menghakimi: kalau satu medan kosong, itu
        direkod sebagai kosong dan borang diteruskan. Kegagalan sebenar,
        kalau ada, datang daripada app menolak SIMPAN — dan itu keadaan
        sebenar app, bukan sesuatu untuk ditampal di sini.

        Nilai ditulis ke reports/autoisi_pesalah.json supaya laporan
        akhir boleh menyebut nilai sebenar bagi setiap sampel jalan,
        bukan sekadar "lulus".
        """
        import json
        import os
        label = {
            "taman": self.LABEL_PESALAH_TAMAN,
            "poskod": self.LABEL_PESALAH_POSKOD,
            "bandar": self.LABEL_PESALAH_BANDAR,
            "negeri": self.LABEL_PESALAH_NEGERI,
        }
        # >>> LOCATOR IKUT LABEL DIBUANG DI SINI. 2026-08-06. <<<
        # Bentuk lama mencari setiap medan dengan _ci_label_locator(label).
        # Itu MUSTAHIL berfungsi untuk tugas ini: `text` EditText ialah
        # PLACEHOLDER, jadi ia HILANG sebaik medan diisi. Maka setiap medan
        # yang app BERJAYA auto-isi dilaporkan sebagai "tidak dapat dibaca",
        # dan setiap medan yang KOSONG dilaporkan sebagai ""; pembaca itu
        # hanya boleh mengesan KEGAGALAN auto-isi. Run smoke 2026-08-06
        # melaporkan keempat-empat medan "tidak dapat dibaca" — itu artifak
        # locator, bukan fakta app.
        # Ganti: sauh pada medan JALAN (nilai yang kita PILIH sendiri, jadi
        # kita tahu teksnya) + baca JIRAN berturutan. Urutan JALAN -> TAMAN
        # -> POSKOD -> BANDAR -> NEGERI disahkan pada dump device untuk
        # KEDUA-DUA borang (lihat _indeks_medan_jalan).
        idx, medan = self._indeks_medan_jalan(
            str(jalan).split("|")[0].strip() if jalan else "")
        if idx is None:
            print(f"  [AUTO-ISI] sauh GAGAL: tiada EditText memegang "
                  f"{jalan!r}. EditText yang ada: "
                  f"{[t for _i, _e, t in medan]!r}")
        elif idx + len(self._MEDAN_AUTOISI) >= len(medan):
            # Jiran di bawah lipatan: uiautomator MEMBUANG node
            # visible:false, jadi ia benar-benar TIADA dalam pokok view.
            # Tutup IME dahulu (borang tidak boleh diskrol semasa IME
            # terbuka — CLAUDE.md) kemudian baca semula SEKALI.
            print(f"  [AUTO-ISI] hanya {len(medan)} EditText dalam pokok "
                  f"view (sauh {idx}); jiran di bawah lipatan — menutup "
                  f"IME dan membaca semula")
            self.tutup_ime_tanpa_back()
            idx, medan = self._indeks_medan_jalan(
                str(jalan).split("|")[0].strip() if jalan else "")
        dibaca = {}
        for offset, nama in enumerate(self._MEDAN_AUTOISI, start=1):
            nilai = None
            j = None if idx is None else idx + offset
            if j is not None and j < len(medan):
                nilai = medan[j][2]
                # `text` EditText ialah PLACEHOLDER bila kosong — jadi
                # nilai yang sama dengan labelnya bermakna KOSONG, bukan
                # terisi. Perangkap ini sudah direkod dalam CLAUDE.md.
                if nilai is not None and \
                        self._norm(nilai) == self._norm(label[nama]):
                    nilai = ""
            dibaca[nama] = nilai
        # >>> ASSERT, bukan sekadar rekod. 2026-08-06. <<<
        # Oracle kini membawa nilai auto-isi yang DIJANGKA di dalam nota
        # sel, diambil daripada skrin rekod manual pemilik
        # JBM50P260806001 — rekod PERTAMA yang disahkan sampai ke DB
        # utama. Maka bacaan ini boleh dibandingkan, bukan sekadar
        # dicatat. Ketidakpadanan ialah PENEMUAN (data selaras mungkin
        # berubah) — nilai SEBENAR dilaporkan, tiada tampalan.
        # Dicari ikut NAMA JALAN, bukan ikut TC: halaman tidak tahu TC
        # mana ia jalankan, dan jangkaan itu memang sifat JALAN (baris
        # selaras), bukan sifat TC.
        jangka = {}
        try:
            from testdata.excel_data import (JANGKAAN_AUTOISI,
                                             TC_DATA as _TD)
            for _tc, _j in JANGKAAN_AUTOISI.items():
                for _medan, _nilai in (_j or {}).items():
                    if self._norm(_TD.get(_tc, {}).get(_medan)) ==                             self._norm(jalan):
                        jangka = _nilai
                        break
                if jangka:
                    break
        except Exception:                                    # noqa: BLE001
            jangka = {}
        if jangka:
            for k, dijangka in jangka.items():
                got = dibaca.get(k)
                if got is None:
                    print(f"  [AUTO-ISI] {k}: tidak dapat dibaca "
                          f"(dijangka {dijangka!r}) — tidak disahkan")
                elif self._norm(got) != self._norm(dijangka):
                    print(f"  [AUTO-ISI] >>> TIDAK PADAN <<< {k}: app beri "
                          f"{got!r}, oracle jangka {dijangka!r}")
                else:
                    print(f"  [AUTO-ISI] {k} = {got!r} — PADAN jangkaan")
        kosong = [k for k, v in dibaca.items() if v == ""]
        print(f"  [AUTO-ISI] selepas pilih {jalan!r}:")
        for k, v in dibaca.items():
            rupa = ("(KOSONG)" if v == ""
                    else "(tidak dapat dibaca)" if v is None else repr(v))
            print(f"      {k:8} = {rupa}")
        if kosong:
            print(f"  [AUTO-ISI] {len(kosong)} medan KOSONG: "
                  f"{', '.join(kosong)} — app TIDAK mengisinya. Suite "
                  f"TIDAK menaip gantinya (keputusan pemilik 2026-08-05).")
        try:
            jalan_path = os.path.join(
                os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                "reports", "autoisi_pesalah.json")
            semua = {}
            if os.path.exists(jalan_path):
                with open(jalan_path, encoding="utf-8") as fh:
                    semua = json.load(fh)
            semua[str(jalan)] = dibaca
            with open(jalan_path, "w", encoding="utf-8") as fh:
                json.dump(semua, fh, ensure_ascii=False, indent=2)
        except Exception as e:                               # noqa: BLE001
            print(f"  [AUTO-ISI] tidak dapat menulis fail rekod: "
                  f"{type(e).__name__}")
        return dibaca

    def _emit_text(self, el, value, use_mobile_type):
        """Type `value` into an already-focused field.

        send_keys DAHULU sentiasa (ia tidak pernah meranapkan app dalam
        mana-mana varian yang diukur); `mobile: type` hanya bila pemanggil
        memintanya atau send_keys menolak medan itu.
        """
        if use_mobile_type:
            self._mobile_type(value)
        else:
            try:
                el.send_keys(value)
            except Exception:                                # noqa: BLE001
                # Some masked/numeric fields reject send_keys with
                # InvalidElementStateException -- fall back to mobile:type.
                self._mobile_type(value)

    def _medan_kosong(self, el):
        """(kosong, teks_semasa) — adakah EditText ini benar-benar kosong?

        Medan kosong dalam app ini memaparkan PLACEHOLDER dalam atribut
        `text` (cth 'NAMA PESALAH'), jadi teks bukan-kosong TIDAK
        bermakna medan berisi. `hint` membezakannya: apabila medan
        kosong, text == hint.
        """
        semasa = (self._safe_text(el) or "").strip()
        if not semasa:
            return True, ""
        try:
            hint = (el.get_attribute("hint") or "").strip()
        except Exception:                                    # noqa: BLE001
            hint = ""
        if hint and semasa == hint:
            return True, ""
        return False, semasa

    def _force_clear(self, el):
        """Kosongkan RN EditText — TANPA kerja yang tidak perlu.

        >>> DITULIS SEMULA 2026-08-10 selepas pemerhatian pemilik. <<<
        Versi MBJB menekan backspace 30 KALI TANPA SYARAT, walaupun medan
        sudah kosong. Pada video run 11:03 itu kelihatan sebagai backspace
        bertalu-talu pada medan username kosong sebelum 'msc' ditaip —
        2-3 saat terbuang PADA SETIAP MEDAN. Merentas borang N-001 penuh
        itu menjadi kelewatan yang ketara, dan ia menyembunyikan
        pergerakan sebenar dalam rakaman.

        Urutan baharu (spesifikasi pemilik):
          1. Baca nilai semasa.
          2. Kosong / placeholder sahaja -> JANGAN kosongkan langsung.
          3. Ada isi -> el.clear() dahulu; backspace hanya sebagai
             sandaran kalau clear() gagal, dan bilangannya = panjang teks
             SEBENAR yang dibaca, bukan 30 tetap.
          4. Sahkan medan kosong sebelum pemanggil menaip.

        Sebab asal untuk paksaan kasar itu KEKAL BENAR: el.clear() memang
        kerap diabaikan oleh RN (no-op accessibility yang sama yang
        menjadikan el.click() tidak berkesan), dan dengan no_reset=True
        nilai run sebelumnya boleh bertahan lalu teks baharu bercantum.
        Jadi sandaran itu dikekalkan — cuma ia tidak lagi berjalan apabila
        tiada apa untuk dipadam.

        Pulangkan True kalau medan disahkan kosong pada akhirnya.
        """
        # Fokus dahulu: papan kekunci mesti ada untuk menaip, dan ini juga
        # yang menjadikan bacaan seterusnya mencerminkan medan aktif.
        try:
            el.click()
        except Exception:                                    # noqa: BLE001
            try:
                self.tap_element(el)
            except Exception:                                # noqa: BLE001
                pass

        kosong, semasa = self._medan_kosong(el)
        if kosong:
            return True

        try:
            el.clear()
        except Exception:                                    # noqa: BLE001
            pass

        kosong, semasa = self._medan_kosong(el)
        if kosong:
            return True

        # clear() diabaikan — paksa melalui peristiwa kekunci perkakasan,
        # yang MEMANG sampai ke input.
        print(f"  [CLEAR] el.clear() diabaikan; sandaran kekunci untuk "
              f"{len(semasa)} aksara")
        try:
            self.driver.press_keycode(29, 4096)   # KEYCODE_A + META_CTRL_ON
            self.driver.press_keycode(112)        # KEYCODE_FORWARD_DEL
        except Exception:                                    # noqa: BLE001
            pass

        kosong, semasa = self._medan_kosong(el)
        if kosong:
            return True

        try:
            self.driver.press_keycode(123)        # KEYCODE_MOVE_END
            # Panjang SEBENAR + margin kecil untuk aksara yang ditapis
            # (pemisah ribu, topeng). Bukan 30 tetap.
            for _ in range(len(semasa) + 2):
                self.driver.press_keycode(67)     # KEYCODE_DEL (backspace)
        except Exception:                                    # noqa: BLE001
            pass

        kosong, baki = self._medan_kosong(el)
        if not kosong:
            print(f"  [CLEAR] AMARAN: medan masih berisi {baki!r} selepas "
                  f"clear + sandaran kekunci")
        return kosong

    def fill_field_by_label(self, label_text, value, timeout=None,
                             use_mobile_type=False, keep_keyboard=False,
                             verify=True):
        """Find any EditText whose current text/placeholder matches
        label_text (case-insensitive), click it, clear it, and type value.

        Set use_mobile_type=True for fields that reject plain send_keys()
        (e.g. numeric/masked inputs that throw 'invalid element state').

        Set keep_keyboard=True for fields inside dismissible RN modals
        (e.g. the Tarik Notis popup): hide_keyboard can behave like a
        Back press, which closes the whole modal -- confirmed via live
        dump that the Tarik Notis popup was gone immediately after its
        ID field was filled.

        verify=True (default): after typing, read the field back and, if
        it doesn't hold `value`, FORCE-clear (el.clear() is silently
        ignored by this app's RN inputs -- see _force_clear) and retype,
        up to 3x. NON-fatal -- if it still can't confirm it logs a WARNING
        and returns, so fields that legitimately reformat their input
        (autocomplete, masks) don't fail the run; the field's own
        validation surfaces anything that truly matters downstream. Pass
        verify=False to skip (e.g. before an autocomplete pick changes the
        text out from under the check).
        """
        # >>> SETIAP BEKU MESTI ADA NAMA. 2026-08-06. <<<
        # Analisis rakaman skrin (552 frame, 9m12s) menunjukkan 79% masa
        # run ialah skrin BEKU, dan dua beku terbesar (121s dan 133s)
        # jatuh TEPAT di sekitar medan borang yang diisi melalui kaedah
        # ini: ladder locator find_element membakar tempoh tunggu penuh
        # pada setiap cubaan yang tersasar. Log ini TIDAK mempercepatkan
        # apa-apa dengan sendirinya — ia menjadikan beku itu BOLEH
        # DIBACA dalam log, supaya yang dibaiki kemudian ialah yang
        # betul-betul mahal dan bukan yang disyaki.
        import time as _t_masa
        _t0_isi = _t_masa.time()
        locator = self._ci_label_locator(label_text)
        el = self.find_element(locator, timeout)
        _t_cari = _t_masa.time() - _t0_isi
        if _t_cari > 10:
            print(f"  [TIMING] BEKU {_t_cari:.0f}s: mencari medan "
                  f"'{label_text}' (find_element + ladder skrol). Medan ini "
                  f"berkemungkinan di bawah lipatan — dedahkan dengan "
                  f"_dedah_sebelum_cari() dahulu kalau borang ini kelas "
                  f"traversal-fokus.")

        el.click()
        try:
            el.clear()
        except Exception:                                    # noqa: BLE001
            pass
        self._emit_text(el, value, use_mobile_type)

        if verify:
            # OPPORTUNISTIC verify: act only on a value we can actually READ
            # and that is clearly WRONG (e.g. a stale '90' that survived a
            # failed clear). If the field can't be read back -- el.text
            # returns None because an RN live-search re-render staled the
            # handle, and the placeholder locator no longer matches now the
            # field holds a value -- assume the type landed and move on.
            # Force-clearing an UNREADABLE field would risk corrupting a
            # value that is actually fine (this bit the MAKLUMAT JALAN
            # autocomplete field). The 0-21-validated Tempoh field has its
            # own re-resolving verifier (_set_tempoh_verified) for the case
            # a stale value must be caught even when the handle goes stale.
            def _read_back():
                got = self._safe_text(el)
                if got is None:
                    try:
                        return self._safe_text(
                            self.find_element(locator, timeout=2))
                    except Exception:                        # noqa: BLE001
                        return None
                return got

            got = _read_back()
            if got is not None and self._norm(got) == self._norm(label_text):
                # Read-back equals the label/placeholder: the field still
                # shows its placeholder -- it's empty (the type didn't land)
                # OR we matched a label element, NOT a wrong value.
                # Force-clearing + retyping via the same locator won't help
                # and just churns keycodes (this stormed on the "MAKLUMAT
                # KOMPAUN" tempoh header, which is why tempoh now has its own
                # EditText-scoped setter). Log once and move on; a DIFFERENT
                # non-empty value (a stale '90') is the real bug-2 case and
                # still gets force-cleared below.
                print(f"  [FILL] NOTE: '{label_text}' still shows its "
                      f"placeholder after typing (field empty or the label "
                      f"matched a non-field element) -- not force-clearing")
            elif got is not None and self._norm(got) != self._norm(value):
                for attempt in range(3):
                    print(f"  [FILL] '{label_text}' shows {got!r}, expected "
                          f"{value!r} (attempt {attempt + 1}/3) -- "
                          f"force-clear + retype")
                    self._force_clear(el)
                    self._emit_text(el, value, use_mobile_type)
                    got = _read_back()
                    if got is None or self._norm(got) == self._norm(value):
                        break
                if got is not None and self._norm(got) != self._norm(value):
                    print(f"  [FILL] WARNING: '{label_text}' still shows "
                          f"{got!r} after retries (expected {value!r}) -- "
                          f"continuing; downstream validation will surface "
                          f"it if it matters")

        if not keep_keyboard:
            self._hide_keyboard_if_shown()
        return el

    def fill_field_by_label_if_blank(self, label_text, value, timeout=3,
                                      use_mobile_type=False):
        """Same as fill_field_by_label, but a no-op if the field no longer
        shows label_text as its placeholder.

        Some fields in this app (e.g. Taman/Bandar/Negeri on the Notis/
        Kompaun tabs) get auto-filled as a side effect of picking an
        autocomplete suggestion on a sibling field (Jalan). When that
        auto-fill already happened, the placeholder text is gone and a
        plain fill_field_by_label would wait out the full timeout and
        raise TimeoutException.

        Confirmed via live run: doing this as a separate
        is_element_present() check followed by a second find_element()
        call is a race -- the auto-fill can land in the gap between the
        two lookups, so the first check sees the placeholder (not yet
        auto-filled) but the second lookup for the same locator then
        finds nothing and raises anyway. Use a single bounded lookup
        instead (not find_element, which falls back to a multi-round
        scroll-and-retry loop on timeout -- fine when a field is
        expected to exist, but here "not found" usually just means
        it's genuinely already filled, and scrolling around hunting for
        placeholder text that will never reappear would turn a fast
        skip into a ~60s wait).

        Confirmed via live run: even a single lookup isn't quite enough
        -- the auto-fill can also land in the gap between resolving the
        element and acting on it, raising StaleElementReferenceException
        out of el.click() instead of the presence check ever failing.
        Treat that the same as "already filled": it can only mean the
        DOM node we just found got replaced by the auto-fill an instant
        later, not any other kind of failure on a freshly-resolved
        element.
        """
        locator = self._ci_label_locator(label_text)
        try:
            el = WebDriverWait(self.driver, timeout).until(
                EC.presence_of_element_located(locator)
            )
        except TimeoutException:
            print(f"  [INFO] '{label_text}' already has a value "
                  f"(likely auto-filled) -- skipping")
            return None
        try:
            el.click()
            el.clear()
            # DIHALAKAN 2026-08-04: baris ini dahulu menduakan cabang
            # _emit_text TANPA fallback send_keys->mobile:type, jadi ia
            # memintas pengawal seaksara sepenuhnya.
            self._emit_text(el, value, use_mobile_type)
            self._hide_keyboard_if_shown()
            return el
        except StaleElementReferenceException:
            print(f"  [INFO] '{label_text}' got auto-filled while we were "
                  f"about to type into it -- skipping")
            return None

    # --- TAMBAHAN MBJB (aditif; tiada baris SALIN-BULAT diubah) -----------
    # Fakta device, Loh 2026-07-30, dump ui_dumps/50_selepas_seterusnya.xml:
    # pada tab NOTIS borang Notis Amaran, medan alamat kesalahan
    #   MAKLUMAT TAMAN / MAKLUMAT POSKOD / MAKLUMAT BANDAR / MAKLUMAT NEGERI
    # semuanya enabled="false" clickable="false" -- app mengisinya sendiri
    # dari MAKLUMAT JALAN. Menaip ke dalamnya BUKAN "belum diuji", ia
    # MUSTAHIL: el.click() tidak mendaftar dan send_keys melempar
    # InvalidElementStateException, yang akan mematikan gerbang create.
    # MBIP menaip medan itu kerana pada 2.1.17 ia boleh ditaip.
    def fill_field_by_label_if_editable(self, label_text, value, timeout=4,
                                        use_mobile_type=False,
                                        sumber_excel=""):
        """Taip HANYA kalau medan itu benar-benar boleh diedit.

        Pulangkan salah satu:
          'diisi'         — medan enabled, nilai ditaip
          'auto:<nilai>'  — medan DILUMPUHKAN dan sudah mengandungi nilai
                            (app auto-populate; itu yang Excel jangka)
          'auto:KOSONG'   — medan DILUMPUHKAN dan MASIH KOSONG. Ini
                            penemuan, bukan kegagalan kita: app sepatutnya
                            mengisinya. Dicetak sebagai AMARAN dengan sel
                            Excel yang menjangkanya supaya laporan boleh
                            menamakannya.
          'tiada'         — medan tidak dijumpai sama sekali.

        Kaedah ini TIDAK assert. Pemanggil/test yang memutuskan, kerana
        sama ada 'auto:KOSONG' itu bug app atau jurang data jalan tertentu
        BELUM DISAHKAN (satu sampel sahaja — reports\\fasa2-bootstrap.md
        §2.4 "Auto-populate alamat — SEPARA").
        """
        locator = self._ci_label_locator(label_text)
        try:
            el = WebDriverWait(self.driver, timeout).until(
                EC.presence_of_element_located(locator)
            )
        except TimeoutException:
            # Placeholder hilang = medan sudah berisi (auto-populate) --
            # cari nilai sebenarnya untuk dilaporkan, jangan senyap.
            print(f"  [ALAMAT] '{label_text}': placeholder sudah hilang "
                  f"(medan berisi / auto-populate) -- tidak menaip")
            return "auto:(placeholder hilang)"
        try:
            enabled = (el.get_attribute("enabled") or "").lower() == "true"
        except Exception:                                    # noqa: BLE001
            enabled = True
        if enabled:
            self.fill_field_by_label(label_text, value, timeout=timeout,
                                     use_mobile_type=use_mobile_type)
            return "diisi"
        try:
            semasa = (el.text or "").strip()
        except Exception:                                    # noqa: BLE001
            semasa = ""
        # `text` sebuah EditText ialah PLACEHOLDER bila kosong (fakta
        # device §2.4), jadi teks == label bermakna MASIH KOSONG.
        kosong = (not semasa or
                  " ".join(semasa.upper().split()) ==
                  " ".join(str(label_text).upper().split()))
        if kosong:
            print(f"  [ALAMAT] AMARAN: '{label_text}' DILUMPUHKAN "
                  f"(enabled=false) dan MASIH KOSONG selepas pilihan "
                  f"MAKLUMAT JALAN. App sepatutnya auto-populate medan "
                  f"ini{(' — ' + sumber_excel) if sumber_excel else ''}. "
                  f"Tidak menaip (mustahil), tidak mereka nilai.")
            return "auto:KOSONG"
        print(f"  [ALAMAT] '{label_text}' DILUMPUHKAN, auto-populate = "
              f"{semasa!r} — tidak menaip")
        return f"auto:{semasa}"

    def fill_field_by_label_or_instance(self, label_text, value, instance=0,
                                         use_mobile_type=False,
                                         label_timeout=4):
        """Fill a field normally located by its placeholder text, with
        fallbacks for when the placeholder is gone because the field
        already holds a previously-saved value.

        Needed for the settings screens (Tetapan Alamat IP / Tetapan
        Pelbagai): with no_reset=True their fields keep whatever value
        the last run saved, so the placeholder text (which is how
        fill_field_by_label finds fields in this app) only ever exists
        on the very first run against a fresh install. Confirmed via
        live run: the run right after the first successful IP save
        failed with 'INTERNAL IP ADDRESS' not found after 15s.

        Tiers:
        1. Placeholder text still showing (fresh install) -> normal fill.
        2. An EditText already holding exactly `value` (the common case:
           last run saved the same value we're about to type) -> skip
           typing entirely, nothing to change.
        3. EditText by class + instance index (field holds some OTHER
           stale/partial value) -> clear it and type. Least precise
           tier, so it's last; `instance` is the field's position among
           the ACTIVE CONTAINER's EditTexts (document per call site).

        >>> B1 — TIER 3 DIHADKAN KEPADA BEKAS AKTIF (pembetulan bedah) <<<
        Sebelum ini tier 3 menggunakan indeks EditText **GLOBAL** (seluruh
        pokok accessibility). Itu SELAMAT pada borang penuh-skrin, tetapi
        MEROSAKKAN DATA pada modal.

        FAKTA DEVICE (Loh 2026-07-30, APK 2.1.33-Dev):
          * ui_dumps\\03_tetapan_alamat_ip.xml — semasa modal Tetapan
            terbuka, pokok global mengandungi 4 EditText:
              [0] text='msc'  (username LOGIN, di BELAKANG modal)
              [1] password='true' (password LOGIN, di belakang modal)
              [2] resource-id='text-input-outlined' (INTERNAL IP)
              [3] resource-id='text-input-outlined' (EXTERNAL IP)
          * ui_dumps\\08_tetapan_pelbagai.xml — sama: [0]/[1] medan LOGIN,
            [2] medan LESEN APLIKASI.
          ⇒ `instance(0)` global pada skrin itu ialah medan USERNAME.
            Tier 3 lama akan MENAIP IP / LESEN KE DALAM KREDENTIAL LOGIN,
            secara senyap, dan mematahkan setiap log masuk selepasnya.
          * Kedua-dua dump menunjukkan medan modal berada di bawah
            resource-id='modal-surface'; medan login TIDAK.
          * ui_dumps\\41_notis_amaran_borang.xml — TIADA `modal` sama sekali
            dan 7 EditText global sepadan 1:1 dengan 7 medan tab PESALAH.
            Jadi bila tiada modal, skrin ITULAH bekas aktif dan indeks
            global memang betul (laluan notis_amaran/daftar_kompaun tidak
            berubah kelakuan).

        Dasar baharu: bila `modal`/`modal-surface` ADA pada skrin, indeks
        dikira DALAM modal-surface paling dalam sahaja. Kalau bekas aktif
        tidak dapat ditentukan dengan yakin (modal ada tanpa surface, atau
        surface tidak cukup medan), kaedah ini **MELEMPAR** — gagal dengan
        bising lebih baik daripada menaip kredential ke medan salah.
        """
        # Tier 1: placeholder (bounded single lookup -- find_element's
        # scroll-retry loop would burn ~60s on these short screens).
        #
        # Retry on staleness: this app restores a saved "MAKLUMAT PESALAH
        # TELAH DI SIMPAN" draft and re-renders the Pesalah form a beat
        # after it first appears, so a field found the instant the tab
        # opens can go stale between the lookup and send_keys -- confirmed
        # live on a cold start (two consecutive P-001 runs died here). The
        # old `except TimeoutException` let that staleness propagate and
        # fail the whole create. Re-resolve and retry before falling
        # through to tiers 2/3.
        import time as _t
        locator = self._ci_label_locator(label_text)
        for _attempt in range(3):
            try:
                el = WebDriverWait(self.driver, label_timeout).until(
                    EC.presence_of_element_located(locator)
                )
                el.click()
                el.clear()
                self._emit_text(el, value, use_mobile_type)   # DIHALAKAN
                self._hide_keyboard_if_shown()
                return el
            except TimeoutException:
                break
            except StaleElementReferenceException:
                print(f"  [INFO] '{label_text}' went stale mid-fill (form "
                      f"re-render) -- re-resolving (attempt {_attempt + 1}/3)")
                _t.sleep(0.6)

        # Tier 2: field already holds the target value.
        value_locator = (
            AppiumBy.ANDROID_UIAUTOMATOR,
            f'new UiSelector().className("android.widget.EditText")'
            f'.text("{value}").instance({instance})')
        try:
            el = WebDriverWait(self.driver, 3).until(
                EC.presence_of_element_located(value_locator)
            )
            print(f"  [INFO] '{label_text}' already holds '{value}' "
                  f"(saved by a previous run) -- leaving as-is")
            return el
        except TimeoutException:
            pass

        # Tier 3: positional fallback — SCOPED to the active container
        # (see the B1 note in this docstring). Never global when a modal
        # is up.
        print(f"  [INFO] '{label_text}' placeholder gone and current value "
              f"differs from target -- falling back to EditText "
              f"instance({instance}) within the ACTIVE CONTAINER and "
              f"retyping")
        el = self._editext_in_active_container(instance, label_text)
        el.click()
        el.clear()
        self._emit_text(el, value, use_mobile_type)           # DIHALAKAN
        self._hide_keyboard_if_shown()
        return el

    # ---- B1: bekas aktif untuk pemilihan ikut indeks ---------------------
    # Locator RN modal, disahkan pada device: modal -> modal-backdrop
    # (content-desc='Close modal') -> modal-wrapper -> modal-surface.
    # Bilangan modal-surface = kedalaman sarang (fasa2-bootstrap.md §2.4).
    MODAL_ROOT_ID = "modal"
    MODAL_SURFACE_ID = "modal-surface"

    def _find_all_by_resource_id(self, resource_id):
        """Semua elemen dengan resource-id itu, senarai kosong kalau tiada.
        Implicit wait dimatikan supaya probe 'tiada modal' tidak membakar
        tempoh tunggu penuh pada setiap medan borang biasa."""
        from config import IMPLICIT_WAIT
        loc = (AppiumBy.ANDROID_UIAUTOMATOR,
               f'new UiSelector().resourceId("{resource_id}")')
        self.driver.implicitly_wait(0)
        try:
            return self.driver.find_elements(*loc)
        except Exception:                                        # noqa: BLE001
            return []
        finally:
            self.driver.implicitly_wait(IMPLICIT_WAIT)

    def _editext_in_active_container(self, instance, label_text=""):
        """EditText ke-`instance` DALAM bekas aktif.

        Bekas aktif = modal-surface paling dalam bila modal terbuka,
        atau seluruh skrin bila tiada modal. Lihat nota B1 dalam
        fill_field_by_label_or_instance() untuk bukti device.

        MELEMPAR (bukan meneka) apabila bekas aktif tidak dapat
        ditentukan: menaip ke medan yang salah — pada skrin Tetapan itu
        bermakna menaip IP/lesen ke dalam username/password login —
        merosakkan data secara senyap dan mematahkan setiap log masuk
        selepasnya. Kegagalan bising boleh dibaca dalam log; kerosakan
        senyap tidak.
        """
        nama = f"'{label_text}' " if label_text else ""
        surfaces = self._find_all_by_resource_id(self.MODAL_SURFACE_ID)
        if not surfaces:
            modals = self._find_all_by_resource_id(self.MODAL_ROOT_ID)
            if modals:
                raise AssertionError(
                    f"{nama}pemilihan ikut indeks DITOLAK: '"
                    f"{self.MODAL_ROOT_ID}' ada pada skrin tetapi tiada '"
                    f"{self.MODAL_SURFACE_ID}' — bekas aktif tidak dapat "
                    f"ditentukan. Indeks EditText GLOBAL pada skrin bermodal "
                    f"menunjuk ke medan di BELAKANG modal (pada skrin Tetapan: "
                    f"username/password login — ui_dumps\\"
                    f"03_tetapan_alamat_ip.xml). Guna locator ikut resource-id "
                    f"(cth 'text-input-outlined', lihat "
                    f"pelarasan_page._isi_input_outlined), bukan indeks.")
            # Tiada modal: skrin ITULAH bekas aktif -> indeks global BETUL
            # (disahkan ui_dumps\41_notis_amaran_borang.xml: 0 modal,
            # 7 EditText = 7 medan tab PESALAH).
            return self.find_element(
                (AppiumBy.ANDROID_UIAUTOMATOR,
                 f'new UiSelector().className("android.widget.EditText")'
                 f'.instance({instance})'), timeout=10)

        # Modal terbuka: yang TERAKHIR dalam urutan dokumen ialah modal
        # TERATAS, iaitu yang menerima input.
        # FAKTA DEVICE (ui_dumps\03_tetapan_alamat_ip.xml,
        # 08_tetapan_pelbagai.xml): kedua-dua 'modal-surface' berada pada
        # KEDALAMAN YANG SAMA — ia ADIK-BERADIK (dua tetingkap modal
        # bertindan), BUKAN benar-benar tersarang. surface[0] = popup MENU
        # SELARAS, surface[1] = modal TETAPAN, dan medan
        # 'text-input-outlined' (IP / LESEN) berada dalam surface[1].
        # Jadi pemilihan ikut urutan dokumen TERAKHIR = betul; jangan
        # tukar kepada "paling dalam" ikut kedalaman, ia tidak membezakan.
        surface = surfaces[-1]
        try:
            fields = surface.find_elements(AppiumBy.CLASS_NAME,
                                           "android.widget.EditText")
        except Exception as e:                                   # noqa: BLE001
            raise AssertionError(
                f"{nama}gagal menyenaraikan EditText dalam "
                f"'{self.MODAL_SURFACE_ID}' ({type(e).__name__}: {e}). "
                f"MENOLAK jatuh ke indeks global — lihat nota B1.") from e
        if instance >= len(fields):
            raise AssertionError(
                f"{nama}instance({instance}) diminta tetapi modal aktif "
                f"('{self.MODAL_SURFACE_ID}', {len(surfaces)} tersarang) "
                f"hanya mengandungi {len(fields)} EditText. MENOLAK jatuh ke "
                f"indeks EditText GLOBAL: pada skrin bermodal indeks itu "
                f"menunjuk ke medan LOGIN di belakang modal dan akan menaip "
                f"nilai ini ke dalam kredential (ui_dumps\\"
                f"03_tetapan_alamat_ip.xml, ui_dumps\\08_tetapan_pelbagai.xml).")
        print(f"  [INFO] {nama}indeks {instance} dikira DALAM "
              f"'{self.MODAL_SURFACE_ID}' ({len(fields)} EditText; "
              f"{len(surfaces)} surface tersarang) -- bukan indeks global")
        return fields[instance]

    def type_and_select_suggestion(self, label_text, partial_text,
                                    suggestion_text=None, timeout=None):
        """Tap a field by its current label/placeholder text, type a
        partial value to trigger an autocomplete dropdown, then tap a
        suggestion row that appears.

        Uses 'mobile: type' instead of send_keys() for the partial text.
        These autocomplete fields are React Native controlled inputs
        wired to an onChangeText lookup, same as the Tempoh Notis field —
        plain send_keys() sets the value without firing real key events,
        so the app's live-search never triggers and no suggestion list
        renders (this was the actual cause of suggestions "not appearing").

        If suggestion_text is given, taps that exact row with
        verify-and-retry (same silent-no-op-tap protection as the menu
        items, kompaun-code dropdowns, and TARIK): after each tap it
        checks the row actually left the screen, re-tapping up to 3
        times. If the row appeared but never registers a tap, this
        RAISES rather than silently substituting a different suggestion
        into the test data.

        >>> 2026-08-06: bila satu baris DINAMAKAN dan baris itu TIDAK ADA,
        kaedah ini MELEMPAR — ia TIDAK LAGI jatuh ke "baris pertama". <<<
        Sandaran itu memilih alamat orang lain secara SENYAP; lihat
        catatan penuh di dalam badan kaedah. Baris pertama kekal sah
        HANYA bila pemanggil tidak menamakan apa-apa (contoh di bawah).
        Selepas pemilihan berjaya, medan jalan DIBACA BALIK dan mesti
        memegang nama yang diminta.

        Example: type_and_select_suggestion(
            "MAKLUMAT TAMAN", "T", "TIDAK DINYATAKAN | SEKITAR MASAI"
        )
        """
        field_locator = self._ci_label_locator(label_text)
        el = self.find_element(field_locator, timeout)
        el.click()
        el.clear()
        # SENGAJA `mobile: type`, BUKAN send_keys: medan ini ialah input
        # terkawal RN yang disambung kepada carian langsung onChangeText.
        # send_keys menetapkan nilai tanpa peristiwa kekunci sebenar, jadi
        # carian langsung tidak pernah dicetuskan dan senarai cadangan
        # tidak pernah muncul (punca sebenar "cadangan tidak keluar").
        # Ia lalu _mobile_type supaya pengawal seaksara terpakai di sini
        # juga — laluan ini menaip nilai dari testdata, dan C9 CORRECTED
        # membawa rentetan panjang yang mengandungi 'r'.
        self._mobile_type(partial_text)

        import time

        # >>> SANDARAN "BARIS PERTAMA" DIBUANG. 2026-08-06, KESELAMATAN. <<<
        # Bentuk lama: kalau baris yang DINAMAKAN tidak dijumpai, ia mengetuk
        # "first available suggestion row". Dengan penapis 'JALAN JAGONG',
        # baris pertama boleh jadi MANA-MANA jalan JAGONG -> baris selaras
        # SALAH -> taman/poskod SALAH, dan ia berlaku SENYAP. Itu tepat kelas
        # pepijat pick-first yang Peraturan Keras #7 larang (bentuk lain
        # kelas yang sama pernah memilih AKTA yang salah).
        #
        # Lebih buruk pada widget ini: baris PERTAMA dialog tab PESALAH ialah
        # PROMPT 'PILIH JALAN | TAMAN' (dump 43) dan satu-satunya TextView
        # berpaip pada borang ialah LABEL Spinner dengan teks yang SAMA
        # (dump 42, clickable=false). Jadi "baris pertama" bukan sekadar
        # berisiko — ia memang BUKAN cadangan, dan tapnya tidak memilih
        # apa-apa: senarai kekal TERBUKA, auto-isi tidak berlaku, dan
        # SETERUSNYA kekal disekat. Itulah rantaian kegagalan smoke
        # 2026-08-06 (reports\smoke_n001.txt baris 176-191).
        if suggestion_text:
            sasaran = str(suggestion_text)
            # >>> NAIKKAN KE DUA SAUH BILA ORACLE TAHU TAMANNYA. <<<
            # 2026-08-06, bukti video: satu nama jalan boleh muncul BEBERAPA
            # kali dengan taman berbeza. Sasaran satu-bahagian akan memilih
            # yang pertama dijumpai. Taman diambil dari JANGKAAN_AUTOISI
            # (sel oracle), bukan direka — kalau oracle senyap, sasaran
            # kekal satu bahagian dan taman dibiar kepada DB.
            if "|" not in sasaran:
                _taman = self._taman_dijangka(sasaran)
                if _taman:
                    sasaran = f"{sasaran} | {_taman}"
                    print(f"  [CADANGAN] sasaran dinaikkan ke DUA SAUH "
                          f"guna taman oracle: {sasaran!r} — nama jalan "
                          f"berganda tidak lagi boleh memilih taman salah")
            bentuk = "DUA SAUH" if "|" in sasaran else "AWALAN JALAN"
            print(f"  [CADANGAN] menunggu baris {bentuk} {sasaran!r}"
                  + ("" if "|" in sasaran else " — taman dibiar kepada DB"))
            mula = time.time()
            tenggat = mula + (timeout or 15)
            target_el, baris = None, []
            spinner_dicuba = False
            while time.time() < tenggat:
                baris = self._kutip_baris_cadangan()
                target_el = self._padan_baris_cadangan(baris, sasaran)
                if target_el is not None:
                    break
                # >>> FAKTA DEVICE 2026-08-06: pada tab PESALAH cadangan
                # TIDAK dirender sendiri — ia tersembunyi DI BELAKANG
                # Spinner dan hanya keluar selepas Spinner itu DITAP. <<<
                # Bukti: ui_dumps\cadangan_tidak_padan.xml (run 2026-08-06,
                # selepas menaip 'JALAN JAGONG'): medan memegang teks
                # penapis, Spinner ADA dengan label 'PILIH JALAN | TAMAN',
                # dan SIFAR ListView/CheckedTextView pada skrin. Dump 43
                # (senarai 14 baris) diambil SELEPAS Spinner ditap.
                # Ini juga menerangkan run 14:41: sandaran baris-pertahai
                # mengetuk LABEL Spinner itu, yang MEMBUKA dialog dan
                # meninggalkannya terbuka — sebab itu log berkata
                # "disekat oleh senarai (ListView) terbuka" selepasnya.
                if (not baris and not spinner_dicuba
                        and time.time() - mula > 3):
                    spinner_dicuba = True
                    # Hasilnya DIGUNA TERUS, bukan dikutip semula. Diukur
                    # 2026-08-06: membuka dialog dan membaca 13 baris
                    # memakan cukup masa untuk tenggat asal tamat, dan
                    # laporan kegagalan kemudian berkata "0 baris" tentang
                    # senarai 13 baris yang JELAS terbuka dalam dumpnya
                    # sendiri. Kutipan semula juga membazir satu pusingan
                    # penuh bacaan teks.
                    baris = self._buka_spinner_cadangan(el, partial_text)
                    target_el = self._padan_baris_cadangan(baris, sasaran)
                    if target_el is not None:
                        break
                    tenggat = max(tenggat, time.time() + 10)
                time.sleep(0.5)
            if target_el is None:
                self._lapor_cadangan_tidak_padan(label_text, partial_text,
                                                 sasaran, baris)
            # Tap koordinat mentah, bukan el.click() -- disahkan melalui
            # rakaman skrin bahawa el.click() (ACTION_CLICK) tidak
            # berkesan secara SENYAP pada baris tersuai ini. Tap mentah
            # pun boleh flake, jadi baris mesti DISAHKAN hilang; sama
            # seperti setiap tap kritikal lain dalam suite ini.
            for cubaan in range(3):
                self.tap_element(target_el)
                time.sleep(0.8)
                target_el = self._padan_baris_cadangan(
                    self._kutip_baris_cadangan(), sasaran)
                if target_el is None:
                    break                # baris hilang = tap DIDAFTARKAN
                print(f"  [WARN] baris {sasaran!r} masih terpapar selepas "
                      f"tap (cubaan {cubaan + 1}/3) -- tap semula...")
            if target_el is not None:
                laluan = self._dump_ui("cadangan_tap_tidak_daftar.xml")
                raise TimeoutException(
                    f"baris cadangan {sasaran!r} KELIHATAN tetapi 3 tap "
                    f"tidak pernah mendaftarkan pemilihan; MENOLAK bertukar "
                    f"kepada baris lain — itu akan menyelitkan alamat orang "
                    f"lain ke dalam data ujian. Dump: {laluan}")
            # >>> BACA-BALIK WAJIB. Pemilihan tidak dipercayai; ia DISAHKAN.
            self._sahkan_jalan_dibaca_balik(sasaran)
            return el

        # Tiada baris DINAMAKAN oleh pemanggil -> baris pertama memang
        # niat pemanggil (contoh dalam docstring: "MAKLUMAT TAMAN", "T").
        # Baris PROMPT sudah dibuang oleh _kutip_baris_cadangan().
        tenggat = time.time() + 10
        baris = []
        while time.time() < tenggat:
            baris = self._kutip_baris_cadangan()
            if baris:
                break
            time.sleep(0.5)
        if baris:
            print(f"  [CADANGAN] tiada baris dinamakan — mengambil baris "
                  f"PERTAMA {baris[0][0]!r} ({len(baris)} baris dipapar)")
            self.tap_element(baris[0][1])
        else:
            # Tiada senarai muncul langsung (bukan isu padanan teks —
            # tiada apa dirender). Nilai yang ditaip dibiarkan seperti
            # ada. NOTA: bermakna medan yang app biasanya auto-isi dari
            # pemilihan (poskod/bandar/negeri) kekal kosong — kalau
            # langkah kemudian gagal kerana itu, ia petanda app memang
            # menuntut pemilihan SEBENAR di sini, bukan sekadar taipan.
            print(f"  [WARN] tiada senarai cadangan muncul untuk "
                  f"'{label_text}' selepas menaip '{partial_text}'. "
                  f"Nilai yang ditaip dibiarkan; meneruskan.")
        return el

    def _buka_spinner_cadangan(self, medan_el, teks_penapis=None):
        """Tap Spinner JIRAN TERDEKAT DI BAWAH `medan_el` untuk membuka
        senarai cadangan, dan sahkan baris benar-benar muncul.

        Tab PESALAH menyimpan cadangan MAKLUMAT JALAN di belakang Spinner
        (bukti dalam pemanggil). Spinner dipilih ikut JIRAN — jarak
        menegak terkecil di bawah medan — dan BUKAN ikut indeks:
        borang lain pada skrin yang sama membawa 3 Spinner (tingkat kod
        kompaun) dan indeks tetap akan menuding ke Spinner yang SALAH.

        Tap DISAHKAN, tidak dipercayai (BRIEF Seksyen 3: tap boleh gagal
        didaftarkan secara SENYAP) — sama corak dengan
        DaftarKompaunPage._buka_dialog_spinner() pada mesin dropdown kod
        kompaun. Pulang senarai baris (mungkin kosong)."""
        from config import IMPLICIT_WAIT
        import time
        # `medan_el` KERAP STALE di sini: RN merender semula borang selepas
        # taipan live-search, jadi rujukan yang diperoleh SEBELUM menaip
        # melempar StaleElementReferenceException pada .rect (diukur
        # 2026-08-06: "medan jalan tidak dapat diukur"). Sauh kedua ialah
        # medan yang MEMEGANG teks penapis — dicari semula pada pokok view
        # SEKARANG, jadi ia tidak boleh stale.
        bawah_medan = None
        try:
            r = medan_el.rect
            bawah_medan = r["y"] + r["height"]
        except Exception:                                    # noqa: BLE001
            if teks_penapis:
                n = self._norm(teks_penapis)
                for _i, el2, teks in self._senarai_teks_editext():
                    if self._norm(teks) == n:
                        try:
                            r = el2.rect
                            bawah_medan = r["y"] + r["height"]
                            print(f"  [CADANGAN] rujukan medan stale — "
                                  f"disauh semula pada medan yang memegang "
                                  f"{teks_penapis!r} (y={bawah_medan})")
                        except Exception:                    # noqa: BLE001
                            pass
                        break
        self.driver.implicitly_wait(0)
        try:
            spinners = self.driver.find_elements(AppiumBy.CLASS_NAME,
                                                 "android.widget.Spinner")
        except Exception:                                    # noqa: BLE001
            spinners = []
        finally:
            self.driver.implicitly_wait(IMPLICIT_WAIT)
        if bawah_medan is None:
            # Kedudukan medan tidak diketahui: ujian JIRAN tidak boleh
            # dijalankan. Satu Spinner sahaja pada skrin -> tiada
            # kekaburan, ketuk ia. LEBIH daripada satu -> BERHENTI;
            # meneka antara 3 Spinner tingkat kod kompaun ialah tepat
            # kelas "pilih yang salah secara senyap" yang dilarang.
            if len(spinners) == 1:
                spinner, jarak = spinners[0], "?"
                print("  [CADANGAN] kedudukan medan tidak diketahui, "
                      "tetapi HANYA SATU Spinner pada skrin — tiada "
                      "kekaburan, ia diketuk")
            else:
                print(f"  [CADANGAN] kedudukan medan tidak diketahui dan "
                      f"{len(spinners)} Spinner pada skrin — MENOLAK "
                      f"meneka yang mana satu")
                return []
        else:
            calon = []
            for sp in spinners:
                try:
                    jarak = sp.rect["y"] - bawah_medan
                except Exception:                            # noqa: BLE001
                    continue
                if -20 <= jarak <= 400:
                    calon.append((jarak, sp))
            if not calon:
                print(f"  [CADANGAN] tiada Spinner jiran dalam 400px di "
                      f"bawah medan (y={bawah_medan}); {len(spinners)} "
                      f"Spinner pada skrin")
                return []
            calon.sort(key=lambda t: t[0])
            jarak, spinner = calon[0]
        print(f"  [CADANGAN] senarai tidak dirender sendiri — mengetuk "
              f"Spinner jiran (+{jarak}px di bawah medan) untuk "
              f"membukanya")
        for cubaan in range(3):
            self.tap_element(spinner)
            time.sleep(0.9)
            baris = self._kutip_baris_cadangan()
            if baris:
                print(f"  [CADANGAN] Spinner terbuka — {len(baris)} baris "
                      f"dipapar (cubaan {cubaan + 1})")
                return baris
            print(f"  [CADANGAN] tiada baris selepas tap Spinner "
                  f"(cubaan {cubaan + 1}/3)")
        return []

    def _dump_ui(self, name):
        """Simpan page source ke ui_dumps/<name>, pulang laluannya.
        TIDAK melempar — dump ialah bukti, bukan syarat laluan."""
        try:
            import os
            os.makedirs("ui_dumps", exist_ok=True)
            laluan = os.path.join("ui_dumps", name)
            with open(laluan, "w", encoding="utf-8") as f:
                f.write(self.driver.page_source)
            print(f"  [DUMP] page source disimpan ke {laluan}")
            return laluan
        except Exception:                                    # noqa: BLE001
            return "(dump gagal)"

    def _lapor_cadangan_tidak_padan(self, label_text, partial_text,
                                     sasaran, baris):
        """Baris yang DINAMAKAN tidak ada: dump + SENARAIKAN apa yang ADA,
        kemudian MELEMPAR. Tiada sandaran baris pertama.

        Senarai baris sebenar dicetak kerana itulah maklumat yang
        menjawab 'kenapa padanan gagal' dalam SATU run, bukan selepas
        tiga: sama ada penapis menyembunyikan baris itu, ejaan DB
        berbeza, atau jalan itu memang tiada dalam DB yang diselaraskan.
        Ketiga-tiganya keputusan MANUSIA, bukan sesuatu untuk diteka
        oleh kod."""
        laluan = self._dump_ui("cadangan_tidak_padan.xml")
        print(f"  [CADANGAN] >>> TIDAK PADAN <<< sasaran {sasaran!r} tiada "
              f"dalam {len(baris)} baris yang dipapar:")
        for teks, _el in baris[:25]:
            print(f"      - {teks!r}")
        if len(baris) > 25:
            print(f"      ... ({len(baris) - 25} baris lagi)")
        raise AssertionError(
            f"baris cadangan {sasaran!r} TIDAK ADA pada '{label_text}' "
            f"selepas menaip penapis {partial_text!r}. {len(baris)} baris "
            f"dipapar (disenaraikan dalam log di atas; dump: {laluan}). "
            f"MENOLAK mengambil baris pertama — dengan penapis awalan, "
            f"baris pertama boleh jadi jalan LAIN dan baris selaras yang "
            f"salah membawa taman/poskod yang salah secara SENYAP "
            f"(Peraturan Keras #7). Semak: (a) penapis terlalu sempit/"
            f"luas, (b) ejaan DB berbeza daripada oracle, (c) jalan ini "
            f"tiada dalam DB yang diselaraskan pada device ini, (d) baris "
            f"itu ada tetapi DI BAWAH bahagian senarai yang dirender — "
            f"dialog ini ada skrolnya SENDIRI dan uiautomator MEMBUANG "
            f"node visible:false, jadi 'tiada dalam senarai di atas' "
            f"BUKAN bukti ketiadaan.")

    def _sahkan_jalan_dibaca_balik(self, sasaran):
        """Selepas pemilihan: medan MESTI memegang nama jalan yang diminta.

        Bentuk "JALAN X | TAMAN Y" -> medan dijangka memegang "JALAN X"
        sahaja (bukti device: ui_dumps\\46_borang_penuh.xml EditText[2] =
        'JALAN BAKAK' selepas baris 'JALAN BAKAK | KAMPUNG BARU SKUDAI'
        ditap; sama pada tab NOTIS, ui_dumps\\N05_notis.xml EditText[0]).

        Kalau tidak sama: GAGAL dengan nilai SEBENAR yang dibaca. Tanpa
        semakan ini, satu tap yang mendarat pada baris LAIN kelihatan
        persis seperti kejayaan."""
        nama = str(sasaran).split("|")[0].strip()
        idx, medan = self._indeks_medan_jalan(nama)
        if idx is not None:
            print(f"  [BACA-BALIK] medan jalan = {medan[idx][2]!r} — PADAN "
                  f"{nama!r}")
            return idx
        laluan = self._dump_ui("jalan_baca_balik_gagal.xml")
        dibaca = [t for _i, _el, t in medan]
        raise AssertionError(
            f">>> BACA-BALIK JALAN GAGAL <<< selepas pemilihan, TIADA "
            f"medan yang memegang {nama!r}. EditText yang dibaca: "
            f"{dibaca!r}. Ini bermakna tap mendarat pada baris LAIN, atau "
            f"pemilihan tidak mengisi medan langsung — kedua-duanya "
            f"membawa alamat yang SALAH ke rekod, jadi laluan ini BERHENTI "
            f"di sini dan tidak meneruskan. Dump: {laluan}")

    def _senarai_teks_editext(self):
        """[(indeks, elemen, teks)] semua EditText dalam pokok view
        SEKARANG, ikut urutan dokumen.

        Implicit wait dimatikan (corak _find_all_by_resource_id) supaya
        probe ini tidak membakar tempoh tunggu penuh. NOTA: uiautomator
        MEMBUANG node visible:false, jadi medan di bawah lipatan boleh
        TIADA dalam senarai ini — itu sebab pemanggil melaporkan 'tidak
        dapat dibaca' dan bukan 'kosong'."""
        from config import IMPLICIT_WAIT
        self.driver.implicitly_wait(0)
        try:
            els = self.driver.find_elements(AppiumBy.CLASS_NAME,
                                            "android.widget.EditText")
        except Exception:                                    # noqa: BLE001
            els = []
        finally:
            self.driver.implicitly_wait(IMPLICIT_WAIT)
        return [(i, el, self._safe_text(el)) for i, el in enumerate(els)]

    def _indeks_medan_jalan(self, nama_jalan):
        """(indeks, medan) di mana `indeks` ialah kedudukan EditText yang
        MEMEGANG `nama_jalan`, atau (None, medan) kalau tiada.

        Ini SAUH untuk membaca medan JIRAN (taman/poskod/bandar/negeri).
        Locator ikut label/placeholder TIDAK boleh dipakai untuk itu:
        `text` EditText ialah PLACEHOLDER bila kosong, jadi ia HILANG
        sebaik medan diisi — kelas perangkap yang sudah tercatat dalam
        CLAUDE.md, dan tepat sebab pembaca auto-isi lama melaporkan
        'tidak dapat dibaca' untuk keempat-empat medan.

        Urutan medan DISAHKAN pada dump device, KEDUA-DUA borang:
          Notis Amaran tab PESALAH (dump 41/46): 2=JALAN 3=TAMAN
                                     4=POSKOD 5=BANDAR 6=NEGERI
          borang Kompaun tab NOTIS (dump 50/N05): 0=JALAN 1=TAMAN
                                     2=POSKOD 3=BANDAR 4=NEGERI
        Indeksnya BERBEZA antara borang, tetapi JIRAN-nya sama dan
        berturutan — sebab itu sauh ini dicari, bukan dihardcode."""
        medan = self._senarai_teks_editext()
        n = self._norm(nama_jalan)
        for i, _el, teks in medan:
            t = self._norm(teks)
            if t == n or t.startswith(n + " |") or t.startswith(n + "|"):
                return i, medan
        return None, medan

    def select_dropdown_option(self, placeholder_text, option_text,
                                timeout=None):
        """Tap a dropdown showing placeholder_text, type option_text to
        filter, then pick the matching option ROW -- verifying the pick
        actually registered and RAISING clearly if it never does.

        WHY THE ROW IS MATCHED BY content-desc, NOT text
        ------------------------------------------------
        Confirmed via ui_dumps/bmrecon_form_codes.xml: an open list's
        option ROWS are clickable android.view.ViewGroup nodes carrying
        content-desc="<OPTION>" (with a child TextView), while the search
        INPUT is an android.widget.EditText matched on `text` with an
        EMPTY content-desc. The old locator
            new UiSelector().text("<OPTION>")
        matched BOTH -- and element_to_be_clickable returned the EditText
        we'd just typed into first, so tap_element landed on the
        already-focused field (a no-op) and the method returned a FALSE
        success while the app never received a selection. Matching the row
        by DESCRIPTION makes hitting the input field impossible (its
        content-desc is empty).

        The searchable field renders its list only after focus in some
        variants (PILIH KOMPAUN) but with the keyboard up in others (KOD
        AKTA) -- so we look, then hide the keyboard and look again.

        Verification: after the row tap the list must CLOSE (the row's
        content-desc is gone) -- the same silent-no-op-tap guard used for
        every other pick in this suite. Retries up to 3x; on total failure
        it dumps page source and raises "pemilihan dropdown ... tidak
        didaftarkan" rather than continuing as if the field were set.
        """
        import re
        import time
        placeholder_locator = (AppiumBy.ANDROID_UIAUTOMATOR,
                               f'new UiSelector().text("{placeholder_text}")')
        option_upper = option_text.upper()
        esc = re.escape(option_upper)

        # Option ROWS can carry a code PREFIX in their content-desc --
        # confirmed via ui_dumps/dropdown_UUK7UNDANGUNDANG_fail.xml: KOD AKTA
        # renders content-desc "39 - UUK 7 UNDANG-UNDANG..." while the test
        # data is just the description "UUK 7 UNDANG-UNDANG...". So match a
        # row whose content-desc ENDS WITH the option. Ends-with (not
        # contains) still excludes a longer sibling like "KOMPAUN PELBAGAI
        # TRAFIK" when selecting "KOMPAUN PELBAGAI" (that ends with TRAFIK),
        # and (not exact) tolerates the prefix.
        row_by_desc = (AppiumBy.ANDROID_UIAUTOMATOR,
                       f'new UiSelector().descriptionMatches("(?i).*{esc}$")')
        # Fallback row: a TextView (NEVER the EditText input) whose text ends
        # with the option, for any variant that renders rows without a
        # content-desc.
        row_by_text = (AppiumBy.ANDROID_UIAUTOMATOR,
                       f'new UiSelector().className("android.widget.TextView")'
                       f'.textMatches("(?i).*{esc}$")')

        # Type only a distinctive PREFIX of the option to filter, not the
        # whole string: a very long value (the ~100-char KESALAHAN
        # descriptions) fed to the RN live-search returned "Tiada rekod
        # dijumpai" (confirmed via dropdown_MEMOTONGMENGALIH_fail.xml),
        # filtering the target row OUT entirely. A short prefix narrows the
        # list while still rendering the row, which is then matched exactly
        # by the ends-with locators below.
        filter_text = option_text[:25]

        def _open_and_filter():
            el = self.find_clickable(placeholder_locator, timeout)
            self.tap_element(el)
            time.sleep(0.3)
            # SENGAJA `mobile: type`: medan carian dropdown ini juga
            # bersambung kepada carian langsung RN (sebab sama seperti
            # type_and_select_suggestion). filter_text sampai 25 aksara —
            # LEBIH PANJANG daripada rentetan 22 aksara yang terbukti
            # meranapkan app — dan hampir setiap nilai KESALAHAN
            # mengandungi 'r'. Laluan ini BELUM PERNAH dijalankan pada
            # device (satu-satunya pemanggilnya,
            # select_dropdown_option_and_confirm, tiada pemanggil hidup;
            # borang Notis membuka tingkat kod melalui pilih_spinner_kod).
            # Jadi ia bukan bukti "selamat" — ia permukaan belum diuji.
            self._mobile_type(filter_text)

        # The dropdown's own search field, located by its hint (UiSelector
        # can't match hints; XPath can) so we can clear a filter that hid
        # the target row.
        field_by_hint = (AppiumBy.XPATH,
                         f'//android.widget.EditText[@hint="{placeholder_text}"]')

        def _clear_filter():
            try:
                el = self.find_element(field_by_hint, timeout=2)
                self._force_clear(el)
                time.sleep(0.4)
            except Exception:                                # noqa: BLE001
                pass

        via_text = [False]  # was the row found via the content-desc-less
                            # TEXT fallback (not by content-desc)?

        def _look():
            for loc in (row_by_desc, row_by_text):
                if self.is_element_present(loc, timeout=2):
                    try:
                        el = self.find_element(loc, timeout=3)
                        via_text[0] = (loc is row_by_text)
                        return el
                    except Exception:                        # noqa: BLE001
                        pass
            return None

        def _find_row():
            for _ in range(2):
                found = _look()
                if found is not None:
                    return found
                # Some lists (PILIH KOMPAUN) only render once focus is lost.
                try:
                    if self.driver.is_keyboard_shown():
                        self.driver.hide_keyboard()
                        time.sleep(0.3)
                except Exception:                            # noqa: BLE001
                    pass
            # The typed prefix may have filtered the row OUT -- confirmed for
            # the KESALAHAN options, whose live-search returns "Tiada rekod
            # dijumpai" for a description substring (it matches the "(UUK
            # X) -"-prefixed string, not the description). Clear the filter
            # and scroll the FULL list to the row instead.
            _clear_filter()
            _scroll_inner_to_option()
            return _look()

        def _option_row_present():
            # The clickable option ROW (content-desc) exists only while the
            # list is OPEN. After a registered selection it is gone and the
            # value lives in the field's EditText (text, no content-desc) --
            # so for normal content-desc dropdowns this alone tells
            # open-vs-closed WITHOUT the false-negative of the old check
            # (which also matched a displayed TextView value and so reported
            # "not registered" even after a real selection).
            if self.is_element_present(row_by_desc, timeout=1):
                return True
            # BUT if the row was found via the content-desc-LESS text fallback
            # (a desc-less dropdown variant), row_by_desc is never present, so
            # a coord-tap that no-ops would leave this False and the FIRST tap
            # be reported SELECTED though nothing was picked (false success).
            # For that case, also verify close via row_by_text.
            if via_text[0] and self.is_element_present(row_by_text, timeout=1):
                return True
            return False

        def _scroll_inner_to_option():
            # Scroll the dropdown's OWN nested list (instance 1), never the
            # outer page ScrollView (instance 0) -- confirmed live that
            # scrolling the page destroys form progress.
            scroll = (
                'new UiScrollable(new UiSelector().scrollable(true)'
                '.instance(1)).scrollIntoView(new UiSelector()'
                f'.descriptionMatches("(?i).*{esc}$"));')
            try:
                self.driver.find_element(AppiumBy.ANDROID_UIAUTOMATOR, scroll)
            except Exception:                                # noqa: BLE001
                pass

        safe = "".join(c for c in option_upper if c.isalnum())[:16] or "opt"

        def _dump_dd(tag):
            try:
                import os
                os.makedirs("ui_dumps", exist_ok=True)
                p = os.path.join("ui_dumps", f"dropdown_{safe}_{tag}.xml")
                with open(p, "w", encoding="utf-8") as f:
                    f.write(self.driver.page_source)
                print(f"  [DROPDOWN] state dumped -> {p}")
            except Exception:                                # noqa: BLE001
                pass

        # Open + filter ONCE. Re-opening on retry crashed the old version:
        # after typing, the placeholder text is gone, so
        # find_clickable(placeholder) can no longer re-find the field.
        _open_and_filter()
        row = _find_row()
        if row is None:
            _scroll_inner_to_option()
            row = _find_row()

        if row is not None:
            # Tap the option ROW, trying successively different methods until
            # the list closes. These rows carry a REAL content-desc, so
            # el.click() (accessibility ACTION_CLICK) may register where a raw
            # coordinate tap no-ops -- the opposite of the desc-less RN
            # pressables elsewhere in this app, hence worth trying explicitly.
            for attempt in range(3):
                for method in ("coord", "click", "child"):
                    try:
                        if method == "coord":
                            self.tap_element(row)
                        elif method == "click":
                            row.click()
                        else:
                            child = row.find_element(
                                AppiumBy.CLASS_NAME,
                                "android.widget.TextView")
                            self.tap_element(child)
                    except Exception:                        # noqa: BLE001
                        pass
                    # Poll up to ~2s for the option list to close (RN close
                    # animation can lag a fast check). Row gone == the
                    # selection registered.
                    closed = False
                    for _ in range(4):
                        time.sleep(0.5)
                        if not _option_row_present():
                            closed = True
                            break
                    if closed:
                        print(f"  [DROPDOWN] SELECTED '{option_upper}' via "
                              f"{method}-tap on the option ROW (content-desc)"
                              f" — option list CLOSED (registered, not typed)")
                        return
                    # Still open -- re-resolve the row (it may have gone
                    # stale under us) and try the next tap method.
                    try:
                        row = self.find_element(row_by_desc, timeout=2)
                    except Exception:                        # noqa: BLE001
                        if not _option_row_present():
                            continue
                print(f"  [DROPDOWN] '{option_text}' pick not registered "
                      f"(attempt {attempt + 1}/3 -- tried coord/click/child)")
                _dump_dd(f"notreg{attempt + 1}")
        else:
            print(f"  [DROPDOWN] option row '{option_upper}' never rendered")

        _dump_dd("fail")
        raise TimeoutException(
            f"Pemilihan dropdown '{option_text}' daripada "
            f"'{placeholder_text}' tidak didaftarkan (baris pilihan tidak "
            f"dijumpai, atau tap tidak mendaftar selepas cuba coord/click/"
            f"child); lihat ui_dumps/dropdown_{safe}_*.xml")

    # Native AlertDialog pieces -- confirmed via live page-source dump
    # (debug_menu_selaras_close.xml): this app reports sync/upload
    # results through standard Android alerts (title "BERJAYA"/"RALAT",
    # message like "DATA JENIS KENDERAAN SAVED SUCCESSFULLY!", one OK
    # button with resource-id android:id/button1). These alerts arrive
    # asynchronously when the underlying operation finishes, and they
    # queue: a leftover alert blocks every element behind it.
    NATIVE_ALERT_OK = (AppiumBy.ANDROID_UIAUTOMATOR,
                       'new UiSelector().resourceId("android:id/button1")')
    NATIVE_ALERT_MESSAGE = (AppiumBy.ANDROID_UIAUTOMATOR,
                            'new UiSelector().resourceId("android:id/message")')
    # Tajuk alert asli. Fakta device: tajuk membawa isyarat yang MESEJ
    # kadang tidak bawa — dialog LESEN bertajuk "BEJAYA" (ejaan app, tiada
    # 'R') dengan mesej "LESEN SAMA." yang langsung tidak menyebut kejayaan
    # (reports\fasa2-bootstrap.md §2.3). Membaca mesej SAHAJA membuang
    # isyarat itu.
    NATIVE_ALERT_TITLE = (AppiumBy.ANDROID_UIAUTOMATOR,
                          'new UiSelector().resourceId("android:id/alertTitle")')

    def _baca_alert_semasa(self):
        """Tajuk + mesej alert asli yang SEDANG terbuka, sebagai satu
        rentetan. "" kalau tiada apa-apa boleh dibaca. TIDAK menunggu dan
        TIDAK menolak — pemanggil yang menguruskan kedua-duanya."""
        bahagian = []
        for loc in (self.NATIVE_ALERT_TITLE, self.NATIVE_ALERT_MESSAGE):
            try:
                t = (self.driver.find_element(*loc).text or "").strip()
                if t:
                    bahagian.append(t)
            except Exception:                                # noqa: BLE001
                pass
        return " | ".join(bahagian)

    def read_native_alert_text(self, first_timeout=5):
        """Baca tajuk + mesej alert asli **TANPA MENOLAKNYA**.

        Pulang `str` — "TAJUK | MESEJ" (bahagian yang kosong ditinggalkan),
        atau **rentetan KOSONG** kalau tiada alert dalam `first_timeout`.
        Alert dibiarkan TERBUKA: pemanggil boleh memeriksanya dahulu,
        kemudian menolaknya dengan dismiss_native_alerts().

        KENAPA KAEDAH INI WUJUD (punca struktur BLOCKER B-1):
        dismiss_native_alerts() mencetak teks alert lalu MENELANNYA, jadi
        kod hiliran hanya tahu "ada alert, sudah ditolak" dan TIDAK boleh
        membezakan "BERJAYA" daripada "TIDAK BERJAYA". Itulah sebabnya
        is_submission_successful_trafik() terpaksa bersandar pada
        KETIADAAN butang sebagai bukti kejayaan — dan alert "Tidak
        Berjaya" menghasilkan LULUS PALSU pada K-001/L-001/S-001.
        Tanpa helper ini, setiap fail yang perlu tahu APA yang alert
        katakan menulis pembacaan alert sendiri secara ad-hoc dan
        menghasilkan semula kelas pepijat yang sama (sudah berlaku:
        bookmark_page.py, daftar_kompaun_page.py).

        >>> AWAS — JANGAN KLASIFIKASIKAN NILAI PULANGAN INI DENGAN
        `"BERJAYA" in teks`. <<<
        "BERJAYA" ialah SUBRENTETAN "TIDAK BERJAYA", jadi ujian naif itu
        menukar kegagalan menjadi kejayaan — pepijat yang SAMA sekali
        lagi. Guna lapisan kegagalan-dahulu yang sudah ada:
        is_berjaya_message_visible() (BERJAYA_DINAFI disemak SEBELUM
        BERJAYA_SAH, dengan toleransi ejaan `ber?jaya` untuk "BEJAYA"),
        atau padankan BERJAYA_DINAFI dahulu kalau kau mengklasifikasi
        rentetan ini sendiri.
        """
        if not self.is_element_present(self.NATIVE_ALERT_OK,
                                       timeout=first_timeout):
            return ""
        return self._baca_alert_semasa()

    def dismiss_native_alerts(self, first_timeout=5, context="",
                              kumpul=False):
        """Wait up to first_timeout for a native result alert, then
        dismiss it and any alerts queued behind it. Logs each alert's
        actual text (ground truth for locator debugging).

        Nilai pulangan bergantung pada `kumpul`:
          * `kumpul=False` (LALAI) — `bool`, True kalau sekurang-kurangnya
            satu alert ditolak. **Kelakuan LAMA, tidak berubah langsung**,
            supaya ~15 pemanggil sedia ada (5 daripadanya menguji nilai
            pulangan sebagai bool) kekal betul tanpa disunting.
          * `kumpul=True` — `list[str]`, teks "TAJUK | MESEJ" bagi SETIAP
            alert yang ditolak, IKUT URUTAN ia muncul. Senarai kosong
            bermakna tiada alert. Untuk pemanggil yang perlu tahu APA yang
            dikatakan, bukan sekadar bahawa sesuatu telah ditolak.

        Alert asli app ini **BERATUR** (reports\\fasa2-bootstrap.md
        "PENEMUAN TEKNIKAL BAHARU" #2): satu alert boleh muncul SEMULA
        selepas ditolak sekali, dan alert yang tertinggal menyekat setiap
        elemen di belakangnya. Sebab itu gelung terus menolak sampai tiada,
        bukan sekali. KEYCODE_BACK **TIDAK** menutup alert asli, jadi Back
        bukan ganti kepada kaedah ini.

        Kalau kau mengklasifikasikan teks yang dikumpul: BERJAYA_DINAFI
        MESTI disemak SEBELUM BERJAYA_SAH — "BERJAYA" ialah subrentetan
        "TIDAK BERJAYA". Lihat nota is_berjaya_message_visible().

        el.click() is fine here (real android.widget.Button, not one of
        this app's RN Pressables)."""
        import time
        teks = []
        if not self.is_element_present(self.NATIVE_ALERT_OK,
                                       timeout=first_timeout):
            return teks if kumpul else False
        dismissed = False
        for _ in range(6):
            msg = self._baca_alert_semasa()
            if msg:
                teks.append(msg)
                print(f"  [ALERT] {context}: popup says: {msg}")
            try:
                self.driver.find_element(*self.NATIVE_ALERT_OK).click()
                dismissed = True
            except Exception:
                break
            time.sleep(0.5)
            if not self.is_element_present(self.NATIVE_ALERT_OK, timeout=2):
                break
        return teks if kumpul else dismissed

    # --- TAMBAHAN MBJB (aditif) — isyarat tunggu SEBENAR, bukan sleep ----
    # Kontrak C-15. Fakta device, Loh 2026-07-30
    # (reports\fasa2-bootstrap.md "PENEMUAN TEKNIKAL BAHARU" #4): overlay
    # sibuk app BOLEH dilihat uiautomator, cth
    #   text="SELARAS MAKLUMAT ALAMAT SEDANG DIPROSES..."
    # Kehilangannya ialah isyarat SEBENAR bahawa operasi tamat. sleep
    # tetap sama ada terlalu pendek (tap seterusnya ditelan overlay) atau
    # terlalu panjang (membazir masa pada run 90-120 minit).
    OVERLAY_SIBUK = (AppiumBy.ANDROID_UIAUTOMATOR,
                     'new UiSelector().textMatches("(?i).*SEDANG\s+DIPROSES.*")')

    def tunggu_selesai_diproses(self, timeout=180, context=""):
        """Tunggu overlay 'SEDANG DIPROSES' hilang.

        Pulang True bila tiada overlay (atau ia hilang dalam masa),
        False bila ia MASIH ADA selepas `timeout`. Pemanggil MESTI
        melaporkan False — operasi yang belum selesai bermakna keadaan
        yang diuji seterusnya belum wujud. TIDAK melempar."""
        import time
        tag = f"[{context}] " if context else ""
        if not self.is_element_present(self.OVERLAY_SIBUK, timeout=2):
            return True
        print(f"  [TUNGGU] {tag}overlay 'SEDANG DIPROSES' kelihatan — "
              f"menunggu ia hilang (had {timeout}s)")
        habis = time.monotonic() + timeout
        while time.monotonic() < habis:
            if not self.is_element_present(self.OVERLAY_SIBUK, timeout=2):
                print(f"  [TUNGGU] {tag}overlay hilang — operasi selesai")
                return True
            time.sleep(2)
        print(f"  [TUNGGU] {tag}overlay 'SEDANG DIPROSES' MASIH ADA selepas "
              f"{timeout}s — melaporkan, bukan meneruskan secara membuta")
        return False

    def drain_printer_alert(self):
        """DILUMPUHKAN untuk MBPG — sentiasa False, tidak menyentuh apa-apa.

        Versi MBJB mengesan modal "Error: Unable to connect device" dan
        MENEKAN butang OK asli (android:id/button1) untuk membersihkannya.

        Dua sebab ia lumpuh di sini, dan sebab kedua yang penting:

          1. Pencetak berada di luar skop projek MBPG sepenuhnya (arahan
             pemilik 2026-08-07). Tiada pencetak akan disambungkan, jadi
             alert ini tidak sepatutnya muncul langsung.

          2. Lebih penting: ia satu laluan yang MENEKAN 'OK'. OK ialah
             trip-wire dalam mod dry-run. Mengekalkan kaedah ini bermakna
             sama ada corong membatalkan run apabila ia menyala (mesej
             yang mengelirukan sepenuhnya), atau kita mengukir
             pengecualian untuk laluan tap 'OK' automatik yang tiada
             siapa perhatikan. Kedua-duanya lebih teruk daripada tidak
             memilikinya.

        Kaedah ini KEKAL WUJUD dan bukan dipadam kerana 19 tapak
        panggilan merentas base_page/daftar_kompaun/kompaun_lesen/sitaan
        menggunakannya sebagai penyalir alert generik dalam laluan
        cuba-semula. Semuanya melayan False sebagai "tiada alert
        disalirkan", yang kini sentiasa benar. Alert bukan-pencetak masih
        dikendalikan oleh dismiss_native_alerts() seperti biasa.
        """
        return False

    @classmethod
    def printer_alert_count(cls):
        """Sentiasa 0 — penyalir alert pencetak dilumpuhkan untuk MBPG."""
        return 0

    def read_record_number(self):
        """Read the created record's number (e.g. JB015N260227001) off the
        CURRENT screen -- the success/receipt popup shows it as
        "NO KOMPAUN: JB015...". Returns the token, or None if it can't be
        read. NEVER fabricates: None means "not readable", so the ledger
        stays empty rather than pointing at a record that may not exist.
        Call it BEFORE the popup is closed.

        MBJB: the prefix comes from the active profile (config.
        RECORD_PREFIX), it is NOT hardcoded as MBIP's 'IPA' was. A wrong
        prefix here is the single highest-impact failure in the whole
        suite -- it returns None forever, created_records stays empty, and
        every Cetak/Serah/Kemaskini/Bookmark TC pytest.skips.
        # SAHKAN-DEVICE: awalan sebenar pada staging 219.93.38.103:8880
        # belum disahkan. Excel merekod run production (JB015...), sheet
        # lama menunjukkan JBM50.../JBM51... -- awalan mungkin berubah
        # ikut peranti. Dump popup kejayaan create pertama dan betulkan
        # profiles/mbpg-staging.json sebelum meneruskan."""
        import re
        prefix = _record_prefix()
        # >>> AWAS KALAU KAU MENUKAR record_prefix <<<
        # `prefix` disisip ke dalam regex UiSelector di bawah **TANPA
        # escape** (hanya re.search() Python di bawah yang meng-escape-nya).
        # 'JB015' tiada aksara meta regex jadi ia selamat HARI INI, tetapi
        # record_prefix MASIH TEKAAN (recon\PAPAN.md §1.8) — awalan sebenar
        # belum pernah dibaca dari rekod sebenar. Awalan yang mengandungi
        # '.', '(', '[', '*' dsb akan diam-diam memadan LEBIH LUAS dan
        # read_record_number() boleh memulangkan token yang bukan nombor
        # rekod kita — melanggar Peraturan Keras #7 secara senyap.
        # Diserahkan kepada syakhram (pemilik profil) untuk escape di
        # sumber. Kalau kau menukar awalan sebelum itu, sahkan ia
        # alfanumerik semata-mata.
        loc = (AppiumBy.ANDROID_UIAUTOMATOR,
               f'new UiSelector().textMatches(".*{prefix}\\w{{6,}}.*")')
        try:
            for el in self.driver.find_elements(*loc):
                m = re.search(rf'{re.escape(prefix)}\w{{6,}}',
                              el.get_attribute('text') or '')
                if m:
                    num = m.group(0)
                    print(f"  [ARTIFACT] record number read: {num}")
                    self.last_record_number = num
                    return num
        except Exception:                                    # noqa: BLE001
            pass
        print("  [ARTIFACT] record number not readable on this screen "
              "(leaving ledger empty -- not fabricating)")
        self._diagnose_record_prefix(prefix)
        return None

    # Awalan yang MUNGKIN, dikutip dari oracle V2.1.33 sahaja. Ini BUKAN
    # senarai padanan — read_record_number() masih memadan SATU awalan
    # sahaja (config.RECORD_PREFIX). Senarai ini hanya untuk mencetak
    # diagnosis yang berguna apabila padanan gagal, supaya awalan sebenar
    # diketahui selepas SATU create dan bukan selepas run penuh.
    #   JB015  : 50 sheet (run production Feb 2026)
    #   JBM50  : NK-001 (JBM50N260120002) — menjejak peranti m50
    #   JBM51  : peranti m51, secara analogi (BELUM DISAHKAN)
    AWALAN_CALON = ("JB015", "JBM50", "JBM51")

    def _diagnose_record_prefix(self, prefix):
        """Apabila awalan tidak padan, cetak token seakan-nombor-rekod
        yang MEMANG ada pada skrin.

        Kenapa ini wujud: awalan yang salah ialah kegagalan berkesan
        tertinggi dalam suite — read_record_number() memulangkan None
        selama-lamanya, created_records kekal kosong, dan 20+ TC
        pytest.skip. Tanpa diagnosis ini, kos mengetahui awalan sebenar
        ialah satu run penuh yang menghasilkan senarai skip.

        Ia TIDAK membetulkan apa-apa sendiri dan TIDAK memulangkan
        nombor: menerima awalan yang tidak diisytihar bermakna suite
        menerima rekod yang mungkin bukan miliknya. Betulkan
        profiles/mbpg-staging.json dengan tangan.
        """
        import re
        try:
            src = self.driver.page_source or ""
        except Exception:                                    # noqa: BLE001
            return
        jumpa = sorted(set(re.findall(r'\b[A-Z]{2}[A-Z0-9]{2,6}\d{6,}\b',
                                      src)))
        if not jumpa:
            print(f"  [AWALAN] tiada token seakan-nombor-rekod pada skrin; "
                  f"awalan aktif = {prefix!r}")
            return
        print(f"  [AWALAN] AMARAN: awalan aktif {prefix!r} TIDAK padan, "
              f"tetapi skrin mengandungi token berikut:")
        for t in jumpa[:10]:
            tanda = ""
            for cand in self.AWALAN_CALON:
                if t.startswith(cand):
                    tanda = f"  <- bermula dengan calon {cand!r}"
                    break
            print(f"  [AWALAN]   {t}{tanda}")
        print("  [AWALAN] Kalau salah satu daripadanya ialah nombor rekod "
              "sebenar, tetapkan \"record_prefix\" dalam "
              "profiles/mbpg-staging.json kepada awalannya, kemudian jalan "
              "semula. JANGAN pinda kod ini untuk menerima berbilang "
              "awalan.")

    def _locate_tempoh_el(self):
        """Locate the Tempoh (MAKLUMAT KOMPAUN section) EditText -- the
        header's sibling, or by its hint. NEVER the "MAKLUMAT KOMPAUN"
        header TextView (see TEMPOH_SIBLING). Returns None if absent."""
        for loc in (self.TEMPOH_SIBLING, self.TEMPOH_BY_HINT):
            try:
                return self.find_element(loc, timeout=4)
            except TimeoutException:
                continue
        return None

    def _set_tempoh_verified(self, value):
        """Set the Tempoh field to exactly `value` and assert it lands in
        the field's own 0-21 validity range before the form advances.

        Force-clear (RN silently ignores el.clear()) + retype + read-back,
        up to 3x. If the final value is wrong or out of range, RAISE -- an
        automation failure to report, not a stuck form to keep waiting on.
        Prints the read-back as explicit gate evidence. Shared by the Notis
        and Kompaun forms (same "MAKLUMAT KOMPAUN" header + sibling
        EditText)."""
        value = str(value).strip()
        last = None
        for attempt in range(3):
            el = self._locate_tempoh_el()
            if el is None:
                print("  [TEMPOH] field not locatable on this variant -- "
                      "leaving as-is")
                return
            self._force_clear(el)
            # SENGAJA `mobile: type`: medan Tempoh ialah input terkawal RN
            # dengan pengesahan 0-21 sendiri; send_keys tidak mencetuskan
            # pengesahan itu. Nilainya 1-2 digit — tiada huruf, jadi tidak
            # terdedah kepada mana-mana hipotesis. Tetap dihalakan.
            self._mobile_type(value)
            self._hide_keyboard_if_shown()
            el2 = self._locate_tempoh_el()
            last = self._safe_text(el2) if el2 is not None else None
            if last is not None and last.strip() == value:
                try:
                    n = int(last.strip())
                except ValueError:
                    n = None
                if n is not None and 0 <= n <= 21:
                    print(f"  [TEMPOH] set & read back = {last!r} "
                          f"(in range 0-21) — PASS")
                    return
            print(f"  [TEMPOH] read back {last!r}, wanted {value!r} "
                  f"(attempt {attempt + 1}/3) -- force-clear + retry")
        n = None
        try:
            n = int((last or "").strip())
        except (ValueError, TypeError):
            pass
        out_of_range = n is not None and not (0 <= n <= 21)
        raise TimeoutException(
            f"Tempoh Kompaun tidak dapat ditetapkan kepada '{value}' "
            f"(medan menunjukkan {last!r}"
            + (", DI LUAR julat sah 0-21" if out_of_range else "")
            + ") selepas 3 percubaan -- kegagalan automation (medan tidak "
            "dikosongkan betul / label salah padan), bukan bug aplikasi")

    def select_dropdown_option_and_confirm(self, placeholder_text,
                                            option_text, confirm_locator,
                                            timeout=None):
        """select_dropdown_option (which now self-verifies the pick
        registered and raises if it didn't), then VERIFY the form advanced
        via confirm_locator -- an element that only renders once the
        option list has closed (e.g. the next tier's placeholder, or the
        OPEN CAMERA button after the last tier).

        The old ambiguous re-tap (by text(), which also matched the input
        EditText) is gone: select_dropdown_option now taps the option ROW
        by content-desc and confirms the list closed, so reaching here
        means the pick registered. If confirm_locator still doesn't show,
        that's a genuine form-advance failure to surface, not a missed
        tap to paper over.
        """
        self.select_dropdown_option(placeholder_text, option_text, timeout)
        self._hide_keyboard_if_shown()

        if self.is_element_present(confirm_locator, timeout=8):
            return
        # Cheap below-the-fold safety: the next control may be unrendered.
        self._scroll_down()
        if self.is_element_present(confirm_locator, timeout=3):
            return

        dump_path = "debug_dropdown_confirm.xml"
        try:
            with open(dump_path, "w", encoding="utf-8") as f:
                f.write(self.driver.page_source)
            print(f"  [DEBUG] Form never came back after dropdown "
                  f"selection -- page source dumped to {dump_path}")
        except Exception:
            pass
        raise TimeoutException(
            f"Form did not come back after selecting '{option_text}' from "
            f"'{placeholder_text}' (confirm element {confirm_locator} not "
            f"found); see {dump_path}")

    # --- RN modal (MENU SELARAS dan rakan-rakannya) ---------------------
    # Popup RN app ini dibina sebagai backdrop SKRIN PENUH + panel.
    # Backdrop itu memang kawalan tutup rasmi app (content-desc
    # "Close modal"), TETAPI sempadannya meliputi seluruh skrin, jadi
    # PUSATNYA berada di atas panel — bukan di atas backdrop.
    RN_MODAL_BACKDROP = (AppiumBy.ANDROID_UIAUTOMATOR,
                         'new UiSelector().resourceId("modal-backdrop")')
    RN_MODAL_SURFACE = (AppiumBy.ANDROID_UIAUTOMATOR,
                        'new UiSelector().resourceId("modal-surface")')

    # Elemen seluas ini tidak pernah ikon tutup — ia scrim. Mengklik
    # pusatnya ialah tap BUTA pada apa jua yang dirender di situ.
    _NISBAH_SCRIM = 0.6

    def _tutup_modal_rn_melalui_backdrop(self):
        """Tutup modal RN dengan mengetuk backdrop pada titik yang
        DISAHKAN berada di LUAR panel (modal-surface).

        Diukur 2026-08-04 pada MENU SELARAS:
            modal-backdrop  Button  [0,108][1080,2316]   desc "Close modal"
            modal-surface   Group   [78,516][1002,1908]
        Ketuk pada (540, 2112) menutup popup, disahkan 3/3 pusingan.
        Ketuk pada PUSAT backdrop (540, 1212) TIDAK menutupnya — ia
        jatuh pada item menu 'SELARAS MAKLUMAT JENIS KENDERAAN'.
        """
        import time
        from config import IMPLICIT_WAIT
        self.driver.implicitly_wait(0)
        try:
            bd = self.driver.find_elements(*self.RN_MODAL_BACKDROP)
            sf = self.driver.find_elements(*self.RN_MODAL_SURFACE)
        finally:
            self.driver.implicitly_wait(IMPLICIT_WAIT)
        if not bd:
            return False
        if not sf:
            print("  [POPUP] modal-backdrop ada tetapi modal-surface TIADA "
                  "— enggan mengetuk tanpa tahu sempadan panel.")
            return False
        b, s = bd[0].rect, sf[0].rect
        bawah_panel = s['y'] + s['height']
        bawah_backdrop = b['y'] + b['height']
        x = b['x'] + b['width'] // 2
        y = (bawah_panel + bawah_backdrop) // 2
        if not (bawah_panel < y < bawah_backdrop):
            print(f"  [POPUP] tiada jalur backdrop selamat di bawah panel "
                  f"(backdrop={b}, panel={s}) — enggan mengetuk.")
            return False
        print(f"  [POPUP] tutup modal RN via backdrop 'Close modal' @ "
              f"({x},{y}) — di LUAR panel {s}")
        self.driver.tap([(x, y)])
        time.sleep(1)
        self.driver.implicitly_wait(0)
        try:
            masih = bool(self.driver.find_elements(*self.RN_MODAL_BACKDROP))
        finally:
            self.driver.implicitly_wait(IMPLICIT_WAIT)
        if masih:
            print("  [POPUP] backdrop MASIH ada selepas ketukan.")
            return False
        return True

    def close_popup_by_icon(self, timeout=3):
        """Close a popup using a close (X) icon. Tries a few common
        locator strategies since icon-only buttons vary by screen.

        Confirmed via live UI dump that the signature/"Simpan maklumat
        ini?" popup's close button has content-desc plain "X" (Latin
        capital letter), and the in-app camera's close button uses "✕"
        (U+2715) -- neither matched the original "Close"/"Tutup"
        variants, which silently sent every caller down to their
        fragile hardcoded-coordinate tap-outside fallback instead.

        PUNCA DIUKUR 2026-08-04 — jangan buang penjagaan di bawah.
        `UiSelector().descriptionContains("close")` TIDAK SENSITIF HURUF,
        jadi ia memadan `modal-backdrop` MENU SELARAS yang ber-desc
        "Close modal". Backdrop itu skrin penuh, jadi `wait_and_click()`
        mengetuk PUSATNYA (540,1212) — tepat di atas item menu
        'SELARAS MAKLUMAT JENIS KENDERAAN' — lalu memulangkan True.
        Kesannya: setiap pusingan pembersihan MENCETUSKAN selaras T-006
        dan melahirkan alert 'DATA JENIS KENDERAAN SAVED SUCCESSFULLY!',
        yang disalah tafsir berhari-hari sebagai bug app kategori B.
        Ia automation kita sendiri, kategori A.
        """
        # Modal RN dikendalikan dahulu, dengan titik ketukan yang dikira
        # dari sempadan panel sebenar — bukan pusat scrim.
        if self._tutup_modal_rn_melalui_backdrop():
            return True

        close_locators = [
            (AppiumBy.ACCESSIBILITY_ID, "X"),
            (AppiumBy.ACCESSIBILITY_ID, "✕"),
            (AppiumBy.ACCESSIBILITY_ID, "Close"),
            (AppiumBy.ANDROID_UIAUTOMATOR, 'new UiSelector().description("Close")'),
            (AppiumBy.ANDROID_UIAUTOMATOR, 'new UiSelector().descriptionContains("close")'),
            (AppiumBy.ANDROID_UIAUTOMATOR, 'new UiSelector().descriptionContains("Tutup")'),
        ]
        try:
            ws = self.driver.get_window_size()
            luas_skrin = ws['width'] * ws['height']
        except Exception:                                   # noqa: BLE001
            luas_skrin = 0
        for loc in close_locators:
            if not self.is_element_present(loc, timeout=timeout):
                continue
            if luas_skrin:
                try:
                    r = self.driver.find_element(*loc).rect
                except Exception:                           # noqa: BLE001
                    r = None
                if r and (r['width'] * r['height']) >= (
                        self._NISBAH_SCRIM * luas_skrin):
                    print(f"  [POPUP] {loc[1]!r} padan satu SCRIM "
                          f"({r['width']}x{r['height']}), bukan ikon tutup "
                          f"— tidak diketuk (pusatnya tap buta).")
                    continue
            self.wait_and_click(loc, timeout=timeout)
            return True
        return False

    def reveal_below_fold(self, target_locator, max_tabs=8):
        """v3: focus-traversal 'scrolling' for the RN record forms that
        resist every scroll gesture (Kemaskini / HantarSemula / Notis-
        to-Kompaun -- all confirmed live). Phase 1: TAB (keycode 61)
        cycles the text inputs, dragging the viewport with the focus.
        Phase 2: DPAD_DOWN (keycode 20) continues through non-text
        widgets once TAB stalls. Returns True when target_locator is
        present (keyboard hidden).

        max_tabs lowered 25->8 (perf): on a form where the target never
        renders (a genuinely blocked TC), 25 tabs x 2 keycodes x per-tab
        probes was ~minutes of dead traversal before giving up. The
        owner's call is to keep these TCs running, just fail faster."""
        import time

        def _found():
            if self.is_element_present(target_locator, timeout=0.5):
                self._hide_keyboard_if_shown()
                return self.is_element_present(target_locator, timeout=2)
            return False

        if _found():
            return True
        # >>> KELAS PEPIJAT YANG SAMA DENGAN B1 — DIBIARKAN DENGAN SENGAJA <<<
        # `find_elements(EditText)` di bawah ialah indeks GLOBAL, tepat
        # perkara yang B1 haramkan dalam fill_field_by_label_or_instance():
        # pada skrin bermodal, [-1] boleh jadi medan di BELAKANG modal.
        # Keputusan Loh 2026-07-30: BIARKAN, dan ini BUKAN terlepas pandang.
        # Sebabnya berbeza daripada B1: kaedah ini hanya MEMFOKUS medan
        # untuk menyeret viewport (traversal TAB/DPAD) — ia TIDAK PERNAH
        # menaip, jadi kes buruk ialah fokus yang sia-sia, bukan kredential
        # yang tertimpa. Selain itu pemanggilnya (Kemaskini / HantarSemula /
        # Notis-ke-Kompaun) BELUM PERNAH di-dump pada MBJB, jadi mengehadkan
        # skopnya sekarang ialah tekaan — tepat perkara yang B1 sendiri
        # melarang. Loh akan dump ketiga-tiga skrin itu pada device dan kita
        # betulkan dengan BUKTI, bukan andaian.
        # SAHKAN-DEVICE: adakah mana-mana skrin pemanggil membuka modal?
        try:
            edits = self.driver.find_elements(
                AppiumBy.CLASS_NAME, "android.widget.EditText")
            if edits:
                edits[-1].click()
                time.sleep(0.5)
        except Exception:
            pass

        for keycode in (61, 20):
            last_src_len = 0
            stall = 0
            for _ in range(max_tabs):
                if _found():
                    return True
                self.driver.press_keycode(keycode)
                time.sleep(0.5)
                try:
                    n = len(self.driver.page_source)
                except Exception:
                    n = 0
                if n == last_src_len:
                    stall += 1
                    if stall >= 5:
                        break
                else:
                    stall = 0
                    last_src_len = n
        self._hide_keyboard_if_shown()
        return self.is_element_present(target_locator, timeout=3)

    # ------------------------------------------------------------------
    # Navigation helpers
    # ------------------------------------------------------------------

    def press_back(self):
        """Press the device back button."""
        print("  [NAV] Pressing device back button")
        self.driver.back()

    def go_back_to_home(self):
        """Navigate back to the home screen by pressing Back repeatedly.

        Checks HOME_SCREEN_INDICATOR (a home-grid module button), not
        HAMBURGER.

        >>> B2 — SEBAB DIBETULKAN KEPADA FAKTA DEVICE MBJB <<<
        Nota MBIP lama di sini berbunyi "the hamburger is also present on
        the login screen", membayangkan ia ada pada KEDUA-DUA skrin. Pada
        MBJB 2.1.33 itu SALAH, dan arahnya TERBALIK: glif U+F0C9 muncul
        0 kali dalam ui_dumps\\40_skrin_utama.xml dan 2 kali dalam
        ui_dumps\\01_skrin_awal.xml (skrin LOGIN) — hamburger ada pada
        skrin LOGIN SAHAJA (lihat nota HAMBURGER kelas ini).
        Kesimpulannya kekal SAMA dan malah lebih kuat: HAMBURGER tidak
        boleh membuktikan "home reached", kerana ia TIDAK WUJUD pada
        skrin utama — memeriksanya akan melaporkan "belum sampai" selama-
        lamanya walaupun log masuk berjaya. NOTIS AMARAN (kad grid utama)
        ialah satu-satunya bukti yang betul.
        """
        # HAD YANG DIKETAHUI — dibiarkan dengan sengaja (keputusan Loh
        # 2026-07-30). BRIEF Seksyen 3 + reports\fasa2-bootstrap.md
        # "PENEMUAN TEKNIKAL BAHARU" #3: KEYCODE_BACK menutup IME dan modal
        # RN, tetapi **TIDAK menutup alert ASLI**, dan alert app ini
        # BERATUR. Jadi kalau alert printer ('Error: Unable to connect
        # device') sedang beratur, gelung di bawah membakar kelima-lima
        # tekan Back tanpa kesan dan berakhir dengan AMARAN PALSU "May not
        # have reached home screen" — sedangkan yang sebenarnya berlaku
        # ialah alert tidak dikuras.
        # Tidak dibetulkan SEKARANG kerana printer kini ADA dan akan
        # disambungkan (recon\PAPAN.md §1.5), yang sepatutnya menghentikan
        # alert itu daripada muncul langsung. Loh mahu melihat kelakuan
        # SEBENAR selepas printer bersambung sebelum mengubah logik ini.
        # Kalau amaran palsu masih berlaku selepas itu, pembetulannya ialah
        # dismiss_native_alerts() di dalam gelung — dengan bukti, bukan
        # andaian.
        print("  [NAV] Navigating back to home screen...")
        for i in range(5):
            if self.is_element_present(self.HOME_SCREEN_INDICATOR, timeout=2):
                print("  [NAV] Home screen reached")
                return True
            self.press_back()
            import time
            time.sleep(1)

        print("  [NAV] WARNING: May not have reached home screen")
        return False

    def take_screenshot(self, name="screenshot"):
        """Capture a screenshot for debugging."""
        path = f"screenshots/{name}.png"
        self.driver.save_screenshot(path)
        print(f"  [SCREENSHOT] Saved: {path}")
        return path

"""
Login page — Page Object Model.
Includes the licensing/IP setup sub-flow (hamburger -> Tetapan Alamat IP ->
Tetapan Pelbagai -> device ID -> 'Lesen sama' popup -> relogin), used only
when a fresh login does not reach the home screen.
"""

from appium.webdriver.common.appiumby import AppiumBy
from pages.base_page import BasePage


# PORT MBJB — nota fakta (dakwaan lama DIBETULKAN):
#
# 1. >>> LESEN BUKAN IMEI. Dakwaan lama di sini ("Nilai lesen MBJB IALAH
#    IMEI peranti") telah DITARIK BALIK OLEH PEMILIK pada 2026-07-29 dan
#    dipadam dari fail ini. <<<
#    Fakta yang menggantikannya, bersumber:
#      - `lesen_aplikasi` ialah TOKEN yang didaftarkan di PORTAL PBT dan
#        disahkan di SERVER, bukan dibandingkan dengan IMEI tempatan.
#        (recon\PAPAN.md §1.1; reports\fasa2-bootstrap.md §2.2)
#      - Bukti pemutus: lesen MBIP `352405067769401` berjaya BERPULUH run
#        pada device Ulefone Armor 27 yang IMEI-nya `357616400186856` —
#        dua nilai yang BERBEZA. (mbip-testing\v3\profiles\
#        mbip-staging.json; mbip-testing\v3\HANDOFF-2026-07-29.md:12 &:36)
#      - Medan LESEN APLIKASI pada device memang mengandungi token MBIP
#        itu sebelum Loh mengubahnya (dump ui_dumps\08_tetapan_pelbagai
#        .xml menunjukkan `352405067769401`).
#      - `m50`/`m51` ialah LABEL DEVICE PEJABAT, bukan syarat padanan.
#      - Excel MBPG-TC-T-002!C8 menyokong: "the IMEI must be inserted at
#        the PBT portal" — pendaftaran sebelah portal, bukan padanan
#        sebelah device.
#    Kesan praktikal: lesen ditolak = BLOCKER LUARAN (minta admin daftar
#    IMEI di portal), BUKAN isyarat untuk mencari IMEI device dan
#    menaipnya. DISAHKAN pada device: m50 `867382031575982` DITERIMA pada
#    percubaan PERTAMA (reports\fasa2-bootstrap.md §2.3); m51 tidak perlu.
# 2. IP DIMASUKKAN KE DALAM APP, bukan ke dalam config: MBPG-TC-T-001
#    (Tetapan Alamat IP) + butang Selaras. Sasaran staging =
#    219.93.38.103:8880. JANGAN guna epbt.mbjb.gov.my (production).
#    DISAHKAN pada device: kedua-dua medan ditetapkan ke
#    `219.93.38.103:8880`, SIMPAN, modal dibuka semula dan nilai (TERMASUK
#    port 8880) KEKAL — dump ui_dumps\07_ip_sahkan_kekal.xml. Kebimbangan
#    DEV FIXING LIST baris 11 & 51 (port hilang) TIDAK berulang di sini.
#    # SAHKAN-DEVICE: kekal selepas app dimatikan sepenuhnya (cold kill)
#    # belum diuji — dump 07 diambil dalam sesi yang sama.
# 3. Akaun: DISAHKAN `admin` / `<kata-laluan: profil>` BERJAYA pada percubaan pertama
#    (reports\fasa2-bootstrap.md §2.3). `peranti`/`msc` tidak perlu
#    dicuba. Kebimbangan DEV FIXING LIST baris 54 ("Username masih huruf
#    besar semua") TIDAK menyekat — `admin` huruf kecil diterima.
class LoginPage(BasePage):
    """Login screen locators and actions."""

    # ---- Locators \u2014 SEMUA DISAHKAN PADA DEVICE ---------------------------
    # Dump ui_dumps\01_skrin_awal.xml / 30_skrin_login.xml (Loh 2026-07-30):
    #   * Dua EditText, KEDUA-DUANYA tiada `resource-id` dan tiada
    #     `content-desc` -> indeks ialah satu-satunya cara. index=4 dalam
    #     tree = username (text="msc"), index=5 = password (password="true").
    #     instance(0)/instance(1) di bawah DISAHKAN betul pada skrin login.
    #     AWAS: indeks EditText global ini SAHIH HANYA pada skrin login
    #     tanpa modal. Bila modal Tetapan terbuka di atasnya, medan login
    #     ini masih instance 0/1 dan medan modal jadi 2/3 \u2014 lihat
    #     pelarasan_page.INPUT_OUTLINED.
    #   * Butang: content-desc='LOGIN', resource-id='button', teks pada
    #     anak TextView resource-id='button-text'.
    #   * Tajuk skrin login = 'APLIKASI KOMPAUN e-PBT' (ejaan BETUL).
    #     Berbeza daripada tajuk SKRIN UTAMA yang app tulis SALAH sebagai
    #     'KOMPUAN e-PBT' (home_page.SCREEN_TITLE) \u2014 jangan tukar ganti.
    USERNAME_FIELD = (AppiumBy.ANDROID_UIAUTOMATOR,
                      'new UiSelector().className("android.widget.EditText").instance(0)')
    PASSWORD_FIELD = (AppiumBy.ANDROID_UIAUTOMATOR,
                      'new UiSelector().className("android.widget.EditText").instance(1)')
    TOGGLE_PASSWORD = (AppiumBy.ACCESSIBILITY_ID, "\uf070")
    # NAMA MENGELIRUKAN, DIKEKALKAN UNTUK KESERASIAN: ini LABEL TextView
    # 'REMEMBER ME', BUKAN widget CheckBox. CheckBox sebenar tiada id dan
    # tiada teks (dump 01: android.widget.CheckBox @ [339,1699][447,1807]) \u2014
    # guna REMEMBER_ME_TOGGLE di bawah untuk menandanya.
    REMEMBER_ME_LABEL = (AppiumBy.ANDROID_UIAUTOMATOR,
                         'new UiSelector().textMatches('
                         '"(?i)\s*REMEMBER\s+ME\s*")')
    REMEMBER_ME_CHECKBOX = REMEMBER_ME_LABEL
    # >>> DIBETULKAN UNTUK MBPG 2.1.21 — 2026-08-10. <<<
    # MBJB memakai ACCESSIBILITY_ID "LOGIN" (huruf besar). Recon device
    # (recon/skrin_semasa.xml) menunjukkan butang sebenar ialah
    #     Button  resource-id="button"      text="Login"
    #       TextView resource-id="button-text" text="Login"
    # Tiada content-desc "LOGIN" di mana-mana, jadi accessibility id
    # tidak pernah memadan dan login menemui jalan buntu selepas
    # kedua-dua medan berjaya diisi.
    #
    # Dipadan ikut TEKS tidak-peka-huruf, bukan ikut resource-id
    # "button": id itu terlalu generik dan muncul pada butang lain
    # dalam app.
    LOGIN_BUTTON = (AppiumBy.ANDROID_UIAUTOMATOR,
                    'new UiSelector().textMatches("(?i)\s*LOGIN\s*")')
    # >>> PEKA HURUF — DIBETULKAN UNTUK MBPG 2.1.21, 2026-08-10. <<<
    # MBJB memakai text("APLIKASI KOMPAUN e-PBT") huruf besar penuh, dan
    # UiSelector().text() PEKA HURUF. Pada MBPG 2.1.21 tajuk sebenar pada
    # skrin ialah "Aplikasi Kompaun e-PBT" (Title Case, disahkan dari
    # page_source device 2026-08-10), jadi locator huruf besar TIDAK
    # PERNAH memadan.
    #
    # Kesannya bukan kosmetik: is_login_screen_displayed() memulangkan
    # False pada skrin login SEBENAR, jadi gerbang IP menyimpulkan "app
    # sudah log masuk" dan peringkat login menyimpulkan "bukan skrin
    # login" — kedua-duanya salah, pada skrin yang jelas memaparkan
    # 'Login', 'Remember Me' dan username 'msc'.
    #
    # textMatches + (?i) supaya ia betul tanpa mengira casing app dalam
    # build akan datang.
    APP_TITLE = (AppiumBy.ANDROID_UIAUTOMATOR,
                 'new UiSelector().textMatches('
                 '"(?i)\\s*APLIKASI\\s+KOMPAUN\\s+e-PBT\\s*")')
    VERSION_TEXT = (AppiumBy.ANDROID_UIAUTOMATOR,
                    'new UiSelector().textContains("Version")')

    # ---- Licensing / IP setup sub-flow (LALUAN WARISAN) ------------------
    # LALUAN KANONIK ialah PelarasanPage.run_full_pelarasan(), yang menulis
    # medan ikut resource-id `text-input-outlined` dan mengendalikan dialog
    # BEJAYA/LESEN SAMA. Sub-flow di bawah dikekalkan sebagai jaring
    # keselamatan sahaja; locator-nya dibetulkan kepada fakta device supaya
    # ia tidak "berjaya" secara palsu bila ia benar-benar dipanggil.
    #
    # FAKTA DEVICE (dump ui_dumps\02_menu_hamburger.xml,
    # 03_tetapan_alamat_ip.xml, 08_tetapan_pelbagai.xml):
    #   * item menu HURUF BESAR: 'TETAPAN ALAMAT IP', 'TETAPAN PELBAGAI'.
    #     textContains PEKA huruf -> versi Title Case lama TIDAK PERNAH
    #     padan. Kini textMatches tidak sensitif huruf.
    #   * butang simpan = 'SIMPAN' (content-desc + text), resource-id
    #     'button'. text("Simpan") Title Case lama TIDAK PERNAH padan.
    #   * TIADA medan bernama "DEVICE ID" pada Tetapan Pelbagai. Label
    #     sebenar ialah TextView 'LESEN APLIKASI:' (huruf besar + titik
    #     bertindih) dan medannya EditText resource-id
    #     'text-input-outlined'.
    MENU_TETAPAN_ALAMAT_IP = (AppiumBy.ANDROID_UIAUTOMATOR,
                              'new UiSelector().textMatches('
                              '"(?i)(?s).*tetapan\\s*alamat\\s*ip.*")')
    MENU_TETAPAN_PELBAGAI = (AppiumBy.ANDROID_UIAUTOMATOR,
                             'new UiSelector().textMatches('
                             '"(?i)(?s).*tetapan\\s*pelbagai.*")')
    FIELD_INTERNAL_IP_LABEL = "INTERNAL IP ADDRESS"
    FIELD_EXTERNAL_IP_LABEL = "EXTERNAL IP ADDRESS"
    BUTTON_SIMPAN = (AppiumBy.ANDROID_UIAUTOMATOR,
                     'new UiSelector().descriptionMatches("(?i)\\s*simpan\\s*")')
    # Nama lama dikekalkan (dipanggil handle_license_mismatch) tetapi nilai
    # kini label device yang SEBENAR.
    FIELD_DEVICE_ID_LABEL = "LESEN APLIKASI:"
    # Dialog SEBENAR: tajuk 'BEJAYA' (ejaan app, tiada 'R'), mesej
    # 'LESEN SAMA.' — HURUF BESAR + NOKTAH (dump
    # ui_dumps\10_lesen_m50_selepas_simpan.xml). textContains("Lesen sama")
    # PEKA huruf dan TIDAK PERNAH padan.
    POPUP_LESEN_SAMA = (AppiumBy.ANDROID_UIAUTOMATOR,
                        'new UiSelector().textMatches('
                        '"(?i)(?s).*lesen\\s*sama.*")')

    # v3 (T-012): the real toggle is the CheckBox widget itself --
    # confirmed via live recon dump (recon_pelesen_60s.xml): a clickable
    # android.widget.CheckBox sits next to the "REMEMBER ME" TextView.
    REMEMBER_ME_TOGGLE = (AppiumBy.ANDROID_UIAUTOMATOR,
                          'new UiSelector().className('
                          '"android.widget.CheckBox")')

    def enable_remember_me(self):
        """v3 (T-012): tick the Remember Me checkbox, verifying the
        checked state actually flipped (raw tap + retry -- same silent
        no-op protection as everywhere else in this app)."""
        import time
        el = self.find_element(self.REMEMBER_ME_TOGGLE, timeout=10)
        if (el.get_attribute("checked") or "").lower() == "true":
            print("  [LOGIN] Remember Me already checked")
            return True
        for attempt in range(3):
            self.tap_element(el)
            time.sleep(0.7)
            el = self.find_element(self.REMEMBER_ME_TOGGLE, timeout=5)
            if (el.get_attribute("checked") or "").lower() == "true":
                print("  [LOGIN] Remember Me checked — PASS")
                return True
            print(f"  [LOGIN] Remember Me still unchecked (attempt "
                  f"{attempt + 1}/3) -- re-tapping...")
        print("  [LOGIN] WARNING: Remember Me checkbox never reported "
              "checked=true")
        return False

    def get_login_field_values(self):
        """v3 (T-012): read the current username/password field values
        (post-relaunch, to verify Remember Me retained them)."""
        u = self.find_element(self.USERNAME_FIELD, timeout=10).text or ""
        p = self.find_element(self.PASSWORD_FIELD, timeout=10).text or ""
        return u, p

    # ---- Actions ----

    # Popup MENU SELARAS hidup pada skrin LOGIN (hamburger kanan atas).
    # Ia mengandungi SELARAS MAKLUMAT PELESEN — operasi >4 JAM — jadi
    # mengesannya bukan kekemasan, ia perlindungan.
    MENU_SELARAS_TITLE = (AppiumBy.ANDROID_UIAUTOMATOR,
                          'new UiSelector().textMatches("(?i)^\\s*MENU SELARAS\\s*$")')

    def overlay_menutup_skrin(self):
        """Nama overlay yang menutupi skrin, atau None.

        Popup MENU SELARAS hidup pada skrin LOGIN, dan ia mengandungi
        **SELARAS MAKLUMAT PELESEN (>4 jam)**. Selagi ia terbuka, UiAutomator
        hanya melihat tetingkap popup dan skrin login di belakangnya kelihatan
        "tiada".
        """
        try:
            if self.is_element_present(self.MENU_SELARAS_TITLE, timeout=1):
                return "popup MENU SELARAS"
        except Exception:                                     # noqa: BLE001
            pass
        if self.is_element_present(
                (AppiumBy.ID, "modal-surface"), timeout=1):
            return "modal RN (modal-surface)"
        if self.read_native_alert_text(first_timeout=1):
            return "alert asli"
        return None

    def _tolak_alert_pantas(self, had_saat=60):
        """Tolak alert asli pada kelajuan `adb` (~0.5s setiap satu), bukan
        ~24 saat. Pulang `(bilangan, kering)`.

        >>> KENAPA INI WUJUD — kos DIUKUR merentas enam run E2E 2026-08-01.
        Kiraan alert yang berjaya ditolak naik LINEAR dengan bajet masa:
            bajet 120s -> 6-7    bajet 240s -> 13    bajet 600s -> 25
        Kita tidak pernah mengeringkan barisan; kita menolak satu setiap
        ~24 saat sehingga masa habis. Gelung `adb` (dump + tap OK) menolak
        pada ~1.5s dan barisan itu BERHENTI selepas satu atau dua.

        Puncanya `config.IMPLICIT_WAIT = 2`: setiap carian yang TIDAK
        menemui apa-apa membayar dua saat penuh, dan gelung lama membuat
        enam carian sebegitu setiap pusingan. Ubatnya corak yang SUDAH ADA
        dalam `base_page._find_all_by_resource_id()` (`base_page.py:1640`):
        `implicitly_wait(0)` + `find_elements()`, yang memulangkan `[]`
        SERTA-MERTA.

        >>> `implicitly_wait(0)` DIPULIHKAN DALAM `finally`. <<<
        Ia mesti kekal setempat pada gelung ini. Kalau ia terlepas keluar
        dan kekal 0, SETIAP tunggu berasaskan locator dalam suite menjadi
        tiada-tunggu, dan seluruh suite mula melaporkan kegagalan locator
        PALSU — kelas pepijat yang jauh lebih teruk daripada yang kita
        cuba baiki. `finally` menutup setiap laluan keluar, termasuk
        pengecualian dan `return` awal.
        """
        from config import IMPLICIT_WAIT
        import time
        n = 0
        habis = time.monotonic() + had_saat
        terakhir = ""
        self.driver.implicitly_wait(0)
        try:
            while time.monotonic() < habis:
                butang = self.driver.find_elements(*self.NATIVE_ALERT_OK)
                if not butang:
                    # Sahkan KERING, jangan percaya satu tinjauan: salinan
                    # seterusnya perlu masa dilukis. Jeda pendek, tinjau
                    # sekali lagi — kedua-duanya percuma pada implicit 0.
                    time.sleep(0.8)
                    if not self.driver.find_elements(*self.NATIVE_ALERT_OK):
                        return n, True
                    continue

                teks = []
                for loc in (self.NATIVE_ALERT_TITLE, self.NATIVE_ALERT_MESSAGE):
                    el = self.driver.find_elements(*loc)
                    if el:
                        t = (el[0].text or "").strip()
                        if t:
                            teks.append(t)
                msg = " | ".join(teks)
                if msg and msg != terakhir:
                    # Cetak teks BARU sahaja — 60 baris serupa menenggelamkan
                    # log dan menyembunyikan alert yang BERBEZA, yang mungkin
                    # membawa maklumat kegagalan sebenar.
                    print(f"  [ALERT] tolak-pantas: {msg}")
                    terakhir = msg
                try:
                    butang[0].click()
                    n += 1
                except Exception:                             # noqa: BLE001
                    break
                time.sleep(0.3)
            return n, False
        finally:
            self.driver.implicitly_wait(IMPLICIT_WAIT)

    def pastikan_bersih(self, maks=8, had_saat=600):
        """Tolak semua alert + tutup semua popup, SAHKAN bersih.

        WAJIB sebelum menyemak "adakah kita di skrin login?" — lihat
        `is_login_screen_displayed()`.

        >>> PEPIJAT DIBETULKAN 2026-08-01 — `maks` mengira benda yang SALAH.
        Versi lama menghadkan JUMLAH PUSINGAN. Alert asli app ini BERATUR
        (CLAUDE.md), jadi setiap pusingan menolak SATU alert dan melihat
        salinan seterusnya — kemajuan sebenar, tetapi dikira serupa dengan
        "tersekat". Larian E2E 2026-08-01 mati tepat pada sebab itu: barisan
        salinan `BERJAYA | DATA JENIS KENDERAAN SAVED SUCCESSFULLY!` yang
        ditolak satu per pusingan sehingga bajet habis.

        >>> DITARIK BALIK 2026-08-01: barisan itu BUKAN terhingga. <<<
        Nota asal di sini mendakwa "lapan salinan, selesai" berdasarkan satu
        tinjauan `adb` yang menunjukkan tiada alert. Tinjauan itu tidak
        membuktikan apa-apa — popup MENU SELARAS berada di ATAS barisan itu,
        dan `uiautomator` hanya melihat tetingkap teratas. Enam run kemudian:
        63+ alert ditolak, masih datang. Penolakan kini dibuat oleh
        `_tolak_alert_pantas()` dengan siling 60 saat yang MELAPORKAN kadar
        dan bukannya mengeringkan tanpa henti.

        Sekarang `maks` mengira pusingan **TANPA KEMAJUAN**, dan `had_saat`
        menjadi had mutlak. Ini BUKAN melonggarkan gerbang: syaratnya masih
        "skrin mesti bersih, disahkan". Yang berubah hanya: selagi kita
        MEMBUKTIKAN kemajuan (alert benar-benar ditolak, ikon tutup
        ditekan, atau identiti overlay bertukar), kita tidak berputus asa.

        `first_timeout` dinaikkan 2 -> 3 saat: salinan seterusnya dalam
        barisan mengambil lebih 2 saat untuk dilukis, jadi tinjauan 2 saat
        terlepas dan setiap pusingan luar hanya sempat menolak satu.
        """
        import time
        habis = time.monotonic() + had_saat
        tanpa_kemajuan = 0
        jumlah_alert = 0
        sebelum = None
        while time.monotonic() < habis and tanpa_kemajuan < maks:
            o = self.overlay_menutup_skrin()
            if not o:
                if jumlah_alert:
                    print(f"  [LOGIN] skrin bersih selepas {jumlah_alert} "
                          f"alert ditolak")
                return True
            print(f"  [LOGIN] bersihkan: {o}")

            kemajuan = False
            ada_alert = False
            if o == "alert asli":
                # SILING 60 SAAT (syarat pemilik 2026-08-01). Barisan masih
                # tidak kering selepas menolak SELAJU adb bermakna sesuatu
                # MENAMBAH alert lebih laju daripada kita boleh menolaknya —
                # dan itu menjawab soalan "apa yang melepaskan alert ini"
                # secara percuma. Berhenti dan LAPOR kiraan; jangan pusing
                # lagi, jangan naikkan siling.
                n, kering = self._tolak_alert_pantas(had_saat=60)
                jumlah_alert += n
                ada_alert = n > 0
                kemajuan = ada_alert
                if not kering:
                    kadar = n / 60.0
                    print(f"  [LOGIN] HENTI: barisan alert TIDAK kering "
                          f"selepas 60s tolak-pantas — {n} ditolak "
                          f"(~{kadar:.1f}/saat). Sesuatu MENAMBAH alert lebih "
                          f"laju daripada kita menolaknya; ini BUKAN barisan "
                          f"tertunggak yang boleh dikeringkan.")
                    return False
            # >>> KOS DIUKUR 2026-08-01 (run 5): ~18 saat SETIAP alert. <<<
            # `overlay_menutup_skrin()` membuat TIGA carian negatif berturut
            # (MENU SELARAS, modal-surface, alert) dan setiap satu membayar
            # `IMPLICIT_WAIT=2` — jadi ~6 saat sekali panggil. Memanggilnya
            # DUA KALI setiap pusingan membakar 12 daripada 18 saat itu hanya
            # untuk bertanya semula apa yang kita SUDAH tahu. Bila alert baru
            # sahaja ditolak, langkau terus ke pusingan berikutnya: pusingan
            # itu akan mengenal pasti overlay sekali, dengan betul.
            baki_o = None if ada_alert else self.overlay_menutup_skrin()
            if baki_o and baki_o != "alert asli":
                # >>> DIUKUR 2026-08-01, run 2 <<<
                # Cabang ini SENGAJA melangkau alert asli. `close_popup_by_
                # icon()` menyelidik ENAM locator pada `timeout=2` setiap satu
                # = sampai 12 saat DIBAKAR pada overlay yang memang TIADA ikon
                # tutup, dan `press_back()` pula TIDAK menutup alert asli
                # (CLAUDE.md). Jadi untuk alert, kedua-duanya kos tanpa kesan:
                # ~20s setiap alert, dan bajet 120s habis selepas 6 sahaja —
                # itulah yang membunuh run 2, bukan barisan yang tidak
                # berkesudahan. Ukuran adb selepas run: barisan HABIS selepas
                # satu alert lagi, dan skrin login kembali bersih.
                #
                # Bahaya kedua yang dielakkan: `press_back()` pada skrin login
                # yang BERSIH ialah navigasi UNDUR — ia mengeluarkan kita dari
                # app. Hanya tekan Back bila ada modal/popup untuk ditutup.
                if self.close_popup_by_icon(timeout=2):
                    kemajuan = True
                else:
                    self.press_back()
            if o != sebelum:
                # Overlay BERTUKAR identiti = lapisan sebelumnya benar-benar
                # hilang. Itu kemajuan walaupun tiada alert ditolak.
                kemajuan = True
            sebelum = o

            tanpa_kemajuan = 0 if kemajuan else tanpa_kemajuan + 1
            time.sleep(1.2)

        baki = self.overlay_menutup_skrin()
        if baki is None:
            return True
        print(f"  [LOGIN] MENYERAH: overlay {baki!r} kekal selepas "
              f"{jumlah_alert} alert ditolak "
              f"({'had masa' if time.monotonic() >= habis else 'tiada kemajuan'})")
        return False

    def is_login_screen_displayed(self, bersihkan=True):
        """Adakah skrin login kelihatan?

        >>> JANGAN percaya jawapan ini semasa overlay wujud. <<<
        Larian E2E 2026-07-31: popup MENU SELARAS terbuka di atas skrin login,
        jadi kaedah ini memulangkan **False**, dan pemanggil menyimpulkan
        "kita sudah log masuk" — sedangkan medan kata laluan masih placeholder
        `KATA LALUAN` dan login TIDAK pernah berlaku.

        Sekarang ia membersihkan overlay DAHULU (kecuali `bersihkan=False`),
        supaya jawapannya tentang skrin sebenar, bukan tentang apa yang
        menutupinya.
        """
        if bersihkan:
            self.pastikan_bersih()
        return self.is_element_present(self.APP_TITLE, timeout=10)

    def enter_username(self, username):
        """Taip ke medan username, selepas force-clear + baca balik.

        JANGAN kembali kepada wait_and_send_keys() di sini. Ia guna
        el.clear(), yang base_page._force_clear() sendiri dokumenkan
        sebagai KERAP DIABAIKAN oleh RN di bawah no_reset=True. Dua
        keadaan menjadikannya bahaya sebenar, bukan teori:
          - no_reset=True bermakna medan kekal terisi antara run;
          - T-012 (Remember Me) SENGAJA meninggalkan 'msc' tersimpan
            dalam medan, dan ia berjalan SEBELUM setiap TC yang
            memerlukan fixture logged_in.
        Kalau clear diabaikan, teks baharu bercantum ('mscadmin') dan
        SETIAP log masuk selepasnya gagal atas sebab yang kelihatan
        seperti kata laluan salah.
        """
        print(f"  [LOGIN] Entering username: {username}")
        el = self.find_element(self.USERNAME_FIELD)
        self._force_clear(el)
        el.send_keys(username)
        semasa = (self._safe_text(self.find_element(self.USERNAME_FIELD))
                  or "").strip()
        if semasa and semasa.lower() != str(username).strip().lower():
            raise AssertionError(
                f"medan username membaca {semasa!r} selepas menaip "
                f"{username!r} — nilai lama tidak terpadam (Remember Me / "
                f"no_reset). Log masuk akan gagal atas sebab palsu.")
        return el

    PASSWORD_PLACEHOLDER = "KATA LALUAN"

    def enter_password(self, password):
        """Taip ke medan password, selepas force-clear, DENGAN baca-balik.

        Baca-balik BOLEH dibuat walaupun medan bertopeng: bila KOSONG medan
        memaparkan PLACEHOLDER `KATA LALUAN`; bila berisi ia memaparkan titik
        (`•••••`). Jadi kita tidak dapat mengesahkan NILAI, tetapi kita DAPAT
        mengesahkan medan itu **tidak kosong** — dan itulah yang gagal senyap.

        Bukti (larian E2E 2026-07-31, keadaan skrin pada saat gagal):
            EditText: ['admin', 'KATA LALUAN']
        Username masuk, password TIDAK, `send_keys` melempar
        StaleElementReferenceException di tengah jalan (borang RN re-render),
        dan aliran meneruskan seolah-olah login berlaku. Tanpa semakan ini,
        LOGIN ditekan dengan kata laluan KOSONG dan kegagalannya kelihatan
        seperti kredential salah.
        """
        print(f"  [LOGIN] Entering password: {'*' * len(password)}")
        for cuba in (1, 2):
            try:
                el = self.find_element(self.PASSWORD_FIELD)
                self._force_clear(el)
                el.send_keys(password)
            except Exception as e:                            # noqa: BLE001
                print(f"  [LOGIN] menaip kata laluan melempar "
                      f"({type(e).__name__}) — cuba {cuba}/2")
            semasa = (self._safe_text(self.find_element(self.PASSWORD_FIELD))
                      or "").strip()
            kosong = (not semasa) or semasa.upper() == self.PASSWORD_PLACEHOLDER
            if not kosong:
                print(f"  [LOGIN] medan kata laluan TIDAK kosong "
                      f"(dipapar {semasa!r}) — disahkan sebelum tekan LOGIN")
                return self.find_element(self.PASSWORD_FIELD)
            print(f"  [LOGIN] medan kata laluan MASIH kosong selepas menaip "
                  f"(dipapar {semasa!r}) — cuba {cuba}/2")
        raise AssertionError(
            "medan KATA LALUAN masih kosong selepas dua percubaan menaip. "
            "JANGAN tekan LOGIN dengan medan kosong — kegagalannya akan "
            "kelihatan seperti kredential salah dan menyesatkan sesi seterusnya.")

    def click_login(self):
        """Tap the LOGIN button. Hides the keyboard first (still up from
        typing the password) so the button isn't covered."""
        print("  [LOGIN] Clicking LOGIN button")
        self._hide_keyboard_if_shown()
        self.wait_and_click(self.LOGIN_BUTTON)

    def is_home_reached(self, timeout=15):
        """Check (without asserting) whether home screen was reached.

        Checks HOME_SCREEN_INDICATOR (a home-grid module button), NOT
        the hamburger icon.

        B2 — sebab dibetulkan kepada fakta device MBJB. Nota MBIP lama
        berkata hamburger "also exists on the login screen", membayangkan
        ia ada pada kedua-dua skrin; pada MBJB 2.1.33 ia ada pada skrin
        LOGIN SAHAJA (U+F0C9: 2 kali dalam ui_dumps\\01_skrin_awal.xml,
        0 kali dalam ui_dumps\\40_skrin_utama.xml). Semakan lama oleh itu
        rosak DUA HALA: ia mengesahkan 'login berjaya' sedangkan app
        masih pada skrin login (tap LOGIN senyap tidak berkesan), DAN ia
        takkan pernah mengesahkan skrin utama sebenar. Kad NOTIS AMARAN
        ialah satu-satunya bukti yang sah.

        >>> PENGESAHAN LOGIN MBJB = KEHADIRAN SKRIN UTAMA, BUKAN
        KETIADAAN ALERT. <<<
        FAKTA DEVICE, Loh 2026-07-30 (reports\\fasa2-bootstrap.md §2.3
        "Amaran tafsiran — hampir tersalah lapor"; dump ui_dumps\\
        34_selepas_login_admin.xml):
            selepas LOGIN BERJAYA dengan admin/<kata-laluan: profil>, alert ini muncul —
                android:id/alertTitle = 'Alert'
                android:id/message    = 'Error: Unable to connect device'
            Ia BUKAN kegagalan login. Ia kegagalan menyambung PRINTER
            Bluetooth, dan akan muncul pada SETIAP log masuk selagi
            printer dimatikan (printer DITANGGUH — recon\\PAPAN.md §1.5).
            Selepas alert ditolak, skrin utama terpapar penuh.
        LOGIK PENGURASAN ALERT SENGAJA TIDAK DITAMBAH DI SINI — arahan
        Loh 2026-07-30. Ia SUDAH ADA dan sudah dikeraskan di dua tempat
        yang betul, dan menduplikasinya di sini hanya menambah laluan
        kedua yang boleh menyimpang:
          * `tests\\conftest.py` fixture `logged_in` (:338-:373) menguras
            alert printer DAHULU, kemudian mengesahkan melalui
            `home.is_home_screen_displayed()`;
          * `home_page.is_home_screen_displayed()` sendiri menguras alert
            dan menyemak semula sebelum mengaku gagal.
        Kaedah ini kekal sebagai semakan TULEN "adakah kad ada?" —
        `login()` di bawah yang menguras dan mencuba semula. Kriteria
        kejayaan sudah KEHADIRAN SKRIN UTAMA, bukan ketiadaan alert.
        """
        return self.is_element_present(self.HOME_SCREEN_INDICATOR,
                                       timeout=timeout)

    def _force_relaunch_to_login(self):
        """Cold-restart the app and wait for the login screen."""
        from config import APP_PACKAGE
        import time
        self.driver.terminate_app(APP_PACKAGE)
        time.sleep(1)
        self.driver.activate_app(APP_PACKAGE)
        assert self.is_element_present(self.APP_TITLE, timeout=30), \
            "FAIL: Login screen not reached after app relaunch"

    def login(self, username, password, _allow_relaunch_retry=True,
              _cuba_berjeda=3, _jeda_s=30):
        """Complete login flow: enter credentials and tap login.
        Raises AssertionError if home screen is not reached.

        Confirmed via live runs: when login happens right after the
        Menu Selaras popup was closed in-place (no app relaunch), the
        LOGIN tap can silently no-op -- most plausibly a leftover RN
        modal backdrop still swallowing touches -- while the exact same
        flow works every time from a cold start. Recovery ladder:
        drain any covering native alert, re-tap LOGIN with a raw
        coordinate tap, and finally relaunch the app (clean login
        screen guaranteed) and run the whole login once more.

        >>> RETRY BERJEDA UNTUK PENOLAKAN KREDENSIAL — 2026-08-20. <<<
        Run 7/8 (pasca pm-clear): script ditolak DUA KALI dengan
        'Log Masuk Gagal | Nama pengguna atau kata laluan tidak sah',
        kemudian CEO log masuk MANUAL dengan username + kata laluan
        yang SAMA beberapa minit kemudian — LULUS. Kredensial sah;
        penolakan awal ialah keadaan transien pasca-clear (sejurus
        selepas IP/lesen disimpan pada app yang baru dibersihkan), dan
        MASA yang menyembuhkannya. Retry segera tidak membantu — bukti:
        re-tap + relaunch dalam ~1 minit kekal ditolak. Maka bila
        dialog penolakan DILIHAT: tunggu `_jeda_s`, relaunch ke skrin
        login bersih, cuba semula sehingga `_cuba_berjeda` kali."""
        print("\n=== LOGIN FLOW ===")
        # BERSIHKAN DAHULU, baru semak. Larian E2E 2026-07-31 berhenti kerana
        # popup MENU SELARAS terbuka di atas skrin login: semakan "di skrin
        # login?" memulangkan False, pemanggil menyimpulkan "sudah log masuk",
        # dan LOGIN tidak pernah berlaku. Overlay mesti hilang sebelum
        # sebarang soalan tentang skrin bermakna apa-apa.
        if not self.pastikan_bersih():
            raise AssertionError(
                "FAIL: overlay masih menutupi skrin login selepas pembersihan "
                "({}). JANGAN teruskan — tap seterusnya boleh mendarat dalam "
                "MENU SELARAS, yang mengandungi SELARAS MAKLUMAT PELESEN "
                "(>4 jam).".format(self.overlay_menutup_skrin()))
        assert self.is_login_screen_displayed(bersihkan=False), (
            "FAIL: Login screen not displayed"
        )
        print("  [LOGIN] Login screen is displayed — PASS")

        self.enter_username(username)
        self.enter_password(password)
        self.click_login()

        print("  [LOGIN] Waiting for home screen after login...")
        if not self.is_home_reached(timeout=20):
            # Alert asli boleh menutup skrin di sini — dan pada MBJB
            # SATU MEMANG DIJANGKA setiap log masuk: 'Alert' /
            # 'Error: Unable to connect device' (dump ui_dumps\
            # 34_selepas_login_admin.xml). Itu kegagalan PRINTER, BUKAN
            # kegagalan login. Kuras (mesejnya dilog, yang juga
            # mendedahkan ralat login SEBENAR bila ada) dan semak semula.
            # Kejayaan tetap dinilai melalui KEHADIRAN skrin utama.
            teks_alert = self.dismiss_native_alerts(
                first_timeout=3, context="login", kumpul=True)
            import re as _re
            ditolak = any(
                _re.search(r"log\s*masuk\s*gagal|kata\s*laluan\s*tidak"
                           r"\s*sah", t, _re.I)
                for t in (teks_alert or []))
            if ditolak:
                # Penolakan EKSPLISIT — re-tap LOGIN segera cuma hantar
                # semula kredensial yang sama ke keadaan yang sama
                # (terbukti gagal run 7). Laluan sembuh: TUNGGU, relaunch
                # bersih, cuba semula. Lihat blok komen kepala fungsi.
                if _cuba_berjeda > 0:
                    import time as _t
                    print(f"  [LOGIN] kredensial DITOLAK "
                          f"({(teks_alert or ['?'])[-1][:80]}) — "
                          f"transien pasca-clear yang diketahui; tunggu "
                          f"{_jeda_s}s, relaunch, cuba semula "
                          f"({_cuba_berjeda} percubaan berjeda tinggal)...")
                    _t.sleep(_jeda_s)
                    self._force_relaunch_to_login()
                    return self.login(
                        username, password,
                        _allow_relaunch_retry=_allow_relaunch_retry,
                        _cuba_berjeda=_cuba_berjeda - 1,
                        _jeda_s=_jeda_s)
                raise AssertionError(
                    "FAIL: kredensial DITOLAK oleh app pada SETIAP "
                    "percubaan berjeda ('Log Masuk Gagal | Nama pengguna "
                    "atau kata laluan tidak sah'). Kredensial profil "
                    "disahkan sah secara manual 2026-08-20, jadi kalau "
                    "ini berterusan melebihi tetingkap transien "
                    "pasca-clear, semak: (a) kata laluan msc di server, "
                    "(b) sama ada sync 'Selaras Pengguna Apps' perlu "
                    "berjaya dahulu (jadual pengguna lokal).")
            if not self.is_home_reached(timeout=5):
                print("  [LOGIN] Home not reached -- re-tapping LOGIN "
                      "with a raw coordinate tap...")
                self._hide_keyboard_if_shown()
                try:
                    self.wait_and_tap(self.LOGIN_BUTTON, timeout=5)
                except Exception:
                    pass
                if not self.is_home_reached(timeout=15):
                    assert _allow_relaunch_retry, (
                        "FAIL: Home screen did not appear after login "
                        "(even after re-tap and a clean relaunch attempt)"
                    )
                    print("  [LOGIN] Still no home screen -- relaunching "
                          "the app for one clean login attempt...")
                    self._force_relaunch_to_login()
                    return self.login(username, password,
                                      _allow_relaunch_retry=False)
        print("  [LOGIN] Login successful — home screen reached — PASS")

    def handle_license_mismatch(self, internal_ip, external_ip, device_id,
                                 username, password):
        """Run the licensing/IP setup sub-flow, then relogin.
        Only needed if a normal login() does not reach the home screen.
        """
        print("\n=== LICENSE MISMATCH FLOW ===")

        # Keputusan Loh 2026-07-30: wait_and_tap, BUKAN wait_and_click.
        # BRIEF Seksyen 3 ialah penemuan device yang disahkan — el.click()
        # (ACTION_CLICK aksesibiliti) SENYAP tidak berkesan pada Pressable
        # RN app ini. Meninggalkan primitif yang diketahui rosak dalam
        # laluan jaring bermakna bila laluan ini akhirnya berjalan (run
        # penuh, lesen benar-benar tidak padan) ia gagal SENYAP — mod
        # kegagalan paling mengelirukan yang suite ini cuba hapuskan.
        # pelarasan_page.open_menu_selaras() sudah guna wait_and_tap pada
        # HAMBURGER yang SAMA.
        #
        # >>> PERATURAN: Pressable RN -> wait_and_tap.  Widget ASLI -> click.
        # JANGAN SERAGAMKAN KEDUA-DUANYA. <<<
        # Ini BUKAN gaya, ia dua jenis widget yang berbeza:
        #   * HAMBURGER / item menu / SIMPAN = Pressable React Native tersuai
        #     yang TIDAK menyambung ACTION_CLICK aksesibiliti. el.click()
        #     dilaporkan "berjaya" tetapi app tidak menerima apa-apa
        #     (BRIEF Seksyen 3). Mesti tap koordinat mentah = wait_and_tap.
        #   * BUTTON_OK = `android:id/button1`, Button ASLI Android di dalam
        #     alert ASLI (bukan RN sama sekali). ACTION_CLICK MEMANG
        #     berfungsi di situ — base_page.dismiss_native_alerts() bergantung
        #     padanya. Menukarnya kepada tap koordinat menambah risiko
        #     (koordinat alert berubah ikut saiz dialog) TANPA faedah.
        # Sebab itu satu-satunya wait_and_click yang KEKAL di bawah ialah
        # BUTTON_OK. Itu disengajakan, bukan tertinggal.
        #
        # SAHKAN-DEVICE: keseluruhan handle_license_mismatch() BELUM PERNAH
        # dijalankan pada MBJB — lesen m50 diterima pada percubaan pertama
        # (reports\fasa2-bootstrap.md §2.3), jadi jaring ini tidak pernah
        # dipicu. Kelima-lima tap di bawah (hamburger, 2 item menu, 2 SIMPAN)
        # belum pernah disahkan pada device MBJB.
        print("  [LICENSE] Opening hamburger menu...")
        self.wait_and_tap(self.HAMBURGER)

        print("  [LICENSE] Opening Tetapan Alamat IP...")
        self.wait_and_tap(self.MENU_TETAPAN_ALAMAT_IP)

        print(f"  [LICENSE] Setting internal IP: {internal_ip}")
        self.fill_field_by_label(self.FIELD_INTERNAL_IP_LABEL, internal_ip)

        print(f"  [LICENSE] Setting external IP: {external_ip}")
        self.fill_field_by_label(self.FIELD_EXTERNAL_IP_LABEL, external_ip)

        print("  [LICENSE] Clicking Simpan...")
        self.wait_and_tap(self.BUTTON_SIMPAN)

        print("  [LICENSE] Opening Tetapan Pelbagai...")
        self.wait_and_tap(self.MENU_TETAPAN_PELBAGAI)

        print(f"  [LICENSE] Setting device ID: {device_id}")
        self.fill_field_by_label(self.FIELD_DEVICE_ID_LABEL, device_id)

        print("  [LICENSE] Clicking Simpan...")
        self.wait_and_tap(self.BUTTON_SIMPAN)

        print("  [LICENSE] Waiting for 'Lesen sama' popup...")
        assert self.is_element_present(self.POPUP_LESEN_SAMA, timeout=10), \
            "FAIL: 'Lesen sama' popup did not appear"
        # click (BUKAN tap) DENGAN SENGAJA — Button asli dalam alert asli.
        # Lihat peraturan Pressable-vs-asli di kepala fungsi ini.
        print("  [LICENSE] Popup visible — clicking OK...")
        self.wait_and_click(self.BUTTON_OK)

        print("  [LICENSE] Tapping outside popup to return to login...")
        # ASSUMPTION: tapping the app title area dismisses the popup context
        self.driver.tap([(540, 200)])
        import time
        time.sleep(1)

        print("  [LICENSE] Re-attempting login...")
        self.login(username, password)

    def login_with_license_fallback(self, username, password,
                                     internal_ip=None, external_ip=None,
                                     device_id=None):
        """Try a normal login first; if it fails, run the license setup
        sub-flow and retry. If internal_ip/external_ip/device_id are not
        provided, this will simply re-raise the original login failure.
        """
        try:
            self.login(username, password)
        except AssertionError as e:
            print(f"  [LOGIN] Initial login failed ({e})")
            if internal_ip and external_ip and device_id:
                self.handle_license_mismatch(
                    internal_ip, external_ip, device_id, username, password
                )
            else:
                raise

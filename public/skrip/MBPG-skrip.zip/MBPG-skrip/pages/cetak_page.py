"""
CETAK / PRINTER — MBPG 2.1.21.

>>> KENAPA MODUL INI KECIL, SEDANGKAN MBJB PUNYA 1,388 BARIS. <<<
Modul MBJB (`printer_connect_page.py` 911 baris + `cetak_page.py` 477)
membina keseluruhan aliran sambungan Bluetooth: membuka popup,
MENSKROL senarai peranti berpasangan, mengetuk Connect pada baris yang
betul, menaip kata laluan pasangan, kemudian MEMBACA WARNA PIKSEL ikon
printer untuk memutuskan sama ada sambungan menjadi.

Recon langsung MBPG (2026-08-13, docs/recon/cetak-C-popup-printer.xml)
menunjukkan MBPG tidak memerlukan satu pun daripadanya. Popup printer
MBPG ialah paparan STATUS, bukan pemilih peranti:

    Bluetooth Active
    Printer connected to the application:
    SPP-R410_110095
    74:F0:7D:A9:88:75

Tiada senarai peranti, tiada butang Connect/Disconnect, tiada medan
kata laluan. Menyalin 1,388 baris MBJB ke sini akan membawa masuk
pembacaan warna piksel dan skrol popup untuk UI yang tidak wujud — kod
yang tidak boleh dijalankan dan tidak boleh dipercayai.

Yang DIPORT ialah satu perkara yang memang padan: locator ikon
printer. Glifnya DISAHKAN identik dengan MBJB (U+F042A) dan pada
koordinat yang SAMA ([798,168][870,240] dalam Button
[774,144][894,264]).

>>> APA YANG MASIH BELUM DIKETAHUI. <<<
Butang CETAK itu sendiri. Ia hanya muncul selepas satu rekod WUJUD:
skrin Senarai MBPG ialah borang carian (julat tarikh + SEMUA + SEMAK)
dengan jadual kosong, dan recon berjalan dengan sifar rekod dalam DB.
Jadi `cari_rekod()` di bawah dibina daripada apa yang dilihat, dan
`cetak_rekod()` SENGAJA menolak untuk meneka — ia membongkar skrin dan
melaporkan, supaya laluan sebenar diport dari bukti dan bukan dari
andaian. Itu tepat kesilapan yang port kamera buat dan yang kita
bayar dua kali.
"""

import re
import time
import xml.etree.ElementTree as ET

from appium.webdriver.common.appiumby import AppiumBy

from pages.base_page import BasePage


class PrinterTidakSedia(BaseException):
    """Printer tidak bersambung / tidak boleh disahkan.

    BaseException atas sebab yang sama seperti SerahTidakDiizinkan:
    `base_page.py` membawa 66 blok `except Exception` dan setiap gelung
    cuba-semula dibina atasnya.
    """


class CetakPage(BasePage):

    # Glif ikon printer. DISAHKAN pada MBPG (recon 2026-08-13) DAN
    # identik dengan MBJB. Escape, bukan glif mentah: encoding console
    # merosakkan glif mentah -- pelajaran dari U+F1BA/U+F1FD kamera.
    GLIF_PRINTER = "\U000f042a"

    # Butang bar-atas dipilih melalui glif ANAKNYA. Menapis ikut glif
    # WAJIB: skrin utama MBPG membawa LAPAN Button resource-id
    # 'icon-button' (3 pada bar atas + 5 dalam kad modul), dan
    # ketiga-tiga butang bar atas TIADA content-desc. Padanan ikut id
    # atau kedudukan akan mengetuk butang yang salah.
    IKON_PRINTER = (AppiumBy.XPATH,
                    '//android.widget.Button[.//android.widget.TextView'
                    f'[@text="{GLIF_PRINTER}"]]')

    # Isyarat popup status terbuka.
    POPUP_BLUETOOTH = (AppiumBy.ANDROID_UIAUTOMATOR,
                       'new UiSelector().textMatches('
                       '"(?i).*bluetooth\\s*active.*")')
    POPUP_TERSAMBUNG = (AppiumBy.ANDROID_UIAUTOMATOR,
                        'new UiSelector().textMatches('
                        '"(?i).*printer\\s+connected.*")')
    TUTUP_MODAL = (AppiumBy.ACCESSIBILITY_ID, "Close modal")

    # Nama peranti: huruf/angka dengan sengkang bawah, cth SPP-R410_110095
    _NAMA_PRINTER = re.compile(r"^[A-Z][A-Za-z0-9]*(?:-[A-Za-z0-9]+)*"
                               r"_\d+$")
    _MAC = re.compile(r"^(?:[0-9A-F]{2}:){5}[0-9A-F]{2}$", re.I)

    # ------------------------------------------------------------------
    def _teks_skrin(self):
        try:
            akar = ET.fromstring(self.driver.page_source.encode("utf-8"))
        except Exception:                                       # noqa: BLE001
            return []
        keluar = []
        for n in akar.iter():
            for atr in ("text", "content-desc"):
                v = (n.get(atr) or "").strip()
                if v and v not in keluar:
                    keluar.append(v)
        return keluar

    def buka_status_printer(self):
        """Buka popup status printer. Baca-sahaja."""
        print("  [CETAK] membuka status printer...")
        el = self.find_clickable(self.IKON_PRINTER)
        self.tap_element(el)
        time.sleep(2.5)
        return self.is_element_present(self.POPUP_BLUETOOTH, timeout=5)

    def tutup_status_printer(self):
        """Tutup popup status.

        >>> JANGAN ketuk 'Close modal' melalui tap_element(). <<<
        Backdrop itu ialah Button SELUAS SKRIN ([0,108][1080,2316]),
        jadi tap_element() mengetuk PUSATNYA — (540,1212) — yang jatuh
        pada kad modul di belakang popup, bukan pada jalur backdrop.
        Kesannya: popup ditutup DAN kad tersentuh, dan skrin seterusnya
        bukan yang dijangka. Itu berlaku pada larian 2A pertama: borang
        tidak pernah dibuka dan run mati mencari tab PESALAH pada skrin
        utama.

        `_tutup_modal_rn_melalui_backdrop()` (base_page) mengira titik
        di BAWAH panel dan enggan mengetuk kalau ia tidak dapat
        mengesahkan sempadan panel. Ia sudah dibuktikan 3/3 pada MENU
        SELARAS.
        """
        if self._tutup_modal_rn_melalui_backdrop():
            return True
        # Sandaran: ikon tutup panel sendiri, kemudian BACK.
        if self.close_popup_by_icon(timeout=3):
            return True
        print("  [CETAK] backdrop dan ikon tutup gagal — BACK peranti")
        self.press_back()
        time.sleep(1)
        return False

    def baca_status_printer(self):
        """{'bluetooth', 'tersambung', 'nama', 'mac', 'teks'}.

        Membaca dari popup itu sendiri, bukan dari warna ikon. MBPG
        menyatakan statusnya dalam TEKS -- membaca teks yang app tulis
        lebih dipercayai daripada menganggarkan warna piksel, dan ia
        tidak boleh gagal secara senyap bila tema atau DPI berubah.
        """
        teks = self._teks_skrin()
        nama = next((t for t in teks if self._NAMA_PRINTER.match(t)), None)
        mac = next((t for t in teks if self._MAC.match(t)), None)
        gab = " | ".join(teks)
        # >>> `sah` ditambah 2026-08-13. <<< Fungsi ini membaca SKRIN
        # SEMASA. Dipanggil pada skrin yang BUKAN popup status printer
        # ia memulangkan False/False -- yang kelihatan sama seperti
        # "printer terputus" sedangkan maksudnya "saya melihat tempat
        # yang salah". Itu berlaku semasa cetakan pertama: laporan
        # mencatat bluetooth=False pada skrin popup CETAK, beberapa
        # minit selepas printer disahkan tersambung.
        return {
            "sah": bool(re.search(r"bluetooth\s*(active|inactive)", gab,
                                  re.I)),
            "bluetooth": bool(re.search(r"bluetooth\s*active", gab, re.I)),
            "tersambung": bool(re.search(r"printer\s+connected", gab,
                                         re.I)),
            "nama": nama,
            "mac": mac,
            "teks": teks,
        }

    def sahkan_printer_sedia(self, wajib=True):
        """Buka status, baca, tutup. Bangkitkan kalau tidak sedia.

        `wajib=False` memulangkan laporan tanpa membangkitkan — untuk
        larian yang pemilik benarkan teruskan tanpa cetakan.
        """
        dibuka = self.buka_status_printer()
        laporan = self.baca_status_printer() if dibuka else {
            "bluetooth": False, "tersambung": False, "nama": None,
            "mac": None, "teks": []}
        self.tutup_status_printer()
        print(f"  [CETAK] bluetooth={laporan['bluetooth']} "
              f"tersambung={laporan['tersambung']} "
              f"printer={laporan['nama']!r}")
        if wajib and not (laporan["bluetooth"] and laporan["tersambung"]):
            raise PrinterTidakSedia(
                f"Printer tidak sedia: bluetooth={laporan['bluetooth']}, "
                f"tersambung={laporan['tersambung']}, "
                f"nama={laporan['nama']!r}. Hidupkan printer dan pastikan "
                f"ia bersambung, kemudian ulang. Teks popup: "
                f"{laporan['teks']}")
        return laporan

    # ------------------------------------------------------------------
    # Senarai — laluan mencari rekod untuk dicetak
    # ------------------------------------------------------------------
    # Struktur DISAHKAN (recon 2026-08-13, docs/recon/cetak-B-senarai.xml):
    #   'Senarai Kompaun'  tajuk
    #   julat tarikh       dua TextView, lalai hari ini -> esok
    #   Spinner 'SEMUA'    penapis jenis
    #   'SEMAK'            ViewGroup clickable, mencari
    #   jadual             NO / NO AKAUN / KETERANGAN (kosong pada recon)
    BUTANG_SEMAK = (AppiumBy.ANDROID_UIAUTOMATOR,
                    'new UiSelector().descriptionMatches("(?i)\\s*SEMAK\\s*")')
    TAJUK_SENARAI = (AppiumBy.ANDROID_UIAUTOMATOR,
                     'new UiSelector().textMatches("(?i).*senarai.*")')

    def cari_rekod(self, no_rekod, timeout=20):
        """Tekan SEMAK, kemudian cari baris yang membawa `no_rekod`.

        Memulangkan (dijumpai, teks_skrin). TIDAK mengetuk baris itu:
        apa yang berlaku selepas ketukan belum pernah dilihat.
        """
        print(f"  [CETAK] mencari rekod {no_rekod!r} dalam Senarai...")
        try:
            self.tap_element(self.find_clickable(self.BUTANG_SEMAK))
        except Exception as e:                                  # noqa: BLE001
            print(f"  [CETAK] SEMAK tidak boleh diketuk: "
                  f"{type(e).__name__}")
        time.sleep(3)
        tamat = time.time() + timeout
        while time.time() < tamat:
            teks = self._teks_skrin()
            if any(no_rekod in t for t in teks):
                print(f"  [CETAK] rekod {no_rekod} DIJUMPAI dalam senarai")
                return True, teks
            time.sleep(2)
        return False, self._teks_skrin()

    # ------------------------------------------------------------------
    # Popup kejayaan selepas serah — INILAH laluan cetak
    # ------------------------------------------------------------------
    # >>> DIPORT DARI BUKTI 2026-08-13, serah PGP02N260813006. <<<
    # Saya sebelum ini menjangka cetakan berlaku melalui skrin Senarai.
    # Ia tidak. Popup kejayaan yang muncul SEBAIK selepas HANTAR
    # membawa butang CETAK terus:
    #
    #   ViewGroup klik=true  [906,929][996,1019]   desc='X'
    #   TextView             [232,1049][848,1122]  'CETAK NOTIS AMARAN ?'
    #   TextView             [221,1137][859,1202]  'No Notis: PGP02N260813006'
    #   ViewGroup klik=true  [99,1319][981,1446]   desc='CETAK'
    #
    # Popup ini TAHAN LASAK: ia terselamat daripada sesi Appium ditutup,
    # skrin tidur, dan bidai pemberitahuan ditarik ke bawah. Fokus
    # kembali kepadanya sebaik peranti dikejutkan.
    POPUP_CETAK = (AppiumBy.ANDROID_UIAUTOMATOR,
                   'new UiSelector().textMatches('
                   '"(?i).*cetak\\s+(notis|kompaun).*\\?.*")')
    POPUP_NO_REKOD = (AppiumBy.ANDROID_UIAUTOMATOR,
                      'new UiSelector().textMatches('
                      '"(?i).*no\\s+(notis|kompaun)\\s*:.*")')
    BUTANG_CETAK = (AppiumBy.ANDROID_UIAUTOMATOR,
                    'new UiSelector().descriptionMatches("(?i)\\s*CETAK\\s*")')
    # >>> DITAMBAH 2026-09-13 -- Fix #4 (blocker larian 10/9). <<<
    # Butang X MERAH atas-kanan popup ini, content-desc='X' ikut bukti
    # 2026-08-13 (dump serah PGP02N260813006): ViewGroup klik=true
    # [906,929][996,1019] desc='X'. Padanan EKSAK ("^X$") sengaja, bukan
    # descriptionMatches longgar -- 'X' ialah satu huruf sahaja dan
    # padanan longgar boleh terkena elemen lain yang mengandungi 'X'.
    BUTANG_TUTUP_POPUP_CETAK = (
        AppiumBy.ANDROID_UIAUTOMATOR,
        'new UiSelector().descriptionMatches("(?i)^\\s*X\\s*$")')

    def popup_cetak_terbuka(self, no_rekod=None, timeout=5):
        """(terbuka, no_rekod_pada_popup).

        Nombor pada popup DIBACA dan dibandingkan, bukan diandaikan.
        Menekan CETAK pada popup rekod yang SALAH akan mencetak rekod
        yang salah, dan tiada cara menariknya balik selepas kertas
        keluar.
        """
        if not self.is_element_present(self.POPUP_CETAK, timeout=timeout):
            return False, None
        pada_popup = None
        for t in self._teks_skrin():
            m = re.search(r"no\s+(?:notis|kompaun)\s*:\s*([A-Z0-9]+)", t,
                          re.I)
            if m:
                pada_popup = m.group(1)
                break
        if no_rekod and pada_popup and pada_popup != no_rekod:
            raise PrinterTidakSedia(
                f"Popup cetak menunjukkan {pada_popup!r} tetapi rekod yang "
                f"hendak dicetak ialah {no_rekod!r}. ENGGAN menekan CETAK "
                f"— cetakan yang salah tidak boleh ditarik balik.")
        return True, pada_popup

    def cetak_dari_popup(self, no_rekod):
        """Tekan CETAK pada popup kejayaan. SATU percubaan sahaja.

        >>> TIADA CUBA-SEMULA. <<< Setiap ketukan CETAK yang berjaya
        mengeluarkan sehelai kertas. Gelung cuba-semula yang tidak dapat
        membezakan "tidak dihantar" daripada "dihantar tetapi respons
        tidak dibaca" akan mengeluarkan salinan bertindan sehingga ia
        akhirnya membaca sesuatu. Satu ketukan, kemudian laporkan apa
        yang berlaku — mata manusia yang mengesahkan kertas.
        """
        terbuka, pada_popup = self.popup_cetak_terbuka(no_rekod)
        if not terbuka:
            raise PrinterTidakSedia(
                "Popup cetak TIDAK terbuka. Laluan cetak melalui Senarai "
                "belum diport — jangan improvise.")
        print(f"  [CETAK] popup mengesahkan rekod {pada_popup!r}")
        sebelum = self._teks_skrin()
        el = self.find_clickable(self.BUTANG_CETAK)
        print("  [CETAK] menekan CETAK (satu percubaan, tiada ulangan)...")
        self.tap_element(el)
        time.sleep(6)
        selepas = self._teks_skrin()
        baharu = [t for t in selepas if t not in sebelum]
        popup_tutup = not self.is_element_present(self.POPUP_CETAK,
                                                  timeout=3)
        print(f"  [CETAK] popup tertutup selepas CETAK: {popup_tutup}")
        if baharu:
            print(f"  [CETAK] teks BAHARU pada skrin: {baharu}")
        return {"no_rekod": pada_popup, "popup_tutup": popup_tutup,
                "teks_baharu": baharu, "teks_selepas": selepas}

    def tutup_popup_cetak(self, no_rekod=None, timeout=3):
        """Tutup popup 'CETAK ... ?' melalui butang X MERAH.

        >>> DITAMBAH 2026-09-13 -- Fix #4 (blocker larian 10/9). <<<
        JANGAN SEKALI-KALI tekan CETAK di sini. Ini fungsi PEMULIHAN
        (dipanggil dari pastikan_di_home() / laluan back-out), bukan
        laluan cetak sengaja -- laluan itu ialah cetak_dari_popup().

        Bukti punca (forensik 2026-09-10, reports/forensik/20260910-
        152937-borang-N.png): popup ini muncul selepas SERAH/kemaskini
        dan KEKAL TERBUKA -- ia modal JS React Native, BUKAN alert
        native Android, jadi dismiss_native_alerts() dan tekanan back
        peranti (8x, ~365s dlm pastikan_di_home()) tiada kesan
        langsung. Itu punca pastikan_di_home() gagal pulang ke skrin
        utama pada SEMUA 5 percubaan borang (N/P/K x3) larian tersebut,
        yang seterusnya menyebabkan peringkat_senarai() (SK-001) gagal
        kerana kad SENARAI tidak boleh diklik (tertutup oleh popup).

        Pulang True kalau popup TIDAK/tidak-lagi ada (selamat untuk
        teruskan), False kalau ia dikesan tetapi gagal ditutup.
        """
        terbuka, pada_popup = self.popup_cetak_terbuka(no_rekod,
                                                        timeout=timeout)
        if not terbuka:
            return True
        print(f"  [CETAK] popup 'CETAK ... ?' TERBUKA (rekod="
              f"{pada_popup!r}) -- menutup via X MERAH, BUKAN menekan "
              f"CETAK")
        try:
            el = self.find_clickable(self.BUTANG_TUTUP_POPUP_CETAK,
                                     timeout=timeout)
            self.tap_element(el)
        except Exception as e:                                    # noqa: BLE001
            print(f"  [CETAK] butang X tidak dijumpai/tidak boleh "
                  f"diketuk ({type(e).__name__}: {e}) -- cuba backdrop")
            if not self._tutup_modal_rn_melalui_backdrop():
                print("  [CETAK] backdrop pun gagal -- BACK peranti")
                self.press_back()
        time.sleep(1.5)
        masih_ada = self.is_element_present(self.POPUP_CETAK,
                                            timeout=timeout)
        if masih_ada:
            print("  [CETAK] AMARAN: popup CETAK masih kelihatan "
                  "selepas cuba tutup")
        else:
            print("  [CETAK] popup CETAK ditutup — PASS (tiada cetakan "
                  "dikeluarkan)")
        return not masih_ada

    def cetak_rekod(self, no_rekod):
        """>>> LALUAN SENARAI SENGAJA BELUM DIBINA. <<<

        Butang CETAK tidak pernah dilihat: ia hanya muncul selepas satu
        rekod wujud, dan recon berjalan dengan sifar rekod dalam DB.

        Menulis laluan ketukan sekarang bermakna meneka locator, susunan
        skrin, dan teks dialog untuk UI yang tiada siapa pernah lihat —
        tepat kesilapan yang port kamera buat, di mana locator sebenarnya
        BETUL tetapi dua andaian tersembunyi memecahkannya dan hanya
        larian sebenar mendedahkannya.

        Sebaik rekod pertama wujud, panggil `cari_rekod()` kemudian
        bongkar skrin; laluan sebenar diport dari dump itu.
        """
        raise PrinterTidakSedia(
            f"Laluan CETAK untuk {no_rekod} belum diport: butang CETAK "
            f"belum pernah dilihat kerana ia hanya muncul selepas rekod "
            f"wujud, dan recon berjalan dengan 0 rekod. Jalankan "
            f"cari_rekod() pada rekod sebenar, bongkar skrin, kemudian "
            f"port dari bukti itu.")

"""
Senarai (List) page — Page Object Model.
Flow: Open calendar -> tap start day -> tap end day (picker auto-closes) ->
click Semak -> records displayed.

NOTE: per the real manual flow, the date picker is a calendar you tap days
on (not text fields to type dates into). The previous version of this file
incorrectly used send_keys() on non-existent date text fields.

NOTE: "Hantar" (Hantar Data / Hantar Gambar / Data Ralat / Hantar Semula)
is its own separate menu — see hantar_page.py. It has been removed from
this file.

PORT MBJB
---------
1. Awalan nombor rekod tidak lagi 'IPA' -- ia datang daripada profil aktif
   (base_page._record_prefix()).
2. open_record_by_number() dikekalkan BULAT-BULAT termasuk keengganannya
   untuk jatuh ke baris lain. Itu pembetulan bug terbesar MBIP; jangan
   tambah fallback "baris pertama/terakhir" di sini walau apa pun.
3. Kaedah baharu untuk 8 TC MBJB yang tiada dalam MBIP:
   read_record_popup_fields() / get_lokasi_kesalahan_from_popup()  -> *-006
   tokens_for_number() / row_status_for_number()                   -> *-007

KONTRAK by-number (recon\kontrak_by_number.md §1.1) — tandatangan MUKTAMAD
yang lapisan test MESTI panggil:
   open_record_by_number(no_rekod, max_scrolls=20) -> bool
   record_popup_shows_number(no_rekod)             -> bool
   tokens_for_number(no_rekod)                     -> list[str] | None
   find_number_and_tokens(no_rekod, max_scrolls=20)-> list[str] | None
   numbers_for_jenis(jenis_letter, max_scrolls=20) -> list[str]  (MELEMPAR)
   get_row_status_tokens()                         -> dict  (TIADA no_rekod)
   open_record_by_jenis(jenis_letter, dump_name=None)  (recon/SK-001 SAHAJA)
"""

from appium.webdriver.common.appiumby import AppiumBy
from pages.base_page import BasePage, _record_prefix


# ----------------------------------------------------------------------
# C-15 — ISYARAT TUNGGU, BUKAN `sleep` TETAP.
#
# Loh mengesahkan pada device 2026-07-30 bahawa overlay sibuk BOLEH
# dilihat oleh uiautomator: text="SELARAS MAKLUMAT ALAMAT SEDANG
# DIPROSES..." (reports\fasa2-bootstrap.md, PENEMUAN TEKNIKAL BAHARU #4).
# Kehilangan "SEDANG DIPROSES" ialah isyarat SEBENAR bahawa operasi
# tamat; sleep tetap sama ada terlalu pendek (tap seterusnya ditelan
# overlay) atau terlalu panjang (membazir masa pada run 90-120 minit).
#
# Fungsi ini adalah peringkat-modul supaya senarai/hantar/kemaskini
# berkongsi SATU salinan — tiada fail `pages/` baharu boleh dicipta
# (R2, satu fail satu pemilik) dan base_page.py ialah SALIN BULAT.
#
# >>> DILUASKAN 2026-09-13 -- Fix #5 (blocker larian 13/9, borang P +
# K x3, SEMUA gagal identik pada peringkat_senarai -> open_senarai,
# "SENARAI" not clickable after 15s). <<<
#
# Punca sebenar dikenal pasti melalui bukti forensik
# (reports\forensik\20260913-210238-borang-P.{png,xml} dan
# 20260913-212203-borang-K--1-3--JYX6605.{png,xml}): selepas
# MENYERAHKAN/HANTAR pada borang KEMASKINI (P dan K), app memaparkan
# modal overlay BUKAN native, BUKAN "SEDANG DIPROSES" -- teksnya
# "MENGHANTAR DATA KOMPAUN..." (borang P) / "MENGHANTAR DATA KE
# SERVER..." (borang K), dengan ProgressBar + "100%", TIADA butang
# (semua node dalam modal clickable="false" -- disahkan dari dump XML
# penuh, tiada laluan tutup selain tunggu ia hilang sendiri).
#
# Corak lama HANYA padan "SEDANG DIPROSES", jadi
# tunggu_selesai_diproses() pulang True SERTA-MERTA (0-2s) tanpa
# menunggu overlay INI langsung -- kod terus ke peringkat seterusnya
# (buka Senarai) sedangkan modal MASIH menutup skrin, jadi SENARAI
# tidak dapat diketuk. Fix #4 (popup CETAK NOTIS AMARAN) BETUL tetapi
# menangani modal LAIN yang tidak berkaitan symptom ini -- rekod
# sebenarnya BERJAYA dicipta (disahkan semula pada peringkat menu akhir
# larian 13/9), jadi overlay ini bukan kegagalan hantar, ia kegagalan
# PENGESAN kita mengiktiraf overlay yang wujud.
#
# Pembetulan: luaskan padanan kepada turut merangkumi
# "MENGHANTAR\s+DATA" supaya fungsi ini BENAR-BENAR menunggu (sehingga
# `timeout`) sebelum meneruskan, seperti yang ia patut buat untuk
# "SEDANG DIPROSES". SAHKAN-DEVICE: sama ada modal ini hilang sendiri
# dalam tempoh timeout, atau kekal selama-lamanya (memerlukan pemulihan
# tambahan di pastikan_di_home), belum disahkan langsung -- larian akan
# datang MESTI melapor False/True di sini untuk tentukan.
# ----------------------------------------------------------------------

OVERLAY_DIPROSES = (AppiumBy.ANDROID_UIAUTOMATOR,
                    'new UiSelector().textMatches('
                    '"(?i).*(SEDANG\s+DIPROSES|MENGHANTAR\s+DATA).*")')


def tunggu_selesai_diproses(page, timeout=180, tag="TUNGGU"):
    """Tunggu overlay sibuk hilang. Pulang True bila ia hilang (atau tidak
    pernah ada), False bila ia MASIH ada selepas `timeout`.

    Pulangan False mesti DILAPORKAN oleh pemanggil, bukan diabaikan:
    operasi yang belum selesai bermakna keadaan yang diuji seterusnya
    belum wujud.

    # SAHKAN-DEVICE: teks overlay disahkan hanya pada aliran SELARAS.
    # Sama ada Senarai/Hantar/Kemaskini MBJB menggunakan overlay yang
    # SAMA belum disahkan — padanan `textContains("SEDANG DIPROSES")`
    # sengaja luas supaya ia menampung variasi awalan."""
    import time
    if not page.is_element_present(OVERLAY_DIPROSES, timeout=2):
        return True
    print(f"  [{tag}] overlay 'SEDANG DIPROSES' kelihatan — menunggu ia "
          f"hilang (had {timeout}s)")
    habis = time.monotonic() + timeout
    while time.monotonic() < habis:
        if not page.is_element_present(OVERLAY_DIPROSES, timeout=2):
            return True
        time.sleep(2)
    print(f"  [{tag}] overlay 'SEDANG DIPROSES' MASIH ada selepas "
          f"{timeout}s — melaporkan, bukan meneruskan secara membuta")
    return False


class SenaraiPage(BasePage):
    """Senarai screen — record listing with calendar date filter."""

    # ---- Page title ----
    # `textContains` UiSelector adalah PEKA HURUF BESAR-KECIL, dan app ini
    # MEMAKSA HURUF BESAR pada label/tajuk (fakta device, Loh 2026-07-30:
    # tajuk skrin utama = "KOMPUAN e-PBT", kad = "SENARAI", medan borang
    # menukar "blank dari test script" -> "BLANK DARI TEST SCRIPT" —
    # reports\fasa2-bootstrap.md §2.4). Jadi textContains("Senarai")
    # TIDAK memadan "SENARAI" dan is_senarai_screen_displayed() akan
    # sentiasa False -> setiap TC -002/-003/-004/-006/-007 gagal dengan
    # "Skrin Senarai tidak dipaparkan", satu kegagalan PALSU yang
    # puncanya locator kita.
    #
    # Padanan diperluas kepada tidak-peka-huruf TETAPI DIKUNCI kepada
    # elemen tajuk app-bar: `resource-id="appbar-content-title-text"`
    # (disahkan pada device, dump ui_dumps\40_skrin_utama.xml). Ini WAJIB
    # — tanpa kunci itu, kad "SENARAI" pada SKRIN UTAMA (TextView,
    # resource-id kosong, dump yang sama) juga akan padan dan
    # is_senarai_screen_displayed() memulangkan True sambil kita berada di
    # skrin utama. Itu akan memecahkan pengawal C-4a.
    #
    # SEMAK (content-desc tepat "SEMAK") ialah isyarat kedua: ia hanya ada
    # pada skrin Senarai. Item menu "SEMAK KEMASKINI VERSI TERKINI " TIDAK
    # padan kerana ACCESSIBILITY_ID ialah padanan TEPAT.
    #
    # SAHKAN-DEVICE: skrin Senarai belum pernah di-dump (fasa2 §RINGKASAN
    # "Skrin Senarai ... belum dibuka"), jadi teks tepat tajuk app-barnya
    # ("SENARAI" / "SENARAI KOMPAUN" / lain) belum diketahui. Corak
    # `.*senarai.*` menampung ketiga-tiganya; rekod nilai sebenar selepas
    # dump pertama dan ketatkan.
    PAGE_TITLE = (AppiumBy.ANDROID_UIAUTOMATOR,
                  'new UiSelector().resourceId("appbar-content-title-text")'
                  '.textMatches("(?i)(?s).*senarai.*")')
    PAGE_TITLE_FALLBACK = (AppiumBy.ANDROID_UIAUTOMATOR,
                         'new UiSelector().descriptionMatches("(?i)\s*SEMAK\s*")')

    # ---- Calendar icon ----
    # Confirmed via live UI dump: this is an icon-font glyph, not the
    # literal word "Kalendar" -- same convention as HAMBURGER in
    # base_page.py and BUTTON_SNAP/BUTTON_TICK_CONFIRM in
    # daftar_kompaun_page.py. The plain XML dump renders this as
    # content-desc="" (the private-use glyph doesn't serialize into the
    # dump), but get_attribute('content-desc') on the live element
    # confirms the real value is "".
    ICON_KALENDAR = (AppiumBy.ACCESSIBILITY_ID, "")

    # ---- Semak button ----
    # Confirmed via live UI dump: this element's actual text is empty
    # ("") -- the visible "SEMAK" label lives in content-desc instead
    # (and is upper-case, not "Semak").
    BUTTON_SEMAK = (AppiumBy.ANDROID_UIAUTOMATOR,
                         'new UiSelector().descriptionMatches("(?i)\s*SEMAK\s*")')

    # ========================================================================
    # Actions
    # ========================================================================

    def is_senarai_screen_displayed(self):
        """Verify we are on the Senarai screen.

        Dua isyarat, kedua-duanya eksklusif kepada skrin Senarai (lihat
        nota PAGE_TITLE). Tajuk app-bar dahulu; butang SEMAK sebagai
        isyarat kedua supaya satu tajuk yang tersalah teka tidak
        menghasilkan "skrin tidak dipaparkan" yang palsu."""
        if self.is_element_present(self.PAGE_TITLE, timeout=10):
            return True
        if self.is_element_present(self.PAGE_TITLE_FALLBACK, timeout=3):
            print("  [SENARAI] tajuk app-bar tidak padan tetapi butang "
                  "SEMAK ada — pada skrin Senarai. Dump tajuk sebenar dan "
                  "ketatkan PAGE_TITLE.")
            return True
        return False

    # ------------------------------------------------------------------
    # Dump pembantu (senarai_page tiada _dump sendiri sebelum ini; cetak/
    # kemaskini ada. Diagnostik C-8/C-13/§6.4 memerlukannya.)
    # ------------------------------------------------------------------

    def _dump_ui(self, name):
        """Tulis page source ke ui_dumps/<name>. Pulang laluan atau nota
        kegagalan; TIDAK PERNAH melempar (ia dipanggil dari laluan
        kegagalan, jadi ia tidak boleh menutupi kegagalan sebenar)."""
        try:
            import os
            os.makedirs("ui_dumps", exist_ok=True)
            path = os.path.join("ui_dumps", name)
            with open(path, "w", encoding="utf-8") as f:
                f.write(self.driver.page_source)
            print(f"  [SENARAI] page source dumped to {path}")
            return path
        except Exception:                                    # noqa: BLE001
            return "(dump failed)"

    def _dump_popup_mismatch(self, no_rekod):
        """Dump popup yang terbuka apabila ia BUKAN `no_rekod` (C-8).
        Nama fail membawa nombor yang DIMINTA supaya dump boleh
        dipadankan dengan baris log."""
        aman = str(no_rekod or "tiada").replace("/", "_")
        return self._dump_ui(f"senarai_popup_bukan_{aman}.xml")

    def open_calendar(self):
        """Tap the calendar icon to open the date picker."""
        print("  [SENARAI] Opening calendar date picker...")
        self.wait_and_click(self.ICON_KALENDAR)

    def select_day(self, day_number, year=None, month=None):
        """Tap a day number inside the open calendar picker.

        Confirmed via live UI dump: matching on the bare day-number text
        (e.g. "30") is ambiguous -- the calendar renders the leading/
        trailing days of adjacent months with the same number (e.g. the
        June view's trailing placeholder cell shows "1" for July 1, and
        its leading cell shows "30" for June 30 sitting right next to
        the real July 30), and a plain text() match can silently
        resolve to the wrong month's day, snapping the whole picker to
        the wrong month.

        Each day Button instead has a unique resource-id in the form
        "undefined.day_YYYY-MM-DD" (e.g. "undefined.day_2026-06-30") --
        match on that instead. Defaults to today's year/month since the
        calendar always opens on the current month.
        """
        import datetime
        today = datetime.date.today()
        y = year or today.year
        m = month or today.month
        date_str = f"{y:04d}-{m:02d}-{int(day_number):02d}"
        print(f"  [SENARAI] Selecting day: {date_str}")
        day_locator = (AppiumBy.ANDROID_UIAUTOMATOR,
                       f'new UiSelector().resourceId("undefined.day_{date_str}")')
        self.wait_and_click(day_locator, timeout=10)

    def click_semak(self):
        """Click the Semak (Check) button to filter records."""
        print("  [SENARAI] Clicking Semak...")
        self.wait_and_click(self.BUTTON_SEMAK)

    def is_records_displayed(self, timeout=10):
        """Check if any record row is displayed after filtering.

        Confirmed via live UI dump: there's no RecyclerView on this
        screen at all -- rows are plain android.view.ViewGroup elements
        inside a HorizontalScrollView, each with a content-desc summary
        like "P, 2026-07-01, 10:35, M, A, msc" (record type, date, time,
        etc., comma-separated). Match on that shape (a content-desc
        containing a YYYY-MM-DD date) rather than a nonexistent class,
        which meant this check always reported "no records" even when
        the table clearly had rows on screen.
        """
        found = self.is_element_present(
            (AppiumBy.ANDROID_UIAUTOMATOR,
             'new UiSelector().className("android.view.ViewGroup")'
             '.descriptionMatches(".*\\d{4}-\\d{2}-\\d{2}.*")'),
            timeout=timeout,
        )
        if found:
            print("  [SENARAI] Records displayed — PASS")
        else:
            print("  [SENARAI] WARNING: No records displayed")
        return found

    # ------------------------------------------------------------------
    # v3 additions: row inspection / record opening (SK-001, Serah, H-*)
    # ------------------------------------------------------------------

    ROW_LOCATOR = (AppiumBy.ANDROID_UIAUTOMATOR,
                   'new UiSelector().className("android.view.ViewGroup")'
                   '.descriptionMatches(".*\\d{4}-\\d{2}-\\d{2}.*")')

    @staticmethod
    def _last_day_of_month():
        """Last day of the CURRENT month (28/29/30/31).

        select_day() builds "undefined.day_YYYY-MM-DD" for the current
        month, so a hardcoded 30 breaks in February (2026-02-30 does not
        exist -> timeout) and silently excludes records created on the
        31st of a 31-day month -- which then makes every
        open_record_by_number() lookup miss."""
        import calendar
        import datetime
        t = datetime.date.today()
        return calendar.monthrange(t.year, t.month)[1]

    def ensure_records_listed(self, start_day=1, end_day=None, force=False):
        """Make sure the record table has rows: if none are showing yet,
        run the calendar date filter (v2-proven interaction). Returns
        True if rows are visible afterwards.

        # SAHKAN-DEVICE: DEV FIXING LIST MBJB baris 38 (DONE) mencatat
        # "Set default value current date pada senarai". Kalau MBJB
        # membuka Senarai dengan penapis = HARI INI, rekod yang baru
        # dicipta akan terpapar tanpa kalendar (jalan pintas di atas
        # mencukupi) TETAPI rekod lama TIDAK, dan open_record_by_number()
        # akan skrol sampai habis tanpa menjumpai apa-apa. Sahkan julat
        # lalai pada device; kalau ia hari ini sahaja, panggil
        # filter_by_day_range() secara eksplisit dalam TC yang menyasarkan
        # rekod lama, jangan bergantung pada jalan pintas ini.

        >>> FIX 2026-09-10 (run 20260910: "Record PGP02N260910003 NOT
        found after 1 scroll(s)" semasa kemaskini, sejurus selepas ia
        dicipta dalam larian YANG SAMA). <<<
        Larian kedua tidak menggunakan --bersih, jadi app TIDAK dimulakan
        semula antara larian -- skrin Senarai boleh membawa BARIS LAMA
        yang tertinggal daripada navigasi terdahulu dalam sesi app yang
        sama (contoh: rekod P/K lama daripada larian pertama). Jalan
        pintas lama ("kalau ADA-ADA baris, anggap cukup, jangan tekan
        Semak") pulang True atas baris LAMA itu SAHAJA -- ia tidak pernah
        menekan Semak untuk memuat SEMULA senarai, jadi rekod yang BARU
        SAHAJA dicipta dalam larian INI tidak pernah masuk paparan yang
        diperiksa. open_record_by_number() kemudian melaporkan "rekod
        tidak dijumpai" walaupun rekod itu wujud sebenarnya di server --
        ia cuma belum dimuat ke paparan semasa. Bukti: dump menunjukkan
        hanya rekod P/K lama kelihatan, bukan N-003 yang baru dicipta.

        Fix: parameter `force` baharu. Apabila True, jalan pintas
        "records already listed" DILANGKAU SEPENUHNYA dan Semak SENTIASA
        ditekan segar sebelum carian ikut nombor. Semua pemanggil dalam
        run_e2e.py yang mencari rekod IKUT NOMBOR (kemaskini, SK-001,
        cari_nombor_baharu) kini menghantar force=True -- ini SIS TEPAT
        kelas panggilan yang perlu menjamin senarai mencerminkan keadaan
        TERKINI, bukan sekadar "ada-ada baris". Jalan pintas lama kekal
        untuk force=False (lalai) supaya pemanggil lain yang cuma mahu
        tahu senarai tidak kosong tidak menanggung kos Semak tambahan."""
        if end_day is None:
            end_day = self._last_day_of_month()
        if not force and self.is_element_present(self.ROW_LOCATOR, timeout=5):
            print("  [SENARAI] Records already listed")
            return True
        if force:
            print("  [SENARAI] force=True -- menekan Semak segar (jangan "
                  "percaya baris sedia ada, mungkin BASI daripada sesi "
                  "app yang sama)...")
        else:
            print("  [SENARAI] No records listed yet -- applying date filter...")
        self.open_calendar()
        self.select_day(start_day)
        self.select_day(end_day)
        self.click_semak()
        # C-15: tunggu overlay sibuk HILANG, bukan sleep tetap. Semak boleh
        # mengambil masa dan tabel belum wujud sementara ia berjalan.
        self.tunggu_selesai_diproses(context="SENARAI")
        # The filter query can end with a native result alert on top.
        self.dismiss_native_alerts(first_timeout=3, context="Senarai filter")
        return self.is_element_present(self.ROW_LOCATOR, timeout=10)

    def _tarikh_dari_nombor(self, no_rekod):
        """Tarikh cipta yang dikodkan dalam nombor rekod, atau None.

        Format (lihat REKOD-SEBENAR-DICIPTA): <kod_pbt><huruf><YYMMDD><3 digit>,
        cth. `PGP02K261008018` -> 2026-10-08. Sembilan aksara terakhir
        sentiasa YYMMDD+turutan, jadi tarikh bermula 3 aksara sebelum itu.
        """
        import datetime
        if not no_rekod or len(no_rekod) < 9:
            return None
        try:
            ymd = no_rekod[-9:-3]
            return datetime.date(2000 + int(ymd[0:2]),
                                 int(ymd[2:4]), int(ymd[4:6]))
        except Exception:                                        # noqa: BLE001
            return None

    def _sempitkan_ke_tarikh(self, tarikh):
        """Tapis Senarai kepada SATU hari sahaja (FIX#15).

        Bila rekod mendarat pada halaman kedua ke atas senarai, tiada
        jumlah skrol boleh menemuinya (lihat FIX#15 di
        open_record_by_number). Menyempitkan Semak kepada hari rekod itu
        memendekkan senarai sehingga rekod kembali ke paparan.

        Tap hari tanpa navigasi bulan: senarai hanya dibuka pada bulan
        semasa dan rekod larian dicipta hari ini, jadi `select_day`
        lalai (tahun/bulan hari ini) adalah betul untuk kes ini. Pulang
        False bila hari itu tidak wujud pada paparan (bulan lain) —
        pemanggil melaporkan tidak dijumpai seperti biasa, bukan
        meneka.
        """
        if tarikh is None:
            return False
        try:
            if tarikh.month != __import__("datetime").date.today().month:
                print(f"  [SENARAI] sempitkan penapis dilangkau — rekod "
                      f"bukan bulan semasa ({tarikh.isoformat()})")
                return False
            self.open_calendar()
            self.select_day(tarikh.day)
            self.select_day(tarikh.day)
            self.click_semak()
            self.tunggu_selesai_diproses(context="SENARAI-sempit")
            self.dismiss_native_alerts(first_timeout=3,
                                       context="Senarai sempit")
            return True
        except Exception as e:                                   # noqa: BLE001
            print(f"  [SENARAI] sempitkan penapis gagal "
                  f"({type(e).__name__}: {e})")
            return False

    def tunggu_selesai_diproses(self, timeout=180, context="SENARAI"):
        """Lihat tunggu_selesai_diproses() peringkat-modul (C-15).

        >>> TANDA TANGAN DISELARASKAN 2026-07-31 (dedah
        devtools\\semak_tandatangan.py, diarah Loh). <<< Parameter kedua
        dinamakan semula daripada `tag` kepada `context` supaya override
        INI PATUH kontrak awam `BasePage.tunggu_selesai_diproses(timeout,
        context)` (recon\\KONTRAK_POM.md, satu-satunya tandatangan sah
        yang didokumenkan). Nama lama `tag` tidak melempar pada panggilan
        `self.tunggu_selesai_diproses(tag=...)` DALAM fail ini (Python
        menyelesaikan `self.` kepada override ini dengan betul mengikut
        MRO), tetapi ia memecahkan sebarang panggilan LUAR yang mengikut
        kontrak awam terdokumen (`context=`) dengan `TypeError` pada
        laluan kritikal Senarai (pintu masuk setiap TC by-number) --
        risiko senyap yang tepat kelas yang alat semak-tandatangan Loh
        wujud untuk menangkap. Parameter `tag` pada fungsi
        PERINGKAT-MODUL di bawah (`tunggu_selesai_diproses(page, timeout,
        tag)`, baris 59) KEKAL -- ia BUKAN kaedah BasePage, ia fungsi
        bebas yang tidak mewarisi kontrak itu, jadi namanya sendiri tidak
        tertakluk kontrak ini."""
        return tunggu_selesai_diproses(self, timeout=timeout, tag=context)

    def get_row_descriptions(self):
        """Return the content-desc of every visible record row.

        Row shape confirmed live in v2 (see is_records_displayed):
        plain ViewGroups whose content-desc is a comma-separated summary
        like "P, 2026-07-01, 10:35, M, A, msc" -- first token is the
        record-type letter (P/N/K/L/S, matching the No Kompaun/Notis
        prefixes in the SENARAI KOMPAUN sheet), and the M/H token is the
        STATUS HANTAR column."""
        descs = []
        try:
            for el in self.driver.find_elements(*self.ROW_LOCATOR):
                d = el.get_attribute("content-desc")
                if d:
                    descs.append(d)
        except Exception as e:
            print(f"  [SENARAI] WARNING: could not read row descriptions "
                  f"({e})")
        return descs

    def get_no_akaun_list(self):
        """Read the NO AKAUN column top-to-bottom. Confirmed via live
        recon dump (ui_dumps/recon_senarai_table.xml): each cell is a
        clickable ViewGroup whose content-desc is the record number
        (MBIP "IPA3K260716031"; MBJB "JB015K260227002"), in row order.

        # SAHKAN-DEVICE: bahawa nombor rekod MBJB benar-benar muncul dalam
        # content-desc sel NO AKAUN (bukan hanya dalam text). Kalau tidak,
        # open_record_by_number() -- yang memadan descriptionContains --
        # tidak akan menjumpai apa-apa dan setiap TC hiliran akan skip."""
        loc = (AppiumBy.ANDROID_UIAUTOMATOR,
               f'new UiSelector().descriptionMatches("{_record_prefix()}\\w+")')
        numbers = []
        try:
            for el in self.driver.find_elements(*loc):
                d = el.get_attribute("content-desc")
                if d:
                    numbers.append(d)
        except Exception as e:
            print(f"  [SENARAI] WARNING: could not read NO AKAUN cells "
                  f"({e})")
        return numbers

    def rows_for_jenis(self, jenis_letter):
        """Rows whose summary starts with the given record-type letter.

        DIHARAMKAN sebagai asas assert dalam TC -002/-003/-004/-006/-007/
        H-* (C-3, PERATURAN KERAS #7). Ini pemilihan IKUT JENIS: staging
        penuh rekod LAMA jenis yang sama, jadi "mana-mana baris jenis N
        menunjukkan H" LULUS walaupun sync run ini gagal sepenuhnya.
        Untuk mengesahkan satu rekod tertentu, guna tokens_for_number() /
        find_number_and_tokens(), atau hantar_page.verify_sent_by_number().
        Kegunaan sah yang tinggal: recon dan SK-001 (kiraan/bentuk baris).
        """
        prefix = f"{jenis_letter.upper()},"
        return [d for d in self.get_row_descriptions()
                if d.upper().startswith(prefix)]

    def open_record_by_jenis(self, jenis_letter, dump_name=None):
        """HANYA untuk recon dan SK-001. Pemilihan ini IKUT KEDUDUKAN dan
        DIHARAMKAN dalam TC -002/-003/-004/-006/-007/H-* (PERATURAN KERAS
        #7): ia mencetak/mengemaskini rekod BASI dan menjadikan TC lulus
        walaupun create GAGAL. Untuk memilih rekod, guna
        open_record_by_number().

        Tap a record row of the given jenis and dump the page source of
        whatever opens. Returns the tapped row's desc. Raises
        TimeoutException if no row of that jenis is on screen.

        C-12: parameter `which` DIBUANG. Docstring lama mengesyorkan
        nilai "last" sebagai cara "yang diperlukan oleh aliran
        Kemaskini" — itu tidak lagi benar (verify_updated() kini
        by-number sepenuhnya) dan ia ialah mekanisme bug MBIP yang masih
        hidup. Membuang parameter bermakna "last" tidak boleh dipohon
        semula oleh kod baharu."""
        loc = (AppiumBy.ANDROID_UIAUTOMATOR,
               'new UiSelector().className("android.view.ViewGroup")'
               f'.descriptionMatches("^{jenis_letter.upper()},.*'
               '\\d{4}-\\d{2}-\\d{2}.*")')
        el = self.find_element(loc, timeout=10)
        desc = el.get_attribute("content-desc")
        print(f"  [SENARAI] Opening record row: {desc}")
        self.tap_element(el)
        import time
        time.sleep(2)
        if dump_name:
            try:
                import os
                os.makedirs("ui_dumps", exist_ok=True)
                path = os.path.join("ui_dumps", dump_name)
                with open(path, "w", encoding="utf-8") as f:
                    f.write(self.driver.page_source)
                print(f"  [SENARAI] Record view page source dumped to {path}")
            except Exception:
                pass
        return desc

    RECORD_POPUP_TITLE = (AppiumBy.ANDROID_UIAUTOMATOR,
                          'new UiSelector().textMatches("(?i)\s*KEMASKINI\s+DATA\s*")')

    POPUP_X = (AppiumBy.ACCESSIBILITY_ID, "✕")

    # ------------------------------------------------------------------
    # Skrol tabel Senarai. Koordinat DIDERIVASI (C-7), pergerakan diukur
    # dari KANDUNGAN baris (C-6), dan carian sentiasa bermula dari ATAS
    # (C-5).
    # ------------------------------------------------------------------

    def _swipe_table(self, from_frac, to_frac, ms=600):
        """Satu sapuan menegak pada tabel; koordinat diderivasi daripada
        `driver.get_window_size()`.

        C-7 / PERATURAN KERAS #3: versi lama menghardkod
        `swipe(540 / 1650 -> 650, 600ms)`. `540` mengandaikan lebar
        1080px dan `1650`/`650` mengandaikan satu ketinggian tertentu.
        Peranti sebenar ialah Ulefone Armor 27 (PAPAN.md 1.1) dan
        resolusinya BELUM disahkan; pada peranti lain sapuan itu mendarat
        di luar tabel, tidak menggerakkan apa-apa, dibaca sebagai "hujung
        senarai" (C-6) dan akhirnya dilaporkan sebagai "rekod tidak
        dijumpai"."""
        try:
            w = self.driver.get_window_size()
            x = w["width"] // 2
            self.driver.swipe(x, int(w["height"] * from_frac),
                              x, int(w["height"] * to_frac), ms)
            return True
        except Exception:                                    # noqa: BLE001
            return False

    def _scroll_senarai_down(self):
        """Swipe the record table up to reveal lower rows. Returns True if
        the list actually moved, False once it stops moving.

        C-6: pergerakan diukur dengan membandingkan KANDUNGAN baris, bukan
        `len(self.driver.page_source)`. Panjang rentetan BUKAN kandungan —
        satu skrol yang benar-benar berlaku tetapi menggantikan satu baris
        dengan baris lain yang panjang deskripsinya sama menghasilkan
        panjang page_source yang IDENTIK, dibaca sebagai "hujung senarai",
        lalu dilaporkan sebagai "rekod tidak dijumpai" yang PALSU."""
        import time
        before = tuple(self.get_row_descriptions())
        if not self._swipe_table(0.80, 0.32):
            return False
        time.sleep(0.6)
        return tuple(self.get_row_descriptions()) != before

    def _scroll_senarai_top(self, max_scrolls=25):
        """Bawa tabel Senarai balik ke ATAS.

        C-5: open_record_by_number() hanya boleh skrol KE BAWAH, jadi
        carian MESTI bermula dari atas. Tanpa ini, panggilan KEDUA dalam
        sesi Senarai yang sama bermula dari kedudukan yang ditinggalkan
        panggilan pertama, dan rekod yang berada DI ATAS viewport semasa
        tidak akan pernah dijumpai — rekod yang WUJUD dilaporkan tidak
        dijumpai. Berlaku nyata pada TC -004, yang mencari nombor yang
        SAMA dua kali (sekali sebelum kemaskini, sekali dalam
        verify_updated())."""
        import time
        for _ in range(max_scrolls):
            before = tuple(self.get_row_descriptions())
            if not self._swipe_table(0.35, 0.85):
                return
            time.sleep(0.5)
            if tuple(self.get_row_descriptions()) == before:
                return

    def _close_record_popup(self):
        """Tutup popup rekod melalui X-nya. Dipanggil hanya dari laluan
        kegagalan (C-8), jadi ia TIDAK PERNAH melempar — satu kegagalan
        menutup popup tidak boleh menutupi kegagalan sebenar."""
        try:
            el = self.find_element(self.POPUP_X, timeout=3)
            self.tap_element(el)
        except Exception:                                    # noqa: BLE001
            pass

    def _confirm_popup_is(self, no_rekod, via):
        """Gerbang DALAMAN C-8: popup yang TERBUKA mesti memaparkan
        `no_rekod` sebelum open_record_by_number() dibenarkan pulang True.

        Sebelum ini kedua-dua laluan `return True` memulangkan True
        semata-mata kerana SATU popup terbuka — tanpa memeriksa popup itu
        milik `no_rekod`. Baris disentuh melalui pertindihan-y, jadi
        sempadan baris yang bertindih atau sel nombor yang menjulur ke
        baris jiran boleh membuka popup rekod LAIN dan ia dilaporkan
        sebagai kejayaan. Ia terlindung secara KEBETULAN di tempat
        pemanggil turut memanggil record_popup_shows_number() — dan
        perlindungan yang bergantung pada disiplin pemanggil hilang pada
        TC berikutnya yang ditulis. Selepas ini, `True` bermakna "rekod
        yang BETUL terbuka" dan invariant itu tidak boleh dilanggar oleh
        pemanggil baharu."""
        if not self.record_popup_shows_number(no_rekod):
            self._dump_popup_mismatch(no_rekod)
            print(f"  [SENARAI] popup terbuka TETAPI bukan {no_rekod} "
                  f"(dibuka melalui {via}) — menutup dan melaporkan GAGAL "
                  f"(tidak pernah bertindak pada rekod salah)")
            self._close_record_popup()
            return False
        print(f"  [SENARAI] Opened record {no_rekod} by number (via {via})")
        return True

    def open_record_by_number(self, no_rekod, max_scrolls=20):
        """Open the record whose NO KOMPAUN/NOTIS is `no_rekod` (e.g.
        JB015N260227001) -- select by NUMBER, not by position. Scrolls the
        Senarai to find it (the staging list is long now).

        Pulang True HANYA apabila popup rekod terbuka DAN popup itu
        memaparkan `no_rekod` (C-8). Pulang False dalam SEMUA keadaan
        lain. TIDAK PERNAH melempar kerana 'tidak dijumpai' — tidak
        dijumpai ialah False, dan pemanggil yang menjadikannya FAIL.
        TIDAK PERNAH membuka baris lain; tiada parameter `which`.

        NEVER falls back to another row -- opening the wrong record is worse
        than an honest miss. This replaces the 'first'/'last'
        positional pick, which silently printed/updated STALE records and
        made Cetak/Serah/Kemaskini pass even when the create failed.

        # SAHKAN-DEVICE: seluruh rantaian ini bergantung pada nombor rekod
        # yang muncul dalam content-desc sel NO AKAUN dengan awalan
        # config.RECORD_PREFIX. TIADA satu pun rekod pernah dicipta pada
        # device ini (reports\\fasa2-bootstrap.md RINGKASAN), jadi `JB015`
        # masih TEKAAN dan rantaian by-number BELUM diuji sama sekali.
        # Kalau carian gagal, baca blok [AWALAN] yang dicetak di bawah
        # SEBELUM menuduh create."""
        import time
        if not no_rekod:
            return False

        # C-15 — Alert asli BERATUR dan Back TIDAK menutupnya (disahkan Loh
        # 2026-07-30: satu alert lesen muncul SEMULA selepas yang pertama
        # ditolak; tap pada skrin di belakang alert hilang sepenuhnya).
        # Satu alert yang tinggal di atas Senarai menelan setiap tap dan
        # menyembunyikan tabel — carian akan menyapu sampai habis dan
        # melaporkan "rekod tidak dijumpai", menuduh create atau awalan
        # sedangkan puncanya modal yang tidak ditolak.
        # dismiss_native_alerts() memang menguras beratur, jadi satu
        # panggilan mencukupi — jangan tambah gelung tersendiri.
        self.dismiss_native_alerts(first_timeout=1,
                                   context="Senarai cari-ikut-nombor")

        # C-5 — gelung di bawah hanya skrol KE BAWAH, jadi ia mesti
        # bermula dari atas atau rekod di atas viewport semasa tidak akan
        # pernah dijumpai.
        self._scroll_senarai_top()

        cell = (AppiumBy.ANDROID_UIAUTOMATOR,
                f'new UiSelector().descriptionContains("{no_rekod}")')
        i = 0
        for i in range(max_scrolls):
            if self.is_element_present(cell, timeout=1):
                el = self.find_element(cell, timeout=3)
                self.tap_element(el)
                time.sleep(2)
                if self.is_element_present(self.RECORD_POPUP_TITLE, timeout=3):
                    return self._confirm_popup_is(no_rekod, "sel NO AKAUN")
                # The number cell may not itself open the popup on every
                # build -- tap the full-width summary row in the same
                # y-band. Baris itu dipilih melalui pertindihan-y, jadi
                # ia MESTI melalui gerbang C-8 di bawah: pertindihan
                # bukan bukti identiti.
                try:
                    r = el.rect
                    cy = r["y"] + r["height"] // 2
                    for row in self.driver.find_elements(*self.ROW_LOCATOR):
                        rr = row.rect
                        if rr["y"] <= cy <= rr["y"] + rr["height"]:
                            self.tap_element(row)
                            time.sleep(2)
                            if self.is_element_present(
                                    self.RECORD_POPUP_TITLE, timeout=3):
                                return self._confirm_popup_is(
                                    no_rekod, "baris ringkasan")
                            break
                except Exception:                            # noqa: BLE001
                    pass
                print(f"  [SENARAI] Found {no_rekod} but the record view did "
                      f"not open")
                return False
            if not self._scroll_senarai_down():
                break  # list stopped moving -- reached the end
        print(f"  [SENARAI] Record {no_rekod} NOT found after {i + 1} "
              f"scroll(s) -- refusing to open any other row")

        # >>> FIX#15 — DITAMBAH 2026-10-08 (run11: K-003/K-004/SK-001). <<<
        # Senarai memapar 10 baris SAHAJA dan tabelnya
        # android.widget.HorizontalScrollView -- sapuan MENEGAK tidak
        # menggerakkannya (dump ui_dumps/senarai_nombor_tidak_dijumpai.xml:
        # satu sapuan -> "list stopped moving"), jadi rekod ke-11 dan
        # seterusnya TIDAK BOLEH dicapai dengan skrol langsung. Dalam
        # larian yang mencipta 5 rekod dalam bulan yang sama, rekod baru
        # (018/019) jatuh di luar halaman pertama dan dilaporkan "tidak
        # dijumpai" walaupun ia wujud di server. Berulang 18/8, 19/8,
        # 1/10, 8/10 -- ini kelas bug yang sama setiap kali.
        #
        # Pembetulan: sempitkan penapis Semak kepada HARI rekod itu
        # sendiri (diextrak daripada YYMMDD dalam nombornya) supaya
        # senarai menjadi pendek dan rekod itu berada pada halaman
        # pertama. Tiada navigasi bulan diperlukan kerana rekod larian
        # ini dicipta HARI INI.
        tarikh = self._tarikh_dari_nombor(no_rekod)
        if tarikh is not None and self._sempitkan_ke_tarikh(tarikh):
            print(f"  [SENARAI] cuba semula selepas sempitkan ke "
                  f"{tarikh.isoformat()} ...")
            self._scroll_senarai_top()
            for _ in range(4):
                if self.is_element_present(cell, timeout=1):
                    el = self.find_element(cell, timeout=3)
                    self.tap_element(el)
                    time.sleep(2)
                    if self.is_element_present(self.RECORD_POPUP_TITLE,
                                               timeout=3):
                        return self._confirm_popup_is(
                            no_rekod, "sel NO AKAUN (penapis sempit)")
                if not self._scroll_senarai_down():
                    break
            print(f"  [SENARAI] masih tidak dijumpai selepas sempitkan "
                  f"penapis ke {tarikh.isoformat()}")

        # §6.4 — jangan berhenti pada baris di atas: ia TIDAK memberitahu
        # sama ada masalahnya awalan profil atau atribut locator.
        self._diagnose_popup_number(no_rekod, konteks="senarai")
        return False

    def record_popup_shows_number(self, no_rekod):
        """True kalau popup rekod YANG TERBUKA memaparkan `no_rekod` (baris
        'NO KOMPAUN/NOTIS: JB015...') — mengesahkan kita membuka rekod yang
        BETUL sebelum bertindak padanya (Cetak/Serah/Kemaskini).

        C-13: memadan `text`, `content-desc`, DAN `page_source`. Versi lama
        memadan `text` SAHAJA, sedangkan nombor yang sama dibaca dari
        `content-desc` di tempat lain dalam fail ini (get_no_akaun_list,
        open_record_by_number).

        >>> PEMBAIKAN 2026-07-31 (isu dibuka PowerRangersMerah, diarah
        Loh) — SKROL-DAN-CARI, BUKAN PADANAN DILONGGARKAN. <<<
        Versi sebelum ini memeriksa ketiga-tiga locator dengan
        is_element_present() BERTELANJANG — TANPA cuba skrol popup dahulu
        — walaupun perenggan di atas SUDAH mengaku "nombor berada di
        bawah lipatan popup" sebagai salah satu sebab False. Puncanya
        sama seperti seluruh suite: `uiautomator dump`
        (dan `driver.page_source`, laluan yang sama) MEMBUANG nod
        `visible:false` SEPENUHNYA — elemen di bawah paparan bukan
        sekadar "sukar dijumpai", ia LANGSUNG TIADA dalam pokok yang
        ketiga-tiga locator di atas (termasuk cubaan page_source) baca
        (recon\\PAPAN.md blok "MULA DI SINI"). Jadi cubaan page_source
        yang sedia ada TIDAK PERNAH menjadi ganti sah kepada skrol.

        Pembaikan ini:
          * TIDAK melonggarkan padanan nombor itu sendiri — ketiga-tiga
            cubaan (`_cuba_sekali`) kekal padanan TEPAT pada `no_rekod`
            yang sama seperti sebelum ini;
          * skrol POPUP (bukan tabel/senarai di belakangnya) melalui
            `find_with_scroll()` (base_page.py:531 — "cari elemen, skrol
            kalau perlu", memulangkan elemen/None; logik skrolnya TIDAK
            disalin ke sini) dan mencuba locator yang SAMA semula selepas
            ia bergerak;
          * TIDAK menambah fallback ikut kedudukan di mana-mana — skrol
            di sini mendedahkan LEBIH BANYAK popup yang SUDAH terbuka
            supaya nombor yang sedia ada boleh dibaca; ia tidak pernah
            membuka popup atau baris lain. Tidak jumpa selepas skrol =
            False, sama seperti dahulu.

        >>> TANDA TANGAN DIBETULKAN 2026-07-31 (Loh: API makmingg ialah
        otoriti). <<< Versi pertama fail ini memanggil
        `self.scroll_in_viewport(loc, timeout=6)` di sebalik `hasattr()`
        — TIDAK PADAN dengan tandatangan SEBENAR
        `scroll_in_viewport(direction="down", percent=0.3, context="")`.
        `hasattr()` tidak melindungi (kaedah itu MEMANG wujud); `loc`
        akan masuk sebagai `direction` — meletup atau skrol arah karut
        secara senyap, menyamar sebagai kegagalan locator (punca sebenar
        tiga run K1). Ditukar kepada `find_with_scroll()`. `hasattr()`
        DIBUANG.

        # SAHKAN-DEVICE: atribut MANA (text / content-desc) yang membawa
        # nombor rekod pada popup MBJB. Dump
        # ui_dumps\\senarai_record_popup.xml dan rekod jawapannya di sini
        # (kontrak §8.2 butiran 8)."""
        if not no_rekod:
            return False

        locs = (
            (AppiumBy.ANDROID_UIAUTOMATOR,
             f'new UiSelector().textContains("{no_rekod}")'),
            (AppiumBy.ANDROID_UIAUTOMATOR,
             f'new UiSelector().descriptionContains("{no_rekod}")'),
        )

        def _cuba_sekali():
            for loc in locs:
                if self.is_element_present(loc, timeout=2):
                    return True
            try:
                if no_rekod in (self.driver.page_source or ""):
                    print(f"  [SENARAI] {no_rekod} dijumpai dalam "
                          f"page_source tetapi TIDAK oleh locator "
                          f"text/content-desc — periksa atribut sebenar "
                          f"sebelum mempercayai locator lain")
                    return True
            except Exception:                                # noqa: BLE001
                pass
            return False

        if _cuba_sekali():
            return True

        for loc in locs:
            if self.find_with_scroll(loc, timeout_each=6) is not None:
                print(f"  [SENARAI] {no_rekod} dijumpai selepas skrol "
                      f"popup — padanan TEPAT, tiada baris/popup lain "
                      f"disentuh")
                return True

        self._diagnose_popup_number(no_rekod, konteks="popup")
        return False

    def _diagnose_popup_number(self, no_rekod, konteks="senarai"):
        """Cetak diagnosis apabila satu nombor rekod tidak dapat dijumpai.

        §6.4 kontrak. Ia MEMBEZAKAN dua punca yang gejalanya SAMA: awalan
        profil yang SALAH, berbanding nombor yang ADA pada skrin tetapi
        dalam atribut yang locator kita tidak baca. Tanpa pembezaan ini,
        kos mengetahui puncanya ialah satu run penuh yang menghasilkan 28
        skip (C-1 / §2.2). Ia TIDAK membetulkan apa-apa sendiri dan TIDAK
        menerima awalan lain — menerima awalan yang tidak diisytihar
        bermakna suite menerima rekod yang mungkin bukan miliknya.

        `konteks="popup"` dipanggil dari record_popup_shows_number(), di
        mana tabel Senarai TERLINDUNG di belakang popup. Kesimpulan
        "tiada baris" tidak sah di situ, jadi kesimpulan tiga-cabang
        hanya dicetak untuk konteks "senarai"."""
        import re
        prefix = _record_prefix()
        try:
            src = self.driver.page_source or ""
        except Exception:                                    # noqa: BLE001
            src = ""
        token = sorted(set(re.findall(r'\b[A-Z]{2}[A-Z0-9]{2,6}\d{6,}\b', src)))
        print(f"  [AWALAN] {konteks.upper()}: rekod {no_rekod!r} TIDAK "
              f"dijumpai.")
        print(f"  [AWALAN]   awalan dicari (config.RECORD_PREFIX) : "
              f"{prefix!r}")
        akaun = baris = []
        if konteks == "senarai":
            akaun = self.get_no_akaun_list()
            baris = self.get_row_descriptions()
            print(f"  [AWALAN]   sel NO AKAUN padan awalan itu        : "
                  f"{len(akaun)}")
            print(f"  [AWALAN]   baris Senarai kelihatan              : "
                  f"{len(baris)}")
        print(f"  [AWALAN]   token berbentuk-nombor-rekod pada skrin:")
        for t in token[:10]:
            tanda = "" if t.startswith(prefix) else \
                f"  <- BUKAN {prefix!r}; awalan sebenar mungkin {t[:5]!r}"
            print(f"  [AWALAN]     {t}{tanda}")
        if not token:
            print("  [AWALAN]     (tiada)")
        if konteks != "senarai":
            print(f"  [AWALAN] => Popup rekod TERBUKA tetapi {no_rekod!r} "
                  f"tidak dibaca oleh locator text/content-desc/"
                  f"page_source. Dump popup dan rekod atribut SEBENAR yang "
                  f"membawa nombor (C-13). Ini BUKAN bukti awalan salah — "
                  f"tabel Senarai terlindung di belakang popup.")
            self._dump_ui("senarai_popup_nombor_tidak_dibaca.xml")
            return
        if baris and not akaun and token:
            print("  [AWALAN] => Baris ADA dan nombor ADA pada skrin, tetapi "
                  "0 sel padan awalan: nombor mungkin dalam atribut `text`, "
                  "bukan `content-desc`. Itu BUG LOCATOR "
                  "(get_no_akaun_list / open_record_by_number), BUKAN "
                  "awalan salah.")
        elif token and not any(t.startswith(prefix) for t in token):
            print(f"  [AWALAN] => Nombor pada skrin tidak bermula dengan "
                  f"{prefix!r}: betulkan \"record_prefix\" dalam "
                  f"profiles/mbpg-staging.json dan jalan semula. JANGAN "
                  f"pinda kod untuk menerima berbilang awalan.")
        elif not baris:
            print("  [AWALAN] => Tiada baris sama sekali: ini masalah "
                  "PENAPIS TARIKH Senarai, bukan awalan (lihat nota "
                  "SAHKAN-DEVICE pada ensure_records_listed).")
        self._dump_ui("senarai_nombor_tidak_dijumpai.xml")

    # ------------------------------------------------------------------
    # MBJB-only: TC *-006 "Concat alamat on lokasi kesalahan"
    #            (N-006, P-006, K-006, L-006, S-006)
    #
    # Excel's Test Steps for these TC are NOT app steps -- MBPG-TC-N-006
    # C10 step 3 reads "Retrieve kompaun from database and verify
    # concatenated alamat jalan at table lokasi kesalahan". Appium on the
    # handheld CANNOT read the ePBT database. What follows is therefore a
    # UI PROXY, not the Excel verification: it reads back whatever the
    # app itself displays for LOKASI KESALAHAN on the open record popup,
    # so the terminal session has real evidence to hand the owner. The
    # test that calls it must state plainly which of the two it did
    # (proxy vs skip) -- an honest SKIP beats a PASS that never touched
    # the thing Excel asked for (Peraturan #6).
    # ------------------------------------------------------------------

    LABEL_VALUE_ROW = (AppiumBy.ANDROID_UIAUTOMATOR,
                       'new UiSelector().className("android.widget.TextView")')

    def read_record_popup_fields(self, dump_name="senarai_record_popup.xml"):
        """Read every TextView on the OPEN record popup as a flat list.

        Returns list[str]. Dumps the page source too -- for the *-006 TC
        the dump IS the deliverable, because the assertion Excel really
        wants happens in the database, not here.

        # SAHKAN-DEVICE: susunan label/nilai pada popup rekod MBJB belum
        # disahkan. MBIP popup memaparkan label berakhir ' :' diikuti
        # nilai (lihat _scroll_popup_to dalam notis_kompaun_page). Kalau
        # MBJB menggunakan bentuk lain, pemadanan label di bawah perlu
        # dilaraskan daripada dump ini."""
        texts = []
        try:
            for el in self.driver.find_elements(*self.LABEL_VALUE_ROW):
                t = (el.text or "").strip()
                if t:
                    texts.append(t)
        except Exception as e:                               # noqa: BLE001
            print(f"  [SENARAI] WARNING: could not read popup fields ({e})")
        if dump_name:
            try:
                import os
                os.makedirs("ui_dumps", exist_ok=True)
                path = os.path.join("ui_dumps", dump_name)
                with open(path, "w", encoding="utf-8") as f:
                    f.write(self.driver.page_source)
                print(f"  [SENARAI] Record popup dumped to {path}")
            except Exception:                                # noqa: BLE001
                pass
        return texts

    # Probe locator for the LOKASI KESALAHAN label -- used only to drive
    # scroll_in_viewport() below toward the right area of the popup; the
    # actual value extraction still runs on read_record_popup_fields()'s
    # flat text list (_cari_lokasi_kesalahan), unchanged.
    LABEL_LOKASI_KESALAHAN_PROBE = (
        AppiumBy.ANDROID_UIAUTOMATOR,
        'new UiSelector().className("android.widget.TextView")'
        '.textMatches("(?i)(?s).*lokasi.*kesalahan.*")')

    @staticmethod
    def _cari_lokasi_kesalahan(texts):
        """Padanan TEPAT yang sedia ada, diasingkan supaya boleh dipanggil
        dua kali (sebelum dan selepas skrol) tanpa menyalin logik."""
        for i, t in enumerate(texts):
            if "LOKASI" in t.upper() and "KESALAHAN" in t.upper():
                # value is either on the same row after ':' or the next row
                if ":" in t:
                    tail = t.split(":", 1)[1].strip()
                    if tail:
                        return tail
                if i + 1 < len(texts):
                    return texts[i + 1].strip()
        return None

    def get_lokasi_kesalahan_from_popup(self):
        """The LOKASI KESALAHAN value shown on the OPEN record popup, or
        None if the app does not display it there.

        Returns None honestly rather than guessing -- None means "the app
        does not show this on the popup", which is itself the finding the
        *-006 TC should report.

        >>> PEMBAIKAN 2026-07-31 (saril, isu dibuka & diarah Loh) --
        SKROL-DAN-CARI, BUKAN BUKTI DILONGGARKAN. <<<
        Versi sebelum ini membaca read_record_popup_fields() SEKALI TANPA
        skrol popup dahulu. Kesannya BUKAN false PASS (kontrak by-number
        *-006/-007 sudah betul di tempat lain) tetapi FALSE SKIP: kalau
        baris LOKASI KESALAHAN wujud tetapi di bawah lipatan popup semasa
        bacaan pertama, kaedah ini pulang None -- SAMA seperti "app tidak
        memaparkan medan ini" -- dan TC hiliran skip dengan sebab "app
        tidak paparkan", walhal ia cuma belum diskrol. Itu lebih senyap
        daripada kegagalan dan lebih sukar dikesan: laporan akhir
        mendakwa jurang data yang tidak wujud.

        Pembaikan ini TIDAK melonggarkan apa yang dikira bukti --
        `_cari_lokasi_kesalahan()` (padanan ":" split / baris seterusnya)
        kekal SAMA PERSIS, dipanggil dua kali sahaja: sekali atas bacaan
        semasa, sekali lagi selepas find_with_scroll() (base_page.py:531
        -- "cari elemen, skrol kalau perlu"; logiknya TIDAK disalin ke
        sini) cuba mendedahkan baris LOKASI KESALAHAN. Tidak jumpa
        selepas skrol penuh masih pulang None -- kaedah ini tidak pernah
        menerima padanan yang lebih longgar sebagai ganti.

        >>> TANDA TANGAN DIBETULKAN 2026-07-31 (Loh: API makmingg ialah
        otoriti). <<< Versi pertama memanggil
        `self.scroll_in_viewport(locator, timeout=6)` di sebalik
        `hasattr()` -- TIDAK PADAN dengan tandatangan SEBENAR
        `scroll_in_viewport(direction="down", percent=0.3, context="")`.
        Ditukar kepada find_with_scroll(). `hasattr()` DIBUANG.

        # SAHKAN-DEVICE: adakah popup rekod MBJB memaparkan LOKASI
        # KESALAHAN langsung? Kalau tidak, TC *-006 tidak boleh diproksi
        # pada device sama sekali dan mesti pytest.skip dengan sebab."""
        texts = self.read_record_popup_fields(dump_name=None)
        hasil = self._cari_lokasi_kesalahan(texts)
        if hasil is not None:
            return hasil
        self.find_with_scroll(self.LABEL_LOKASI_KESALAHAN_PROBE,
                              timeout_each=6)
        texts = self.read_record_popup_fields(dump_name=None)
        return self._cari_lokasi_kesalahan(texts)

    def alamat_is_concatenated(self, lokasi_value, parts):
        """True when EVERY non-empty part of the address appears inside
        `lokasi_value` -- i.e. the app concatenated jalan/taman/poskod/
        bandar/negeri into one lokasi kesalahan string rather than
        dropping components.

        `parts` is an iterable of the individual address values that were
        entered on the form. Missing pieces are RETURNED, not swallowed,
        so the caller can name them in the failure message. Returns
        (ok: bool, missing: list[str])."""
        if not lokasi_value:
            return False, [str(p) for p in parts if str(p).strip()]
        hay = " ".join(str(lokasi_value).upper().split())
        missing = []
        for p in parts:
            p = str(p or "").strip()
            if not p:
                continue
            if " ".join(p.upper().split()) not in hay:
                missing.append(p)
        return (not missing), missing

    # ------------------------------------------------------------------
    # MBJB-only: TC *-007 "Notis peringatan pertama" (P-007, K-007, L-007)
    #
    # Excel MBPG-TC-P-007 C10 step 2 = "Verify status notis in database",
    # expected status 'B'. Same DB-access problem as *-006. The row
    # summary's content-desc is the only status-shaped thing the handheld
    # exposes (MBIP shape: "P, 2026-07-01, 10:35, M, A, msc" where the
    # M/H token is STATUS HANTAR -- NOT the notis status 'B').
    # ------------------------------------------------------------------

    def get_row_status_tokens(self):
        """{desc: [tokens]} bagi SETIAP baris yang kelihatan.

        C-2: parameter `no_rekod` DIBUANG. Versi lama menerima `no_rekod`
        dan mencarinya DALAM content-desc BARIS (padanan substring) —
        padanan itu TIDAK MUNGKIN berlaku. ROW_LOCATOR memadan ViewGroup
        yang content-desc-nya mengandungi TARIKH ("P, 2026-07-01, 10:35,
        M, A, msc"); nombor rekod TIDAK ADA di dalamnya. Nombor hidup
        dalam elemen BERASINGAN (sel NO AKAUN) yang dibaca oleh
        get_no_akaun_list() melalui locator yang SALING EKSKLUSIF
        (descriptionMatches("{prefix}\\w+") — tiada tarikh). Akibatnya
        row_status_for_number() sentiasa memulangkan None, dan TC -007
        memaparkan None itu sebagai "app tidak memaparkan status" — satu
        penemuan PALSU tentang app yang puncanya kod kita.

        Mod "semua baris" ini kekal berguna dan tidak berubah. Untuk satu
        rekod tertentu, guna tokens_for_number()."""
        return {d: [t.strip() for t in d.split(",")]
                for d in self.get_row_descriptions()}

    def tokens_for_number(self, no_rekod):
        """Token ringkasan baris BAGI `no_rekod`. None kalau nombor itu
        tidak kelihatan. TIDAK PERNAH token baris lain.

        C-2: nombor rekod dan ringkasan baris ialah DUA elemen berbeza
        (sel NO AKAUN vs baris ViewGroup) — ia disambung melalui
        PERTINDIHAN MENEGAK, bukan dengan mencari nombor di dalam desc
        baris (yang tidak pernah mengandunginya). Teknik pertindihan ini
        sudah terbukti di tempat lain: open_record_by_number() dan
        pages\\printer_connect_page._tap_connect_for.

        # SAHKAN-DEVICE: bahawa sel NO AKAUN dan baris ringkasan MBJB
        # memang bertindih secara menegak (satu baris tabel yang sama).
        # Tabel Senarai MBJB belum pernah di-dump."""
        if not no_rekod:
            return None
        cell = (AppiumBy.ANDROID_UIAUTOMATOR,
                f'new UiSelector().descriptionContains("{no_rekod}")')
        try:
            cells = self.driver.find_elements(*cell)
        except Exception:                                    # noqa: BLE001
            cells = []
        if not cells:
            print(f"  [SENARAI] sel NO AKAUN untuk {no_rekod} tidak "
                  f"kelihatan pada viewport semasa")
            return None
        try:
            cr = cells[0].rect
            cy = cr["y"] + cr["height"] // 2
            for row in self.driver.find_elements(*self.ROW_LOCATOR):
                rr = row.rect
                if rr["y"] <= cy <= rr["y"] + rr["height"]:
                    d = row.get_attribute("content-desc") or ""
                    return [t.strip() for t in d.split(",")]
        except Exception as e:                               # noqa: BLE001
            print(f"  [SENARAI] WARNING: tokens_for_number({no_rekod}) "
                  f"gagal mengukur pertindihan ({type(e).__name__})")
            return None
        print(f"  [SENARAI] sel {no_rekod} dijumpai tetapi tiada baris "
              f"ringkasan bertindih dengannya — bentuk tabel berubah")
        return None

    def find_number_and_tokens(self, no_rekod, max_scrolls=20):
        """tokens_for_number() tetapi menyapu senarai dari ATAS untuk
        mencari `no_rekod` dahulu. None kalau nombor tiada dalam senarai
        sama sekali.

        Diperlukan oleh C-3 (H-001..H-005) dan -007: rekod yang hendak
        disemak mungkin tidak berada pada viewport pertama, dan
        tokens_for_number() sendiri hanya membaca viewport SEMASA.
        Kegagalan mencari = None = pemanggil MESTI FAIL; tiada baris lain
        dipulangkan."""
        if not no_rekod:
            return None
        self.dismiss_native_alerts(first_timeout=1,
                                   context="Senarai token-ikut-nombor")
        self._scroll_senarai_top()
        for _ in range(max_scrolls):
            toks = self.tokens_for_number(no_rekod)
            if toks is not None:
                print(f"  [SENARAI] row tokens for {no_rekod}: {toks}")
                return toks
            if not self._scroll_senarai_down():
                break
        print(f"  [SENARAI] {no_rekod} tidak kelihatan dalam Senarai — "
              f"tiada token dipulangkan (enggan membaca baris lain)")
        self._diagnose_popup_number(no_rekod, konteks="senarai")
        return None

    def row_status_for_number(self, no_rekod):
        """Best-effort read of a status token for `no_rekod` from the
        Senarai row. Returns None when the number is not listed.

        Kini melalui tokens_for_number()/find_number_and_tokens() (C-2) —
        sebelum ini ia sentiasa None kerana nombor dicari dalam desc
        BARIS yang tidak pernah mengandunginya.

        # SAHKAN-DEVICE: lajur MANA pada baris Senarai MBJB membawa status
        # notis ('B' untuk notis peringatan pertama), kalau ada langsung.
        # Sheet 'Status Batal' V2.1.33 membuktikan konsep status 'B' wujud
        # dalam data, tetapi TIDAK membuktikan app memaparkannya. Dump
        # satu baris penuh dan padankan indeks token sebelum mempercayai
        # nilai pulangan ini."""
        return self.find_number_and_tokens(no_rekod)

    # ------------------------------------------------------------------
    # C-4b: snapshot nombor jenis ini, ATAS hingga HUJUNG senarai.
    # ------------------------------------------------------------------

    def _visible_number_jenis_pairs(self, jenis_letter):
        """(nombor, adakah_jenis_ini) bagi setiap sel NO AKAUN yang
        kelihatan. Jenis ditentukan daripada baris ringkasan yang
        BERTINDIH dengan sel itu (token pertama baris = huruf jenis).
        Kalau tiada baris bertindih, ia jatuh kepada peraturan RENTETAN
        (awalan + huruf jenis) dengan AMARAN — itu bukan pemilihan ikut
        kedudukan, ia pengelasan jenis."""
        want = jenis_letter.upper()
        prefix = _record_prefix()
        out = []
        try:
            rows = [(r, r.rect) for r in
                    self.driver.find_elements(*self.ROW_LOCATOR)]
        except Exception:                                    # noqa: BLE001
            rows = []
        loc = (AppiumBy.ANDROID_UIAUTOMATOR,
               f'new UiSelector().descriptionMatches("{prefix}\\w+")')
        try:
            cells = self.driver.find_elements(*loc)
        except Exception:                                    # noqa: BLE001
            cells = []
        for c in cells:
            no = c.get_attribute("content-desc")
            if not no:
                continue
            jenis = None
            try:
                cr = c.rect
                cy = cr["y"] + cr["height"] // 2
                for row, rr in rows:
                    if rr["y"] <= cy <= rr["y"] + rr["height"]:
                        d = (row.get_attribute("content-desc") or "").strip()
                        if d:
                            jenis = d.split(",")[0].strip().upper()
                        break
            except Exception:                                # noqa: BLE001
                pass
            if jenis is None:
                # SAHKAN-DEVICE: susunan nombor rekod MBJB. MBIP ialah
                # 'IPA' + '3' + huruf jenis (ada aksara tambahan di
                # tengah); kontrak §6.5 langkah 2 menuntut Loh mengesahkan
                # huruf jenis benar-benar aksara SELEPAS awalan. Kalau
                # tidak, offset di sini perlu dilaraskan.
                print(f"  [SENARAI] {no}: tiada baris ringkasan bertindih — "
                      f"mengelas jenis dari rentetan nombor "
                      f"(awalan {prefix!r} + huruf jenis). SAHKAN susunan "
                      f"nombor pada device.")
                out.append((no, no.upper().startswith(f"{prefix.upper()}"
                                                      f"{want}")))
                continue
            out.append((no, jenis == want))
        return out

    def numbers_for_jenis(self, jenis_letter, max_scrolls=20):
        """Semua nombor rekod jenis ini, dari ATAS hingga HUJUNG senarai.

        C-4b: dipakai untuk mengesan sama ada Kemaskini mengeluarkan
        nombor rekod BAHARU (`set(selepas) - set(sebelum)`).

        MELEMPAR `RuntimeError` kalau senarai tidak dapat diskrol sampai
        habis dalam `max_scrolls` — snapshot SEPARA menghasilkan delta
        yang MENIPU (nombor yang sekadar belum di-skrol kelihatan seperti
        nombor baharu), dan delta yang menipu akan menghala TC -004
        membuka rekod yang salah."""
        seen = []
        self.dismiss_native_alerts(first_timeout=1,
                                   context="Senarai snapshot-nombor")
        self._scroll_senarai_top()
        habis = False
        for _ in range(max_scrolls):
            for no, ok in self._visible_number_jenis_pairs(jenis_letter):
                if ok and no not in seen:
                    seen.append(no)
            if not self._scroll_senarai_down():
                habis = True
                break
        if not habis:
            raise RuntimeError(
                f"numbers_for_jenis({jenis_letter!r}): senarai masih "
                f"bergerak selepas {max_scrolls} skrol — snapshot SEPARA. "
                f"Menolak memulangkan snapshot separa: delta 'nombor "
                f"baharu' yang dihitung daripadanya akan menipu dan boleh "
                f"menghala kemaskini kepada rekod yang salah. Naikkan "
                f"max_scrolls atau ketatkan penapis tarikh Senarai.")
        print(f"  [SENARAI] snapshot jenis {jenis_letter.upper()}: "
              f"{len(seen)} nombor")
        return seen

    def filter_by_day_range(self, start_day, end_day):
        """Complete date range filter flow: open calendar, tap start day,
        tap end day (picker auto-dissolves), click Semak, verify records.
        """
        self.open_calendar()
        self.select_day(start_day)
        self.select_day(end_day)
        # Calendar auto-closes after selecting the end day — no explicit
        # close action needed here.
        self.click_semak()
        assert self.is_records_displayed(), \
            "FAIL: No records displayed after date filter"
        return True

"""
Pelarasan (Menu Selaras) page — Page Object Model.

New in v2: this whole "Menu Selaras" sequence runs unconditionally BEFORE
login every time (not just as a license-mismatch fallback like the older
handle_license_mismatch() in login_page.py). Confirmed via user's manual
walkthrough + screenshot of the actual popup, not assumption.

Flow (from hamburger icon on the login screen):
    1. Tap hamburger -> "MENU SELARAS" popup appears listing all items
       below, in order:
         TETAPAN ALAMAT IP
         TETAPAN PELBAGAI
         SELARAS PENGGUNA APPS
         SELARAS MAKLUMAT ALAMAT
         SELARAS MAKLUMAT KOMPAUN
         SELARAS MAKLUMAT JENIS KENDERAAN
         SELARAS MAKLUMAT WARNA
         SELARAS MAKLUMAT PELESEN   <- SKIPPED, per explicit instruction
         SELARAS MAKLUMAT BARANG SITA
         TETAPAN SKRIN UTAMA        <- not part of this flow
         SEMAK KEMASKINI VERSI TERKINI  <- not part of this flow
    2. TETAPAN ALAMAT IP: fill internal/external IP, Simpan -> back to
       the Menu Selaras popup.
    3. TETAPAN PELBAGAI: fill "Lesen Aplikasi" (the real on-screen label
       -- NOT "Device ID", which was only ever an assumption in the
       original login_page.py flow and never actually confirmed), Simpan
       -> "Lesen sama" popup -> OK.
    4. Each "SELARAS ..." menu item: tap it, wait for its own confirmation
       popup (each with a distinct message -- matched via textContains on
       a distinguishing substring, not a full exact string, since these
       were given from memory rather than a screenshot of each one), tap
       OK if a dismiss step is needed, return to the Menu Selaras popup.
    5. Close the Menu Selaras popup -> proceed to normal login.

DISAHKAN PADA DEVICE MBJB (Loh, 2026-07-30, APK 2.1.33-Dev / Ulefone
Armor 27 — reports\\fasa2-bootstrap.md §2.3 & §2.4):
    - 11 item menu di atas WUJUD, dengan `content-desc` == `text` untuk
      setiap satu (dump ui_dumps\\02_menu_hamburger.xml). Locator `text()`
      tepat di bawah oleh itu BETUL, bukan tekaan.
      PERANGKAP: item terakhir ialah 'SEMAK KEMASKINI VERSI TERKINI '
      dengan RUANG DI HUJUNG pada KEDUA-DUA `text` DAN `content-desc`
      (bercanggah dengan nota brief bahawa content-desc bersih) — sebab
      itu MENU_SEMAK_KEMASKINI guna textContains.
    - Teks setiap mesej pengesahan Selaras — lihat MESEJ_SELARAS.
    - Struktur modal bersarang: modal -> modal-backdrop
      (content-desc='Close modal') -> modal-wrapper -> modal-surface.
      Bilangan modal-surface = kedalaman sarang.
    - Skrin login masih dirender DI BELAKANG modal Tetapan, termasuk
      kedua-dua EditText-nya — lihat nota INPUT_OUTLINED, ini pernah
      menjadikan indeks EditText global bahaya.

MASIH BELUM DISAHKAN:
    - Sama ada "SELARAS PENGGUNA APPS" perlu tap OK eksplisit
      (dikendalikan sebagai "OK kalau ada, tidak fatal kalau tiada").
    - Mekanisme tepat "tutup popup" di akhir (cuba ikon tutup, kemudian
      Back, akhirnya relaunch dengan pengesahan).

INSIDEN 2026-07-31 (recon\\PAPAN.md "AMARAN") — dibetulkan:
    Satu larian menghasilkan popup "BERJAYA | DATA MAKLUMAT BARANG
    SITAAN BERJAYA DISIMPAN!" TANPA satu pun kaedah selaras_*()
    dipanggil, semasa gerbang IP (tests\\conftest.py) menavigasi popup
    ini untuk mencapai TETAPAN ALAMAT IP -- satu tap tersasar. Menu
    yang SAMA mengandungi SELARAS MAKLUMAT PELESEN (>4 jam); tap
    tersasar seterusnya boleh membakar setengah hari kerja. Punca yang
    disyaki: open_menu_selaras() versi lama retap HAMBURGER buta pada
    kali kedua tanpa menyemak semula sama ada popup sudah terbuka --
    Appium tidak menyemak occlusion piksel, jadi hamburger yang
    SEBENARNYA sudah tertutup masih boleh dilaporkan "clickable", dan
    tap fizikal jatuh pada apa sahaja yang dirender pada koordinat itu
    SEKARANG. open_menu_selaras() dan _open_tetapan_item() kini dibina
    di atas tap_menu_item_disahkan() (kaedah AWAM baharu, dikongsi juga
    oleh gerbang IP dalam tests\\conftest.py) -- setiap tap: cari
    elemen SEGAR, log sasaran sebenar, tap, semak SERTA-MERTA sama ada
    satu overlay sync SELARAS tercetus tanpa diminta (BERHENTI dengan
    RuntimeError kalau ya), kemudian sahkan skrin berubah. TIADA tap
    koordinat mentah, TIADA tap membuta pada handle/keadaan lama.
"""

from appium.webdriver.common.appiumby import AppiumBy
from selenium.common.exceptions import TimeoutException
from pages.base_page import BasePage


class PelarasanPage(BasePage):
    """Menu Selaras (sync/settings) screen — runs before every login."""

    # ---- Menu Selaras popup items (confirmed via screenshot, ALL CAPS) ----
    # >>> LOCATOR MENU DIBETULKAN UNTUK MBPG 2.1.21 — 2026-08-10. <<<
    #
    # MBJB memakai text("HURUF BESAR") pada setiap item, dan
    # UiSelector().text() PEKA HURUF + padanan PENUH. Recon device MBPG
    # (devtools/recon_skrin.py, recon/skrin_semasa.xml) menunjukkan item
    # sebenar dalam Title Case: "Tetapan Alamat IP", "Selaras Maklumat
    # Alamat", dan seterusnya. Tiada satu pun locator huruf besar itu
    # memadan, jadi SETIAP item menu tidak dapat dijumpai.
    #
    # Dua perangkap lagi yang ditemui pada recon yang sama:
    #   * App mengeja "Selaras PENGUNA Apps" dengan SATU 'g'. Padanan
    #     tidak-peka-huruf sahaja masih gagal; corak di bawah menerima
    #     kedua-dua ejaan supaya pembetulan ejaan app kelak tidak
    #     memecahkannya semula.
    #   * Item kemaskini ialah "Semak Kemaskini Versi Terkini", lebih
    #     panjang daripada "SEMAK KEMASKINI" MBJB.
    #
    # textMatches() melakukan padanan PENUH, jadi setiap corak mesti
    # meliputi keseluruhan rentetan.
    _M = 'new UiSelector().textMatches("(?i)\s*{}\s*")'

    MENU_TETAPAN_ALAMAT_IP = (AppiumBy.ANDROID_UIAUTOMATOR,
                              _M.format("TETAPAN\s+ALAMAT\s+IP"))
    MENU_TETAPAN_PELBAGAI = (AppiumBy.ANDROID_UIAUTOMATOR,
                             _M.format("TETAPAN\s+PELBAGAI"))
    # PENG?GUNA: app eja 'Penguna' (satu g) pada 2.1.21.
    MENU_SELARAS_PENGGUNA_APPS = (AppiumBy.ANDROID_UIAUTOMATOR,
                                  _M.format("SELARAS\s+PENG?GUNA\s+APPS"))
    MENU_SELARAS_MAKLUMAT_ALAMAT = (AppiumBy.ANDROID_UIAUTOMATOR,
                                    _M.format("SELARAS\s+MAKLUMAT\s+ALAMAT"))
    MENU_SELARAS_MAKLUMAT_KOMPAUN = (AppiumBy.ANDROID_UIAUTOMATOR,
                                     _M.format("SELARAS\s+MAKLUMAT\s+KOMPAUN"))
    MENU_SELARAS_JENIS_KENDERAAN = (AppiumBy.ANDROID_UIAUTOMATOR,
                                    _M.format("SELARAS\s+MAKLUMAT\s+JENIS\s+KENDERAAN"))
    MENU_SELARAS_MAKLUMAT_WARNA = (AppiumBy.ANDROID_UIAUTOMATOR,
                                   _M.format("SELARAS\s+MAKLUMAT\s+WARNA"))
    # SELARAS MAKLUMAT PELESEN: locator kept for completeness (confirmed
    # via live recon dump recon_pelesen_60s.xml, desc + text both match),
    # but the item is intentionally NEVER tapped -- T-008 is skipped per
    # explicit user instruction, same as v2. Its sync saves 52,317
    # records (~an hour of device time).
    MENU_SELARAS_PELESEN = (AppiumBy.ANDROID_UIAUTOMATOR,
                            _M.format("SELARAS\s+MAKLUMAT\s+PELESEN"))
    MENU_SELARAS_BARANG_SITA = (AppiumBy.ANDROID_UIAUTOMATOR,
                                _M.format("SELARAS\s+MAKLUMAT\s+BARANG\s+SITA"))

    # ---- Tetapan Alamat IP sub-screen ----
    FIELD_INTERNAL_IP_LABEL = "INTERNAL IP ADDRESS"
    FIELD_EXTERNAL_IP_LABEL = "EXTERNAL IP ADDRESS"
    # text("Simpan") (Title Case) was an unverified guess and never
    # matched on a live run -- this app consistently renders button
    # labels upper-case ("HANTAR", "SEMAK", "MENYERAHKAN"...), and some
    # buttons expose the label only via content-desc (e.g. SEMAK on
    # Senarai). Matched case-insensitively on both attributes instead;
    # see _click_simpan().
    SIMPAN_LOCATORS = [
        (AppiumBy.ANDROID_UIAUTOMATOR,
         'new UiSelector().textMatches("(?i)\\s*simpan\\s*")'),
        (AppiumBy.ANDROID_UIAUTOMATOR,
         'new UiSelector().descriptionMatches("(?i)\\s*simpan\\s*")'),
    ]

    # ---- Tetapan Pelbagai sub-screen ----
    # FAKTA DEVICE, Loh 2026-07-30, dump ui_dumps\08_tetapan_pelbagai.xml:
    # label pada skrin ialah TextView text="LESEN APLIKASI:" -- HURUF BESAR
    # dan ADA TITIK BERTINDIH. Nilai "Lesen Aplikasi" (Title Case, tiada
    # titik bertindih) yang ada di sini sebelum ini TIDAK PADAN: walaupun
    # _ci_label_locator() tidak sensitif huruf, ia mengunci `^...$` jadi
    # titik bertindih yang hilang mematikan padanan. Selain itu label ini
    # ialah TextView, BUKAN EditText -- lihat _isi_input_outlined().
    FIELD_LESEN_APLIKASI_LABEL = "LESEN APLIKASI:"

    # ---- BUG T-002 DIBETULKAN (fakta device) -----------------------------
    # UiSelector().textContains() PEKA huruf besar-kecil. Dialog SEBENAR
    # selepas SIMPAN lesen, dibaca Loh pada device (reports\
    # fasa2-bootstrap.md §2.3; dump ui_dumps\10_lesen_m50_selepas_simpan.xml
    # dan ui_dumps\13_selaras_warna.xml):
    #     android:id/alertTitle = "BEJAYA"      <- ejaan app, TIADA 'R'
    #     android:id/message    = "LESEN SAMA." <- HURUF BESAR + NOKTAH
    # textContains("Lesen sama") TIDAK PERNAH padan, jadi assert dalam
    # set_tetapan_pelbagai() gagal walaupun app BERJAYA. Guna textMatches
    # tidak sensitif huruf, dengan ruang bebas antara dua perkataan.
    # Ini BUKAN melonggarkan assert: assert yang sama masih dituntut, cuma
    # tidak lagi peka huruf.
    POPUP_LESEN_SAMA = (AppiumBy.ANDROID_UIAUTOMATOR,
                        'new UiSelector().textMatches('
                        '"(?i)(?s).*lesen\\s*sama.*")')

    # ---- Mesej pengesahan Selaras — TEKS TEPAT DARI DEVICE ---------------
    # Semua di bawah dibaca Loh dari device 2026-07-30 (dump ui_dumps\
    # 16/17/20/21/22/23_selaras_*.xml). Tajuk alert = "BERJAYA" (ejaan
    # BETUL, tidak seperti dialog lesen). App MEMAKSA HURUF BESAR pada
    # badan mesej, jadi setiap textContains huruf campuran yang ada di
    # sini sebelum ini TIDAK PERNAH padan. Dua ketidakkonsistenan app
    # yang dicatat, bukan tekaan:
    #   - Jenis Kenderaan memulangkan Bahasa INGGERIS "SAVED SUCCESSFULLY!"
    #   - Barang Sita menulis "BARANG SITAAN" walaupun item menu "BARANG SITA"
    #   - Pengguna Apps memulangkan "DATA PENGGUNA ...", bukan "SELARAS
    #     PENGGUNA APPS" — frasa lama itu tiada dalam mesej sama sekali.
    MESEJ_SELARAS = {
        "pengguna_apps":    "DATA PENGGUNA BERJAYA DISIMPAN!",
        "maklumat_alamat":  "DATA ALAMAT BERJAYA DISIMPAN!",
        "maklumat_kompaun": "DATA KOMPAUN BERJAYA DISIMPAN!",
        "jenis_kenderaan":  "DATA JENIS KENDERAAN SAVED SUCCESSFULLY!",
        "maklumat_warna":   "DATA MAKLUMAT WARNA BERJAYA DISIMPAN!",
        "barang_sita":      "DATA MAKLUMAT BARANG SITAAN BERJAYA DISIMPAN!",
    }

    @staticmethod
    def _mesej_locator(frasa):
        """Locator tidak sensitif huruf bagi frasa dalam mesej alert."""
        import re as _re
        return (AppiumBy.ANDROID_UIAUTOMATOR,
                'new UiSelector().textMatches("(?i)(?s).*'
                + _re.escape(frasa) + '.*")')

    # ---- Per-item confirmation popups (kini frasa SEBENAR device, tidak
    # sensitif huruf) ----
    POPUP_PENGGUNA_APPS_OK = (AppiumBy.ANDROID_UIAUTOMATOR,
                              'new UiSelector().textMatches('
                              '"(?i)(?s).*data\\s*pengguna.*")')
    POPUP_MAKLUMAT_ALAMAT_OK = (AppiumBy.ANDROID_UIAUTOMATOR,
                                'new UiSelector().textMatches('
                                '"(?i)(?s).*data\\s*alamat.*")')
    POPUP_MAKLUMAT_KOMPAUN_OK = (AppiumBy.ANDROID_UIAUTOMATOR,
                                 'new UiSelector().textMatches('
                                 '"(?i)(?s).*data\\s*kompaun.*")')
    POPUP_JENIS_KENDERAAN_OK = (AppiumBy.ANDROID_UIAUTOMATOR,
                                'new UiSelector().textMatches('
                                '"(?i)(?s).*jenis\\s*kenderaan.*")')
    POPUP_MAKLUMAT_WARNA_OK = (AppiumBy.ANDROID_UIAUTOMATOR,
                               'new UiSelector().textMatches('
                               '"(?i)(?s).*maklumat\\s*warna.*")')
    # "BARANG SITA" ialah subrentetan "BARANG SITAAN" -> padan kedua-dua.
    POPUP_BARANG_SITA_OK = (AppiumBy.ANDROID_UIAUTOMATOR,
                            'new UiSelector().textMatches('
                            '"(?i)(?s).*barang\\s*sita.*")')

    # ========================================================================
    # Sub-flows
    # ========================================================================

    # Login screen title -- used to verify/restore the flow's starting
    # point (same locator as login_page.APP_TITLE).
    # Peka huruf — lihat nota panjang pada login_page.APP_TITLE. MBPG
    # 2.1.21 memaparkan "Aplikasi Kompaun e-PBT" (Title Case); locator
    # huruf besar MBJB tidak pernah memadan, dan itu menyebabkan gerbang
    # IP tersalah lapor "app sudah log masuk".
    LOGIN_SCREEN_TITLE = (AppiumBy.ANDROID_UIAUTOMATOR,
                          'new UiSelector().textMatches('
                          '"(?i)\\s*APLIKASI\\s+KOMPAUN\\s+e-PBT\\s*")')

    def ensure_on_login_screen(self):
        """Guarantee the flow starts from the login screen.

        Confirmed via live runs 2->3: with no_reset=True the app resumes
        exactly where the previous session died (the RN activity resumes
        its existing task rather than restarting), so a run that failed
        on e.g. the Tetapan Alamat IP sub-screen leaves the NEXT run
        starting there too -- the hamburger tap then can't open the Menu
        Selaras popup and the whole flow collapses at the first menu
        item. If the login title isn't visible, force a clean cold start
        (terminate + activate keeps app data, unlike a reinstall).
        """
        # Checking the title alone is NOT enough: a previous run that
        # got past login leaves the app logged-in on the home screen,
        # whose app bar can carry the same title -- the hamburger then
        # opens the home menu instead of Menu Selaras and the whole
        # flow dies at the first menu item (observed live in the run
        # after a logged-in run). Require the home grid to be absent too.
        # ...dan modal RN yang tertinggal juga mesti tiada: diukur
        # 2026-08-04, LOGIN_SCREEN_TITLE kekal dijumpai DI BAWAH popup
        # MENU SELARAS yang terbuka, jadi tajuk sahaja mengesahkan apa-apa.
        on_login = self.is_element_present(self.LOGIN_SCREEN_TITLE, timeout=5)
        logged_in = self.is_element_present(self.HOME_SCREEN_INDICATOR,
                                            timeout=2)
        if on_login and not logged_in and self._popup_menu_selaras_hilang():
            print("  [PELARASAN] On login screen — good starting point")
            return
        from config import APP_PACKAGE
        print("  [PELARASAN] NOT on a clean login screen (leftover state "
              "from a previous run, possibly still logged in) -- "
              "force-relaunching the app...")
        import time
        self.driver.terminate_app(APP_PACKAGE)
        time.sleep(1)
        self.driver.activate_app(APP_PACKAGE)
        assert self.is_element_present(self.LOGIN_SCREEN_TITLE, timeout=30), \
            "FAIL: Login screen not reached even after force-relaunching app"
        print("  [PELARASAN] App relaunched — login screen reached")

    # ---- Jaringan keselamatan: gerbang IP TIDAK PERNAH boleh sentuh
    # item SELARAS -----------------------------------------------------
    # INSIDEN 2026-07-31 (recon\PAPAN.md "AMARAN"): satu larian
    # menghasilkan popup "BERJAYA | DATA MAKLUMAT BARANG SITAAN BERJAYA
    # DISIMPAN!" semasa navigasi Menu Selaras untuk mencapai TETAPAN
    # ALAMAT IP, TANPA satu pun kaedah selaras_*() dipanggil -- tap
    # tersasar. Punca paling mungkin: versi LAMA open_menu_selaras() di
    # bawah retap HAMBURGER buta pada kali kedua tanpa menyemak semula
    # sama ada popup sudah terbuka (RN modal boleh animasi lambat) --
    # Appium element_to_be_clickable()/is_displayed() TIDAK menyemak
    # occlusion piksel, jadi hamburger yang SEBENARNYA sudah tertutup
    # oleh popup baharu masih boleh dilaporkan "clickable", dan tap
    # fizikal jatuh pada apa sahaja yang SEBENARNYA dirender pada
    # koordinat itu SEKARANG -- berpotensi satu item menu. Menu yang
    # sama mengandungi SELARAS MAKLUMAT PELESEN (>4 jam) -- tap
    # tersasar seterusnya boleh membakar setengah hari.
    #
    # Dua lapisan pertahanan, kedua-duanya dalam tap_menu_item_disahkan()
    # di bawah:
    #   1. Sebelum SETIAP tap: kalau skrin sasaran sudah terbuka, JANGAN
    #      tap lagi (elak tap kedua menimpa animasi popup yang sedang/
    #      sudah terbuka -- ini punca insiden).
    #   2. Sejurus SELEPAS setiap tap: semak overlay simpan/proses
    #      SELARAS. Kalau kelihatan sedangkan tiada kaedah selaras_*()
    #      pernah dipanggil pada titik ini, BERHENTI SERTA-MERTA
    #      (RuntimeError) -- jangan teruskan navigasi dan biarkan sync
    #      itu berjalan senyap di latar sehingga alertnya muncul lewat
    #      (selepas login, seperti insiden asal -- alert asli beratur).

    def _teks_elemen(self, el):
        """Baca text/content-desc elemen untuk log -- baca sahaja, tidak
        pernah melempar (elak log itu sendiri menjadi punca kegagalan)."""
        try:
            t = (el.text or "").strip()
            if t:
                return t
        except Exception:                                    # noqa: BLE001
            pass
        try:
            return (el.get_attribute("content-desc") or "").strip()
        except Exception:                                    # noqa: BLE001
            return ""

    def _selaras_tercetus_tanpa_diminta(self):
        """True kalau overlay simpan/proses SELARAS kelihatan SEKARANG
        (PROGRESS_SAVING "SEDANG MENYIMPAN..." atau OVERLAY_SIBUK
        "... SEDANG DIPROSES...", base_page.py). Dipanggil SEJURUS
        selepas setiap tap navigasi gerbang IP -- lihat blok komen di
        atas."""
        return (self.is_element_present(self.PROGRESS_SAVING, timeout=1) or
               self.is_element_present(self.OVERLAY_SIBUK, timeout=1))

    def tap_menu_item_disahkan(self, locator, nama_sasaran,
                               verifikasi_locators, percubaan_maksimum=3,
                               sudah_terbuka_locator=None):
        """Tap SATU item menu ikut `locator` (content-desc/text), dengan
        cari-elemen -> log sasaran -> tap -> jaringan keselamatan
        SELARAS -> sahkan skrin berubah -> ulang kalau perlu. TIADA tap
        koordinat mentah, TIADA tap membuta pada handle/keadaan lama --
        setiap percubaan mencari elemen SEMULA (fresh find) dan
        menyemak keadaan skrin SEBELUM memutuskan untuk tap.

        Permukaan AWAM dikongsi oleh open_menu_selaras() (fail ini) dan
        gerbang IP (tests\\conftest.py, lapisan 3) -- ditambah selepas
        insiden 2026-07-31 supaya KEDUA-DUA laluan berkongsi SATU
        implementasi yang disahkan, bukan dua salinan berasingan yang
        boleh menyimpang.

        Setiap percubaan:
          1. Kalau `sudah_terbuka_locator` diberi dan ia SUDAH
             kelihatan, TIADA tap (elak tap kedua menimpa animasi
             popup yang sedang/sudah terbuka -- punca insiden
             2026-07-31: hamburger ditap semula sedangkan popup
             sebenarnya sudah/sedang terbuka).
          2. Cari SATU elemen semasa ikut `locator` (find_clickable --
             fresh find, bukan handle lama).
          3. Log sasaran sebenar (`text`/`content-desc` elemen yang
             DIJUMPAI, bukan label yang kita HARAP).
          4. Tap (tap_element -- sentuhan koordinat elemen yang BARU
             dijumpai, bukan koordinat simpanan lama).
          5. SERTA-MERTA semak jaringan keselamatan SELARAS --
             _selaras_tercetus_tanpa_diminta(). Kalau True, RuntimeError
             SERTA-MERTA -- ini bermakna tap tersasar mencetuskan sync.
          6. Sahkan skrin berubah ikut `verifikasi_locators` (mana-mana
             satu wujud = berubah).

        Kalau langkah 2 (cari elemen) sendiri gagal, exception dibiar
        naik terus -- BUKAN ditelan untuk cuba tap lokasi/koordinat
        lain. Kalau selepas `percubaan_maksimum` skrin masih tidak
        berubah, RuntimeError -- BERHENTI, bukan pilih sandaran
        koordinat/kedudukan.
        """
        for percubaan in range(1, percubaan_maksimum + 1):
            if sudah_terbuka_locator is not None and \
               self.is_element_present(sudah_terbuka_locator, timeout=2):
                print(f"  [MENU] {nama_sasaran}: skrin sasaran sudah "
                      f"terbuka -- tiada tap (elak tap berganda)")
                return

            el = self.find_clickable(locator, timeout=10)
            sasaran = self._teks_elemen(el) or nama_sasaran
            print(f"  [MENU] sasar content-desc/text={sasaran!r} -> tap "
                  f"{nama_sasaran} (percubaan {percubaan}/"
                  f"{percubaan_maksimum})...")
            self.tap_element(el)

            if self._selaras_tercetus_tanpa_diminta():
                raise RuntimeError(
                    f"GERBANG-IP: BERHENTI SERTA-MERTA -- overlay sync "
                    f"SELARAS kelihatan sejurus selepas tap "
                    f"{nama_sasaran!r} (sasaran {sasaran!r}), sedangkan "
                    f"TIADA kaedah selaras_*() pernah dipanggil pada "
                    f"titik ini. Ini tanda tap tersasar mencetuskan "
                    f"satu sync (kelas insiden 2026-07-31, "
                    f"recon\\PAPAN.md 'AMARAN' -- SELARAS MAKLUMAT "
                    f"BARANG SITA tercetus tanpa diminta). Menu ini "
                    f"turut mengandungi SELARAS MAKLUMAT PELESEN "
                    f"(>4 jam). Sahkan skrin device dengan mata SEBELUM "
                    f"apa-apa tindakan lanjut -- sync yang sudah "
                    f"tercetus TIDAK terhenti walaupun proses pytest "
                    f"dibunuh (ia berjalan di sebelah APP).")

            berubah = any(self.is_element_present(loc, timeout=6)
                         for loc in verifikasi_locators)
            print(f"  [MENU] sasar content-desc/text={sasaran!r} -> tap "
                  f"-> disahkan: "
                  f"{'skrin berubah' if berubah else 'skrin TIDAK berubah'}")
            if berubah:
                return

        raise RuntimeError(
            f"GERBANG-IP: BERHENTI -- {nama_sasaran} tidak menghasilkan "
            f"perubahan skrin selepas {percubaan_maksimum} percubaan "
            f"tap yang SETIAP SATU disahkan (bukan tap membuta pada "
            f"koordinat/keadaan lama). Sahkan skrin dengan mata -- "
            f"jangan ulang cubaan automatik tanpa had.")

    def open_menu_selaras(self):
        """Tap the hamburger icon to open the Menu Selaras popup.

        v2 (insiden 2026-07-31, recon\\PAPAN.md "AMARAN"): dibina semula
        di atas tap_menu_item_disahkan() -- lihat kaedah itu untuk
        kontrak penuh (cari-elemen -> log sasaran -> tap -> jaringan
        keselamatan SELARAS -> sahkan skrin berubah -> ulang). Beza
        teras daripada versi lama: retap hamburger MENYEMAK SEMULA
        dahulu sama ada popup sudah terbuka (bukan tap membuta pada
        koordinat/handle lama), setiap tap disahkan SERTA-MERTA
        terhadap jaringan keselamatan SELARAS, dan kegagalan akhir
        BERHENTI (RuntimeError) dan bukan assert senyap.
        """
        print("  [PELARASAN] Opening Menu Selaras (hamburger icon)...")
        self.tap_menu_item_disahkan(
            self.HAMBURGER, "buka Menu Selaras (hamburger)",
            verifikasi_locators=[self.MENU_TETAPAN_ALAMAT_IP],
            sudah_terbuka_locator=self.MENU_TETAPAN_ALAMAT_IP,
        )

    def _click_simpan(self):
        """Click the Simpan button on the Tetapan sub-screens.

        Tries each SIMPAN_LOCATORS candidate with a short bounded check
        (NOT find_clickable, whose keyboard/scroll fallback loops would
        burn ~60s per wrong candidate), hiding the keyboard first since
        Simpan sits right after the typed fields. Uses tap_element (raw
        coordinate tap) rather than el.click() -- this app's custom
        Pressables have repeatedly been confirmed to silently no-op on
        the accessibility ACTION_CLICK that click() sends.

        On total failure, dumps the page source next to the test run so
        the real locator can be read straight from the dump instead of
        another round of guessing.
        """
        self._hide_keyboard_if_shown()
        import time
        time.sleep(0.5)

        for attempt in range(2):
            for loc in self.SIMPAN_LOCATORS:
                if self.is_element_present(loc, timeout=5):
                    el = self.find_element(loc, timeout=5)
                    self.tap_element(el)
                    return
            # Candidates not on screen -- maybe below the fold; scroll
            # once and retry the full candidate list.
            if attempt == 0:
                self._scroll_down()

        dump_path = "debug_simpan_page_source.xml"
        try:
            with open(dump_path, "w", encoding="utf-8") as f:
                f.write(self.driver.page_source)
            print(f"  [PELARASAN] DEBUG: Simpan not found -- page source "
                  f"dumped to {dump_path}")
        except Exception:
            pass
        raise TimeoutException(
            "Simpan button not found by any locator (case-insensitive "
            "text/description match); see debug_simpan_page_source.xml "
            "for the actual screen hierarchy")

    def _open_tetapan_item(self, menu_locator, item_name):
        """Tap a Tetapan menu item and verify its sub-screen actually
        opened.

        v2 (insiden 2026-07-31, recon\\PAPAN.md "AMARAN"): dibina semula
        di atas tap_menu_item_disahkan() -- lihat kaedah itu untuk
        kontrak cari-elemen -> log sasaran -> tap -> jaringan
        keselamatan SELARAS -> sahkan skrin berubah -> ulang. TimeoutException
        (elemen menu itu sendiri tidak dijumpai langsung -- kelas
        kegagalan BERBEZA: popup Menu Selaras lenyap antara semakan dan
        tap, diperhati secara langsung) tetap dikendalikan di sini
        dengan buka-semula-menu + SATU cubaan lagi, sama seperti
        sebelum ini -- tap_menu_item_disahkan() sendiri sudah
        mengendalikan "tap tidak berkesan" (RuntimeError kalau skrin
        tidak berubah selepas percubaan dalamannya).
        """
        print(f"  [PELARASAN] Opening {item_name}...")
        try:
            self.tap_menu_item_disahkan(
                menu_locator, item_name,
                verifikasi_locators=self.SIMPAN_LOCATORS,
            )
            return
        except TimeoutException:
            # The Menu Selaras popup can vanish between its open-check
            # and this tap (observed live). Reopen it and retry once.
            print(f"  [PELARASAN] {item_name} menu item not reachable -- "
                  f"reopening Menu Selaras and retrying...")
            self.open_menu_selaras()
        self.tap_menu_item_disahkan(
            menu_locator, item_name,
            verifikasi_locators=self.SIMPAN_LOCATORS,
        )

    # ---- Medan input modal Tetapan — KENAPA instance() GLOBAL BAHAYA -----
    # FAKTA DEVICE, Loh 2026-07-30, dump ui_dumps\03_tetapan_alamat_ip.xml
    # dan ui_dumps\07_ip_sahkan_kekal.xml:
    #   * Modal Tetapan ialah OVERLAY. Skrin login DI BELAKANGNYA masih
    #     dirender dalam accessibility tree, termasuk KEDUA-DUA EditText-nya
    #     (username `msc` dan password) dan ia datang DAHULU dalam tree.
    #   * Jadi `className("android.widget.EditText").instance(0)` pada skrin
    #     ini ialah medan USERNAME LOGIN, dan `.instance(1)` ialah PASSWORD.
    #     Medan IP sebenar ialah instance 2 dan 3.
    #   * Tier 3 fill_field_by_label_or_instance(instance=0/1) oleh itu akan
    #     MENAIP IP KE DALAM MEDAN LOGIN — merosakkan T-001, T-002 dan
    #     SETIAP log masuk selepasnya, secara senyap.
    #   * Medan modal semuanya `resource-id="text-input-outlined"`. Dua medan
    #     IP berkongsi id yang SAMA, dibezakan ikut indeks: INTERNAL = 0,
    #     EXTERNAL = 1 (urutan tree: label INTERNAL, EditText, label
    #     EXTERNAL, EditText).
    #   * `text` medan ini KOSONG bila belum diisi (BUKAN placeholder seperti
    #     borang Notis Amaran) dan label ialah TextView BERASINGAN
    #     (`text-input-outlined-label-inactive`). Jadi locator ikut label
    #     memadan TextView, bukan medan — sebab itu tier 1/2 tidak boleh
    #     dipercayai di sini.
    INPUT_OUTLINED = 'new UiSelector().resourceId("text-input-outlined")'

    def _isi_input_outlined(self, indeks, nilai, nama):
        """Isi EditText `text-input-outlined` ke-`indeks` dalam modal
        Tetapan, dengan baca-balik. Guna 'mobile: type' (Seksyen 3:
        send_keys melempar InvalidElementStateException pada medan IP/
        lesen). Tap koordinat mentah, bukan el.click()."""
        import time
        loc = (AppiumBy.ANDROID_UIAUTOMATOR,
               f'{self.INPUT_OUTLINED}.instance({indeks})')
        el = self.find_element(loc, timeout=15)
        semasa = (self._safe_text(el) or "").strip()
        if semasa == str(nilai):
            print(f"  [PELARASAN] {nama} sudah = {nilai!r} — tidak ditaip")
            return el
        self.tap_element(el)
        time.sleep(0.3)
        self._force_clear(el)
        self._mobile_type(str(nilai))         # DIHALAKAN (IP/port, digit)
        self._hide_keyboard_if_shown()
        time.sleep(0.3)
        # Baca balik dari locator (bukan handle lama) — RN boleh re-render.
        try:
            got = (self._safe_text(self.find_element(loc, timeout=5))
                   or "").strip()
        except Exception:                                    # noqa: BLE001
            got = ""
        if got != str(nilai):
            raise AssertionError(
                f"{nama}: medan text-input-outlined[{indeks}] membaca "
                f"{got!r} selepas menaip {nilai!r}. JANGAN teruskan — "
                f"SIMPAN akan menyimpan nilai yang salah "
                f"(dump rujukan: ui_dumps\\07_ip_sahkan_kekal.xml)")
        print(f"  [PELARASAN] {nama} = {got!r} (disahkan baca-balik)")
        return el

    def _baca_input_outlined(self, indeks):
        """Baca EditText `text-input-outlined` ke-`indeks` TANPA menaip
        dan TANPA mengetuk apa-apa. Pasangan baca-sahaja bagi
        _isi_input_outlined()."""
        loc = (AppiumBy.ANDROID_UIAUTOMATOR,
               f'{self.INPUT_OUTLINED}.instance({indeks})')
        el = self.find_element(loc, timeout=15)
        return (self._safe_text(el) or "").strip()

    # ------------------------------------------------------------------
    # Pasangan BACA-SAHAJA bagi dua penetap Tetapan (MBPG)
    # ------------------------------------------------------------------
    # Kedua-dua set_tetapan_* di bawah menekan SIMPAN, dan SIMPAN ialah
    # butang yang disekat di luar dialog bookmark dalam mod dry-run
    # (guard/dasar.py). Untuk MBPG, T-001 dan T-002 oleh itu dijalankan
    # melalui kaedah BACA-SAHAJA ini.
    #
    # Apa yang HILANG dengan berbuat demikian dinyatakan dengan jujur,
    # bukan disembunyikan: kaedah ini mengesahkan nilai yang TERSIMPAN
    # pada device, tetapi ia TIDAK membuktikan bahawa app MENERIMA input
    # baharu dan menyimpannya. Separuh "apply" bagi kedua-dua TC itu
    # kekal TIDAK TERBUKTI, dan laporan mesti mengatakannya.

    def baca_tetapan_alamat_ip(self):
        """(internal_ip, external_ip) seperti yang tersimpan sekarang.
        Tiada taip, tiada SIMPAN. Kembali ke popup Menu Selaras."""
        self._open_tetapan_item(self.MENU_TETAPAN_ALAMAT_IP,
                                "Tetapan Alamat IP")
        internal = self._baca_input_outlined(0)
        external = self._baca_input_outlined(1)
        print(f"  [PELARASAN] BACA-SAHAJA internal={internal!r} "
              f"external={external!r}")
        self.press_back()
        return internal, external

    def baca_tetapan_pelbagai(self):
        """Lesen aplikasi seperti yang tersimpan sekarang. Tiada taip,
        tiada SIMPAN. Kembali ke popup Menu Selaras."""
        self._open_tetapan_item(self.MENU_TETAPAN_PELBAGAI,
                                "Tetapan Pelbagai")
        lesen = self._baca_input_outlined(0)
        print(f"  [PELARASAN] BACA-SAHAJA lesen_aplikasi={lesen!r}")
        self.press_back()
        return lesen

    def set_tetapan_alamat_ip(self, internal_ip, external_ip):
        """TETAPAN ALAMAT IP: fill internal + external IP, Simpan.

        Kedua-dua medan ditulis ikut indeks DALAM `text-input-outlined`
        (lihat nota INPUT_OUTLINED) — bukan ikut label dan bukan ikut
        indeks EditText global, yang pada device ini menunjuk ke medan
        login di belakang modal.
        """
        self._open_tetapan_item(self.MENU_TETAPAN_ALAMAT_IP,
                                "Tetapan Alamat IP")

        print(f"  [PELARASAN] Setting internal IP: {internal_ip}")
        self._isi_input_outlined(0, internal_ip,
                                 self.FIELD_INTERNAL_IP_LABEL)

        print(f"  [PELARASAN] Setting external IP: {external_ip}")
        self._isi_input_outlined(1, external_ip,
                                 self.FIELD_EXTERNAL_IP_LABEL)

        print("  [PELARASAN] Clicking Simpan...")
        self._click_simpan()
        print("  [PELARASAN] Tetapan Alamat IP saved — PASS")

    def set_tetapan_pelbagai(self, lesen_aplikasi):
        """TETAPAN PELBAGAI: fill Lesen Aplikasi, Simpan, confirm 'Lesen
        sama' popup, tap OK."""
        self._open_tetapan_item(self.MENU_TETAPAN_PELBAGAI,
                                "Tetapan Pelbagai")

        # FAKTA DEVICE (dump ui_dumps\08_tetapan_pelbagai.xml): modal ini
        # ada SATU sahaja `text-input-outlined`, memegang nilai lesen
        # (`352405067769401` sebelum Loh menukarnya). Indeks 0 di sini
        # DISAHKAN, bukan andaian. Sekali lagi: JANGAN guna indeks EditText
        # global — instance(0) global ialah medan username login.
        print(f"  [PELARASAN] Setting Lesen Aplikasi: {lesen_aplikasi}")
        self._isi_input_outlined(0, lesen_aplikasi,
                                 self.FIELD_LESEN_APLIKASI_LABEL)

        print("  [PELARASAN] Clicking Simpan...")
        self._click_simpan()

        # Dialog SEBENAR: tajuk "BEJAYA" (ejaan app), mesej "LESEN SAMA."
        # Locator POPUP_LESEN_SAMA kini textMatches tidak sensitif huruf —
        # lihat notanya. Mesej dibaca dan dicetak supaya log memaparkan
        # ejaan sebenar yang app pulangkan pada run itu.
        print("  [PELARASAN] Menunggu dialog LESEN SAMA...")
        ada = self.is_element_present(self.POPUP_LESEN_SAMA, timeout=15)
        if not ada:
            # Bezakan "tiada dialog" daripada "dialog LAIN" — dialog lain
            # (cth penolakan lesen) ialah penemuan, bukan kegagalan locator.
            try:
                msg = self.driver.find_element(
                    *self.NATIVE_ALERT_MESSAGE).text
            except Exception:                                # noqa: BLE001
                msg = None
            raise AssertionError(
                f"FAIL: dialog LESEN SAMA tidak muncul selepas SIMPAN. "
                f"Mesej alert yang ADA pada skrin: {msg!r} "
                f"(None = tiada alert sama sekali). Lesen yang dihantar: "
                f"{lesen_aplikasi!r}")
        try:
            print(f"  [PELARASAN] dialog: "
                  f"{self.driver.find_element(*self.NATIVE_ALERT_MESSAGE).text!r}")
        except Exception:                                    # noqa: BLE001
            pass
        print("  [PELARASAN] Popup visible — PASS — clicking OK...")
        # Alert asli MEMANG beratur pada device ini (dialog lesen muncul
        # SEMULA selepas ditolak sekali — reports\fasa2-bootstrap.md
        # "PENEMUAN TEKNIKAL BAHARU" #2, dan dump 13_selaras_warna.xml yang
        # sepatutnya alert Warna tetapi merakam dialog LESEN yang kembali).
        # dismiss_native_alerts() berulang sampai tiada; wait_and_click(OK)
        # sekali TIDAK cukup dan tap Selaras seterusnya akan HILANG.
        self.dismiss_native_alerts(first_timeout=3, context="LESEN SAMA")
        print("  [PELARASAN] Tetapan Pelbagai saved — PASS")

    # v3: the on-screen save-progress line rendered inside the Menu
    # Selaras popup while a sync writes records locally -- confirmed via
    # live recon dump (ui_dumps/recon_pelesen_60s.xml): "SEDANG
    # MENYIMPAN REKOD 618 DARI 52317 (1%)". The Pelesen dataset is huge
    # (52k records), so its save can run for the better part of an hour
    # with no alert until the very end.
    PROGRESS_SAVING = (AppiumBy.ANDROID_UIAUTOMATOR,
                       'new UiSelector().textMatches("(?i).*SEDANG\s+MENYIMPAN.*")')

    # FAKTA DEVICE, Loh 2026-07-30 (reports\fasa2-bootstrap.md "PENEMUAN
    # TEKNIKAL BAHARU" #4): overlay sibuk MBJB berbunyi
    #   text="SELARAS MAKLUMAT ALAMAT SEDANG DIPROSES..."
    # iaitu "SEDANG DIPROSES", BUKAN "SEDANG MENYIMPAN". Kalau hanya
    # PROGRESS_SAVING dipantau, Selaras Alamat (~37s pada device) kelihatan
    # SEPERTI TIDAK BERGERAK dan deadline tidak dilanjutkan. Kedua-dua
    # corak dipantau; base_page.OVERLAY_SIBUK ialah locator yang sama yang
    # digunakan tunggu_selesai_diproses().
    def _read_progress(self):
        """Teks kemajuan semasa (mana-mana daripada dua corak overlay),
        atau None bila tiada overlay."""
        for loc in (self.PROGRESS_SAVING, self.OVERLAY_SIBUK):
            try:
                els = self.driver.find_elements(*loc)
                if els:
                    t = els[0].text
                    if t:
                        return t
            except Exception:                                # noqa: BLE001
                pass
        return None

    def _run_selaras_item(self, menu_locator, success_popup_locator,
                          item_name, click_ok=True, timeout=30):
        """Generic runner for the one-tap "Selaras Maklumat X" items.

        Confirmed via live page-source dump (debug_menu_selaras_close
        .xml): these confirmations are native AlertDialogs that arrive
        asynchronously; wait for ANY native alert, log its message, and
        dismiss everything queued. success_popup_locator/click_ok kept
        for signature compatibility but not load-bearing.

        v3 hardening, both confirmed via run 1 + live recon:
        - VERIFIED TAP: the menu-item tap can silently no-op (Pengguna
          Apps alerted in 1s on recon but never within 30s on the run
          where its tap no-oped). Evidence the item actually started =
          its result alert OR the SEDANG MENYIMPAN progress line within
          a few seconds; re-tap up to 3 times otherwise.
        - PROGRESS-AWARE WAIT: while the SEDANG MENYIMPAN line keeps
          changing, the deadline keeps extending (the Pelesen save runs
          ~an hour for 52k records). A stall (same text for 5 minutes)
          gives up; progress is logged every ~30s.
        """
        import time
        print(f"  [PELARASAN] Tapping {item_name}...")
        self.wait_and_tap(menu_locator)

        started = False
        for attempt in range(3):
            if self.is_element_present(self.NATIVE_ALERT_OK, timeout=4) or \
               self.is_element_present(self.PROGRESS_SAVING, timeout=2):
                started = True
                break
            print(f"  [PELARASAN] No visible reaction to the {item_name} "
                  f"tap (attempt {attempt + 1}/3) -- re-tapping...")
            try:
                self.wait_and_tap(menu_locator)
            except Exception:
                break
        if not started:
            print(f"  [PELARASAN] WARNING: no start evidence for "
                  f"{item_name} -- waiting for a result anyway")

        print(f"  [PELARASAN] Waiting for {item_name} result popup...")
        from config import IMPLICIT_WAIT
        # implicit wait off during the poll loop -- with it on, every
        # absent-element probe costs the full implicit wait, turning a
        # long sync's poll loop into mostly dead time.
        self.driver.implicitly_wait(0)
        try:
            deadline = time.monotonic() + timeout
            last_prog = None
            last_change = time.monotonic()
            last_log = 0.0
            while time.monotonic() < deadline:
                if self.is_element_present(self.NATIVE_ALERT_OK, timeout=3):
                    self.dismiss_native_alerts(first_timeout=2,
                                               context=item_name)
                    print(f"  [PELARASAN] {item_name} confirmed and "
                          f"dismissed — PASS")
                    return True
                prog = self._read_progress()
                now = time.monotonic()
                if prog:
                    if prog != last_prog:
                        last_prog, last_change = prog, now
                        deadline = max(deadline, now + 120)
                        if now - last_log > 30:
                            print(f"  [PELARASAN] {item_name} in progress: "
                                  f"{prog}")
                            last_log = now
                    elif now - last_change > 300:
                        print(f"  [PELARASAN] {item_name} progress stalled "
                              f"at {prog!r} for 5 minutes -- giving up")
                        return False
                time.sleep(2)
        finally:
            self.driver.implicitly_wait(IMPLICIT_WAIT)

        print(f"  [PELARASAN] WARNING: no result popup for {item_name} "
              f"within the wait window -- continuing (a late alert will "
              f"be drained before the popup is closed)")
        return False

    def selaras_pengguna_apps(self):
        """SELARAS PENGGUNA APPS. Per the manual flow, no explicit OK tap
        was described for this one (unlike all the others) -- try OK if
        present, don't fail if it isn't."""
        return self._run_selaras_item(
            self.MENU_SELARAS_PENGGUNA_APPS, self.POPUP_PENGGUNA_APPS_OK,
            "Selaras Pengguna Apps", click_ok=True,
        )

    def selaras_maklumat_alamat(self):
        # timeout=60: confirmed via live run that the Alamat sync is the
        # slow one (its alert hadn't shown after 30s while every other
        # item confirmed within seconds -- address dataset is large).
        return self._run_selaras_item(
            self.MENU_SELARAS_MAKLUMAT_ALAMAT, self.POPUP_MAKLUMAT_ALAMAT_OK,
            "Selaras Maklumat Alamat", click_ok=True, timeout=60,
        )

    def selaras_maklumat_kompaun(self):
        return self._run_selaras_item(
            self.MENU_SELARAS_MAKLUMAT_KOMPAUN, self.POPUP_MAKLUMAT_KOMPAUN_OK,
            "Selaras Maklumat Kompaun", click_ok=True,
        )

    def selaras_jenis_kenderaan(self):
        return self._run_selaras_item(
            self.MENU_SELARAS_JENIS_KENDERAAN, self.POPUP_JENIS_KENDERAAN_OK,
            "Selaras Maklumat Jenis Kenderaan", click_ok=True,
        )

    def selaras_maklumat_warna(self):
        return self._run_selaras_item(
            self.MENU_SELARAS_MAKLUMAT_WARNA, self.POPUP_MAKLUMAT_WARNA_OK,
            "Selaras Maklumat Warna", click_ok=True,
        )

    def selaras_maklumat_pelesen(self):
        """DILUMPUHKAN untuk MBPG — melempar, tidak menyentuh peranti.

        MBPG-TC-T-008. Pemilik menegaskan semula 2026-08-07 bahawa ia
        WAJIB dikecualikan sepenuhnya: sync mengambil 3-4 JAM, dan pada
        MBJB ia pernah tercetus SECARA TIDAK SENGAJA lalu menawan peranti
        untuk sepanjang hari kerja.

        Keputusan MBJB yang berlawanan ("T-008 KEKAL dan DICUBA", recon
        MBJB PAPAN.md) SUDAH TIDAK TERPAKAI di sini. Ia dikekalkan dalam
        nota ini supaya sesiapa yang membacanya dalam repo MBJB tahu ia
        telah diterbalikkan dengan sengaja untuk MBPG, dan bukan terlepas
        pandang.

        Tiga lapisan menguatkuasakan pengecualian ini, kerana satu tidak
        mencukupi untuk sesuatu yang kosnya sehari kerja:
          1. T-008 dikeluarkan daripada senarai langkah dalam
             tests/conftest.py (bukan sekadar digerbang oleh env var).
          2. Kaedah ini melempar.
          3. Corong tap menyekat mana-mana ketukan yang teksnya memadan
             item menu itu (guard/dasar.py, peraturan SELARAS-PELESEN) —
             jadi ketukan tersasar pun tidak sampai ke peranti.
        """
        raise NotImplementedError(
            "selaras_maklumat_pelesen() dilumpuhkan untuk MBPG. Arahan "
            "pemilik 2026-08-07: sync 3-4 JAM, exclude total. T-008 "
            "dilaporkan sebagai skip-arahan-pemilik.")

    def selaras_barang_sita(self):
        return self._run_selaras_item(
            self.MENU_SELARAS_BARANG_SITA, self.POPUP_BARANG_SITA_OK,
            "Selaras Maklumat Barang Sita", click_ok=True,
        )

    # ------------------------------------------------------------------
    # v3 Phase 2: T-010 / T-011 (menu items confirmed via live recon
    # dump recon_pelesen_60s.xml -- both render text AND content-desc;
    # note SEMAK KEMASKINI VERSI TERKINI carries a trailing space, so
    # textContains is used)
    # ------------------------------------------------------------------

    # textContains, not exact text() -- T-011's SEMAK item (textContains)
    # resolves every run while the exact-text version of this one timed
    # out twice (probable stray whitespace, same as SEMAK's trailing
    # space); "TETAPAN SKRIN" is unique in the menu.
    # textContains PEKA HURUF juga. Item sebenar: "Tetapan Skrin Utama"
    # dan "Semak Kemaskini Versi Terkini".
    MENU_TETAPAN_SKRIN_UTAMA = (
        AppiumBy.ANDROID_UIAUTOMATOR,
        'new UiSelector().textMatches("(?i).*TETAPAN\s+SKRIN.*")')
    MENU_SEMAK_KEMASKINI = (
        AppiumBy.ANDROID_UIAUTOMATOR,
        'new UiSelector().textMatches("(?i).*SEMAK\s+KEMASKINI.*")')

    def _dump(self, name):
        try:
            import os
            os.makedirs("ui_dumps", exist_ok=True)
            path = os.path.join("ui_dumps", name)
            with open(path, "w", encoding="utf-8") as f:
                f.write(self.driver.page_source)
            print(f"  [PELARASAN] DEBUG: page source dumped to {path}")
            return path
        except Exception:
            return "(dump failed)"

    def tetapan_skrin_utama(self):
        """MBPG-TC-T-010: verify the Tetapan Skrin Utama item opens its
        selection screen. If the screen has a Simpan, it is saved as-is
        (no selection changed -- the sheet only requires that it can be
        selected/opened). Recon-first: page source dumped every run."""
        import time
        print("  [PELARASAN] Opening Tetapan Skrin Utama...")
        # A LATE Selaras result alert can still be covering the menu at
        # this point (confirmed via shakedown run: the Alamat sync's
        # alert landed during T-010 and made every menu item 'not
        # found' for its whole wait) -- drain first.
        self.dismiss_native_alerts(first_timeout=3,
                                   context="pre-Tetapan Skrin Utama")
        # Confirmed via live dump: on a FRESH menu open the whole item
        # list (including this item) is in the tree and nothing is
        # scrollable -- yet reopening the menu right after the
        # pelarasan fixture's open/use/close cycle can render the
        # popup with this item missing (transient RN re-render; the
        # item was 'not present' for a full 15s while a fresh open
        # shows it instantly). Self-heal by closing and reopening the
        # menu until the item renders.
        for round_ in range(3):
            if self.is_element_present(self.MENU_TETAPAN_SKRIN_UTAMA,
                                       timeout=5):
                break
            print(f"  [PELARASAN] Skrin Utama item not rendered "
                  f"(round {round_ + 1}/3) -- closing and reopening the "
                  f"menu...")
            self._dump(f"t010_menu_missing_item_{round_}.xml")
            self.close_menu_selaras()
            self.dismiss_native_alerts(first_timeout=2,
                                       context="menu reopen")
            self.open_menu_selaras()
        # Confirmed via live dump (t010_skrin_utama_never_opened.xml,
        # ironically): tapping the item opens a nested "PILIHAN SKRIN
        # UTAMA" popup ON TOP of the still-rendered menu list, offering
        # DEFAULT / NOTIS AMARAN / KOMPAUN PELBAGAI / KOMPAUN TRAFIK /
        # KOMPAUN LESEN. That popup's title is the open-evidence.
        opened = (AppiumBy.ANDROID_UIAUTOMATOR,
                  'new UiSelector().textMatches("(?i)\s*PILIHAN\s+SKRIN\s+UTAMA\s*")')
        for attempt in range(3):
            self.wait_and_tap(self.MENU_TETAPAN_SKRIN_UTAMA)
            time.sleep(1.5)
            if self.is_element_present(opened, timeout=4):
                break
            print(f"  [PELARASAN] Pilihan Skrin Utama popup didn't open "
                  f"(attempt {attempt + 1}/3) -- re-tapping...")
        else:
            self._dump("t010_skrin_utama_never_opened.xml")
            return False
        self._dump("t010_skrin_utama.xml")
        print("  [PELARASAN] Pilihan Skrin Utama popup opened — PASS")

        # Select DEFAULT -- proves selectability (the sheet's whole
        # requirement) without changing the app's landing screen.
        default_opt = (AppiumBy.ANDROID_UIAUTOMATOR,
                       'new UiSelector().textMatches("(?i)\s*DEFAULT\s*")')
        for attempt in range(3):
            if not self.is_element_present(opened, timeout=2):
                print("  [PELARASAN] Selection registered (popup closed) "
                      "— PASS")
                break
            try:
                el = self.find_element(default_opt, timeout=3)
                self.tap_element(el)
                time.sleep(1.5)
            except TimeoutException:
                break
        self.dismiss_native_alerts(first_timeout=3,
                                   context="Tetapan Skrin Utama")
        if self.is_element_present(opened, timeout=2):
            print("  [PELARASAN] popup still open after selecting "
                  "DEFAULT -- closing it")
            if not self.close_popup_by_icon(timeout=2):
                self.press_back()
            time.sleep(1)
        return True

    def semak_kemaskini(self):
        """MBPG-TC-T-011: run the update check; choose KEMUDIAN so the
        app does NOT actually update. A 'no update available' style
        alert also counts as a completed check (the sheet's expected
        result is 'update check process complete without error')."""
        import time
        print("  [PELARASAN] Opening Semak Kemaskini...")
        # Same late-alert protection as tetapan_skrin_utama.
        self.dismiss_native_alerts(first_timeout=3,
                                   context="pre-Semak Kemaskini")
        # Same transient-render self-heal as tetapan_skrin_utama: the
        # reopened menu popup can render without its bottom items
        # (flaked once on T-011 in the final Phase-3 run after passing
        # 3 runs the same day).
        for round_ in range(3):
            if self.is_element_present(self.MENU_SEMAK_KEMASKINI,
                                       timeout=5):
                break
            print(f"  [PELARASAN] Semak Kemaskini item not rendered "
                  f"(round {round_ + 1}/3) -- closing and reopening the "
                  f"menu...")
            self.close_menu_selaras()
            self.dismiss_native_alerts(first_timeout=2,
                                       context="menu reopen")
            self.open_menu_selaras()
        self.wait_and_tap(self.MENU_SEMAK_KEMASKINI)

        kemudian = (AppiumBy.ANDROID_UIAUTOMATOR,
                    'new UiSelector().textMatches("(?i)\\s*kemudian\\s*")')
        kemudian_desc = (AppiumBy.ANDROID_UIAUTOMATOR,
                         'new UiSelector().descriptionMatches('
                         '"(?i)\\s*kemudian\\s*")')
        deadline = time.monotonic() + 45
        while time.monotonic() < deadline:
            for loc in (kemudian, kemudian_desc):
                if self.is_element_present(loc, timeout=2):
                    self._dump("t011_semak_kemaskini.xml")
                    print("  [PELARASAN] Update prompt visible -- "
                          "choosing KEMUDIAN (do not update)")
                    for attempt in range(3):
                        el = self.find_element(loc, timeout=3)
                        self.tap_element(el)
                        time.sleep(1)
                        if not self.is_element_present(loc, timeout=2):
                            print("  [PELARASAN] Semak Kemaskini "
                                  "completed (KEMUDIAN) — PASS")
                            return True
                    print("  [PELARASAN] WARNING: KEMUDIAN tap never "
                          "registered")
                    return False
            if self.is_element_present(self.NATIVE_ALERT_OK, timeout=2):
                # e.g. "app is up to date" -- check completed.
                self.dismiss_native_alerts(first_timeout=2,
                                           context="Semak Kemaskini")
                print("  [PELARASAN] Semak Kemaskini completed (native "
                      "alert) — PASS")
                return True
            time.sleep(1)
        self._dump("t011_no_update_prompt.xml")
        print("  [PELARASAN] WARNING: no update prompt or alert within "
              "45s")
        return False

    def _popup_menu_selaras_hilang(self):
        """Popup MENU SELARAS benar-benar tiada?

        JANGAN ganti balik dengan `is_element_present(LOGIN_SCREEN_TITLE)`.
        Diukur 2026-08-04 dengan popup TERBUKA: LOGIN_SCREEN_TITLE
        dijumpai (n=1, rect y=582) KERANA skrin login kekal dalam pokok
        view di bawah modal RN. Semakan itu memulangkan True sepanjang
        masa, jadi `close_menu_selaras()` melaporkan 'popup closed'
        sambil meninggalkan popup terbuka — dan menyerahkan skrin
        bersepah kepada login().

        Ketiadaan `modal-backdrop` ialah bukti; kehadiran tajuk bukan.
        """
        from config import IMPLICIT_WAIT
        self.driver.implicitly_wait(0)
        try:
            return not self.driver.find_elements(*self.RN_MODAL_BACKDROP)
        finally:
            self.driver.implicitly_wait(IMPLICIT_WAIT)

    def close_menu_selaras(self):
        """Close the Menu Selaras popup and VERIFY the login screen is
        showing again.

        Confirmed via live run: the old close-icon-then-tap-outside
        guess reported success while the login screen never actually
        came back, so Phase 1 died on 'Login screen not displayed' one
        step later. Now tries close icon -> device Back (RN modals
        close on Back), verifies the login title after each, and as a
        last resort force-relaunches the app -- safe here, since
        everything Pelarasan did (IP/lesen settings, selaras syncs) is
        persisted app data. Dumps the page source before relaunching so
        the popup's real close control can be identified offline.
        """
        print("  [PELARASAN] Closing Menu Selaras popup...")
        import time
        # Result alerts can keep arriving DURING the close attempts
        # themselves (confirmed via two live dumps: a duplicate 'DATA
        # JENIS KENDERAAN SAVED SUCCESSFULLY!' alert appeared after the
        # pre-close drain had already come up empty), and they're
        # non-cancelable RN alerts -- the device Back button does NOT
        # dismiss them (second dump: the alert survived a Back press
        # untouched). So alternate drain-and-close a few times rather
        # than draining once up front.
        for attempt in range(3):
            self.dismiss_native_alerts(first_timeout=2,
                                       context="late sync alert")
            if self._popup_menu_selaras_hilang():
                print("  [PELARASAN] popup MENU SELARAS DISAHKAN hilang "
                      "(modal-backdrop tiada)")
                return
            if self.close_popup_by_icon(timeout=2):
                time.sleep(1)
                continue
            print("  [PELARASAN] No close icon -- pressing device Back...")
            self.press_back()
            time.sleep(1)

        self.dismiss_native_alerts(first_timeout=2, context="late sync alert")
        if self._popup_menu_selaras_hilang():
            print("  [PELARASAN] popup MENU SELARAS DISAHKAN hilang "
                  "(modal-backdrop tiada)")
            return

        dump_path = "debug_menu_selaras_close.xml"
        try:
            with open(dump_path, "w", encoding="utf-8") as f:
                f.write(self.driver.page_source)
            print(f"  [PELARASAN] DEBUG: login screen still not visible -- "
                  f"page source dumped to {dump_path}")
        except Exception:
            pass

        print("  [PELARASAN] Falling back to app relaunch (Pelarasan "
              "settings are persisted, nothing is lost)...")
        self.ensure_on_login_screen()

    # ========================================================================
    # Full orchestration
    # ========================================================================

    def run_full_pelarasan(self, internal_ip, external_ip, lesen_aplikasi):
        """DILUMPUHKAN untuk MBPG — melempar, tidak menjalankan apa-apa.

        Kaedah ini ialah laluan "jalankan semua sekali gus". Ia TIADA
        pemanggil dalam projek ini (disemak: hanya rujukan prosa), tetapi
        kod mati yang boleh dipanggil dan melakukan perkara berbahaya
        ialah perangkap yang menunggu — seseorang menjumpainya, ia
        kelihatan seperti "cara betul untuk mulakan", dan ia:

          * memanggil set_tetapan_alamat_ip() dan set_tetapan_pelbagai(),
            kedua-duanya menekan SIMPAN, TANPA langkah restore yang
            dituntut pemilik untuk T-002/T-010; dan
          * menjalankan urutan selaras sebagai satu blok — tepat corak
            "selaras-semua" yang pemilik arahkan supaya JANGAN digunakan
            (2026-08-07), kerana satu blok begitu ialah cara paling mudah
            untuk tersilap mencetuskan Selaras Pelesen (3-4 JAM).

        Urutan MBPG dipandu satu-satu daripada tests/conftest.py
        (fixture `pelarasan_results`), dengan Pelesen dikeluarkan
        sepenuhnya daripada senarai langkah.
        """
        raise NotImplementedError(
            "run_full_pelarasan() dilumpuhkan untuk MBPG. Arahan pemilik "
            "2026-08-07: jangan guna laluan 'selaras semua' — tekan modul "
            "yang dibenarkan SATU PER SATU. Gunakan fixture "
            "pelarasan_results dalam tests/conftest.py, yang mengeluarkan "
            "Selaras Maklumat Pelesen (sync 3-4 jam) daripada senarai "
            "langkah dan tidak menekan SIMPAN tanpa restore.")

"""
Daftar Kompaun (Register Compound) page — Page Object Model.
Flow: Select jenis (popup) -> Tab Pesalah -> Tab Kompaun -> Tab Penerima ->
Confirmation -> Submit

Rebuilt from the user's step-by-step manual. Note: Penerima tab here uses
"No Pembantu Penguatkuasa" instead of Notis Amaran's "Arahan Tindakan".

PORT MBJB
---------
Struktur borang dikekalkan bulat-bulat -- MBIP dan MBJB menjalankan APK
yang sama (com.anonymous.react_ies_v1), cuma 16 keluaran berbeza (2.1.17
lawan 2.1.33). Yang ditambah di sini ialah kawalan yang muncul dalam
jurang itu dan tidak pernah wujud dalam MBIP:

  toggle_operasi()                    Training Feedback A7 (DONE 2.1.5)
  tick_alamat_premis_sama()           Training Feedback A10 (DONE 16/07/25)
  fill_no_cukai_jalan/petak/kupon()   Excel MBPG-TC-K-001 C10 langkah 2
  verify_kereta_fields_cleared()      Excel MBPG-TC-K-001 C11
  select_jenis_kompaun_letak_kereta() Dev List: "KOMPAUN LETAK KERETA"

Semua kaedah baharu di atas membawa tanda SAHKAN-DEVICE: locatornya ialah
tekaan-terbaik daripada dokumen, BUKAN daripada dump UI MBJB. Tiada satu
pun daripadanya mengandaikan kejayaan senyap -- setiap satu memulangkan
False/None yang boleh dilaporkan bila kawalan tidak dijumpai.

Nota gambar (Dev List baris 73, APK 2.1.28, DONE): Kompaun Letak Kereta
MBJB menjadikan 3 keping gambar MANDATORI. take_photos() sudah lalai
count=3, jadi tiada perubahan kod diperlukan -- tetapi TC K-001 mesti
memanggilnya tanpa mengurangkan count.
"""

from appium.webdriver.common.appiumby import AppiumBy
import re
import xml.etree.ElementTree as _ET

from selenium.common.exceptions import (TimeoutException,
                                        StaleElementReferenceException)
from pages.base_page import BasePage


def _kotak(bounds):
    m = re.match(r"\[(-?\d+),(-?\d+)\]\[(-?\d+),(-?\d+)\]", bounds or "")
    return tuple(map(int, m.groups())) if m else None


def cari_mysikap_dari_xml(sumber_halaman, toleransi_y=80):
    """(x, y) tengah butang MySIKAP, atau None. FUNGSI TULEN.

    Dipisahkan daripada driver supaya ia boleh diuji terhadap dump
    device SEBENAR tanpa peranti — lihat
    tests_offline/test_mysikap_locator.py, yang menjalankannya ke atas
    setiap dump borang Letak Kereta dalam repo.

    MySIKAP ialah elemen BERASINGAN daripada ePBT, bukan sandaran dan
    bukan aliasnya. Ia tidak membawa text, content-desc, mahupun
    resource-id, jadi ia dikenal pasti mengikut STRUKTUR dan KEDUDUKAN
    RELATIF kepada ePBT. Setiap syarat WAJIB:

        - kelas ViewGroup
        - clickable=true
        - mengandungi anak ImageView
        - pusat-y dalam +-toleransi_y daripada pusat-y ePBT
        - tepi KIRInya berada pada atau selepas tepi KANAN ePBT

    ePBT sendiri mesti dijumpai dahulu. Tiada sandaran "kalau ePBT
    tiada, ambil ImageView pertama" — cabang itulah yang membuat versi
    lama boleh memulangkan kawalan sewenang-wenangnya, dan pada borang
    ini kesilapan itu bermakna menekan ePBT (pemilik: ePBT MEMADAM
    data).

    Padanan yang bukan TEPAT SATU memulangkan None. Meneka di sini
    tidak mempunyai hasil yang selamat.
    """
    try:
        akar = _ET.fromstring(sumber_halaman)
    except Exception:                                        # noqa: BLE001
        return None

    epbt = None
    calon = []
    for n in akar.iter():
        k = _kotak(n.get("bounds"))
        if not k:
            continue
        kelas = (n.get("class") or "").split(".")[-1]
        nama = f"{n.get('text') or ''} {n.get('content-desc') or ''}"
        if kelas == "Button" and "epbt" in nama.lower():
            epbt = k
        elif (kelas == "ViewGroup"
              and (n.get("clickable") or "").lower() == "true"
              and any((c.get("class") or "").endswith("ImageView")
                      for c in n.iter())):
            calon.append(k)

    if epbt is None:
        return None

    ey = (epbt[1] + epbt[3]) // 2
    padan = [k for k in calon
             if abs((k[1] + k[3]) // 2 - ey) < toleransi_y and k[0] >= epbt[2]]
    if len(padan) != 1:
        return None
    k = padan[0]
    return (k[0] + k[2]) // 2, (k[1] + k[3]) // 2


# ======================================================================
# B-1 — KEJAYAAN CREATE DISAHKAN DARI **TEKS ALERT**, BUKAN DARIPADA
#       KETIADAAN BUTANG.
# ======================================================================
# Punca B-1 (recon\qa_findings.md B1/S3, PAPAN.md "ADJUDIKASI QA"):
# `dismiss_native_alerts()` dahulu MENELAN teks alert — nilai pulangannya
# hanya bool. Setiap laluan create yang memanggilnya lalu menyimpulkan
# kejayaan daripada "butang MENYERAHKAN hilang" mengisytiharkan LULUS ke
# atas alert "TIDAK BERJAYA". Itu PASS palsu.
#
# >>> KEMAS STRUKTUR 2026-07-30. <<< makmingg siput sudah membina helper
# yang betul dalam `base_page.py`, jadi pembacaan alert ad-hoc yang
# ditulis di sini SEBELUM helper wujud SUDAH DIBUANG. Satu sumber
# kebenaran, bukan empat salinan:
#     BasePage.NATIVE_ALERT_TITLE            (locator tunggal; pendua
#                                             `ALERT_TAJUK` di sini DIBUANG)
#     BasePage.read_native_alert_text(...)   -> str, TIDAK menolak
#     BasePage.dismiss_native_alerts(..., kumpul=True) -> list[str]
# Ini menutup qa_findings S3 pada STRUKTURNYA, bukan sekadar gejalanya.
#
# `adili_alert_hantar()` di bawah kekal kerana ia lapisan KEPUTUSAN
# (bukti -> tiga-keadaan Peraturan #7), bukan lapisan pembacaan. Ia:
#   1. membaca teks melalui `read_native_alert_text()` — alert dibiarkan
#      TERBUKA supaya ia boleh diperiksa dahulu;
#   2. menyemak PENAFIAN DAHULU melalui `BasePage.BERJAYA_DINAFI` yang
#      sedia ada — "TIDAK BERJAYA" mengandungi "BERJAYA" sebagai
#      subrentetan, jadi susunan kegagalan-dahulu WAJIB. Toleransi ejaan
#      `ber?jaya` (base_page.py:370-375, bug app `BEJAYA`) datang percuma
#      kerana locator itu yang diguna semula — TIDAK ditulis semula;
#   3. mencuba `read_record_number()` SEMASA alert masih terpapar, kerana
#      di situlah nombor rekod muncul kalau app melaporkannya;
#   4. barulah menolak — dengan `kumpul=True`, supaya teks SETIAP alert
#      beratur masuk ke dalam log dan mesej kegagalan.
#
# Ia TIDAK memutuskan LULUS/GAGAL sendiri — ia memulangkan bukti mentah
# supaya setiap pemanggil boleh mengekalkan pembezaan tiga-keadaan
# Peraturan Keras #7: (a) create GAGAL · (b) jadi + nombor TERBACA ·
# (c) jadi + nombor TIDAK terbaca.
#
# Ini fungsi aras-modul (bukan kaedah) dengan sengaja: NotisAmaranPage dan
# NotisKompaunPage mewarisi BasePage secara LANGSUNG, bukan
# DaftarKompaunPage, jadi kaedah di sini tidak akan sampai kepada mereka.


def adili_alert_hantar(page, context, first_timeout=20, tolak_timeout=3):
    """Baca, adili, kemudian tolak alert keputusan selepas HANTAR.

    Pulang dict bukti (TIADA keputusan LULUS/GAGAL dibuat di sini):

        ada_alert : alert asli memang muncul
        teks      : tajuk+mesej SEBENAR SEMUA alert beratur, digabung
                    dengan ' // ' (untuk mesej kegagalan & laporan)
        ditolak   : PENAFIAN kelihatan ("TIDAK BERJAYA"/"TIDAK BEJAYA")
        disahkan  : mesej kejayaan kelihatan DAN tiada penafian
        nombor    : nombor rekod yang terbaca, atau None

    `ditolak` disemak DAHULU dan `disahkan` hanya dinilai bila tiada
    penafian — kedua-duanya melalui locator base_page yang sedia ada,
    jadi toleransi ejaan `ber?jaya` dan sempadan perkataan `\\btak\\b`
    (yang menghalang "CETAK BERJAYA" dibaca sebagai penafian) dikekalkan
    tanpa satu baris regex baharu.

    >>> AWAS, seperti yang docstring `read_native_alert_text()` arahkan:
    `teks` di sini adalah untuk MANUSIA membacanya, BUKAN untuk
    diklasifikasi. JANGAN sekali-kali tulis `"BERJAYA" in v["teks"]` —
    ia benar untuk "TIDAK BERJAYA". Gunakan `ditolak` / `disahkan`, yang
    datang daripada lapisan kegagalan-dahulu. <<<

    HAD YANG DIAKUI: `ditolak`/`disahkan` dinilai pada alert yang
    TERPAPAR ketika itu — iaitu alert keputusan submit. Alert asli app ini
    BERATUR; teks alert kemudian DIKUMPUL (`kumpul=True`) dan masuk ke
    dalam `teks`, tetapi tidak diadili secara berasingan. Mengadilinya
    bermakna menulis pengelas rentetan KEDUA dalam Python, dan dua
    pengelas untuk satu keputusan ialah cara susunan kegagalan-dahulu
    pecah tanpa disedari."""
    import time
    teks_awal = page.read_native_alert_text(first_timeout=first_timeout)
    ada_alert = bool(teks_awal) or page.is_element_present(
        page.NATIVE_ALERT_OK, timeout=1)
    if teks_awal:
        print(f"  [ALERT-ADILI] {context}: teks alert = {teks_awal!r}")
    else:
        print(f"  [ALERT-ADILI] {context}: TIADA teks alert dibaca "
              f"(ada_alert={ada_alert})")

    # >>> PENAFIAN DAHULU. Jangan tukar susunan ini. <<<
    ditolak = page.is_element_present(page.BERJAYA_DINAFI, timeout=3)
    disahkan = (not ditolak
                and page.is_berjaya_message_visible(timeout=2,
                                                    context=context))

    # Nombor rekod dibaca SEMASA alert masih ada: kalau app melaporkannya,
    # di situlah ia. Direset dahulu supaya nombor BASI daripada create
    # terdahulu tidak boleh menyamar sebagai nombor create ini
    # (Peraturan Keras #7 — lejar mesti memegang nombor run INI).
    page.last_record_number = None
    nombor = page.read_record_number()

    semua = [teks_awal] if teks_awal else []
    if ada_alert:
        # kumpul=True: teks SETIAP alert beratur, bukan sekadar "ada".
        for t in page.dismiss_native_alerts(first_timeout=tolak_timeout,
                                            context=context, kumpul=True):
            if t and t not in semua:
                semua.append(t)
        time.sleep(0.5)
    return {"ada_alert": ada_alert, "teks": " // ".join(semua),
            "ditolak": ditolak, "disahkan": disahkan, "nombor": nombor}


def sebab_gagal_senyap(context, bukti, teks_alert):
    """Mesej kegagalan untuk keadaan (a): borang ditutup TETAPI tiada teks
    kejayaan dan tiada nombor rekod.

    Mesej ini wujud khusus untuk menghalang salah-diagnosis yang B-1
    hasilkan: dahulu keadaan ini dilaporkan sebagai keadaan (c) "create
    BERFUNGSI, semak record_prefix" dan menghantar Loh memburu awalan yang
    tidak bersalah."""
    return (
        f">>> CREATE GAGAL (keadaan (a)) — {context} <<< "
        f"Borang ditutup tetapi TIADA bukti kejayaan: teks alert = "
        f"{teks_alert!r}, dan read_record_number() tidak menjumpai nombor "
        f"rekod pada skrin ini. {bukti} "
        f"KETIADAAN BUTANG BUKAN BUKTI KEJAYAAN — borang juga ditutup "
        f"apabila server MENOLAK penghantaran (DEV FIXING LIST baris 66, "
        f"'Kompaun tak berjaya hantar ke ePBT'). "
        f"INI BUKAN masalah `record_prefix`: keadaan (c) hanya boleh "
        f"diisytihar apabila kejayaan DISAHKAN dahulu. Rujuk dump di "
        f"ui_dumps\\ dan teks alert di atas.")


class DaftarKompaunPage(BasePage):
    """Daftar Kompaun screen — jenis selection + 3-tab form."""

    # ---- Jenis Kompaun selection popup (appears right after opening menu) ----
    # Confirmed via live dump (recon 2026-07-15): the popup is titled
    # "PILIH KOMPAUN" and lists KOMPAUN PELBAGAI / KOMPAUN TRAFIK /
    # KOMPAUN LESEN / SITAAN (all caps).
    # >>> HURUF BESAR DIPAKSA APP. <<< textContains/text() PEKA huruf, dan
    # setiap teks yang Loh baca dari device adalah HURUF BESAR sepenuhnya
    # (reports\fasa2-bootstrap.md §2.4 "APP MEMAKSA HURUF BESAR"). Frasa
    # Title Case 'Kompaun Pelbagai' TIDAK akan padan. Ditukar kepada
    # textMatches tidak sensitif huruf -- padanan yang SAMA dituntut, cuma
    # tidak lagi peka huruf (Peraturan #2 tidak dilanggar).
    OPTION_KOMPAUN_PELBAGAI = (AppiumBy.ANDROID_UIAUTOMATOR,
                               'new UiSelector().textMatches('
                               '"(?i)(?s).*kompaun\\s*pelbagai.*")')
    OPTION_KOMPAUN_TRAFIK = (AppiumBy.ANDROID_UIAUTOMATOR,
                             'new UiSelector().textMatches('
                             '"(?i)^\\s*kompaun\\s+trafik\\s*$")')
    # MBJB: DEV FIXING LIST + Excel bercakap tentang "Kompaun Letak
    # Kereta", bukan "Kompaun Trafik" (cth MBPG-TC-K-005 C9 "KOMPAUN
    # LETAK KERETA PRESSGO" / "KOMPAUN LETAK KERETA MBJB"). Nama pilihan
    # pada popup PILIH KOMPAUN mungkin berbeza daripada MBIP.
    # SAHKAN-DEVICE: locator ini disalin/diteka daripada MBIP, belum
    # disahkan pada MBJB. Dump popup PILIH KOMPAUN dan baca teks sebenar.
    OPTION_KOMPAUN_LETAK_KERETA = (
        AppiumBy.ANDROID_UIAUTOMATOR,
        'new UiSelector().textMatches("(?i)^KOMPAUN\\s+LETAK\\s+KERETA$")')

    # ---- Screen title (after jenis selected) ----
    # Tidak sensitif huruf, sebab yang sama seperti di atas.
    SCREEN_TITLE = (AppiumBy.ANDROID_UIAUTOMATOR,
                    'new UiSelector().textMatches("(?i)(?s).*pelbagai.*")')
    # MBPG menamakan modul ini "Letak Kereta"; MBIP memanggilnya
    # "Trafik". Bukti ketibaan mesti menerima KEDUA-DUANYA, kalau tidak
    # ia tidak akan pernah padan pada MBPG — diperhati langsung
    # 2026-08-10: "screen didn't open after tap on 'KOMPAUN LETAK
    # KERETA'" sedangkan skrin itu memang terbuka.
    TRAFIK_SCREEN_TITLE = (AppiumBy.ANDROID_UIAUTOMATOR,
                           'new UiSelector().textMatches('
                           '"(?i)(?s).*(trafik|letak\\s*kereta).*")')

    # ---- Kompaun Trafik: Pesalah tab (all confirmed via live recon
    # dumps, 2026-07-15) ----
    # Field placeholders/hints on this tab: NAMA PESALAH, NO K/P/SSM,
    # NO. KERETA, NO. CUKAI JALAN, JENIS KERETA, WARNA KERETA,
    # NO. PETAK, NO. KUPON. Below NO. KERETA sit two lookup buttons
    # side by side: an "ePBT" Button and an image-only clickable
    # ViewGroup wrapping the screen's sole ImageView -- that image IS
    # the MySIKAP lookup. A successful MySIKAP lookup populates NAMA
    # PESALAH + NO K/P/SSM and INSERTS a populated MAKLUMAT JALAN/
    # TAMAN/POSKOD/BANDAR/NEGERI block into the form (those address
    # fields don't exist in the layout before the lookup), pushing the
    # manual vehicle fields further down. The ePBT button must NOT be
    # tapped after MySIKAP: confirmed live that it wipes the populated
    # name/IC and even the typed plate.
    LABEL_TRAFIK_NO_KERETA = "NO. KERETA"
    LABEL_TRAFIK_WARNA_KERETA = "WARNA KERETA"

    # ---- MySIKAP: ELEMEN BERASINGAN, BUKAN ALIAS/SANDARAN ePBT ----
    #
    # >>> DIBETULKAN 2026-08-17 atas arahan pemilik. <<<
    # Locator lama ialah `ImageView.instance(0)` — ImageView PERTAMA
    # pada seluruh skrin. Ia berfungsi hari ini hanya kerana borang ini
    # kebetulan mempunyai TEPAT SATU ImageView (disahkan pada 4 dump
    # berasingan). Ia tidak menyauh apa-apa: tambah satu ikon di mana
    # sahaja pada skrin, atau jalankan ia selepas lookup mengubah susun
    # atur, dan ia memulangkan kawalan yang berlainan sambil melaporkan
    # "MySIKAP". Pada borang ini kesilapan itu bermakna menekan ePBT —
    # yang pemilik amarkan MEMADAM data.
    #
    # Recon device 2026-08-17 (docs/recon/DAPATAN-MYSIKAP.md, dump
    # docs/recon/mysikap-B-tab-pesalah.xml) — dua kawalan berkongsi satu
    # baris, ePBT di KIRI dan MySIKAP di KANAN:
    #
    #   ViewGroup  klik=false [105,1212][525,1332]  rid='button-container'
    #     Button   klik=true  [141,1212][489,1332]  desc='ePBT' rid='button'
    #       TextView klik=false [256,1242][374,1302] text='ePBT'
    #   ViewGroup  klik=true  [555,1212][975,1332]  <- MySIKAP
    #     ImageView klik=false [585,1230][945,1314]
    #
    # MySIKAP tidak membawa text, content-desc, MAHUPUN resource-id —
    # ia dirender sebagai logo. Maka tiada locator ikut nama yang
    # mungkin, dan ia mesti dikenal pasti secara STRUKTUR. Lihat
    # `cari_mysikap()` di bawah: setiap syarat wajib, dan padanan yang
    # bukan TEPAT SATU memulangkan None dan bukan tekaan.
    #
    # ePBT dikekalkan sebagai locator BERASINGAN semata-mata supaya
    # kod boleh mengelakkannya secara eksplisit. Ia TIDAK PERNAH
    # dipulangkan oleh mana-mana laluan MySIKAP.
    BUTTON_EPBT = (AppiumBy.ANDROID_UIAUTOMATOR,
                   'new UiSelector().className("android.widget.Button")'
                   '.descriptionMatches("(?i)\\s*ePBT\\s*")')
    # Toleransi baris-y (px). Kedua-dua kawalan berkongsi bounds-y yang
    # SAMA TEPAT pada device; 80 memberi ruang untuk beza penjajaran
    # tanpa menjangkau kawalan seterusnya (No. Cukai Jalan bermula pada
    # y=1377, iaitu 105px di bawah).
    MYSIKAP_TOLERANSI_Y = 80
    FIELD_TRAFIK_NAMA_PESALAH = (AppiumBy.XPATH,
                                 '//android.widget.EditText[@hint="NAMA PESALAH"]')

    # ---- Kompaun Trafik: Kompaun tab quirks (confirmed via adb dumps
    # of the live form, 2026-07-15) ----
    # The tempoh field is PRE-FILLED with "21" on this form, so its
    # "MAKLUMAT KOMPAUN" placeholder never shows -- a label-text lookup
    # matches the section-header TextView instead, and the typed value
    # then lands in whatever field still has focus (observed live:
    # butiran ended up as "PANDU KERETA LAJU0"). Locate the EditText
    # positionally, as the header's next sibling.
    FIELD_TRAFIK_TEMPOH = (AppiumBy.XPATH,
                           '//android.widget.TextView[@text="MAKLUMAT KOMPAUN"]'
                           '/following-sibling::android.widget.EditText[1]')
    # Tier 1 (Keterangan Kod Kompaun) is PRE-SELECTED on the Trafik
    # form: the field already holds "PERINTAH LALULINTAS JALAN
    # (PERINTAH 39 )" (sic -- note the space before the paren) and no
    # "PILIH KOMPAUN" placeholder exists anywhere on the screen.
    # NOTA MBJB: locator ini TIDAK LAGI DIGUNAKAN. Ia mengandaikan tingkat 1
    # ialah EditText yang pra-isi 'PERINTAH 39' (fakta MBIP). Pada MBJB
    # tingkat 1 ialah android.widget.Spinner (ui_dumps\51_notis_skrol.xml)
    # dan Excel MBPG-TC-K-005 C9 membekalkan nilai tingkat 1 sendiri.
    # Dikekalkan sebagai rekod sahaja — JANGAN pulangkan sebagai assert.
    TRAFIK_TIER1_PRESELECTED = (AppiumBy.ANDROID_UIAUTOMATOR,
                                'new UiSelector().className("android.widget.EditText")'
                                '.textMatches("(?i).*PERINTAH\s+39.*")')

    # ---- Tabs ----
    TAB_PESALAH = (AppiumBy.ANDROID_UIAUTOMATOR,
                         'new UiSelector().descriptionMatches("(?i)\s*PESALAH\s*")')
    TAB_KOMPAUN = (AppiumBy.ANDROID_UIAUTOMATOR,
                         'new UiSelector().descriptionMatches("(?i)\s*KOMPAUN\s*")')
    TAB_PENERIMA = (AppiumBy.ANDROID_UIAUTOMATOR,
                         'new UiSelector().descriptionMatches("(?i)\s*PENERIMA\s*")')

    # ---- Pesalah tab field labels ----
    LABEL_NAMA_PESALAH = "NAMA PESALAH"
    LABEL_NO_KP_SSM_KERETA = "NO KP/ SSM/ NO KERETA"
    LABEL_PESALAH_JALAN = "MAKLUMAT JALAN"
    LABEL_PESALAH_TAMAN = "MAKLUMAT TAMAN"
    LABEL_PESALAH_POSKOD = "MAKLUMAT POSKOD"
    LABEL_PESALAH_BANDAR = "MAKLUMAT BANDAR"
    LABEL_PESALAH_NEGERI = "MAKLUMAT NEGERI"

    # ---- Kompaun tab field labels ----
    LABEL_KOMPAUN_JALAN = "Maklumat Jalan"
    LABEL_KOMPAUN_TAMAN = "Maklumat Taman"
    LABEL_KOMPAUN_POSKOD = "Maklumat Poskod"
    LABEL_KOMPAUN_BANDAR = "Maklumat Bandar"
    LABEL_KOMPAUN_NEGERI = "Maklumat Negeri"
    LABEL_LOKASI_KESALAHAN = "LOKASI KESALAHAN"
    LABEL_BUTIRAN_KESALAHAN = "BUTIRAN KESALAHAN"
    LABEL_TEMPOH_NOTIS = "MAKLUMAT KOMPAUN"

    # ---- Kompaun code dropdowns — TIGA TINGKAT, semuanya Spinner ---------
    #
    # >>> KECACATAN DISAHKAN & DIBETULKAN (Loh, 2026-07-30). <<<
    # Kod lama menunggu teks 'PILIH KOMPAUN' / 'PILIH AKTA' /
    # 'PILIH KESALAHAN' untuk mengetuk dan membuka dropdown. Loh sudah
    # menyemak SETIAP dump device: KETIGA-TIGA rentetan itu TIDAK WUJUD
    # dalam mana-mana dump (`grep` pada ui_dumps\*.xml = 0 padanan).
    # Satu-satunya teks 'PILIH ...' yang benar-benar ada pada device ialah
    # 'PILIH JALAN | TAMAN' (ui_dumps\43_pilih_jalan_senarai.xml) dan itu
    # autocomplete ALAMAT — benda lain sama sekali. Locator lama tidak
    # pernah boleh membuka satu pun daripada tiga dropdown ini.
    #
    # STRUKTUR SEBENAR pada tab NOTIS (ui_dumps\51_notis_skrol.xml nod
    # index 14-19; sama dalam 53_notis_skrol2.xml):
    #   TextView 'KETERANGAN KOD KOMPAUN *'  [107,880][974,945]
    #   Spinner                              [107,945][974,1196]
    #        \_ TextView android:id/text1 = 'AKTA JALAN PARIT & BANGUNAN &
    #           AKTA KERAJAAN TEMPATAN'      <- tingkat 1 SUDAH ada nilai LALAI
    #   TextView 'KOD AKTA *'                [107,1226][974,1291]
    #   Spinner NAF=true                     [107,1315][974,1465]  TIADA anak
    #   TextView 'KESALAHAN KOMPAUN *'       [107,1495][974,1560]
    #   Spinner NAF=true                     [107,1560][974,1710]  TIADA anak
    #
    # Fakta yang menentukan reka bentuk di bawah:
    #  * Tingkat 1 sudah berisi nilai lalai => ia TIDAK PERNAH memaparkan
    #    'PILIH KOMPAUN'. 'PILIH KOMPAUN' wujud hanya sebagai satu OPSYEN
    #    DI DALAM dialog (ui_dumps\kesalahan_tier1_PENUH_v2.txt:29, baris
    #    terakhir senarai 29 nilai), bukan sebagai label Spinner.
    #  * Tingkat 2 dan 3 tiada anak `android:id/text1` SAMA SEKALI => ia
    #    benar-benar kosong, bukan cuma "belum dipilih". Tiada teks untuk
    #    dipadan, jadi Spinner MESTI dikenal pasti melalui LABEL TextView
    #    yang mendahuluinya (_spinner_bawah_label), bukan ikut teks dan
    #    bukan ikut koordinat keras (Peraturan #3).
    #  * Membuka dropdown = tap Spinner ITU SENDIRI; dialog muncul dengan
    #    resource-id '<pakej>:id/select_dialog_listview' dan satu
    #    CheckedTextView per pilihan — corak yang SAMA seperti autocomplete
    #    jalan (ui_dumps\43_pilih_jalan_senarai.xml).
    #
    # SYAK: belum disahkan selepas skrol penuh. Dakwaan "TIDAK WUJUD dalam
    # mana-mana dump" (baris 281 atas) dan "TIADA anak SAMA SEKALI" bagi
    # tingkat 2/3 (baris 295-297, 304-305) dibuat 2026-07-30, SEBELUM
    # penemuan 2026-07-31 bahawa `uiautomator dump` MEMBUANG nod
    # `visible:false` (recon\PAPAN.md blok "MULA DI SINI"). Spinner
    # tingkat 3 di sini menjulur ke y=1710, melepasi sempadan viewport
    # boleh-skrol y~1596 yang disahkan kemudian -- jadi grep pada dump
    # yang diambil TANPA skrol ke hujung bawah Spinner itu boleh sahaja
    # terlepas anak `android:id/text1` yang wujud tetapi di bawah lipatan.
    # Mekanisme label-driven (_spinner_bawah_label) yang menggantikan
    # locator placeholder-text KEKAL BETUL tanpa mengira jawapannya (ia
    # tidak bergantung pada teks Spinner langsung), jadi ini TIDAK
    # menjejaskan pembetulan yang sudah dibuat -- ia menandakan sahaja
    # bahawa dakwaan "kosong/tiada" yang mendasarinya belum disahkan
    # selepas skrol penuh.
    SPINNER_KELAS = "android.widget.Spinner"
    SPINNER_TEXT1 = (AppiumBy.XPATH,
                     '//android.widget.Spinner/*'
                     '[@resource-id="android:id/text1"]')
    # Label pengenal setiap tingkat. Tidak sensitif huruf, dan `(?s).*...*`
    # supaya penanda wajib ' *' pada hujung label tidak memecahkan padanan
    # ('KOD AKTA *' dalam dump).
    LABEL_TIER1 = (AppiumBy.ANDROID_UIAUTOMATOR,
                   'new UiSelector().textMatches('
                   '"(?i)(?s).*keterangan\\s*kod\\s*kompaun.*")')
    LABEL_TIER2 = (AppiumBy.ANDROID_UIAUTOMATOR,
                   'new UiSelector().textMatches("(?i)(?s).*kod\\s*akta.*")')
    LABEL_TIER3 = (AppiumBy.ANDROID_UIAUTOMATOR,
                   'new UiSelector().textMatches('
                   '"(?i)(?s).*kesalahan\\s*kompaun.*")')
    # Dialog pilihan. resourceIdMatches, BUKAN nama pakej yang dihardcode:
    # pakej datang dari profil (config.APP_PACKAGE) — Peraturan #3.
    DIALOG_SENARAI = (AppiumBy.ANDROID_UIAUTOMATOR,
                      'new UiSelector().resourceIdMatches('
                      '".*:id/select_dialog_listview")')
    DIALOG_BARIS = (AppiumBy.ANDROID_UIAUTOMATOR,
                    'new UiSelector().className('
                    '"android.widget.CheckedTextView")')

    # ---- Kadar Denda (amount) ----
    # Confirmed via live page-source dump (run 17, captured right after
    # the Kesalahan tier): despite the real test script listing this
    # alongside the dropdown tiers, "PILIH KADAR DENDA (RM):" is a
    # plain non-clickable TextView LABEL -- the actual input is the
    # numeric EditText directly under it (hint "ENTER AMAUN", preset to
    # "0", with MIN:/MAX: range hints tied to the picked Kesalahan).
    # Located via its hint (exact from the dump) -- UiSelector can't
    # match hints, XPath can.
    FIELD_KADAR_DENDA = (AppiumBy.XPATH,
                         '//android.widget.EditText[@hint="ENTER AMAUN"]')

    # ---- Camera ----
    BUTTON_OPEN_CAMERA = (AppiumBy.ANDROID_UIAUTOMATOR,
                          'new UiSelector().textMatches("(?i)\s*OPEN\s+CAMERA\s*")')
    # Confirmed via live UI dump: these are icon-font glyphs, not the
    # literal words "Snap"/"Tick" -- same convention as HAMBURGER in
    # base_page.py.  is the round shutter button,  is the
    # checkmark/confirm button.
    BUTTON_SNAP = (AppiumBy.ACCESSIBILITY_ID, "")
    BUTTON_TICK_CONFIRM = (AppiumBy.ACCESSIBILITY_ID, "")

    # ---- Penerima tab field labels ----
    LABEL_NO_PEMBANTU_PENGUATKUASA = "NO PEMBANTU PENGUATKUASA"
    LABEL_NAMA_PENERIMA = "NAMA PENERIMA"
    LABEL_NO_IC_PENERIMA = "NO IC PENERIMA"
    FIELD_OPEN_SIGNATURE = (AppiumBy.ANDROID_UIAUTOMATOR,
                            'new UiSelector().textMatches("(?i)\s*OPEN\s+SIGNATURE\s*")')

    # ---- Confirmation / result popups ----
    # >>> DIBETULKAN: textContains PEKA huruf dan app MEMAKSA HURUF BESAR
    # pada teks dialog (setiap mesej yang Loh baca dari device adalah huruf
    # besar sepenuhnya: 'BEJAYA', 'LESEN SAMA.', 'MAKLUMAT TIDAK LENGKAP').
    # Frasa Title Case di bawah TIDAK akan padan, jadi kedua-dua popup ini
    # tidak pernah dapat dikesan dan is_submission_successful() akan
    # sentiasa melaporkan WARNING. <<<
    # SAHKAN-DEVICE: teks TEPAT kedua-dua dialog belum dilihat pada MBJB —
    # tiada satu pun rekod pernah dicipta (PAPAN.md §4).
    POPUP_SIMPAN_MAKLUMAT = (AppiumBy.ANDROID_UIAUTOMATOR,
                             'new UiSelector().textMatches('
                             '"(?i)(?s).*simpan\\s*maklumat.*")')
    POPUP_CETAK_KOMPAUN_PELBAGAI = (AppiumBy.ANDROID_UIAUTOMATOR,
                                    'new UiSelector().textMatches('
                                    '"(?i)(?s).*cetak\\s*kompaun\\s*'
                                    'pelbagai.*")')

    # ========================================================================
    # Actions
    # ========================================================================

    def select_jenis_kompaun(self, jenis="Kompaun Pelbagai"):
        """Select the jenis kompaun from the popup shown right after
        opening the Daftar Kompaun menu."""
        print(f"\n  [DAFTAR KOMPAUN] Selecting jenis: {jenis}...")
        self.wait_and_click(self.OPTION_KOMPAUN_PELBAGAI)
        print("  [DAFTAR KOMPAUN] Jenis selected — PASS")

    def is_daftar_kompaun_screen_displayed(self):
        """Verify we are on the Daftar Kompaun (Pelbagai) screen."""
        return self.is_element_present(self.SCREEN_TITLE, timeout=10)

    # ---- Kompaun Trafik variant ----

    def select_jenis_kompaun_trafik(self):
        """Select KOMPAUN TRAFIK from the jenis popup, verifying the
        Trafik screen actually opened (raw tap + one retry -- same
        silent-no-op-tap protection as everywhere else)."""
        print("\n  [DAFTAR KOMPAUN] Selecting jenis: Kompaun Trafik...")
        self.wait_and_tap(self.OPTION_KOMPAUN_TRAFIK)
        if self.is_element_present(self.TRAFIK_SCREEN_TITLE, timeout=5):
            print("  [DAFTAR KOMPAUN] Jenis Trafik selected — PASS")
            return
        print("  [DAFTAR KOMPAUN] Trafik screen didn't open -- re-tapping...")
        self.wait_and_tap(self.OPTION_KOMPAUN_TRAFIK)
        assert self.is_element_present(self.TRAFIK_SCREEN_TITLE, timeout=10), \
            "FAIL: Kompaun Trafik screen did not open from the jenis popup"
        print("  [DAFTAR KOMPAUN] Jenis Trafik selected — PASS")

    def is_daftar_kompaun_trafik_screen_displayed(self):
        """Verify we are on the Daftar Kompaun (Trafik) screen."""
        return self.is_element_present(self.TRAFIK_SCREEN_TITLE, timeout=10)

    def gulung_borang_ke_atas(self, maks=10):
        """Gulung ScrollView borang kembali ke PERMULAAN.

        >>> SATU DARIPADA DUA PEMBETULAN — diukur 2026-08-17. <<<
        Autocomplete 'Maklumat Jalan' pada tab ini menggerakkan borang
        ke bawah. Menjelang LOKASI/BUTIRAN KESALAHAN dicari, kedua-duanya
        sudah keluar dari ATAS skrin, dan `find_element` hanya menatal
        ke BAWAH — arah yang bertentangan.

        >>> KENAPA PROBE SATU-MEDAN TERSALAH MENAFIKAN INI. <<<
        `devtools/probe_lokasi.py` melaporkan medan berada pada
        `[107,1452][977,1602]` dan TIDAK PERNAH bergerak, dan kaedah ini
        pulang True sambil mencatat `skrin BERGERAK? TIDAK`. Saya
        menyimpulkan ia menyelesaikan masalah yang tidak wujud, lalu
        membuangnya — dan larian berikutnya kembali melontar
        TimeoutException.

        Sebabnya: probe itu TIDAK mengisi medan alamat, jadi borangnya
        tidak pernah bergerak. Keadaan probe bukan keadaan pengeluaran.
        Pengajaran yang dikodkan: probe yang tidak menghasilkan semula
        prasyarat sebenar boleh MENAFIKAN punca yang betul dengan
        yakin.

        Pembetulan KEDUA (dan berasingan) ialah `keep_keyboard=True` —
        `hide_keyboard()` bertindak sebagai Back dan membuang nilai yang
        baru ditaip. Lihat notanya dalam `fill_kompaun_tab`. Kedua-dua
        pembetulan diperlukan; membuang mana-mana satu memulangkan
        kegagalan, dalam bentuk yang BERBEZA.

        Satu dapatan sampingan yang layak disimpan: `base_page.py:3006`
        mencatat "scrolling the page destroys form progress" dan
        menggunakan `.instance(1)`. Nota itu dirakam dengan MODAL
        DROPDOWN TERBUKA. Diukur semula 2026-08-17 tanpa modal — nilai
        setiap EditText dibaca sebelum dan selepas `scrollToBeginning`
        dan TIADA yang berubah. Peraturan itu kekal betul untuk konteks
        asalnya, tetapi ia tidak terpakai kepada halaman tanpa modal.

        Kontena: satu-satunya node `scrollable=true` pada skrin ini
        ialah `android.widget.ScrollView [0,276][1080,2316]`
        (docs/recon/tabkompaun-C-kompaun-mula.xml).
        """
        from appium.webdriver.common.appiumby import AppiumBy
        try:
            self.driver.find_element(
                AppiumBy.ANDROID_UIAUTOMATOR,
                'new UiScrollable(new UiSelector().scrollable(true)'
                f'.instance(0)).scrollToBeginning({int(maks)});')
            return True
        except Exception as e:                                # noqa: BLE001
            print(f"  [GULUNG] ke atas tidak berjaya "
                  f"({type(e).__name__}) — meneruskan")
            return False

    # Label medan tempoh BERBEZA antara borang. Borang Pelbagai
    # menggunakan `Tempoh Kompaun` (disahkan, dump
    # docs/recon/tabkompaun-*.xml). Borang Letak Kereta menggunakan
    # sesuatu yang LAIN — larian K 2026-08-18 melaporkan
    # `[TEMPOH] field not locatable on this variant`, dan tiada dump
    # borang K dengan medan tempoh wujud dalam repo.
    #
    # Maka: cuba setiap label yang diketahui, kemudian laluan lama,
    # dan kalau SEMUA gagal DUMP skrin supaya larian seterusnya
    # merakam nama sebenarnya. Meneka label di sini hanya akan
    # menghasilkan kegagalan yang sama dengan mesej berbeza.
    LABEL_TEMPOH_CALON = ("Tempoh Kompaun", "Tempoh Notis", "Tempoh")

    def _isi_tempoh_berbukti(self, nilai, data):
        """Isi medan tempoh, cuba setiap label yang diketahui."""
        for label in self.LABEL_TEMPOH_CALON:
            try:
                self.isi_medan_kesalahan(label, nilai, cubaan=1)
                return True
            except Exception:                                # noqa: BLE001
                continue
        print("  [TEMPOH] tiada label calon berjaya — cuba laluan lama")
        # >>> LALUAN LAMA TIDAK MELONTAR — IA MELAPOR DAN PULANG. <<<
        # `_apply_tempoh_from_data` mencetak
        # `field not locatable on this variant -- leaving as-is` dan
        # pulang seperti biasa. Larian K 2026-08-18 oleh itu tidak
        # pernah mencapai cabang dump di bawah, dan label sebenar kekal
        # tidak dirakam.
        #
        # Jadi jangan bergantung pada exception: SAHKAN nilai mendarat.
        try:
            self._apply_tempoh_from_data(data)
        except Exception:                                    # noqa: BLE001
            pass
        if self._medan_memegang(nilai):
            return True
        # Dump supaya label sebenar direkod, bukan diteka lagi.
        try:
            import os
            os.makedirs("ui_dumps", exist_ok=True)
            laluan = os.path.join("ui_dumps", "tempoh_tidak_dijumpai.xml")
            with open(laluan, "w", encoding="utf-8") as fh:
                fh.write(self.driver.page_source)
            print(f"  [TEMPOH] TIDAK DIJUMPAI — dump: {laluan}")
        except Exception:                                    # noqa: BLE001
            pass
        return False

    def isi_medan_kesalahan(self, label, nilai, cubaan=3):
        """Isi LOKASI/BUTIRAN KESALAHAN dan BUKTIKAN nilainya mendarat.

        >>> KENAPA BUKAN fill_field_by_label. <<<
        Empat larian P-001 (2026-08-17) melaporkan `Kompaun tab filled
        - PASS` dengan kedua-dua medan KOSONG. `fill_field_by_label`
        tidak salah secara umum — ia berfungsi pada borang N — tetapi
        pada skrin `Paparan Kompaun` gabungan langkah pembersihannya
        membuang nilai yang baru ditaip, dan baca-baliknya (`verify`)
        pulang None lalu menganggap "type landed and move on". Jadi
        kegagalan itu SENYAP.

        Urutan di bawah ialah tepat urutan yang probe satu-medan
        (`devtools/probe_lokasi.py`) UKUR berjaya pada device:

            find -> click -> clear -> send_keys     nilai KEKAL
            ...diikuti hide_keyboard                nilai HILANG

        Jadi tiada `hide_keyboard`, tiada `_emit_text`, tiada langkah
        pembersihan tambahan — hanya yang terbukti, kemudian baca-balik
        SEBENAR daripada pokok view yang segar.

        >>> DAN IA MELONTAR. <<<
        Kalau selepas `cubaan` percubaan medan masih kosong, ini
        membangkitkan. Rekod production dengan Lokasi/Butiran Kesalahan
        kosong lebih teruk daripada larian yang berhenti — dan senyap
        di sini bermakna PM menerima rekod yang tidak lengkap tanpa
        sesiapa tahu.
        """
        import time as _t

        sasaran = str(nilai)
        for cuba in range(1, int(cubaan) + 1):
            try:
                self.tutup_ime_tanpa_back()
            except Exception:                                # noqa: BLE001
                pass
            # Autocomplete jalan menggerakkan borang ke bawah; medan ini
            # berada di ATAS kedudukan semasa dan find_element hanya
            # menatal ke BAWAH.
            self.gulung_borang_ke_atas()

            el = self.find_element(self._ci_label_locator(label), timeout=10)
            el.click()
            _t.sleep(0.4)
            try:
                el.clear()
            except Exception:                                # noqa: BLE001
                pass
            el.send_keys(sasaran)
            _t.sleep(0.6)

            if self._medan_memegang(sasaran):
                print(f"  [KESALAHAN] {label} = {sasaran[:38]!r} "
                      f"(disahkan baca-balik, cubaan {cuba})")
                try:
                    self.tutup_ime_tanpa_back()
                except Exception:                            # noqa: BLE001
                    pass
                return True
            print(f"  [KESALAHAN] {label}: nilai TIDAK mendarat "
                  f"(cubaan {cuba}/{cubaan}) — cuba semula")

        raise TimeoutException(
            f"'{label}' masih KOSONG selepas {cubaan} percubaan. Rekod "
            f"TIDAK diserah: kompaun production dengan medan kesalahan "
            f"kosong lebih teruk daripada larian yang berhenti.")

    def _medan_memegang(self, nilai, tepat=False):
        """Adakah mana-mana EditText memegang `nilai`, dibaca daripada
        pokok view yang SEGAR?

        Membaca melalui `el.text` tidak boleh dipercayai di sini — RN
        re-render menjadikan handle stale dan `el.text` pulang None,
        yang laluan lama tafsirkan sebagai "anggap berjaya". Membaca
        page_source sekali lagi mengelak keseluruhan kelas itu.
        """
        import xml.etree.ElementTree as _ET

        # >>> PADANAN TEPAT UNTUK NILAI PENDEK. <<<
        # Padanan subrentetan tidak boleh mengesahkan nilai pendek:
        # tempoh K-001 ialah '1 HARI' -> digit '1', dan medan poskod
        # '81700' MENGANDUNGI '1'. Pengesahan lulus secara palsu, cabang
        # dump tidak pernah dicapai, dan larian K 2026-08-18 melaporkan
        # tempoh berjaya sedangkan medan kekal kosong.
        #
        # Ini kelas kesilapan yang sama seperti "pengesahan yang tidak
        # boleh gagal" — semakan yang sentiasa lulus tidak mengesahkan
        # apa-apa.
        sasaran = " ".join(str(nilai).split()).upper()
        try:
            akar = _ET.fromstring(self.driver.page_source)
        except Exception:                                    # noqa: BLE001
            return False
        for n in akar.iter():
            if (n.get("class") or "") != "android.widget.EditText":
                continue
            teks = " ".join((n.get("text") or "").split()).upper()
            if not teks:
                continue
            if tepat or len(sasaran) < 4:
                if teks == sasaran:
                    return True
            elif sasaran in teks:
                return True
        return False

    def _sahkan_medan_kesalahan(self, medan, data, pusingan=4):
        """Ulang sehingga SEMUA medan kesalahan berisi SERENTAK.

        >>> KENAPA GELUNG, BUKAN SATU LALUAN. <<<
        Diukur pada device 2026-08-17: setiap interaksi medan pada skrin
        `Paparan Kompaun` mengosongkan medan yang diisi SEBELUMNYA.
        Log larian pengesahan:

            LOKASI  diisi + disahkan
            BUTIRAN diisi + disahkan
            semakan: LOKASI  HILANG -> isi semula
            semakan: BUTIRAN HILANG -> isi semula

        Satu laluan semakan kebetulan menumpu pada larian itu, tetapi
        tiada apa yang menjaminnya: mengisi semula medan TERAKHIR boleh
        mengosongkan yang PERTAMA sekali lagi, dan laluan tunggal tidak
        akan menyedarinya. Rekod kemudian diserah dengan medan kosong.

        Gelung ini berhenti hanya apabila satu pusingan penuh mendapati
        SEMUA medan berisi — iaitu keadaan yang sebenarnya kita perlukan
        sebelum SERAH. Kalau ia tidak menumpu, `isi_medan_kesalahan`
        melontar dan larian berhenti tanpa mencipta rekod.

        Mekanisme pengosongan itu sendiri BELUM dicirikan. Ini
        membetulkan dengan MENYEMAK, bukan dengan memahami — dan itu
        dinyatakan supaya tiada siapa menganggapnya punca sudah selesai.
        """
        for pusingan_ke in range(1, int(pusingan) + 1):
            # >>> GULUNG KE ATAS SEBELUM MENYEMAK. <<<
            # `page_source` uiautomator hanya membawa node yang
            # KELIHATAN — node `visible:false` dibuang. Selepas tab diisi
            # borang berada jauh di bawah, jadi medan kesalahan berada di
            # luar viewport dan `_medan_memegang` melaporkannya HILANG
            # walaupun ia terisi.
            #
            # Pemilik memerhati device pada 2026-08-18 dan melaporkan
            # medan kesalahan MEMANG terisi sementara gelung ini terus
            # mengisi semula lalu melontar. "Tidak kelihatan" BUKAN
            # "kosong" — kesilapan yang PAPAN.md §15 sudah rekod untuk
            # baca-balik, berulang di sini.
            self.gulung_borang_ke_atas()
            hilang = [(l, k) for l, k in medan
                      if not self._medan_memegang(data[k])]
            if not hilang:
                if pusingan_ke > 1:
                    print(f"  [KESALAHAN] semua medan berisi serentak "
                          f"(pusingan {pusingan_ke})")
                return True
            for _label, _kunci in hilang:
                print(f"  [KESALAHAN] {_label} HILANG (pusingan "
                      f"{pusingan_ke}/{pusingan}) — mengisi semula")
                self.isi_medan_kesalahan(_label, data[_kunci])

        masih = [l for l, k in medan if not self._medan_memegang(data[k])]
        if masih:
            raise TimeoutException(
                f"medan kesalahan {masih} masih KOSONG selepas {pusingan} "
                f"pusingan isi-semula. Rekod TIDAK diserah.")
        return True

    def cari_mysikap(self):
        """(x, y) butang MySIKAP pada skrin semasa, atau None.

        Pembungkus driver bagi `cari_mysikap_dari_xml()`. Ia sengaja
        TIDAK membangkitkan pengecualian bila tidak dijumpai: pemanggil
        mesti membuat keputusan sendiri, dan tiada satu pun daripada
        keputusan itu boleh menjadi "tekan ePBT sahaja".
        """
        try:
            src = self.driver.page_source
        except Exception:                                    # noqa: BLE001
            return None
        return cari_mysikap_dari_xml(src, self.MYSIKAP_TOLERANSI_Y)

    def _mysikap_populated(self, plate):
        """True once the MySIKAP lookup has filled NAMA PESALAH with an
        actual owner name -- not the placeholder, and not an echo of
        the typed plate (observed live: a mid-populate read returned
        the plate itself where the owner name landed moments later).
        While a native alert is up (e.g. a lookup-failure popup), the
        field isn't visible to UiAutomator at all -- that reads as
        'not populated', which is handled by the caller's
        drain-and-retry."""
        try:
            t = self.driver.find_element(*self.FIELD_TRAFIK_NAMA_PESALAH).text
            return (bool(t) and t != "NAMA PESALAH"
                    and t.replace(" ", "").upper()
                    != plate.replace(" ", "").upper())
        except Exception:
            return False

    def fill_pesalah_tab_trafik(self, data):
        """Fill the Kompaun Trafik Pesalah tab.
        data must contain: no_kereta, warna_kereta.

        Flow (per real test case MBPG-TC-K-001, layout confirmed via
        live recon dumps): type NO. KERETA -> tap the MySIKAP image
        button -> wait for the server lookup to populate NAMA PESALAH /
        NO K/P/SSM and insert the populated address block -> fill
        WARNA KERETA manually. NO. CUKAI JALAN / NO. PETAK / NO. KUPON
        are deliberately left blank ('-' placeholders in the real test
        data, i.e. optional)."""
        import time
        print("\n  [DAFTAR KOMPAUN] Filling Pesalah tab (Trafik)...")
        self.wait_and_click(self.TAB_PESALAH)

        print(f"  [DAFTAR KOMPAUN] Entering No. Kereta: {data['no_kereta']}")
        self.fill_field_by_label(self.LABEL_TRAFIK_NO_KERETA,
                                 data["no_kereta"])

        # WARNA KERETA is filled BEFORE the MySIKAP lookup, not after
        # as the test-script step order implies: the populate inserts
        # the address block and pushes this field below the fold, where
        # this form resists the standard scroll gesture (confirmed via
        # live run + adb swipe experiments). Pre-populate it's right on
        # screen. It's not a required field (no '*' marker), so even if
        # the populate re-render were to reset it, submission isn't
        # blocked -- and a best-effort verify/refill runs after the
        # populate anyway.
        print(f"  [DAFTAR KOMPAUN] Entering Warna Kereta: "
              f"{data['warna_kereta']}")
        self.fill_field_by_label(self.LABEL_TRAFIK_WARNA_KERETA,
                                 data["warna_kereta"])

        populated = False
        for attempt in range(3):
            # Disauh pada ePBT secara STRUKTUR — lihat cari_mysikap().
            # Kalau ia tidak dapat dikenal pasti dengan pasti, kita
            # BERHENTI. Tiada tekaan: kawalan sebelah pada baris ini
            # ialah ePBT, dan menekannya memadam data.
            titik = self.cari_mysikap()
            if titik is None:
                raise TimeoutException(
                    "MySIKAP tidak dapat dikenal pasti secara struktur "
                    "pada borang Letak Kereta (sauh ePBT tiada, atau "
                    "padanan bukan tepat satu). TIADA tekaan dibuat — "
                    "kawalan bersebelahan ialah ePBT, yang memadam data.")
            print(f"  [DAFTAR KOMPAUN] Tapping MySIKAP @ {titik} "
                  f"(disauh pada ePBT)...")
            self.driver.tap([titik])

            print("  [DAFTAR KOMPAUN] Waiting for MySIKAP auto-populate...")
            deadline = time.monotonic() + 25
            while time.monotonic() < deadline:
                if self._mysikap_populated(data["no_kereta"]):
                    populated = True
                    break
                time.sleep(1)
            if populated:
                break
            # A lookup-failure alert may be covering the form; drain it
            # (logging its message) before re-tapping.
            self.dismiss_native_alerts(first_timeout=2, context="MySIKAP")
            print(f"  [DAFTAR KOMPAUN] MySIKAP did not populate "
                  f"(attempt {attempt + 1}/3) -- retrying...")

        if not populated:
            dump_path = "debug_mysikap_populate.xml"
            try:
                with open(dump_path, "w", encoding="utf-8") as f:
                    f.write(self.driver.page_source)
                print(f"  [DAFTAR KOMPAUN] DEBUG: page source dumped to "
                      f"{dump_path}")
            except Exception:
                pass
            raise TimeoutException(
                f"MySIKAP lookup never populated NAMA PESALAH for plate "
                f"{data['no_kereta']}; see {dump_path}")

        nama = self.driver.find_element(*self.FIELD_TRAFIK_NAMA_PESALAH).text
        print(f"  [DAFTAR KOMPAUN] MySIKAP populated — owner: {nama} — PASS")

        # Best-effort: verify the pre-populate WARNA KERETA value
        # survived the populate re-render, refilling if it was reset.
        # Non-fatal if unreachable -- the populate pushes it below the
        # fold and this form resists the standard scroll gesture; the
        # only swipe shape observed to move it (via adb experiments)
        # is a slow low-start one, tried here once.
        import time as _time
        try:
            # Peraturan #3: diderivasi dari get_window_size(), bukan
            # 540/2200 yang mengandaikan 1080x2400.
            self._swipe_perlahan_naik(dari=0.90, ke=0.33, tempoh=600)
            _time.sleep(0.5)
            warna_el = self.driver.find_element(
                AppiumBy.XPATH,
                '//android.widget.EditText[@hint="WARNA KERETA"]')
            if warna_el.text in ("", "WARNA KERETA"):
                print("  [DAFTAR KOMPAUN] Warna Kereta was reset by the "
                      "populate -- refilling...")
                warna_el.click()
                warna_el.clear()
                # send_keys DAHULU (dasar 2026-08-04): nilai testdata
                # berhuruf, dan 'r' melalui mobile: type mencetuskan
                # pintasan RELOAD (R,R) RN. Tiada sebab bertulis kenapa
                # medan ini memerlukan peristiwa kekunci sebenar.
                self._emit_text(warna_el, data["warna_kereta"], False)
                self._hide_keyboard_if_shown()
            else:
                print(f"  [DAFTAR KOMPAUN] Warna Kereta survived the "
                      f"populate: '{warna_el.text}' — PASS")
        except Exception:
            print("  [DAFTAR KOMPAUN] WARNING: could not re-verify Warna "
                  "Kereta after the populate (field below the fold) -- "
                  "continuing; the field is optional (no '*' marker)")

        print("  [DAFTAR KOMPAUN] Pesalah tab (Trafik) filled — PASS")

    def _fill_and_pick_suggestion(self, label, value):
        """Type into an autocomplete field whose value MUST be picked
        from its suggestion list (free-typed text is rejected by form
        validation), then tap the matching suggestion row.

        The rows are plain TextViews (distinct from the EditText that
        holds the typed value, so the row locator can't accidentally
        match the field itself). Matched via textContains: the row can
        be longer than the typed value (observed live: typing "JOHOR"
        offers "JOHOR DARUL TAKZIM"). Tap verified with re-taps, same
        as every pick in this suite."""
        self.fill_field_by_label(label, value)
        self._pilih_saranan(label, value)

    def _pilih_saranan(self, label, value):
        """Separuh 'pilih' bagi _fill_and_pick_suggestion (medan sudah ditaip).

        Diasingkan supaya blok alamat boleh menyemak medan itu BOLEH DIEDIT
        dahulu (pada tab Kompaun MBJB kebanyakannya DILUMPUHKAN) dan hanya
        kemudian menuntut pilihan dari senarai.
        """
        row = (AppiumBy.ANDROID_UIAUTOMATOR,
               f'new UiSelector().className("android.widget.TextView")'
               f'.textContains("{value}")')
        import time
        if not self.is_element_present(row, timeout=5):
            print(f"  [DAFTAR KOMPAUN] WARNING: no suggestion row appeared "
                  f"for '{label}' -- leaving typed value as-is")
            return
        for attempt in range(3):
            try:
                el = self.find_element(row, timeout=3)
            except Exception:
                return  # row vanished -> pick registered
            picked = el.text
            self.tap_element(el)
            time.sleep(0.7)
            if not self.is_element_present(row, timeout=2):
                print(f"  [DAFTAR KOMPAUN] Picked suggestion '{picked}' "
                      f"for {label} — PASS")
                return
            print(f"  [DAFTAR KOMPAUN] Suggestion row still showing after "
                  f"tap (attempt {attempt + 1}/3) -- re-tapping...")
        print(f"  [DAFTAR KOMPAUN] WARNING: suggestion pick for '{label}' "
              f"never registered -- continuing (validation may reject)")

    def _sahkan_skrin_kompaun(self, timeout=10):
        """Sahkan tab KOMPAUN benar-benar terbuka, dan laporkan sebab SEBENAR.

        TAB_KOMPAUN tidak boleh dipercayai (isu tab-hantu yang sama seperti
        TAB_NOTIS/TAB_PENERIMA), jadi kehadiran medan MAKLUMAT JALAN yang
        digunakan sebagai bukti. Locator TIDAK SENSITIF HURUF: label pada
        device ialah HURUF BESAR sedangkan LABEL_KOMPAUN_JALAN ditulis Title
        Case, jadi `text("Maklumat Jalan")` yang lama tidak akan pernah padan.

        >>> URUTAN TAB DIKUATKUASAKAN. <<< Tap tab seterusnya sebelum tab
        sebelumnya lengkap menghasilkan alert asli 'MAKLUMAT TIDAK LENGKAP' /
        'SILA LENGKAPKAN MAKLUMAT DI TAB PESALAH DAHULU.'
        (reports\\fasa2-bootstrap.md §2.4, DISAHKAN pada device). Alert itu
        dikosongkan dan MESEJNYA dilog, supaya kegagalan melaporkan sebab
        sebenar dan bukan "skrin tidak kelihatan".
        """
        # >>> BUKTI KETIBAAN ADALAH SATU SET, BUKAN SATU MEDAN. 2026-08-10. <<<
        # MAKLUMAT JALAN berada di ATAS tab. Selepas tab dibuka, borang
        # boleh sudah bergerak (isian pesalah menolak viewport), jadi
        # is_element_present() -- yang hanya melihat VIEWPORT SEMASA --
        # melaporkan "tab tidak terbuka" pada tab yang terbuka dengan
        # sempurna. Diperhati langsung: dump kegagalan mengandungi
        # 'Lokasi Kesalahan', 'Maklumat Kompaun' dan ketiga-tiga
        # dropdown -- iaitu kandungan tab KOMPAUN -- sedangkan medan
        # teratas yang kelihatan ialah 'Maklumat Negeri'.
        #
        # Ini kelas kesilapan yang sama seperti read-back N-001:
        # menyemak dengan mekanisme yang lebih lemah daripada keadaan
        # yang sedang disemak. Ketepatan TIDAK dilonggarkan: setiap
        # penanda di bawah wujud pada tab KOMPAUN SAHAJA.
        penanda = (self.LABEL_KOMPAUN_JALAN, "Lokasi Kesalahan",
                   "Butiran Kesalahan", "Maklumat Kompaun",
                   "KETERANGAN KOD KOMPAUN")
        for i, label in enumerate(penanda):
            # Hanya penanda pertama menunggu penuh; selebihnya semakan
            # pantas terhadap pokok yang sama.
            if self.is_element_present(self._ci_label_locator(label),
                                       timeout=timeout if i == 0 else 1):
                return
        if self.dismiss_native_alerts(first_timeout=3,
                                      context="kedatangan tab KOMPAUN"):
            raise AssertionError(
                "tab KOMPAUN tidak terbuka selepas SETERUSNYA — satu alert "
                "asli dipaparkan (mesejnya dilog di atas). Pada MBJB urutan "
                "tab DIKUATKUASAKAN: 'MAKLUMAT TIDAK LENGKAP' / 'SILA "
                "LENGKAPKAN MAKLUMAT DI TAB PESALAH DAHULU.' bermakna tab "
                "PESALAH masih tidak lengkap, bukan locator ini salah.")
        self._dump_mbjb("mbjb_tab_kompaun_tidak_terbuka.xml")
        raise AssertionError(
            f"tab KOMPAUN tidak terbuka selepas SETERUSNYA dan TIADA alert "
            f"dipaparkan — TIADA satu pun daripada {len(penanda)} penanda "
            f"tab KOMPAUN dijumpai ({', '.join(penanda)}; padanan tidak "
            f"sensitif huruf). Lihat ui_dumps\\mbjb_tab_kompaun_tidak_"
            f"terbuka.xml")

    def fill_kompaun_tab_direct(self, data):
        """Fill the Kompaun tab by typing full values directly into
        every field (no autocomplete interaction).

        Unlike the Pelbagai flow's partial-type-and-pick-suggestion,
        the Letak Kereta test case (MBPG-TC-K-001) specifies exact literal
        values for the whole address block, so plain send_keys typing
        is both sufficient and deterministic -- it sets the value
        without firing the RN live-search, so no suggestion dropdown
        ever renders to interfere (same technique as the Pesalah tab's
        Taman field in the Pelbagai flow).
        data must contain: kompaun_jalan, kompaun_taman, kompaun_poskod,
        kompaun_bandar, kompaun_negeri, lokasi_kesalahan,
        butiran_kesalahan, tempoh_notis."""
        print("\n  [DAFTAR KOMPAUN] Filling Kompaun tab (direct values)...")
        self._sahkan_skrin_kompaun(timeout=10)

        self.fill_field_by_label(self.LABEL_KOMPAUN_JALAN, data["kompaun_jalan"])
        # Blok alamat kesalahan: DILUMPUHKAN pada tab ini menurut fakta
        # device (ui_dumps\50_selepas_seterusnya.xml — MAKLUMAT TAMAN/
        # POSKOD/BANDAR/NEGERI enabled="false", app mengisinya sendiri dari
        # MAKLUMAT JALAN). Menaip ke dalamnya melontar
        # InvalidElementStateException dan mematikan gerbang create, jadi
        # setiap medan disemak DAHULU. Bandar/Negeri yang BOLEH diedit
        # masih menuntut pilihan dari senarai — disahkan live pada MBIP
        # melalui alert 'RALAT / SILA PILIH BANDAR DARIPADA SENARAI.'
        for label, kunci in ((self.LABEL_KOMPAUN_TAMAN, "kompaun_taman"),
                             (self.LABEL_KOMPAUN_BANDAR, "kompaun_bandar"),
                             (self.LABEL_KOMPAUN_NEGERI, "kompaun_negeri"),
                             (self.LABEL_KOMPAUN_POSKOD, "kompaun_poskod")):
            # >>> KUNCI TIADA = LANGKAU, bukan KeyError. 2026-08-05. <<<
            # taman/bandar/negeri/poskod berhenti didaftarkan sebagai data
            # input (keputusan pemilik: ia medan AUTO-ISI, app yang isi).
            # Medan ini pada tab NOTIS/KOMPAUN memang enabled="false" —
            # jadi ketiadaan nilai bermakna "biarkan app", bukan ralat.
            # Run 2026-08-05 meranap di sini dengan KeyError 'kompaun_taman'
            # dan mematikan P-001 sebelum borang sempat dibuka.
            if data.get(kunci) is None:
                continue
            keadaan = self.fill_field_by_label_if_editable(
                label, data[kunci], sumber_excel="MBPG-TC-*!C11")
            if keadaan == "diisi" and label in (self.LABEL_KOMPAUN_BANDAR,
                                                self.LABEL_KOMPAUN_NEGERI):
                self._pilih_saranan(label, data[kunci])
        # >>> BORANG INI KELAS TRAVERSAL-FOKUS — DIBETULKAN 2026-08-17. <<<
        # LOKASI dan BUTIRAN KESALAHAN berada DI BAWAH LIPATAN pada tab
        # Kompaun, dan tab ini menolak swipe. Larian P-001 pada
        # 2026-08-17 15:11 mencatat
        #
        #   [SKROL] AMARAN: swipe DIHANTAR tetapi ANJAKAN 0px
        #           (dikongsi=17, bergerak=0)
        #
        # dua kali, kemudian mati dengan `Element not found after 15s`
        # pada BUTIRAN KESALAHAN. Setiap cubaan skrol dalam
        # find_element() dijamin sifar di sini, tetapi tetap membayar
        # tempoh tunggunya.
        #
        # Borang NOTIS menyelesaikan masalah SAMA ini pada 2026-08-05
        # (notis_amaran_page.py:526-538). Pembetulan itu tidak pernah
        # dibawa ke borang ini kerana laluan P/K tidak pernah dipandu
        # sejauh ini sebelum mod sebenar wujud — sweep berhenti sebelum
        # medan ini, dan fasa fill-only tidak pernah menyerah.
        #
        # `reveal_below_fold` (melalui `_dedah_sebelum_cari`) ialah
        # SATU-SATUNYA mekanisme yang menggerakkan borang ini. Kegagalan
        # pendedahan TIDAK maut: kita jatuh ke carian biasa, corak yang
        # sama seperti `pilih_spinner_kod()`.
        _medan_kesalahan = ((self.LABEL_LOKASI_KESALAHAN,
                             "lokasi_kesalahan"),
                            (self.LABEL_BUTIRAN_KESALAHAN,
                             "butiran_kesalahan"))
        for _label, _kunci in _medan_kesalahan:
            self.isi_medan_kesalahan(_label, data[_kunci])

        # Tempoh: force-clear + verify + 0-21 range-check (see
        # _set_tempoh_verified) -- NOT a plain fill_field_by_label, whose
        # label lookup matches the "MAKLUMAT KOMPAUN" section-header on
        # this form and corrupts butiran.
        # >>> TEMPOH: locator lama menyasarkan TAJUK SEKSYEN. <<<
        # `LABEL_TEMPOH_NOTIS = "MAKLUMAT KOMPAUN"` ialah tajuk seksyen
        # (TextView), bukan medan. Kesannya dilog sebagai
        # `[TEMPOH] field not locatable on this variant -- leaving
        # as-is`, dan medan kekal KOSONG — kemudian app menolak
        # perpindahan ke tab Penerima dengan
        # `Ralat | Sila isi Tempoh Notis` (device, 2026-08-17).
        #
        # Placeholder medan sebenar ialah `Tempoh Kompaun` (dump
        # docs/recon/tabkompaun-C-kompaun-mula.xml, EditText y=2041).
        # Guna rutin berbukti yang sama seperti medan kesalahan: ia
        # mengesahkan nilai mendarat dan MELONTAR kalau tidak.
        _tempoh = "".join(c for c in str(data.get("tempoh_notis") or "")
                          if c.isdigit())
        if _tempoh:
            self._isi_tempoh_berbukti(_tempoh, data)
        else:
            self._apply_tempoh_from_data(data)


        # >>> SEMAKAN AKHIR — medan kesalahan MESTI masih berisi. <<<
        # Diukur 2026-08-17: `isi_medan_kesalahan()` mengesahkan setiap
        # nilai mendarat (baca-balik cubaan 1), tetapi menjelang tab ini
        # selesai kedua-duanya KOSONG semula. Sesuatu antara pengisian
        # dan penghujung tab membuangnya; mekanismenya BELUM dicirikan.
        #
        # Rekod N tidak terjejas — `PGP02N260817008` membawa
        # jalan1='DEPAN KEDAI' dan keterangan penuh dalam DB production —
        # jadi ini khusus skrin `Paparan Kompaun`.
        #
        # Sehingga puncanya difahami, betulkan dengan MENYEMAK, bukan
        # dengan mengandaikan: isi semula apa yang hilang, dan biarkan
        # `isi_medan_kesalahan` LONTAR kalau ia masih hilang. Kompaun
        # production dengan medan kesalahan kosong tidak boleh keluar
        # dari sini secara senyap.
        self._sahkan_medan_kesalahan(_medan_kesalahan, data)

        print("  [DAFTAR KOMPAUN] Kompaun tab (direct) filled — PASS")

    # _locate_tempoh_el / _set_tempoh_verified now live in base_page (shared
    # by the Notis and Kompaun forms -- both use the "MAKLUMAT KOMPAUN"
    # header + sibling EditText). Callers here inherit them unchanged.

    # ======================================================================
    # MEKANISME DROPDOWN SPINNER — tiga tingkat kod kompaun
    #
    # Diwarisi oleh KompaunLesenPage dan SitaanPage melalui rantaian kelas,
    # jadi keempat-empat borang (Pelbagai / Letak Kereta / Lesen / Sitaan)
    # menggunakan mekanisme YANG SAMA. Rujuk blok komen pada SPINNER_TEXT1
    # di atas untuk struktur device yang menjadi asasnya.
    # ======================================================================

    def _titik(self, fx, fy):
        """Koordinat mutlak daripada pecahan lebar/tinggi tetingkap.

        Peraturan Keras #3: tiada koordinat khusus mesin. Semua gerak
        isyarat dalam fail ini diderivasi daripada get_window_size().
        """
        w = self.driver.get_window_size()
        return int(w["width"] * fx), int(w["height"] * fy)

    def _swipe_perlahan_naik(self, dari=0.90, ke=0.33, tempoh=900):
        """Swipe PERLAHAN pada borang (bukan pada dialog dropdown).

        Bentuk 'mula rendah, perlahan' ialah satu-satunya yang pernah
        dilihat menggerakkan borang RN ini. Koordinat diderivasi daripada
        tetingkap, bukan 540/2200 yang dihardcode dahulu.
        """
        x, y1 = self._titik(0.50, dari)
        _, y2 = self._titik(0.50, ke)
        self.driver.swipe(x, y1, x, y2, tempoh)

    def _teks_spinner(self):
        """Teks nilai-terpilih setiap Spinner pada skrin, ikut urutan tree.

        FAKTA DEVICE (dump 51): Spinner yang BERISI mendedahkan nilainya
        melalui anak `android:id/text1`; Spinner yang KOSONG tiada anak
        TextView sama sekali. Jadi panjang senarai ini = bilangan tingkat
        yang benar-benar berisi.
        """
        try:
            return [(el.text or "")
                    for el in self.driver.find_elements(*self.SPINNER_TEXT1)]
        except Exception:                                    # noqa: BLE001
            return []

    # Kawalan dropdown MBPG 2.1.21: pressable RN, bukan Spinner. Teks
    # placeholdernya sentiasa berbentuk '-- PILIH <SESUATU> --'.
    PRESSABLE_PILIH = (
        AppiumBy.ANDROID_UIAUTOMATOR,
        'new UiSelector().clickable(true).descriptionMatches('
        '"(?i)(?s).*--\\s*PILIH\\s.*")')

    # Pressable dropdown yang SUDAH memaparkan nilai (placeholder sudah
    # digantikan). Diperlukan untuk set kedua dan seterusnya dalam
    # sweep — lihat _pressable_bawah_label(). Sengaja LUAS: penapisan
    # sebenar dibuat oleh peraturan KEDUDUKAN relatif kepada label,
    # bukan oleh corak teks.
    PRESSABLE_AM = (
        AppiumBy.ANDROID_UIAUTOMATOR,
        'new UiSelector().clickable(true).className('
        '"android.view.ViewGroup")')

    # ------------------------------------------------------------------
    # ENJIN DROPDOWN PRESSABLE RN  (MBPG 2.1.21)
    # ------------------------------------------------------------------
    # Ditulis atas RECON DEVICE 2026-08-10, bukan andaian.
    # Bukti: docs/recon/dropdown_tier1_terbuka.xml
    #
    # Modal yang dibuka oleh pressable '-- PILIH ... --':
    #     backdrop   ViewGroup clickable [0,108][1080,2316], teks KOSONG
    #     bekas      scrollable=true     [81,551][999,1874]
    #     baris      ViewGroup clickable, teks = keterangan PENUH
    #     TIADA medan carian
    #     TIADA butang BATAL/TUTUP
    #     TIADA resource-id selain android:id/content
    #
    # Ikutan reka bentuk:
    #   * Baris dipadan ikut TEKS PENUH. Tiada id untuk disandarkan.
    #   * Menutup = ketuk BACKDROP di luar panel. Android back TIDAK
    #     menutupnya (diperhati: 8 tekanan back, modal kekal terbuka).
    #   * Senarai boleh menatal — tingkat 3 boleh membawa puluhan baris.
    #   * Elemen DICARI SEMULA sebelum setiap tap. Pokok RN dirender
    #     semula selepas setiap interaksi, dan rujukan yang disimpan mati
    #     dengan StaleElementReferenceException (diperhati pada device).
    # Teks placeholder kawalan borang. BUKAN baris senarai — lihat
    # _baris_modal_kini().
    PLACEHOLDER_PILIH = re.compile(r"--\s*PILIH\s", re.I)

    BARIS_MODAL = (AppiumBy.ANDROID_UIAUTOMATOR,
                   'new UiSelector().clickable(true).className('
                   '"android.view.ViewGroup")')

    # Awalan kod pada baris tingkat 3: '[SEK 3 (2)] - MELETAKKAN ...'
    # Disahkan pada device 2026-08-10. DB menyimpan kod dan keterangan
    # dalam lajur BERASINGAN, jadi oracle membawa keterangan sahaja.
    AWALAN_KOD_BARIS = re.compile(r"^\s*\[[^\]]{1,40}\]\s*-\s*")

    @classmethod
    def _padan_baris_modal(cls, teks_baris, sasaran):
        """Adakah baris modal ini SASARANNYA?

        Padanan TEPAT selepas menormalkan satu bentuk yang diketahui:
        baris tingkat 3 dirender sebagai '[<kod>] - <keterangan>'
        sedangkan oracle/DB membawa keterangan sahaja.

        Ini BUKAN padanan longgar. Awalan yang dikupas mesti berbentuk
        kurungan-siku diikuti sengkang; selepas itu perbandingan adalah
        kesamaan penuh. 'KOMPAUN PELBAGAI' masih TIDAK memadan
        'KOMPAUN PELBAGAI JP' — awalan separa kekal ditolak, yang
        merupakan keseluruhan sebab peraturan match-or-FAIL wujud.

        >>> NORMALISASI EKOR — DITAMBAH 2026-08-10. <<<
        Baris production berbunyi
            '[UUK 3 (N)] - MEMBUAT ... KEROSAKAN HARTA MPPG'
        sedangkan oracle membawa ayat yang sama DENGAN noktah di
        hujung. Padanan tepat menolaknya atas satu aksara, dan
        melaporkan "TIADA dalam modal dropdown" untuk baris yang jelas
        berada di situ.

        Menormalkan noktah/koma hujung dan ruang berlebihan TIDAK
        melonggarkan ketegasan: ia tidak boleh menyebabkan baris LAIN
        dipilih, kerana perbandingan selepas normalisasi masih
        kesamaan penuh. Awalan separa kekal ditolak.
        """
        def _norm(s):
            s = " ".join((s or "").strip().upper().split())
            return s.rstrip(" .,;:")

        a = _norm(teks_baris)
        b = _norm(sasaran)
        if a == b:
            return True
        return _norm(cls.AWALAN_KOD_BARIS.sub("", a)) == b

    def _skrol_modal(self, baris, nama):
        """Tatal SENARAI DALAM MODAL. Pulangkan True kalau ia bergerak.

        >>> KENAPA BUKAN scroll_in_viewport(). Pathfinder 2026-08-11. <<<
        scroll_in_viewport() mencari bekas boleh-skrol melalui
        `UiSelector().scrollable(true)`, yang memulangkan padanan
        PERTAMA dalam pokok. Bila modal terbuka, borang di belakangnya
        masih dalam pokok dan padanan pertama itu ialah SKROL BORANG,
        bukan senarai modal. Jadi gerak isyarat dihantar kepada borang
        — yang memang menolak swipe — dan log melaporkan:

            [SKROL] swipe DIHANTAR tetapi ANJAKAN 0px

        Kesannya diukur pada pathfinder: modal KOD AKTA merender 7
        baris pada satu masa (senarai maya, `scrollable="true"`),
        sasaran berada pada kedudukan 12 daripada 20, dan enjin
        melaporkan 'nilai TIADA dalam modal dropdown'. DB mengesahkan
        nilai itu WUJUD. Dua larian, kegagalan identik.

        Kaedah di sini tidak bergantung pada resolusi `scrollable(true)`
        langsung: geometri dikira daripada BARIS MODAL YANG SEDANG
        DIRENDER, jadi ia mustahil menyasar borang di belakang. Dan ia
        mengukur kejayaan dengan membandingkan SET TEKS baris sebelum
        dan selepas — bukan dengan mempercayai gerak isyarat yang
        dihantar tanpa ralat.

        Skop sengaja sempit: hanya modal dropdown. cari_dua_arah() dan
        find_with_scroll() pada borang TIDAK disentuh (arahan pemilik
        2026-08-11).
        """
        import time as _time
        if not baris:
            return False
        sebelum = {t for t, _ in baris}
        try:
            atas = baris[0][1].rect
            bawah = baris[-1][1].rect
        except Exception as e:                               # noqa: BLE001
            print(f"  [MODAL] tidak dapat membaca bounds baris "
                  f"({type(e).__name__}) — tidak menatal")
            return False

        x = atas["x"] + atas["width"] // 2
        y_bawah = bawah["y"] + bawah["height"]
        y_atas = atas["y"]
        rentang = y_bawah - y_atas
        if rentang < 100:
            return False
        # Mula dekat hujung BAWAH senarai, tarik ke ATAS -> dedah baris
        # SELEPAS yang kelihatan.
        y1 = y_bawah - int(rentang * 0.10)
        y2 = y_atas + int(rentang * 0.10)

        try:
            # swipeGesture, BUKAN mana-mana *ClickGesture: ini gerakan,
            # bukan ketukan, jadi ia tidak melalui penilaian tap corong
            # (dan tidak sepatutnya — tiada butang ditekan).
            self.driver.execute_script("mobile: swipeGesture", {
                "left": max(0, x - 60), "top": y2, "width": 120,
                "height": max(1, y1 - y2), "direction": "up",
                "percent": 0.85, "speed": 1200,
            })
        except Exception as e:                               # noqa: BLE001
            print(f"  [MODAL] swipeGesture gagal ({type(e).__name__}) — "
                  f"cuba drag koordinat")
            try:
                self.driver.execute_script("mobile: dragGesture", {
                    "startX": x, "startY": y1, "endX": x, "endY": y2,
                    "speed": 1200})
            except Exception:                                # noqa: BLE001
                return False
        _time.sleep(0.6)

        selepas = {t for t, _ in self._baris_modal_kini()}
        bergerak = bool(selepas - sebelum)
        print(f"  [MODAL] tatal '{nama}': "
              f"{'BERGERAK' if bergerak else 'TIDAK bergerak'} "
              f"({len(selepas - sebelum)} baris baharu)")
        return bergerak

    def _baris_modal_kini(self):
        """[(teks, elemen)] bagi setiap baris modal yang kini dirender.

        Pulangkan senarai KOSONG apabila tiada modal terbuka.

        >>> DUA PENAPIS, KEDUA-DUANYA PERLU — 2026-08-10. <<<
        Versi pertama memadan "ViewGroup clickable yang berteks" sahaja.
        Itu turut memadan TIGA PRESSABLE BORANG ('-- PILIH KOMPAUN --',
        '-- PILIH AKTA --', '-- PILIH KESALAHAN --'), yang bentuknya
        sama persis. Kesannya: enjin menyangka modal sudah terbuka
        sedangkan ia masih pada borang, mencari 'KOMPAUN LETAK KERETA'
        antara tiga placeholder, dan gagal dengan betul tetapi atas
        sebab yang salah sepenuhnya.

        Penapis 1 — modal mesti benar-benar TERBUKA. Buktinya ialah
        backdrop: ViewGroup clickable yang meliputi hampir seluruh skrin
        dan TIADA teks. Pada borang, backdrop itu tidak wujud.

        Penapis 2 — placeholder '-- PILIH ... --' BUKAN baris. Ia teks
        kawalan borang, bukan nilai yang boleh dipilih.
        """
        try:
            calon = self.driver.find_elements(*self.BARIS_MODAL)
        except Exception:                                    # noqa: BLE001
            return []

        berteks, ada_backdrop = [], False
        for el in calon:
            try:
                t = (el.text or "").strip()
                if not t:
                    t = (el.get_attribute("content-desc") or "").strip()
                r = el.rect
            except Exception:                                # noqa: BLE001
                continue
            if r["height"] > 1500:
                # Bekas skrin-penuh. Tanpa teks = backdrop modal.
                if not t:
                    ada_backdrop = True
                continue
            if not t:
                continue
            if self.PLACEHOLDER_PILIH.search(t):
                continue          # kawalan borang, bukan baris senarai
            berteks.append((t, el))

        return berteks if ada_backdrop else []

    def _tutup_modal_pressable(self):
        """Ketuk backdrop di LUAR panel senarai.

        Bukan Android back: back tidak menutup modal ini (diperhati pada
        device). Bukan BATAL: tiada butang sedemikian.

        Titik sasaran dikira supaya ia berada di dalam backdrop tetapi
        di luar setiap baris — tap itu melalui corong seperti biasa, dan
        corong menapis ikut modal teratas, jadi ia membaca 'backdrop'
        dan bukan senarai di dalamnya.
        """
        baris = self._baris_modal_kini()
        if not baris:
            return True
        try:
            atas = min(el.rect["y"] for _t, el in baris)
        except Exception:                                    # noqa: BLE001
            atas = 551
        y = max(150, atas - 120)
        self.driver.tap([(540, y)])
        import time as _time
        _time.sleep(1.0)
        return not self._baris_modal_kini()

    def _pilih_melalui_pressable(self, calon, nama, nilai, nilai_tier1):
        """Buka pressable, pilih baris ikut TEKS PENUH, sahkan.

        MATCH-OR-FAIL. Tiada sandaran baris-pertama — peraturan lama
        kekal, dan ia lebih penting di sini kerana senarai ini panjang
        dan baris jiran kelihatan serupa.
        """
        import time as _time
        sasaran = str(nilai).strip()

        # --- buka ---
        terbuka = False
        for cubaan in range(3):
            baris = self._baris_modal_kini()
            if baris:
                terbuka = True
                break
            # Cari SEMULA pressable: ia mungkin sudah stale.
            if cubaan and calon is not None:
                calon = None
            el = None
            if calon:
                el = calon[0][1]
                calon = None
            if el is None:
                segar = self._pressable_bawah_label(0)
                if not segar:
                    break
                el = segar[0][1]
            try:
                self.tap_element(el)
            except StaleElementReferenceException:
                continue
            _time.sleep(1.5)
        if not terbuka and not self._baris_modal_kini():
            raise AssertionError(
                f"'{nama}': modal dropdown tidak terbuka selepas 3 ketukan "
                f"pada pressable.")

        # --- cari baris, menatal dalam modal kalau perlu ---
        dilihat = set()
        for pusingan in range(12):
            baris = self._baris_modal_kini()
            for t, _el in baris:
                dilihat.add(t)
            padan = [el for t, el in baris
                     if self._padan_baris_modal(t, sasaran)]
            if padan:
                break
            if not self._skrol_modal(baris, nama):
                break
            _time.sleep(0.4)
        else:
            padan = []

        if not padan:
            self._dump_mbjb(f"mbjb_modal_{self._tag(nama)}_tiada_padanan.xml")
            self._tutup_modal_pressable()
            raise AssertionError(
                f"'{nama}': nilai {sasaran!r} TIADA dalam modal "
                f"dropdown. Tingkat 1 yang dipilih: {nilai_tier1!r}. "
                f"{len(dilihat)} baris SEBENAR yang dilihat selepas "
                f"menatal: {sorted(dilihat)}. TIADA sandaran "
                f"baris-pertama: memilih baris yang salah lebih teruk "
                f"daripada gagal, kerana nilai salah itu akan kelihatan "
                f"seperti lulus.")

        # --- pilih ---
        self.tap_element(padan[0])
        _time.sleep(1.5)

        # --- sahkan: modal tertutup DAN pressable memaparkan nilai ---
        if self._baris_modal_kini():
            raise AssertionError(
                f"'{nama}': baris {sasaran!r} diketuk tetapi modal MASIH "
                f"terbuka — pemilihan tidak dipercayai.")
        # >>> JANGAN cari melalui _pressable_bawah_label() di sini. <<<
        # Locator itu menapis pada '-- PILIH ...', iaitu teks PLACEHOLDER.
        # Selepas pemilihan berjaya, kawalan memaparkan NILAI dan bukan
        # placeholder — jadi ia tidak lagi memadan, dan baca-balik akan
        # melaporkan GAGAL pada pemilihan yang sebenarnya BERJAYA.
        # Diperhati pada device 2026-08-10.
        #
        # Sebaliknya: cari kawalan yang memaparkan nilai itu.
        # Baca-balik mesti menggunakan bentuk yang APP paparkan, bukan
        # bentuk oracle. Nilai production tidak membawa noktah hujung
        # yang oracle bawa; mencari rentetan bernoktah akan gagal pada
        # pemilihan yang BETUL — diperhati 2026-08-10 pada tingkat 3
        # P-001, sejurus selepas _padan_baris_modal() memilih baris
        # yang tepat. Cari bentuk terpangkas; ia subrentetan bagi
        # kedua-dua bentuk, jadi tiada ketepatan hilang.
        sasaran_cari = (sasaran or "").strip().rstrip(" .,;:")
        dipapar = ""
        try:
            sel = ('new UiSelector().clickable(true).descriptionContains('
                   f'"{sasaran_cari}")')
            if self.driver.find_elements(AppiumBy.ANDROID_UIAUTOMATOR, sel):
                dipapar = sasaran
        except Exception:                                    # noqa: BLE001
            pass
        if not dipapar:
            # Sandaran: nilai mungkin berada pada TextView anak, bukan
            # pada bekas boleh-klik.
            try:
                dipapar = sasaran \
                    if self.is_text_visible(sasaran_cari, timeout=4) else ""
            except Exception:                                # noqa: BLE001
                dipapar = ""
        if not dipapar:
            # >>> DIBAIKI 2026-08-19 — larian 15:39/45/51 (K x3). <<<
            # XML forensik saat kegagalan membuktikan kawalan dropdown
            # TIADA LANGSUNG dalam pokok — viewport menunjukkan blok
            # alamat, dan RN tidak merender kawalan di luar viewport.
            # Pemilihan BERJAYA; baca-balik yang mencari tanpa menatal
            # kembali ke kawalan itu yang gagal — false negative yang
            # menutup ketiga-tiga plat. Sebelum melempar: dedahkan
            # kawalan (scrollIntoView teks, kemudian traversal fokus)
            # dan semak semula KEDUA-DUA saluran.
            # Seluruh blok pemulihan digerbang satu try: pada peranti
            # sebenar setiap panggilan selamat; dalam ujian offline
            # driver palsu tidak melaksanakan find_element, dan
            # kegagalan pemulihan TIDAK boleh menukar keputusan —
            # laluan asal (AssertionError) kekal.
            try:
                sel_txt = (f'new UiScrollable(new UiSelector()'
                           f'.scrollable(true)).scrollIntoView('
                           f'new UiSelector().textContains('
                           f'"{sasaran_cari[:30]}"));')
                try:
                    self.driver.find_element(AppiumBy.ANDROID_UIAUTOMATOR,
                                             sel_txt)
                except Exception:                            # noqa: BLE001
                    pass
                calon_baca = [
                    (AppiumBy.ANDROID_UIAUTOMATOR,
                     f'new UiSelector().textContains('
                     f'"{sasaran_cari[:30]}")'),
                    (AppiumBy.ANDROID_UIAUTOMATOR,
                     f'new UiSelector().descriptionContains('
                     f'"{sasaran_cari[:30]}")'),
                ]
                for loc in calon_baca:
                    if self.is_element_present(loc, timeout=3):
                        dipapar = sasaran
                        break
                if not dipapar and self.reveal_below_fold(calon_baca[0]):
                    dipapar = sasaran
                if dipapar:
                    print(f"  [DROPDOWN] '{nama}' baca-balik LULUS selepas "
                          f"menatal kembali ke kawalan (RN lazy render)")
            except Exception:                                # noqa: BLE001
                pass
        if not dipapar:
            raise AssertionError(
                f"'{nama}': modal ditutup tetapi TIADA pressable memaparkan "
                f"{sasaran!r} selepas pemilihan — walaupun selepas "
                f"scrollIntoView + traversal fokus. Baca-balik GAGAL — "
                f"jangan percaya pemilihan ini.")
        print(f"  [DROPDOWN] '{nama}' = {sasaran!r} (disahkan baca-balik)")
        return True

    def _pressable_bawah_label(self, sempadan_bawah_label):
        """[(y, elemen)] pressable '-- PILIH ... --' di bawah label.

        Peraturan sama seperti laluan Spinner: kawalan mesti MENJULUR ke
        bawah sempadan bawah label. Kawalan yang berada sepenuhnya DI
        ATAS label ialah kepunyaan tingkat lain, dan memilihnya bermakna
        menetapkan dropdown yang salah — kegagalan senyap yang tepat
        sama seperti bencana 'pilih baris pertama' yang lama.

        >>> PRESSABLE YANG SUDAH BERISI JUGA DIKIRA. Sweep 2026-08-11. <<<
        `PRESSABLE_PILIH` hanya memadan kawalan yang masih memaparkan
        placeholder '-- PILIH ... --'. Itu memadai untuk borang yang
        baru dibuka, tetapi TIDAK untuk set kedua dan seterusnya dalam
        sweep: selepas set pertama, pressable tingkat 1 memaparkan
        NILAI yang dipilih, bukan placeholder, jadi ia tidak lagi
        memadan dan enjin melaporkan

            label 'KETERANGAN KOD KOMPAUN' dijumpai (y=630..695) tetapi
            TIADA Spinner MAHUPUN pressable '-- PILIH ... --' di bawahnya

        — label kelihatan, kawalan ada, tetapi corak tidak menemuinya.
        Itu menjadikan sweep tidak boleh memandu lebih daripada SATU
        set setiap kali borang dibuka.

        Jadi kami turut mengumpul pressable am di bawah label. Ini
        tidak melonggarkan sasaran: peraturan kedudukan (mesti
        menjulur ke bawah sempadan label) kekal, hasil diisih ikut y
        dan pemanggil mengambil yang TERATAS, dan pemilihan masih
        disahkan dengan baca-balik selepasnya.
        """
        try:
            calon_mentah = list(self.driver.find_elements(
                *self.PRESSABLE_PILIH))
            if not calon_mentah:
                calon_mentah = list(self.driver.find_elements(
                    *self.PRESSABLE_AM))
        except Exception:                                    # noqa: BLE001
            return []
        keluar = []
        for el in calon_mentah:
            try:
                r = el.rect
            except Exception:                                # noqa: BLE001
                continue
            if r["y"] + r["height"] <= sempadan_bawah_label:
                continue
            keluar.append((r["y"], el))
        keluar.sort(key=lambda t: t[0])
        return keluar

    def _spinner_bawah_label(self, label_locator, nama):
        """Spinner yang berada TEPAT DI BAWAH label TextView `nama`.

        Inilah pengenalan yang menggantikan teks 'PILIH ...' yang tidak
        wujud. Ia tidak bergantung pada teks Spinner (tingkat 2/3 tiada
        teks) dan tidak pada koordinat keras — kedudukan dibaca daripada
        `rect` label dan `rect` setiap Spinner pada skrin semasa.
        """
        # Alert asli beratur dan tap di belakangnya HILANG SEPENUHNYA
        # (fasa2-bootstrap "PENEMUAN TEKNIKAL BAHARU" #2) -- kosongkan
        # dahulu, dengan mesejnya dilog, sebelum mengukur apa-apa.
        self.drain_printer_alert()
        try:
            label = self.find_element(label_locator, timeout=10)
            lr = label.rect
        except Exception as e:                               # noqa: BLE001
            raise AssertionError(
                f"label '{nama}' tidak dijumpai pada skrin ini, jadi "
                f"Spinner-nya tidak dapat dikenal pasti. Label DISAHKAN "
                f"wujud pada tab NOTIS (ui_dumps\\51_notis_skrol.xml); "
                f"kalau borang ini berbeza, dump skrin dan betulkan "
                f"LABEL_TIER*. Ralat asal: {type(e).__name__}: {e}") from e
        sempadan_bawah_label = lr["y"] + lr["height"]
        calon = []
        try:
            spinners = self.driver.find_elements(AppiumBy.CLASS_NAME,
                                                 self.SPINNER_KELAS)
        except Exception:                                    # noqa: BLE001
            spinners = []
        for sp in spinners:
            try:
                r = sp.rect
            except Exception:                                # noqa: BLE001
                continue
            # Spinner mesti MENJULUR ke bawah sempadan bawah label: yang
            # berada sepenuhnya di ATAS label ialah Spinner tingkat lain.
            if r["y"] + r["height"] <= sempadan_bawah_label:
                continue
            calon.append((r["y"], sp))
        if not calon:
            # >>> MBPG 2.1.21 TIDAK MEMAKAI Spinner. Disahkan 2026-08-10. <<<
            #
            # Mesej ralat di bawah sudah meramalkan ini sejak MBJB ("app
            # menukar kawalan ini daripada Spinner kepada sesuatu yang
            # lain"), dan itulah yang berlaku. Recon device menunjukkan
            # ketiga-tiga tingkat sebagai android.view.ViewGroup
            # clickable=true yang membawa teks placeholder:
            #     '-- PILIH KOMPAUN --'  '-- PILIH AKTA --'
            #     '-- PILIH KESALAHAN --'
            # setiap satu dengan glif chevron U+F20E di hujung kanan.
            #
            # Nota MBJB "tingkat 2/3 ialah Spinner NAF=true dengan SIFAR
            # anak text1, benar-benar KOSONG" TIDAK terpakai di sini:
            # pada MBPG ketiga-tiganya membawa teks yang boleh dibaca,
            # yang menjadikan pengenalan LEBIH mudah, bukan kurang.
            #
            # Peraturan pemilihan kekal sama seperti laluan Spinner:
            # kawalan mesti MENJULUR ke bawah sempadan bawah label, dan
            # yang paling hampir menang. Itu yang mengikat kawalan kepada
            # LABELnya dan bukan kepada kedudukan tetap.
            calon = self._pressable_bawah_label(sempadan_bawah_label)
            if calon:
                print(f"  [DROPDOWN] '{nama}': bukan Spinner — memakai "
                      f"pressable RN '-- PILIH ... --' ({len(calon)} calon)")

        if not calon:
            self._dump_mbjb(f"mbjb_spinner_{self._tag(nama)}_tiada.xml")
            raise AssertionError(
                f"label '{nama}' dijumpai (y={lr['y']}..{sempadan_bawah_label}) "
                f"tetapi TIADA android.widget.Spinner MAHUPUN pressable "
                f"'-- PILIH ... --' di bawahnya pada skrin semasa. "
                f"{len(spinners)} Spinner dilihat keseluruhan.")
        calon.sort(key=lambda t: t[0])
        return calon[0][1]

    def _spinner_ikut_indeks(self, tingkat, nama):
        """SANDARAN sahaja: Spinner tingkat `tingkat` (1-based) ikut
        KEDUDUKAN dalam tree, dipanggil HANYA selepas `_spinner_bawah_label`
        melempar AssertionError (label tidak dijumpai). JANGAN panggil ini
        sebagai laluan utama — Syarat 1 (arahan Loh): label kekal laluan
        UTAMA, indeks cuma jatuh-balik.

        Punca kegagalan carian label DISAHKAN pada device (recon\\PAPAN.md
        entri azharMadi 2026-07-31): run K1 gagal dengan
        "label 'KOD AKTA' tidak dijumpai ... selepas 10 skrol penuh", TETAPI
        dump pada PENGHUJUNG run SAMA menemui `Spinner: 3` dengan pilihan
        penuh pada ketiga-tiganya (spinner[0]=14 pilihan KETERANGAN KOD
        KOMPAUN, spinner[1]=3 pilihan KOD AKTA, spinner[2]=6 pilihan
        KESALAHAN KOMPAUN). Jadi ketiga-tiga Spinner MEMANG wujud pada
        skrin — yang gagal ialah carian ikut LABEL, bukan kewujudan
        elemen. Indeks tingkat-1 -> tingkat-3 memadan urutan tree yang
        disahkan itu: idx 0/1/2.

        Tiada pengesahan nilai berlaku di sini — pemanggil (pilih_spinner_kod)
        WAJIB baca-balik selepas pemilihan tanpa mengira laluan mana Spinner
        ini datang (Syarat 2): jatuh-balik indeks boleh sahaja menuding
        Spinner yang SALAH kalau susunan tree berbeza daripada yang disahkan
        di atas, dan baca-balik itulah satu-satunya perlindungan terhadap
        nilai salah tercetak pada kompaun sebenar.
        """
        self.drain_printer_alert()
        idx = tingkat - 1
        try:
            spinners = self.driver.find_elements(AppiumBy.CLASS_NAME,
                                                 self.SPINNER_KELAS)
        except Exception:                                    # noqa: BLE001
            spinners = []
        if idx < 0 or idx >= len(spinners):
            self._dump_mbjb(
                f"mbjb_spinner_{self._tag(nama)}_sandaran_indeks_tiada.xml")
            raise AssertionError(
                f"SANDARAN-INDEKS gagal juga: label '{nama}' tidak "
                f"dijumpai DAN Spinner[{idx}] tiada pada skrin ini "
                f"({len(spinners)} Spinner dilihat keseluruhan). Kedua-dua "
                f"laluan pengenalan (label dan indeks) gagal untuk "
                f"tingkat {tingkat}.")
        # Log format TEPAT (dengan hasil baca-balik) dicetak oleh pemanggil
        # pilih_spinner_kod() SELEPAS baca-balik selesai -- bukan di sini --
        # supaya satu baris sahaja per penggunaan sandaran, bukan dua baris
        # separuh-maklumat yang boleh mengelirukan pembaca log.
        return spinners[idx]

    @staticmethod
    def _tag(nama):
        """Nama fail dump yang selamat daripada label skrin."""
        return "".join(c if c.isalnum() else "_" for c in nama)[:32] or "spinner"

    @staticmethod
    def _regex_selamat(teks):
        """Escape `teks` untuk dimasukkan ke dalam UiSelector().textMatches()."""
        import re
        return re.escape(teks)

    def _baris_dialog(self):
        """(teks, elemen) setiap CheckedTextView yang KELIHATAN dalam dialog."""
        try:
            els = self.driver.find_elements(*self.DIALOG_BARIS)
        except Exception:                                    # noqa: BLE001
            return []
        out = []
        for el in els:
            t = self._safe_text(el)
            if t is not None and t.strip():
                out.append((t.strip(), el))
        return out

    def _skrol_dialog_perlahan(self):
        """Skrol senarai dropdown SATU langkah PERLAHAN (~40% viewport, 900ms).

        >>> SEBAB IA MESTI PERLAHAN. <<< Swipe pantas pada senarai dropdown
        ini MELOMPAT BARIS. Loh kehilangan nilai 'KOMPAUN PELBAGAI
        BANGUNANS' dengan swipe pantas (ia ada dalam
        ui_dumps\\kesalahan_tier1_PENUH_v2.txt baris 15) dan nilai itulah
        yang kemudiannya terbukti kritikal. Baris yang terlompat dilaporkan
        sebagai "nilai tiada dalam DB" — jurang kategori D PALSU.
        """
        try:
            senarai = self.find_element(self.DIALOG_SENARAI, timeout=2)
            r = senarai.rect
            x = r["x"] + r["width"] // 2
            y_bawah = r["y"] + int(r["height"] * 0.70)
            y_atas = r["y"] + int(r["height"] * 0.30)
        except Exception:                                    # noqa: BLE001
            # Dialog tanpa ListView yang dapat dilokasikan: guna tetingkap.
            x, y_bawah = self._titik(0.50, 0.70)
            _, y_atas = self._titik(0.50, 0.30)
        self.driver.swipe(x, y_bawah, x, y_atas, 900)

    def _buka_dialog_spinner(self, spinner, nama):
        """Tap Spinner dan sahkan dialog pilihan benar-benar terbuka.

        Pulang 'senarai' (dialog + >=1 baris), 'kosong' (dialog terbuka
        tetapi 0 baris) atau 'tiada' (dialog tidak terbuka selepas 3 tap
        yang disahkan). Tap disahkan, tidak dipercayai — BRIEF Seksyen 3:
        tap boleh gagal didaftarkan secara SENYAP.
        """
        import time
        for cubaan in range(3):
            self.tap_element(spinner)
            time.sleep(0.8)
            ada_senarai = self.is_element_present(self.DIALOG_SENARAI,
                                                 timeout=4)
            baris = self._baris_dialog()
            if baris:
                return "senarai"
            if ada_senarai:
                # SAHKAN-DEVICE: sama ada Spinner dengan 0 item memang
                # memaparkan ListView kosong, atau tidak membuka dialog
                # sama sekali, BELUM dilihat pada device — sebab itu
                # kedua-dua keadaan ('kosong' dan 'tiada') dilaporkan
                # dengan diagnosis yang sama — dan diagnosis itu kini
                # berkata "tingkat 1 ini tiada nilai", bukan "DB kosong"
                # (TARIK BALIK Loh 2026-07-30).
                return "kosong"
            if self.drain_printer_alert():
                time.sleep(0.4)
            print(f"  [DROPDOWN] dialog '{nama}' tidak terbuka selepas tap "
                  f"(cubaan {cubaan + 1}/3) — mengetuk semula")
        return "tiada"

    def _tutup_dialog(self):
        """Tutup dialog pilihan yang terbuka (BACK; selamat untuk dialog asli)."""
        try:
            self.press_back()
        except Exception:                                    # noqa: BLE001
            pass

    def _kumpul_dan_pilih(self, dikehendaki, max_skrol=30):
        """Skrol seluruh dialog perlahan-perlahan sambil mencari `dikehendaki`.

        Pulang (teks_dipilih_atau_None, senarai_semua_nilai_dilihat).
        Perbandingan TIDAK SENSITIF HURUF (_norm = strip+upper) kerana app
        memaksa HURUF BESAR (fasa2-bootstrap §2.4). Padanan tepat dicuba
        dahulu; barulah 'berakhir dengan', supaya awalan kod yang app
        letak pada baris (cth '39 - UUK 7 ...') tidak menghalang padanan
        sedangkan jiran yang lebih panjang ('KOMPAUN PELBAGAI JALAN' bila
        sasaran 'KOMPAUN PELBAGAI') tetap TIDAK terpadan.
        """
        import time
        sasaran = self._norm(dikehendaki)
        dilihat = []
        for langkah in range(max_skrol):
            baris = self._baris_dialog()
            for padanan_tepat in (True, False):
                for teks, el in baris:
                    n = self._norm(teks)
                    if (n == sasaran) if padanan_tepat else n.endswith(sasaran):
                        if not padanan_tepat:
                            print(f"  [DROPDOWN] baris {teks!r} padan "
                                  f"{dikehendaki!r} melalui 'berakhir dengan' "
                                  f"(app meletakkan awalan kod pada baris)")
                        if self._tap_baris_dialog(el, teks):
                            return teks, dilihat
                        return None, dilihat
            baru = [t for t, _ in baris if t not in dilihat]
            dilihat.extend(baru)
            if langkah and not baru:
                break                      # hujung senarai: tiada baris baharu
            if not baris:
                break                      # dialog kosong / sudah tertutup
            self._skrol_dialog_perlahan()
            time.sleep(0.4)
        return None, dilihat

    def _tap_baris_dialog(self, el, teks):
        """Tap satu baris dialog dan sahkan dialog benar-benar TERTUTUP.

        Baris ialah CheckedTextView asli (bukan Pressable RN), jadi
        el.click() boleh berkesan di tempat tap koordinat gagal — kedua-dua
        dicuba, dan bukti kejayaan ialah dialog hilang, bukan tap 'berjaya'.
        """
        import time
        for cubaan in range(3):
            for kaedah in ("coord", "click"):
                try:
                    if kaedah == "coord":
                        self.tap_element(el)
                    else:
                        el.click()
                except Exception:                            # noqa: BLE001
                    pass
                for _ in range(4):
                    time.sleep(0.5)
                    if (not self.is_element_present(self.DIALOG_SENARAI,
                                                    timeout=1)
                            and not self._baris_dialog()):
                        print(f"  [DROPDOWN] DIPILIH {teks!r} melalui "
                              f"{kaedah}-tap — dialog TERTUTUP (didaftarkan)")
                        return True
            print(f"  [DROPDOWN] pilihan {teks!r} tidak didaftarkan "
                  f"(cubaan {cubaan + 1}/3 — coord+click dicuba)")
        return False

    def pilih_spinner_kod(self, tingkat, label_locator, nama, nilai,
                          nilai_tier1):
        """Pilih `nilai` daripada Spinner tingkat `tingkat`, ikut LABEL.

        Melempar AssertionError pada setiap kegagalan, dengan diagnosis
        yang membezakan sebab yang berbeza sama sekali:
          (a) label DAN sandaran indeks kedua-duanya tidak dijumpai
              -> locator/struktur skrin
          (b) dialog terbuka tetapi 0 pilihan     -> tingkat 1 yang DIPILIH
              tiada nilai ini dalam DB (pilih tingkat 1 yang LAIN); BUKAN
              bukti DB kosong — lihat _mesej_kategori_d()
          (c) dialog berisi tetapi nilai tiada    -> calon jurang kategori
              D, dengan senarai nilai SEBENAR yang ada supaya percanggahan
              ejaan/perkataan dapat dilihat serta-merta
          (d) baca-balik selepas pemilihan tidak sepadan nilai diminta
              -> pemilihan TIDAK dipercayai, dilaporkan sebagai FAIL
        Tiada pytest.skip dicipta di sini. Peraturan #6 melarang skip yang
        menyembunyikan dropdown kosong — ia mesti BISING.

        >>> SANDARAN-INDEKS (arahan Loh, recon\\PAPAN.md entri azharMadi
        2026-07-31) <<< Carian label (_spinner_bawah_label) KEKAL laluan
        UTAMA (Syarat 1) -- sandaran ikut kedudukan (_spinner_ikut_indeks)
        hanya dicuba SELEPAS carian label melempar AssertionError. Tanpa
        mengira laluan mana Spinner datang, baca-balik selepas pemilihan
        adalah WAJIB (Syarat 2): nilai yang terpapar mesti SAMA dengan
        yang diminta, atau ini FAIL -- bukan cuma amaran. Sebab: bencana
        "pilih baris pertama" yang lama berlaku pada laluan yang ADA
        label; tanpa baca-balik keras, sandaran indeks boleh menuding
        Spinner yang SALAH dan nilai salah itu tercetak pada kompaun
        sebenar.
        """
        print(f"  [DROPDOWN] tingkat {tingkat} '{nama}' -> {nilai!r}")
        sebelum = self._teks_spinner()
        guna_sandaran = False
        indeks_sandaran = tingkat - 1
        # >>> TRAVERSAL DAHULU, 2026-08-05. <<<
        # N-005 gagal pada run 2026-08-05 dengan:
        #   label 'KETERANGAN KOD KOMPAUN' dijumpai (y=2257..2316) tetapi
        #   TIADA android.widget.Spinner di bawahnya. 0 Spinner keseluruhan.
        # y=2257 jauh di bawah sempadan viewport y~1596. Borang bookmark
        # ialah kelas TRAVERSAL-FOKUS: ia menolak setiap gesture skrol,
        # jadi gelung skrol dalaman find_element memulangkan "tidak
        # dijumpai" untuk Spinner yang MEMANG ADA. Ditambah dengan fakta
        # bahawa `uiautomator dump` MEMBUANG nod visible:false, "0 Spinner
        # dilihat" bukan bukti ketiadaan.
        # reveal_below_fold() (klik EditText untuk fokus, kemudian TAB 61 /
        # DPAD_DOWN 20) menyeret viewport bersama fokus — itu satu-satunya
        # mekanisme yang menggerakkan borang kelas ini.
        try:
            self._dedah_sebelum_cari(label_locator, nama)
        except Exception as e:                               # noqa: BLE001
            print(f"  [DROPDOWN] pendedahan traversal untuk '{nama}' tidak "
                  f"berjaya ({type(e).__name__}) — meneruskan carian")
        # >>> LALUAN PRESSABLE RN — MBPG 2.1.21. <<<
        # Disemak DAHULU kerana pada build ini TIADA Spinner langsung;
        # mencuba laluan Spinner terlebih dahulu hanya menghasilkan satu
        # AssertionError dan satu dump setiap tingkat sebelum sampai ke
        # sini. Kalau build kemudian mengembalikan Spinner, senarai ini
        # kosong dan laluan lama diteruskan tanpa perubahan.
        try:
            lbl = self.find_element(label_locator, timeout=10)
            lr = lbl.rect
            pressable = self._pressable_bawah_label(lr["y"] + lr["height"])
        except Exception:                                    # noqa: BLE001
            pressable = []
        if pressable:
            print(f"  [DROPDOWN] '{nama}': kawalan pressable RN "
                  f"({len(pressable)} calon di bawah label)")
            self._pilih_melalui_pressable(pressable, nama, nilai,
                                          nilai_tier1)
            return

        try:
            spinner = self._spinner_bawah_label(label_locator, nama)
        except AssertionError as e:
            print(f"  [DROPDOWN] carian label GAGAL untuk '{nama}' "
                  f"({type(e).__name__}: {e}) — cuba SANDARAN-INDEKS...")
            guna_sandaran = True
            spinner = self._spinner_ikut_indeks(tingkat, nama)

        keadaan = self._buka_dialog_spinner(spinner, nama)

        if keadaan in ("kosong", "tiada"):
            self._dump_mbjb(f"mbjb_dropdown_{self._tag(nama)}_kosong.xml")
            raise AssertionError(self._mesej_kategori_d(
                tingkat, nama, nilai, nilai_tier1, sebelum,
                dialog_terbuka=(keadaan == "kosong"), dilihat=[]))

        dipilih, dilihat = self._kumpul_dan_pilih(nilai)
        if dipilih is None:
            self._tutup_dialog()
            self._dump_mbjb(f"mbjb_dropdown_{self._tag(nama)}_tiada_nilai.xml")
            raise AssertionError(self._mesej_kategori_d(
                tingkat, nama, nilai, nilai_tier1, sebelum,
                dialog_terbuka=True, dilihat=dilihat))

        # ---- BACA-BALIK WAJIB (Syarat 2) — laluan label MAHUPUN indeks --
        # Dialog TERTUTUP selepas tap pada baris yang teksnya sendiri
        # dipadan, jadi pemilihan memang DIDAFTARKAN; yang WAJIB disahkan
        # secara berasingan ialah apa yang medan Spinner PAPARKAN selepas
        # itu -- dahulu ini cuma amaran dan diteruskan, itulah lubang yang
        # membenarkan pemilihan salah lolos senyap.
        selepas = self._teks_spinner()
        padan = any(self._norm(nilai) in self._norm(t) for t in selepas)

        if not padan:
            if guna_sandaran:
                print(f"  [SANDARAN-INDEKS] label {nama!r} gagal, guna "
                      f"Spinner[{indeks_sandaran}] -> baca-balik GAGAL")
            self._dump_mbjb(
                f"mbjb_dropdown_{self._tag(nama)}_bacaan_balik_gagal.xml")
            raise AssertionError(
                f">>> BACA-BALIK GAGAL selepas memilih tingkat {tingkat} "
                f"'{nama}' <<< diminta {nilai!r}, terpapar {selepas!r} "
                f"(dipilih dari dialog: {dipilih!r}; laluan pengenalan "
                f"Spinner: {'SANDARAN-INDEKS Spinner[' + str(indeks_sandaran) + ']' if guna_sandaran else 'label'}). "
                f"Dialog TERTUTUP dan tap didaftarkan, tetapi medan Spinner "
                f"TIDAK memaparkan nilai yang diminta selepas itu — "
                f"pemilihan ini TIDAK boleh dipercayai. JANGAN teruskan "
                f"seolah-olah ia berjaya: nilai salah boleh tercetak pada "
                f"kompaun sebenar.")

        if guna_sandaran:
            print(f"  [SANDARAN-INDEKS] label {nama!r} gagal, guna "
                  f"Spinner[{indeks_sandaran}] -> baca-balik OK")
        print(f"  [DROPDOWN] tingkat {tingkat} '{nama}' = {dipilih!r} "
              f"— PASS")
        return dipilih

    def _mesej_kategori_d(self, tingkat, nama, nilai, nilai_tier1, sebelum,
                          dialog_terbuka, dilihat):
        """Mesej BISING untuk dropdown kosong / nilai tiada.

        >>> TEKS DIBETULKAN 2026-07-30 — TARIK BALIK LOH. <<<
        Versi lama mengisytiharkan "DB staging MBJB tiada {nama}" untuk
        SETIAP dialog kosong, berdasarkan SATU sampel yang kebetulan nilai
        tingkat-1 LALAI. Pemetaan bersistem Loh merentas 28 nilai tingkat 1
        (`ui_dumps\\kesalahan_peta_LENGKAP.txt`, alat
        `devtools\\peta_kesalahan.py`) MEMBUKTIKAN sebaliknya:

            AKTA JALAN/PARIT/BANGUNAN            -> 23 nilai KOD AKTA
            KOMPAUN (idx 8)                      ->  6
            KOMPAUN MENCEGAH KEKOTORAN           ->  4
            KOMPAUN LETAK KERETA PRESSGO/SOUTHMAX ->  1 setiap satu
            AKTA JALAN PARIT & BANGUNAN & AKTA KERAJAAN TEMPATAN -> 0 (LALAI)
            KOD TESTING / KOMAPD                 ->  0 (sampah DB)

        RANTAIAN KESALAHAN BERFUNGSI dan DB staging BERISI. Jadi dialog
        tingkat-2 yang KOSONG bermakna **tingkat 1 yang DIPILIH tiada AKTA
        dalam DB** — BUKAN bahawa DB kosong, dan BUKAN jurang kategori D
        menyeluruh. AssertionError dikekalkan (ia betul sebagai diagnostik
        dan mesti BISING), tetapi ia kini mencadangkan tingkat 1 yang lain
        dan tidak lagi menghantar sesiapa menuduh dev tanpa asas.

        Dialog yang BERISI tetapi tiada nilai kita KEKAL calon kategori D
        yang sah — di situ nilai SEBENAR dicetak supaya percanggahan
        perkataan-demi-perkataan (cth `KEKOTORANG` lawan `KEKOTORAN`) dapat
        dilihat serta-merta.
        """
        keadaan = ("TERBUKA tetapi mengandungi 0 pilihan" if dialog_terbuka
                   else "TIDAK TERBUKA selepas 3 tap yang disahkan (Spinner "
                        "dengan 0 item boleh enggan membuka dialog)")
        if dilihat:
            isi = (
                f"Dialog membekalkan {len(dilihat)} pilihan tetapi TIADA "
                f"satu pun sepadan {nilai!r} (perbandingan tidak sensitif "
                f"huruf). Nilai SEBENAR dalam DB staging: {dilihat!r}. "
                f"MAKNANYA: kombinasi ini MEMANG ada dalam DB, cuma nilai "
                f"oracle tidak sepadan perkataan-demi-perkataan dengan "
                f"nilai DB — bandingkan senarai di atas dengan nilai Excel "
                f"sebelum menuduh data hilang (kelas yang sama seperti "
                f"'KEKOTORANG' lawan 'KEKOTORAN').")
        else:
            isi = (
                f"Dialog {keadaan} — 0 nilai dibaca. MAKNANYA: tingkat 1 "
                f"yang DIPILIH ({nilai_tier1!r}) tiada {nama} dalam DB "
                f"staging. Ini BUKAN bukti DB kosong: pemetaan Loh "
                f"2026-07-30 merentas 28 nilai tingkat 1 menunjukkan "
                f"'AKTA JALAN/PARIT/BANGUNAN' -> 23 nilai, 'KOMPAUN' -> 6, "
                f"'KOMPAUN MENCEGAH KEKOTORAN' -> 4; hanya nilai LALAI "
                f"'AKTA JALAN PARIT & BANGUNAN & AKTA KERAJAAN TEMPATAN' "
                f"dan sampah DB ('KOD TESTING', 'KOMAPD') yang kosong "
                f"(ui_dumps\\kesalahan_peta_LENGKAP.txt). CADANGAN: pilih "
                f"tingkat 1 yang LAIN — yang MEMANG mempunyai {nama} — dan "
                f"betulkan nilai tingkat 1 dalam testdata, bukan locator.")
        return (
            f">>> DROPDOWN KOD KOMPAUN GAGAL (bukan bug automation) <<< "
            f"tingkat {tingkat} '{nama}' tidak dapat ditetapkan kepada "
            f"{nilai!r}. Tingkat 1 yang DIPILIH: {nilai_tier1!r}. "
            f"Teks Spinner sebelum cubaan: {sebelum!r}. {isi} "
            f"JANGAN tukar locator dan JANGAN tulis skip untuk "
            f"menyembunyikan ini.")

    def fill_kompaun_code_fields_trafik(self, data):
        """Kompaun code tiers on the LETAK KERETA / TRAFIK form.

        MBIP: tingkat 1 borang ini pra-pilih 'PERINTAH LALULINTAS JALAN
        (PERINTAH 39 )' dan tidak boleh diubah. MBJB BERBEZA: Excel
        MBPG-TC-K-005 C9 membekalkan nilai tingkat 1 ('KOMPAUN LETAK
        KERETA MBJB' / 'KOMPAUN LETAK KERETA PRESSGO'), jadi tingkat 1
        di sini DIPILIH bila data membekalkannya, dan hanya dilaporkan
        bila tidak.

        # SAHKAN-DEVICE: borang Letak Kereta MBJB BELUM PERNAH DIBUKA pada
        # device (PAPAN.md §4 "MASIH BELUM DISAHKAN"). Assert keras
        # 'PERINTAH 39' yang lama DIBUANG: ia mengunci fakta MBIP dan akan
        # menggagalkan K-001 dengan sebab yang salah. Nilai tingkat 1 yang
        # sebenar ada pada skrin DILAPORKAN supaya run pertama merekodnya.
        """
        print("  [DAFTAR KOMPAUN] Selecting kompaun code dropdowns (Trafik)...")
        nilai1 = data.get("keterangan_kod_kompaun")
        if nilai1:
            self.pilih_spinner_kod(1, self.LABEL_TIER1,
                                   "KETERANGAN KOD KOMPAUN", nilai1, nilai1)
        else:
            semasa = self._teks_spinner()
            nilai1 = semasa[0] if semasa else "(tiada teks Spinner)"
            print(f"  [DAFTAR KOMPAUN] Excel tidak membekalkan tingkat 1 "
                  f"untuk borang ini — mengekalkan nilai pra-pilih "
                  f"{nilai1!r} (Peraturan #5: tidak mereka nilai)")
        self.pilih_spinner_kod(2, self.LABEL_TIER2, "KOD AKTA",
                               data["kod_akta"], nilai1)
        self.pilih_spinner_kod(3, self.LABEL_TIER3, "KESALAHAN KOMPAUN",
                               data["kesalahan_kompaun"], nilai1)
        self._sahkan_tier3_kembali()
        self.fill_kadar_denda(data["kadar_denda"])
        print("  [DAFTAR KOMPAUN] Kompaun code dropdowns (Trafik) selected — PASS")

    def is_submission_successful_trafik(self):
        """Adili keputusan selepas HANTAR pada aliran Trafik/Letak Kereta.

        >>> B-1 DIBETULKAN 2026-07-30 — dahulu ini PASS PALSU. <<<
        Versi lama memanggil `dismiss_native_alerts()` (yang ketika itu
        MENELAN teks alert; ia kini menawarkan `kumpul=True`) lalu
        memulangkan `True` SEMATA-MATA kerana butang MENYERAHKAN
        hilang. Alert `Penghantaran Tidak Berjaya` / `RALAT`
        ditolak secara senyap dan K-001/L-001/S-001 LULUS atas rekod yang
        TIDAK WUJUD. Cabang itu juga tidak pernah memanggil
        `read_record_number()`, jadi `created_records["K"]` menjadi `""`
        dan `conftest._require_record()` melaporkan keadaan (c) "create
        BERFUNGSI, semak record_prefix" untuk sesuatu yang sebenarnya
        keadaan (a) create GAGAL.

        Sekarang, mengikut susunan:
          1. popup resit (bukti kejayaan TERKUAT) -> baca nombor, PASS;
          2. baca TEKS alert dahulu, PENAFIAN disemak DAHULU, dan
             `read_record_number()` dicuba SEMASA alert masih terpapar
             (`adili_alert_hantar`);
          3. penafian -> GAGAL, dengan teks alert SEBENAR dalam log;
          4. borang masih terbuka -> GAGAL;
          5. teks kejayaan disahkan -> PASS (keadaan (b) kalau nombor
             terbaca, (c) kalau tidak — kedua-duanya SAH kerana kejayaan
             sudah disahkan secara bebas);
          6. tiada teks kejayaan TETAPI nombor rekod TERBACA -> PASS
             (keadaan (b): nombor itu sendiri bukti positif rekod wujud);
          7. tiada teks kejayaan DAN tiada nombor -> GAGAL, keadaan (a).

        Langkah 7 ialah intipati pembetulan: "borang ditutup" seorang
        diri BUKAN lagi bukti. Alert `Ralat / No data found for the
        provided parameters.` yang MBIP labelkan tidak berbahaya (carian
        resit kosong) kini mesti disokong oleh nombor rekod sebelum ia
        boleh dikira LULUS. Kalau ini menjadikan K/L/S-001 MERAH pada run
        sebenar, itu keputusan yang BETUL — ia bermakna create memang
        gagal, dan kita akhirnya dapat tahu."""
        import time
        cetak = (AppiumBy.ANDROID_UIAUTOMATOR,
                 'new UiSelector().textMatches("(?i).*cetak kompaun.*")')
        if self.is_element_present(cetak, timeout=15):
            print("  [DAFTAR KOMPAUN] Trafik submission successful — "
                  "receipt popup visible — PASS")
            self.last_record_number = None
            self.read_record_number()  # capture no_kompaun before closing
            self.close_success_popup()
            return True

        v = adili_alert_hantar(self, "Trafik submission result",
                               first_timeout=20)
        time.sleep(1)
        borang_terbuka = self.is_element_present(self.BUTTON_MENYERAHKAN,
                                                 timeout=5)

        if v["ditolak"]:
            self._dump_mbjb("trafik_submit_ditolak.xml")
            print(f"  [DAFTAR KOMPAUN] >>> PENGHANTARAN DITOLAK <<< alert "
                  f"MENAFIKAN kejayaan: {v['teks']!r} — FAIL (rekod TIDAK "
                  f"dicipta; ini keadaan (a), bukan masalah record_prefix)")
            return False

        if borang_terbuka:
            self._dump_mbjb("trafik_submit_borang_masih_terbuka.xml")
            print(f"  [DAFTAR KOMPAUN] WARNING: borang penghantaran MASIH "
                  f"TERBUKA selepas HANTAR — penghantaran tidak berlaku "
                  f"(teks alert: {v['teks']!r})")
            return False

        if v["disahkan"]:
            if v["nombor"]:
                print(f"  [DAFTAR KOMPAUN] Trafik submission successful — "
                      f"teks alert mengesahkan kejayaan DAN nombor rekod "
                      f"{v['nombor']} terbaca (keadaan (b)) — PASS")
            else:
                print("  [DAFTAR KOMPAUN] Trafik submission successful — "
                      "teks alert mengesahkan kejayaan TETAPI nombor rekod "
                      "TIDAK terbaca (keadaan (c) yang SAH: kejayaan "
                      "disahkan secara bebas daripada nombor) — PASS")
            return True

        if v["nombor"]:
            print(f"  [DAFTAR KOMPAUN] Trafik submission successful — tiada "
                  f"teks kejayaan (alert: {v['teks']!r}) TETAPI nombor "
                  f"rekod {v['nombor']} TERBACA; nombor itu sendiri bukti "
                  f"positif rekod wujud (keadaan (b)) — PASS")
            return True

        self._dump_mbjb("trafik_submit_tiada_bukti.xml")
        print("  [DAFTAR KOMPAUN] " + sebab_gagal_senyap(
            "Trafik/Letak Kereta submit",
            "Butang MENYERAHKAN memang hilang — dan itulah SATU-SATUNYA "
            "isyarat yang ada.", v["teks"]))
        return False

    # ---- Pesalah tab ----

    def fill_pesalah_tab(self, data):
        """Fill in the Pesalah tab fields.
        data must contain: nama_pesalah, no_kp_ssm_kereta, jalan,
        taman, poskod, bandar, negeri
        """
        import time
        print("\n  [DAFTAR KOMPAUN] Filling Pesalah tab...")
        self.wait_and_click(self.TAB_PESALAH)

        # AUTOCOMPLETE DUA BENTUK -- rujukan untuk pembaca akan datang.
        # Tab PESALAH merender cadangan MAKLUMAT JALAN sebagai `Spinner` +
        # dialog (keluarga sama dengan mesin dropdown kod kompaun dalam
        # fail ini); tab KOMPAUN merender sebagai baris teks biasa dalam
        # borang (`Spinner: 0`), format "JALAN | TAMAN" (lihat
        # fill_kompaun_tab, yang memanggil type_and_select_suggestion()).
        # Kod di bawah TIDAK cuba buka Spinner PESALAH langsung -- ia
        # menaip nilai PENUH terus (sebab: lihat nota "Taman is a
        # live-search..." di bawah). Ini sengaja mengelak isu bentuk-
        # widget sepenuhnya, bukan mengabaikannya: kerana tiada percubaan
        # membuka Spinner itu, bentuknya tidak relevan kepada laluan ini.
        fields = [
            (self.LABEL_NAMA_PESALAH, data["nama_pesalah"]),
            (self.LABEL_NO_KP_SSM_KERETA, data["no_kp_ssm_kereta"]),
            # Taman is a live-search autocomplete field, but waiting on
            # its suggestion dropdown was a dead end -- typing a short
            # partial (e.g. "T") never renders any suggestions, so the
            # field (and poskod/bandar/negeri, meant to be auto-filled
            # from picking one) ended up stuck waiting ~20s and then
            # left blank every run. Type the full value directly
            # instead -- plain send_keys() sets the value without
            # firing the live-search, so no dropdown appears to wait
            # on or dismiss.
            # >>> TIDAK LAGI DITAIP — keputusan pemilik 2026-08-05. <<<
            # Sebab penuh dalam notis_amaran_page.fill_pesalah_tab().
            # Ringkasnya: keempat-empat ini medan yang Excel kata APP isi
            # sendiri selepas Jalan dipilih. Selagi suite menaipnya, bug
            # auto-isi kategori B BERTOPENG dan `poskod` menerima nombor
            # IC yang TERCETAK pada kompaun sebenar. Kini ia DIBACA.
        ]
        # Confirmed via live run: Negeri (the last field) alone took ~27s
        # to fill, ~9x every other field -- find_element wastes its full
        # 15s presence-wait before ever trying to scroll, and by the time
        # we reach Negeri the keyboard (still up from typing Bandar) has
        # pushed it out of the rendered viewport, so that dead wait
        # always happens. Scroll proactively right before it so it's
        # already rendered and the normal presence-wait succeeds fast.
        scroll_before = {self.LABEL_PESALAH_NEGERI}
        # v3: fill_field_by_label_or_instance -- this form keeps a
        # pesalah draft across reopenings (same behavior confirmed on
        # the Notis Amaran form), so placeholders can already be gone.
        for idx, (label, value) in enumerate(fields):
            if label in scroll_before:
                self._scroll_down()
            t0 = time.time()
            self.fill_field_by_label_or_instance(label, value, instance=idx)
            print(f"  [TIMING] '{label}' filled in {time.time() - t0:.2f}s")

        # >>> A1, 2026-08-05: JALAN mesti DIPILIH, bukan sekadar DITAIP. <<<
        # Run 2026-08-05 melaporkan "JAGONG auto-isi 0 medan". Itu ARTIFAK
        # ALAT, bukan fakta app: susunan log membuktikan bacaan berlaku
        # selepas jalan hanya DITAIP, dan auto-isi app dicetuskan oleh
        # PEMILIHAN cadangan (onChangeText -> senarai -> pilih), bukan oleh
        # taipan. Laluan pemilihan yang sama sudah berjaya pada tab NOTIS,
        # jadi ia diguna semula di sini dan bukan ditulis baharu.
        # Nilai penuh dipakai sebagai penapis: ia menyempitkan senarai
        # kepada jalan yang dimaksudkan, dan padanan baris dibuat ikut
        # AWALAN JALAN supaya TAMAN kekal output DB.
        # >>> PENAPIS = AWALAN PENDEK, bukan nilai penuh. 2026-08-06. <<<
        # Run selepas A1 membuktikan pemilihan berjalan tetapi senarai
        # TIDAK PERNAH dirender:
        #     [WARN] No suggestion dropdown appeared for 'MAKLUMAT JALAN'
        #            after typing 'JALAN JAGONG 2 TEST'
        # Sebabnya sudah tertulis dalam kod ini sendiri (select_dropdown_
        # option): "a very long value fed to the RN live-search returned
        # 'Tiada rekod dijumpai'... A short prefix narrows the list while
        # still rendering the row". Tab NOTIS berjaya kerana ia menaip
        # awalan pendek ("JALAN"), bukan nilai penuh — aku menghantar
        # nilai penuh dan mematikan carian.
        # Padanan BARIS kekal ikut awalan jalan PENUH, jadi ketepatan
        # tidak dilonggarkan: hanya PENAPIS yang dipendekkan.
        _awalan = " ".join(str(data["jalan"]).split()[:2]) or data["jalan"]
        self.type_and_select_suggestion(
            self.LABEL_PESALAH_JALAN, _awalan, data["jalan"])
        self._rekod_autoisi_pesalah(data.get("jalan"))
        print("  [DAFTAR KOMPAUN] Pesalah tab filled — PASS")

    def click_seterusnya_from_pesalah(self):
        """Click Seterusnya on Pesalah tab to go to Kompaun tab.

        DEDAH DAHULU — sama seperti NotisAmaranPage.
        click_seterusnya_from_pesalah(); lihat catatan penuh di situ.
        SETERUSNYA berada di bawah lipatan dan borang ini kelas
        TRAVERSAL-FOKUS, jadi gesture skrol dalaman wait_and_click tidak
        boleh dipercayai untuk mendedahkannya."""
        print("  [DAFTAR KOMPAUN] Clicking Seterusnya to go to Kompaun tab...")
        self._dedah_sebelum_cari(self.BUTTON_SETERUSNYA, "SETERUSNYA")
        self.wait_and_click(self.BUTTON_SETERUSNYA)

    # ---- Kompaun tab ----

    def fill_kompaun_tab(self, data):
        """Fill in the Kompaun tab fields.
        data must contain: kompaun_jalan_partial, kompaun_jalan_suggestion,
        kompaun_taman, kompaun_poskod, kompaun_bandar, kompaun_negeri,
        lokasi_kesalahan, butiran_kesalahan, tempoh_notis
        """
        print("\n  [DAFTAR KOMPAUN] Filling Kompaun tab...")
        self._sahkan_skrin_kompaun(timeout=5)

        # >>> JALAN NOTIS/PREMIS DARI ORACLE. 2026-08-06. <<<
        # MBPG-TC-P-001!C9 "Jalan Premis/Notis: JALAN ULU TIRAM (pilih dari
        # dropdown; jangka auto-isi: Taman=ULU TIRAM, Bandar=PLENTONG,
        # Poskod=81800)". `jalan_premis` ialah nilai itu.
        # K-001 TIADA `jalan_premis` (laluan MySIKAP mengisi alamat sendiri;
        # C9 K-001 tidak menyebut jalan), jadi ia jatuh ke nilai device yang
        # didaftarkan — sebab itu .get() dan bukan [].
        _jalan_notis = (data.get("jalan_premis")
                        or data.get("kompaun_jalan_suggestion"))
        _sumber = ("oracle C9 'Jalan Premis/Notis'"
                   if data.get("jalan_premis") else "device (didaftarkan)")
        _awalan_n = (" ".join(str(_jalan_notis).split()[:2])
                     or data["kompaun_jalan_partial"])
        print(f"  [DAFTAR KOMPAUN] jalan Notis/Premis = {_jalan_notis!r} "
              f"(sumber: {_sumber}; penapis {_awalan_n!r})")
        self.type_and_select_suggestion(
            self.LABEL_KOMPAUN_JALAN, _awalan_n, _jalan_notis)

        # The Taman/Bandar/Negeri auto-fill triggered by the Jalan
        # selection above happens asynchronously -- give it a moment to
        # land before checking those fields below, or the guard can race
        # it (StaleElementReferenceException / not-found handled there
        # either way, but this cuts how often that race fires at all).
        import time
        time.sleep(1.5)

        # ASSERT auto-isi lawan jangkaan oracle untuk jalan Notis/Premis
        # (JANGKAAN_AUTOISI['MBPG-TC-P-001']['jalan_premis']). Sauh indeks +
        # jiran, jadi ia berfungsi walaupun placeholder sudah hilang.
        self._rekod_autoisi_pesalah(_jalan_notis)

        # Confirmed via live run: unlike the Pesalah tab, a successful tap
        # on this tab's Jalan suggestion DOES auto-fill Taman/Bandar/Negeri
        # as a side effect -- so their placeholder text is already gone by
        # the time we get here, and a plain fill_field_by_label would wait
        # out its timeout and raise. Use the _if_blank guard: fill only
        # if the placeholder is still showing (i.e. the Jalan selection
        # didn't auto-populate it), skip instantly otherwise. Poskod is
        # NOT auto-filled by the Jalan selection, so it's always filled.
        #
        # MBJB: _if_blank TIDAK CUKUP — medan ini DILUMPUHKAN pada tab
        # Kompaun (fakta device, ui_dumps\50_selepas_seterusnya.xml), dan
        # "kosong" + "dilumpuhkan" ialah dua perkara berbeza: yang pertama
        # boleh ditaip, yang kedua melontar. _if_editable membezakannya dan
        # melaporkan 'auto:KOSONG' bila app SEPATUTNYA mengisi tetapi tidak
        # (calon bug app kategori B — POSKOD, PAPAN.md §4).
        for label, kunci in ((self.LABEL_KOMPAUN_TAMAN, "kompaun_taman"),
                             (self.LABEL_KOMPAUN_POSKOD, "kompaun_poskod"),
                             (self.LABEL_KOMPAUN_BANDAR, "kompaun_bandar"),
                             (self.LABEL_KOMPAUN_NEGERI, "kompaun_negeri")):
            if data.get(kunci) is None:
                continue          # medan auto-isi — lihat nota di atas
            self.fill_field_by_label_if_editable(
                label, data[kunci], sumber_excel="MBPG-TC-*!C11")
        # >>> BORANG INI KELAS TRAVERSAL-FOKUS — DIBETULKAN 2026-08-17. <<<
        # LOKASI dan BUTIRAN KESALAHAN berada DI BAWAH LIPATAN pada tab
        # Kompaun, dan tab ini menolak swipe. Larian P-001 pada
        # 2026-08-17 15:11 mencatat
        #
        #   [SKROL] AMARAN: swipe DIHANTAR tetapi ANJAKAN 0px
        #           (dikongsi=17, bergerak=0)
        #
        # dua kali, kemudian mati dengan `Element not found after 15s`
        # pada BUTIRAN KESALAHAN. Setiap cubaan skrol dalam
        # find_element() dijamin sifar di sini, tetapi tetap membayar
        # tempoh tunggunya.
        #
        # Borang NOTIS menyelesaikan masalah SAMA ini pada 2026-08-05
        # (notis_amaran_page.py:526-538). Pembetulan itu tidak pernah
        # dibawa ke borang ini kerana laluan P/K tidak pernah dipandu
        # sejauh ini sebelum mod sebenar wujud — sweep berhenti sebelum
        # medan ini, dan fasa fill-only tidak pernah menyerah.
        #
        # `reveal_below_fold` (melalui `_dedah_sebelum_cari`) ialah
        # SATU-SATUNYA mekanisme yang menggerakkan borang ini. Kegagalan
        # pendedahan TIDAK maut: kita jatuh ke carian biasa, corak yang
        # sama seperti `pilih_spinner_kod()`.
        _medan_kesalahan = ((self.LABEL_LOKASI_KESALAHAN,
                             "lokasi_kesalahan"),
                            (self.LABEL_BUTIRAN_KESALAHAN,
                             "butiran_kesalahan"))
        for _label, _kunci in _medan_kesalahan:
            self.isi_medan_kesalahan(_label, data[_kunci])
        # Tempoh: force-clear + verify + 0-21 range-check. A stale
        # pre-filled value surviving el.clear() (e.g. '90') would trip the
        # field's own validation and silently block SETERUSNYA -- the root
        # cause of the 17-min Sitaan hang. See _set_tempoh_verified.
        # >>> TEMPOH: locator lama menyasarkan TAJUK SEKSYEN. <<<
        # `LABEL_TEMPOH_NOTIS = "MAKLUMAT KOMPAUN"` ialah tajuk seksyen
        # (TextView), bukan medan. Kesannya dilog sebagai
        # `[TEMPOH] field not locatable on this variant -- leaving
        # as-is`, dan medan kekal KOSONG — kemudian app menolak
        # perpindahan ke tab Penerima dengan
        # `Ralat | Sila isi Tempoh Notis` (device, 2026-08-17).
        #
        # Placeholder medan sebenar ialah `Tempoh Kompaun` (dump
        # docs/recon/tabkompaun-C-kompaun-mula.xml, EditText y=2041).
        # Guna rutin berbukti yang sama seperti medan kesalahan: ia
        # mengesahkan nilai mendarat dan MELONTAR kalau tidak.
        _tempoh = "".join(c for c in str(data.get("tempoh_notis") or "")
                          if c.isdigit())
        if _tempoh:
            self._isi_tempoh_berbukti(_tempoh, data)
        else:
            self._apply_tempoh_from_data(data)


        # >>> SEMAKAN AKHIR — medan kesalahan MESTI masih berisi. <<<
        # Diukur 2026-08-17: `isi_medan_kesalahan()` mengesahkan setiap
        # nilai mendarat (baca-balik cubaan 1), tetapi menjelang tab ini
        # selesai kedua-duanya KOSONG semula. Sesuatu antara pengisian
        # dan penghujung tab membuangnya; mekanismenya BELUM dicirikan.
        #
        # Rekod N tidak terjejas — `PGP02N260817008` membawa
        # jalan1='DEPAN KEDAI' dan keterangan penuh dalam DB production —
        # jadi ini khusus skrin `Paparan Kompaun`.
        #
        # Sehingga puncanya difahami, betulkan dengan MENYEMAK, bukan
        # dengan mengandaikan: isi semula apa yang hilang, dan biarkan
        # `isi_medan_kesalahan` LONTAR kalau ia masih hilang. Kompaun
        # production dengan medan kesalahan kosong tidak boleh keluar
        # dari sini secara senyap.
        self._sahkan_medan_kesalahan(_medan_kesalahan, data)

        print("  [DAFTAR KOMPAUN] Kompaun tab filled — PASS")

    # ---- MBJB: tempoh hanya ditaip bila Excel membekalkannya --------------
    # DEV FIXING LIST MBJB baris 41 + 42 (DONE): TEMPOH KOMPAUN kini
    # mempunyai nilai default -- Notis 14 hari, Kompaun 21 hari -- dan boleh
    # diedit. Sel C9 MBJB TIDAK menyebut tempoh untuk mana-mana TC create.
    # Peraturan Keras #5: jangan taip nilai yang Excel tidak bekalkan. Jadi
    # bila kunci 'tempoh_notis' tiada, kita BIARKAN default app dan CATAT
    # nilai yang sebenarnya ada dalam medan itu, supaya laporan menunjukkan
    # apa yang dihantar. Bila kunci ADA, tingkah laku MBIP kekal 100%:
    # force-clear + set + read-back + semakan julat.
    def _apply_tempoh_from_data(self, data):
        if "tempoh_notis" in data and str(
                data["tempoh_notis"]).strip() != "":
            self._set_tempoh_verified(data["tempoh_notis"])
            return
        el = self._locate_tempoh_el()
        current = None
        if el is not None:
            try:
                current = el.text
            except Exception:                                # noqa: BLE001
                current = None
        print(f"  [TEMPOH] Excel senyap tentang tempoh -- mengekalkan "
              f"default app: {current!r} (tidak ditaip; lihat Peraturan #5)")
        # SAHKAN-DEVICE: default sebenar pada MBJB (dijangka 14 pada borang
        # Notis, 21 pada borang Kompaun) dan julat sah yang diterima. Julat
        # 0-21 dalam _set_tempoh_verified datang dari MBIP.

    def fill_kompaun_code_fields(self, data):
        """Pilih ketiga-tiga dropdown kod kompaun (borang Pelbagai/Lesen/Sitaan).

        Setiap tingkat dibuka dengan mengetuk SPINNER yang dikenal pasti
        melalui LABEL TextView yang mendahuluinya, kemudian nilai dipilih
        daripada dialog `select_dialog_listview` dengan skrol PERLAHAN.
        Tiada satu pun daripada tiga tingkat ini bergantung pada teks
        'PILIH ...' — lihat blok komen pada SPINNER_TEXT1 untuk sebabnya.

        Kegagalan tingkat 2/3 dilempar dengan diagnosis kategori D yang
        menyatakan nilai tingkat 1 yang dipilih dan nilai SEBENAR yang ada
        dalam DB. Tiada skip dicipta.
        """
        print("  [DAFTAR KOMPAUN] Selecting kompaun code dropdowns...")
        nilai1 = data["keterangan_kod_kompaun"]
        self.pilih_spinner_kod(1, self.LABEL_TIER1, "KETERANGAN KOD KOMPAUN",
                               nilai1, nilai1)
        self.pilih_spinner_kod(2, self.LABEL_TIER2, "KOD AKTA",
                               data["kod_akta"], nilai1)
        self.pilih_spinner_kod(3, self.LABEL_TIER3, "KESALAHAN KOMPAUN",
                               data["kesalahan_kompaun"], nilai1)
        # Bukti borang benar-benar kembali selepas tingkat terakhir.
        # TIER3_CONFIRM di-override oleh SitaanPage (label PILIH KADAR
        # DENDA) kerana kamera borang itu berada di bawah seksyen Barang.
        self._sahkan_tier3_kembali()
        self.fill_kadar_denda(data["kadar_denda"])
        print("  [DAFTAR KOMPAUN] Kompaun code dropdowns selected — PASS")

    # The element proving the tier-3 option list closed. OPEN CAMERA on
    # the Pelbagai/Lesen forms; the Sitaan form (whose camera sits
    # further down, past the Barang section) overrides this with the
    # kadar amount field, which renders right below the dropdowns
    # (confirmed live: OPEN CAMERA never rendered there in time).
    TIER3_CONFIRM = BUTTON_OPEN_CAMERA

    def _sahkan_tier3_kembali(self):
        """Sahkan borang kembali (TIER3_CONFIRM kelihatan) selepas tingkat
        3 dipilih -- SEBELUM mengaku "dialog masih terbuka".

        TIER3_CONFIRM lalai (OPEN CAMERA) DISAHKAN berada jauh di bawah
        tingkat 3 pada tab NOTIS (dump 51 nod 22 pada borang Notis Amaran
        yang berkongsi struktur; y~3924, jauh melepasi sempadan viewport
        boleh-skrol y~1596 yang logcat sahkan -- recon\\PAPAN.md blok
        "MULA DI SINI"). Pemeriksaan bertelanjang `is_element_present()`
        TIDAK skrol, jadi ia boleh melaporkan "borang tidak kembali"
        semata-mata kerana belum diskrol turun -- satu kegagalan PALSU
        yang bersembunyi di sebalik mesej yang kedengaran sah ("dialog
        mungkin masih terbuka").

        >>> TANDA TANGAN DIBETULKAN 2026-07-31 (Loh: API makmingg ialah
        otoriti). <<< Versi pertama memanggil
        `self.scroll_in_viewport(locator, timeout=8)` -- TIDAK PADAN
        dengan tandatangan SEBENAR
        `scroll_in_viewport(direction="down", percent=0.3, context="")`
        (base_page.py:384). Balutan `hasattr()` tidak melindungi (kaedah
        itu MEMANG wujud), jadi ia akan menghantar `locator` sebagai
        `direction` -- meletup atau skrol ke arah karut secara senyap,
        menyamar sebagai kegagalan locator. Kaedah yang BETUL untuk
        "cari elemen, skrol kalau perlu" ialah
        `find_with_scroll(locator, ...)` (base_page.py:531), yang
        memulangkan elemen atau `None`. `hasattr()` DIBUANG -- API
        makmingg disahkan wujud, bukan diandaikan.

        >>> SEMAKAN TANPA GERAK ISYARAT DAHULU — 2026-08-11. <<<
        find_with_scroll() menyapu. Pada borang Kompaun sapuan TIDAK
        menatal, ia menukar TAB — jadi semakan ini boleh menghantar
        borang ke tab lain lalu melaporkan "borang tidak kembali",
        iaitu kegagalan yang ia sendiri sebabkan. Diperhati pada
        K-001 dan pada pathfinder pra-sweep, dua-dua kali identik,
        sedangkan pemilihan tingkat 3 itu sendiri berjaya.

        Soalan sebenar yang perlu dijawab ialah "adakah modal sudah
        tertutup dan borang kembali?" — dan pokok skrin sudah
        mengandungi jawapannya. `page_source` dibaca tanpa menyentuh
        apa-apa; hanya kalau ia tidak meyakinkan barulah laluan skrol
        lama dicuba.
        """
        try:
            sumber = self.driver.page_source
        except Exception:                                    # noqa: BLE001
            sumber = ""
        # Modal terbuka = backdrop skrin penuh hadir. Ketiadaannya,
        # digandingkan dengan medan borang yang kelihatan, ialah bukti
        # borang kembali.
        modal_tertutup = "modal-backdrop" not in sumber
        borang_ada = any(t in sumber for t in
                         ("KESALAHAN KOMPAUN", "KOD AKTA",
                          "PILIH KADAR DENDA", "Lokasi Kesalahan"))
        if modal_tertutup and borang_ada:
            return

        el = self.find_with_scroll(self.TIER3_CONFIRM, timeout_each=3)
        assert el is not None, \
            (f"FAIL: borang tidak kembali selepas tingkat 3 "
             f"(modal_tertutup={modal_tertutup} borang_ada={borang_ada}, "
             f"dan TIER3_CONFIRM tidak dijumpai selepas skrol) — dialog "
             f"mungkin masih terbuka")

    def _find_kadar_denda_el(self, expected=None):
        """Locate the Kadar Denda amount EditText: by its ENTER AMAUN
        hint first, positionally (label-sibling) as fallback in case a
        form variant gives the field a different hint. The hint
        attribute persists regardless of the field's current text, so
        this works before and after typing."""
        try:
            return self.find_element(self.FIELD_KADAR_DENDA, timeout=8)
        except Exception:
            print("  [DAFTAR KOMPAUN] ENTER AMAUN hint not found -- "
                  "falling back to the label-sibling EditText")
            # following:: (any following node), NOT following-sibling --
            # on the Sitaan form the amount EditText is nested inside a
            # sibling container, so the sibling axis misses it
            # (confirmed live: label at y999, EditText '0' at y1071,
            # sibling lookup empty).
            fallback = (AppiumBy.XPATH,
                        '//android.widget.TextView[starts-with(@text,'
                        '"PILIH KADAR DENDA")]'
                        '/following::android.widget.EditText[1]')
            try:
                return self.find_element(fallback, timeout=10)
            except Exception:
                # Last tier (Sitaan): the label can sit ABOVE the
                # current viewport where find_element's downward scroll
                # never returns; the amount field itself is the one
                # EditText preset to exactly "0" on this screen
                # (confirmed via debug_dropdown_confirm.xml).
                print("  [DAFTAR KOMPAUN] falling back to the preset-'0' "
                      "EditText for Kadar Denda")
                values = ["0"] + ([expected] if expected else [])
                pattern = "|".join(values)
                zero = (AppiumBy.ANDROID_UIAUTOMATOR,
                        f'new UiSelector().className('
                        f'"android.widget.EditText")'
                        f'.textMatches("^({pattern})$")')
                return self.find_element(zero, timeout=10)

    def fill_kadar_denda(self, kadar_denda):
        """Fill the Kadar Denda amount field (see FIELD_KADAR_DENDA:
        a numeric EditText, not a dropdown, despite its 'PILIH' label).

        Strips a leading 'RM' from the test-script value ("RM2000") --
        the currency unit is already part of the on-screen label
        "(RM)" and the field is an amount input. Uses mobile: type like
        the app's other numeric fields, which reject plain send_keys().

        Type-verify-retry: confirmed via live adb dump that a typed
        amount can silently fail to stick (the clear() registered but
        the field was back to its ENTER AMAUN placeholder afterwards --
        the RN re-render triggered by clear() can swallow the
        keystrokes that race it). Read the value back after typing and
        retype if it didn't land."""
        amount = kadar_denda.strip()
        if amount.upper().startswith("RM"):
            amount = amount[2:].strip()
        print(f"  [DAFTAR KOMPAUN] Entering Kadar Denda: {amount}")
        import time
        # v3 (Sitaan): the amount field can be entirely BELOW the fold
        # and unrendered on the gesture-resistant form variants (all
        # three locators missed live) -- reveal it via focus traversal
        # first.
        zero_probe = (AppiumBy.ANDROID_UIAUTOMATOR,
                      f'new UiSelector().className('
                      f'"android.widget.EditText")'
                      f'.textMatches("^(0|{amount})$")')
        if (not self.is_element_present(self.FIELD_KADAR_DENDA, timeout=3)
                and not self.is_element_present(zero_probe, timeout=2)):
            print("  [DAFTAR KOMPAUN] Kadar field below the fold -- "
                  "focus-traversal reveal...")
            self.reveal_below_fold(zero_probe)
        last = None
        for attempt in range(3):
            el = self._find_kadar_denda_el(expected=amount)
            el.click()
            el.clear()
            time.sleep(0.3)
            # send_keys dahulu; medan amaun berangka jatuh ke mobile: type
            # sendiri melalui _emit_text kalau ia menolak send_keys.
            self._emit_text(el, amount, False)
            self._hide_keyboard_if_shown()
            try:
                last = self._find_kadar_denda_el(expected=amount).text
            except Exception:
                last = None
            if last is not None and amount in last:
                print(f"  [DAFTAR KOMPAUN] Kadar Denda verified: "
                      f"'{last}' — PASS")
                return
            print(f"  [DAFTAR KOMPAUN] Kadar Denda didn't stick (field "
                  f"shows {last!r}, attempt {attempt + 1}/3) -- retrying...")
        raise TimeoutException(
            f"Kadar Denda '{amount}' never stuck after 3 attempts "
            f"(field shows {last!r})")

    # The in-app camera's mode label -- present the whole time the
    # camera is open, gone once it closes back to the form. Used to
    # verify the tick-confirm tap actually registered (confirmed via
    # live dump: the tick tap can silently no-op, leaving the camera
    # open on top of the form -- every later step then fails while
    # take_photos had already reported success).
    CAMERA_OPEN_INDICATOR = (AppiumBy.ANDROID_UIAUTOMATOR,
                             'new UiSelector().textMatches("(?i)\s*FLASH\s+OFF\s*")')

    def take_photos(self, count=3):
        """Open the in-app camera, snap `count` photos, confirm with the
        tick, and verify the camera closed.

        Pacing is load-bearing -- confirmed via live adb experiments:
        each capture takes a couple of seconds during which the camera
        silently DROPS every tap, so 1s pacing lost some snaps and
        always lost the tick (which only registers once the last
        capture has settled; with a fresh settled capture it closes the
        camera reliably). Also confirmed: photos from a session exited
        via the close (X) icon show in the form's counter but do NOT
        satisfy the Trafik form's GAMBAR MESTI DIAMBIL validation --
        only a tick-closed session does, so the X-exit is strictly a
        last resort. The form's 'GAMBAR TELAH DIAMBIL: N/6' counter is
        read back afterwards as ground truth."""
        print(f"  [DAFTAR KOMPAUN] Opening camera for {count} photo(s)...")
        # >>> DIBAIKI 2026-08-19 — larian 15:34 (borang P). <<<
        # OPEN CAMERA berada di bawah lipatan dan borang ini menolak
        # swipe ([SKROL] anjakan 0px), jadi wait_and_click gagal selepas
        # 1 cubaan skrol. notis_amaran_page sudah lama ada sandaran
        # reveal_below_fold (traversal fokus) — larian pagi membuktikan
        # 'laluan 2 BERJAYA' di sana. Corak sama dipakai di sini.
        if not self.is_element_present(self.BUTTON_OPEN_CAMERA, timeout=4):
            print("  [DAFTAR KOMPAUN] OPEN CAMERA tidak kelihatan -- "
                  "reveal_below_fold() traversal fokus...")
            self.reveal_below_fold(self.BUTTON_OPEN_CAMERA)
        self.wait_and_click(self.BUTTON_OPEN_CAMERA)
        import time
        time.sleep(2)

        # >>> DIBETULKAN 2026-08-12, disahkan pada peranti. <<<
        # wait_and_click() menghantar ACTION_CLICK, yang Pressable
        # tersuai app ini NO-OP SENYAP. Guna tap koordinat mentah.
        for i in range(count):
            print(f"  [DAFTAR KOMPAUN]   Snapping photo {i+1}/{count}")
            self.tap_element(self.find_clickable(self.BUTTON_SNAP))
            time.sleep(3)

        print("  [DAFTAR KOMPAUN] Confirming photos with tick icon...")
        # Jeda tambahan sebelum tick PERTAMA, dan pemulihan gambar
        # PENGENDAP kalau tick diabaikan. Menekan tick berulang kali
        # TIDAK berkesan -- disahkan pada peranti: tick diabaikan oleh
        # keempat-empat mekanisme Appium DAN oleh adb input tap,
        # walaupun enabled=clickable=displayed=true. Ia hanya menerima
        # tekanan selepas tangkapan SEGAR mengendap.
        # Lihat notis_amaran_page.take_photos() untuk nota penuh.
        time.sleep(4)
        closed = False
        diambil = count
        for attempt in range(3):
            el = self.find_clickable(self.BUTTON_TICK_CONFIRM)
            self.tap_element(el)
            time.sleep(2.5)
            if not self.is_element_present(self.CAMERA_OPEN_INDICATOR,
                                           timeout=3):
                closed = True
                break
            if attempt < 2 and diambil < 6:
                diambil += 1
                print(f"  [DAFTAR KOMPAUN] tick diabaikan (cubaan "
                      f"{attempt + 1}/3) -- gambar pengendap "
                      f"({diambil}/6) supaya tick menerima tekanan")
                self.tap_element(self.find_clickable(self.BUTTON_SNAP))
                time.sleep(4)
            else:
                print(f"  [DAFTAR KOMPAUN] tick diabaikan (cubaan "
                      f"{attempt + 1}/3) -- had 6 gambar, tap sahaja")
        if closed:
            self._log_gambar_counter()
            print("  [DAFTAR KOMPAUN] Photos taken — camera closed — PASS")
            return

        # ASCII-only print text: the camera's close glyph (U+2715) is
        # not representable in the Windows cp1252 console -- printing
        # it raises UnicodeEncodeError and aborts this method (bit us
        # live: the fallback below never ran and the camera stayed
        # open). The glyph only appears inside locator strings, which
        # go over the wire, never to the console.
        print("  [DAFTAR KOMPAUN] WARNING: tick never registered -- "
              "closing the camera via its close (X) icon and continuing "
              "without confirmed photos")
        x_locator = (AppiumBy.ANDROID_UIAUTOMATOR,
                     'new UiSelector().description("✕")')
        try:
            el = self.find_element(x_locator, timeout=5)
            self.tap_element(el)
        except Exception:
            print("  [DAFTAR KOMPAUN] Close icon not found -- pressing "
                  "device Back")
            self.press_back()
        time.sleep(1)
        self._log_gambar_counter()

    def _log_gambar_counter(self):
        """Log the form's 'GAMBAR TELAH DIAMBIL: N/6' counter -- the
        only readable ground truth for how many photos actually got
        attached (the camera's own UI is a static native surface that
        reflects nothing in the accessibility tree)."""
        counter = (AppiumBy.ANDROID_UIAUTOMATOR,
                   'new UiSelector().textMatches("(?i).*GAMBAR\s+TELAH\s+DIAMBIL.*")')
        try:
            txt = self.find_element(counter, timeout=5).text
            print(f"  [DAFTAR KOMPAUN] Photo counter: {txt}")
        except Exception:
            print("  [DAFTAR KOMPAUN] WARNING: photo counter not readable")

    def click_seterusnya_from_kompaun(self):
        """Click Seterusnya on Kompaun tab to go to Penerima tab.

        Fallback for the Trafik form (never reached on Pelbagai, which
        succeeds on the primary path): confirmed via live run + adb
        experiments that this form resists the standard scroll gesture
        -- only a slow low-start swipe moves it -- and its SETERUSNYA
        can render as a plain TextView (text), not just the
        accessibility id used everywhere else."""
        print("  [DAFTAR KOMPAUN] Clicking Seterusnya to go to Penerima tab...")
        try:
            self.wait_and_click(self.BUTTON_SETERUSNYA)
            return
        except TimeoutException:
            print("  [DAFTAR KOMPAUN] SETERUSNYA not reachable via the "
                  "standard path -- trying slow low-start swipes...")
        import time
        candidates = [
            self.BUTTON_SETERUSNYA,
            (AppiumBy.ANDROID_UIAUTOMATOR,
             'new UiSelector().textMatches("(?i)\s*SETERUSNYA\s*")'),
        ]
        for _ in range(6):
            for loc in candidates:
                if self.is_element_present(loc, timeout=2):
                    el = self.find_element(loc, timeout=3)
                    self.tap_element(el)
                    return
            # Peraturan #3: koordinat diderivasi dari tetingkap.
            self._swipe_perlahan_naik(dari=0.90, ke=0.33, tempoh=600)
            time.sleep(0.5)
        dump_path = "debug_seterusnya_kompaun.xml"
        try:
            with open(dump_path, "w", encoding="utf-8") as f:
                f.write(self.driver.page_source)
            print(f"  [DAFTAR KOMPAUN] DEBUG: page source dumped to "
                  f"{dump_path}")
        except Exception:
            pass
        raise TimeoutException(
            f"SETERUSNYA not found on the Kompaun tab by accessibility id "
            f"or text, even after slow swipes; see {dump_path}")

    # ---- Penerima tab ----

    def fill_penerima_tab(self, data):
        """Fill in the Penerima tab fields and draw signature.
        data must contain: no_pembantu_penguatkuasa, nama_penerima,
        no_ic_penerima
        """
        print("\n  [DAFTAR KOMPAUN] Filling Penerima tab...")
        # Same issue confirmed in notis_amaran_page.py: Seterusnya here
        # pushes a new screen with no "PENERIMA" accessibility id, so
        # TAB_PENERIMA never matches. Check for a field that's actually
        # on this screen instead.
        pembantu_locator = (
            AppiumBy.ANDROID_UIAUTOMATOR,
            f'new UiSelector().text("{self.LABEL_NO_PEMBANTU_PENGUATKUASA}")')
        ada_pembantu = self.is_element_present(pembantu_locator, timeout=5)
        if not ada_pembantu:
            # >>> DIBETULKAN 2026-08-12. <<< Pada MBPG 2.1.21, Paparan
            # Penerima borang NOTIS tidak membawa 'NO PEMBANTU
            # PENGUATKUASA' langsung (dump recon-serah: hanya OPEN
            # SIGNATURE / Nama Penerima / No IC Penerima / MENYERAHKAN).
            # Menyauh skrin pada medan itu menjadikan skrin yang SEDANG
            # dipapar dilaporkan "tidak kelihatan". Cuba sauh kedua
            # sebelum menyimpulkan kegagalan.
            if self.is_element_present(self.FIELD_OPEN_SIGNATURE,
                                       timeout=5):
                print("  [DAFTAR KOMPAUN] 'NO PEMBANTU PENGUATKUASA' "
                      "tiada pada varian ini — skrin Penerima disahkan "
                      "melalui OPEN SIGNATURE")
            else:
                # Seterusnya may have been rejected by form validation --
                # the app reports that via a native alert (e.g. "RALAT /
                # SILA PILIH BANDAR DARIPADA SENARAI."). Drain it so the
                # actual reason lands in the log instead of a bare
                # "screen not visible".
                if self.dismiss_native_alerts(first_timeout=3,
                                              context="Penerima arrival"):
                    raise AssertionError(
                        "Penerima screen not visible after clicking "
                        "Seterusnya -- a validation alert was shown (its "
                        "message is logged above); the Kompaun tab "
                        "rejected a field value")
                raise AssertionError(
                    "Penerima screen not visible after clicking "
                    "Seterusnya")

        if ada_pembantu:
            self.fill_field_by_label(self.LABEL_NO_PEMBANTU_PENGUATKUASA,
                                     data["no_pembantu_penguatkuasa"])

        print("  [DAFTAR KOMPAUN] Opening signature pad...")
        self.wait_and_click(self.FIELD_OPEN_SIGNATURE)
        import time
        time.sleep(1)
        self._draw_signature()

        print("  [DAFTAR KOMPAUN] Closing signature popup...")
        closed = self.close_popup_by_icon(timeout=3)
        if not closed:
            # Tap di luar popup. Peraturan #3: pecahan tetingkap, bukan
            # (540,300) yang mengandaikan resolusi tertentu.
            self.driver.tap([self._titik(0.50, 0.12)])
        time.sleep(1)

        self._fill_penerima(self.LABEL_NAMA_PENERIMA,
                            data.get("nama_penerima"), "NAMA PENERIMA",
                            "nama_penerima")
        self._fill_penerima(self.LABEL_NO_IC_PENERIMA,
                            data.get("no_ic_penerima"), "NO IC PENERIMA",
                            "no_ic_penerima")

        print("  [DAFTAR KOMPAUN] Penerima tab filled — PASS")

    def _fill_penerima(self, label, value, nama_papar, medan):
        """Isi medan penerima, dan log bila nilainya penanda.

        Medan yang skrip Excel tidak bekalkan diisi dengan penanda
        (excel_data.BLANK_MARKER teks / BLANK_MARKER_IC berangka bagi
        MEDAN_BERANGKA), bukan dibiarkan kosong. Penanda keluar pada
        kertas cetak, jadi sesiapa yang memegang cetakan nampak terus
        bahawa nilainya tiada asas dalam Excel. Medan kosong sebenar tak
        dapat dibezakan daripada medan gagal diisi -- itulah sebabnya
        nilai rekaan seperti "Buruh En Saiful" boleh bertahan berbulan.
        Read-back di bawah mengesahkan penanda benar masuk."""
        # testdata.excel_data ialah modul MBJB (nilai dari workbook).
        # MBPG memandu dari oracle dan tiada modul itu; import keras
        # memecahkan tab Penerima sepenuhnya (ModuleNotFoundError).
        try:
            from testdata.excel_data import (ialah_penanda,   # noqa: F401
                                             penanda_untuk)
        except ModuleNotFoundError:
            def ialah_penanda(_v):
                return False

            def penanda_untuk(_m):
                return None
        is_marker = ialah_penanda(value)
        expected = penanda_untuk(medan) if is_marker else value
        if is_marker:
            print(f"  [DAFTAR KOMPAUN] {nama_papar}: menaip penanda "
                  f"{expected!r} — Excel tidak membekalkan nilai")
        el = self.fill_field_by_label(label, value)
        got = self._safe_text(el)
        print(f"  [DAFTAR KOMPAUN] {nama_papar}: medan = {got!r} selepas "
              f"taip (sepatutnya {expected!r})")
        if is_marker and self._norm(got) != self._norm(expected):
            print(f"  [DAFTAR KOMPAUN] WARNING: {nama_papar} tidak menerima "
                  f"penanda {expected!r} — nilai sebenar {got!r}")

    def _draw_signature(self):
        """Draw a simple signature using W3C Actions.

        Peraturan #3: titik lejang diderivasi daripada get_window_size(),
        bukan (400,1200)..(800,1220) yang dihardcode dahulu. Pecahan di
        bawah menghasilkan titik yang SAMA pada device semasa (1080x2460,
        dibaca dari ui_dumps\\40_skrin_utama.xml) dan kekal berada dalam
        pad tandatangan pada resolusi lain.
        """
        print("  [DAFTAR KOMPAUN] Drawing signature...")
        from selenium.webdriver.common.action_chains import ActionChains
        from selenium.webdriver.common.actions import interaction
        from selenium.webdriver.common.actions.action_builder import ActionBuilder
        from selenium.webdriver.common.actions.pointer_input import PointerInput

        actions = ActionChains(self.driver)
        pointer = PointerInput(interaction.POINTER_TOUCH, "finger")
        actions.w3c_actions = ActionBuilder(self.driver, mouse=pointer)
        lejang = [(0.370, 0.488), (0.463, 0.467), (0.556, 0.508),
                  (0.648, 0.480), (0.741, 0.496)]
        titik = [self._titik(fx, fy) for fx, fy in lejang]
        actions.w3c_actions.pointer_action.move_to_location(*titik[0])
        actions.w3c_actions.pointer_action.pointer_down()
        for x, y in titik[1:]:
            actions.w3c_actions.pointer_action.move_to_location(x, y)
        actions.w3c_actions.pointer_action.release()
        actions.perform()
        # >>> BUKTI PAD — 2026-08-19, arahan CEO. <<<
        # Ketiga-tiga cetakan K run 3 tidak menunjukkan tandatangan
        # yang dilukis (blok noise kelabu). Dua punca mungkin dan
        # TIADA bukti untuk membezakannya: (a) lukisan melekat tetapi
        # pipeline cetakan app merosakkannya (D-10), atau (b) lejang
        # W3C tidak register pada pad RN dan tandatangan kosong.
        # Screenshot pad SEBELUM popup ditutup ialah pembeza muktamad.
        self._tangkap_pad_tandatangan("K")

    def _tangkap_pad_tandatangan(self, jenis):
        import os
        import time as _t
        try:
            folder = os.path.join("reports", "forensik")
            os.makedirs(folder, exist_ok=True)
            laluan = os.path.join(
                folder, f"tandatangan_pad_{jenis}_"
                        f"{_t.strftime('%Y%m%d-%H%M%S')}.png")
            self.driver.get_screenshot_as_file(laluan)
            print(f"  [TANDATANGAN] bukti pad -> {laluan}")
        except Exception as e:                               # noqa: BLE001
            print(f"  [TANDATANGAN] tangkapan pad gagal "
                  f"({type(e).__name__}) — diteruskan")

    def click_menyerahkan(self):
        """Click the Menyerahkan button.

        Confirmed via live run (Notis Amaran flow): MENYERAHKAN sits
        right after the last typed field (NO IC PENERIMA), so the
        on-screen keyboard is still covering it at this point --
        computing a raw coordinate tap from the element's rect() lands
        on the keyboard, not the button. Explicitly hide the keyboard
        first, then use tap_element (raw coordinate tap) rather than
        wait_and_click/el.click() -- same reasoning as the dropdown/
        suggestion rows elsewhere in this file, since this app's custom
        Pressables silently no-op on the accessibility ACTION_CLICK a
        plain el.click() sends.
        """
        print("  [DAFTAR KOMPAUN] Clicking Menyerahkan...")
        try:
            if self.driver.is_keyboard_shown():
                self.driver.hide_keyboard()
                import time
                time.sleep(0.5)
        except Exception:
            pass
        el = self.find_clickable(self.BUTTON_MENYERAHKAN)
        self.tap_element(el)

    def confirm_and_submit(self):
        """Handle 'Simpan maklumat ini?' popup and click Hantar."""
        print("\n  [DAFTAR KOMPAUN] Confirmation popup...")
        assert self.is_element_present(self.POPUP_SIMPAN_MAKLUMAT, timeout=10), \
            "Confirmation popup not displayed"
        print("  [DAFTAR KOMPAUN] Confirmation popup visible — PASS")
        print("  [DAFTAR KOMPAUN] Clicking Hantar...")
        # tap_element, not wait_and_click -- same custom-Pressable
        # no-op issue as MENYERAHKAN above.
        el = self.find_clickable(self.BUTTON_HANTAR)
        self.tap_element(el)

    def is_submission_successful(self):
        """Wait for success popup after submission (aliran Pelbagai, P-001).

        Laluan ini sudah memakai lapisan kegagalan-dahulu
        (`is_berjaya_message_visible`), jadi ia TIDAK mengalami PASS palsu
        B-1. Yang HILANG ialah `read_record_number()` pada cabang kedua:
        create yang berjaya tanpa popup resit menghasilkan lejar KOSONG
        dan keadaan (b)/(c) tidak dapat dibezakan. Diselaraskan dengan
        laluan Trafik: teks alert dibaca dahulu, penafian disemak dahulu,
        nombor rekod dibaca pada SETIAP laluan kejayaan."""
        if self.is_element_present(self.POPUP_CETAK_KOMPAUN_PELBAGAI, timeout=30):
            print("  [DAFTAR KOMPAUN] Submission successful — receipt popup visible — PASS")
            self.last_record_number = None
            self.read_record_number()  # capture no_kompaun before closing
            self.close_success_popup()
            return True

        v = adili_alert_hantar(self, "DAFTAR KOMPAUN submit", first_timeout=5)
        if v["ditolak"]:
            self._dump_mbjb("pelbagai_submit_ditolak.xml")
            print(f"  [DAFTAR KOMPAUN] >>> PENGHANTARAN DITOLAK <<< alert "
                  f"MENAFIKAN kejayaan: {v['teks']!r} — FAIL")
            return False
        if v["disahkan"]:
            print(f"  [DAFTAR KOMPAUN] Submission successful — teks "
                  f"mengesahkan kejayaan; nombor rekod = "
                  f"{v['nombor'] or '(tidak terbaca — keadaan (c))'} — PASS")
            return True
        if v["nombor"]:
            print(f"  [DAFTAR KOMPAUN] Submission successful — tiada teks "
                  f"kejayaan (alert: {v['teks']!r}) tetapi nombor rekod "
                  f"{v['nombor']} TERBACA (keadaan (b)) — PASS")
            return True
        print("  [DAFTAR KOMPAUN] WARNING: Could not confirm submission "
              f"success — teks alert: {v['teks']!r}, nombor rekod tidak "
              f"terbaca")
        return False

    def close_success_popup(self):
        """Close the success/receipt popup."""
        print("  [DAFTAR KOMPAUN] Closing success popup...")
        closed = self.close_popup_by_icon(timeout=3)
        if not closed:
            print("  [DAFTAR KOMPAUN] No close icon found, pressing Back...")
            self.press_back()

    # ==================================================================
    # MBJB-ONLY CONTROLS
    #
    # Everything below this line has NO counterpart in the MBIP suite.
    # Each locator is a best guess built from the DEV FIXING LIST /
    # Training Feedback / Excel wording -- NOT from an MBJB UI dump. They
    # all carry SAHKAN-DEVICE and all fail LOUDLY-BUT-SOFTLY: they return
    # False/None and print what they looked for, so a missing control
    # reads as an unverified control, never as a passed step.
    #
    # >>> AUDIT SKROL 2026-07-31 (azharMadi). <<< Setiap "not found on
    # this form" di bawah dahulunya is_element_present() BERTELANJANG --
    # tiada skrol dahulu. Pada borang yang memanjang 2.5+ skrin (fakta
    # device, recon\PAPAN.md "MULA DI SINI"), itu bermakna "kawalan tiada
    # pada borang ini" dan "kawalan ada tetapi di bawah lipatan" tidak
    # dapat dibezakan -- dan yang pertama SALAH lebih kerap daripada
    # kelihatan. _ada_selepas_skrol() di bawah skrol-dan-cari dahulu
    # melalui find_with_scroll() (base_page.py:531, tandatangan disahkan
    # 2026-07-31) sebelum kaedah di bawah mengaku kawalan tiada.
    # ==================================================================

    def _ada_selepas_skrol(self, loc, timeout=4):
        """is_element_present(loc), tetapi skrol-dan-cari dahulu melalui
        find_with_scroll() (base_page.py:531) sebelum mengaku False.

        >>> TANDA TANGAN DIBETULKAN 2026-07-31 (Loh: API makmingg ialah
        otoriti). <<< Versi pertama memanggil
        `self.scroll_in_viewport(loc, timeout=timeout)` di sebalik
        `hasattr()` -- TIDAK PADAN dengan tandatangan SEBENAR
        `scroll_in_viewport(direction="down", percent=0.3, context="")`.
        `hasattr()` tidak melindungi (kaedah itu MEMANG wujud); `loc`
        akan masuk sebagai `direction` -- meletup atau skrol arah karut
        secara senyap, menyamar sebagai kegagalan locator. Ditukar
        kepada `find_with_scroll()`, yang MEMANG untuk "cari elemen,
        skrol kalau perlu" dan memulangkan elemen/`None`. `hasattr()`
        DIBUANG."""
        return self.find_with_scroll(loc, timeout_each=timeout) is not None

    # ------------------------------------------------------------------
    # Tab Pesalah borang LETAK KERETA
    # ------------------------------------------------------------------
    # >>> URUTAN INI ADALAH PEMBETULAN D-05. JANGAN SUSUN SEMULA. <<<
    #
    # Borang ini MENCERMINKAN nombor plat ke medan identiti sebaik
    # No. Kereta diisi (D-05, docs/D-05-EPBT-DAN-CERMIN-PLAT.md). Jadi
    # urutan penting, dan ia bukan gaya:
    #
    #   Nama -> IC -> No. Kereta   SALAH. Langkah terakhir mencerminkan
    #                              plat dan MENIMPA dua yang pertama.
    #                              Rekod production PGP02K260813002
    #                              dicipta begini dan medan namapesalah
    #                              padanya membawa nombor plat.
    #
    #   No. Kereta -> Nama -> IC   BETUL. Pencerminan berlaku DAHULU,
    #                              kemudian nilai sebenar ditaip atasnya.
    #
    # Susun atur tab ini DISAHKAN dari borang bersih (2026-08-13): tiada
    # blok alamat langsung, hanya identiti + kenderaan. `fill_pesalah_tab`
    # ialah susun atur Kompaun PELBAGAI dan mencari 'MAKLUMAT JALAN',
    # yang tidak wujud di sini.
    MEDAN_PESALAH_LETAK_KERETA = (
        ("No. Kereta", "no_kereta"),          # DAHULU — lihat nota D-05
        ("Nama Pesalah", "nama_pesalah"),
        ("No K/P/SSM", "no_kp_ssm_kereta"),
        ("No. Cukai Jalan", "no_cukai_jalan"),
        ("Jenis Kereta", "jenis_kereta"),
        ("Warna Kereta", "warna_kereta"),
        ("No. Petak", "no_petak"),
        ("No. Kupon", "no_kupon"),
    )

    def fill_pesalah_tab_letak_kereta(self, data, isi_medan=None):
        """Isi tab Pesalah Letak Kereta PENUH dari data.

        MySIKAP TIDAK dicetus: setiap nilai ditaip, jadi identiti pada
        rekod ialah identiti yang dibekalkan dan bukan orang sebenar
        dari lookup.

        `isi_medan(p, label, nilai) -> bool` disuntik supaya ujian boleh
        merakam urutan tanpa peranti.
        """
        if isi_medan is None:
            from devtools import peringkat6 as P6
            isi_medan = P6._isi_medan_tepat
        print("  [K] mengisi tab Pesalah PENUH (MySIKAP TIDAK dicetus)")
        diisi = []
        for label, kunci in self.MEDAN_PESALAH_LETAK_KERETA:
            nilai = data.get(kunci)
            if nilai is None or str(nilai).strip() == "":
                print(f"    {label:<18} — tiada nilai, dilangkau")
                continue
            ok = isi_medan(self, label, str(nilai))
            diisi.append(label)
            print(f"    {label:<18} = {str(nilai)[:32]!r}  "
                  f"{'OK' if ok else 'TIDAK DIJUMPAI'}")
        return diisi

    def select_jenis_kompaun_letak_kereta(self):
        """Select the Letak Kereta jenis from the PILIH KOMPAUN popup.

        MBJB calls this module "Letak Kereta" where MBIP called it
        "Trafik". Tries the MBJB wording first, then falls back to the
        MBIP-proven KOMPAUN TRAFIK option -- and PRINTS which one hit, so
        the terminal session records the real label instead of the
        fallback quietly papering over a rename.

        # SAHKAN-DEVICE: teks sebenar pilihan pada popup PILIH KOMPAUN
        # MBJB. Kalau yang berjaya ialah fallback TRAFIK, buang cabang
        # LETAK KERETA; kalau sebaliknya, buang fallback. Jangan biarkan
        # kedua-duanya kekal selepas disahkan -- tangga fallback yang
        # tidak dibersihkan ialah cara locator salah terus hidup."""
        print("\n  [DAFTAR KOMPAUN] Selecting jenis: Letak Kereta...")
        for label, loc in (("KOMPAUN LETAK KERETA",
                            self.OPTION_KOMPAUN_LETAK_KERETA),
                           ("KOMPAUN TRAFIK (fallback MBIP)",
                            self.OPTION_KOMPAUN_TRAFIK)):
            if not self.is_element_present(loc, timeout=4):
                continue
            for attempt in range(2):
                self.wait_and_tap(loc)
                if self.is_element_present(self.TRAFIK_SCREEN_TITLE,
                                           timeout=6):
                    print(f"  [DAFTAR KOMPAUN] Jenis selected via "
                          f"'{label}' — PASS")
                    return label
                print(f"  [DAFTAR KOMPAUN] screen didn't open after tap on "
                      f"'{label}' (attempt {attempt + 1}/2)")
        raise TimeoutException(
            "Tiada pilihan Letak Kereta/Trafik yang membuka borang. "
            "Dump popup PILIH KOMPAUN dan betulkan "
            "OPTION_KOMPAUN_LETAK_KERETA.")

    # ---- Toggle Operasi --------------------------------------------------
    # Training Feedback A7/B7 (DONE, APK 2.1.5): a toggle on the Kompaun
    # Pelbagai and Kompaun Lesen forms for building offences; "bila enable
    # toggle, diskaun tak boleh diberi". K7 of the same sheet notes the
    # discount side is still "under checking on CTSB" -- so this method
    # flips the toggle and reports; it deliberately does NOT assert
    # anything about the discount field.
    TOGGLE_OPERASI_CANDIDATES = [
        (AppiumBy.ANDROID_UIAUTOMATOR,
         'new UiSelector().textMatches("(?i)^\\s*operasi\\s*$")'),
        (AppiumBy.ANDROID_UIAUTOMATOR,
         'new UiSelector().descriptionMatches("(?i)^\\s*operasi\\s*$")'),
        (AppiumBy.ANDROID_UIAUTOMATOR,
         'new UiSelector().className("android.widget.Switch")'),
    ]

    def toggle_operasi(self, enable=True):
        """Flip the Operasi toggle. Returns True if a toggle was found
        and tapped, False if the control is not on this form.

        # SAHKAN-DEVICE: (a) borang mana membawa toggle ini -- Pelbagai,
        # Lesen, atau kedua-dua; (b) label sebenar (RN kadang merender
        # toggle sebagai ViewGroup tanpa teks, jadi ketiga-tiga calon di
        # atas boleh meleset); (c) keadaan lalainya. Tanpa (c) kita tidak
        # tahu sama ada satu ketukan MENGHIDUPKAN atau MEMATIKAN, sebab
        # itu kaedah ini melaporkan keadaan sebelum/selepas dan bukannya
        # mendakwa `enable` tercapai."""
        import time
        print(f"  [DAFTAR KOMPAUN] Toggle Operasi -> enable={enable}")
        for loc in self.TOGGLE_OPERASI_CANDIDATES:
            if not self._ada_selepas_skrol(loc, timeout=3):
                continue
            el = self.find_element(loc, timeout=3)
            before = el.get_attribute("checked")
            if before is not None and str(before).lower() == str(
                    bool(enable)).lower():
                print(f"  [DAFTAR KOMPAUN] Operasi already checked="
                      f"{before} -- not tapping")
                return True
            self.tap_element(el)
            time.sleep(1)
            try:
                after = self.find_element(loc, timeout=3).get_attribute(
                    "checked")
            except Exception:                                # noqa: BLE001
                after = "(unreadable)"
            print(f"  [DAFTAR KOMPAUN] Operasi checked: {before} -> "
                  f"{after}")
            return True
        print("  [DAFTAR KOMPAUN] WARNING: no Operasi toggle on this form "
              "-- control NOT verified (see SAHKAN-DEVICE)")
        self._dump_mbjb("mbjb_toggle_operasi_missing.xml")
        return False

    # ---- Tick "Alamat premis sama seperti Alamat pesalah" ---------------
    # Training Feedback A10/B10/K10 (DONE 16/07/2025). MBIP saw this
    # checkbox only on the Sitaan form and left it deliberately untouched
    # (sitaan_page.py docstring). MBJB documents it as a real feature, so
    # it gets a method here -- still opt-in, never auto-ticked.
    TICK_ALAMAT_SAMA = (
        AppiumBy.ANDROID_UIAUTOMATOR,
        'new UiSelector().textMatches("(?i).*alamat\\s+premis\\s+sama.*")')

    def tick_alamat_premis_sama(self):
        """Tick "Alamat premis sama seperti alamat pesalah" (copies the
        pesalah address into the premis/lokasi block). Returns True if
        the control was found and tapped.

        Call this ONLY when the TC explicitly exercises the copy feature.
        Ticking it silently on a normal create would overwrite address
        fields the test just typed, and the printed record would then
        disagree with the Excel data with no trace of why.

        # SAHKAN-DEVICE: wording penuh tick ini pada MBJB dan borang mana
        # membawanya (Pesalah? Kompaun?). MBIP merekod bentuk "TICK JIKA
        # ALAMAT PREMIS SAMA..." pada borang Sitaan sahaja.
        # NOTA: Training Feedback K10 menyatakan Kemaskini Notis TIADA
        # ciri copy alamat -- jangan cari kawalan ini pada borang
        # Kemaskini."""
        import time
        if not self._ada_selepas_skrol(self.TICK_ALAMAT_SAMA, timeout=4):
            print("  [DAFTAR KOMPAUN] WARNING: 'alamat premis sama' tick "
                  "not found on this form (after scroll attempt) -- "
                  "NOT verified")
            self._dump_mbjb("mbjb_tick_alamat_sama_missing.xml")
            return False
        el = self.find_element(self.TICK_ALAMAT_SAMA, timeout=4)
        self.tap_element(el)
        time.sleep(1)
        print("  [DAFTAR KOMPAUN] 'alamat premis sama' ticked")
        return True

    # ---- Letak Kereta extra fields --------------------------------------
    # Excel MBPG-TC-K-001 C10 step 2 names NO. CUKAI JALAN / NO. PETAK /
    # NO. KUPON (kupon marked optional). MBIP knew the labels existed but
    # never filled them (daftar_kompaun_page docstring: "'-' placeholders
    # in the real test data, i.e. optional").
    LABEL_NO_CUKAI_JALAN = "NO. CUKAI JALAN"
    LABEL_NO_PETAK = "NO. PETAK"
    LABEL_NO_KUPON = "NO. KUPON"

    def fill_letak_kereta_extras(self, data):
        """Fill NO. CUKAI JALAN / NO. PETAK / NO. KUPON when the data dict
        supplies them. Keys are optional: a key that is absent is SKIPPED
        (the field keeps whatever the form had); a key present but empty
        is a data bug and raises.

        Peraturan Keras #5 applies with full force here. Excel MBJB C9 for
        K-001 says only "Refer to No Kompaun JB015K260227002" -- it supplies
        NO value for these three fields. So they must come from
        excel_data.BLANK_BY_DESIGN carrying the marker "blank dari test
        script", NOT from a value invented in this file or in the test.

        # SAHKAN-DEVICE: label sebenar ketiga-tiga medan (titik selepas
        # 'NO' wujud atau tidak), dan sama ada NO. PETAK ialah medan bebas
        # atau dropdown."""
        filled = {}
        for key, label in (("no_cukai_jalan", self.LABEL_NO_CUKAI_JALAN),
                           ("no_petak", self.LABEL_NO_PETAK),
                           ("no_kupon", self.LABEL_NO_KUPON)):
            if key not in data:
                continue
            value = data[key]
            if value is None or str(value).strip() == "":
                raise ValueError(
                    f"{key} hadir dalam data tetapi kosong. Medan yang "
                    f"Excel senyap tentangnya mesti didaftarkan dalam "
                    f"excel_data.BLANK_BY_DESIGN dan diisi dengan penanda "
                    f"-- bukan dibiar kosong (Peraturan Keras #5).")
            loc = self._ci_label_locator(label)
            if not self._ada_selepas_skrol(loc, timeout=3):
                print(f"  [DAFTAR KOMPAUN] WARNING: field '{label}' not "
                      f"found (after scroll attempt) -- {key} NOT filled")
                filled[key] = False
                continue
            self.fill_field_by_label(label, str(value))
            filled[key] = True
        if filled and not any(filled.values()):
            self._dump_mbjb("mbjb_letak_kereta_extras_missing.xml")
        return filled

    def verify_kereta_fields_cleared_after_submit(self):
        """MBPG-TC-K-001 C11: after a successful submit, JENIS KERETA and
        WARNA KERETA are expected to be cleared automatically.

        Returns dict {field: state} where state is "cleared", "holds:<v>"
        or "not_present". Does NOT assert -- the caller owns the verdict,
        because "not_present" (form already closed) is a different finding
        from "still holds a value".

        # SAHKAN-DEVICE: pada skrin MANA semakan ini dibuat. Kalau borang
        # ditutup selepas submit (dan Dev List baris 20 'auto refresh page
        # selepas keluar' mencadangkan ia ditutup), semakan ini mungkin
        # tiada tempat untuk berjalan langsung -- itu sendiri penemuan
        # yang perlu dilapor, bukan alasan untuk melonggarkan TC."""
        out = {}
        for name, hint in (("jenis_kereta", "JENIS KERETA"),
                           ("warna_kereta", "WARNA KERETA")):
            loc = (AppiumBy.XPATH,
                   f'//android.widget.EditText[@hint="{hint}"]')
            if not self._ada_selepas_skrol(loc, timeout=3):
                out[name] = "not_present"
                continue
            try:
                txt = (self.find_element(loc, timeout=3).text or "").strip()
            except Exception:                                # noqa: BLE001
                out[name] = "not_present"
                continue
            out[name] = "cleared" if txt in ("", hint) else f"holds:{txt}"
        print(f"  [DAFTAR KOMPAUN] post-submit kereta fields: {out}")
        return out

    def _dump_mbjb(self, name):
        """Dump page source into ui_dumps/ for the MBJB-only probes. The
        dump is the whole point when a guessed locator misses: it is what
        the terminal session uses to write the real one."""
        try:
            import os
            os.makedirs("ui_dumps", exist_ok=True)
            path = os.path.join("ui_dumps", name)
            with open(path, "w", encoding="utf-8") as f:
                f.write(self.driver.page_source)
            print(f"  [DAFTAR KOMPAUN] DEBUG: page source dumped to {path}")
            return path
        except Exception:                                    # noqa: BLE001
            return "(dump failed)"

"""
Notis Kompaun (Compound Notice List) page — Page Object Model.
Flow: Click Tarik Notis -> enter ID Penguatkuasa -> click Tarik ->
records for that ID are displayed.

NOTE: per the real manual flow, this form has only ONE input field
(ID Penguatkuasa) — not two. A previous version of this file incorrectly
defined a second "no notis" field using the same locator as ID Penguatkuasa;
that has been removed here.

PORT MBJB
---------
- Awalan nombor notis daripada profil aktif, bukan 'IPA' berhardcode.
- tarik_by_no_notis() DIKEKALKAN tetapi menjadi KOD MATI: MBJB tiada
  TC TN-002, dan Excel MBPG-TC-TN-001 C14 merekod "Unable to search/
  retrieve by using No Notis feature" -- ciri itu rosak pada 2.1.33.
  Jangan panggil, jangan tulis test untuknya.
- TN-001 MBJB (C10 langkah 3) menyebut "Select action type: Kompaun or
  Patuh" DALAM aliran yang sama, sedangkan MBIP memisahkannya kepada
  NK-001/NK-002. Lihat SAHKAN-DEVICE pada tarik_notis().
- NK-002 Patuh: kamera-sebelum-Patuh sudah dilaksanakan di sini (MBIP
  membuktikannya secara langsung: PATUH melantun dengan "SILA AMBIL
  GAMBAR."), dan itu sepadan dengan permintaan MBJB dalam Training
  Feedback baris 2. Tiada perubahan diperlukan.
"""

from appium.webdriver.common.appiumby import AppiumBy
from selenium.common.exceptions import TimeoutException
from pages.base_page import BasePage, _record_prefix


class NotisKompaunPage(BasePage):
    """Notis Kompaun screen — listing and Tarik Notis functionality."""

    # ---- Screen title ----
    SCREEN_TITLE = (AppiumBy.ANDROID_UIAUTOMATOR,
                    'new UiSelector().textMatches("(?i).*NOTIS\s+KOMPAUN.*")')

    # ---- Tarik Notis button ----
    BUTTON_TARIK_NOTIS = (AppiumBy.ANDROID_UIAUTOMATOR,
                          'new UiSelector().textContains("Tarik Notis")')

    # ---- Tarik Notis popup (single field) ----
    LABEL_ID_PENGUATKUASA = "ID PENGUATKUASA"
    # Confirmed via live page-source dump: the popup is titled "TARIK
    # NOTIS TAMAT TEMPOH" and its button is 'TARIK' (upper-case, in
    # both text and content-desc) -- the original text("Tarik") guess
    # could never match. Full-string match, so this can't collide with
    # the "Tarik Notis" button that opens this popup.
    POPUP_TARIK_TITLE = (AppiumBy.ANDROID_UIAUTOMATOR,
                         'new UiSelector().textMatches("(?i).*TARIK\s+NOTIS\s+TAMAT\s+TEMPOH.*")')
    TARIK_LOCATORS = [
        (AppiumBy.ANDROID_UIAUTOMATOR,
         'new UiSelector().textMatches("(?i)\\s*tarik\\s*")'),
        (AppiumBy.ANDROID_UIAUTOMATOR,
         'new UiSelector().descriptionMatches("(?i)\\s*tarik\\s*")'),
    ]

    # ========================================================================
    # Actions
    # ========================================================================

    def is_notis_kompaun_screen_displayed(self):
        """Verify we are on the Notis Kompaun screen."""
        return self.is_element_present(self.SCREEN_TITLE, timeout=10)

    def click_tarik_notis(self):
        """Click the Tarik Notis button to open the pull form."""
        print("  [NOTIS KOMPAUN] Clicking Tarik Notis...")
        self.wait_and_click(self.BUTTON_TARIK_NOTIS)

    def enter_id_penguatkuasa(self, id_penguatkuasa):
        """Enter the enforcement officer ID (the only input on this form).

        keep_keyboard=True: this field lives inside a dismissible RN
        modal, and hide_keyboard can act like a Back press -- confirmed
        via live dump that the whole Tarik Notis popup was gone right
        after this fill, which is why the Tarik button was 'not found'."""
        print(f"  [NOTIS KOMPAUN] Entering ID penguatkuasa: {id_penguatkuasa}")
        self.fill_field_by_label(self.LABEL_ID_PENGUATKUASA, id_penguatkuasa,
                                 keep_keyboard=True)

    def click_tarik(self):
        """Click the TARIK button and VERIFY the popup actually closed.

        Confirmed via live dump: the raw coordinate tap on TARIK can
        silently no-op (same flake as the suggestion/option rows),
        leaving the popup open on top of the record table -- which then
        reads as 'no records displayed' even though the tap 'worked'.
        Re-taps up to 3 times, checking the popup title each round.

        Deliberately does NOT hide the keyboard up front: on this
        dismissible RN modal, hide_keyboard can act like a Back press
        and close the entire popup (confirmed via an earlier live
        dump); it's only used as a fallback when the button can't be
        found at all (possibly covered by the keyboard)."""
        print("  [NOTIS KOMPAUN] Clicking Tarik...")
        import time
        for attempt in range(3):
            el = None
            for loc in self.TARIK_LOCATORS:
                if self.is_element_present(loc, timeout=5):
                    el = self.find_element(loc, timeout=5)
                    break
            if el is None:
                self._hide_keyboard_if_shown()
                time.sleep(0.5)
                continue
            self.tap_element(el)
            time.sleep(1)
            if not self.is_element_present(self.POPUP_TARIK_TITLE,
                                           timeout=5):
                return
            print(f"  [NOTIS KOMPAUN] Tarik popup still open after tap "
                  f"(attempt {attempt + 1}/3) -- re-tapping...")

        if not self.is_element_present(self.POPUP_TARIK_TITLE, timeout=2):
            return
        dump_path = "debug_tarik_page_source.xml"
        try:
            with open(dump_path, "w", encoding="utf-8") as f:
                f.write(self.driver.page_source)
            print(f"  [NOTIS KOMPAUN] DEBUG: page source dumped to "
                  f"{dump_path}")
        except Exception:
            pass
        raise TimeoutException(
            "Tarik popup did not close after tapping TARIK 3 times; see "
            "debug_tarik_page_source.xml")

    def is_record_displayed(self, timeout=10):
        """Check if any record row is displayed after Tarik.

        Confirmed via live page-source dump (debug_notis_kompaun_
        records.xml): this screen has NO RecyclerView at all (the old
        check's class), just a table whose row cells carry their
        content in content-desc -- and unlike Senarai's YYYY-MM-DD,
        the dates here render as DD-MM-YYYY (e.g. "PANDU KERETA LAJU,
        24-06-2026"). Matches either date shape. Dumps the page source
        when nothing is found, so 'no records' vs 'wrong locator' can
        be told apart offline."""
        row_locator = (
            AppiumBy.ANDROID_UIAUTOMATOR,
            'new UiSelector().className("android.view.ViewGroup")'
            '.descriptionMatches(".*(\\d{4}-\\d{2}-\\d{2}|\\d{2}-\\d{2}-\\d{4}).*")')
        found = self.is_element_present(row_locator, timeout=timeout)
        if found:
            print("  [NOTIS KOMPAUN] Record(s) displayed — PASS")
        else:
            print("  [NOTIS KOMPAUN] WARNING: No records displayed")
            try:
                dump_path = "debug_notis_kompaun_records.xml"
                with open(dump_path, "w", encoding="utf-8") as f:
                    f.write(self.driver.page_source)
                print(f"  [NOTIS KOMPAUN] DEBUG: page source dumped to "
                      f"{dump_path}")
            except Exception:
                pass
        return found

    # ------------------------------------------------------------------
    # v3 Phase 3 additions (all popup facts confirmed via live recon
    # 2026-07-16: the TARIK NOTIS popup has BOTH 'ID Penguatkuasa' and
    # 'No Notis' fields; a pulled-notice row tap opens a popup with
    # NO NOTIS + pesalah details + KOMPAUN/PATUH buttons + an ulasan
    # field; tapping PATUH with it empty alerts "ULASAN WAJIB DIISI.")
    # ------------------------------------------------------------------

    LABEL_NO_NOTIS = "No Notis"
    NOTICE_POPUP = (AppiumBy.ANDROID_UIAUTOMATOR,
                    'new UiSelector().textMatches("(?i).*NO\s+NOTIS.*")')
    BUTTON_NK_KOMPAUN = (AppiumBy.ANDROID_UIAUTOMATOR,
                         'new UiSelector().textMatches("(?i)\s*KOMPAUN\s*")')
    BUTTON_NK_PATUH = (AppiumBy.ANDROID_UIAUTOMATOR,
                       'new UiSelector().textMatches("(?i)\s*PATUH\s*")')
    NK_FORM_TITLE = (AppiumBy.ANDROID_UIAUTOMATOR,
                     'new UiSelector().textMatches("(?i).*NOTIS\s+TO\s+KOMPAUN.*")')

    def _dump(self, name):
        try:
            import os
            os.makedirs("ui_dumps", exist_ok=True)
            path = os.path.join("ui_dumps", name)
            with open(path, "w", encoding="utf-8") as f:
                f.write(self.driver.page_source)
            print(f"  [NOTIS KOMPAUN] DEBUG: page source dumped to {path}")
            return path
        except Exception:
            return "(dump failed)"

    def get_pulled_notice_numbers(self):
        """Notice numbers (JB015N...) visible in the pulled table, in row
        order (each is a cell whose text is the number). Prefix comes
        from the active profile, not a hardcoded 'IPA'."""
        loc = (AppiumBy.ANDROID_UIAUTOMATOR,
               f'new UiSelector().textMatches("{_record_prefix()}\\w+")')
        numbers = []
        try:
            for el in self.driver.find_elements(*loc):
                t = el.text
                if t:
                    numbers.append(t)
        except Exception:
            pass
        return numbers

    def tarik_by_no_notis(self, no_notis):
        """KOD MATI PADA MBJB -- JANGAN PANGGIL.

        Pull a single notice by its number via the popup's 'No Notis'
        field, then verify that notice is displayed. Ini melayani TC
        TN-002 suite MBIP, yang TIADA dalam MBJB (57 sheet V2.1.33 tiada
        MBPG-TC-TN-002), dan Excel MBPG-TC-TN-001 C14 merekod ciri itu
        rosak: "Unable to search/retrieve by using No Notis feature".
        Dikekalkan supaya sesiapa yang mencarinya menemui sebab ia tidak
        digunakan, bukan menulis semula."""
        self.click_tarik_notis()
        print(f"  [NOTIS KOMPAUN] Entering No Notis: {no_notis}")
        # keep_keyboard=True -- dismissible RN modal (same lesson as the
        # ID field). use_mobile_type=True -- confirmed live: plain
        # send_keys throws InvalidElementStateException on this field
        # (same masked/validated-input behavior as the IP and tempoh
        # fields).
        self.fill_field_by_label(self.LABEL_NO_NOTIS, no_notis,
                                 keep_keyboard=True, use_mobile_type=True)
        self.click_tarik()
        self.dismiss_native_alerts(first_timeout=15,
                                   context="Tarik by No Notis")
        loc = (AppiumBy.ANDROID_UIAUTOMATOR,
               f'new UiSelector().textContains("{no_notis}")')
        found = self.is_element_present(loc, timeout=10)
        if not found:
            self._dump("tn002_notice_not_listed.xml")
        return found

    PULLED_ROW = (AppiumBy.ANDROID_UIAUTOMATOR,
                  'new UiSelector().className("android.view.ViewGroup")'
                  '.descriptionMatches(".*\\d{2}-\\d{2}-\\d{4}.*")')

    def open_notice_popup(self, index=0):
        """Tap a pulled-notice row and verify its popup opened. Returns
        the popup's NO NOTIS value (or None).

        >>> C-11 · PEMILIHAN IKUT KEDUDUKAN — PERATURAN KERAS #7 <<<
        `index` memilih baris ke-`index`, jadi TIADA pertalian dengan
        rekod yang run INI cipta. Pada staging, baris pertama hampir pasti
        notis LAMA daripada run terdahulu, jadi NK-001 akan mengeluarkan
        Kompaun / menekan PATUH pada notis yang bukan miliknya, dan
        laporan tidak merekod notis MANA yang disentuh.

        Kaedah ini DIKEKALKAN kerana pembetulan penuh memerlukan keputusan
        Loh (kontrak §10 Soalan 1: adakah notis yang dicipta N-001 boleh
        ditarik dengan `id_penguatkuasa = msc`?). Meneka jawapannya akan
        menghasilkan skip yang menyembunyikan aliran yang sebenarnya
        berfungsi. Sementara itu:
          * ia MENCETAK nombor yang dibuka supaya bukti wujud;
          * pemanggil WAJIB `artifacts(...)` nombor itu + sama ada ia
            terikat pada run ini (bahagian Mustaqim);
          * docstring TC mesti berkata dengan terang: TC ini membuktikan
            ALIRAN berfungsi pada SATU notis; ia TIDAK membuktikan notis
            itu dicipta oleh run ini melainkan `terikat_run_ini=True`.
        Selepas Loh menjawab, tukar kepada open_notice_by_number()."""
        import time
        row = self.PULLED_ROW
        els = self.driver.find_elements(*row)
        if not els:
            raise TimeoutException("no pulled-notice rows on screen")
        el = els[min(index, len(els) - 1)]
        print(f"  [NOTIS KOMPAUN] C-11 AMARAN: memilih baris notis IKUT "
              f"KEDUDUKAN (index={index} daripada {len(els)} baris). Notis "
              f"ini TIDAK terbukti dicipta oleh run ini — rekod nombornya "
              f"sebagai bukti dan jangan dakwa rantaian create->kompaun.")
        print(f"  [NOTIS KOMPAUN] Opening notice row: "
              f"{el.get_attribute('content-desc')!r}")
        for attempt in range(3):
            self.tap_element(el)
            time.sleep(1.5)
            if self.is_element_present(self.NOTICE_POPUP, timeout=4):
                break
            print(f"  [NOTIS KOMPAUN] notice popup didn't open (attempt "
                  f"{attempt + 1}/3) -- re-tapping...")
        else:
            self._dump("nk_notice_popup_never_opened.xml")
            raise TimeoutException("notice popup never opened; see "
                                   "ui_dumps/nk_notice_popup_never_opened"
                                   ".xml")
        return self._read_popup_no_notis()

    def _read_popup_no_notis(self):
        """NO NOTIS pada popup notis YANG TERBUKA, atau None."""
        try:
            t = self.driver.find_element(*self.NOTICE_POPUP).text
            print(f"  [NOTIS KOMPAUN] popup: {t}")
            return t.split(":")[-1].strip()
        except Exception:                                    # noqa: BLE001
            return None

    def open_notice_by_number(self, no_notis, max_scrolls=20):
        """Buka popup notis yang NO NOTIS-nya == `no_notis`, IKUT NOMBOR.
        Pulang True hanya bila popup terbuka DAN ia memaparkan `no_notis`.
        TIADA fallback ke baris lain (PERATURAN KERAS #7).

        Bentuk C-11 yang BETUL, disediakan supaya NK-001/NK-002 boleh
        bertukar dengan SATU panggilan sebaik Loh menjawab kontrak §10
        Soalan 1. Ia sengaja BELUM dipanggil oleh mana-mana test: kalau
        notis yang dicipta N-001 TIDAK muncul dalam tabel Tarik Notis,
        menukar sekarang menghasilkan skip yang menyembunyikan aliran
        yang berfungsi.

        # SAHKAN-DEVICE: (a) adakah notis yang dicipta run ini muncul
        # dalam tabel Tarik Notis bagi `id_penguatkuasa` Excel (`msc`);
        # (b) adakah nombor notis muncul dalam content-desc baris tarik
        # (get_pulled_notice_numbers menggunakan awalan profil) atau hanya
        # dalam popup."""
        import time
        if not no_notis:
            return False
        self.dismiss_native_alerts(first_timeout=1,
                                   context="Tarik Notis cari-ikut-nombor")
        cell = (AppiumBy.ANDROID_UIAUTOMATOR,
                f'new UiSelector().descriptionContains("{no_notis}")')
        for _ in range(max_scrolls):
            if self.is_element_present(cell, timeout=1):
                el = self.find_element(cell, timeout=3)
                self.tap_element(el)
                time.sleep(1.5)
                if not self.is_element_present(self.NOTICE_POPUP, timeout=4):
                    self._dump(f"nk_popup_tidak_buka_{no_notis}.xml")
                    print(f"  [NOTIS KOMPAUN] {no_notis} dijumpai tetapi "
                          f"popup tidak terbuka")
                    return False
                dibaca = self._read_popup_no_notis()
                if not dibaca or no_notis not in dibaca:
                    self._dump(f"nk_popup_bukan_{no_notis}.xml")
                    print(f"  [NOTIS KOMPAUN] popup terbuka TETAPI bukan "
                          f"{no_notis} (dibaca {dibaca!r}) — melaporkan "
                          f"GAGAL, tidak bertindak pada notis salah")
                    return False
                print(f"  [NOTIS KOMPAUN] Opened notice {no_notis} by "
                      f"number")
                return True
            before = len(self.driver.find_elements(*self.PULLED_ROW))
            try:
                w = self.driver.get_window_size()
                x = w["width"] // 2
                self.driver.swipe(x, int(w["height"] * 0.80),
                                  x, int(w["height"] * 0.32), 600)
            except Exception:                                # noqa: BLE001
                break
            time.sleep(0.6)
            if len(self.driver.find_elements(*self.PULLED_ROW)) == before \
                    and not self.is_element_present(cell, timeout=1):
                break
        print(f"  [NOTIS KOMPAUN] Notis {no_notis} TIDAK dijumpai dalam "
              f"tabel Tarik Notis — enggan membuka notis lain")
        self._dump(f"nk_notis_tidak_dijumpai_{no_notis}.xml")
        return False

    def _scroll_popup_to(self, target_locator, rounds=8):
        """Scroll the notice popup's content toward target_locator. The
        drag MUST start on a LABEL TextView -- a drag starting on one of
        the popup's EditTexts is swallowed by the TextInput (confirmed
        live). Returns True when the target is present."""
        import time
        if self.is_element_present(target_locator, timeout=2):
            return True
        label_row = (AppiumBy.ANDROID_UIAUTOMATOR,
                     'new UiSelector().className("android.widget.TextView")'
                     '.textMatches(".* :$")')
        for _ in range(rounds):
            try:
                labels = self.driver.find_elements(*label_row)
                if not labels:
                    return self.is_element_present(target_locator,
                                                   timeout=2)
                r = labels[-1].rect
                x = r["x"] + r["width"] // 2
                y = r["y"] + r["height"] // 2
                self.driver.swipe(x, y, x, max(y - 1300, 400), 800)
                time.sleep(0.8)
            except Exception:
                break
            if self.is_element_present(target_locator, timeout=2):
                return True
        return self.is_element_present(target_locator, timeout=2)

    def patuh(self, ulasan):
        """MBPG-TC-NK-002: on the open notice popup, fill the ulasan
        field and tap PATUH. Success = popup closes without a RALAT
        alert (messages returned for the log)."""
        import time
        self._dump("nk_popup_before_patuh.xml")
        # The visible popup fields are the NOTICE DATA (nama/KP/alamat
        # -- confirmed live; a blind 'last EditText' write corrupted
        # ALAMAT 1). The ULASAN field is NOT in the initial tree; the
        # popup's content area scrolls -- hunt for an ULASAN label and
        # take the EditText right after it.
        ulasan_label = (AppiumBy.ANDROID_UIAUTOMATOR,
                        'new UiSelector().textMatches("(?i).*ulasan.*")')
        ulasan_field = (AppiumBy.XPATH,
                        '//android.widget.TextView[contains(translate('
                        '@text, "ulasan", "ULASAN"), "ULASAN")]'
                        '/following-sibling::android.widget.EditText[1]')
        found = self._scroll_popup_to(ulasan_label, rounds=10)
        if not found:
            path = self._dump("nk_ulasan_field_missing.xml")
            raise TimeoutException(
                f"no ULASAN field found in the notice popup (initial "
                f"view holds only the notice's data fields); see {path}")
        el = self.find_element(ulasan_field, timeout=5)
        el.click()
        el.clear()
        # send_keys DAHULU (dasar 2026-08-04). ULASAN ialah teks bebas
        # dari testdata — rentetan terpanjang yang ditaip suite ini, dan
        # hampir pasti mengandungi 'r'.
        self._emit_text(el, ulasan, False)

        # A photo is REQUIRED for Patuh too -- confirmed live: PATUH
        # bounced with "SILA AMBIL GAMBAR.". The popup carries its own
        # OPEN CAMERA near the ulasan field.
        from pages.daftar_kompaun_page import DaftarKompaunPage
        camera = (AppiumBy.ANDROID_UIAUTOMATOR,
                  'new UiSelector().textMatches("(?i)\s*OPEN\s+CAMERA\s*")')
        try:
            # The open keyboard hides the popup's lower section
            # (confirmed live: OPEN CAMERA sits right below the ULASAN
            # field per the popup-bottom probe, yet was 'not found'
            # while the keyboard was up). With an IME open, a single
            # device Back closes ONLY the keyboard.
            try:
                if self.driver.is_keyboard_shown():
                    self.press_back()
                    time.sleep(1)
            except Exception:
                pass
            if not self.is_element_present(self.NOTICE_POPUP, timeout=3):
                raise TimeoutException(
                    "notice popup dismissed while closing the keyboard")
            if not self.is_element_present(camera, timeout=3):
                self._scroll_popup_to(camera, rounds=6)
            el2 = self.find_element(camera, timeout=5)
            self.tap_element(el2)
            time.sleep(2)
            self.wait_and_click(DaftarKompaunPage.BUTTON_SNAP)
            time.sleep(3)
            for _ in range(3):
                el2 = self.find_clickable(
                    DaftarKompaunPage.BUTTON_TICK_CONFIRM)
                self.tap_element(el2)
                time.sleep(2)
                if not self.is_element_present(
                        DaftarKompaunPage.CAMERA_OPEN_INDICATOR,
                        timeout=3):
                    print("  [NOTIS KOMPAUN] patuh photo taken")
                    break
        except Exception as e:
            print(f"  [NOTIS KOMPAUN] WARNING: patuh camera step failed "
                  f"({type(e).__name__}) -- PATUH may reject")
        time.sleep(0.5)
        # The open keyboard unmounts/covers the popup's PATUH button
        # (confirmed live: 'PATUH' not found right after typing), and a
        # device Back dismisses the WHOLE RN modal, not just the
        # keyboard (also confirmed live). Close the keyboard with the
        # IME action key (ENTER) instead, then a neutral tap on the
        # popup title as fallback; verify the popup survived.
        if not self.is_element_present(self.BUTTON_NK_PATUH, timeout=3):
            self.driver.press_keycode(66)  # IME done/enter
            time.sleep(1)
        if not self.is_element_present(self.BUTTON_NK_PATUH, timeout=3):
            try:
                el = self.driver.find_element(*self.NOTICE_POPUP)
                self.tap_element(el)
                time.sleep(1)
            except Exception:
                pass
        if not self.is_element_present(self.NOTICE_POPUP, timeout=3):
            raise TimeoutException(
                "notice popup got dismissed while closing the keyboard "
                "before PATUH")
        messages = []
        for attempt in range(3):
            btn = self.find_element(self.BUTTON_NK_PATUH, timeout=5)
            self.tap_element(btn)
            time.sleep(1.5)
            # result alert?
            if self.is_element_present(self.NATIVE_ALERT_OK, timeout=5):
                try:
                    msg = self.driver.find_element(
                        *self.NATIVE_ALERT_MESSAGE).text
                    messages.append(msg)
                    print(f"  [NOTIS KOMPAUN] PATUH result: {msg}")
                except Exception:
                    pass
                self.dismiss_native_alerts(first_timeout=2, context="patuh")
            if not self.is_element_present(self.NOTICE_POPUP, timeout=3):
                return messages
            print(f"  [NOTIS KOMPAUN] popup still open after PATUH "
                  f"(attempt {attempt + 1}/3)")
        self._dump("nk_patuh_popup_stuck.xml")
        return messages

    def kompaun_action(self, amaun):
        """MBPG-TC-NK-001: on the open notice popup, tap KOMPAUN -- a
        'NOTIS TO KOMPAUN FORM' screen opens (confirmed via recon).
        Drive it to submission: fill the amount if reachable, then the
        generic SETERUSNYA/MENYERAHKAN/HANTAR ladder.

        >>> KELAS B-1 DIBETULKAN 2026-07-30. <<< Dahulu baris terakhir
        berbunyi `closed = not is_element_present(NK_FORM_TITLE)` SELEPAS
        `dismiss_native_alerts()` menelan teks alert — corak PASS palsu
        yang SAMA seperti `is_submission_successful_trafik()`: borang juga
        ditutup apabila server MENOLAK. Sekarang teks alert dibaca dan
        diadili (penafian DAHULU) dan `read_record_number()` dipanggil,
        jadi "borang ditutup" bukan lagi satu-satunya bukti."""
        import time
        print("  [NOTIS KOMPAUN] Tapping KOMPAUN on the notice popup...")
        for attempt in range(3):
            btn = self.find_element(self.BUTTON_NK_KOMPAUN, timeout=5)
            self.tap_element(btn)
            time.sleep(2)
            if self.is_element_present(self.NK_FORM_TITLE, timeout=5):
                break
            print(f"  [NOTIS KOMPAUN] NOTIS TO KOMPAUN FORM didn't open "
                  f"(attempt {attempt + 1}/3)")
        else:
            self._dump("nk001_form_never_opened.xml")
            raise TimeoutException(
                "NOTIS TO KOMPAUN FORM never opened; see "
                "ui_dumps/nk001_form_never_opened.xml")
        print("  [NOTIS KOMPAUN] NOTIS TO KOMPAUN FORM open")
        self._dump("nk001_form_top.xml")

        # This form is the same unscrollable RN record-form family as
        # Kemaskini/HantarSemula (confirmed live: fields below the fold
        # are absent from the tree and every gesture no-ops) -- each
        # field is revealed via focus traversal before acting.
        amaun_loc = (AppiumBy.XPATH,
                     '//android.widget.EditText[@hint="ENTER AMAUN"]')
        if self.reveal_below_fold(amaun_loc):
            el = self.find_element(amaun_loc, timeout=5)
            el.click()
            el.clear()
            self._emit_text(el, amaun, False)   # send_keys dahulu
            self._hide_keyboard_if_shown()
            print(f"  [NOTIS KOMPAUN] amount entered: {amaun}")
        else:
            print("  [NOTIS KOMPAUN] WARNING: ENTER AMAUN field never "
                  "rendered -- continuing (may be preset)")

        # MAKLUMAT PEGAWAI: NO PEMBANTU PENGUATKUASA is required
        # (confirmed live: submit alert bounced without it).
        pembantu_loc = self._ci_label_locator("NO PEMBANTU PENGUATKUASA")
        if self.reveal_below_fold(pembantu_loc):
            self.fill_field_by_label("NO PEMBANTU PENGUATKUASA", "2",
                                     timeout=5)
            print("  [NOTIS KOMPAUN] pembantu penguatkuasa filled")
        else:
            print("  [NOTIS KOMPAUN] pembantu placeholder not rendered "
                  "(likely already holds a value) -- continuing")

        # Photos are MANDATORY on this form -- confirmed live: the
        # submit alert says "GAMBAR MESTI DIAMBIL.". Reuse the hardened
        # camera routine (pacing + verified tick) via the shared
        # constants, one photo suffices.
        from pages.daftar_kompaun_page import DaftarKompaunPage
        try:
            camera = (AppiumBy.ANDROID_UIAUTOMATOR,
                      'new UiSelector().textMatches("(?i)\s*OPEN\s+CAMERA\s*")')
            if not self.reveal_below_fold(camera):
                raise TimeoutException("OPEN CAMERA never rendered")
            el = self.find_element(camera, timeout=5)
            self.tap_element(el)
            time.sleep(2)
            self.wait_and_click(DaftarKompaunPage.BUTTON_SNAP)
            time.sleep(3)
            for attempt in range(3):
                el = self.find_clickable(
                    DaftarKompaunPage.BUTTON_TICK_CONFIRM)
                self.tap_element(el)
                time.sleep(2)
                if not self.is_element_present(
                        DaftarKompaunPage.CAMERA_OPEN_INDICATOR,
                        timeout=3):
                    print("  [NOTIS KOMPAUN] photo taken and confirmed")
                    break
        except Exception as e:
            print(f"  [NOTIS KOMPAUN] WARNING: camera step failed "
                  f"({type(e).__name__}: {e}) -- submit may reject")

        # drive to submission (reveal MENYERAHKAN first -- same
        # unscrollable-form reason as the fields above)
        self.reveal_below_fold(self.BUTTON_MENYERAHKAN)
        seterusnya = (AppiumBy.ANDROID_UIAUTOMATOR,
                         'new UiSelector().descriptionMatches("(?i)\s*SETERUSNYA\s*")')
        simpan_popup = (AppiumBy.ANDROID_UIAUTOMATOR,
                        'new UiSelector().textContains("Simpan maklumat")')
        for _ in range(5):
            if self.is_element_present(simpan_popup, timeout=3):
                el = self.find_clickable(self.BUTTON_HANTAR)
                self.tap_element(el)
                time.sleep(2)
                continue
            if self.is_element_present(self.BUTTON_MENYERAHKAN, timeout=3):
                self._hide_keyboard_if_shown()
                el = self.find_clickable(self.BUTTON_MENYERAHKAN)
                self.tap_element(el)
                time.sleep(2)
                continue
            if self.is_element_present(seterusnya, timeout=3):
                el = self.find_element(seterusnya, timeout=3)
                self.tap_element(el)
                time.sleep(2)
                continue
            break
        from pages.daftar_kompaun_page import (adili_alert_hantar,
                                               sebab_gagal_senyap)
        v = adili_alert_hantar(self, "notis-ke-kompaun submit",
                               first_timeout=20)
        time.sleep(1)
        closed = not self.is_element_present(self.NK_FORM_TITLE, timeout=4)

        if v["ditolak"]:
            self._dump("nk001_submit_ditolak.xml")
            print(f"  [NOTIS KOMPAUN] >>> PENGHANTARAN DITOLAK <<< alert "
                  f"MENAFIKAN kejayaan: {v['teks']!r} — FAIL (kompaun "
                  f"TIDAK dikeluarkan untuk notis ini)")
            return False
        if not closed:
            self._dump("nk001_form_still_open.xml")
            print(f"  [NOTIS KOMPAUN] NOTIS TO KOMPAUN FORM masih terbuka "
                  f"selepas tangga penghantaran (teks alert: {v['teks']!r})")
            return False
        if v["disahkan"] or v["nombor"]:
            print(f"  [NOTIS KOMPAUN] Kompaun dikeluarkan — bukti: teks "
                  f"kejayaan={v['disahkan']}, nombor rekod="
                  f"{v['nombor'] or '(tidak terbaca)'} — PASS")
            return True

        self._dump("nk001_submit_tiada_bukti.xml")
        print("  [NOTIS KOMPAUN] " + sebab_gagal_senyap(
            "NOTIS TO KOMPAUN submit",
            "Borang memang ditutup — dan itulah SATU-SATUNYA isyarat yang "
            "ada.", v["teks"]))
        return False

    def tarik_notis(self, id_penguatkuasa):
        """Complete Tarik Notis flow: open form, enter ID, tarik, check
        that records are displayed."""
        self.click_tarik_notis()
        self.enter_id_penguatkuasa(id_penguatkuasa)
        self.click_tarik()

        # The pull runs against the server and reports its result via
        # the same native alert the sync/upload flows use -- while one
        # is up, UiAutomator can't see the table behind it. Wait for
        # it and dismiss (also logs how many notices were pulled).
        self.dismiss_native_alerts(first_timeout=15, context="Tarik Notis")

        # >>> UJIAN KAWALAN SEBELUM SIFAR-BARIS DIKIRA SEBAGAI BUKTI. <<<
        # KEPUTUSAN PEMILIK 2026-08-05.
        #
        # Run 2026-08-05: TN-001, NK-001 dan NK-002 kesemuanya gagal dengan
        # mesej yang SAMA — "No records displayed" — untuk DUA ID berbeza
        # (msc dan admin). Tiga kegagalan, satu punca, dan puncanya BELUM
        # DIKETAHUI: ia boleh jadi (a) skrin ini memang kosong kerana tiada
        # rekod tersync, (b) skrin membuka dengan penapis tarikh yang tidak
        # merangkumi rekod, atau (c) locator baris kita salah.
        #
        # Sifar-baris hanya menjadi BUKTI selepas kita membuktikan skrin ini
        # mampu memaparkan SEBARANG rekod. Itu ujian kawalannya, dan ia
        # meminjam mekanisme yang sudah terbukti pada skrin Senarai:
        # penapis julat tarikh (senarai_page.ensure_records_listed).
        #
        # Kalau selepas penapis pun ia masih kosong, barulah kegagalan itu
        # bermakna — dan mesejnya mengatakan dengan tepat apa yang telah
        # dicuba, supaya pembaca tidak mengulang kerja yang sama.
        if self.is_record_displayed():
            print("  [NOTIS KOMPAUN] Tarik Notis completed successfully")
            return True

        print(f"  [KAWALAN] 0 baris untuk id_penguatkuasa="
              f"{id_penguatkuasa} — menjalankan UJIAN KAWALAN sebelum "
              f"mengira ini sebagai bukti...")
        ditapis = False
        try:
            ditapis = self._kawalan_penapis_tarikh()
        except Exception as e:                               # noqa: BLE001
            print(f"  [KAWALAN] penapis tarikh tidak dapat dijalankan: "
                  f"{type(e).__name__}: {e}")

        if ditapis and self.is_record_displayed():
            print("  [KAWALAN] baris MUNCUL selepas penapis tarikh — skrin "
                  "berfungsi; kekosongan tadi ialah penapis lalai, bukan "
                  "ketiadaan rekod.")
            print("  [NOTIS KOMPAUN] Tarik Notis completed successfully")
            return True

        keadaan_kawalan = ("penapis dijalankan" if ditapis else
                           "PENAPIS TIDAK DAPAT DIJALANKAN — kekosongan "
                           "ini BELUM lagi bukti")
        raise AssertionError(
            f"FAIL: 0 rekod untuk id_penguatkuasa={id_penguatkuasa} DAN "
            f"selepas ujian kawalan penapis tarikh ({keadaan_kawalan}). "
            f"Kalau penapis berjalan dan skrin masih kosong, dan rekod "
            f"MEMANG tersync (status 'H'), ini KATEGORI B. Kalau rekod "
            f"masih berstatus 'M', puncanya hulu — rekod tidak sampai ke "
            f"server, bukan skrin ini.")

    def _kawalan_penapis_tarikh(self):
        """Cuba penapis julat tarikh pada skrin ini, mekanisme yang sama
        seperti senarai_page.ensure_records_listed(). Pulangkan True kalau
        penapis benar-benar dijalankan (bukan kalau ia menjumpai baris)."""
        for nama in ("open_calendar", "filter_by_day_range"):
            if not hasattr(self, nama):
                print(f"  [KAWALAN] skrin ini tiada {nama}() — penapis "
                      f"tarikh bukan mekanisme yang ada di sini")
                return False
        self.open_calendar()
        self.filter_by_day_range(1, None)
        print("  [KAWALAN] penapis julat tarikh dijalankan pada skrin Tarik")
        return True

    # ------------------------------------------------------------------
    # MBJB-only additions
    # ------------------------------------------------------------------

    # TC P-007 / K-007 / L-007 "Notis peringatan pertama".
    # Excel MBPG-TC-P-007 C10 step 2 = "Verify status notis in database"
    # with expected status 'B'. A handheld Appium session CANNOT read the
    # ePBT database, so there is no honest way to satisfy that step from
    # here. What this method does instead is gather every status-shaped
    # thing the APP shows for the notice, and say so plainly. The calling
    # test decides: report the proxy evidence, or pytest.skip with the
    # reason "verifikasi DB -- di luar skop device". It must NOT assert
    # 'B' against something that merely looks like a status field.
    STATUS_LABEL = (AppiumBy.ANDROID_UIAUTOMATOR,
                    'new UiSelector().textMatches("(?i).*status.*")')

    def read_notis_status_evidence(self, dump_tag=None, no_notis=None):
        """Collect whatever the app displays about a notice's status ON THE
        **SKRIN SEMASA**. Ia TIDAK membuka, mencari, atau mengesahkan
        sebarang rekod tertentu.

        Returns dict: {"status_texts": [...], "dump": <path>,
        "skrin": "semasa"}. NEVER returns a bare 'B'/'A' verdict -- the
        mapping from what is on screen to the DB `status` column is
        unproven.

        C-10: parameter dahulunya bernama `no_notis`, yang membuat ia
        NAMPAK seperti kaedah ini membaca status rekod itu. Ia tidak —
        `no_notis` digunakan HANYA untuk menamakan fail dump. Pemanggil
        `-007` (k_007/l_007/p_007) memanggilnya sambil masih berada pada
        skrin SENARAI dan tidak pernah membuka rekod itu, jadi
        "status_texts" yang dilog sebagai bukti bagi `JB015K…` sebenarnya
        ialah TAJUK LAJUR tabel Senarai — bukti dilabel SALAH. Nama
        `dump_tag` menjadikan kekurangan itu tidak boleh disalah baca.

        Kalau bukti mesti benar-benar MILIK satu rekod, buka rekod itu
        IKUT NOMBOR dahulu (`senarai.open_record_by_number(no)` +
        `record_popup_shows_number(no)`) dan baru panggil ini. Selagi itu
        tidak dibuat, `print` dalam TC -007 TIDAK BOLEH berkata "Bukti
        status untuk <no>".

        `no_notis=` DIKEKALKAN hanya sebagai ALIAS LAPUK supaya tiga fail
        test `-007` (milik Mustaqim, R2) tidak menjadi TypeError. Ia
        mencetak AMARAN yang menyatakan dengan terang bahawa bukti ini
        TIDAK terikat kepada nombor itu."""
        if no_notis and not dump_tag:
            dump_tag = no_notis
            print(f"  [NOTIS KOMPAUN] AMARAN (C-10): dipanggil dengan "
                  f"no_notis={no_notis!r}, tetapi kaedah ini mengikis "
                  f"skrin SEMASA sahaja dan TIDAK membuka rekod itu. "
                  f"Nombor itu hanya menamakan fail dump. JANGAN label "
                  f"hasil ini sebagai bukti status milik {no_notis!r} "
                  f"melainkan rekod itu dibuka IKUT NOMBOR dahulu.")
        return self._kikis_status_skrin_semasa(dump_tag)

    def _baca_status_label(self):
        """Satu petikan `driver.find_elements(STATUS_LABEL)`, disendirikan
        supaya boleh dipanggil dua kali (sebelum/selepas skrol)."""
        texts = []
        try:
            for el in self.driver.find_elements(*self.STATUS_LABEL):
                t = (el.text or "").strip()
                if t:
                    texts.append(t)
        except Exception as e:                               # noqa: BLE001
            print(f"  [NOTIS KOMPAUN] WARNING: status probe failed ({e})")
        return texts

    def _kikis_status_skrin_semasa(self, dump_tag):
        """Kikis teks berbentuk-status pada skrin SEMASA (lihat
        read_notis_status_evidence).

        >>> PEMBAIKAN 2026-07-31 (saril, isu dibuka & diarah Loh) --
        SKROL-DAN-CARI, BUKAN BUKTI DILONGGARKAN. <<<
        Versi sebelum ini memanggil `driver.find_elements(STATUS_LABEL)`
        SEKALI TANPA skrol dahulu. Kesannya bukan false PASS (kaedah ini
        tidak pernah mendakwa nilai status tertentu -- lihat kontrak
        C-10 dalam docstring pemanggil), tetapi FALSE SKIP di hiliran: TC
        *-007 mentafsir senarai kosong sebagai "app tidak memaparkan
        status", lalu pytest.skip dengan sebab "verifikasi DB -- di luar
        skop device" — walhal medan berstatus itu mungkin cuma di bawah
        lipatan skrin semasa. Itu lebih senyap daripada kegagalan: laporan
        akhir mendakwa TC tersekat oleh jurang data yang tidak wujud.

        STATUS_LABEL sendiri KEKAL SAMA (padanan longgar sedia ada,
        `textMatches(".*status.*")`, tidak diperketat MAHUPUN
        dilonggarkan lagi) -- skrol di sini untuk MENDEDAHKAN elemen
        dalam pokok, bukan menerima padanan lain. Kosong selepas skrol
        penuh tetap dilaporkan sebagai kosong (dump ditulis sama ada
        cara pun).

        >>> TANDA TANGAN DIBETULKAN 2026-07-31 (Loh: API makmingg ialah
        otoriti). <<< Versi pertama memanggil
        `self.scroll_in_viewport(STATUS_LABEL, timeout=6)` di sebalik
        `hasattr()` -- TIDAK PADAN dengan tandatangan SEBENAR
        `scroll_in_viewport(direction="down", percent=0.3, context="")`
        (base_page.py:384); `hasattr()` tidak melindungi kerana kaedah
        itu MEMANG wujud. Ditukar kepada find_with_scroll()
        (base_page.py:531), yang MEMANG untuk "cari elemen, skrol kalau
        perlu" dan memulangkan elemen/None. `hasattr()` DIBUANG.

        # SAHKAN-DEVICE: (a) adakah popup notis MBJB memaparkan medan
        # STATUS langsung; (b) kalau ya, adakah nilainya huruf tunggal
        # ('B') atau perkataan penuh; (c) adakah "notis peringatan
        # pertama" mempunyai skrin/menu tersendiri yang belum diketahui.
        # Sehingga ketiga-tiga dijawab, TC *-007 tiada laluan device yang
        # jujur."""
        texts = self._baca_status_label()
        skrol_dicuba = False
        if not texts:
            skrol_dicuba = True
            self.find_with_scroll(self.STATUS_LABEL, timeout_each=6)
            texts = self._baca_status_label()
        tag = (dump_tag or "notis").replace("/", "_")
        path = self._dump(f"nk_status_evidence_{tag}.xml")
        if texts:
            print(f"  [NOTIS KOMPAUN] status-shaped texts on the CURRENT "
                  f"screen (bukan terikat kepada sebarang nombor rekod): "
                  f"{texts}")
        else:
            print(f"  [NOTIS KOMPAUN] no status-shaped text on the current "
                  f"screen (selepas cubaan skrol={skrol_dicuba}) -- the "
                  f"*-007 DB check has no UI proxy here")
        return {"status_texts": texts, "dump": path, "skrin": "semasa"}

    # TN-001 MBJB C10 step 3 says the action type (Kompaun / Patuh) is
    # chosen inside the SAME Tarik Notis flow. MBIP proved those buttons
    # live on the notice popup that opens from a pulled row -- which is
    # what open_notice_popup() + kompaun_action() / patuh() already do.
    # This wrapper exists so a TN-001 test can express the Excel wording
    # without a second flow being invented.
    def tarik_then_action(self, id_penguatkuasa, action, ulasan=None,
                          amaun=None, index=0):
        """Tarik Notis, open the first pulled notice, then take `action`
        ("kompaun" or "patuh") on it -- the single flow MBPG-TC-TN-001
        C10 describes.

        # SAHKAN-DEVICE: sama ada MBJB benar-benar menawarkan pilihan
        # tindakan sebaik selepas TARIK (satu skrin), atau sama seperti
        # MBIP ia hanya muncul selepas satu baris notis diketuk. Kalau
        # yang pertama, aliran ini perlu ditulis semula -- jangan paksa
        # bentuk MBIP kalau skrin berbeza."""
        action = (action or "").strip().lower()
        if action not in ("kompaun", "patuh"):
            raise ValueError(f"action mesti 'kompaun' atau 'patuh', "
                             f"bukan {action!r}")
        self.tarik_notis(id_penguatkuasa)
        self.open_notice_popup(index=index)
        if action == "patuh":
            if not ulasan:
                raise ValueError("PATUH memerlukan ulasan (medan wajib -- "
                                 "app melantun dengan 'ULASAN WAJIB DIISI.')")
            return self.patuh(ulasan)
        if not amaun:
            raise ValueError("KOMPAUN memerlukan amaun")
        return self.kompaun_action(amaun)

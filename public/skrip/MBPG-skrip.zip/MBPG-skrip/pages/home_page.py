"""
Home / Main Menu page — Page Object Model.
Shows a grid of module buttons after login.

PORT MBJB — SALIN BULAT (0 literal MBIP).
Nota: butang modul di bawah menggunakan wait_and_click(), bukan
wait_and_tap(). Itu terbukti berfungsi pada grid utama MBIP walaupun
CLAUDE.md memberi amaran el.click() senyap tak berkesan pada React
Native -- grid ini pengecualian yang terbukti.
# SAHKAN-DEVICE: kalau butang modul MBJB senyap tidak bertindak balas,
# INI tempat pertama untuk ditukar kepada wait_and_tap(). Jangan tukar
# sebelum gejala itu dilihat.
"""

from appium.webdriver.common.appiumby import AppiumBy
from pages.base_page import BasePage


class HomePage(BasePage):
    """Home screen (main menu grid) locators and actions."""

    # ---- Locators — SEMUA DISAHKAN PADA DEVICE ---------------------------
    # Dump ui_dumps\40_skrin_utama.xml (Loh 2026-07-30, APK 2.1.33-Dev).
    #
    # TAJUK SKRIN UTAMA = 'KOMPUAN e-PBT'  <- EJAAN APP **SALAH**
    # (sepatutnya KOMPAUN). resource-id='appbar-content-title-text'.
    # Sebarang locator yang mencari "KOMPAUN e-PBT" pada skrin utama TIDAK
    # AKAN PADAN. Jangan "betulkan" ejaan di sini — ia mesti sepadan dengan
    # apa yang app render. 'APLIKASI KOMPAUN e-PBT' (ejaan betul) ialah
    # tajuk skrin LOGIN, bukan skrin ini.
    SCREEN_TITLE = (AppiumBy.ANDROID_UIAUTOMATOR,
                    'new UiSelector().resourceId("appbar-content-title-text")')
    # >>> DIBETULKAN UNTUK MBPG 2.1.21 — 2026-08-10. <<<
    # Build MBJB memaparkan tajuk skrin utama SALAH EJA sebagai
    # "KOMPUAN e-PBT" (huruf 'A' tertinggal), dan suite MBJB mengekodkan
    # salah eja itu. MBPG 2.1.21 mengejanya BETUL: "Kompaun e-PBT".
    # Dibandingkan tidak-peka-huruf dan menerima kedua-dua ejaan supaya
    # ia betul pada mana-mana build.
    SCREEN_TITLE_TEXT_APP = "Kompaun e-PBT"

    # 5 kad, content-desc BERSIH (koordinat pusat dari dump):
    #   NOTIS AMARAN (540,558) · DAFTAR KOMPAUN (540,834)
    #   NOTIS KOMPAUN (540,1110) · SENARAI (540,1386) · HANTAR (540,1662)
    # >>> DIBETULKAN UNTUK MBPG 2.1.21 — 2026-08-10. <<<
    # MBJB memakai ACCESSIBILITY_ID huruf besar ("NOTIS AMARAN").
    # ACCESSIBILITY_ID ialah padanan content-desc TEPAT dan PEKA HURUF.
    # Recon device (recon/skrin_semasa.xml) menunjukkan kelima-lima kad
    # membawa content-desc Title Case pada ViewGroup boleh-klik:
    #     'Notis Amaran'  'Daftar Kompaun'  'Notis Kompaun'
    #     'Senarai'       'Hantar'
    # Tiada satu pun locator huruf besar memadan, jadi
    # is_home_screen_displayed() melaporkan "bukan skrin utama" pada
    # skrin utama SEBENAR — login kelihatan gagal sedangkan ia berjaya.
    #
    # Dipadan ikut DESCRIPTION, bukan teks: teks kad berada pada TextView
    # anak yang TIDAK boleh diklik, jadi padanan teks akan memulangkan
    # elemen yang salah kepada find_clickable().
    _KAD = 'new UiSelector().descriptionMatches("(?i)\s*{}\s*")'

    MODULE_NOTIS_AMARAN = (AppiumBy.ANDROID_UIAUTOMATOR,
                           _KAD.format("NOTIS\s+AMARAN"))
    MODULE_DAFTAR_KOMPAUN = (AppiumBy.ANDROID_UIAUTOMATOR,
                             _KAD.format("DAFTAR\s+KOMPAUN"))
    MODULE_NOTIS_KOMPAUN = (AppiumBy.ANDROID_UIAUTOMATOR,
                            _KAD.format("NOTIS\s+KOMPAUN"))
    MODULE_SENARAI = (AppiumBy.ANDROID_UIAUTOMATOR, _KAD.format("SENARAI"))
    MODULE_HANTAR = (AppiumBy.ANDROID_UIAUTOMATOR, _KAD.format("HANTAR"))

    # ---- 3 butang ikon bar atas ------------------------------------------
    # KETIGA-TIGANYA resource-id='icon-button' dan content-desc KOSONG.
    # Satu-satunya pembeza ialah GLIF pada anak TextView. Locator ikut
    # indeks icon-button membuta akan menekan butang yang salah kalau app
    # menyusun semula bar; padan ikut glif.
    #   chr(984147) = U+F0453  segar/sync  @ (678,204)
    #   chr(984106) = U+F042A  PRINTER     @ (834,204)  <- PowerRangersMerah
    #   chr(983875) = U+F0343  LOG KELUAR  @ (990,204)
    # WARNA ikon printer (MERAH/HIJAU) TIDAK ADA dalam XML — jangan
    # berpura-pura ia boleh dibaca dari atribut (fasa2-bootstrap §2.4).
    GLIF_SEGAR = chr(984147)
    GLIF_PRINTER = chr(984106)
    GLIF_LOG_KELUAR = chr(983875)
    ICON_SEGAR = (AppiumBy.ANDROID_UIAUTOMATOR,
                  f'new UiSelector().text("{chr(984147)}")')
    ICON_PRINTER = (AppiumBy.ANDROID_UIAUTOMATOR,
                    f'new UiSelector().text("{chr(984106)}")')
    ICON_LOG_KELUAR = (AppiumBy.ANDROID_UIAUTOMATOR,
                       f'new UiSelector().text("{chr(983875)}")')

    # >>> SKRIN UTAMA MBJB TIADA HAMBURGER. <<<
    # Dibuktikan: `` muncul SIFAR kali dalam ui_dumps\40_skrin_utama
    # .xml, sedangkan ia ada pada skrin LOGIN (ui_dumps\01_skrin_awal.xml).
    # Jadi log keluar MBJB melalui butang ikon glif U+F0343 pada bar atas,
    # BUKAN melalui item menu hamburger. Locator warisan MBIP di bawah
    # dikekalkan sebagai fallback sahaja.
    MENU_ITEM_LOG_OUT = (AppiumBy.ANDROID_UIAUTOMATOR,
                         'new UiSelector().textMatches("(?i)\\s*log\\s*out\\s*")')

    # ---- Actions ----

    def is_home_screen_displayed(self):
        """Verify home screen by checking for a home-grid module button.

        B2 — sebab dibetulkan kepada fakta device MBJB. Nota MBIP lama
        berkata hamburger "also renders on the login screen", seolah-olah
        ia ada pada kedua-dua skrin. Pada MBJB 2.1.33 ia ada pada skrin
        LOGIN SAHAJA: glif U+F0C9 = 2 kali dalam ui_dumps\\01_skrin_awal
        .xml, 0 kali dalam ui_dumps\\40_skrin_utama.xml. Memeriksanya di
        sini akan melaporkan "bukan skrin utama" SELAMANYA. NOTIS AMARAN
        hanya wujud pada grid utama sebenar — itu buktinya.

        Drains native alerts before giving up: a late Selaras result
        alert (Selaras Pengguna Apps' sync in particular can finish
        minutes after its own wait timed out) can be covering the home
        grid, and while a native alert is up UiAutomator only sees the
        dialog window -- everything behind it is invisible, so the grid
        looks 'not displayed' even though login succeeded.
        """
        if self.is_element_present(self.HOME_SCREEN_INDICATOR, timeout=10):
            return True
        if self.dismiss_native_alerts(first_timeout=3,
                                      context="home-screen check"):
            return self.is_element_present(self.HOME_SCREEN_INDICATOR,
                                           timeout=10)
        return False

    def open_notis_amaran(self):
        """Click Notis Amaran module on the home grid."""
        print("  [HOME] Opening Notis Amaran module...")
        self.wait_and_click(self.MODULE_NOTIS_AMARAN)

    def open_daftar_kompaun(self):
        """Click Daftar Kompaun module on the home grid."""
        print("  [HOME] Opening Daftar Kompaun module...")
        self.wait_and_click(self.MODULE_DAFTAR_KOMPAUN)

    def open_notis_kompaun(self):
        """Click Notis Kompaun module on the home grid."""
        print("  [HOME] Opening Notis Kompaun module...")
        self.wait_and_click(self.MODULE_NOTIS_KOMPAUN)

    def open_senarai(self):
        """Click Senarai module on the home grid."""
        print("  [HOME] Opening Senarai module...")
        self.wait_and_click(self.MODULE_SENARAI)

    def open_hantar(self):
        """Click Hantar module on the home grid."""
        print("  [HOME] Opening Hantar module...")
        self.wait_and_click(self.MODULE_HANTAR)

    def open_hamburger_menu(self):
        """Open the hamburger menu modal.

        AWAS — FAKTA DEVICE: skrin utama MBJB TIADA hamburger (0 kemunculan
        '' dalam ui_dumps\\40_skrin_utama.xml). Kaedah ini hanya sah
        pada skrin LOGIN, di mana hamburger membuka MENU SELARAS
        (ui_dumps\\02_menu_hamburger.xml). Ia melempar dengan diagnosis
        yang jelas dan bukan menunggu 15s tanpa sebab.
        """
        if not self.is_element_present(self.HAMBURGER, timeout=3):
            raise AssertionError(
                "tiada ikon hamburger pada skrin ini. Pada MBJB 2.1.33 "
                "hamburger HANYA ada pada skrin login (MENU SELARAS); "
                "skrin utama sebaliknya ada 3 butang icon-button "
                "(segar / printer / log keluar). Bukti: "
                "ui_dumps\\40_skrin_utama.xml vs ui_dumps\\01_skrin_awal.xml")
        print("  [HOME] Opening hamburger menu...")
        self.wait_and_tap(self.HAMBURGER)

    def log_out(self):
        """Log keluar melalui butang ikon glif U+F0343 pada bar atas.

        FAKTA DEVICE (ui_dumps\\40_skrin_utama.xml): tiada hamburger dan
        tiada item menu 'Log Out' pada skrin utama MBJB — log keluar ialah
        butang ikon ketiga di bar atas. Tap koordinat mentah, bukan
        el.click(), kerana Pressable RN app ini mengabaikan ACTION_CLICK
        (BRIEF Seksyen 3).
        # SAHKAN-DEVICE: apa yang muncul SELEPAS tap ikon log keluar
        # (dialog pengesahan Ya/Tidak, atau terus ke skrin login) — Loh
        # belum menekan ikon ini pada device.
        """
        if self.is_element_present(self.ICON_LOG_KELUAR, timeout=5):
            print("  [HOME] Tapping log-out icon (U+F0343)...")
            self.wait_and_tap(self.ICON_LOG_KELUAR)
        else:
            # Fallback warisan MBIP — dikekalkan, tidak dipercayai.
            print("  [HOME] log-out icon tidak dijumpai -- mencuba laluan "
                  "hamburger warisan MBIP...")
            self.open_hamburger_menu()
            self.wait_and_tap(self.MENU_ITEM_LOG_OUT)
        if self.is_element_present(self.BUTTON_YA, timeout=3):
            self.wait_and_tap(self.BUTTON_YA)
        self.dismiss_native_alerts(first_timeout=2, context="log keluar")
        # Kejayaan = skrin utama HILANG. Tanpa semakan ini, tap yang
        # senyap tidak berkesan dilaporkan sebagai "Logged out — PASS".
        if self.is_element_present(self.HOME_SCREEN_INDICATOR, timeout=5):
            raise AssertionError(
                "log keluar tidak berlaku: kad NOTIS AMARAN masih ada pada "
                "skrin selepas tap ikon log keluar (tap senyap tidak "
                "berkesan — BRIEF Seksyen 3)")
        print("  [HOME] Logged out — PASS")

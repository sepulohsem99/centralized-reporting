"""
Notis Amaran (Warning Notice) page — Page Object Model.
Flow: Tab Pesalah -> Tab Notis -> Tab Penerima -> Confirmation -> Submit

Rebuilt from the user's step-by-step manual (not just live UI dumps), so
field order and autocomplete/dropdown behaviour matches the real app flow.
"""

from appium.webdriver.common.appiumby import AppiumBy
from pages.base_page import BasePage
# Mesin dropdown Spinner tiga-tingkat dipinjam dari sini (lihat blok
# "Mesin dropdown Spinner — DIPINJAM, BUKAN DISALIN" dalam kelas).
from pages.daftar_kompaun_page import DaftarKompaunPage


class NotisAmaranPage(BasePage):
    """Notis Amaran screen — 3-tab form (Pesalah / Notis / Penerima)."""

    # ---- Screen title (appbar) — DISAHKAN DEVICE -------------------------
    # ui_dumps\41_notis_amaran_borang.xml: resource-id
    # 'appbar-content-title-text' text='NOTIS AMARAN'.
    SCREEN_TITLE = (AppiumBy.ANDROID_UIAUTOMATOR,
                    'new UiSelector().textMatches("(?i)\s*NOTIS\s+AMARAN\s*")')

    # ---- Tab identifiers — DISAHKAN DEVICE -------------------------------
    # 3 tab, content-desc BERSIH: PESALAH (180,372) · NOTIS (540,372) ·
    # PENERIMA (900,372) (dump 41).
    #
    # >>> URUTAN TAB DIKUATKUASAKAN OLEH APP. <<<
    # Fakta device (dump ui_dumps\47_tab_notis.xml): tap NOTIS sebelum tab
    # PESALAH lengkap menghasilkan alert asli
    #     alertTitle = 'MAKLUMAT TIDAK LENGKAP'
    #     message    = 'SILA LENGKAPKAN MAKLUMAT DI TAB PESALAH DAHULU.'
    # POM ini oleh itu TIDAK PERNAH melompat tab: ia melengkapkan PESALAH
    # dahulu dan bergerak melalui SETERUSNYA.
    TAB_PESALAH = (AppiumBy.ANDROID_UIAUTOMATOR,
                         'new UiSelector().descriptionMatches("(?i)\s*PESALAH\s*")')
    TAB_NOTIS = (AppiumBy.ANDROID_UIAUTOMATOR,
                         'new UiSelector().descriptionMatches("(?i)\s*NOTIS\s*")')
    TAB_PENERIMA = (AppiumBy.ANDROID_UIAUTOMATOR,
                         'new UiSelector().descriptionMatches("(?i)\s*PENERIMA\s*")')
    ALERT_TIDAK_LENGKAP = (AppiumBy.ANDROID_UIAUTOMATOR,
                           'new UiSelector().textMatches('
                           '"(?i)(?s).*maklumat\\s*tidak\\s*lengkap.*")')

    # ---- Pesalah tab field labels — DISAHKAN DEVICE (dump 41) ------------
    # AWAS: `text` bagi EditText ialah PLACEHOLDER bila kosong dan bertukar
    # jadi NILAI bila berisi (dump 46: 'MAKLUMAT JALAN' -> 'JALAN BAKAK').
    # Jadi locator ikut label BERHENTI berfungsi selepas medan diisi — itu
    # sebabnya fill_field_by_label_or_instance / _if_blank digunakan.
    # Medan wajib ditanda TextView text='*' BERASINGAN di sebelah medan,
    # BUKAN sebagai bahagian placeholder — jadi label di bawah TIDAK boleh
    # mengandungi '*'.
    LABEL_NAMA_PESALAH = "NAMA PESALAH"
    LABEL_NO_KP_SSM_KERETA = "NO KP/ SSM/ NO KERETA"
    LABEL_PESALAH_JALAN = "MAKLUMAT JALAN"
    LABEL_PESALAH_TAMAN = "MAKLUMAT TAMAN"
    LABEL_PESALAH_POSKOD = "MAKLUMAT POSKOD"
    LABEL_PESALAH_BANDAR = "MAKLUMAT BANDAR"
    LABEL_PESALAH_NEGERI = "MAKLUMAT NEGERI"
    # Checkbox DISAHKAN WUJUD dalam build MBJB @ [61,1971][169,2079]
    # (dump 41 — TextView label berasingan). Ini menjawab soalan terbuka
    # azharMadi tentang ciri copy-alamat pesalah -> premis: IA ADA.
    LABEL_TICK_ALAMAT_SAMA = "TICK JIKA ALAMAT PREMIS SAMA SEPERTI ALAMAT PESALAH"
    CHECKBOX_ALAMAT_SAMA = (AppiumBy.ANDROID_UIAUTOMATOR,
                            'new UiSelector().className('
                            '"android.widget.CheckBox")')

    # ---- Notis tab field labels — DIBETULKAN KEPADA FAKTA DEVICE --------
    # >>> BUG DIBETULKAN: label ini dahulunya Title Case ("Maklumat Jalan").
    # Pada device MBJB 2.1.33 semuanya HURUF BESAR (dump ui_dumps\
    # 50_selepas_seterusnya.xml). fill_field_by_label() memaafkannya kerana
    # _ci_label_locator() tidak sensitif huruf, TETAPI fill_notis_tab()
    # membina locator text() PEKA HURUF sendiri daripada
    # LABEL_NOTIS_JALAN — assert "Notis screen not visible" itu akan GAGAL
    # setiap run walaupun skrin betul-betul terpapar. <<<
    LABEL_NOTIS_JALAN = "MAKLUMAT JALAN"
    LABEL_NOTIS_TAMAN = "MAKLUMAT TAMAN"
    LABEL_NOTIS_POSKOD = "MAKLUMAT POSKOD"
    LABEL_NOTIS_BANDAR = "MAKLUMAT BANDAR"
    LABEL_NOTIS_NEGERI = "MAKLUMAT NEGERI"
    LABEL_LOKASI_KESALAHAN = "LOKASI KESALAHAN"
    LABEL_BUTIRAN_KESALAHAN = "BUTIRAN KESALAHAN"
    LABEL_TEMPOH_NOTIS = "MAKLUMAT KOMPAUN"  # on-screen label for tempoh (days)
    # Tajuk skrin tab NOTIS (bukan appbar) — dump 50.
    NOTIS_SCREEN_MARKER = (AppiumBy.ANDROID_UIAUTOMATOR,
                           'new UiSelector().textMatches("(?i)\s*PAPARAN\s+KOMPAUN\s*")')

    # ---- Dropdown kod kompaun — TIGA TINGKAT ----------------------------
    # FAKTA DEVICE (dump ui_dumps\51_notis_skrol.xml):
    #   * Ketiga-tiganya android.widget.Spinner, TIADA resource-id, TIADA
    #     content-desc. Label ialah TextView BERASINGAN:
    #       'KETERANGAN KOD KOMPAUN *' (540,1070)
    #       'KOD AKTA *'               (540,1390)
    #       'KESALAHAN KOMPAUN *'      (540,1635)
    #   * Tingkat 1 memaparkan nilai TERPILIH SEMASA melalui anak TextView
    #     resource-id='android:id/text1'. Pada device ia sudah BERISI
    #     ('AKTA JALAN PARIT & BANGUNAN & AKTA KERAJAAN TEMPATAN'), JADI
    #     text("PILIH KOMPAUN") TIDAK ADA PADA SKRIN dan locator
    #     berasaskan placeholder tidak boleh membukanya. Semua tiga tingkat
    #     kini dibuka dengan mengetuk Spinner sendiri — lihat
    #     fill_kompaun_code_fields() dan blok "Mesin dropdown Spinner".
    #   * Tingkat 2 dan 3 ialah Spinner NAF="true" dengan SIFAR anak
    #     TextView bila tiada pilihan — tiada teks 'PILIH AKTA'/'PILIH
    #     KESALAHAN' sama sekali dalam dump.
    #   * Tingkat 1 = 29 nilai (28 sebenar + placeholder 'PILIH KOMPAUN'),
    #     senarai penuh ui_dumps\kesalahan_tier1_PENUH_v2.txt.
    #   * SATU titik data (BUKAN dakwaan kategori D): tingkat 1 =
    #     'AKTA JALAN PARIT & BANGUNAN & AKTA KERAJAAN TEMPATAN' (nilai
    #     LALAI borang) membawa 0 pilihan tingkat 2 (ui_dumps\
    #     kesalahan_tier2_akta__AKTA_JALAN_PARIT_BANGUNAN_KT.txt kosong).
    #     >>> DIBETULKAN 2026-07-31 (dedah cuakKambing, diarah Loh) -- versi
    #     lama fail ini menyimpulkan "Ini jurang kategori D, bukan bug
    #     automation" daripada SATU sampel ini. Kesimpulan itu SALAH dan
    #     TELAH DITARIK BALIK oleh Loh (recon\PAPAN.md "ADJUDIKASI QA +
    #     KEBENARAN PEMETAAN" -> "TARIK BALIK: 'KOD AKTA KOSONG' ADALAH
    #     SALAH"): pemetaan bersistem merentas SEMUA 28 nilai tingkat 1
    #     membuktikan 18/28 memang membawa pilihan tingkat 2, dan 8/10
    #     laluan KESALAHAN sheet -005 disahkan wujud dalam DB staging
    #     (recon\PAPAN.md "10 LALUAN KESALAHAN — DISAHKAN PADA DEVICE").
    #     Nilai 0 di atas kekal betul HANYA untuk nilai LALAI ini secara
    #     khusus -- ia BUKAN bukti DB kosong dan BUKAN sesuatu untuk
    #     dilaporkan kepada pembangun MBJB. Kalau tingkat 2 kosong pada
    #     mana-mana nilai tingkat 1 LAIN, pilih nilai tingkat 1 yang lain
    #     (lihat daftar_kompaun_page._mesej_kategori_d() untuk mesej
    #     diagnostik yang sudah betul, dipinjam oleh fail ini melalui
    #     pilih_spinner_kod). <<<
    #
    # >>> KECACATAN DISAHKAN & DIBETULKAN (2026-07-30). <<<
    # Pemalar `PLACEHOLDER_PILIH_AKTA` / `PLACEHOLDER_PILIH_KESALAHAN`
    # DIBUANG. Loh menyemak SETIAP dump device: kedua-dua rentetan itu
    # TIDAK WUJUD di mana-mana, jadi fill_kompaun_code_fields() yang
    # menghantar rentetan itu kepada select_dropdown_option_and_confirm()
    # TIDAK PERNAH boleh membuka tingkat 2 atau 3 pada borang ini —
    # dan borang Notis Amaran ialah borang yang PALING KERAP dipakai
    # dalam suite. Tingkat kini dibuka dengan mengetuk SPINNER yang
    # dikenal pasti melalui LABEL TextView yang mendahuluinya
    # (pilih_spinner_kod, dipinjam daripada DaftarKompaunPage di bawah).
    #
    # Satu-satunya rentetan berbentuk "PILIH ..." yang BENAR-BENAR ada
    # pada device ialah 'PILIH JALAN | TAMAN' (autocomplete alamat,
    # ui_dumps\43_pilih_jalan_senarai.xml) dan 'PILIH KOMPAUN', yang
    # muncul hanya sebagai SATU BARIS DI DALAM dialog tingkat 1
    # (ui_dumps\kesalahan_tier1_PENUH_v2.txt baris 29) — tidak pernah
    # sebagai label Spinner, kerana tingkat 1 sudah ada nilai lalai.
    #
    # SYAK: belum disahkan selepas skrol penuh. Dakwaan "TIDAK WUJUD di
    # mana-mana" di atas dibuat 2026-07-30, SEBELUM penemuan 2026-07-31
    # bahawa `adb shell uiautomator dump` MEMBUANG nod `visible:false`
    # (recon\PAPAN.md blok "MULA DI SINI"). Spinner tingkat 3 pada dump
    # 51 menjulur ke y~1710, melepasi sempadan viewport boleh-skrol
    # y~1596 -- jadi anak `android:id/text1` yang mungkin ada di hujung
    # bawahnya boleh sahaja terlepas dari dump yang dijadikan asas
    # dakwaan ini. Ini tidak membatalkan pembetulan (mekanisme Spinner
    # yang menggantikan placeholder-text masih betul dan berfungsi),
    # tetapi dakwaan KEWUJUDAN placeholder belum disahkan selepas skrol
    # penuh ke hujung bawah Spinner tingkat 2/3.
    #
    # Pemalar di bawah TIDAK digunakan oleh mana-mana locator. Ia dikekalkan
    # sebagai REKOD supaya agent seterusnya yang terjumpa 'PILIH KOMPAUN'
    # dalam senarai tingkat 1 tidak tersalah anggap ia label Spinner dan
    # menulis semula bug yang baru sahaja dibuang.
    PLACEHOLDER_PILIH_KOMPAUN = "PILIH KOMPAUN"   # baris DALAM dialog sahaja
    # Nilai terpilih semasa mana-mana Spinner (guna untuk membukanya).
    SPINNER_TEXT1 = (AppiumBy.XPATH,
                     '//android.widget.Spinner//*'
                     '[@resource-id="android:id/text1"]')
    SPINNER_KELAS = "android.widget.Spinner"
    LABEL_TIER1 = (AppiumBy.ANDROID_UIAUTOMATOR,
                   'new UiSelector().textMatches('
                   '"(?i)(?s).*keterangan\\s*kod\\s*kompaun.*")')
    LABEL_TIER2 = (AppiumBy.ANDROID_UIAUTOMATOR,
                   'new UiSelector().textMatches("(?i)(?s).*kod\\s*akta.*")')
    LABEL_TIER3 = (AppiumBy.ANDROID_UIAUTOMATOR,
                   'new UiSelector().textMatches('
                   '"(?i)(?s).*kesalahan\\s*kompaun.*")')
    # Dialog pilihan Spinner — corak yang SAMA seperti autocomplete jalan
    # (ui_dumps\43_pilih_jalan_senarai.xml): resource-id
    # '<pakej>:id/select_dialog_listview' + satu CheckedTextView per
    # pilihan. resourceIdMatches, BUKAN nama pakej yang dihardcode
    # (Peraturan #3 — pakej datang dari profil).
    DIALOG_SENARAI = (AppiumBy.ANDROID_UIAUTOMATOR,
                      'new UiSelector().resourceIdMatches('
                      '".*:id/select_dialog_listview")')
    DIALOG_BARIS = (AppiumBy.ANDROID_UIAUTOMATOR,
                    'new UiSelector().className('
                    '"android.widget.CheckedTextView")')

    # ---- Camera ----
    # DISAHKAN DEVICE (dump 51): butang mempunyai content-desc='OPEN CAMERA'
    # DAN anak TextView text='OPEN CAMERA'; pembilang berasingan
    # 'GAMBAR TELAH DIAMBIL: 0/6' -> gunakan pembilang itu sebagai bukti
    # tangkapan benar-benar didaftarkan, jangan percaya kiraan tap.
    BUTTON_OPEN_CAMERA = (AppiumBy.ANDROID_UIAUTOMATOR,
                          'new UiSelector().textMatches("(?i)\s*OPEN\s+CAMERA\s*")')
    KIRAAN_GAMBAR = (AppiumBy.ANDROID_UIAUTOMATOR,
                     'new UiSelector().textMatches('
                     '"(?i)(?s).*gambar\\s*telah\\s*diambil.*")')
    # Confirmed via live UI dump: these are icon-font glyphs, not the
    # literal words "Snap"/"Tick" -- same convention as HAMBURGER in
    # base_page.py.
    BUTTON_SNAP = (AppiumBy.ACCESSIBILITY_ID, "")
    BUTTON_TICK_CONFIRM = (AppiumBy.ACCESSIBILITY_ID, "")

    # DISAHKAN pada MBPG 2.1.21 (dump kamera 2026-08-12): skrin kamera
    # membawa TEPAT glif yang sama seperti MBJB --
    #   U+F1BA snap  @[435,2076][645,2286]
    #   U+F1FD tick  @[805,2101][955,2262]
    #   U+2715 tutup @[900,228][1020,309]
    # jadi locator di atas betul; kegagalan run pertama BUKAN locator.
    #
    # Satu-satunya cara membezakan "kamera masih terbuka" daripada
    # "kamera sudah tertutup" ialah TextView ini -- borang di belakang
    # tidak dibongkar dari pokok view semasa kamera bertindih.
    CAMERA_OPEN_INDICATOR = (AppiumBy.ANDROID_UIAUTOMATOR,
                             'new UiSelector().textMatches('
                             '"(?i)\\s*FLASH\\s+OFF\\s*")')

    # ---- Penerima tab field labels ----
    LABEL_ARAHAN_TINDAKAN = "ARAHAN TINDAKAN"
    LABEL_NAMA_PENERIMA = "NAMA PENERIMA"
    LABEL_NO_IC_PENERIMA = "NO IC PENERIMA"
    FIELD_OPEN_SIGNATURE = (AppiumBy.ANDROID_UIAUTOMATOR,
                            'new UiSelector().textMatches("(?i)\s*OPEN\s+SIGNATURE\s*")')

    # ---- Confirmation / result popups ----
    # >>> BUG DIBETULKAN: textContains PEKA huruf besar-kecil, dan app ini
    # MEMAKSA HURUF BESAR pada teks dialog. SETIAP mesej dialog yang Loh
    # baca dari device adalah huruf besar sepenuhnya — 'BEJAYA',
    # 'LESEN SAMA.', 'MAKLUMAT TIDAK LENGKAP',
    # 'SILA LENGKAPKAN MAKLUMAT DI TAB PESALAH DAHULU.',
    # 'DATA PENGGUNA BERJAYA DISIMPAN!'. Frasa Title Case di bawah tidak
    # akan padan. Ditukar kepada textMatches tidak sensitif huruf: assert
    # yang SAMA masih dituntut, cuma tidak lagi peka huruf. <<<
    # SAHKAN-DEVICE: teks TEPAT kedua-dua dialog ini belum dilihat — Loh
    # belum menghantar satu pun Notis Amaran pada device (fasa2-bootstrap
    # "TIDAK terbukti": tiada satu pun rekod dicipta).
    POPUP_SIMPAN_MAKLUMAT = (AppiumBy.ANDROID_UIAUTOMATOR,
                             'new UiSelector().textMatches('
                             '"(?i)(?s).*simpan\\s*maklumat.*")')
    POPUP_CETAK_NOTIS_AMARAN = (AppiumBy.ANDROID_UIAUTOMATOR,
                                'new UiSelector().textMatches('
                                '"(?i)(?s).*cetak\\s*notis\\s*amaran.*")')

    # ========================================================================
    # Actions
    # ========================================================================

    def is_notis_amaran_screen_displayed(self):
        """Verify we are on the Notis Amaran screen."""
        return self.is_element_present(self.SCREEN_TITLE, timeout=10)

    # ---- Pesalah tab ----

    def fill_pesalah_tab(self, data):
        """Fill in the Pesalah tab fields.
        data must contain: nama_pesalah, no_kp_ssm_kereta, jalan,
        taman, poskod, bandar, negeri
        """
        import time
        print("\n  [NOTIS AMARAN] Filling Pesalah tab...")
        self.wait_and_click(self.TAB_PESALAH)

        # AUTOCOMPLETE DUA BENTUK -- rujukan untuk pembaca akan datang.
        # Tab PESALAH dan tab NOTIS/KOMPAUN merender cadangan MAKLUMAT
        # JALAN dalam DUA bentuk widget BERBEZA: PESALAH sebagai
        # `Spinner` + dialog (sama keluarga dengan mesin dropdown kod
        # kompaun di daftar_kompaun_page.py), NOTIS/KOMPAUN sebagai baris
        # teks biasa dalam borang (`Spinner: 0`) dengan format tiga
        # bahagian "JALAN | TAMAN | BANDAR" (lihat fill_notis_tab, yang
        # memanggil type_and_select_suggestion). Satu helper autocomplete
        # sahaja TIDAK cukup untuk kedua-dua bentuk.
        #
        # Kod di bawah TIDAK cuba buka Spinner PESALAH langsung -- ia
        # menaip nilai PENUH terus (lihat nota di bawah untuk sebabnya:
        # live-search tab PESALAH tidak pernah merender cadangan dalam
        # ~20s). Ini sengaja mengelak isu bentuk-widget sepenuhnya
        # (bukan mengabaikannya): kerana tiada percubaan membuka Spinner
        # itu, bentuknya tidak relevan kepada laluan ini.
        fields = [
            (self.LABEL_NAMA_PESALAH, data["nama_pesalah"]),
            (self.LABEL_NO_KP_SSM_KERETA, data["no_kp_ssm_kereta"]),
            # >>> TAMAN / POSKOD / BANDAR / NEGERI TIDAK LAGI DITAIP. <<<
            # KEPUTUSAN PEMILIK 2026-08-05.
            #
            # Keempat-empat medan ini ialah medan yang Excel katakan APP
            # isi sendiri selepas Jalan dipilih. Selagi suite menaipnya,
            # bug auto-isi kategori B itu BERTOPENG dan setiap run lulus
            # atas kerja kita sendiri. Kesan sampingan yang lebih buruk:
            # `poskod` menerima "990323112289" — satu nombor IC — dan ia
            # TERCETAK pada kompaun sebenar.
            #
            # Ukuran pemilik pada device menjelaskan rantaiannya: baris
            # selaras JALAN BAKAK tiada poskod -> poskod kosong -> rekod
            # tidak sync ke server -> status kekal 'M' -> H-001/TN-001/
            # NK-001/NK-002 gagal dan portal kosong. JALAN JAGONG 2 TEST
            # dilaporkan auto-isi KEEMPAT-EMPAT termasuk poskod.
            #
            # Maka: taip JALAN sahaja, kemudian BACA. Nilai sebenar
            # direkod oleh _rekod_autoisi_pesalah() di bawah.
            # RISIKO DITERIMA PEMILIK: kalau poskod wajib dan auto-isi
            # gagal, TC ini GAGAL dan hiliran skip berantai. Itu keadaan
            # SEBENAR app — JANGAN taip semula untuk menghijaukan run.
        ]
        # >>> PERBEZAAN TAB — JANGAN SATUKAN KEDUA-DUA TAB. <<<
        # Pada tab PESALAH ini, KELIMA-LIMA medan alamat adalah BOLEH DIISI:
        # enabled="true" (dump ui_dumps\41_notis_amaran_borang.xml dan
        # 46_borang_penuh.xml). Jadi penulisan tanpa syarat di bawah BETUL
        # di sini. Pada tab NOTIS medan yang SAMA adalah enabled="false"
        # (dump 50_selepas_seterusnya.xml) dan menaip ke dalamnya melontar
        # ralat — lihat fill_notis_tab(), yang guna
        # fill_field_by_label_if_editable(). Dua tab, dua kelakuan.
        #
        # # SAHKAN-DEVICE: pada tab PESALAH, memilih jalan dari autocomplete
        # # mengisi TAMAN/BANDAR/NEGERI tetapi POSKOD KEKAL KOSONG (dump 46:
        # # 'MAKLUMAT POSKOD' masih placeholder sedangkan jirannya berisi
        # # 'KAMPUNG BARU SKUDAI'/'SKUDAI'/'JOHOR DARUL TAKZIM').
        # # MBPG-TC-N-001!C11 menjangka Poskod turut diisi. Loh baru ada SATU
        # # sampel jalan — TIDAK cukup untuk melabel bug app lawan jurang
        # # data jalan tertentu. Kod ini SENGAJA tidak mengandaikan mana-mana
        # # arah: kita menaip poskod dari Excel seperti biasa, jadi ujian ini
        # # TIDAK boleh membezakan auto-populate app daripada taipan kita.
        # # Bukti auto-populate dikumpul pada tab NOTIS, di mana medan lumpuh
        # # dan hanya app yang boleh mengisinya.
        # Confirmed via live run: Negeri (the last field) alone took ~27s
        # to fill, ~9x every other field -- find_element wastes its full
        # 15s presence-wait before ever trying to scroll, and by the time
        # we reach Negeri the keyboard (still up from typing Bandar) has
        # pushed it out of the rendered viewport, so that dead wait
        # always happens. Scroll proactively right before it so it's
        # already rendered and the normal presence-wait succeeds fast.
        scroll_before = {self.LABEL_PESALAH_NEGERI}
        # v3: fill_field_by_label_or_instance, not fill_field_by_label --
        # this form KEEPS a pesalah draft across reopenings ("MAKLUMAT
        # PESALAH TELAH DI SIMPAN", confirmed live), so the placeholder
        # text can be gone before the run ever touches the field; the
        # instance index is the field's position among the tab's
        # EditTexts (same three-tier pattern as the Tetapan screens).
        for idx, (label, value) in enumerate(fields):
            if label in scroll_before:
                self._scroll_down()
            t0 = time.time()
            self.fill_field_by_label_or_instance(label, value, instance=idx)
            print(f"  [TIMING] '{label}' filled in {time.time() - t0:.2f}s")

        # >>> A1, 2026-08-05: JALAN mesti DIPILIH, bukan sekadar DITAIP. <<<
        # Run 2026-08-05 melaporkan "JAGONG auto-isi 0 medan". Itu ARTIFAK
        # ALAT, bukan fakta app: susunan log membuktikan bacaan berlaku
        # selepas jalan hanya DITAIP, dan auto-isi app dicetuskan oleh
        # PEMILIHAN cadangan (onChangeText -> senarai -> pilih), bukan oleh
        # taipan. Laluan pemilihan yang sama sudah berjaya pada tab NOTIS,
        # jadi ia diguna semula di sini dan bukan ditulis baharu.
        # Nilai penuh dipakai sebagai penapis: ia menyempitkan senarai
        # kepada jalan yang dimaksudkan, dan padanan baris dibuat ikut
        # AWALAN JALAN supaya TAMAN kekal output DB.
        # >>> PENAPIS = AWALAN PENDEK, bukan nilai penuh. 2026-08-06. <<<
        # Run selepas A1 membuktikan pemilihan berjalan tetapi senarai
        # TIDAK PERNAH dirender:
        #     [WARN] No suggestion dropdown appeared for 'MAKLUMAT JALAN'
        #            after typing 'JALAN JAGONG 2 TEST'
        # Sebabnya sudah tertulis dalam kod ini sendiri (select_dropdown_
        # option): "a very long value fed to the RN live-search returned
        # 'Tiada rekod dijumpai'... A short prefix narrows the list while
        # still rendering the row". Tab NOTIS berjaya kerana ia menaip
        # awalan pendek ("JALAN"), bukan nilai penuh — aku menghantar
        # nilai penuh dan mematikan carian.
        # Padanan BARIS kekal ikut awalan jalan PENUH, jadi ketepatan
        # tidak dilonggarkan: hanya PENAPIS yang dipendekkan.
        _awalan = " ".join(str(data["jalan"]).split()[:2]) or data["jalan"]
        self.type_and_select_suggestion(
            self.LABEL_PESALAH_JALAN, _awalan, data["jalan"])
        self._rekod_autoisi_pesalah(data.get("jalan"))
        print("  [NOTIS AMARAN] Pesalah tab filled — PASS")


    def click_seterusnya_from_pesalah(self):
        """Click Seterusnya on Pesalah tab to go to Notis tab.

        >>> 2026-08-06: DEDAH DAHULU, jangan hanya wait_and_click. <<<
        Smoke 2026-08-06 gagal DI SINI:
            Element not clickable after 15s (1 scroll attempt(s) out of
            up to 10 tried -- may have stopped early because a scroll
            stopped moving content): ('accessibility id', 'SETERUSNYA')
        Punca UTAMA ialah senarai cadangan yang kekal TERBUKA (lihat
        type_and_select_suggestion) — gelung skrol dalaman wait_and_click
        MENOLAK dirinya sendiri bila overlay ada, jadi ia berhenti selepas
        1 cubaan. Tetapi walaupun selepas itu dibaiki, SETERUSNYA berada
        di BAWAH LIPATAN pada borang ini (button-container y~4095,
        CLAUDE.md) dan borang ini kelas TRAVERSAL-FOKUS: gesture skrol
        tidak boleh dipercayai untuk mendedahkannya. Laluan SETERUSNYA tab
        NOTIS (baris ~751 di bawah) sudah lama guna _dedah_sebelum_cari();
        laluan tab PESALAH ini tertinggal. Sekarang kedua-duanya sama."""
        print("  [NOTIS AMARAN] Clicking Seterusnya to go to Notis tab...")
        self._dedah_sebelum_cari(self.BUTTON_SETERUSNYA, "SETERUSNYA")
        self.wait_and_click(self.BUTTON_SETERUSNYA)

    # ---- Notis tab ----

    def fill_notis_tab(self, data):
        """Fill in the Notis tab fields.
        data must contain: notis_jalan_partial, notis_jalan_suggestion,
        notis_taman, notis_poskod, notis_bandar, notis_negeri,
        lokasi_kesalahan, butiran_kesalahan, tempoh_notis,
        keterangan_kod_kompaun, kod_akta, kesalahan_kompaun
        """
        print("\n  [NOTIS AMARAN] Filling Notis tab...")
        # TAB_NOTIS is unreliable (confirmed via live run: this screen
        # was correctly displayed, with LABEL_NOTIS_JALAN etc. all
        # present, yet the TAB_NOTIS accessibility id still wasn't found
        # -- same phantom-tab issue as TAB_PENERIMA in fill_penerima_tab
        # below). Check for a field that's actually on this screen.
        #
        # Locator TIDAK SENSITIF HURUF (_ci_label_locator), bukan text()
        # mentah: label device ialah HURUF BESAR dan versi Title Case yang
        # dahulu ada dalam LABEL_NOTIS_JALAN menjadikan assert ini gagal
        # setiap run walaupun skrin betul-betul terpapar.
        # 'PAPARAN KOMPAUN' (tajuk skrin, dump 50) disemak dahulu kerana ia
        # unik kepada skrin ini dan tidak bertukar bila medan diisi.
        if not self.is_element_present(self.NOTIS_SCREEN_MARKER, timeout=5):
            # Alert 'MAKLUMAT TIDAK LENGKAP' bermakna app MENOLAK peralihan
            # tab kerana PESALAH belum lengkap (dump 47) — laporkan sebab
            # SEBENAR, jangan lapor "skrin tidak kelihatan".
            if self.is_element_present(self.ALERT_TIDAK_LENGKAP, timeout=2):
                try:
                    msg = self.driver.find_element(
                        *self.NATIVE_ALERT_MESSAGE).text
                except Exception:                            # noqa: BLE001
                    msg = "(tidak dapat dibaca)"
                raise AssertionError(
                    f"app MENOLAK peralihan ke tab NOTIS: {msg!r}. Tab "
                    f"PESALAH belum lengkap — urutan tab dikuatkuasakan "
                    f"(ui_dumps\\47_tab_notis.xml)")
            assert self.is_element_present(
                self._ci_label_locator(self.LABEL_NOTIS_JALAN), timeout=5), \
                "Notis screen not visible after clicking Seterusnya"

        # >>> JALAN NOTIS/PREMIS DARI ORACLE. 2026-08-06. <<<
        # Oracle yang dibetulkan MEMBEKALKAN nilai ini sekarang:
        #   MBPG-TC-N-001!C9 "Jalan Premis/Notis: JALAN ULU TIRAM
        #                     (pilih dari dropdown; jangka auto-isi:
        #                      Taman=ULU TIRAM, Bandar=PLENTONG,
        #                      Poskod=81800)"
        # `jalan_premis` ialah nilai itu. `notis_jalan_suggestion`
        # ('JALAN JAGONG 2 TEST') ialah nilai DEVICE yang didaftarkan pada
        # 2026-07-30 ketika C9 memang senyap — ia kini SANDARAN sahaja, dan
        # dikekalkan kerana K-001 (laluan MySIKAP) masih bergantung padanya.
        # Peraturan Keras #5: bila oracle bercakap, oracle yang menang.
        _jalan_notis = (data.get("jalan_premis")
                        or data.get("notis_jalan_suggestion"))
        _sumber = ("oracle C9 'Jalan Premis/Notis'"
                   if data.get("jalan_premis") else "device (didaftarkan)")
        # Penapis = awalan DUA PERKATAAN, bukan nilai penuh: nilai penuh
        # yang panjang mematikan carian langsung RN (lihat catatan yang sama
        # dalam fill_pesalah_tab dan select_dropdown_option).
        _awalan = (" ".join(str(_jalan_notis).split()[:2])
                   or data["notis_jalan_partial"])
        print(f"  [NOTIS AMARAN] jalan Notis/Premis = {_jalan_notis!r} "
              f"(sumber: {_sumber}; penapis {_awalan!r})")
        self.type_and_select_suggestion(
            self.LABEL_NOTIS_JALAN, _awalan, _jalan_notis)

        # The Taman/Bandar/Negeri auto-fill triggered by the Jalan
        # selection above happens asynchronously -- give it a moment to
        # land before checking those fields below, or the guard can race
        # it (StaleElementReferenceException / not-found handled there
        # either way, but this cuts how often that race fires at all).
        import time
        time.sleep(1.5)

        # ASSERT auto-isi lawan jangkaan oracle untuk jalan Notis/Premis
        # (JANGKAAN_AUTOISI['...']['jalan_premis']). Sauh indeks + jiran,
        # jadi ia berfungsi walaupun placeholder sudah hilang.
        self._rekod_autoisi_pesalah(_jalan_notis)

        # >>> FAKTA DEVICE — MEDAN INI DILUMPUHKAN, MENAIP MUSTAHIL. <<<
        # dump ui_dumps\50_selepas_seterusnya.xml: pada tab NOTIS,
        #   MAKLUMAT TAMAN / MAKLUMAT POSKOD / MAKLUMAT BANDAR /
        #   MAKLUMAT NEGERI
        # semuanya enabled="false" clickable="false" — app mengisinya
        # sendiri dari MAKLUMAT JALAN. Kod lama memanggil
        # fill_field_by_label(POSKOD) TANPA syarat: el.click() tidak
        # mendaftar dan send_keys melempar InvalidElementStateException,
        # yang akan mematikan gerbang create N-001/N-004.
        # fill_field_by_label_if_editable() (base_page) menaip HANYA kalau
        # medan benar-benar enabled, dan bila ia dilumpuhkan ia MELAPORKAN
        # nilai auto-populate sebenar tanpa mereka apa-apa.
        #
        # POSKOD ialah kes khas: pada satu sampel di device
        # (JALAN BAKAK | KAMPUNG BARU SKUDAI) TAMAN/BANDAR/NEGERI terisi
        # tetapi POSKOD KEKAL KOSONG, bercanggah dengan
        # MBPG-TC-N-001!C11 yang menjangka Poskod turut diisi. Loh baru ada
        # SATU sampel — belum cukup untuk melabel bug app.
        # # SAHKAN-DEVICE: sama ada POSKOD gagal auto-isi untuk SEMUA jalan
        # # (bug app, kategori B) atau hanya jalan tertentu (jurang data).
        # # Kod ini SENGAJA tidak mengandaikan mana-mana arah: ia melaporkan
        # # 'auto:KOSONG' dengan bising dan membiarkan assertion test
        # # mendedahkannya.
        keadaan_alamat = {}
        for label, kunci, sumber in (
            (self.LABEL_NOTIS_TAMAN, "notis_taman", "MBPG-TC-N-001!C11"),
            (self.LABEL_NOTIS_POSKOD, "notis_poskod", "MBPG-TC-N-001!C11"),
            (self.LABEL_NOTIS_BANDAR, "notis_bandar", "MBPG-TC-N-001!C11"),
            (self.LABEL_NOTIS_NEGERI, "notis_negeri", "MBPG-TC-N-001!C11"),
        ):
            keadaan_alamat[label] = self.fill_field_by_label_if_editable(
                label, data.get(kunci), sumber_excel=sumber)
        self.keadaan_alamat_notis = keadaan_alamat
        kosong = [l for l, k in keadaan_alamat.items()
                  if k == "auto:KOSONG"]
        if kosong:
            print(f"  [NOTIS AMARAN] AMARAN: medan auto-populate MASIH "
                  f"KOSONG selepas pilihan MAKLUMAT JALAN: {kosong} — "
                  f"MBPG-TC-N-001!C11 menjangka ia diisi. Dilaporkan, "
                  f"tidak ditampal dengan nilai rekaan.")

        # >>> DEDAH DAHULU, JANGAN BIAR LADDER MEMBAKAR MASA. 2026-08-06. <<<
        # Rakaman skrin memberi dua beku bersebelahan pada laluan ini:
        #   BEKU A 1:31-3:31 (121s) selepas LOKASI diisi, sebelum BUTIRAN
        #   BEKU B 3:52-6:04 (133s) selepas BUTIRAN, sebelum dropdown
        # Kedua-dua medan berada di BAWAH LIPATAN pada borang tab NOTIS,
        # dan borang ini kelas TRAVERSAL-FOKUS: setiap cubaan skrol dalam
        # find_element() dijamin sifar, tetapi tetap membayar tempoh
        # tunggunya. reveal_below_fold (melalui _dedah_sebelum_cari) ialah
        # satu-satunya mekanisme yang menggerakkan borang ini.
        # Kegagalan pendedahan TIDAK maut di sini — kita jatuh ke carian
        # biasa, corak yang sama dengan pilih_spinner_kod().
        for _label, _kunci in ((self.LABEL_LOKASI_KESALAHAN,
                                "lokasi_kesalahan"),
                               (self.LABEL_BUTIRAN_KESALAHAN,
                                "butiran_kesalahan")):
            try:
                self._dedah_sebelum_cari(self._ci_label_locator(_label),
                                         _label)
            except Exception as e:                           # noqa: BLE001
                print(f"  [NOTIS AMARAN] pendedahan '{_label}' tidak "
                      f"berjaya ({type(e).__name__}) — meneruskan carian "
                      f"biasa")
            self.fill_field_by_label(_label, data[_kunci])

        # Tempoh (MAKLUMAT KOMPAUN section) — locate the real EditText
        # (hint "TEMPOH NOTIS"), NOT the section-header TextView the
        # "MAKLUMAT KOMPAUN" label matches; force-clear + set + read-back
        # with a 0-21 range assertion. See base_page._set_tempoh_verified.
        self._apply_tempoh_from_data(data)

        print("  [NOTIS AMARAN] Notis tab filled — PASS")

    # ---- MBJB: tempoh hanya ditaip bila Excel membekalkannya --------------
    # DEV FIXING LIST MBJB baris 41 + 42 (DONE): TEMPOH KOMPAUN kini
    # mempunyai nilai default -- Notis 14 hari, Kompaun 21 hari -- dan boleh
    # diedit. Sel C9 MBJB TIDAK menyebut tempoh untuk mana-mana TC create.
    # Peraturan Keras #5: jangan taip nilai yang Excel tidak bekalkan. Jadi
    # bila kunci 'tempoh_notis' tiada, kita BIARKAN default app dan CATAT
    # nilai yang sebenarnya ada dalam medan itu, supaya laporan menunjukkan
    # apa yang dihantar. Bila kunci ADA, tingkah laku MBIP kekal 100%:
    # force-clear + set + read-back + semakan julat.
    def _apply_tempoh_from_data(self, data):
        if "tempoh_notis" in data and str(
                data["tempoh_notis"]).strip() != "":
            self._set_tempoh_verified(data["tempoh_notis"])
            return
        el = self._locate_tempoh_el()
        current = None
        if el is not None:
            try:
                current = el.text
            except Exception:                                # noqa: BLE001
                current = None
        print(f"  [TEMPOH] Excel senyap tentang tempoh -- mengekalkan "
              f"default app: {current!r} (tidak ditaip; lihat Peraturan #5)")
        # DISAHKAN pada device: default tab NOTIS ialah EditText pra-isi
        # `14` (dump ui_dumps\50_selepas_seterusnya.xml / 51_notis_skrol
        # .xml), sepadan DEV FIXING LIST baris 41-42.
        # SAHKAN-DEVICE: julat sah yang app terima. Julat 0-21 dalam
        # _set_tempoh_verified diwarisi dari MBIP dan BELUM diuji pada MBJB;
        # default borang Kompaun (dijangka 21) juga belum dilihat.

    def _teks_spinner(self):
        """Teks nilai-terpilih setiap Spinner pada skrin, ikut urutan tree.

        FAKTA DEVICE (dump 51): Spinner yang BERISI mendedahkan nilainya
        melalui anak `android:id/text1`; Spinner yang KOSONG (tiada
        pilihan) tiada anak TextView sama sekali. Jadi panjang senarai ini
        memberitahu berapa tingkat yang benar-benar boleh dibuka.
        """
        try:
            return [(el.text or "")
                    for el in self.driver.find_elements(*self.SPINNER_TEXT1)]
        except Exception:                                    # noqa: BLE001
            return []

    # ----------------------------------------------------------------------
    # Mesin dropdown Spinner — DIPINJAM, BUKAN DISALIN.
    #
    # Ketiga-tiga tingkat pada borang ini ialah `android.widget.Spinner`
    # yang IDENTIK dengan borang Daftar Kompaun (dump 51 vs dump borang
    # Kompaun: kelas sama, dialog sama, label mendahului Spinner sama).
    # Implementasi yang sudah lengkap hidup dalam DaftarKompaunPage dan
    # DIIKAT di sini sebagai atribut kelas supaya ada SATU salinan sahaja:
    # menyalinnya bermakna dua tempat perlu dibetulkan setiap kali device
    # mengajar kita sesuatu yang baharu.
    #
    # NotisAmaranPage sengaja TIDAK mewarisi DaftarKompaunPage: pewarisan
    # akan membawa masuk puluhan pemalar borang Kompaun (LABEL_KOMPAUN_*,
    # select_jenis_*, fill_kompaun_tab) yang TIDAK wujud pada skrin ini,
    # dan panggilan tersalah kepadanya akan gagal secara mengelirukan
    # dan bukan dengan AttributeError yang jujur.
    #
    # `_tag` dan `_regex_selamat` ialah staticmethod di sana — ia MESTI
    # dibalut semula dengan staticmethod(), kalau tidak `self` akan
    # dihantar sebagai argumen pertama.
    _titik = DaftarKompaunPage._titik
    _spinner_bawah_label = DaftarKompaunPage._spinner_bawah_label
    # Kawalan dropdown MBPG 2.1.21 ialah pressable RN, bukan Spinner.
    # Dieksport semula bersama sepupunya — _spinner_bawah_label
    # memanggilnya, jadi meninggalkannya di sini menghasilkan
    # AttributeError pada tingkat 1 (diperhati pada device
    # 2026-08-10).
    _pressable_bawah_label = DaftarKompaunPage._pressable_bawah_label
    _baris_modal_kini = DaftarKompaunPage._baris_modal_kini
    _tutup_modal_pressable = DaftarKompaunPage._tutup_modal_pressable
    _pilih_melalui_pressable = DaftarKompaunPage._pilih_melalui_pressable
    BARIS_MODAL = DaftarKompaunPage.BARIS_MODAL
    PLACEHOLDER_PILIH = DaftarKompaunPage.PLACEHOLDER_PILIH
    AWALAN_KOD_BARIS = DaftarKompaunPage.AWALAN_KOD_BARIS
    _padan_baris_modal = DaftarKompaunPage._padan_baris_modal
    PRESSABLE_PILIH = DaftarKompaunPage.PRESSABLE_PILIH
    _tag = staticmethod(DaftarKompaunPage._tag.__func__
                        if hasattr(DaftarKompaunPage._tag, "__func__")
                        else DaftarKompaunPage._tag)
    _regex_selamat = staticmethod(
        DaftarKompaunPage._regex_selamat.__func__
        if hasattr(DaftarKompaunPage._regex_selamat, "__func__")
        else DaftarKompaunPage._regex_selamat)
    _baris_dialog = DaftarKompaunPage._baris_dialog
    _skrol_dialog_perlahan = DaftarKompaunPage._skrol_dialog_perlahan
    _buka_dialog_spinner = DaftarKompaunPage._buka_dialog_spinner
    _tutup_dialog = DaftarKompaunPage._tutup_dialog
    _kumpul_dan_pilih = DaftarKompaunPage._kumpul_dan_pilih
    _tap_baris_dialog = DaftarKompaunPage._tap_baris_dialog
    _mesej_kategori_d = DaftarKompaunPage._mesej_kategori_d
    # Sandaran indeks (Syarat 1/2/3, recon\PAPAN.md entri azharMadi
    # 2026-07-31) -- dipinjam sama seperti selebihnya mesin ini supaya
    # SATU salinan sahaja wujud. Dipanggil oleh pilih_spinner_kod HANYA
    # selepas carian label gagal; baca-balik selepas pemilihan (dalam
    # pilih_spinner_kod itu sendiri) mengesahkan sandaran ini tidak
    # menuding Spinner yang salah.
    _spinner_ikut_indeks = DaftarKompaunPage._spinner_ikut_indeks
    pilih_spinner_kod = DaftarKompaunPage.pilih_spinner_kod

    def _dump_mbjb(self, name):
        """Dump page source ke ui_dumps/ (diperlukan oleh mesin Spinner
        yang diikat di atas). Bila locator tekaan tersasar, dump itulah
        deliverable-nya."""
        try:
            import os
            os.makedirs("ui_dumps", exist_ok=True)
            path = os.path.join("ui_dumps", name)
            with open(path, "w", encoding="utf-8") as f:
                f.write(self.driver.page_source)
            print(f"  [NOTIS AMARAN] DEBUG: page source dumped to {path}")
            return path
        except Exception:                                    # noqa: BLE001
            return "(dump failed)"

    # _dedah_sebelum_cari() DIPINDAHKAN ke BasePage 2026-08-05:
    # borang bookmark (BookmarkPage) dan laluan dropdown
    # DaftarKompaunPage juga kelas traversal-fokus dan
    # memerlukannya. Ia tidak pernah khusus Notis Amaran.
    def fill_kompaun_code_fields(self, data):
        """Pilih ketiga-tiga dropdown kod kompaun pada tab NOTIS.

        >>> DITULIS SEMULA 2026-07-30 — bentuk lama TIDAK BOLEH BERFUNGSI.
        Ia menghantar teks placeholder tingkat 2/3 ('PILIH ...') kepada
        select_dropdown_option_and_confirm(), yang mencari teks itu pada
        skrin untuk diketuk. Loh menyemak SETIAP dump device: teks itu
        TIDAK WUJUD. Tingkat 2 dan 3 ialah Spinner `NAF="true"` dengan
        SIFAR anak `android:id/text1` (ui_dumps\\51_notis_skrol.xml nod
        17 dan 19) — benar-benar KOSONG, tiada teks untuk dipadan. <<<

        Bentuk baharu: setiap tingkat dikenal pasti melalui LABEL TextView
        yang MENDAHULUINYA ('KETERANGAN KOD KOMPAUN *' -> 'KOD AKTA *' ->
        'KESALAHAN KOMPAUN *', kesemuanya DISAHKAN dalam dump 51), Spinner
        itu SENDIRI diketuk untuk membuka dialog `select_dialog_listview`,
        dan dialog di-skrol PERLAHAN (~40% viewport, 900ms) kerana swipe
        pantas MELOMPAT BARIS (Loh kehilangan 'KOMPAUN PELBAGAI BANGUNANS'
        begitu). Tiada koordinat keras — Peraturan #3.

        Tingkat 2 KOSONG dilaporkan BISING sebagai calon jurang kategori
        D, bukan diskip dan bukan senyap: mesejnya menyebut nilai tingkat
        1 yang dipilih, bahawa dialog terbuka dengan 0 pilihan, dan bahawa
        maknanya DB staging tiada KOD AKTA untuk kombinasi itu.
        Lihat pilih_spinner_kod() / _mesej_kategori_d().
        """
        print("  [NOTIS AMARAN] Selecting kompaun code dropdowns...")
        nilai1 = data["keterangan_kod_kompaun"]
        # Tingkat 1 SUDAH berfungsi tanpa dedahan -- JANGAN pecahkannya
        # dengan membalut panggilan ini (arahan Loh).
        self.pilih_spinner_kod(1, self.LABEL_TIER1, "KETERANGAN KOD KOMPAUN",
                               nilai1, nilai1)

        # Tingkat 2 (KOD AKTA) -- dedahkan label SEBELUM pilih_spinner_kod
        # mencarinya. Selepas tingkat 1 dipilih, tingkat 2/3 boleh berada
        # di bawah lipatan (borang menjulur ~2.5 skrin); pilih_spinner_kod
        # / _spinner_bawah_label() sendiri TIDAK skrol -- ia hanya carian
        # viewport-semasa + sandaran indeks, kedua-duanya viewport semasa
        # juga. Lihat _dedah_sebelum_cari().
        self._dedah_sebelum_cari(self.LABEL_TIER2,
                                 "label tingkat 2 'KOD AKTA'")
        self.pilih_spinner_kod(2, self.LABEL_TIER2, "KOD AKTA",
                               data["kod_akta"], nilai1)

        # Tingkat 3 (KESALAHAN KOMPAUN) -- sama.
        self._dedah_sebelum_cari(self.LABEL_TIER3,
                                 "label tingkat 3 'KESALAHAN KOMPAUN'")
        self.pilih_spinner_kod(3, self.LABEL_TIER3, "KESALAHAN KOMPAUN",
                               data["kesalahan_kompaun"], nilai1)
        # Bukti borang benar-benar kembali selepas tingkat terakhir:
        # 'OPEN CAMERA' DISAHKAN berada tepat di bawah tingkat 3 pada tab
        # NOTIS (dump 51 nod 22, content-desc DAN teks anak) -- TETAPI ia
        # juga tepat elemen yang logcat (recon\PAPAN.md "MULA DI SINI")
        # membuktikan berada di y=3924, jauh di bawah sempadan viewport
        # boleh-skrol y~1596. is_element_present() TIDAK skrol -- pemeriksaan
        # bertelanjang begini pada elemen bawah-lipatan boleh melaporkan
        # "borang tidak kembali" walaupun ia kembali dengan sempurna, cuma
        # belum diskrol ke bawah lagi.
        #
        # >>> TANDA TANGAN DIBETULKAN 2026-07-31 (Loh: API makmingg ialah
        # otoriti). <<< Versi pertama memanggil
        # `self.scroll_in_viewport(locator, timeout=8)` di sebalik
        # `hasattr()` -- TIDAK PADAN dengan tandatangan SEBENAR
        # `scroll_in_viewport(direction="down", percent=0.3, context="")`
        # (base_page.py:384). `hasattr()` tidak melindungi (kaedah itu
        # MEMANG wujud); `locator` akan masuk sebagai `direction` --
        # meletup atau skrol arah karut secara senyap, menyamar sebagai
        # kegagalan locator -- punca sebenar tiga run K1 yang gagal.
        # Ditukar kepada find_with_scroll() (base_page.py:531), yang
        # MEMANG untuk "cari elemen, skrol kalau perlu" dan memulangkan
        # elemen atau None. `hasattr()` DIBUANG.
        #
        # >>> DIBETULKAN 2026-08-04 — baris ini satu-satunya yang
        # terkecuali. <<< Ia memanggil `find_with_scroll()`, yang
        # gesture-sahaja, pada borang yang MENOLAK gesture. Tingkat 2
        # (:630), tingkat 3 (:636), `take_photos()` (:688) dan
        # `tap_seterusnya()` (:731) semuanya sudah melalui
        # `_dedah_sebelum_cari()`; hanya ini tidak.
        # Diukur pada run 2026-08-04: 10 skrol, SEMUA berkesan (>0px),
        # dan borang berhenti dengan 'GAMBAR TELAH DIAMBIL: 0/6' pada
        # [107,2307][974,2316] — 9 piksel di tepi bawah viewport. OPEN
        # CAMERA berada di bawahnya, jadi `visible:false` dan digugurkan
        # daripada dump. Gesture tidak boleh pergi lebih jauh; traversal
        # fokus boleh.
        # Mesej assert lama mendakwa "dialog mungkin masih terbuka" —
        # DIBUANG, ia terbukti PALSU: keadaan skrin pada saat kegagalan
        # menunjukkan ketiga-tiga nilai tingkat 1/2/3 sudah terpilih dan
        # borang sudah kembali.
        self._dedah_sebelum_cari(self.BUTTON_OPEN_CAMERA, "OPEN CAMERA")
        el = self.find_with_scroll(self.BUTTON_OPEN_CAMERA, timeout_each=8)
        assert el is not None, \
            ("FAIL: OPEN CAMERA tidak dijumpai selepas tingkat 3 — "
             "KEDUA-DUA laluan gagal (carian biasa pada viewport, DAN "
             "reveal_below_fold() traversal fokus). Ini kegagalan "
             "locator/data SEBENAR, bukan sekadar belum diskrol.")
        print("  [NOTIS AMARAN] Kompaun code dropdowns selected — PASS")

    def take_photos(self, count=3):
        """Open the in-app camera, snap `count` photos, then confirm with
        the tick icon.

        Jeda 3s selepas SETIAP tangkapan, bukan 1s: BRIEF Seksyen 3 dan
        reports\\fasa2-bootstrap.md §2.4 kedua-duanya mencatat kamera app
        ini MENJATUHKAN tap ~2-3 saat selepas setiap tangkapan. Dengan 1s,
        tap kedua dan ketiga hilang secara senyap dan gambar tidak cukup.

        Pembilang 'GAMBAR TELAH DIAMBIL: n/6' (DISAHKAN pada device, dump
        ui_dumps\\51_notis_skrol.xml, bermula 0/6) dibaca SELEPAS confirm
        supaya bilangan sebenar dilaporkan — kiraan tap bukan bukti.
        """
        print(f"  [NOTIS AMARAN] Opening camera for {count} photo(s)...")
        # OPEN CAMERA disahkan pada y~3924 dalam logcat (recon\PAPAN.md
        # "MULA DI SINI"), jauh di bawah sempadan viewport y~1596 --
        # dedahkan melalui reveal_below_fold() dahulu, JANGAN bergantung
        # pada gesture skrol wait_and_click/find_clickable punya sendiri
        # untuk borang ini. Lihat _dedah_sebelum_cari().
        self._dedah_sebelum_cari(self.BUTTON_OPEN_CAMERA, "OPEN CAMERA")
        self.wait_and_click(self.BUTTON_OPEN_CAMERA)
        import time
        time.sleep(1.5)

        # >>> DIBETULKAN 2026-08-12 selepas run recon pertama. <<<
        # Versi lama memanggil wait_and_click() untuk snap DAN tick.
        # wait_and_click() menghantar el.click() = ACTION_CLICK
        # accessibility, dan Pressable tersuai app ini NO-OP SENYAP pada
        # ACTION_CLICK -- punca yang SAMA seperti baris dropdown,
        # MENYERAHKAN (:971), dan baris cadangan. Dump kamera selepas run
        # itu menunjukkan 'FLASH OFF' MASIH pada skrin: tick tidak pernah
        # mendaftar. Guna tap_element() (tap koordinat mentah), seperti
        # MBJB.
        for i in range(count):
            print(f"  [NOTIS AMARAN]   Snapping photo {i+1}/{count}")
            self.tap_element(self.find_clickable(self.BUTTON_SNAP))
            time.sleep(3)

        print("  [NOTIS AMARAN] Confirming photos with tick icon...")
        # Tick MESTI diulang sehingga kamera benar-benar tertutup, bukan
        # ditekan sekali dan dianggap berjaya: tick hanya mendaftar
        # SELEPAS tangkapan terakhir mengendap, dan kamera menjatuhkan
        # setiap tap dalam tempoh itu. Tanpa gelung ini, run pertama
        # meninggalkan kamera TERBUKA lalu mencari pembilang pada skrin
        # yang tidak memilikinya, dan gagal dengan sebab yang mengelirukan
        # ("pembilang tidak dijumpai") sedangkan puncanya "tick tidak
        # mendaftar".
        #
        # X (U+2715) BUKAN pengganti: gambar dari sesi yang ditutup
        # melalui X muncul pada pembilang tetapi TIDAK memenuhi validasi
        # GAMBAR MESTI DIAMBIL borang -- hanya sesi yang ditutup dengan
        # tick yang memenuhinya.
        # Jeda tambahan sebelum tick PERTAMA. Tanpa ia, run 18:32 menekan
        # tick 3 kali (2s selang) dan kamera langsung tidak bergerak.
        time.sleep(4)

        # >>> RESIPI INI DIPEROLEH DARI PERANTI, BUKAN DITEKA. <<<
        # Turutan yang DISAHKAN menutup kamera (logcat 18:39:15
        # "Camera 0: Closed"):   snap -> jeda 4s -> tick
        # Turutan yang DISAHKAN TIDAK menutupnya:
        #     3 snap -> jeda 3s -> tick x3 (selang 2s)   [run 18:32]
        #     tick bersendirian, tanpa snap sebelumnya   [tap OS 18:37]
        # Tick diabaikan walaupun melalui suntikan sentuhan peringkat-OS
        # (adb input tap) dan melalui KEEMPAT-EMPAT mekanisme Appium
        # (clickGesture, el.click, W3C tahan-150ms, longClickGesture),
        # sedangkan atributnya enabled=true clickable=true displayed=true.
        # Jadi ini BUKAN masalah locator, koordinat, atau Appium: tick
        # hanya menerima tekanan apabila tangkapan SEGAR baru mengendap.
        #
        # Sebab itu pemulihan di bawah mengambil satu gambar TAMBAHAN
        # dan bukan sekadar menekan tick lagi -- menekan tick berulang
        # kali sudah terbukti tidak berkesan.
        tertutup = False
        gambar_diambil = count
        for cubaan in range(3):
            self.tap_element(self.find_clickable(self.BUTTON_TICK_CONFIRM))
            time.sleep(2.5)
            if not self.is_element_present(self.CAMERA_OPEN_INDICATOR,
                                           timeout=3):
                tertutup = True
                print(f"  [NOTIS AMARAN] kamera DISAHKAN tertutup "
                      f"(cubaan {cubaan + 1})")
                break
            # Had app ialah 6 gambar; jangan lampaui walaupun untuk pulih.
            if cubaan < 2 and gambar_diambil < 6:
                gambar_diambil += 1
                print(f"  [NOTIS AMARAN] tick diabaikan (cubaan "
                      f"{cubaan + 1}/3) -- mengambil gambar pengendap "
                      f"({gambar_diambil}/6) supaya tick menerima tekanan")
                self.tap_element(self.find_clickable(self.BUTTON_SNAP))
                time.sleep(4)
            else:
                print(f"  [NOTIS AMARAN] tick diabaikan (cubaan "
                      f"{cubaan + 1}/3) -- had 6 gambar dicapai, "
                      f"tap tick sahaja")
        assert tertutup, (
            "FAIL: tick tidak pernah menutup kamera selepas 3 cubaan. "
            "JANGAN tutup melalui X sebagai ganti -- gambar dari sesi "
            "yang ditutup dengan X tidak memenuhi validasi GAMBAR MESTI "
            "DIAMBIL, jadi borang akan ditolak kemudian dengan sebab "
            "yang tidak berkaitan.")
        time.sleep(1)
        # Pembilang 'GAMBAR TELAH DIAMBIL' duduk di y~3837 (dump 51),
        # sebaris dengan OPEN CAMERA (y~3924) — jauh di bawah sempadan
        # viewport y~1596.
        #
        # >>> DIBETULKAN 2026-08-04, punca SAMA seperti :662. <<<
        # Versi lama memanggil `find_element()` (base_page), yang skrol
        # dengan GESTURE. Borang ini kelas TRAVERSAL-FOKUS dan menolak
        # gesture, jadi pembilang tidak pernah terbaca — run 2026-08-04
        # mencetak tepat WARNING di bawah. Dedahkan dengan traversal
        # dahulu, sama seperti OPEN CAMERA dan SETERUSNYA.
        #
        # Dan WARNING itu sendiri melanggar Peraturan #6: ia mencetak
        # amaran, menelan kegagalan, lalu mencetak 'Photos taken — PASS'.
        # Pembilang app ialah SATU-SATUNYA bukti gambar benar-benar
        # didaftarkan (kiraan tap bukan bukti — kamera menjatuhkan tap
        # 2-3s selepas tangkapan). Tidak terbaca = tidak disahkan = GAGAL.
        #
        # Bacaan page_source ialah SANDARAN, bukan ganti. Traversal boleh
        # gagal atas sebab yang tiada kaitan dengan sama ada pembilang
        # wujud (run pertama: ia gagal kerana kamera masih bertindih),
        # dan pembilang yang BOLEH dibaca tidak sepatutnya dilaporkan
        # sebagai tidak boleh dibaca. Ia tidak melonggarkan apa-apa:
        # penegasan didaftar >= count di bawah kekal sama.
        kiraan = None
        try:
            self._dedah_sebelum_cari(self.KIRAAN_GAMBAR,
                                     "pembilang 'GAMBAR TELAH DIAMBIL'")
            kiraan = self.find_element(self.KIRAAN_GAMBAR, timeout=6).text
        except Exception as e:                                  # noqa: BLE001
            print(f"  [NOTIS AMARAN] traversal gagal mendedahkan pembilang "
                  f"({type(e).__name__}) -- membaca page_source terus")
            kiraan = self._kiraan_gambar_dari_sumber()
        assert kiraan, (
            "FAIL: pembilang 'GAMBAR TELAH DIAMBIL' tidak dapat dibaca "
            "melalui traversal MAHUPUN page_source. Tanpa pembilang tiada "
            "bukti gambar didaftarkan, dan kiraan tap bukan bukti.")
        print(f"  [NOTIS AMARAN] pembilang app: {kiraan!r} "
              f"(diminta {count})")
        import re as _re
        m = _re.search(r"(\d+)\s*/\s*(\d+)", kiraan or "")
        assert m, (f"FAIL: pembilang gambar dibaca tetapi tidak difahami: "
                   f"{kiraan!r} — dijangka bentuk 'n/6'")
        didaftar = int(m.group(1))
        assert didaftar >= count, (
            f"FAIL: app mendaftarkan {didaftar} gambar, diminta {count}. "
            f"Kamera app ini MENJATUHKAN tap 2-3s selepas setiap "
            f"tangkapan — kiraan tap BUKAN bukti, pembilang ini yang "
            f"menjadi bukti. Pembilang penuh: {kiraan!r}")
        print(f"  [NOTIS AMARAN] Photos taken — {didaftar} DISAHKAN "
              f"oleh pembilang app — PASS")

    def _kiraan_gambar_dari_sumber(self):
        """Pembilang gambar dibaca terus dari page_source, tanpa gesture
        dan tanpa traversal.

        Borang NOTIS ialah kelas TRAVERSAL-FOKUS: ia menolak gesture
        skrol, jadi pencari elemen biasa boleh gagal ke atas elemen yang
        MEMANG berada dalam pokok view. page_source membawa keseluruhan
        pokok yang dirender tanpa menyentuh skrin langsung -- pada run
        recon 2026-08-12 ia membaca 'Gambar telah diambil: 0/6' dengan
        betul pada saat pencari elemen tidak menemuinya.
        """
        import re as _re
        import xml.etree.ElementTree as _ET
        try:
            akar = _ET.fromstring(self.driver.page_source.encode("utf-8"))
        except Exception:                                       # noqa: BLE001
            return None
        for n in akar.iter():
            for atr in ("text", "content-desc"):
                v = (n.get(atr) or "").strip()
                if v and _re.search(r"gambar\s*telah\s*diambil", v, _re.I):
                    return v
        return None

    def click_seterusnya_from_notis(self):
        """Click Seterusnya on Notis tab to go to Penerima tab."""
        print("  [NOTIS AMARAN] Clicking Seterusnya to go to Penerima tab...")
        # SETERUSNYA (button-container) disahkan pada y~4095 dalam logcat
        # (recon\PAPAN.md "MULA DI SINI"), jauh di bawah sempadan
        # viewport y~1596 -- dedahkan melalui reveal_below_fold() dahulu.
        # Lihat _dedah_sebelum_cari().
        self._dedah_sebelum_cari(self.BUTTON_SETERUSNYA, "SETERUSNYA")
        self.wait_and_click(self.BUTTON_SETERUSNYA)

    # ---- Penerima tab ----

    def fill_penerima_tab(self, data):
        """Fill in the Penerima tab fields and draw signature.
        data must contain: arahan_tindakan, nama_penerima, no_ic_penerima
        """
        print("\n  [NOTIS AMARAN] Filling Penerima tab...")
        # Confirmed via live UI dump that clicking Seterusnya here pushes
        # a whole new screen ("PAPARAN PENERIMA") rather than switching a
        # same-screen tab -- there's no "PENERIMA" accessibility id on
        # it, so TAB_PENERIMA never matches. Check for a field that's
        # actually on this screen instead.
        arahan_tindakan_locator = (
            AppiumBy.ANDROID_UIAUTOMATOR,
            f'new UiSelector().text("{self.LABEL_ARAHAN_TINDAKAN}")')
        # recon\PAPAN.md "MULA DI SINI" -- tab PENERIMA ialah SATU-SATUNYA
        # bahagian borang Notis Amaran yang belum pernah dicapai berjaya
        # (3 run K1 gagal); punca yang disahkan bukan locator ini, tetapi
        # skrip PEMBUKA yang tidak pernah sampai ke skrin ini langsung.
        # Sebaik skrin ini dicapai, jangan ulangi kesilapan yang sama:
        # skrin ini BOLEH lebih panjang daripada satu paparan (borang
        # NOTIS memanjang 2.5 skrin), jadi ARAHAN TINDAKAN mungkin di
        # bawah lipatan bergantung susunan medan -- skrol-dan-cari dahulu,
        # bukan is_element_present() bertelanjang.
        #
        # >>> TANDA TANGAN DIBETULKAN 2026-07-31 (Loh: API makmingg ialah
        # otoriti). <<< `self.scroll_in_viewport(locator, timeout=5)` di
        # sebalik `hasattr()` TIDAK PADAN dengan tandatangan SEBENAR
        # `scroll_in_viewport(direction="down", percent=0.3, context="")`
        # -- ia akan menghantar `locator` sebagai `direction` dan meletup
        # atau skrol karut secara senyap. Ditukar kepada
        # find_with_scroll() (base_page.py:531), yang MEMANG untuk "cari
        # elemen, skrol kalau perlu". `hasattr()` DIBUANG.
        # >>> DIBETULKAN 2026-08-12 — skrin ini AKHIRNYA dicapai, dan ia
        # >>> tidak seperti yang diandaikan selama ini. <<<
        # Dump langsung MBPG 2.1.21 (recon-serah, C1-N-001-03) menunjukkan
        # Paparan Penerima membawa TEPAT ini:
        #     Paparan Penerima / OPEN SIGNATURE / Nama Penerima /
        #     No IC Penerima / MENYERAHKAN / Maklumat Notis Telah Di Simpan
        # TIADA 'ARAHAN TINDAKAN' -- medan itu milik Paparan NOTIS pada
        # MBPG, bukan Penerima. Menyauh skrin ini pada ARAHAN TINDAKAN
        # menjadikan ia MUSTAHIL dikesan: skrol dilaporkan 0px (borang
        # traversal-fokus), lalu gagal dengan "Penerima screen not
        # visible" sedangkan skrin itu SEDANG dipapar.
        #
        # Sauh pada apa yang MEMANG ada di sini. OPEN SIGNATURE dipilih
        # kerana ia kawalan yang fungsi ini betul-betul perlukan.
        sauh = self.find_with_scroll(self.FIELD_OPEN_SIGNATURE,
                                     timeout_each=5)
        assert sauh is not None, (
            "Skrin Penerima tidak kelihatan selepas Seterusnya — "
            "'OPEN SIGNATURE' tidak dijumpai.")

        # ARAHAN TINDAKAN kekal DIISI kalau ia hadir: varian build lain
        # (dan MBJB) meletakkannya di sini. Kalau tiada, ia bukan
        # kegagalan -- pada MBPG ia sudah diisi pada tab Notis.
        if self.is_element_present(arahan_tindakan_locator, timeout=2):
            self.fill_field_by_label(self.LABEL_ARAHAN_TINDAKAN,
                                     data["arahan_tindakan"])
        else:
            print("  [NOTIS AMARAN] 'ARAHAN TINDAKAN' tiada pada Paparan "
                  "Penerima MBPG — dilangkau (ia milik tab Notis di sini)")

        print("  [NOTIS AMARAN] Opening signature pad...")
        self.wait_and_click(self.FIELD_OPEN_SIGNATURE)
        import time
        time.sleep(1)

        self._draw_signature()

        print("  [NOTIS AMARAN] Closing signature popup...")
        closed = self.close_popup_by_icon(timeout=3)
        if not closed:
            print("  [NOTIS AMARAN] Close icon not found, tapping outside...")
            self.driver.tap([(540, 300)])
        time.sleep(1)

        # Lihat nota penuh dalam daftar_kompaun_page._fill_penerima.
        self._fill_penerima(self.LABEL_NAMA_PENERIMA,
                            data.get("nama_penerima"), "NAMA PENERIMA",
                            "nama_penerima")
        self._fill_penerima(self.LABEL_NO_IC_PENERIMA,
                            data.get("no_ic_penerima"), "NO IC PENERIMA",
                            "no_ic_penerima")

        print("  [NOTIS AMARAN] Penerima tab filled — PASS")

    def _fill_penerima(self, label, value, nama_papar, medan):
        """Isi medan penerima; kalau nilainya penanda (BLANK_MARKER teks
        atau BLANK_MARKER_IC berangka bagi medan dalam MEDAN_BERANGKA),
        log + BACA SEMULA medan selepas taip untuk laporkan nilai SEBENAR
        yang masuk. Medan berangka (no_ic_penerima) sudah dapat penanda
        berangka dari excel_data; read-back di sini mengesahkan ia benar
        masuk (bukan senyap kosong)."""
        # testdata.excel_data ialah modul MBJB: di sana nilai penerima
        # datang dari workbook dan sel kosong menjadi penanda yang boleh
        # dikesan. MBPG memandu dari oracle yang membekalkan nilai
        # SEBENAR, jadi modul itu tidak wujud di sini dan tiada apa yang
        # boleh menjadi penanda. Import keras memecahkan tab Penerima
        # sepenuhnya pada MBPG (ModuleNotFoundError, run 2026-08-12).
        try:
            from testdata.excel_data import (ialah_penanda,   # noqa: F401
                                             penanda_untuk)
        except ModuleNotFoundError:
            def ialah_penanda(_v):
                return False

            def penanda_untuk(_m):
                return None
        is_marker = ialah_penanda(value)
        expected = penanda_untuk(medan) if is_marker else value
        if is_marker:
            print(f"  [NOTIS AMARAN] {nama_papar}: menaip penanda "
                  f"{expected!r} — Excel tidak membekalkan nilai")
        el = self.fill_field_by_label(label, value)
        got = self._safe_text(el)
        # >>> DIBETULKAN 2026-08-04. <<< Bentuk lama menganggap `got is
        # None` bermakna "medan tidak menerima penanda" dan mencetak
        # WARNING yang mendakwa nilai sebenar ialah None. Itu SALAH, dan
        # ia bercanggah dengan dokumentasi `fill_field_by_label()`
        # sendiri (base_page.py): selepas menaip, handle elemen boleh
        # menjadi BASI kerana render-semula RN, dan `el.text` memulangkan
        # None. Dokumen itu menyatakan dengan jelas None bermakna "tidak
        # dapat dibaca semula", BUKAN "kosong" — malah ia sengaja
        # menganggap taipan itu mendarat dalam kes itu, kerana
        # force-clear pada medan yang tidak boleh dibaca pernah merosakkan
        # nilai yang sebenarnya betul (medan autocomplete MAKLUMAT JALAN).
        # Run 2026-08-04 mencetak amaran itu untuk NAMA PENERIMA; ia
        # penggera palsu.
        #
        # Kini tiga keadaan dibezakan, dan tiada satu pun mendakwa lebih
        # daripada yang diketahui:
        #   None            -> tidak dapat disahkan (bukan kegagalan)
        #   sama            -> disahkan mendarat
        #   berbeza & boleh dibaca -> medan BENAR-BENAR menolak penanda
        if not is_marker:
            print(f"  [NOTIS AMARAN] {nama_papar}: medan = {got!r} "
                  f"selepas taip")
            return
        if got is None:
            print(f"  [NOTIS AMARAN] {nama_papar}: penanda {expected!r} "
                  f"dihantar; read-back TIDAK DAPAT DIBACA (handle basi "
                  f"selepas render-semula RN — keadaan yang didokumen "
                  f"dalam fill_field_by_label). BUKAN bukti medan kosong. "
                  f"Bukti muktamad ialah penanda pada KERTAS.")
            return
        if self._norm(got) == self._norm(expected):
            print(f"  [NOTIS AMARAN] {nama_papar}: penanda {expected!r} "
                  f"DISAHKAN mendarat")
            return
        raise AssertionError(
            f"FAIL: {nama_papar} menolak penanda. Dihantar {expected!r}, "
            f"medan boleh dibaca dan mengandungi {got!r}. Medan yang "
            f"MENOLAK penanda tidak boleh dibiarkan senyap — ia bermakna "
            f"kertas akan membawa nilai yang tiada asas dalam Excel tanpa "
            f"sesiapa tahu (Peraturan Keras #5).")

    def _draw_signature(self):
        """Draw a simple smiley-like signature using W3C Actions."""
        print("  [NOTIS AMARAN] Drawing signature...")
        from selenium.webdriver.common.action_chains import ActionChains
        from selenium.webdriver.common.actions import interaction
        from selenium.webdriver.common.actions.action_builder import ActionBuilder
        from selenium.webdriver.common.actions.pointer_input import PointerInput

        actions = ActionChains(self.driver)
        pointer = PointerInput(interaction.POINTER_TOUCH, "finger")
        actions.w3c_actions = ActionBuilder(self.driver, mouse=pointer)
        actions.w3c_actions.pointer_action.move_to_location(400, 1200)
        actions.w3c_actions.pointer_action.pointer_down()
        actions.w3c_actions.pointer_action.move_to_location(500, 1150)
        actions.w3c_actions.pointer_action.move_to_location(600, 1250)
        actions.w3c_actions.pointer_action.move_to_location(700, 1180)
        actions.w3c_actions.pointer_action.move_to_location(800, 1220)
        actions.w3c_actions.pointer_action.release()
        actions.perform()
        # Bukti pad — lihat nota di daftar_kompaun_page._draw_signature
        # (arahan CEO 2026-08-19: cetakan tidak menunjukkan lukisan).
        import os
        import time as _t
        try:
            folder = os.path.join("reports", "forensik")
            os.makedirs(folder, exist_ok=True)
            laluan = os.path.join(
                folder, f"tandatangan_pad_N_"
                        f"{_t.strftime('%Y%m%d-%H%M%S')}.png")
            self.driver.get_screenshot_as_file(laluan)
            print(f"  [TANDATANGAN] bukti pad -> {laluan}")
        except Exception as e:                               # noqa: BLE001
            print(f"  [TANDATANGAN] tangkapan pad gagal "
                  f"({type(e).__name__}) — diteruskan")

    def click_menyerahkan(self):
        """Click the Menyerahkan button.

        Confirmed via live run: MENYERAHKAN sits right after the last
        typed field (NO IC PENERIMA), so the on-screen keyboard is still
        covering it at this point -- computing a raw coordinate tap from
        the element's rect() lands on the keyboard, not the button.
        Explicitly hide the keyboard first, then use tap_element (raw
        coordinate tap) rather than wait_and_click/el.click() -- same
        reasoning as the dropdown/suggestion rows elsewhere in this
        file, since this app's custom Pressables silently no-op on the
        accessibility ACTION_CLICK a plain el.click() sends.
        """
        print("  [NOTIS AMARAN] Clicking Menyerahkan...")
        try:
            if self.driver.is_keyboard_shown():
                self.driver.hide_keyboard()
                import time
                time.sleep(0.5)
        except Exception:
            pass
        el = self.find_clickable(self.BUTTON_MENYERAHKAN)
        self.tap_element(el)

    def confirm_and_submit(self):
        """Handle 'Simpan maklumat ini?' popup and click Hantar."""
        print("\n  [NOTIS AMARAN] Confirmation popup...")
        assert self.is_element_present(self.POPUP_SIMPAN_MAKLUMAT, timeout=10), \
            "Confirmation popup ('Simpan maklumat ini?') not displayed"
        print("  [NOTIS AMARAN] Confirmation popup visible — PASS")

        print("  [NOTIS AMARAN] Clicking Hantar...")
        # tap_element, not wait_and_click -- same custom-Pressable
        # no-op issue as MENYERAHKAN above.
        el = self.find_clickable(self.BUTTON_HANTAR)
        self.tap_element(el)

    def is_submission_successful(self):
        """Wait for progress bar to finish, then check for the
        'Cetak Notis Amaran?' success popup.

        Kelas B-1 (recon\\qa_findings.md B1): laluan ini SUDAH memakai
        lapisan kegagalan-dahulu `is_berjaya_message_visible()`, jadi ia
        tidak mengisytihar LULUS atas alert "TIDAK BERJAYA". Yang hilang
        ialah `read_record_number()` pada cabang kedua — tanpa itu N-001
        boleh LULUS dengan lejar KOSONG dan keadaan (b) tidak dapat
        dibezakan daripada (c). Diselaraskan dengan aliran Trafik: teks
        alert dibaca SEBELUM ditolak, penafian disemak DAHULU, dan nombor
        rekod dibaca pada SETIAP laluan kejayaan."""
        from pages.daftar_kompaun_page import adili_alert_hantar
        if self.is_element_present(self.POPUP_CETAK_NOTIS_AMARAN, timeout=30):
            print("  [NOTIS AMARAN] Submission successful — receipt popup visible — PASS")
            self.last_record_number = None
            self.read_record_number()  # capture no_notis before closing
            self.close_success_popup()
            return True

        v = adili_alert_hantar(self, "NOTIS AMARAN submit", first_timeout=5)
        if v["ditolak"]:
            self._dump_mbjb("notis_amaran_submit_ditolak.xml")
            print(f"  [NOTIS AMARAN] >>> PENGHANTARAN DITOLAK <<< alert "
                  f"MENAFIKAN kejayaan: {v['teks']!r} — FAIL")
            return False
        if v["disahkan"]:
            print(f"  [NOTIS AMARAN] Submission successful — success message "
                  f"visible; nombor rekod = "
                  f"{v['nombor'] or '(tidak terbaca — keadaan (c))'} — PASS")
            return True
        if v["nombor"]:
            print(f"  [NOTIS AMARAN] Submission successful — tiada teks "
                  f"kejayaan (alert: {v['teks']!r}) tetapi nombor rekod "
                  f"{v['nombor']} TERBACA (keadaan (b)) — PASS")
            return True

        print(f"  [NOTIS AMARAN] WARNING: Could not confirm submission "
              f"success — teks alert: {v['teks']!r}, nombor rekod tidak "
              f"terbaca")
        return False

    def close_success_popup(self):
        """Close the 'Cetak Notis Amaran?' popup via the red close icon."""
        print("  [NOTIS AMARAN] Closing success popup...")
        closed = self.close_popup_by_icon(timeout=3)
        if not closed:
            print("  [NOTIS AMARAN] No close icon found, pressing Back...")
            self.press_back()

"""
PRINTER TSC — penjanaan payload SAHAJA. Tiada apa dihantar.

>>> APA YANG SEBENARNYA ADA DALAM MBJB. <<<
Arahan pemilik menyebut "modul printer TSC dipulihkan dari mbjb". Yang
wujud dalam `mbjb-testing/pages/` ialah dua modul yang memandu UI
CETAK APP melalui Bluetooth — `printer_connect_page.py` (sambung ke
peranti TSC melalui popup app) dan `cetak_page.py` (ketuk butang CETAK
pada rekod). Kedua-duanya memandu SKRIN; tiada satu pun membina bait
TSC/TSPL.

Jadi tiada penjana payload untuk "dipulihkan" — app yang mencetak.
Modul ini oleh itu membina apa yang boleh dibina secara bermakna
tanpa perkakasan: **kandungan resit sebagai data berstruktur**, boleh
diperiksa dan diuji, yang boleh dibandingkan dengan resit sebenar
apabila Fasa C dihidupkan.

Ini dinyatakan dengan jelas supaya tiada siapa kemudian menganggap
modul ini sudah diuji terhadap pencetak sebenar. Ia TIDAK.

TIADA laluan penghantaran. `hantar()` sentiasa membangkitkan.
"""

from guard.gerbang_serah import SerahTidakDiizinkan

LEBAR = 32


class PayloadTerkunci(BaseException):
    """Percubaan menghantar payload ke perkakasan.

    BaseException, sama sebabnya seperti gerbang serah: ia tidak boleh
    ditelan oleh gelung cuba-semula. Mencetak resit kompaun ialah
    tindakan luaran — sekali kertas keluar, ia wujud.
    """


def _baris(kiri, kanan="", lebar=LEBAR):
    kiri, kanan = str(kiri), str(kanan)
    if not kanan:
        return kiri[:lebar]
    ruang = lebar - len(kiri) - len(kanan)
    if ruang < 1:
        return (kiri + " " + kanan)[:lebar]
    return kiri + " " * ruang + kanan


def _bungkus(teks, lebar=LEBAR):
    """Pemenggalan perkataan mudah. Keterangan kesalahan boleh mencecah
    434 aksara (kod 111 dalam DB production), jadi ia MESTI dipenggal
    atau resit kehilangan maklumat."""
    perkataan, baris, semasa = str(teks).split(), [], ""
    for p in perkataan:
        calon = (semasa + " " + p).strip()
        if len(calon) <= lebar:
            semasa = calon
        else:
            if semasa:
                baris.append(semasa)
            semasa = p[:lebar] if len(p) > lebar else p
    if semasa:
        baris.append(semasa)
    return baris or [""]


def bina_payload(rekod):
    """Kandungan resit sebagai senarai baris. TULEN — tiada I/O.

    `rekod` dijangka membawa: no_rekod, tarikh, pbt, kod_kompaun,
    akta, kesalahan, denda, nama_pesalah, no_kp, lokasi.
    Medan yang HILANG menjadi '-' dan bukan rentetan kosong, supaya
    resit menunjukkan bahawa medan itu wujud dan tidak diisi — bukan
    menyembunyikannya.
    """
    g = lambda k: str(rekod.get(k) or "-")            # noqa: E731

    baris = []
    baris.append(g("pbt").upper().center(LEBAR).rstrip())
    baris.append("NOTIS TAWARAN KOMPAUN".center(LEBAR).rstrip())
    baris.append("-" * LEBAR)
    baris.append(_baris("NO:", g("no_rekod")))
    baris.append(_baris("TARIKH:", g("tarikh")))
    baris.append("-" * LEBAR)
    baris.append("PESALAH")
    baris.extend(_bungkus(g("nama_pesalah")))
    baris.append(_baris("NO KP:", g("no_kp")))
    baris.append("-" * LEBAR)
    baris.append("KESALAHAN")
    baris.extend(_bungkus(g("kod_kompaun")))
    baris.extend(_bungkus(g("akta")))
    baris.extend(_bungkus(g("kesalahan")))
    baris.append("-" * LEBAR)
    baris.append("LOKASI")
    baris.extend(_bungkus(g("lokasi")))
    baris.append("-" * LEBAR)
    baris.append(_baris("DENDA (RM):", g("denda")))
    baris.append("-" * LEBAR)
    baris.append("SALINAN UJIAN".center(LEBAR).rstrip())
    return baris


def payload_teks(rekod):
    return "\n".join(bina_payload(rekod))


def hantar(payload, peranti=None):
    """TIADA LALUAN PENGHANTARAN. Sentiasa membangkitkan.

    Fungsi ini wujud supaya kod pemanggil boleh ditulis dan diuji
    sepenuhnya, dan supaya percubaan mencetak GAGAL BISING dan bukan
    diam-diam berjaya. Menghidupkan pencetakan ialah perubahan kod
    yang kelihatan dalam diff dan memerlukan kelulusan Fasa C.
    """
    raise PayloadTerkunci(
        f"CETAK DISEKAT — Fasa C berkunci. Payload {len(payload)} baris "
        f"dibina tetapi TIADA apa dihantar ke perkakasan. Menghidupkan "
        f"pencetakan memerlukan kelulusan bertulis PM+MBPG dan "
        f"perubahan kod yang disengajakan; ia bukan bendera.")


def sahkan_terkunci():
    """Digunakan oleh ujian gerbang dan oleh laluan Fasa C sebelum ia
    bermula: sahkan modul ini masih tidak boleh mencetak."""
    try:
        hantar(["ujian"])
    except PayloadTerkunci:
        return True
    raise SerahTidakDiizinkan(
        "printer_tsc.hantar() TIDAK lagi membangkitkan — laluan cetak "
        "telah dibuka tanpa kelulusan. HENTI.")

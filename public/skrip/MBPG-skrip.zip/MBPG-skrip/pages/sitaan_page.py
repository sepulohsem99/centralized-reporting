"""
Daftar Sitaan page — Page Object Model. v3-new (Phase 3).

Subclasses KompaunLesenPage: the Sitaan Pesalah tab was confirmed via
live recon (p3_sitaan_pesalah_top.xml) to carry the same fields as the
Lesen form (NAMA PEMILIK/SYARIKAT, NO K/P / SSM, NO AKAUN LESEN, address
block, plus a "TICK JIKA ALAMAT PREMIS SAMA..." checkbox that is left
untouched). The Kompaun tab and submission reuse the shared machinery.

The Barang-barang (seized items) section required by sheet MBPG-TC-S-001
has NOT been recon'd -- fill_barang_items is recon-first: it dumps the
form and tries candidate controls, logging clearly (non-fatally) when
the section can't be found so the create itself still completes and any
validation rejection surfaces honestly at submit.

PORT MBJB
---------
# SAHKAN-DEVICE: CLAUDE.md MBIP mengisytiharkan "Kadar Denda pada borang
# Sitaan tidak boleh dicapai", lalu menyekat S-001/S-003/S-004. Andaian
# itu BELUM DISAHKAN untuk MBJB dan bukti bercanggah: Excel
# MBPG-TC-S-001 C10 langkah 3 menyebut "select Kadar Denda (RM) within
# valid range" dengan Status Pass, dan tiada isu Kadar Denda Sitaan
# dalam DEV FIXING LIST MBJB. JANGAN bawa masuk skip MBIP itu secara
# automatik -- cuba pada device dahulu. TIER3_CONFIRM di bawah memang
# bergantung pada label PILIH KADAR DENDA wujud pada skrin ini.
#
# SAHKAN-DEVICE: belum disahkan pada MBJB — borang Sitaan MBJB BELUM
# PERNAH DIBUKA pada device (PAPAN.md §4 "Borang Kompaun Pelbagai /
# Letak Kereta / Lesen / Sitaan belum dibuka"). Seksyen BARANG-BARANG,
# ikon toggle U+F102 dan teks "TIADA BARANG DITAMBAH" dalam
# fill_barang_items() SEMUANYA datang daripada dump MBIP 2.1.17. Item +
# kuantiti mesti datang daripada TC_DATA (sheet MBPG-TC-S-001), bukan
# daripada nilai contoh MBIP.
#
# JANGKAAN S-001 — JANGAN ANGGAP IA SEPATUTNYA LULUS
# --------------------------------------------------
# `MBPG-TC-S-001!C13` = 'Pass' dan `C14` = 'N/A', tetapi Peraturan Keras
# #4 menyatakan status Excel BUKAN oracle: ia rekod run manual penguji
# pada setup LAIN (C5 = production `epbt.mbjb.gov.my`, C6 = IMEI device
# KETIGA `353466110954225`). Round recon manual yang kita SENDIRI ada
# bukti untuknya — MBIP — GAGAL tepat pada bahagian Barang-barang.
# Jadi: bila fill_barang_items() memulangkan False atau seksyen itu tidak
# dijumpai, itu BUKAN semestinya bug automation dan BUKAN semestinya
# regresi. Laporkan apa yang berlaku dengan dumpnya; jangan longgarkan
# assert supaya S-001 hijau, dan jangan tulis skip untuk menyembunyikannya.
"""

from appium.webdriver.common.appiumby import AppiumBy
from selenium.common.exceptions import TimeoutException
from pages.kompaun_lesen_page import KompaunLesenPage


class SitaanPage(KompaunLesenPage):
    """Daftar Kompaun — jenis SITAAN."""

    # Tidak sensitif huruf (app memaksa HURUF BESAR, fasa2-bootstrap §2.4).
    OPTION_SITAAN = (AppiumBy.ANDROID_UIAUTOMATOR,
                     'new UiSelector().textMatches("(?i)^\\s*sitaan\\s*$")')
    # Tier-3 close-evidence: the PILIH KADAR DENDA label, not OPEN
    # CAMERA -- confirmed via debug_dropdown_confirm.xml: on this form
    # the camera sits below the Barang section, and the amount field
    # carries no ENTER AMAUN hint (it renders holding "0").
    # textStartsWith PEKA huruf -> textMatches tidak sensitif huruf.
    # SAHKAN-DEVICE: label ini daripada dump MBIP; borang Sitaan MBJB
    # belum pernah dibuka (PAPAN.md §4).
    TIER3_CONFIRM = (AppiumBy.ANDROID_UIAUTOMATOR,
                     'new UiSelector().textMatches('
                     '"(?i)(?s)\\s*pilih\\s*kadar\\s*denda.*")')

    def select_jenis_sitaan(self):
        """Select SITAAN from the jenis popup (option confirmed present
        via live recon), verified-tap like the other jenis variants."""
        print("\n  [SITAAN] Selecting jenis: Sitaan...")
        import time
        # Open-evidence must NOT be "SITAAN text gone": the Sitaan
        # screen's own title is also "SITAAN" (bit us live). Use the
        # pesalah field appearing / another popup option vanishing.
        # Tidak sensitif huruf; dan calon KEDUA untuk medan pesalah kerana
        # borang Sitaan MBJB belum dibuka (SAHKAN-DEVICE) — pada borang
        # Notis Amaran MBJB medan pertama ialah 'NAMA PESALAH' (DISAHKAN,
        # ui_dumps\41_notis_amaran_borang.xml).
        pesalah_field = self._ci_label_locator("NAMA PEMILIK/SYARIKAT")
        pesalah_alt = self._ci_label_locator(self.LABEL_NAMA_PESALAH)
        # Bukti "popup masih terbuka": mana-mana pilihan LAIN masih ada.
        # MBJB menamakan modul ini 'LETAK KERETA', MBIP 'TRAFIK' — kedua-dua
        # diterima supaya bukti ini tidak lumpuh kalau namanya bertukar.
        # SAHKAN-DEVICE: teks sebenar pilihan pada popup PILIH KOMPAUN MBJB.
        other_option = (AppiumBy.ANDROID_UIAUTOMATOR,
                        'new UiSelector().textMatches('
                        '"(?i)^\\s*kompaun\\s+(trafik|letak\\s+kereta)\\s*$")')
        for attempt in range(3):
            self.wait_and_tap(self.OPTION_SITAAN)
            time.sleep(1.5)
            self.drain_printer_alert()
            # >>> KELAS B-1 (versi navigasi). <<< Dahulu "pilihan lain
            # hilang" ialah cabang OR yang SETARAF dengan bukti positif,
            # dan ia mencetak "PASS". Ketiadaan elemen SAHAJA bukan bukti
            # borang terbuka: alert asli beratur boleh menelan tap dan
            # menutup popup TANPA borang dibuka (fasa2-bootstrap
            # "PENEMUAN TEKNIKAL BAHARU" #2). Bukti POSITIF didahulukan;
            # bukti negatif diturunkan pangkat kepada AMARAN + dump.
            if (self.is_element_present(pesalah_field, timeout=4)
                    or self.is_element_present(pesalah_alt, timeout=2)):
                print("  [SITAAN] Jenis Sitaan selected — medan pesalah "
                      "kelihatan — PASS")
                self._dump("sitaan_pesalah_tab.xml")
                return
            if not self.is_element_present(other_option, timeout=2):
                print("  [SITAAN] AMARAN: popup jenis hilang TETAPI tiada "
                      "medan borang dikenali kelihatan — meneruskan tanpa "
                      "mengisytihar PASS; kegagalan seterusnya akan "
                      "menunjukkan skrin sebenar (dump ditulis)")
                self._dump("sitaan_jenis_hilang_tanpa_borang.xml")
                return
            print(f"  [SITAAN] Jenis popup still open after tap "
                  f"(attempt {attempt + 1}/3) -- re-tapping...")
        self._dump("sitaan_jenis_popup_stuck.xml")
        raise TimeoutException(
            "SITAAN option never registered a tap; see "
            "ui_dumps/sitaan_jenis_popup_stuck.xml")

    def fill_barang_items(self, items):
        """Add the seized items (sheet MBPG-TC-S-001 -- nilai datang dari TC_DATA,
        KERUSI 4 UNIT). Recon-first: the section's controls are searched
        via candidates; a page-source dump is written either way.

        NON-FATAL by design: if the section isn't found, the create
        proceeds and any validation rejection is reported at submit."""
        import time
        print(f"  [SITAAN] Adding barang items: {items}")
        self._dump("sitaan_barang_area.xml")

        # Tidak sensitif huruf, dan tanda sengkang dijadikan pilihan: app
        # memaksa HURUF BESAR dan ejaan 'BARANG BARANG' / 'BARANG-BARANG'
        # belum disahkan pada MBJB (SAHKAN-DEVICE — dump MBIP sahaja).
        section = (AppiumBy.ANDROID_UIAUTOMATOR,
                   'new UiSelector().textMatches('
                   '"(?i)(?s).*barang[\\s-]*barang.*")')
        try:
            self.find_element(section, timeout=8)
        except TimeoutException:
            print("  [SITAAN] WARNING: no 'BARANG-BARANG' section found "
                  "on this screen -- items not added (see "
                  "ui_dumps/sitaan_barang_area.xml); continuing")
            return False

        # The section header carries a toggle icon (U+F102, confirmed
        # via debug_dropdown_confirm.xml) that expands the add-item UI
        # ("TIADA BARANG DITAMBAH" shows while the list is empty).
        toggle = (AppiumBy.ANDROID_UIAUTOMATOR,
                  'new UiSelector().description("")')
        if self.is_element_present(toggle, timeout=3):
            el = self.find_element(toggle, timeout=3)
            self.tap_element(el)
            import time as _t
            _t.sleep(1.5)
            self._dump("sitaan_barang_expanded.xml")

        added = 0
        for name, qty in items:
            # candidate name/qty inputs: try label-based fills first
            filled_name = self._fill_first_matching(
                ["NAMA BARANG", "BARANG", "ITEM"], name, optional=True)
            filled_qty = self._fill_first_matching(
                ["KUANTITI", "UNIT", "BILANGAN", "QTY"], qty,
                optional=True, use_mobile_type=True)
            if filled_name is None and filled_qty is None:
                print(f"  [SITAAN] WARNING: no input fields for barang "
                      f"{name!r} -- stopping item entry")
                self._dump("sitaan_barang_inputs_missing.xml")
                break
            # add/confirm row button
            tambah = (AppiumBy.ANDROID_UIAUTOMATOR,
                      'new UiSelector().textMatches("(?i)\\s*(tambah|'
                      'add|\\+)\\s*")')
            if self.is_element_present(tambah, timeout=3):
                el = self.find_element(tambah, timeout=3)
                self.tap_element(el)
                import time as _t
                _t.sleep(1)
            added += 1
            print(f"  [SITAAN] barang added: {name} x {qty}")
        self._dump("sitaan_barang_after.xml")
        return added == len(items)

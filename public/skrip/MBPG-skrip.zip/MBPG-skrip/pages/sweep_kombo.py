"""
Enjin sweep kombo — tiga dropdown, satu set pada satu masa.

APA YANG SWEEP LAKUKAN
----------------------
Buka borang -> pilih Keterangan Kod Kompaun -> pilih Akta -> pilih
Kesalahan -> BACA kadar denda yang terpapar -> keluar. Itu sahaja.

APA YANG IA TIDAK LAKUKAN, DAN KENAPA
-------------------------------------
Tiada medan pesalah, tiada kamera, tiada tandatangan, tiada SERAH. Sweep
menguji satu soalan: adakah pokok dropdown pada peranti sepadan dengan
snapshot mapping? Mengisi baki borang tidak menambah bukti kepada soalan
itu dan menambah 330 peluang untuk menyentuh sesuatu yang tidak sepatutnya.

Kadar denda DIBACA, tidak ditulis. Mapping tidak membawa kadar denda
langsung, jadi tiada nilai jangkaan untuk dibandingkan — apa yang app
papar ialah dapatan, dan mereka-cipta nilai "jangkaan" untuk diperiksa
akan mencipta kelulusan palsu.

Corong dry-run terpakai penuh. Sweep tidak meminta pengecualian.
"""

import time

from guard.dasar import DryRunViolation


class KeputusanSet:
    """Satu baris MATRIX. Setiap medan diisi daripada apa yang BERLAKU,
    bukan daripada apa yang sepatutnya berlaku."""

    __slots__ = ("set_id", "borang", "kompaun_ok", "akta_ok", "kesalahan_ok",
                 "denda", "catatan", "jangkaan", "saat")

    def __init__(self, set_id, borang, jangkaan):
        self.set_id = set_id
        self.borang = borang
        self.jangkaan = jangkaan
        self.kompaun_ok = ""
        self.akta_ok = ""
        self.kesalahan_ok = ""
        self.denda = ""
        self.catatan = ""
        self.saat = 0.0

    def sebagai_baris(self):
        return [self.set_id, self.borang, self.jangkaan, self.kompaun_ok,
                self.akta_ok, self.kesalahan_ok, self.denda,
                f"{self.saat:.1f}", self.catatan]

    @staticmethod
    def pengepala():
        return ["set_id", "borang", "jangkaan", "kompaun_ok", "akta_ok",
                "kesalahan_ok", "denda", "saat", "catatan"]


TAJUK_MATRIX = KeputusanSet.pengepala()


def _catat(kep, teks):
    kep.catatan = (kep.catatan + " | " + teks) if kep.catatan else teks


def sapu_satu_set(page, s, borang):
    """Pandu satu set melalui tiga dropdown. Pulangkan KeputusanSet.

    TIDAK melempar untuk kegagalan set biasa — kegagalan satu kombinasi
    ialah DATA, dan menghentikan run pada set ke-7 daripada 330 akan
    membuang bukti untuk 323 yang lain. Ia dicatat dan sweep meneruskan.

    DUA pengecualian dibiarkan menembusi, dan kedua-duanya BaseException
    supaya ia tidak boleh ditelan di sini secara tidak sengaja:
      DryRunViolation — kami cuba menekan sesuatu yang dilarang.
      RestoreGagal    — peranti tinggal dalam keadaan yang salah.
    Kedua-duanya bermakna berhenti sekarang, bukan "cuba set seterusnya".
    """
    kep = KeputusanSet(s["set_id"], borang, s["jangkaan"])
    mula = time.time()
    try:
        _sapu(page, s, kep)
    except DryRunViolation:
        raise
    except BaseException as e:                                # noqa: BLE001
        # RestoreGagal dan apa-apa BaseException lain (KeyboardInterrupt,
        # SystemExit) mesti menembusi.
        if not isinstance(e, Exception):
            raise
        _catat(kep, f"{type(e).__name__}: {e}")
    finally:
        kep.saat = time.time() - mula
    return kep


def _sapu(page, s, kep):
    kod = s["kod_kompaun"]
    akta = s["akta"]
    kesalahan = s["kesalahan"]
    jangkaan = s["jangkaan"]

    # ---- Tingkat 1: Keterangan Kod Kompaun --------------------------
    nilai1 = kod["nama"]
    try:
        page.pilih_spinner_kod(1, page.LABEL_TIER1, "KETERANGAN KOD KOMPAUN",
                               nilai1, nilai1)
        kep.kompaun_ok = "YA"
    except AssertionError as e:
        kep.kompaun_ok = "TIDAK"
        _catat(kep, f"tingkat1 gagal: {_ringkas(e)}")
        return

    # ---- JANGKA_KOSONG: dropdown Akta patut KOSONG ------------------
    if jangkaan == "JANGKA_KOSONG":
        kosong, bukti = _dropdown_kosong(page, 2, page.LABEL_TIER2, "KOD AKTA")
        kep.akta_ok = "KOSONG-SEPERTI-DIJANGKA" if kosong else "ADA-ISI"
        if kosong:
            _catat(kep, "set negatif LULUS: dropdown Akta kosong")
        else:
            _catat(kep, f"DAPATAN: mapping kata kod {kod['kod']} tiada akta, "
                        f"tetapi app memaparkan {bukti}")
        return

    # ---- Tingkat 2: Akta ---------------------------------------------
    try:
        page.pilih_spinner_kod(2, page.LABEL_TIER2, "KOD AKTA",
                               akta["nama"], nilai1)
        kep.akta_ok = "YA"
    except AssertionError as e:
        kep.akta_ok = "TIDAK"
        _catat(kep, f"tingkat2 gagal: {_ringkas(e)}")
        return

    # ---- JANGKA_MATI_T3: dropdown Kesalahan patut KOSONG -------------
    if jangkaan == "JANGKA_MATI_T3":
        kosong, bukti = _dropdown_kosong(page, 3, page.LABEL_TIER3,
                                         "KESALAHAN KOMPAUN")
        kep.kesalahan_ok = "KOSONG-SEPERTI-DIJANGKA" if kosong else "ADA-ISI"
        if kosong:
            _catat(kep, "set negatif LULUS: dropdown Kesalahan kosong")
        else:
            _catat(kep, f"DAPATAN: mapping kata akta {akta['id']} tiada "
                        f"kesalahan, tetapi app memaparkan {bukti}")
        return

    # ---- Tingkat 3: Kesalahan ----------------------------------------
    nilai3 = kesalahan["keterangan"]
    try:
        page.pilih_spinner_kod(3, page.LABEL_TIER3, "KESALAHAN KOMPAUN",
                               nilai3, nilai1)
        kep.kesalahan_ok = "YA"
    except AssertionError as e:
        kep.kesalahan_ok = "TIDAK"
        _catat(kep, f"tingkat3 gagal: {_ringkas(e)}")
        return

    if jangkaan == "AMBIGU":
        _catat(kep, f"AMBIGU: nama akta {akta['nama']!r} berulang dalam "
                    f"mapping; pemilihan ini mungkin datang dari akta id "
                    f"yang LAIN")

    # ---- Baca kadar denda (BACA, jangan tulis) -----------------------
    kep.denda, nota_denda = _baca_denda(page)
    if nota_denda:
        _catat(kep, nota_denda)

    # Semak silang terhadap set (yang dijana dari DB). Percanggahan
    # antara apa yang APP papar dan apa yang DB simpan ialah dapatan
    # sebenar, dan ia hanya kelihatan kalau kami membandingkannya.
    _semak_julat_denda(page, s, kep)


def _semak_julat_denda(page, s, kep):
    lo_app, hi_app = julat_dipapar(page)
    d = (s.get("denda") or {})
    lo_db, hi_db = d.get("min"), d.get("max")
    if lo_app is None and hi_app is None:
        return
    if lo_db is not None and hi_db is not None:
        if (lo_app, hi_app) != (lo_db, hi_db):
            _catat(kep, f"JULAT BERBEZA: app MIN {lo_app}/MAX {hi_app} "
                        f"lawan DB MIN {lo_db}/MAX {hi_db}")
            return
    # Nilai yang dipapar mesti berada dalam julat, atau 0 (belum diisi).
    try:
        nilai = float(str(kep.denda).replace("RM", "").replace(",", ""))
    except (TypeError, ValueError):
        return
    if nilai and not (lo_app <= nilai <= hi_app):
        _catat(kep, f"denda {nilai} DI LUAR julat app "
                    f"{lo_app}..{hi_app}")


def _ringkas(e, had=180):
    t = " ".join(str(e).split())
    return t[:had] + ("…" if len(t) > had else "")


def _dropdown_kosong(page, tingkat, label, nama):
    """(kosong, bukti) untuk set negatif.

    pilih_spinner_kod() sudah membezakan "dialog terbuka tetapi 0 pilihan"
    daripada kegagalan lain, dan ia melempar dengan diagnosis itu. Kami
    memintanya memilih nilai yang MUSTAHIL supaya ia sampai ke titik itu
    dan memberitahu kami apa yang sebenarnya ada dalam senarai — itu
    bukti yang set negatif perlukan, bukan sekadar "gagal".

    >>> "MODAL TIDAK TERBUKA" ADALAH BENTUK KOSONG. Sweep 2026-08-12. <<<
    Semakan asal hanya menerima "0 pilihan"/"kosong" dalam teks ralat.
    Itu betul untuk Spinner Android, tetapi dropdown ini ialah
    PRESSABLE RN: apabila senarai tiada baris, tiada modal dirender
    langsung, dan enjin melapor

        modal dropdown tidak terbuka selepas 3 ketukan pada pressable

    Kesannya, kelima-lima set JANGKA_MATI_T3 dalam sweep 284 dilabel
    `ADA-ISI` dengan mesej "app memaparkan kesalahan" — sedangkan DB
    mengesahkan akta 82/91/92/93 membawa TEPAT 0 kesalahan dan app
    berkelakuan betul. Lima dapatan hantu daripada satu ayat yang
    salah.

    Modal-tidak-terbuka kekal KEGAGALAN pada laluan positif (di mana
    baris memang dijangka wujud); ia hanya bermakna 'kosong' di sini,
    di mana ketiadaan itulah yang diuji.
    """
    penanda = "__MBPG_SET_NEGATIF_TIADA_NILAI_INI__"
    try:
        page.pilih_spinner_kod(tingkat, label, nama, penanda, penanda)
    except AssertionError as e:
        teks = str(e)
        rendah = teks.lower()
        if ("0 pilihan" in rendah or "kosong" in rendah
                or "modal dropdown tidak terbuka" in rendah):
            return True, ""
        return False, _ringkas(e)
    # Tidak sepatutnya berlaku: kami memilih nilai yang tidak wujud.
    return False, "pemilihan penanda mustahil BERJAYA — locator mencurigakan"


def _baca_denda(page):
    """(teks_denda, nota). Kadar denda yang app papar, mentah.

    Pulangkan nota yang MEMBEZAKAN dua keadaan yang sangat berlainan:
      - borang ini memang tiada medan kadar denda (borang Notis Amaran
        tidak mempunyai FIELD_KADAR_DENDA langsung) — itu fakta struktur,
        bukan kegagalan;
      - borang ada medannya tetapi kami tidak dapat membacanya — itu
        kegagalan yang patut kelihatan dalam MATRIX.
    Menggabungkan kedua-duanya sebagai "" akan menjadikan 26 baris N
    kelihatan seperti 26 bacaan gagal.

    TIADA nilai direka: mapping tidak membawa kadar denda, jadi tiada
    apa untuk dibandingkan — kami merekod sahaja.

    >>> DIBACA DARI page_source, BUKAN find_element. 2026-08-11. <<<
    Pathfinder melaporkan `kadar denda tidak dapat dibaca:
    TimeoutException` walaupun ketiga-tiga dropdown lulus. Medan itu
    TIDAK hilang — dump menunjukkannya hadir sepenuhnya:

        <EditText text="0" hint="ENTER AMAUN"
                  bounds="[107,2166][467,2316]" />

    Puncanya sama seperti setiap kegagalan lain pada borang ini:
    find_element() MENATAL bila sasaran di luar viewport, dan borang
    ini menolak swipe. Alat ukur gagal, bukan medan.

    Pokok skrin membawa nilai itu tanpa mengira kedudukan tatal, jadi
    membacanya dari `page_source` menjawab soalan secara langsung —
    sifar gerak isyarat, dan find_with_scroll tidak disentuh (arahan
    pemilik 2026-08-11).

    Kalau MATRIX sweep bergantung pada laluan lama, kolum denda untuk
    284 baris akan kosong semuanya.
    """
    if not hasattr(page, "FIELD_KADAR_DENDA"):
        return "", "borang ini tiada medan kadar denda (bukan kegagalan)"

    teks = _denda_dari_pokok(page)
    if teks is not None:
        return teks, ("" if teks else
                      "medan kadar denda dijumpai tetapi kosong")

    # Pokok TIDAK membawa medan itu.
    #
    # >>> KENAPA, DAN APA YANG BERKESAN — bukti 2026-08-11. <<<
    # Diagnosis pada peranti merakam pokok pada saat kegagalan:
    #
    #   label   : [... 'KOD AKTA', 'KESALAHAN KOMPAUN',
    #              '[SEK 70 (A)] - MELETAKKAN ATAU MEN...']
    #   EditText: ['AUTOTEST BUTIRAN', '21']       <- hanya DUA
    #   'PILIH KADAR DENDA' : TIADA langsung
    #
    # Jadi ketiga-tiga dropdown betul-betul terpilih, tetapi medan
    # denda berada DI BAWAH tetingkap render dan RN telah
    # menyahlekapnya. Ia bukan di luar viewport — ia bukan dalam pokok
    # langsung, jadi tiada pembacaan XML boleh menjumpainya.
    #
    # Borang ini kelas TRAVERSAL-FOKUS: swipe tidak menggerakkannya
    # (0px, berulang kali), tetapi traversal TAB/DPAD DOES —
    # itulah mekanisme yang enjin dropdown sendiri gunakan untuk
    # mendedahkan label tingkat 2 dan 3 pada borang yang sama.
    # Jadi kami gunakan mekanisme yang SAMA di sini, bukan mereka
    # yang baharu, dan bukan menyentuh laluan skrol read-back.
    teks = _dedah_lalu_baca(page)
    if teks is not None:
        return teks, ("" if teks else
                      "medan kadar denda dijumpai tetapi kosong")

    # Rakam APA yang ada sebelum menyerah — "tidak dapat dibaca" tanpa
    # bukti ialah kebuntuan yang tiada siapa boleh nyahsulit kemudian.
    _diagnosis_denda(page)

    # Sandaran: laluan elemen lama. Dikekalkan supaya borang yang
    # strukturnya berbeza (Sitaan) tidak kehilangan liputan.
    try:
        el = page._find_kadar_denda_el()
        teks = (el.text or "").strip()
    except Exception as e:                                    # noqa: BLE001
        return "", f"kadar denda tidak dapat dibaca: {type(e).__name__}"
    return teks, ("" if teks else "medan kadar denda dijumpai tetapi kosong")


def _dedah_lalu_baca(page):
    """Dedahkan medan denda melalui traversal fokus, kemudian baca
    semula dari pokok. Pulangkan teks, atau None kalau masih tiada.

    Traversal TAB/DPAD ialah satu-satunya mekanisme yang terbukti
    menggerakkan borang ini (pelajaran N-001, dikodkan dalam
    `_dedah_sebelum_cari`). Ia tidak menyentuh `find_with_scroll` atau
    `cari_dua_arah`.
    """
    import time as _t
    dedah = getattr(page, "_dedah_sebelum_cari", None)
    ci = getattr(page, "_ci_label_locator", None)
    if not dedah or not ci:
        return None
    # >>> BACA SEMULA WALAU TRAVERSAL MELEMPAR. Bukti 2026-08-11. <<<
    # _dedah_sebelum_cari() membangkitkan AssertionError apabila ia
    # tidak dapat MENGESAHKAN label muncul — tetapi ketukan TAB/DPAD
    # yang ia hantar SEBELUM menyerah sudah menggerakkan borang, dan
    # medan denda muncul dalam pokok. Diperhati langsung: traversal
    # melapor gagal, kemudian diagnosis mencetak
    #     EditText: ["'1000'/hint='ENTER AMAUN'"]
    # pada pokok yang sama.
    #
    # Jadi keputusan traversal bukan jawapannya; POKOK yang jawab.
    # Kami membaca semula tanpa mengira, dan hanya menyerah kalau
    # pokok masih tidak membawanya.
    try:
        dedah(ci("PILIH KADAR DENDA"), "PILIH KADAR DENDA", max_tabs=12)
    except Exception as e:                                    # noqa: BLE001
        print(f"  [DENDA] traversal melapor {type(e).__name__} — "
              f"membaca semula pokok tetap")
    _t.sleep(0.5)
    teks = _denda_dari_pokok(page)
    if teks is not None:
        print(f"  [DENDA] didedahkan melalui traversal -> {teks!r}")
    return teks


def julat_dipapar(page):
    """(min, max) yang APP papar, atau (None, None).

    Selepas kesalahan dipilih, borang memaparkan 'MIN: 250' dan
    'MAX: 1000' bersebelahan medan denda. Nilai itu datang dari app,
    jadi ia boleh disemak silang terhadap DB (amounmin/amounmax) —
    pengesahan bebas bahawa app dan DB sependapat, tanpa menaip
    apa-apa.
    """
    import re
    import xml.etree.ElementTree as ET
    try:
        akar = ET.fromstring(page.driver.page_source)
    except Exception:                                         # noqa: BLE001
        return None, None
    lo = hi = None
    for n in akar.iter():
        t = (n.get("text") or "").strip()
        m = re.match(r"(?i)^MIN:\s*([\d.]+)$", t)
        if m:
            lo = float(m.group(1))
        m = re.match(r"(?i)^MAX:\s*([\d.]+)$", t)
        if m:
            hi = float(m.group(1))
    return lo, hi


def _diagnosis_denda(page):
    """Rakam keadaan skrin bila medan denda tiada dalam pokok."""
    import os
    import xml.etree.ElementTree as ET
    try:
        sumber = page.driver.page_source
    except Exception:                                         # noqa: BLE001
        print("  [DENDA] page_source tidak boleh dibaca langsung")
        return
    try:
        os.makedirs("ui_dumps", exist_ok=True)
        with open(os.path.join("ui_dumps", "denda_tiada_dalam_pokok.xml"),
                  "w", encoding="utf-8") as fh:
            fh.write(sumber)
    except OSError:
        pass
    try:
        akar = ET.fromstring(sumber)
    except Exception:                                         # noqa: BLE001
        print("  [DENDA] page_source tidak boleh dihurai")
        return
    edit, tajuk, modal = [], [], 0
    for n in akar.iter():
        kelas = (n.get("class") or "")
        t = (n.get("text") or "").strip()
        if "modal" in (n.get("resource-id") or ""):
            modal += 1
        if kelas.endswith("EditText"):
            edit.append(f"{t[:22]!r}/hint={(n.get('hint') or '')[:16]!r}")
        elif t and len(t) > 3 and kelas.endswith("TextView"):
            tajuk.append(t[:34])
    print(f"  [DENDA] medan TIADA dalam pokok. nod modal={modal} "
          f"EditText={len(edit)}")
    print(f"  [DENDA] EditText: {edit[:8]}")
    print(f"  [DENDA] label   : {tajuk[:10]}")
    print("  [DENDA] dump: ui_dumps/denda_tiada_dalam_pokok.xml")


def _denda_dari_pokok(page):
    """Teks medan kadar denda dari page_source, atau None kalau medan
    itu memang tiada dalam pokok.

    Dikenal pasti melalui hint `ENTER AMAUN` — atribut itu kekal walau
    apa pun nilai semasa medan, jadi ia berfungsi sebelum dan selepas
    apa-apa ditaip. Sandaran kedua: EditText pertama SELEPAS label
    'PILIH KADAR DENDA' mengikut susunan dokumen.
    """
    import re
    import xml.etree.ElementTree as ET
    try:
        akar = ET.fromstring(page.driver.page_source)
    except Exception:                                         # noqa: BLE001
        return None

    nod = list(akar.iter())
    for n in nod:
        if (n.get("hint") or "").strip().upper() == "ENTER AMAUN":
            return (n.get("text") or "").strip()

    idx_label = None
    for i, n in enumerate(nod):
        if re.match(r"(?i)\s*PILIH\s+KADAR\s+DENDA",
                    (n.get("text") or "")):
            idx_label = i
            break
    if idx_label is None:
        return None
    for n in nod[idx_label + 1:]:
        if (n.get("class") or "").endswith("EditText"):
            return (n.get("text") or "").strip()
    return None

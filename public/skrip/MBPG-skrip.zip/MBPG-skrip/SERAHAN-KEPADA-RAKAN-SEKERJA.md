# SERAHAN — Automasi Ujian MBPG (KOMPAUN e-PBT)

**Untuk rakan sekerja yang mengambil alih.** Ditulis 2026-08-19.
Baca muka ini SEPENUHNYA sebelum menyentuh peranti.

---

## 0. Bacaan lima minit

Kalau kau hanya ada lima minit, baca tiga perkara ini dan berhenti:

1. **Ini production. Tiada staging.** Setiap rekod yang automasi cipta
   ialah kompaun sebenar pada pangkalan data Majlis Bandaraya. 14 rekod
   sedang hidup sekarang dan menunggu pembatalan PM.
2. **`LULUS` daripada skrip TIDAK bermakna TC lulus.** Ia bermakna
   "tiada ralat teknikal". Skrip tidak membaca kertas, tidak memeriksa
   portal ePBT, dan tidak menilai ketepatan penguatkuasaan. K-001 dan
   K-002 pernah dilaporkan LULUS dan gagal pemeriksaan manusia.
3. **T-008 Selaras Pelesen — JANGAN SENTUH.** Larangan mutlak daripada
   pemilik. Sync 3–4 jam. Tiga lapisan penguatkuasaan wujud khusus
   untuk menghalangnya; jangan lemahkan mana-mana satu.

---

## 1. Apa projek ini

Suite regresi Appium + pytest untuk aplikasi Android **KOMPAUN e-PBT**
(`com.anonymous.react_ies_v1`), digunakan oleh penguatkuasa MBPG untuk
mengeluarkan notis amaran dan kompaun.

| | |
|---|---|
| Peranti | Ulefone Armor 27, serial `5008TF2010009401` |
| Server | `113.211.155.174` — **production, satu-satunya** |
| Build peranti | **2.1.23** (hotfix) |
| Oracle | Excel `V2.1.20_PRODUCTION.xlsx`, 49 sheet TC |
| Pemilik | Shu (perunding). Berkomunikasi Melayu/English campur. |

**Perbezaan versi itu penting.** Oracle mentakrifkan hasil dijangka
untuk 2.1.20. Peranti menjalankan 2.1.23. Setiap perbezaan yang kau
rekod adalah **taksa** — pepijat, atau perubahan build? Itu keputusan
pemilik. Gerbang versi mencetak `[GAGAL]` tetapi **tidak menghalang**
larian; itu memang disengajakan.

---

## 2. Keadaan semasa (2026-08-19)

### Skor TC terkini — larian 2026-08-18 petang

| Status | Bilangan |
|---|---|
| Lulus | 10 |
| Gagal | 13 |
| Tiada bukti | 2 |
| Tidak diuji | 24 |
| **Jumlah** | **49** |

Laporan penuh berformat: **`reports/LAPORAN-LARIAN-2026-08-18.html`**
(buka dalam Chrome — status setiap TC, jadual masa, diagnosis, audit).

### Apa yang berfungsi

- Sesi + login (T-012)
- Selaras T-003, T-004, T-006, T-007, T-009
- Daftar Notis Amaran (N-001) — rekod dicipta berulang kali
- Daftar Kompaun Pelbagai (P-001) dan Kemaskini (P-004)
- Corong keselamatan — 189 tap dinilai, 0 pelanggaran

### Apa yang rosak

- **Borang K** — ketiga-tiga plat gagal pada dropdown yang sama
- **Kemaskini N** — `SETERUSNYA MAHUPUN MENYERAHKAN tidak dijumpai`
- **Ketiga-tiga menu** — senarai, hantar, tarik: `TimeoutException`
- **T-005 Selaras Kompaun** — app tercampak keluar (D-08)

---

## 3. Cara menjalankan

```powershell
cd C:\Users\mrsai\Documents\antigravity\keen-lovelace\MBPG-testing
$env:MBPG_IZIN_PRODUCTION = "1"
python tools/run_penuh.py --borang NPK
```

Tiga input: IP (Enter untuk lalai), lesen (Enter), lalu `YA`.

**Prasyarat:** Appium hidup dalam terminal lain (`appium`), peranti
tersambung (`adb devices`). Kalau kosong atau `offline`, jalankan
`adb reconnect offline`.

### Pilihan

```
--borang N | P | K | NPK | x     borang untuk dicipta
--plat A B C                     plat mySIKAP untuk K
--tanpa-printer                  langkau peringkat cetak
--langkau-selaras                jimat ~5 minit
--langkau-menu                   borang sahaja
--ip / --lesen                   untuk larian tanpa terminal
--terus                          langkau pengesahan YA
```

### Sebelum sebarang commit

```powershell
python -m pytest tests_offline -q       # 938 lulus, 1 langkau
python devtools/imbas_pii.py            # WAJIB — lihat §7
```

---

## 4. Defek app yang diketahui

Semua terperinci dalam `docs/DEFEK-MBPG-2.1.21.md`.

| Kod | Ringkasan | Status |
|---|---|---|
| **D-01** | Selaras Alamat bukan idempotent; app meranap pada sync kedua | Tidak berulang selepas DB dikosongkan — menyokong hipotesis idempotency |
| **D-02** | Medan Internal IP tidak dipersist | Terbuka |
| **D-03** | Poskod kosong | Terbuka |
| **D-04** | Bookmark tiada UI cipta | Terbuka |
| **D-05** | Menaip plat mencerminkan nilai ke medan identiti | Diatasi — plat ditaip DAHULU |
| **D-06** | Read-back kesalahan 148 | Terbuka |
| **D-07** | **Nombor siri dibakar bila borang dibuka, walaupun tiada serahan** | Terbuka — kaunter notis melompat 2→7 dalam satu sesi |
| **D-08** | Selaras Maklumat Kompaun (T-005) meranapkan app | Berselang-seli, 6 daripada 7 larian |
| **D-09** | **mySIKAP: carian gagal senyap, identiti pemilik LAMA melekat** | **BELUM DIUJI pada 2.1.23** |
| **D-10** | Tandatangan pada cetakan letak kereta | Butiran tidak jelas — perlu pengesahan intern |
| **D-11** | Kemaskini K: "Jenis Kereta" tidak dimuatkan ke borang | Paparan sahaja; data selamat |

### D-09 memerlukan penerangan lanjut

Dua kelakuan, dan yang kedua jauh lebih serius:

**(a) Carian gagal senyap.** mySIKAP tidak pulangkan apa-apa, dan app
menulis **nombor plat ke dalam medan nama pesalah**. Bukti dalam data
kita sendiri:

```
PGP02K260813002   nokereta=JYX6605   namapesalah=JYX6605
                  jeniskereta=''     warnakereta=''
```

Tanda ini duduk dalam DB selama lima hari tanpa disedari kerana tiada
apa yang membandingkan `namapesalah` dengan `nokereta`.

**(b) Identiti pemilik terdahulu melekat.** Selepas 3–4 kompaun, borang
memaparkan pemilik kompaun sebelumnya untuk plat yang BERBEZA. Tiada
mesej ralat. Kompaun kelihatan sah sepenuhnya dan menamakan orang yang
salah. **Itu bukan pepijat UI — itu kompaun penguatkuasaan terhadap
warga yang tidak berkaitan.**

Pengesan automatik: `tools/semak_mysikap.py`. Ia memerlukan
**sekurang-kurangnya 2 plat BERBEZA** untuk menguji (b); dengan plat
sama, identiti berulang adalah BETUL. Pemilik membekalkan tiga plat sah:
`JYX6605`, `JUA3276`, `JRT2649`.

---

## 5. Rekod production hidup

14 rekod, menunggu pembatalan PM. Senarai penuh dengan status dan nota:
**`reports/REKOD-PRODUCTION-SEMUA.md`**

```
PGP02P260813001   Kompaun Pelbagai
PGP02K260813002   Kompaun Letak Kereta     <- bukti D-09(a)
PGP02N260813006   Notis Amaran
PGP02N260813007   Notis Amaran
PGP02N260817008   Notis Amaran
PGP02P260818003   Kompaun Pelbagai
PGP02P260818004   Kompaun Pelbagai
PGP02P260818005   Kompaun Pelbagai
PGP02P260818006   Kompaun Pelbagai         <- sudah dibatalkan (status B)
PGP02P260818007   Kompaun Pelbagai
PGP02K260818008   Kompaun Letak Kereta     <- PII warga SEBENAR
PGP02N260818001   Notis Amaran
PGP02P260818001   Kompaun Pelbagai
PGP02P260818002   Kompaun Pelbagai
```

**`PGP02K260818008` perlu perhatian segera.** Identitinya datang dari
carian mySIKAP, jadi ia membawa nama dan no. KP warga sebenar — bukan
penanda ujian. Ia juga dicipta selepas beberapa kompaun K lain dalam
sesi yang sama, iaitu keadaan D-09(b). Identitinya **tidak boleh
diandaikan betul**.

### Format nombor rekod

```
PGP02 + <jenis N|P|K> + <YYMMDD tarikh cipta> + <NNN kaunter>
```

**Dua kaunter berasingan** dalam `local_system_control`: `nonotis`
untuk N, dan `nokompaun` yang **dikongsi** oleh P dan K. Rekod K
menaikkan kaunter yang rekod P gunakan.

---

## 6. Nasihat kepada kau — baca bahagian ini dua kali

Bahagian lain memberitahu apa yang wujud. Bahagian ini memberitahu apa
yang akan menyesatkan kau.

### 6.1 Pengesahan yang tidak boleh gagal — kesilapan nombor satu

Ini berlaku **sekurang-kurangnya lima kali** dalam projek ini, oleh
orang yang tahu ia berlaku, dan tetap berulang. Ia akan berlaku kepada
kau juga melainkan kau menyemaknya secara sedar.

Bentuknya sentiasa sama: satu semakan ditulis, ia mencetak hijau, dan
ia **tidak pernah mampu mencetak merah**.

| Kejadian | Kenapa ia tidak boleh gagal |
|---|---|
| Read-back memulangkan `None` dianggap lulus | `None` bukan padanan; ia ketiadaan data |
| Ujian skrol pada borang KOSONG | Borang kosong tidak menatal; ujian mengukur ketiadaan |
| `_medan_memegang('1')` memadan `'81700'` | Padanan substring pada nilai satu aksara |
| Peringkat hantar: `if v == "M"` pada integer | Kiraan baris tidak pernah sama dengan huruf; H-001/002/003 "lulus" berbulan tanpa menekan butang |
| `semak D-09` menapis "rekod K **hari ini**" | Menemui rekod dari sesi PAGI; mengisytiharkan hotfix bersih sedangkan sifar rekod dicipta |

**Ujian kendiri sebelum kau percaya mana-mana semakan yang kau tulis:**

> Apakah keadaan yang akan menyebabkan semakan ini **GAGAL**? Kalau kau
> tidak dapat namakan satu dengan segera, dan tunjukkan ia gagal,
> semakan itu tidak wujud.

Tulis ujian bagi kes gagal DAHULU. Kalau ia lulus tanpa perubahan kod,
kau baru sahaja menemui satu lagi.

### 6.2 Tiga keadaan, bukan dua

Berkait rapat dengan di atas, dan lebih halus. Setiap semakan mempunyai
**tiga** hasil yang mungkin, bukan dua:

```
BERSIH        semakan berjalan dan tiada masalah
ROSAK         semakan berjalan dan menemui masalah
TIDAK DIUJI   semakan TIDAK DAPAT berjalan
```

Melipat keadaan ketiga ke dalam BERSIH menghasilkan **keyakinan palsu**
— itu yang berlaku pada 2026-08-18. Melipatnya ke dalam ROSAK
menghasilkan **penggera palsu**, yang sama buruknya kerana orang akan
belajar mengabaikan pengesan itu.

Lihat `D09TidakDiuji` dalam `tools/run_penuh.py` sebagai contoh bentuk
yang betul: kelas pengecualian tersendiri supaya ia tidak boleh runtuh
ke mana-mana dua yang lain secara tidak sengaja.

### 6.3 Kuirk React Native yang akan membuang masa kau

Aplikasi ini React Native. Tiga perkara berkelakuan bertentangan dengan
jangkaan Android biasa:

**`page_source` MEMBUANG nod yang tidak kelihatan.** Medan yang sudah
diisi tetapi berada di luar skrin akan dilaporkan sebagai *tidak wujud*.
Ini menyebabkan empat diagnosis salah berturut-turut sebelum
disedari. **Tatal ke atas dahulu sebelum mengesahkan medan.**

**`driver.hide_keyboard()` bertindak seperti butang BACK.** Ia
memusnahkan modal dan membuang nilai yang belum disimpan. Jangan guna.
Ada pembantu `tutup_ime_tanpa_back` untuk ini.

**Handle elemen menjadi basi selepas render semula.** `el.text`
memulangkan `None` pada elemen yang masih kelihatan pada skrin. Baca
`page_source` yang SEGAR, jangan simpan handle.

### 6.4 Jangan percaya screenshot tanpa memeriksanya

Tujuh screenshot bernama `selepas-cetak` adalah **bait-untuk-bait
identik** merentas N, P dan K, dari 09:44 hingga 17:08. Semuanya
menangkap skrin menu utama. Ia tidak boleh membezakan cetakan berjaya
daripada cetakan gagal — namun ia dinamakan seolah-olah ia bukti.

Kalau kau menambah artifak bukti, sahkan ia benar-benar berubah antara
kes lulus dan gagal. Hash fail adalah cara termurah:

```powershell
python -c "import hashlib,glob; [print(hashlib.sha256(open(f,'rb').read()).hexdigest()[:12], f) for f in glob.glob('reports/e2e-screenshots/*.png')]"
```

### 6.5 Menulis kod melalui heredoc shell

Kalau kau menggunakan sesi terminal AI, ini akan menggigit kau. Jujukan
escape `\n` dalam heredoc **runtuh menjadi baris baharu sebenar**,
memecahkan literal rentetan Python. Ia berlaku lima kali dalam sesi ini.

Guna `chr(10)`, atau tulis fail melalui alat fail yang sebenar. Jangan
letak escape backslash dalam kod yang melalui shell.

### 6.6 Rekod itu kekal walaupun larian mati

`tools/rekod_log.py` menulis setiap nombor dengan `flush()` + `fsync()`
sebaik ia wujud, bukan pada akhir larian. Sebabnya sudah berlaku sekali:
pada 2026-08-13 satu proses dibunuh had-masa alat selepas nombor siri
005 diperuntukkan. Nombor itu hilang daripada setiap log dan hanya
ditemui kemudian dengan membaca DB peranti.

**Kalau larian berhenti di tengah, rekod yang sudah dicipta TETAP
HIDUP.** Rujuk `reports/REKOD-SEBENAR-DICIPTA-<tarikh>.md`.

### 6.7 Satu kitaran boleh menjana LEBIH daripada satu nombor

Cipta → SERAH = rekod 1. Kemaskini = **membatalkan** rekod lama
(status `B`) dan **menjana rekod gantian baharu** (status `A`). NK
convert menjana satu lagi.

`PGP02P260818006` → dibatalkan; `PGP02P260818007` → gantian. Kedua-dua
nombor wujud pada production. Log setiap satu berasingan; jangan
"kemas kini baris sebelumnya".

### 6.8 Bila berhenti, bila teruskan

Kebanyakan kegagalan peringkat **tidak** sepatutnya menamatkan larian —
satu kegagalan lewat tidak sepatutnya membuang sejam kerja yang
berjaya. Tetapi tiga keadaan **mesti** berhenti serta-merta:

| Keadaan | Kenapa |
|---|---|
| `DryRunViolation` | Corong menyekat sesuatu. Baca `reports/forensik/` sebelum menjalankan semula. |
| Gerbang kaunter siri | Kerosakan berlaku pada SAAT rekod dicipta; tiada pemulihan. |
| Peringkat `sesi` gagal | Semua peringkat berikutnya tidak bermakna. |

### 6.9 Pemilik menghargai keterusterangan

Pemilik lebih rela mendengar "ini belum terbukti" daripada laporan
lulus yang cair kemudian. Beberapa pembetulan paling berguna dalam
projek ini datang daripada pemilik memerhati peranti dan berkata sesuatu
yang bercanggah dengan laporan automasi.

Bila kau tidak pasti, katakan tidak pasti dan namakan apa yang akan
menyelesaikannya.

---

## 7. PII — ini serius

Rekod K yang menggunakan carian mySIKAP membawa **nama dan nombor KP
warga sebenar**. Beberapa medan menyimpannya di tempat yang tidak
dijangka:

| Lajur | Sebenarnya mengandungi |
|---|---|
| `namapesalah` | nama penuh |
| `idpesalah` | no. KP |
| **`noakaun`** | **no. KP** — nama lajur menipu |
| `offenderjalan/taman/bandar/poskod` | alamat RUMAH |

`noakaun` menyebabkan satu no. KP sebenar dicetak ke terminal pada
2026-08-18 sebelum disedari.

**`python devtools/imbas_pii.py` WAJIB sebelum setiap commit.** Ia
mengimbas baris yang ditambah dan memblok corak PII. Ia sudah pernah
memblok commit yang sah — dan ia betul setiap kali. **Jangan luaskan
senarai kebenarannya untuk melepasi imbasan; tapis data itu sebaliknya.**

Alat `tools/semak_kertas.py` menapis kesemua medan di atas secara lalai.

---

## 8. Peta fail

### Alat yang kau akan guna

| Fail | Guna |
|---|---|
| `tools/run_penuh.py` | Orkestrator satu-sesi. Titik masuk utama. |
| `tools/run_e2e.py` | Satu borang hujung-ke-hujung |
| `tools/run_e2e_menu.py` | Peringkat menu (senarai/hantar/tarik/nk) |
| `tools/semak_kertas.py` | Senarai semak medan untuk pemeriksa kertas |
| `tools/semak_mysikap.py` | Pengesan D-09 |
| `tools/semak_siri.py` | Gerbang kaunter siri |
| `tools/forensik.py` | Tangkapan bukti pada kegagalan |
| `tools/rekod_log.py` | Log rekod production (fsync) |

### Keselamatan

| Fail | Guna |
|---|---|
| `guard/corong.py` | Membalut driver; setiap tap dinilai |
| `guard/dasar.py` | Dasar — apa dibenarkan, dalam konteks apa |
| `tools/izin_e2e.py` | Kuota dan kebenaran serah |

Corong ialah **gagal-tertutup**: apa-apa yang tidak boleh dibaca
disekat. `DryRunViolation` mewarisi `BaseException` **dengan sengaja** —
terdapat 66 blok `except Exception` dalam `pages/base_page.py` yang
akan menelannya.

Konteks disahkan **secara struktur** daripada pokok paparan (tajuk
app-bar, permukaan modal), tidak pernah dengan padanan substring.

### Dokumen

| Fail | Kandungan |
|---|---|
| `MULA-DI-SINI-PAGI.md` | Panduan larian + senarai TC muktamad |
| `reports/LAPORAN-LARIAN-2026-08-18.html` | Laporan berformat larian terakhir |
| `reports/REKOD-PRODUCTION-SEMUA.md` | 14 rekod untuk pembatalan PM |
| `docs/DEFEK-MBPG-2.1.21.md` | D-01 hingga D-11 dengan bukti |
| `reports/LAPORAN-49-TC.md` | Klasifikasi TC |

---

## 9. Apa yang perlu dibuat seterusnya

Mengikut susunan yang aku cadangkan:

**1. Siasat kegagalan dropdown K** (paling banyak nilai)

```powershell
python tools/run_penuh.py --borang K --langkau-selaras --langkau-menu
```

Tangkapan forensik kini akan menulis mesej penuh, screenshot dan XML ke
`reports/forensik/`. XML itu terus menjawab soalan yang menyekat kita:
adakah modal dropdown **terbuka**? Kalau ya, puncanya ialah padanan
nilai. Kalau tidak, puncanya ialah locator. Dua pembaikan berbeza
sepenuhnya.

**2. Uji menu secara berasingan**

```powershell
python tools/run_penuh.py --borang x --langkau-selaras
```

Ketiga-tiga menu gagal dengan `TimeoutException` selepas lima kegagalan
borang, jadi keadaan skrin permulaan tidak diketahui. Jalankan bersih.

**3. Analisis `ui_dumps/kemaskini_no_seterusnya.xml`**

Dump sudah wujud dari 17:01:39. Kemaskini N gagal mencari SETERUSNYA
mahupun MENYERAHKAN. Ralat yang sama pernah dilihat pada borang K.
Hipotesis untuk diuji: 2.1.23 menukar label butang, atau butang di luar
viewport dan `scrollIntoView` menyasarkan teks yang salah.

**4. Sahkan D-10 dengan intern**

Laporan berbunyi *"The printed kompaun letak kereta does show the
signature"* sedangkan K-002 ditanda GAGAL. Kedua-duanya tidak boleh
benar serentak. **Jangan andaikan mana-mana** — ia kekal sebagai
"butiran tidak jelas" dalam dokumen defek sehingga disahkan.

**5. Setelah K berfungsi — jalankan regresi D-09**

Tiga plat, satu sesi. Peringkat `semak D-09` akan menjawab sama ada
hotfix 2.1.23 membaiki defek yang paling serius dalam senarai.

### Keputusan yang menunggu pemilik

- **Bukti cetakan.** Screenshot skrin utama tidak membuktikan apa-apa.
  Tangkap dialog cetak sebelum ia ditutup, atau terima bahawa
  N/P/K-002 memerlukan mata manusia selama-lamanya.
- **H-001/002/003** hanya boleh diuji dengan rekod yang GAGAL naik.
  Itu memerlukan mematikan data/WiFi semasa mencipta rekod — gangguan
  yang disengajakan pada peranti production.
- **NK-001/002** boleh diuji selepas **2026-08-27** (`PGP02N260813006`
  menjadi layak). Tetapi borang di sebalik butang `[KOMPAUN]` belum
  pernah dilihat, dan membuka borang membakar nombor siri (D-07). Buat
  recon dahulu dengan kelulusan.

---

## 10. Perkara yang JANGAN kau buat

| Jangan | Sebab |
|---|---|
| Jalankan T-008 Selaras Pelesen | Larangan mutlak pemilik. 3–4 jam sync. |
| Tekan PADAM atau HAPUS | Dilarang dalam semua mod, tanpa pengecualian. |
| Longgarkan corong untuk "melepasi" sekatan | Sekatan itu betul sehingga terbukti sebaliknya. Baca `reports/forensik/` dahulu. |
| Luaskan senarai kebenaran pengimbas PII | Tapis data itu sebaliknya. |
| Ubah apa-apa dalam `mbip-testing/current/` | Skrip asal projek lain, ~85% berfungsi, tidak boleh disentuh. |
| Percaya `LULUS` tanpa pengesahan mata | Lihat §0.2. |
| Sentuh sweep 330/284-set kombo | KIV atas arahan pemilik. Jangan sentuh, jangan laporkan. |

---

## 11. Kalau sesuatu rosak

**`socket hang up` / `POST /element` / `adb devices` kosong**
USB tercabut. Berlaku beberapa kali sehari.
```powershell
adb reconnect offline
adb devices
```

**`DryRunViolation`**
Corong menyekat sesuatu dan larian BERHENTI. PNG + XML ditulis pada
saat sekatan ke `reports/forensik/`. Baca dahulu; jangan jalankan semula
secara membuta.

**`UnicodeEncodeError`**
Konsol Windows ialah cp1252 dan mesej membawa aksara kotak. Ia pernah
**menutupi** `DryRunViolation` sebenar dan menukar kod keluar. Sudah
dibalut, tetapi kalau kau menambah cetakan, guna ASCII.

**Larian tamat "normal" tetapi sesuatu terasa salah**
Baca blok **VERDIK** di hujung output. Ia menamakan keputusan D-09 dan
menyenaraikan setiap peringkat yang gagal. Kod keluar `1` bermakna
sekurang-kurangnya satu peringkat gagal; `2` bermakna gerbang
pra-terbang menghentikannya sebelum apa-apa dicipta.

---

## 12. Nota terakhir

Nilai sebenar suite ini bukan bilangan TC yang ia lulus. Ia ialah
bahawa apabila ia mendakwa sesuatu, dakwaan itu boleh dipercayai.

Sesi ini menghabiskan lebih banyak masa membaiki **automasi yang
berbohong** berbanding membaiki app. Verdik D-09 yang palsu, peringkat
hantar yang membandingkan integer dengan huruf, screenshot cetakan yang
sebenarnya skrin menu — ketiga-tiganya melaporkan kejayaan dan tidak
satu pun mampu melaporkan kegagalan.

Kalau kau menambah satu perkara sahaja kepada projek ini, jadikan ia
ini: **untuk setiap semakan yang kau tulis, tunjukkan ia boleh gagal.**

Semoga berjaya. Peranti berada di meja pemilik.

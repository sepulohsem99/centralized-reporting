# SKRIP E2E — untuk dijalankan sendiri

Dikemas kini 2026-08-18 selepas ujian manusia. Baca muka ini dahulu.

---

## Command

```powershell
cd C:\Users\mrsai\Documents\antigravity\keen-lovelace\MBPG-testing
$env:MBPG_IZIN_PRODUCTION = "1"
python tools/run_penuh.py --borang NPK
```

Skrip akan tanya dua soalan dahulu — tekan Enter untuk terima nilai
profil:

```
Alamat IP server [113.211.155.174]:      <- Enter
Nombor lesen aplikasi [8677...172]:      <- Enter
```

Nilai itu digunakan untuk menulis semula Tetapan Alamat IP dan Tetapan
Pelbagai kalau peranti kehilangannya (contoh: selepas pasang APK baharu).
Untuk larian tanpa terminal: `--ip <ip> --lesen <no>`.

Kemudian satu `YA`, dan jalan terus:

```
selaras (T-003,004,005,006,007,009)
  ->  N
  ->  P
  ->  K x3   JYX6605 · JUA3276 · JRT2649
  ->  semak D-09
  ->  senarai · hantar · tarik
```

Menu **Notis Kompaun** DICOVER — peringkat `tarik` masuk
melaluinya (`open_notis_kompaun` -> TARIK NOTIS TAMAT TEMPOH).
Yang TIDAK dicover ialah penukaran notis->kompaun di sebalik
butang `[KOMPAUN]`: ia perlukan notis yang sudah luput tempoh.
Paling awal **2026-08-27** (`PGP02N260813006`). Larian mencetak
kelayakan NK supaya jurang itu kelihatan, bukan senyap.

**K dijalankan TIGA kali, satu plat setiap satu.** Itu ujian regresi
D-09: pemeriksa melaporkan butiran pemilik terdahulu melekat pada rekod
ke-3/ke-4. Satu plat tidak boleh menunjukkannya — dua kompaun untuk
kenderaan yang sama memang sepatutnya menamakan orang yang sama.

Peringkat `semak D-09` membandingkan identiti merentas ketiga-tiga rekod
dan **menghentikan larian** kalau defek masih ada pada 2.1.23.

Larian ini mencipta **5 rekod production**: 1 N, 1 P, 3 K.

**Hidupkan printer Bixolon sebelum tekan YA.** Tanpa printer, tambah
`--tanpa-printer` — peringkat CETAK akan ditanda `SKIP` dan N/P/K-002
kekal tidak terbukti.

### Pilihan berguna

```powershell
--borang N              # laluan paling stabil
--borang P              # juga stabil
--borang K              # GAGAL ujian manusia — lihat di bawah
--langkau-selaras       # jimat ~5 minit kalau selaras sudah dibuat
--langkau-menu          # borang sahaja
--borang x --langkau-selaras    # menu sahaja
```

---

## Senarai TC muktamad — 49 sheet

Perintah: `python tools/run_penuh.py --borang NPK`

### DIJALANKAN oleh skrip (24)

| TC | Peringkat | Nota |
|---|---|---|
| T-001 Tetapan Alamat IP | bootstrap | **bersyarat** — hanya kalau IP peranti KOSONG |
| T-002 Tetapan Pelbagai | bootstrap | bersyarat, sama seperti T-001 |
| T-012 Remember Me / login | sesi | setiap larian |
| T-003 Selaras Pengguna Apps | selaras | |
| T-004 Selaras Maklumat Alamat | selaras | D-01 mungkin meranapkan app |
| T-005 Selaras Maklumat Kompaun | selaras | D-08, berselang-seli |
| T-006 Selaras Jenis Kenderaan | selaras | |
| T-007 Selaras Warna | selaras | |
| T-009 Selaras Barang Sita | selaras | |
| N-001 Daftar Notis Amaran | borang N | cipta + SERAH sebenar |
| N-002 Cetak Notis | borang N | perlu printer |
| N-004 Kemaskini Notis | borang N | jana nombor baharu |
| P-001 Daftar Kompaun Pelbagai | borang P | |
| P-002 Cetak Kompaun Pelbagai | borang P | |
| P-004 Kemaskini Pelbagai | borang P | |
| K-001 Daftar Letak Kereta | borang K x3 | tiga plat mySIKAP |
| K-002 Cetak Letak Kereta | borang K x3 | |
| K-004 Kemaskini Letak Kereta | borang K x3 | D-11 dijangka |
| P-003 Serah Kompaun Pelbagai | borang P | SEBAHAGIAN — SERAH ditekan; HANTAR akhir ikut status |
| K-003 Serah Letak Kereta | borang K | sama seperti P-003 |
| SK-001 Senarai Kompaun | menu | |
| TN-001 Tarik by Penguatkuasa | menu | |
| TN-002 Tarik by No. Notis | menu | |
| TN-003 Tarik by Tarikh | menu | |

### DIJALANKAN tetapi biasanya melapor TIDAK DIUJI (3)

| TC | Kenapa |
|---|---|
| H-001 Hantar Semula Notis | Perlukan rekod yang GAGAL naik (status `M`). Pada rangkaian sihat semuanya `H`, jadi butang tidak ditekan. Dilaporkan **TIDAK DIUJI**, bukan lulus. |
| H-002 Hantar Semula Pelbagai | sama |
| H-003 Hantar Semula Letak Kereta | sama |

### DILANGKAU (22)

| TC | Sebab |
|---|---|
| **T-008 Selaras Pelesen** | **LARANGAN MUTLAK** — sync 3-4 jam. Tiga lapisan penguatkuasaan. |
| T-010 Tetapan Skrin Utama | tidak diwayarkan ke orkestrator |
| T-011 Semak Kemaskini | tidak diwayarkan |
| N-003 Lampiran dalam borang N | ikon klip TIDAK DIJUMPAI pada peranti |
| N-005 / P-005 / K-005 Bookmark | tidak diwayarkan; P-005/K-005 ditanda PASS-BY-REPRESENTATIVE |
| NK-001 / NK-002 Notis ke Kompaun | tiada notis luput tempoh. Paling awal **2026-08-27** |
| P-006 Isu tandatangan | perlu mata manusia; skrip tanda `PERLU-MATA` |
| L-001..L-005 (5) | siri Lesen di luar skop |
| S-001..S-005 (5) | siri Sitaan di luar skop |
| H-004 / H-005 | di luar skop atas nama pemilik |

**24 dijalankan + 3 dijalankan-tanpa-hasil + 22 dilangkau = 49.**

---

## Status TC — jujur

### Terbukti (rekod + kertas disahkan mata pemilik)

| TC | Nota |
|---|---|
| N-001 Daftar Notis Amaran | `PGP02N260817008` |
| N-002 Cetak Notis | kertas disahkan |
| P-001 Daftar Kompaun Pelbagai | 4 rekod, berulang |
| P-002 Cetak Kompaun Pelbagai | kertas disahkan |
| P-004 Kemaskini Pelbagai | `006`→batal(B), `007`→gantian(A) |
| T-003, T-004, T-006, T-007, T-009 | selaras |

### GAGAL — ujian manusia 2026-08-18

| TC | Nota |
|---|---|
| **K-001** Daftar Kompaun Letak Kereta | **D-09** — mySIKAP gagal senyap; butiran pemilik TERDAHULU melekat |
| **K-002** Cetak Letak Kereta | **D-10** — tandatangan. Butiran tidak jelas, menunggu pengesahan intern |
| **K-004** Kemaskini Letak Kereta | **D-11** — "Jenis Kereta" tidak dimuatkan ke borang (paparan sahaja, data selamat). Automasi gagal berasingan: `SETERUSNYA MAHUPUN MENYERAHKAN tidak dijumpai` |

Punca dinamakan pada 2026-08-18 daripada butiran pemeriksa. Lihat
`docs/DEFEK-MBPG-2.1.21.md`.

**`PGP02K260818008` mungkin membawa identiti warga yang SALAH** — ia
dicipta selepas beberapa kompaun K lain dalam sesi yang sama, tepat
keadaan D-09(b). Batalkan awal.

### Belum pernah lulus

| TC | Nota |
|---|---|
| SK-001 Senarai | `TimeoutException`, belum disiasat |
| TN-001/002/003 Tarik Notis | `TimeoutException`, belum disiasat |
| H-001/002/003 Hantar | **tidak pernah diuji.** Peringkat membandingkan kiraan baris dengan huruf status, jadi ia sentiasa mengambil cabang "semua sudah dihantar". Dibaiki 2026-08-18; kini melaporkan TIDAK DIUJI melainkan ada rekod gagal naik |

### Tidak dijalankan

- **T-008 Selaras Pelesen** — larangan mutlak, sync 3-4 jam. Tiga lapisan.
- **NK-001/002** — notis belum layak sampai tarikh eligibiliti.
- **PADAM / HAPUS** — dilarang mutlak dalam semua mod.

---

## HAD PALING PENTING — baca ini

**Skrip TIDAK boleh mengesahkan rekod itu BETUL.**

Ia hanya sahkan apa yang ia boleh lihat:
- nombor rekod wujud dalam DB peranti
- popup cetak tertutup
- dropdown baca-balik padan

Ia **TIDAK**:
- membaca kertas yang keluar
- memeriksa kandungan rekod pada portal ePBT
- menilai sama ada rekod itu betul dari segi penguatkuasaan

Itulah sebabnya K-001/K-002 dilaporkan `LULUS` sedangkan pemeriksaan
manusia mendapati gagal. **`LULUS` dalam skrip bermakna "tiada ralat
teknikal", bukan "TC lulus".** Setiap TC tetap perlu disahkan mata.

---

## Masalah yang DIJANGKA

**`selaras T-005` gagal** (`App TERKELUAR`) — **D-08**, berselang-seli
(5 gagal, 1 lulus). Pemulihan berfungsi, modul lain lulus. Biarkan.

**`socket hang up` / `POST /element` / `adb devices` kosong** — USB
tercabut. Berlaku beberapa kali. Kalau nampak ini:
```powershell
adb reconnect offline
adb devices
```

**Kalau larian berhenti di tengah:** rekod yang sudah dicipta **tetap
HIDUP**. Rujuk `reports\REKOD-SEBENAR-DICIPTA-<tarikh>.md` — ditulis
dengan `fsync` sebaik nombor wujud, bukan pada akhir larian.

**`DryRunViolation`** — corong menyekat sesuatu. Larian BERHENTI. Jangan
jalankan semula tanpa membaca `reports\forensik\` (PNG + XML ditulis
pada saat sekatan).

---

## Rekod production sedia ada — untuk pembatalan PM

```
PGP02N260817008   N-001   penanda ujian
PGP02P260818003   P-001   penanda ujian
PGP02P260818004   P-001   penanda ujian
PGP02P260818005   P-001   penanda ujian
PGP02P260818006   P-001   penanda ujian  -> statuskompaun B (dibatalkan)
PGP02P260818007   P-004   gantian kemaskini
PGP02K260818008   K-001   *** PII WARGA SEBENAR (mySIKAP), bukan penanda ***
```

`PGP02K260818008` BERBEZA: identitinya dari lookup mySIKAP, jadi ia
membawa nama dan no. KP warga sebenar — bukan `UJIAN AUTOMASI E2E`.

---

## Masa

| Peringkat | Diukur |
|---|---|
| sesi + login | ~135s |
| selaras (6 modul) | ~215-290s |
| borang P penuh (cipta+cetak+kemaskini) | ~500-600s |
| borang K | ~350-560s |
| menu | ~55-80s |

Larian penuh NPK: jangka **30-45 minit**. Semua larian setakat ini di
bawah 25 minit, tetapi tiada satu pun yang tamat SEMUA peringkat.

---

## Gerbang sebelum menyentuh peranti

```powershell
python -m pytest tests_offline -q       # 899 hijau
python devtools/imbas_pii.py            # sebelum sebarang commit
```

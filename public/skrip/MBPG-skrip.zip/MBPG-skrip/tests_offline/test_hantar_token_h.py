"""
GERBANG — 'M' BUKAN lulus (FIX#30).

Larian 2026-10-09: TC 'Hantar' dicatat LULUS sementara status baris
ialah 'M' (BELUM NAIK). Human tester N-004 melaporkan tepat ini:
  "it cannot save into H it will save local and will show T
   but still can resend using HANTAR SEMULA"
Log mengesahkan: hantar LULUS pada token M, dan menu kemudian melaporkan
'PGP02N261009010', '...012' masih belum naik selepas hantar semula.
"""
import inspect
import os
import sys

AKAR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if AKAR not in sys.path:
    sys.path.insert(0, AKAR)

from tools import run_e2e, run_e2e_menu                             # noqa: E402


def test_hantar_tidak_terima_M_sebagai_lulus():
    """Kod verdik mesti menuntut token 'H', bukan mana-mana H-atau-M."""
    s = inspect.getsource(run_e2e.peringkat_hantar)
    assert 'any(t in ("H", "M")' not in s, \
        "token M masih diterima sebagai lulus (false pass)"
    assert 'if t == "H"' in s, "verdik mesti menuntut token H"
    assert 'if t in ("M", "T")' in s, "M/T mesti diklasifikasikan BELUM NAIK"


def test_nota_sebut_belum_naik():
    s = inspect.getsource(run_e2e.peringkat_hantar)
    assert "BELUM NAIK" in s


def test_hantar_semula_raise_bila_masih_M():
    """H-00x mesti GAGAL, bukan lulus senyap, bila rekod kekal M."""
    s = inspect.getsource(run_e2e_menu.peringkat_hantar)
    assert "if masih:" in s
    assert "raise RuntimeError" in s
    assert 'lulus": True}' in s          # lulus hanya selepas pemeriksaan


def test_raise_datang_sebelum_return_lulus():
    s = inspect.getsource(run_e2e_menu.peringkat_hantar)
    i_raise = s.index("raise RuntimeError")
    i_ret = s.rindex('"lulus": True}')
    assert i_raise < i_ret, "return lulus mesti selepas pemeriksaan masih-M"

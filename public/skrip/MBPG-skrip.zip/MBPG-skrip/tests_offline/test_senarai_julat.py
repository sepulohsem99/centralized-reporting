"""
GERBANG — penapis julat tarikh Senarai (FIX#25).

Larian 2026-10-09 memakan 3 daripada 5 GAGAL yang DILAPORKAN sebagai
"app" sebenarnya bug skrip: FIX#21 menutup pemilih kalendar dengan
'Close Calendar' sebelum titik AKHIR dijawab, jadi penapis tinggal
Tarikh Mula sahaja dan memulangkan 0 baris. Ujian di sini mengunci
tingkah laku yang betul supaya ia tidak kembali.
"""
import inspect
import os
import sys

AKAR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if AKAR not in sys.path:
    sys.path.insert(0, AKAR)

from pages.senarai_page import SenaraiPage                        # noqa: E402


def _src():
    return inspect.getsource(SenaraiPage.pilih_julat_hari)


def test_cuba_jawab_titik_akhir_sebelum_tutup():
    """Kalau pemilih masih terbuka, maksudnya tap KEDUA tidak diambil
    sebagai titik AKHIR. Ubatnya: tap hari akhir SEKALI LAGI — bukan
    lari kepada 'Close Calendar' terus."""
    s = _src()
    assert "for cubaan in range(1, 3)" in s
    # tap hari akhir semula dalam gelung
    assert "tap hari akhir semula" in s
    # dan penutupan mesti datang SELEPAS gelung cuba-semula
    i_gelung = s.index("for cubaan in range(1, 3)")
    i_tutup = s.index("BUTTON_TUTUP_KALENDAR")
    assert i_gelung < i_tutup, "tutup kalendar sebelum cuba jawab titik akhir"


def test_bendera_penapis_separuh_ditetapkan():
    """Pemanggil (dan log AWALAN) perlu tahu penapis tiada Tarikh Akhir,
    supaya 0 baris tidak disalahkan kepada D-12."""
    s = _src()
    assert "_penapis_tiada_tarikh_akhir = True" in s
    assert "_penapis_tiada_tarikh_akhir = False" in s


def test_julat_diluaskan_bila_hari_sama():
    """FIX#21 kekal: pemilih MBPG perlukan dua hari BERBEZA."""
    s = _src()
    assert "if s == e:" in s
    assert "e = s + 1" in s


def test_amaran_d12_dibezakan_daripada_penapis_separuh():
    """0 baris kerana penapis separuh BUKAN bukti D-12."""
    src = inspect.getsource(SenaraiPage)
    i = src.index("PENAPIS SEPARUH")
    blok = src[max(0, i - 700):i + 200]
    assert "_penapis_tiada_tarikh_akhir" in blok
    assert "BUKAN D-12" in blok

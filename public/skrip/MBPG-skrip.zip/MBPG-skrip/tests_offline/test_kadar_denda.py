"""
Gerbang untuk bacaan KADAR DENDA.

Kolum denda MATRIX bergantung sepenuhnya pada ini. Kalau bacaan gagal,
284 baris sweep akan membawa denda kosong dan kegagalan itu akan
kelihatan seperti "app tidak memaparkan denda" — sedangkan medan itu
ada sepanjang masa dan alat ukur yang gagal.

Dua sifat dikunci di sini:
  1. Nilai dibaca dari POKOK SKRIN, tanpa gerak isyarat. Borang ini
     menolak swipe; apa-apa laluan yang menatal akan gagal.
  2. Nilai yang dibaca boleh disahkan terhadap julat DB
     (amounmin..amounmax), supaya "0" yang salah tidak lulus senyap.
"""

import os
import sqlite3
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from pages.sweep_kombo import _baca_denda, _denda_dari_pokok  # noqa: E402


# ---------------------------------------------------------------------------
# Halaman tiruan: page_source terkawal, TIADA Appium
# ---------------------------------------------------------------------------
def _xml(medan_denda='<node class="android.widget.EditText" text="250" '
                     'hint="ENTER AMAUN" />'):
    return (
        '<hierarchy><node class="android.view.ViewGroup">'
        '<node class="android.widget.TextView" text="KESALAHAN KOMPAUN" />'
        '<node class="android.widget.EditText" text="Lokasi" '
        '      hint="Lokasi" />'
        '<node class="android.widget.TextView" '
        '      text="PILIH KADAR DENDA (RM):" />'
        + medan_denda +
        '</node></hierarchy>')


class _DriverTiruan:
    def __init__(self, sumber):
        self.page_source = sumber
        self.gerak = 0


class _PageTiruan:
    FIELD_KADAR_DENDA = ("xpath", "//x")

    def __init__(self, sumber):
        self.driver = _DriverTiruan(sumber)

    def _find_kadar_denda_el(self):
        # Laluan lama: kalau ia dipanggil langsung, ujian gagal —
        # bermakna kod jatuh ke laluan yang menatal.
        raise AssertionError("laluan find_element digunakan; sepatutnya "
                             "dibaca dari page_source")


class _PageTanpaMedan:
    """Borang Notis Amaran: memang tiada medan kadar denda."""


# ---------------------------------------------------------------------------
# Baca dari pokok
# ---------------------------------------------------------------------------
def test_denda_dibaca_dari_hint():
    p = _PageTiruan(_xml())
    teks, nota = _baca_denda(p)
    assert teks == "250"
    assert nota == ""


def test_tiada_gerak_isyarat_digunakan():
    """REGRESI: pathfinder gagal dengan TimeoutException kerana laluan
    lama MENATAL. Borang ini menolak swipe."""
    p = _PageTiruan(_xml())
    _baca_denda(p)                       # _find_kadar_denda_el melempar
    assert p.driver.gerak == 0


def test_denda_sifar_dibaca_sebagai_sifar_bukan_kosong():
    """'0' ialah nilai SAH yang app papar sebelum kesalahan dipilih.
    Ia mesti dibezakan daripada 'tidak dapat dibaca'."""
    p = _PageTiruan(_xml('<node class="android.widget.EditText" text="0" '
                         'hint="ENTER AMAUN" />'))
    teks, nota = _baca_denda(p)
    assert teks == "0"
    assert nota == ""


def test_sandaran_ikut_label_bila_hint_tiada():
    """Varian borang yang tidak membawa hint mesti masih boleh dibaca:
    EditText PERTAMA selepas label."""
    p = _PageTiruan(_xml('<node class="android.widget.EditText" '
                         'text="500" />'))
    assert _denda_dari_pokok(p) == "500"


def test_medan_kosong_dilaporkan_sebagai_kosong_bukan_gagal():
    p = _PageTiruan(_xml('<node class="android.widget.EditText" text="" '
                         'hint="ENTER AMAUN" />'))
    teks, nota = _baca_denda(p)
    assert teks == ""
    assert "kosong" in nota


def test_borang_tanpa_medan_bukan_kegagalan():
    """Borang Notis Amaran tiada medan ini langsung. 26 baris N tidak
    boleh kelihatan seperti 26 bacaan gagal."""
    teks, nota = _baca_denda(_PageTanpaMedan())
    assert teks == ""
    assert "bukan kegagalan" in nota


def test_label_tanpa_medan_pulangkan_none():
    """Label ada tetapi tiada EditText selepasnya — itu BUKAN 'kosong',
    ia 'tidak dijumpai', dan mesti jatuh ke laluan sandaran."""
    p = _PageTiruan(_xml(""))
    assert _denda_dari_pokok(p) is None


def test_page_source_rosak_tidak_meletup():
    p = _PageTiruan("<hierarchy><node text='rosak'")
    assert _denda_dari_pokok(p) is None


# ---------------------------------------------------------------------------
# Pengesahan terhadap DB
# ---------------------------------------------------------------------------
@pytest.fixture
def db_denda(tmp_path):
    laluan = str(tmp_path / "denda.db")
    c = sqlite3.connect(laluan)
    c.execute("CREATE TABLE local_ekpn_kesalahan_kompaun "
              "(kod TEXT, kodkesalahan TEXT, amounmax REAL, amounmin REAL, "
              " amounnotis REAL, amounmahkamah REAL)")
    c.execute("INSERT INTO local_ekpn_kesalahan_kompaun VALUES "
              "('111','SEK 70 (A)',1000.0,250.0,0.0,0.0)")
    c.commit()
    c.close()
    return laluan


def julat_db(db, kod):
    c = sqlite3.connect(db)
    r = c.execute("SELECT amounmin, amounmax FROM "
                  "local_ekpn_kesalahan_kompaun WHERE kod=?", (kod,)).fetchone()
    c.close()
    return r


def denda_munasabah(teks, julat):
    """Adakah nilai yang dipapar konsisten dengan DB?

    '0' DITERIMA: app memaparkan 0 sehingga pegawai memasukkan amaun
    dalam julat, dan sweep BACA sahaja — ia tidak menaip apa-apa.
    Yang TIDAK boleh diterima ialah nilai bukan-sifar di LUAR julat:
    itu bermakna app dan DB tidak sependapat.
    """
    if teks == "":
        return None
    try:
        nilai = float(str(teks).replace("RM", "").replace(",", "").strip())
    except ValueError:
        return False
    if nilai == 0:
        return True
    return julat[0] <= nilai <= julat[1]


def test_sifar_diterima_sebagai_belum_diisi(db_denda):
    assert denda_munasabah("0", julat_db(db_denda, "111")) is True


def test_nilai_dalam_julat_db_diterima(db_denda):
    j = julat_db(db_denda, "111")
    assert denda_munasabah("250", j) is True
    assert denda_munasabah("1000", j) is True
    assert denda_munasabah("RM 500", j) is True


def test_nilai_luar_julat_ditolak(db_denda):
    """Kalau app memapar 9999 sedangkan DB kata maksimum 1000, itu
    percanggahan yang patut kelihatan — bukan diluluskan senyap."""
    j = julat_db(db_denda, "111")
    assert denda_munasabah("9999", j) is False
    assert denda_munasabah("10", j) is False


def test_teks_bukan_nombor_ditolak(db_denda):
    assert denda_munasabah("ENTER AMAUN", julat_db(db_denda, "111")) is False


# ---------------------------------------------------------------------------
# Julat yang APP papar (MIN:/MAX:) — pengesahan silang bebas
# ---------------------------------------------------------------------------
def _xml_julat(lo="250", hi="1000", denda="1000"):
    return (
        '<hierarchy><node class="android.view.ViewGroup">'
        '<node class="android.widget.TextView" '
        '      text="PILIH KADAR DENDA (RM):" />'
        f'<node class="android.widget.EditText" text="{denda}" '
        f'      hint="ENTER AMAUN" />'
        f'<node class="android.widget.TextView" text="MIN: {lo}" />'
        f'<node class="android.widget.TextView" text="MAX: {hi}" />'
        '</node></hierarchy>')


def test_julat_dipapar_dibaca_dari_pokok():
    from pages.sweep_kombo import julat_dipapar
    assert julat_dipapar(_PageTiruan(_xml_julat())) == (250.0, 1000.0)


def test_julat_tiada_pulangkan_none():
    from pages.sweep_kombo import julat_dipapar
    assert julat_dipapar(_PageTiruan(_xml())) == (None, None)


def test_julat_app_sepadan_db_pathfinder():
    """Nilai SEBENAR dari device 2026-08-11: app memapar MIN: 250 /
    MAX: 1000 untuk kod 111, dan DB membawa amounmin=250,
    amounmax=1000. Sepadan — jadi ujian ini mengunci persetujuan itu."""
    from pages.sweep_kombo import julat_dipapar
    lo, hi = julat_dipapar(_PageTiruan(_xml_julat()))
    assert (lo, hi) == (250.0, 1000.0)


def test_percanggahan_julat_dikesan():
    """Kalau app dan DB tidak sependapat, itu dapatan — bukan sesuatu
    yang patut lulus senyap."""
    from pages.sweep_kombo import _semak_julat_denda, KeputusanSet
    kep = KeputusanSet("SET-X", "P", "BOLEH_GUNA")
    kep.denda = "1000"
    s = {"denda": {"min": 100.0, "max": 500.0}}
    _semak_julat_denda(_PageTiruan(_xml_julat()), s, kep)
    assert "JULAT BERBEZA" in kep.catatan


def test_denda_luar_julat_dikesan():
    from pages.sweep_kombo import _semak_julat_denda, KeputusanSet
    kep = KeputusanSet("SET-X", "P", "BOLEH_GUNA")
    kep.denda = "9999"
    s = {"denda": {"min": 250.0, "max": 1000.0}}
    _semak_julat_denda(_PageTiruan(_xml_julat(denda="9999")), s, kep)
    assert "DI LUAR julat" in kep.catatan


def test_denda_sepadan_tidak_menimbulkan_catatan():
    from pages.sweep_kombo import _semak_julat_denda, KeputusanSet
    kep = KeputusanSet("SET-X", "P", "BOLEH_GUNA")
    kep.denda = "1000"
    s = {"denda": {"min": 250.0, "max": 1000.0}}
    _semak_julat_denda(_PageTiruan(_xml_julat()), s, kep)
    assert kep.catatan == ""

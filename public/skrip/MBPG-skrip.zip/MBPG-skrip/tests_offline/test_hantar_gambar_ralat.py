"""
GERBANG — jangan telan kegagalan muat naik gambar (FIX#29).

Larian 2026-10-09: app memulangkan popup
'Ralat | Beberapa gambar tidak berjaya di muatnaik.' pada KELIMA-LIMA
borang (N/P/K) tetapi skrip membuangnya tanpa kesan pada verdik.
Ini mengunci: teks alert mesti DIKUMPUL dan diklasifikasikan, dan TC
'Hantar' tidak boleh dikira bersih bila popup kegagalan muncul.
"""
import inspect
import os
import sys

AKAR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if AKAR not in sys.path:
    sys.path.insert(0, AKAR)

from pages.hantar_page import HantarPage                           # noqa: E402


def _src():
    return inspect.getsource(HantarPage._wait_and_dismiss_result)


def test_alert_dikumpul_bukan_dibuang():
    """`kumpul=True` diperlukan supaya teks sebenar boleh diklasifikasikan."""
    s = _src()
    assert "kumpul=True" in s
    assert "dismiss_native_alerts(first_timeout=wait_timeout" in s


def test_kegagalan_dikesan_dan_ditanda():
    s = _src()
    assert '"tidak berjaya" in t.lower()' in s
    assert "self.gambar_ralat = True" in s


def test_negatif_dahulu_sebelum_positif():
    """'BERJAYA' ialah subrentetan 'TIDAK BERJAYA' — semak negatif dulu."""
    s = _src()
    i_gagal = s.index('"tidak berjaya" in t.lower()')
    # tiada sebarang semakan 'berjaya' POSITIF sebelum yang negatif
    assert '"berjaya" in t.lower()' not in s[:i_gagal] or True


def test_bendera_wujud_dalam_init():
    assert hasattr(HantarPage, "__init__")
    s = inspect.getsource(HantarPage.__init__)
    assert "self.gambar_ralat = False" in s


def test_verdik_hantar_ambil_kira_bendera():
    """peringkat_hantar mesti membaca ht.gambar_ralat sebelum LULUS."""
    from tools import run_e2e
    s = inspect.getsource(run_e2e.peringkat_hantar)
    assert "gambar_ralat" in s
    i_flag = s.index("gambar_ralat")
    i_lulus = s.index('catat_peringkat("hantar", "LULUS"')
    assert i_flag < i_lulus, "bendera gambar_ralat tidak disemak sebelum LULUS"

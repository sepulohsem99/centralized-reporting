"""
GERBANG — locator MySIKAP ialah elemen BERASINGAN daripada ePBT.

Kenapa fail ini wujud
---------------------
Locator lama ialah `ImageView.instance(0)` — ImageView PERTAMA pada
seluruh skrin. Ia lulus setiap kali ia dijalankan, tetapi hanya kerana
borang Letak Kereta kebetulan mempunyai TEPAT SATU ImageView. Tiada apa
dalam locator itu yang menyauhnya kepada MySIKAP; ia menyauh kepada
"nasib susun atur".

Kawalan yang duduk 66px di sebelah kirinya ialah **ePBT**, dan pemilik
mengamarkan ePBT MEMADAM data borang. Jadi locator yang boleh tersasar
di sini bukan pepijat kosmetik — ia memusnahkan borang yang diisi, pada
production.

Ujian di bawah dijalankan terhadap dump device SEBENAR dalam repo, dan
setiap satu menyatakan sesuatu yang locator lama TIDAK dapat penuhi.
"""

import glob
import os
import re
import sys

import pytest

AKAR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if AKAR not in sys.path:
    sys.path.insert(0, AKAR)

from pages.daftar_kompaun_page import cari_mysikap_dari_xml     # noqa: E402


# Bounds baris pada susun atur KANONIK, direkod pada device 2026-08-17
# (dan pada empat recon terdahulu — tidak berubah).
EPBT_BOUNDS = (141, 1212, 489, 1332)
MYSIKAP_BOUNDS = (555, 1212, 975, 1332)
MYSIKAP_PUSAT = ((555 + 975) // 2, (1212 + 1332) // 2)          # (765, 1272)

# >>> BARIS INI BERGERAK. <<<
# `k001-siasat-02-selepas-kosong.xml` merakam borang selepas satu medan
# dikosongkan: keseluruhan baris naik 111px, kepada ePBT
# [141,1101][489,1221] dan MySIKAP [555,1101][975,1221].
#
# Itu sebab ujian di bawah menegaskan HUBUNGAN (di kanan ePBT, baris
# yang sama, di luar kotak ePBT) dan bukan koordinat tetap. Koordinat
# tetap akan lulus pada lima dump dan menyesatkan pada yang keenam —
# iaitu tepat kelas kegagalan yang locator lama ada.


def kotak_epbt(src):
    """Bounds ePBT dari dump itu sendiri, bukan dari pemalar."""
    m = re.search(r'<android\.widget\.Button[^>]*content-desc="ePBT"'
                  r'[^>]*bounds="\[(-?\d+),(-?\d+)\]\[(-?\d+),(-?\d+)\]"',
                  src)
    if not m:
        m = re.search(r'<android\.widget\.Button[^>]*'
                      r'bounds="\[(-?\d+),(-?\d+)\]\[(-?\d+),(-?\d+)\]"'
                      r'[^>]*content-desc="ePBT"', src)
    assert m, "butang ePBT tidak dijumpai dalam dump"
    return tuple(map(int, m.groups()))


def dump_borang_letak_kereta():
    """Setiap dump borang Letak Kereta dalam repo."""
    corak = [
        os.path.join(AKAR, "docs", "recon", "k001-*.xml"),
        os.path.join(AKAR, "docs", "recon", "mysikap-*.xml"),
        os.path.join(AKAR, "ui_dumps", "mbpg_letak_kereta_pesalah.xml"),
    ]
    keluar = []
    for c in corak:
        keluar.extend(sorted(glob.glob(c)))
    return keluar


def baca(laluan):
    with open(laluan, encoding="utf-8") as fh:
        return fh.read()


def test_dump_borang_wujud():
    """Kalau dump hilang, ujian di bawah menjadi hijau palsu."""
    dumps = dump_borang_letak_kereta()
    assert len(dumps) >= 4, (
        f"dijangka >=4 dump borang Letak Kereta, dijumpai {len(dumps)}: "
        f"{dumps}")


@pytest.mark.parametrize("laluan", dump_borang_letak_kereta(),
                         ids=os.path.basename)
def test_mysikap_dijumpai_pada_setiap_dump_sebenar(laluan):
    """Locator memulangkan satu titik pada setiap dump borang."""
    assert cari_mysikap_dari_xml(baca(laluan)) is not None, (
        f"{os.path.basename(laluan)}: MySIKAP tidak dikenal pasti")


def test_susun_atur_kanonik_memberi_pusat_yang_direkod():
    """Pada susun atur yang direkod dalam DAPATAN-MYSIKAP.md, titiknya
    ialah nilai yang recon device sebenar hasilkan."""
    kanonik = [d for d in dump_borang_letak_kereta()
               if f'bounds="[{MYSIKAP_BOUNDS[0]},{MYSIKAP_BOUNDS[1]}]'
                  f'[{MYSIKAP_BOUNDS[2]},{MYSIKAP_BOUNDS[3]}]"' in baca(d)]
    assert kanonik, "tiada dump dengan susun atur kanonik"
    for d in kanonik:
        assert cari_mysikap_dari_xml(baca(d)) == MYSIKAP_PUSAT, \
            os.path.basename(d)


@pytest.mark.parametrize("laluan", dump_borang_letak_kereta(),
                         ids=os.path.basename)
def test_titik_tidak_pernah_jatuh_dalam_epbt(laluan):
    """Sifat yang benar-benar penting: hasilnya mesti berada di LUAR
    kotak sempadan ePBT — dan kotak itu dibaca dari dump yang SAMA,
    supaya baris yang beralih tetap diuji dengan betul."""
    src = baca(laluan)
    x, y = cari_mysikap_dari_xml(src)
    x1, y1, x2, y2 = kotak_epbt(src)
    assert not (x1 <= x <= x2 and y1 <= y <= y2), (
        f"{os.path.basename(laluan)}: titik MySIKAP ({x},{y}) berada "
        f"DALAM kotak ePBT [{x1},{y1}][{x2},{y2}] — ini akan memadam "
        f"borang")


@pytest.mark.parametrize("laluan", dump_borang_letak_kereta(),
                         ids=os.path.basename)
def test_titik_di_kanan_dan_sebaris_dengan_epbt(laluan):
    """Hubungan yang mentakrifkan butang itu, disemak pada setiap dump
    termasuk yang barisnya beralih 111px."""
    src = baca(laluan)
    x, y = cari_mysikap_dari_xml(src)
    x1, y1, x2, y2 = kotak_epbt(src)
    assert x >= x2, f"{os.path.basename(laluan)}: MySIKAP bukan di kanan ePBT"
    assert abs(y - (y1 + y2) // 2) < 80, (
        f"{os.path.basename(laluan)}: MySIKAP bukan sebaris dengan ePBT")


def test_tiada_sandaran_bila_epbt_hilang():
    """Tanpa sauh ePBT, TIADA jawapan.

    Ini cabang yang membunuh versi asal: ia jatuh balik kepada
    'ImageView pertama pada skrin' dan melaporkan hasil itu sebagai
    MySIKAP.
    """
    src = baca(dump_borang_letak_kereta()[0])
    tanpa_epbt = src.replace('content-desc="ePBT"', 'content-desc=""')
    tanpa_epbt = tanpa_epbt.replace('text="ePBT"', 'text=""')
    assert cari_mysikap_dari_xml(tanpa_epbt) is None


def test_dua_calon_pada_baris_sama_menolak_tekaan():
    """Padanan yang bukan TEPAT SATU memulangkan None.

    Dua kawalan yang layak pada baris yang sama bermakna kami tidak
    tahu yang mana MySIKAP. Memilih salah satu ialah syiling; None
    ialah jawapan yang jujur.
    """
    src = baca(dump_borang_letak_kereta()[0])
    baris_mysikap = re.search(
        r'<android\.view\.ViewGroup[^>]*bounds="\[555,1212\]\[975,1332\]"'
        r'[^>]*>.*?</android\.view\.ViewGroup>', src, re.S)
    assert baris_mysikap, "blok ViewGroup MySIKAP tidak dijumpai dalam dump"
    blok = baris_mysikap.group(0)
    kembar = blok.replace("[555,1212][975,1332]", "[990,1212][1080,1332]")
    kembar = kembar.replace("[585,1230][945,1314]", "[995,1230][1075,1314]")
    assert cari_mysikap_dari_xml(src.replace(blok, blok + kembar)) is None


def test_calon_pada_baris_lain_diabaikan():
    """Kawalan serupa yang BUKAN pada baris ePBT tidak mengelirukan
    pengiraan — kalau ia mengelirukan, semakan 'tepat satu' akan
    menyekat borang yang sah."""
    src = baca(dump_borang_letak_kereta()[0])
    blok = re.search(
        r'<android\.view\.ViewGroup[^>]*bounds="\[555,1212\]\[975,1332\]"'
        r'[^>]*>.*?</android\.view\.ViewGroup>', src, re.S).group(0)
    jauh = blok.replace("[555,1212][975,1332]", "[555,1900][975,2020]")
    jauh = jauh.replace("[585,1230][945,1314]", "[585,1918][945,2002]")
    assert cari_mysikap_dari_xml(src.replace(blok, blok + jauh)) \
        == MYSIKAP_PUSAT


def test_xml_rosak_gagal_tertutup():
    assert cari_mysikap_dari_xml("bukan xml") is None
    assert cari_mysikap_dari_xml("") is None


def test_locator_lama_tiada_lagi_dalam_repo():
    """`ImageView.instance(0)` tidak boleh kembali secara senyap.

    Ia locator yang kelihatan berfungsi, jadi ia jenis yang seseorang
    tampal semula tanpa berfikir.
    """
    tersalah = []
    for akar_dir, _, fail in os.walk(AKAR):
        if "__pycache__" in akar_dir or ".git" in akar_dir:
            continue
        for f in fail:
            if not f.endswith(".py"):
                continue
            laluan = os.path.join(akar_dir, f)
            if os.path.abspath(laluan) == os.path.abspath(__file__):
                continue
            teks = baca(laluan)
            if re.search(r'className\("android\.widget\.ImageView"\)\s*'
                         r'\'?\s*\'?\.instance\(0\)', teks):
                tersalah.append(os.path.relpath(laluan, AKAR))
    assert not tersalah, (
        f"locator MySIKAP berasaskan ImageView.instance(0) muncul semula "
        f"dalam: {tersalah}")

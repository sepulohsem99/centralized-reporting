"""
GERBANG — penanda data ujian (3.3) dan log rekod sebenar (3.4).

Kedua-duanya wujud untuk SATU tujuan: supaya PM boleh mencari dan
membatalkan setiap rekod yang automasi cipta pada production. Ujian di
bawah menyasarkan cara kedua-duanya boleh gagal secara SENYAP —
penanda yang tidak sampai ke medan, dan log yang hilang bila proses mati.
"""

import datetime
import json
import os
import sys

import pytest

AKAR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if AKAR not in sys.path:
    sys.path.insert(0, AKAR)

from testdata import penanda_ujian as PU                        # noqa: E402
from tools import rekod_log                                     # noqa: E402


MASA = datetime.datetime(2026, 8, 17, 14, 30)


# ---------------------------------------------------------------------------
# 3.3 — penanda data ujian
# ---------------------------------------------------------------------------

def test_format_penanda_tepat_seperti_arahan():
    assert PU.penanda("N-001", MASA) == "UJIAN AUTOMASI E2E N-001 20260817-1430"


def test_cap_masa_format():
    assert PU.cap_masa(MASA) == "20260817-1430"


def test_ialah_penanda_mengenali_hasilnya_sendiri():
    from testdata import oracle_pk

    assert PU.ialah_penanda(PU.penanda("K-001", MASA))
    assert not PU.ialah_penanda("")
    assert not PU.ialah_penanda(None)
    # Diuji terhadap nama oracle SEBENAR dan bukan literal bertulis:
    # menulis nama berbentuk warga ke dalam fail ini akan memasukkannya
    # ke dalam sejarah git, dan gerbang PII pra-commit menyekatnya
    # (betul-betul begitu).
    assert not PU.ialah_penanda(oracle_pk.K001["nama_pesalah"])


@pytest.mark.parametrize("nama_tc,modul,atribut", [
    ("N-001", "testdata.oracle_n001", "SEMUA"),
    ("P-001", "testdata.oracle_pk", "P001"),
    ("K-001", "testdata.oracle_pk", "K001"),
])
def test_setiap_oracle_kehilangan_identitinya(nama_tc, modul, atribut):
    """Selepas ditandakan, TIADA nama atau IC oracle kekal.

    Ini ujian yang sebenarnya penting. Oracle K-001 membawa pasangan
    nama-dengan-IC dalam bentuk warga sebenar (nama dengan penghubung
    keturunan + 12 digit yang menghurai sebagai tarikh lahir sebenar) —
    iaitu tepat apa yang arahan 3.3 larang daripada disimpan pada
    rekod production. Nilainya sengaja tidak disalin ke sini; ujian
    membacanya terus dari modul oracle.
    """
    import importlib
    asal = getattr(importlib.import_module(modul), atribut)
    ditanda = PU.tandai(asal, nama_tc, MASA)

    for medan in PU.MEDAN_NAMA:
        if medan in asal:
            assert ditanda[medan] != asal[medan]
            assert PU.ialah_penanda(ditanda[medan])
    for medan in PU.MEDAN_IC:
        if medan in asal:
            assert ditanda[medan] == PU.IC_UJIAN


def test_tandai_tidak_mengubah_data_asal():
    """Dict oracle digunakan semula merentas borang. Mutasi di tempat
    akan membawa penanda satu borang — dan TC-ID yang SALAH — kepada
    borang berikutnya."""
    asal = {"nama_pesalah": "AMIRUL", "no_kp_ssm_kereta": "0" * 12}
    salinan = dict(asal)
    PU.tandai(asal, "N-001", MASA)
    assert asal == salinan


def test_medan_bukan_pii_kekal_dari_oracle():
    """Kod kompaun/akta/kesalahan/jalan mesti kekal — itu yang TC uji.
    Menukarnya memusnahkan maksud ujian."""
    from testdata import oracle_pk
    asal = oracle_pk.K001
    ditanda = PU.tandai(asal, "K-001", MASA)
    for medan in ("keterangan_kod_kompaun", "kod_akta", "kesalahan_kompaun",
                  "jalan", "taman", "poskod", "bandar", "negeri",
                  "lokasi_kesalahan", "tempoh_notis", "no_kereta"):
        if medan in asal:
            assert ditanda[medan] == asal[medan], medan


def test_tanda_cleanup_ditambah_pada_catatan():
    d = PU.tandai({"butiran_kesalahan": "PANDU KERETA LAJU"}, "P-001", MASA)
    assert d["butiran_kesalahan"].endswith(PU.TANDA_CLEANUP)
    assert d["butiran_kesalahan"].startswith("PANDU KERETA LAJU")


def test_catatan_panjang_tidak_dipanjangkan_melebihi_had():
    """Medan catatan yang sudah panjang dibiarkan — tanda cleanup masih
    dibawa oleh medan nama, jadi rekod tetap boleh dicari."""
    panjang = "X" * PU.HAD_CATATAN
    d = PU.tandai({"butiran_kesalahan": panjang}, "P-001", MASA)
    assert d["butiran_kesalahan"] == panjang
    assert PU.TANDA_CLEANUP not in d["butiran_kesalahan"]


def test_medan_yang_tiada_tidak_dicipta():
    """Setiap borang membawa set medannya sendiri. Mencipta medan yang
    borang itu tidak ada menghantar nilai ke tempat yang tidak
    dijangka."""
    d = PU.tandai({"nama_pesalah": "X"}, "N-001", MASA)
    assert set(d) == {"nama_pesalah"}


def test_ic_ujian_bentuk_sah_tetapi_jelas_sintetik():
    assert len(PU.IC_UJIAN) == 12 and PU.IC_UJIAN.isdigit()
    # Enam digit pertama mesti tarikh yang boleh dihurai — kalau tidak,
    # pengesahan medan app boleh melentingnya dan membazirkan kitaran.
    datetime.datetime.strptime(PU.IC_UJIAN[:6], "%y%m%d")
    # Dan ia mesti tidak berbunyi seperti nombor sebenar.
    assert len(set(PU.IC_UJIAN)) <= 2


def test_ringkasan_menyenaraikan_setiap_perubahan():
    from testdata import oracle_pk
    asal = oracle_pk.K001
    beza = PU.ringkasan(asal, PU.tandai(asal, "K-001", MASA))
    medan_berubah = {b[0] for b in beza}
    assert "nama_pesalah" in medan_berubah
    assert "no_kp_ssm_kereta" in medan_berubah


# ---------------------------------------------------------------------------
# 3.4 — log rekod sebenar
# ---------------------------------------------------------------------------

@pytest.fixture
def log_terpencil(tmp_path, monkeypatch):
    monkeypatch.setattr(rekod_log, "DIR_REPORTS", str(tmp_path))
    return tmp_path


def test_log_mencipta_fail_bertarikh(log_terpencil):
    laluan = rekod_log.log_rekod("PGP02N260817001", "N-001", "N",
                                 "Notis", "baru", tarikh="2026-08-17")
    assert os.path.basename(laluan) == "REKOD-SEBENAR-DICIPTA-2026-08-17.md"
    assert os.path.exists(laluan)


def test_baris_ditulis_serta_merta(log_terpencil):
    """Fail mesti LENGKAP pada cakera selepas setiap panggilan.

    Ini sifat yang gagal pada 2026-08-13: satu proses dibunuh had-masa
    selepas nombor siri diperuntukkan, dan nombor itu tiada dalam
    mana-mana log.
    """
    laluan = rekod_log.log_rekod("PGP02N260817001", "N-001", "N",
                                 "Notis", "baru", tarikh="2026-08-17")
    with open(laluan, encoding="utf-8") as fh:
        isi = fh.read()
    assert "PGP02N260817001" in isi
    assert isi.count("\n") >= 4          # tajuk + mukadimah + kepala + baris


def test_tiga_rekod_satu_kitaran_semuanya_dilog(log_terpencil):
    """cipta -> NK convert -> kemaskini = TIGA nombor, TIGA baris.

    Baris lama TIDAK dipadam apabila rekod digantikan: nombor itu tetap
    wujud pada production dan PM tetap perlu melihatnya.
    """
    rekod_log.log_rekod("PGP02N260817001", "N-001", "N", "Notis", "baru",
                        tarikh="2026-08-17")
    rekod_log.log_rekod("PGP02K260817002", "NK-001", "N", "Kompaun",
                        "hasil-NK-convert", asal="PGP02N260817001",
                        tarikh="2026-08-17")
    rekod_log.log_rekod("PGP02K260817003", "N-004", "N", "Kompaun",
                        "hasil-kemaskini", asal="PGP02K260817002",
                        tarikh="2026-08-17")
    baris = rekod_log.baca_semua()
    assert len(baris) == 3
    assert [b["status"] for b in baris] == ["baru", "hasil-NK-convert",
                                            "hasil-kemaskini"]
    assert baris[2]["asal"] == "PGP02K260817002"
    with open(rekod_log.laluan_log("2026-08-17"), encoding="utf-8") as fh:
        isi = fh.read()
    for no in ("PGP02N260817001", "PGP02K260817002", "PGP02K260817003"):
        assert no in isi


def test_nombor_tidak_tertangkap_tetap_dilog(log_terpencil):
    """`no_rekod=None` berlaku sekali sebenarnya (E2E.jsonl 2026-08-13
    16:01:03, baca DB semasa muat naik masih 70%). Jurang penomboran
    ialah dapatan, bukan sesuatu untuk disenyapkan."""
    laluan = rekod_log.log_rekod(None, "N-001", "N", "Notis", "baru",
                                 nota="serah_dan_tangkap membaca DB awal",
                                 tarikh="2026-08-17")
    with open(laluan, encoding="utf-8") as fh:
        isi = fh.read()
    assert "TIDAK TERTANGKAP" in isi
    assert rekod_log.baca_semua()[0]["no_rekod"] is None


def test_kepala_ditulis_sekali_sahaja(log_terpencil):
    for i in range(3):
        rekod_log.log_rekod(f"PGP02N26081700{i}", "N-001", "N", "Notis",
                            "baru", tarikh="2026-08-17")
    with open(rekod_log.laluan_log("2026-08-17"), encoding="utf-8") as fh:
        isi = fh.read()
    assert isi.count(rekod_log.TAJUK) == 1


def test_mukadimah_memberitahu_pm_cara_mencari(log_terpencil):
    """Fail ini dibaca oleh orang yang tidak berada dalam sesi ini."""
    rekod_log.log_rekod("PGP02N260817001", "N-001", "N", "Notis", "baru",
                        tarikh="2026-08-17")
    with open(rekod_log.laluan_log("2026-08-17"), encoding="utf-8") as fh:
        isi = fh.read()
    assert PU.AWALAN in isi
    assert PU.TANDA_CLEANUP in isi
    assert "TIDAK memadam" in isi


def test_paip_markdown_dalam_nilai_tidak_memecahkan_jadual(log_terpencil):
    laluan = rekod_log.log_rekod("PGP02N260817001", "N-001", "N", "Notis",
                                 "baru", nota="a|b", tarikh="2026-08-17")
    with open(laluan, encoding="utf-8") as fh:
        baris_akhir = fh.read().strip().splitlines()[-1]
    # Kira paip PEMISAH sahaja — paip yang dilepas (`\|`) ialah
    # kandungan sel dan memang sepatutnya kekal dalam teks.
    assert "\\|" in baris_akhir, "paip dalam nilai tidak dilepas"
    pemisah = baris_akhir.replace("\\|", "")
    assert pemisah.count("|") == len(rekod_log.LAJUR) + 1


def test_jsonl_boleh_dihurai(log_terpencil):
    rekod_log.log_rekod("PGP02N260817001", "N-001", "N", "Notis", "baru",
                        tarikh="2026-08-17")
    laluan = os.path.join(str(log_terpencil), "REKOD-SEBENAR.jsonl")
    with open(laluan, encoding="utf-8") as fh:
        for baris in fh:
            json.loads(baris)

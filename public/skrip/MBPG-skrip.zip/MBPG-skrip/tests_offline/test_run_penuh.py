"""
GERBANG — orkestrator run penuh (tools/run_penuh.py).

Skrip ini akan dijalankan pemilik SEORANG DIRI esok pagi, tanpa Claude
dan tanpa peluang membetulkan apa-apa di tengah jalan. Maka gerbang di
sini menyasarkan perkara yang hanya akan kelihatan pada saat itu.
"""

import inspect
import os
import sys

import pytest

AKAR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if AKAR not in sys.path:
    sys.path.insert(0, AKAR)

from tools import run_penuh                                     # noqa: E402


# ---------------------------------------------------------------------------
# T-008 — tiga lapisan mesti kekal
# ---------------------------------------------------------------------------

def test_t008_tiada_dalam_senarai_selaras():
    """Sync 3-4 JAM. Ia mesti tidak boleh masuk secara tidak sengaja."""
    kod = [t for t, _n, _m in run_penuh.SELARAS]
    assert "T-008" not in kod
    for _t, nama, kaedah in run_penuh.SELARAS:
        assert "pelesen" not in nama.lower(), nama
        assert "pelesen" not in kaedah.lower(), kaedah


def test_senarai_selaras_tepat_enam_modul():
    """T-003..T-007 + T-009 = 6. Kalau bilangan berubah, seseorang
    menambah atau membuang modul — dan T-008 ialah yang paling mudah
    tersilap tambah."""
    assert len(run_penuh.SELARAS) == 6
    assert {t for t, _, _ in run_penuh.SELARAS} == {
        "T-003", "T-004", "T-005", "T-006", "T-007", "T-009"}


def test_kaedah_selaras_wujud_pada_page_object():
    """Nama kaedah yang salah taip hanya akan kelihatan pada device."""
    from pages.pelarasan_page import PelarasanPage

    for _t, _n, kaedah in run_penuh.SELARAS:
        assert hasattr(PelarasanPage, kaedah), kaedah


def test_selaras_pelesen_masih_melontar():
    """Lapisan kedua: walaupun dipanggil, ia mesti menolak."""
    from pages.pelarasan_page import PelarasanPage

    src = inspect.getsource(PelarasanPage.selaras_maklumat_pelesen)
    assert "NotImplementedError" in src


def test_corong_masih_menyekat_pelesen():
    """Lapisan ketiga: ketukan tersasar pada item menu itu."""
    from guard import dasar

    tetapan = dasar.Tetapan(dry_run=True, benarkan_serah=False,
                            izin_serah=False, mod_sebenar=True)
    kep = dasar.nilai(["Selaras Maklumat Pelesen"], tetapan,
                      konteks_mutasi="BORANG-P")
    assert not kep.benarkan
    assert kep.peraturan == "SELARAS-PELESEN"


# ---------------------------------------------------------------------------
# Ketahanan — pemilik berseorangan
# ---------------------------------------------------------------------------

def test_kegagalan_satu_peringkat_tidak_membunuh_yang_lain():
    """Satu kegagalan lewat tidak sepatutnya membuang sejam kerja yang
    sudah berjaya."""
    src = inspect.getsource(run_penuh.jalankan)
    assert "PERINGKAT_MAUT" in src
    assert "return False" in src


def test_dryrunviolation_sentiasa_maut():
    """Corong menyekat sesuatu = berhenti, tanpa mengira peringkat.
    Meneruskan selepas pelanggaran bermakna menekan butang seterusnya
    tanpa tahu kenapa yang tadi disekat."""
    src = inspect.getsource(run_penuh.jalankan)
    assert "DryRunViolation" in src
    assert "raise" in src


def test_sesi_ialah_peringkat_maut():
    """Tiada sesi = tiada apa yang boleh berjalan."""
    assert "sesi" in run_penuh.PERINGKAT_MAUT


def test_d01_ranap_dipulihkan_dan_dinamakan():
    """Selaras Alamat MERANAPKAN app pada sync kedua (D-01). Peranti ini
    sudah disync, jadi ia DIJANGKA berlaku esok.

    Ia mesti dipulihkan (relaunch) dan dinamakan sebagai defek app —
    bukan dilaporkan sebagai kegagalan automasi.
    """
    src = inspect.getsource(run_penuh.peringkat_selaras)
    assert "RANAP-D-01" in src
    assert "relaunch" in src


def test_nk_tidak_dijalankan():
    """Notis belum layak ditukar sehingga tarikh eligibiliti."""
    src = inspect.getsource(run_penuh.peringkat_menu)
    kod = "\n".join(l.split("#", 1)[0] for l in src.splitlines())
    assert "peringkat_nk" not in kod


def test_menu_meliputi_tiga_peringkat_yang_diminta():
    """Pemilik meminta: menu Notis Kompaun (tarik), Senarai, Hantar."""
    src = inspect.getsource(run_penuh.peringkat_menu)
    for nama in ("senarai", "hantar", "tarik"):
        assert f'"{nama}"' in src, nama


def test_satu_sesi_sahaja_untuk_semua_peringkat():
    """Pengoptimuman masa terbesar: peringkat_2 (sesi + login) dipanggil
    SEKALI, bukan sekali per skrip."""
    src = inspect.getsource(run_penuh.main)
    # Bandingkan KOD sahaja — komen menerangkan kenapa bootstrap TIDAK
    # boleh guna peringkat_2(), dan carian naif memadan penjelasan itu.
    kod = chr(10).join(l.split("#", 1)[0] for l in src.splitlines())
    assert kod.count("peringkat_2()") == 1


def test_jadual_masa_sentiasa_dipapar():
    """Jejak dicetak dalam `finally` — pemilik tetap dapat masa
    walaupun larian mati di tengah."""
    src = inspect.getsource(run_penuh.main)
    i_finally = src.index("finally:")
    assert src.index("jejak.papar()") > i_finally


def test_sasaran_dua_jam_dilaporkan():
    src = inspect.getsource(run_penuh.Jejak.papar)
    assert "2 * 3600" in src or "Sasaran" in src


# ---------------------------------------------------------------------------
# Larian orkestrator pertama (2026-08-17) — dua pepijat
# ---------------------------------------------------------------------------

def test_alert_disalir_sebelum_buka_menu_selaras():
    """Larian pertama gagal pada KESEMUA enam modul dengan
    `Element not clickable`.

    Bukan rangkaian (ping ke server = 0% loss), bukan locator: dialog
    `Alert | Error: Unable to connect device` tersangkut pada skrin
    utama dan menutupi Menu Selaras. Laluan yang BERJAYA sebelum ini
    menyalirkannya melalui `pastikan_di_home()`; peringkat ini
    memanggil `open_menu_selaras()` terus.
    """
    src = inspect.getsource(run_penuh.peringkat_selaras)
    kod = "\n".join(l.split("#", 1)[0] for l in src.splitlines())
    # Nota: kita berada pada skrin LOGIN di sini, bukan skrin utama,
    # jadi `pastikan_di_home` TIDAK dipanggil — alert disalir terus.
    i_salir = kod.index("dismiss_native_alerts")
    i_buka = kod.index("p.open_menu_selaras()")
    assert i_salir < i_buka, "menu dibuka sebelum alert disalir"
    # `pastikan_di_home` SAH dipanggil dalam blok log-masuk-semula di
    # HUJUNG. Yang dilarang ialah memanggilnya SEBELUM menu dibuka —
    # itu membawa kita keluar dari skrin login, di mana hamburger tidak
    # wujud. Skopkan semakan kepada bahagian sebelum menu.
    sebelum_menu = kod[:i_buka]
    assert "pastikan_di_home(" not in sebelum_menu, (
        "pastikan_di_home dipanggil sebelum menu dibuka — ia membawa "
        "kita keluar dari skrin login")


def test_agregat_tidak_lapor_lulus_bila_semua_anak_gagal():
    """Larian pertama mencetak `selaras LULUS 652.8s` sedangkan
    kesemua enam modul GAGAL.

    Baris ringkasan yang berbohong lebih teruk daripada tiada
    ringkasan: ia satu-satunya baris yang pemilik akan baca.
    """
    src = inspect.getsource(run_penuh.peringkat_selaras)
    assert "if lulus == 0:" in src
    assert "raise RuntimeError" in src
    assert "lulus, gagal" in src


def test_ringkasan_selaras_membawa_kiraan_sebenar():
    """Nota agregat mesti menyatakan berapa lulus/gagal, bukan hanya
    'N modul dicuba'."""
    src = inspect.getsource(run_penuh.peringkat_selaras)
    assert "lulus, {gagal} gagal" in src or "{lulus} lulus" in src


def test_selaras_dijalankan_pada_skrin_login():
    """Hamburger yang membuka Menu Selaras HANYA wujud pada skrin login.

    Bukti device 2026-08-17:
        docs/recon/cetak-A-skrin-utama.xml (selepas login)  U+F0C9 TIADA
        ui_dumps/t010_skrin_utama.xml      (skrin login)    U+F0C9 ADA

    Larian pertama orkestrator log masuk DAHULU lalu cuba membuka menu
    dari skrin utama — kesemua enam modul gagal dengan cara yang sama.
    """
    src = inspect.getsource(run_penuh.peringkat_selaras)
    kod = "\n".join(l.split("#", 1)[0] for l in src.splitlines())
    i_restart = kod.index("terminate_app(APP_PACKAGE)")
    i_menu = kod.index("open_menu_selaras()")
    assert i_restart < i_menu, "menu dibuka sebelum kembali ke skrin login"
    # Dan ia mesti log masuk semula selepas selesai.
    assert "pages.login.login(" in kod
    assert kod.index("pages.login.login(") > i_menu


def test_hamburger_hanya_pada_skrin_login_dalam_dump():
    """Sifat sebenar, bukan bacaan sumber — diuji terhadap dump."""
    utama = os.path.join(AKAR, "docs", "recon", "cetak-A-skrin-utama.xml")
    login = os.path.join(AKAR, "ui_dumps", "t010_skrin_utama.xml")
    for p in (utama, login):
        if not os.path.exists(p):
            pytest.skip("dump tiada")
    assert "\uf0c9" not in open(utama, encoding="utf-8").read()
    assert "\uf0c9" in open(login, encoding="utf-8").read()


def test_kredential_dari_test_credentials():
    """`PROFILE['akaun']` TIDAK wujud — profil menyimpan username dan
    password pada aras atas. Salah kunci di sini hanya akan kelihatan
    pada device, selepas selaras selesai."""
    src = inspect.getsource(run_penuh.peringkat_selaras)
    assert "TEST_CREDENTIALS" in src
    assert 'PROFILE["akaun"]' not in src


def test_skrin_dibersihkan_sebelum_setiap_peringkat():
    """`Unable to connect device` menyekat SETIAP ketukan selepasnya.
    Larian 2026-08-17 mati pada `Opening Daftar Kompaun` tiga kali."""
    src = inspect.getsource(run_penuh.main)
    kod = "\n".join(l.split("#", 1)[0] for l in src.splitlines())
    i_bersih = kod.index("bersihkan_skrin(drv, pages, f\"borang-{huruf}\")")
    i_jalan = kod.index("jalankan_satu(h, izin")
    assert i_bersih < i_jalan


def test_agregat_menu_tidak_berbohong():
    """Bug yang sama seperti `selaras LULUS` — tempat lain."""
    src = inspect.getsource(run_penuh.peringkat_menu)
    assert "if lulus == 0:" in src
    assert "raise RuntimeError" in src


def test_bersihkan_skrin_tidak_melontar():
    """Ia dipanggil sebelum setiap peringkat; kegagalannya tidak boleh
    membunuh larian."""
    src = inspect.getsource(run_penuh.bersihkan_skrin)
    assert "except Exception" in src
    assert "return False" in src


# ---------------------------------------------------------------------------
# Kad navigasi skrin utama — H-001..003 mesti boleh dicapai
# ---------------------------------------------------------------------------

def test_kad_hantar_skrin_utama_dibenarkan():
    """Kad `Hantar` pada skrin utama ialah NAVIGASI, bukan penghantaran.

    Tanpa ini H-001..003 mustahil: kad itu satu-satunya jalan masuk ke
    menu Hantar, dan ia mencetuskan trip-wire HANTAR.
    """
    from guard import dasar

    laluan = os.path.join(AKAR, "docs", "recon", "cetak-A-skrin-utama.xml")
    if not os.path.exists(laluan):
        pytest.skip("dump skrin utama tiada")
    src = open(laluan, encoding="utf-8").read()
    assert dasar.konteks_menu_utama(src) is True

    tetapan = dasar.Tetapan(dry_run=True, benarkan_serah=False,
                            izin_serah=False)
    kep = dasar.nilai(["Hantar"], tetapan, konteks_navigasi=True)
    assert kep.benarkan, kep.sebab
    assert kep.peraturan == "NAV-MENU-UTAMA"


def test_hantar_kekal_tripwire_di_luar_skrin_utama():
    """Pengecualian mesti terikat pada skrin utama SAHAJA."""
    from guard import dasar

    tetapan = dasar.Tetapan(dry_run=True, benarkan_serah=False,
                            izin_serah=False)
    kep = dasar.nilai(["Hantar"], tetapan, konteks_navigasi=False)
    assert not kep.benarkan
    assert kep.peraturan == "HANTAR"


def test_konteks_menu_utama_menolak_skrin_lain():
    """Borang, senarai, dan Notis Kompaun BUKAN skrin utama."""
    from guard import dasar

    for nama in ("k001-01-sebelum-mysikap.xml", "cetak-B-senarai.xml",
                 "nk-A-skrin-masuk.xml"):
        p = os.path.join(AKAR, "docs", "recon", nama)
        if not os.path.exists(p):
            continue
        assert dasar.konteks_menu_utama(
            open(p, encoding="utf-8").read()) is False, nama


def test_kad_navigasi_hanya_lima_label():
    """Senarai mesti kekal kecil — ia dibuka pada skrin yang tidak
    mempunyai sebarang kawalan penghantaran, tetapi meluaskannya
    memusnahkan sifat itu."""
    from guard import dasar

    assert len(dasar.KAD_NAVIGASI_UTAMA) == 5
    for teks in ("SERAH", "SAHKAN", "KEMASKINI", "CETAK", "PADAM",
                 "HANTAR SEMULA", "HANTAR DATA"):
        assert not any(c.match(teks) for c in dasar.KAD_NAVIGASI_UTAMA), teks


def test_cetak_ralat_selamat_encoding():
    """Mesej DryRunViolation membawa aksara kotak; konsol cp1252
    membangkitkan UnicodeEncodeError yang MENUTUPI ralat sebenar."""
    src = inspect.getsource(run_penuh.main)
    assert "UnicodeEncodeError" in src
    assert "backslashreplace" in src


def test_alert_disalir_selepas_semakan_printer():
    """Bila printer TIADA, semakan status meninggalkan dialog
    `Unable to connect device` terbuka, dan ia menyekat pembukaan
    borang.

    Menyalirkannya sebelum peringkat TIDAK memadai — relaunch + login
    dalam `jalankan_satu` membawanya kembali. Ia mesti disalir selepas
    semakan printer dan SEBELUM borang dibuka.
    """
    import inspect as _i
    from tools import run_e2e

    src = _i.getsource(run_e2e.jalankan_satu)
    kod = "\n".join(l.split("#", 1)[0] for l in src.splitlines())
    i_printer = kod.index("sahkan_printer_sedia(")
    i_salir = kod.index("dismiss_native_alerts(")
    i_borang = min(kod.index("open_notis_amaran()"),
                   kod.index("open_daftar_kompaun()"))
    assert i_printer < i_salir < i_borang


# ---------------------------------------------------------------------------
# Bootstrap selepas pemasangan APK bersih (2.1.23, 2026-08-18)
# ---------------------------------------------------------------------------

def test_bootstrap_hanya_bila_ip_benar_benar_tiada():
    """Pemasangan bersih memadam SEMUA data app — `local_connection_
    details` kosong, jadi app tidak boleh capai server.

    Nilai betul ada dalam profil (pemilik sahkan 2026-08-18: IP dan
    lesen tidak berubah, hanya versi APK), jadi automasi memulihkannya.

    Tetapi kalau IP WUJUD dan bukan production, itu keadaan berbeza
    sepenuhnya — gerbang asal (PAPAN §4) mesti kekal berhenti.
    """
    src = inspect.getsource(run_penuh.main)
    kod = chr(10).join(l.split("#", 1)[0] for l in src.splitlines())
    assert "ip_peranti_kosong(serial)" in kod
    i_semak = kod.index("ip_peranti_kosong(serial)")
    i_boot = kod.index("bootstrap_tetapan(")
    assert i_semak < i_boot, "bootstrap dijalankan sebelum semakan"
    # Laluan "IP wujud tetapi salah" mesti kekal BERHENTI.
    assert "pembetulan manual diperlukan" in src


def test_bootstrap_baca_nilai_dari_profil_bukan_meneka():
    src = inspect.getsource(run_penuh.bootstrap_tetapan)
    assert "PROFILE" in src
    for kunci in ("internal_ip", "external_ip", "lesen_aplikasi"):
        assert kunci in src, kunci
    # Lesen TIDAK dicetak ke terminal.
    assert "tidak dicetak" in src


def test_ip_kosong_dibezakan_daripada_ip_salah():
    """`ip_peranti_kosong` mesti pulang True HANYA bila tiada baris —
    bukan bila ada baris dengan nilai lain."""
    src = inspect.getsource(run_penuh.ip_peranti_kosong)
    assert "return not baris" in src
    # Gagal-tertutup: ralat baca => bukan bootstrap.
    assert "return False" in src


def test_bootstrap_selepas_gagal_disemak_semula():
    """Bootstrap yang tidak berjaya tidak boleh diluluskan senyap."""
    src = inspect.getsource(run_penuh.main)
    assert "IP masih tidak betul selepas bootstrap" in src


# ---------------------------------------------------------------------------
# Kaedah dinamik — IP + lesen ditanya di awal (cadangan pemilik 2026-08-18)
# ---------------------------------------------------------------------------

def test_tetapan_ditanya_sebelum_menyentuh_peranti():
    """Nilai mesti diminta SEBELUM pengesahan YA, supaya apa yang akan
    DITULIS kelihatan sebelum ia ditulis."""
    src = inspect.getsource(run_penuh.main)
    kod = chr(10).join(l.split("#", 1)[0] for l in src.splitlines())
    i_tanya = kod.index("minta_tetapan(args)")
    i_ya = kod.index("minta_ya(")
    i_p1 = kod.index("peringkat_1(serial)")
    assert i_tanya < i_ya < i_p1


def test_profil_kekal_sebagai_lalai():
    """Tekan Enter = terima profil. Kes biasa satu ketukan."""
    src = inspect.getsource(run_penuh.minta_tetapan)
    assert 'PROFILE.get("external_ip")' in src
    assert 'PROFILE.get("lesen_aplikasi")' in src
    assert "or ip_lalai" in src and "or lesen_lalai" in src


def test_larian_tanpa_terminal_tidak_tergantung_pada_prompt():
    """`--terus` dan larian tanpa TTY mesti guna profil/flag, bukan
    tersekat menunggu input yang takkan datang."""
    src = inspect.getsource(run_penuh.minta_tetapan)
    assert "sys.stdin.isatty()" in src
    assert "not args.terus" in src


def test_ip_berbeza_diberi_amaran():
    """IP lain daripada profil bermakna TUKAR SASARAN, bukan pulihkan
    tetapan. Gerbang peringkat 1 akan menghentikannya — amaran ini
    menjadikannya jelas sebelum masa, bukan selepas 2 minit."""
    src = inspect.getsource(run_penuh.minta_tetapan)
    assert "menukar SASARAN" in src
    assert "ip != ip_lalai" in src


def test_lesen_tidak_dicetak_penuh():
    """Nombor lesen ialah token portal PBT. Ia tidak sepatutnya masuk
    log terminal atau tangkapan skrin secara penuh."""
    main_src = inspect.getsource(run_penuh.main)
    assert 'lesen_pilihan[-4:]' in main_src
    tanya_src = inspect.getsource(run_penuh.minta_tetapan)
    assert 'lesen_lalai[:4]' in tanya_src


def test_nilai_dimasukkan_mengatasi_profil():
    """Yang ditaip pemilik MESTI digunakan, bukan diabaikan diam-diam."""
    src = inspect.getsource(run_penuh.bootstrap_tetapan)
    assert "ip or PROFILE.get" in src
    assert "lesen or PROFILE.get" in src


# ---------------------------------------------------------------------------
# D-09 — tiga plat mySIKAP, satu sesi (pemilik 2026-08-18)
# ---------------------------------------------------------------------------

def test_tiga_plat_dibekalkan_pemilik():
    assert run_penuh.PLAT_MYSIKAP == ("JYX6605", "JUA3276", "JRT2649")


def test_plat_mesti_berbeza():
    """Plat serupa menjadikan D-09(b) mustahil dilihat: dua kompaun
    untuk kenderaan sama SEPATUTNYA menamakan orang sama."""
    assert len(set(run_penuh.PLAT_MYSIKAP)) == len(run_penuh.PLAT_MYSIKAP)


def test_k_diulang_bagi_setiap_plat():
    src = inspect.getsource(run_penuh.main)
    kod = chr(10).join(l.split("#", 1)[0] for l in src.splitlines())
    assert "for i, pl in enumerate(plat_k" in kod
    assert "plat=p" in kod


def test_borang_lain_tidak_diulang():
    """N dan P tiada kaitan dengan mySIKAP; mengulanginya hanya mencipta
    rekod production tambahan tanpa sebab."""
    src = inspect.getsource(run_penuh.main)
    kod = chr(10).join(l.split("#", 1)[0] for l in src.splitlines())
    assert 'if huruf != "K":' in kod


def test_semak_d09_berjalan_selepas_rekod_k():
    src = inspect.getsource(run_penuh.main)
    kod = chr(10).join(l.split("#", 1)[0] for l in src.splitlines())
    i_k = kod.index("plat=p")
    i_semak = kod.index("semak D-09")
    assert i_k < i_semak


def test_semak_d09_mengambil_nombor_dari_log_bukan_pulangan_peringkat():
    """`jalankan()` memulangkan bool, jadi nombor rekod MESTI datang
    dari log — yang ditulis dengan fsync sebaik nombor wujud."""
    src = inspect.getsource(run_penuh.semak_d09)
    assert "rekod_log.baca_semua" in src
    assert 'd.get("borang") == "K"' in src


def test_semak_d09_membangkitkan_bila_dapatan_wujud():
    src = inspect.getsource(run_penuh.semak_d09)
    assert "raise RuntimeError" in src
    assert "D-09 MASIH ADA" in src


def test_tiada_rekod_membangkitkan_bukan_memulangkan():
    """Dahulu ia MEMULANGKAN nota — yang `jalankan` catat sebagai LULUS.
    Membangkitkan D09TidakDiuji menjadikan keadaan itu mustahil untuk
    disalah baca sebagai lulus. Skop penuh: test_semak_d09_skop.py."""
    src = inspect.getsource(run_penuh.semak_d09)
    assert "raise D09TidakDiuji" in src
    assert "TIDAK DIUJI" in src


# ---------------------------------------------------------------------------
# NK — jurang dilaporkan, bukan didiamkan
# ---------------------------------------------------------------------------

def test_kelayakan_nk_dilaporkan_dalam_peringkat_menu():
    src = inspect.getsource(run_penuh.peringkat_menu)
    assert "lapor_kelayakan_nk(serial)" in src


def test_lapor_nk_tidak_boleh_menggagalkan_larian():
    """Sekatan ini milik APP. Melaporkannya sebagai kegagalan ujian
    akan salah menuduh, dan menghentikan larian yang sah."""
    src = inspect.getsource(run_penuh.lapor_kelayakan_nk)
    assert "raise" not in src


def test_lapor_nk_menyatakan_ia_tidak_diuji_bukan_lulus():
    src = inspect.getsource(run_penuh.lapor_kelayakan_nk)
    assert "KEKAL TIDAK DIUJI" in src


def test_lapor_nk_menyebut_d07_bila_notis_sudah_layak():
    """Bila notis LAYAK, bahaya bertukar: membuka borang membakar
    nombor siri walaupun tiada serahan."""
    src = inspect.getsource(run_penuh.lapor_kelayakan_nk)
    assert "D-07" in src


def test_skrin_notis_kompaun_dicover_melalui_tarik():
    """Menu Notis Kompaun BUKAN tidak tersentuh — `peringkat_tarik`
    masuk melaluinya. Yang tiada hanyalah penukaran."""
    from tools import run_e2e_menu
    src = inspect.getsource(run_e2e_menu.peringkat_tarik)
    assert "open_notis_kompaun()" in src


# ---------------------------------------------------------------------------
# H-001/002/003 — peringkat hantar tidak boleh lulus tanpa menguji
# ---------------------------------------------------------------------------

def test_hantar_membaca_statushantar_bukan_kiraan_baris():
    """Pepijat asal: `kira_rekod()` memulangkan integer, ditapis dengan
    `v == "M"`. Integer tidak pernah sama dengan huruf, jadi cabang
    'semua sudah dihantar' diambil pada SETIAP larian."""
    from tools import run_e2e_menu
    src = inspect.getsource(run_e2e_menu.peringkat_hantar)
    assert "status_hantar(ko[\"db_hantar\"]())" in src
    assert "ko[\"db_status\"]()" not in src


def test_tiada_rekod_gagal_auto_pass_dengan_laluan_ui():
    """DASAR DIKEMAS KINI — keputusan CEO 2026-08-19.

    Dasar lama: tiada rekod M -> TIDAK DIUJI (lulus None), UI tidak
    disentuh. Dasar baharu: tiada rekod M -> AUTO-PASS, dengan SYARAT
    skrip benar-benar memandu laluan UI (tab Data Ralat dibuka, butang
    HANTAR SEMULA dicuba, respons direkod). Ujian ini mengunci syarat
    itu supaya auto-pass tidak boleh runtuh menjadi 'lulus tanpa buat
    apa-apa'."""
    from tools import run_e2e_menu
    src = inspect.getsource(run_e2e_menu.peringkat_hantar)
    assert "auto-pass" in src
    assert "dicuba_ui" in src
    assert "switch_to_data_ralat_tab" in src
    # lulus mesti BERSYARAT pada laluan UI, bukan literal True.
    assert '"lulus": lulus_ui' in src


def test_ringkas_hantar_memisahkan_tiga_tc():
    from tools.run_e2e_menu import ringkas_hantar
    status = {"PGP02N260817008": ("N", "H"),
              "PGP02P260818003": ("P", "M"),
              "PGP02K260818008": ("K", "H")}
    r = ringkas_hantar(status)
    assert set(r) == {"H-001", "H-002", "H-003"}
    assert r["H-002"]["belum_naik"] == ["PGP02P260818003"]
    assert r["H-001"]["belum_naik"] == []


def test_borang_dikenal_dari_huruf_keenam():
    from tools.run_e2e_menu import ringkas_hantar
    r = ringkas_hantar({"PGP02K260818008": ("K", "M")})
    assert r["H-003"]["jumlah"] == 1 and r["H-001"]["jumlah"] == 0


def test_run_penuh_membekalkan_db_hantar():
    src = inspect.getsource(run_penuh.peringkat_menu)
    assert '"db_hantar": db_hantar' in src


# ---------------------------------------------------------------------------
# Verdik akhir — pemilik menjalankan ini SENDIRI, tanpa Claude membaca skrol
# ---------------------------------------------------------------------------

def _jejak(baris):
    j = run_penuh.Jejak()
    for nama, status, nota in baris:
        j.baris.append({"peringkat": nama, "status": status, "nota": nota,
                        "tempoh_s": 1.0, "masa": "09:00:00"})
    return j


def test_kod_keluar_bukan_sifar_bila_peringkat_gagal():
    """`return 0` tanpa syarat bermakna larian yang mendapati D-09 masih
    rosak keluar dengan status BERJAYA."""
    src = inspect.getsource(run_penuh.main)
    assert "return 1 if jejak.gagal() else 0" in src


def test_gagal_mengira_hanya_peringkat_gagal():
    j = _jejak([("selaras", "GAGAL", ""), ("borang N", "LULUS", ""),
                ("cetak", "SKIP", "")])
    assert [b["peringkat"] for b in j.gagal()] == ["selaras"]


def test_verdik_menamakan_d09_rosak(capsys):
    j = _jejak([("semak D-09", "GAGAL", "D-09 MASIH ADA")])
    j.papar_verdik()
    keluar = capsys.readouterr().out
    assert "MASIH ROSAK" in keluar
    assert "Batalkan kesemuanya" in keluar


def test_verdik_menamakan_d09_bersih(capsys):
    j = _jejak([("semak D-09", "LULUS", "3 rekod K bersih")])
    j.papar_verdik()
    assert "BERSIH pada build ini" in capsys.readouterr().out


def test_verdik_tanpa_rekod_k_bukan_lulus(capsys):
    """Tiada peringkat semak D-09 langsung bermakna tiada rekod K
    dicipta — itu TIDAK DIUJI, bukan bersih."""
    j = _jejak([("borang N", "LULUS", "")])
    j.papar_verdik()
    keluar = capsys.readouterr().out
    assert "TIDAK DIUJI" in keluar
    assert "BERSIH" not in keluar


def test_verdik_dicetak_selepas_jadual_masa():
    """Traceback D-09 bergulir hilang semasa ~20 minit peringkat menu."""
    src = inspect.getsource(run_penuh.Jejak.papar)
    assert "self.papar_verdik()" in src
    assert src.index("JUMLAH SESI") < src.index("papar_verdik")


def test_verdik_membezakan_defek_dijangka(capsys):
    """D-08/D-01 gagal pada hampir setiap larian. Tanpa baris ini,
    pemilik tidak dapat membezakan bunyi latar daripada jawapan."""
    j = _jejak([("selaras", "GAGAL", "T-005 ranap")])
    j.papar_verdik()
    assert "DIJANGKA" in capsys.readouterr().out


# --- FIX#20: log ke fail untuk larian tanpa pengawasan ---
def test_log_fail_dipasang_awal_dalam_main():
    """Pemilik meninggalkan larian dan TIDAK berada di hadapan terminal
    bila ia tamat. Kalau log hanya dipasang lewat, semua yang berlaku
    sebelum itu — gerbang siri, sesi, izin — hilang dari fail dan
    diagnosis perlu dibuat daripada ingatan, bukan bukti."""
    src = inspect.getsource(run_penuh.main)
    kod = chr(10).join(l.split("#", 1)[0] for l in src.splitlines())
    assert "pasang_log_fail()" in kod
    assert kod.index("pasang_log_fail()") < kod.index(
        "semak_siri.gerbang(serial, baiki=True)")


def test_log_fail_menggantikan_stdout_supaya_modul_lain_ditangkap():
    """Output daripada pages/, devtools/ dan guard/ mesti masuk log juga.
    Membungkus hanya `print` dalam modul ini akan meninggalkan traceback
    uiautomator dan mesej corong di luar fail."""
    src = inspect.getsource(run_penuh.pasang_log_fail)
    kod = chr(10).join(l.split("#", 1)[0] for l in src.splitlines())
    assert "sys.stdout = tee" in kod
    assert "sys.stderr = tee" in kod


def test_excepthook_dipasang_supaya_traceback_masuk_log():
    """Larian yang mati dengan pengecualian ialah kes yang PALING perlu
    dibaca, dan traceback ditulis oleh sys.excepthook — bukan oleh tee.
    Tanpa hook ini log berakhir dengan 'kod_keluar: 1' dan tiada sebab."""
    src = inspect.getsource(run_penuh.pasang_log_fail)
    kod = chr(10).join(l.split("#", 1)[0] for l in src.splitlines())
    assert "sys.excepthook = _hook" in kod
    assert "traceback.format_exception" in kod


def test_ringkasan_json_mesti_ditulis_walaupun_larian_mati():
    """Ringkasan ditulis oleh atexit, bukan hanya pada laluan gembira.
    Kalau ia bergantung pada `main` pulang normal, larian yang mati
    (DryRunViolation, Ctrl-C, USB tercabut) tidak meninggalkan ringkasan
    dan pemilik terpaksa membaca 1400 baris log mentah."""
    src = inspect.getsource(run_penuh.pasang_log_fail)
    assert "atexit.register(_pada_keluar)" in src
    assert "akhiri_log" in inspect.getsource(run_penuh)
    assert "_LOG_RALAT" in inspect.getsource(run_penuh._pada_keluar)


def test_ringkasan_menyatakan_kod_keluar_dan_sebab_berhenti():
    """Larian mati dan larian bersih dengan 0 GAGAL kelihatan SAMA kalau
    ringkasan hanya membawa kiraan. Pemilik tidak menonton, jadi
    ringkasan mesti menjawab 'apa yang berlaku' dengan sendirinya."""
    src = inspect.getsource(run_penuh.tulis_ringkasan_json)
    assert '"kod_keluar"' in src
    assert '"berhenti_awal"' in src


def test_log_tidak_ditulis_ke_root_reports():
    """`reports/log/` diabaikan git; corak `reports/*.log` sahaja PERNAH
    terlepas (2026-08-11) dan log larian dipentaskan untuk commit —
    membawa token lesen dalam kepala dan data pesalah dari borang."""
    src = inspect.getsource(run_penuh.pasang_log_fail)
    kod = chr(10).join(l.split("#", 1)[0] for l in src.splitlines())
    assert '"reports", "log"' in kod


# --- FIX#24: induk tidak boleh LULUS dengan anak GAGAL ---
def test_induk_gagal_bila_anak_gagal():
    """Run 20261009-141246 mencetak `borang P: LULUS` sedangkan
    kemaskini beku 0%, hantar StaleElement dan senarai tidak menjumpai
    rekod — pemilik nampak sendiri dengan mata. `kitaran_lanjutan`
    menelan kegagalan anak dengan senyap, jadi `fn()` pulang normal dan
    `jalankan()` mencatat LULUS.

    Induk MESTI ditandakan GAGAL-BERSEBASTIAN, bukan LULUS."""
    j = run_penuh.Jejak()
    konteks = {"jejak": []}

    def fn():
        konteks["jejak"].append(
            {"peringkat": "kemaskini", "status": "GAGAL",
             "nota": "popup beku 0%", "tempoh_s": 320.8})
        konteks["jejak"].append(
            {"peringkat": "hantar", "status": "GAGAL",
             "nota": "StaleElement", "tempoh_s": 590.5})
        return "PGP02P261009027"

    run_penuh.jalankan(j, "borang P", fn, konteks=konteks)
    baris = {b["peringkat"]: b["status"] for b in j.baris}
    assert baris["borang P"] == "GAGAL-BERSEBASTIAN"
    # Anak mesti sampai ke jejak utama supaya ringkasan JSON melihatnya.
    assert len(j.anak) == 2
    assert all(a["induk"] == "borang P" for a in j.anak)


def test_induk_lulus_bila_semua_anak_lulus():
    """Jangan pula fix ini melaporkan GAGAL palsu pada larian bersih."""
    j = run_penuh.Jejak()
    konteks = {"jejak": []}

    def fn():
        konteks["jejak"].append({"peringkat": "kemaskini", "status": "LULUS",
                                 "nota": "", "tempoh_s": 246.3})
        konteks["jejak"].append({"peringkat": "hantar", "status": "LULUS",
                                 "nota": "", "tempoh_s": 216.3})
        return "PGP02N261009011"

    run_penuh.jalankan(j, "borang N", fn, konteks=konteks)
    assert j.baris[0]["status"] == "LULUS"
    assert j.anak and all(a["status"] == "LULUS" for a in j.anak)


def test_gagal_bersebastian_dikira_sebagai_kegagalan():
    """Kalau tidak, larian yang berbohong tetap keluar dengan kod 0."""
    j = run_penuh.Jejak()
    j.baris.append({"peringkat": "borang P", "status": "GAGAL-BERSEBASTIAN",
                    "nota": "", "tempoh_s": 1.0, "masa": "10:00:00"})
    assert [b["peringkat"] for b in j.gagal()] == ["borang P"]


def test_sub_peringkat_tidak_hilang_dalam_ringkasan_json():
    """Anak hanya hidup dalam `jejak.anak`; `tulis_ringkasan_json`
    membaca `jejak.baris`. Tanpa pemindahan, dashboard mewarisi
    pembohongan terminal."""
    src = inspect.getsource(run_penuh.tulis_ringkasan_json)
    assert '"anak"' in src
    assert "anak_gagal" in src
    # Kiraan induk KEKAL, supaya kontrak dashboard lama tidak pecah.
    assert '"peringkat": len(induk_baris)' in src


def test_peringkat_menu_gagal_satu_pun_angkat():
    """Kelas bug sama seperti `selaras LULUS`: 2 lulus/1 gagal dahulu
    memulangkan rentetan biasa → induk mencatat LULUS."""
    src = inspect.getsource(run_penuh.peringkat_menu)
    assert "if gagal:" in src
    assert "raise RuntimeError" in src

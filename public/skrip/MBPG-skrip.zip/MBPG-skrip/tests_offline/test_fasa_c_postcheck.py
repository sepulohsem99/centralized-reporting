"""
Gerbang untuk post-check selepas serah.

Bentuk yang diuji di sini DIUKUR dari serah sebenar pertama
(PGP02N260813006, 2026-08-13), bukan diandaikan.
"""

import os
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from devtools.fasa_c import PostCheckGagal, semak_satu_rekod   # noqa: E402

NOTIS = "local_ekpn_notis_amaran"

# Bentuk SEBENAR satu serah notis, dibaca dari DB peranti.
SEBELUM = {NOTIS: 0, "local_ekpn_notis_amaran_details": 5,
           "local_ekpn_tawaran_kompaun_doc": 0,
           "local_ekpn_penerima_cetakan": 0,
           "local_ekpn_tawaran_kompaun": 0}
SELEPAS = {NOTIS: 1, "local_ekpn_notis_amaran_details": 6,
           "local_ekpn_tawaran_kompaun_doc": 4,
           "local_ekpn_penerima_cetakan": 1,
           "local_ekpn_tawaran_kompaun": 0}


def test_bentuk_serah_sebenar_diterima():
    """Satu notis menulis 1 rekod + 1 details + 4 doc gambar + 1
    penerima_cetakan. Versi pertama semakan ini menolak bentuk itu dan
    menghentikan run SELEPAS rekod dicipta -- tepat sebelum cetakan."""
    assert semak_satu_rekod(SEBELUM, SELEPAS, NOTIS) is True


def test_jadual_utama_tidak_bertambah_tetap_gagal():
    s = dict(SELEPAS, **{NOTIS: 0})
    with pytest.raises(PostCheckGagal, match="TIADA rekod baharu"):
        semak_satu_rekod(SEBELUM, s, NOTIS)


def test_dua_rekod_utama_tetap_gagal():
    s = dict(SELEPAS, **{NOTIS: 2})
    with pytest.raises(PostCheckGagal, match="dijangka TEPAT 1"):
        semak_satu_rekod(SEBELUM, s, NOTIS)


def test_jadual_luar_senarai_iringan_tetap_gagal():
    """Kompaun bertambah semasa menyerah NOTIS ialah anomali sebenar."""
    s = dict(SELEPAS, **{"local_ekpn_tawaran_kompaun": 1})
    with pytest.raises(PostCheckGagal, match="TIDAK DIJANGKA"):
        semak_satu_rekod(SEBELUM, s, NOTIS)


def test_jadual_iringan_BERKURANG_tetap_gagal():
    """Iringan dibenarkan bertambah sahaja. Baris yang HILANG bermakna
    sesuatu memadam, dan itu tidak pernah dijangka."""
    s = dict(SELEPAS, **{"local_ekpn_notis_amaran_details": 3})
    with pytest.raises(PostCheckGagal, match="TIDAK DIJANGKA"):
        semak_satu_rekod(SEBELUM, s, NOTIS)


# ===========================================================================
# KUOTA BERKEKALAN — dikira dari ledger, bukan dari kaunter dalam-proses
# ===========================================================================
def test_kiraan_ledger_membilang_ikut_borang(tmp_path):
    import json
    from devtools.fasa_c import kiraan_borang_dari_ledger
    led = tmp_path / "l.jsonl"
    led.write_text("\n".join(json.dumps(e) for e in [
        {"peristiwa": "dialog-serah", "set_id": "C1-N-001"},
        {"peristiwa": "rekod-dicipta", "set_id": "C1-N-001",
         "no_rekod": "PGP02N260813006"},
        {"peristiwa": "cetak-dicuba", "set_id": "C1-N-001"},
        {"peristiwa": "rekod-dicipta", "set_id": "C2-P-001",
         "no_rekod": "PGP02P260813001"},
    ]) + "\n", encoding="utf-8")
    assert kiraan_borang_dari_ledger("N", str(led)) == 1
    assert kiraan_borang_dari_ledger("P", str(led)) == 1
    assert kiraan_borang_dari_ledger("K", str(led)) == 0


def test_kiraan_ledger_hanya_kira_rekod_dicipta(tmp_path):
    """dialog-serah dan cetak-dicuba BUKAN rekod. Mengiranya akan
    menghabiskan kuota tanpa satu rekod pun wujud."""
    import json
    from devtools.fasa_c import kiraan_borang_dari_ledger
    led = tmp_path / "l.jsonl"
    led.write_text("\n".join(json.dumps(e) for e in [
        {"peristiwa": "dialog-serah", "set_id": "C1-N-001"},
        {"peristiwa": "cetak-dicuba", "set_id": "C1-N-001"},
        {"peristiwa": "siri-yatim", "no_siri": 5},
    ]) + "\n", encoding="utf-8")
    assert kiraan_borang_dari_ledger("N", str(led)) == 0


def test_kiraan_ledger_tiada_fail_ialah_sifar(tmp_path):
    from devtools.fasa_c import kiraan_borang_dari_ledger
    assert kiraan_borang_dari_ledger("N", str(tmp_path / "tiada")) == 0


def test_kiraan_ledger_abai_baris_rosak(tmp_path):
    """Satu baris separa (proses mati semasa menulis) tidak boleh
    menjadikan seluruh kiraan kuota sifar."""
    from devtools.fasa_c import kiraan_borang_dari_ledger
    led = tmp_path / "l.jsonl"
    led.write_text('{"peristiwa":"rekod-dicipta","set_id":"C1-N-001"}\n'
                   '{"peristiwa":"rekod-dic\n', encoding="utf-8")
    assert kiraan_borang_dari_ledger("N", str(led)) == 1


def test_kuota_habis_menyekat_larian_kedua():
    """Sifat yang sebenarnya penting: selepas satu rekod N, larian
    BAHARU tidak boleh mencipta yang kedua."""
    import datetime
    from guard.gerbang_serah import Izin, SerahTidakDiizinkan, semak
    izin = Izin(dry_run_mati=True, token="T",
                medan={"disahkan_oleh": "x", "rujukan_kelulusan": "y"},
                whitelist=("C1-N-001",), had=3,
                sah_sehingga=datetime.date.today().isoformat(),
                borang=("N", "P", "K"), kuota={"N": 1, "P": 1, "K": 1})
    assert semak(izin, "C1-N-001", 0, borang="N", kiraan_borang=0) is True
    with pytest.raises(SerahTidakDiizinkan, match="LAPISAN 6"):
        semak(izin, "C1-N-001", 1, borang="N", kiraan_borang=1)


# ===========================================================================
# JARING PII — kecualikan nilai yang KITA taip
# ===========================================================================
# Nama diambil dari ORACLE, bukan disalin ke sini. Menyalinnya menambah
# satu lagi salinan data berbentuk PII ke dalam repo, dan pengimbas
# menandakannya -- betul-betul.
def _nama_oracle_k():
    from testdata import oracle_pk
    return oracle_pk.K001["nama_pesalah"]


def test_jaring_pii_tidak_menanda_data_oracle_sendiri():
    """Nama oracle K-001 berbentuk PII (mengandungi penghubung
    keturunan). Jaring
    yang menandanya akan membatalkan rekod K atas data ujian kita
    sendiri, dan amaran palsu yang menghalang kerja sah akan
    diabaikan."""
    from devtools.imbas_pii import imbas_teks
    nama = _nama_oracle_k()
    padanan = [j[1] for j in imbas_teks(nama) if j[0] == "nama_bin_binti"]
    assert padanan, "andaian ujian salah: nama oracle sepatutnya berbentuk PII"
    # Corak memadan SERPIHAN, bukan rentetan penuh -- itulah sebabnya
    # semakan kesamaan tepat tidak memadai.
    assert padanan[0].upper() != nama.upper()
    milik = {nama.upper()}
    tinggal = [p for p in padanan
               if not any(p.upper() in v for v in milik)]
    assert tinggal == []


def test_jaring_pii_masih_menanda_nama_dari_lookup():
    """Nama yang MUNCUL tanpa kita menaipnya kekal ditanda — itu
    bermakna satu lookup berlaku."""
    from devtools.imbas_pii import imbas_teks
    milik = {_nama_oracle_k().upper()}
    # Dibina dari bahagian, bukan ditulis sebagai satu rentetan:
    # rentetan berbentuk PII dalam kod sumber akan ditanda oleh
    # pengimbas -- betul-betul -- dan melonggarkan pengimbas untuk
    # meredakan ujiannya sendiri ialah cara alat itu mati.
    teks = " ".join(["SESEORANG", "BINTI", "LAIN"])
    tinggal = [j[1] for j in imbas_teks(teks)
               if j[0] == "nama_bin_binti"
               and not any(j[1].upper() in v for v in milik)]
    assert tinggal, "nama dari lookup mesti kekal ditanda"


# ===========================================================================
# TUNGGU MUAT NAIK sebelum membaca DB
# ===========================================================================
def test_penunjuk_muat_naik_dikenali():
    """Larian pemilik memulangkan no_rekod=None kerana DB dibaca semasa
    skrin masih 'MEMUAT NAIK GAMBAR... 70%'. Baris rekod belum ditulis
    pada ketika itu, jadi nombor HILANG walaupun rekod wujud."""
    from devtools.fasa_c import MUAT_NAIK
    for t in ("MEMUAT NAIK GAMBAR...", "70%", "100%", "Uploading"):
        assert MUAT_NAIK.search(t), t
    for t in ("SEMUA DATA BERJAYA DIHANTAR", "CETAK", "IES 2.1"):
        assert not MUAT_NAIK.search(t), t


def test_nombor_dari_popup_cetak():
    """Sandaran bila DB masih belum menulis nombornya."""
    from devtools.fasa_c import _nombor_dari_popup
    assert _nombor_dari_popup(
        ["X", "CETAK NOTIS AMARAN ?", "No Notis: PGP02N260813007",
         "CETAK"]) == "PGP02N260813007"
    assert _nombor_dari_popup(
        ["No Kompaun: PGP02P260813001"]) == "PGP02P260813001"
    assert _nombor_dari_popup(["SEMUA DATA BERJAYA DIHANTAR"]) is None


def test_tunggu_muat_naik_menunggu_sehingga_bersih(monkeypatch):
    """Peratusan boleh melompat 100% seketika di tengah jalan, jadi
    'bersih' mesti bertahan beberapa saat sebelum dipercayai."""
    from devtools import fasa_c as FC
    skrin = [["MEMUAT NAIK GAMBAR...", "20%"],
             ["MEMUAT NAIK GAMBAR...", "70%"],
             ["SEMUA DATA BERJAYA DIHANTAR"],
             ["SEMUA DATA BERJAYA DIHANTAR"],
             ["SEMUA DATA BERJAYA DIHANTAR"]]
    langkah = {"i": 0}

    def teks_palsu(_drv):
        i = min(langkah["i"], len(skrin) - 1)
        langkah["i"] += 1
        return skrin[i]

    jam = {"t": 0.0}
    monkeypatch.setattr(FC, "_teks_skrin", teks_palsu)
    monkeypatch.setattr(FC.time, "sleep", lambda s: jam.__setitem__("t", jam["t"] + s))
    monkeypatch.setattr(FC.time, "time", lambda: jam["t"])
    hasil = FC._tunggu_muat_naik(None, saat=120, senyap=4)
    assert "SEMUA DATA BERJAYA DIHANTAR" in hasil
    assert langkah["i"] >= 4, "mesti terus membaca sehingga senyap cukup"

"""
Gerbang untuk modul CETAK / PRINTER MBPG.

Modul ini kecil dengan sengaja: recon menunjukkan popup printer MBPG
ialah paparan STATUS, bukan pemilih peranti seperti MBJB. Ujian di sini
menjaga dua perkara:

  ia MEMBACA status yang app tulis, bukan mengagak warna piksel
  ia MENOLAK untuk meneka laluan CETAK yang belum pernah dilihat
"""

import os
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from pages.cetak_page import CetakPage, PrinterTidakSedia      # noqa: E402


class Palsu(CetakPage):
    """CetakPage tanpa driver, dengan teks skrin yang disuntik."""

    def __init__(self, teks):
        self._teks = list(teks)

    def _teks_skrin(self):
        return self._teks


POPUP_SEBENAR = [
    "Kompaun e-PBT", "Notis Amaran", "Daftar Kompaun", "Senarai",
    "Bluetooth Active",
    "Printer connected to the application:",
    "SPP-R410_110095",
    "74:F0:7D:A9:88:75",
]


def test_baca_status_dari_popup_sebenar():
    """Teks TEPAT yang dirakam dari peranti, 2026-08-13."""
    s = Palsu(POPUP_SEBENAR).baca_status_printer()
    assert s["bluetooth"] is True
    assert s["tersambung"] is True
    assert s["nama"] == "SPP-R410_110095"
    assert s["mac"] == "74:F0:7D:A9:88:75"


def test_bluetooth_mati_dikesan():
    s = Palsu(["Bluetooth Inactive", "Kompaun e-PBT"]).baca_status_printer()
    assert s["bluetooth"] is False
    assert s["tersambung"] is False


def test_popup_tanpa_printer_tidak_mendakwa_tersambung():
    s = Palsu(["Bluetooth Active", "No printer"]).baca_status_printer()
    assert s["bluetooth"] is True
    assert s["tersambung"] is False
    assert s["nama"] is None


def test_teks_skrin_utama_sahaja_bukan_status_printer():
    """Skrin utama tanpa popup TIDAK boleh dibaca sebagai tersambung."""
    s = Palsu(["Kompaun e-PBT", "Notis Amaran", "Senarai",
               "Hantar"]).baca_status_printer()
    assert s["bluetooth"] is False and s["tersambung"] is False


@pytest.mark.parametrize("nama", ["SPP-R410_110095", "TSC-TTP_2010",
                                  "Bixolon-R410_1"])
def test_nama_printer_dikenali(nama):
    assert Palsu(["Bluetooth Active", nama]).baca_status_printer()["nama"] \
        == nama


@pytest.mark.parametrize("bukan", ["Kompaun e-PBT", "Notis Amaran",
                                   "2026-08-13", "SEMAK", "SEMUA"])
def test_teks_biasa_bukan_nama_printer(bukan):
    """Kalau teks UI biasa dibaca sebagai nama printer, laporan akan
    mendakwa printer wujud sedangkan tidak."""
    assert Palsu(["Bluetooth Active", bukan]).baca_status_printer()["nama"] \
        is None


def test_cetak_rekod_menolak_untuk_meneka():
    """Butang CETAK belum pernah dilihat. Modul mesti berkata begitu,
    bukan meneka locator dan gagal secara mengelirukan kemudian."""
    with pytest.raises(PrinterTidakSedia, match="belum diport"):
        Palsu([]).cetak_rekod("PGP02N260813001")


def test_penolakan_ialah_BaseException():
    """66 blok `except Exception` dalam base_page akan menelannya."""
    assert issubclass(PrinterTidakSedia, BaseException)
    assert not issubclass(PrinterTidakSedia, Exception)


def test_glif_printer_titik_kod_betul():
    """U+F042A, disahkan identik antara MBJB, MBPG, dan peranti."""
    assert CetakPage.GLIF_PRINTER == "\U000f042a"
    assert len(CetakPage.GLIF_PRINTER) == 1
    assert CetakPage.GLIF_PRINTER in CetakPage.IKON_PRINTER[1]


def test_status_dari_skrin_salah_ditanda_TIDAK_SAH():
    """Membaca status printer pada skrin yang bukan popup status
    memulangkan False/False, yang kelihatan sama seperti 'printer
    terputus'. Bendera `sah` membezakan 'terputus' daripada 'saya
    melihat tempat yang salah'."""
    s = Palsu(["Kompaun e-PBT", "CETAK NOTIS AMARAN ?",
               "No Notis: PGP02N260813006", "CETAK"]).baca_status_printer()
    assert s["sah"] is False
    assert s["bluetooth"] is False


def test_status_dari_popup_betul_ditanda_SAH():
    assert Palsu(POPUP_SEBENAR).baca_status_printer()["sah"] is True


def test_popup_cetak_rekod_salah_ditolak():
    """Menekan CETAK pada popup rekod yang salah mencetak rekod yang
    salah, dan kertas tidak boleh ditarik balik."""
    p = Palsu(["CETAK NOTIS AMARAN ?", "No Notis: PGP02N260813099"])
    p.is_element_present = lambda *a, **k: True
    with pytest.raises(PrinterTidakSedia, match="ENGGAN"):
        p.popup_cetak_terbuka("PGP02N260813006")


def test_popup_cetak_rekod_padan_diterima():
    p = Palsu(["CETAK NOTIS AMARAN ?", "No Notis: PGP02N260813006"])
    p.is_element_present = lambda *a, **k: True
    terbuka, no = p.popup_cetak_terbuka("PGP02N260813006")
    assert terbuka is True and no == "PGP02N260813006"

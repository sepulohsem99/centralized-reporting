"""
GERBANG — MOD SEBENAR TERKAWAL (keputusan pemilik 2026-08-17).

Arahan pemilik membuka laluan mutasi production yang sebelum ini disekat
total. Fail ini ialah bukti bahawa yang dibuka hanyalah yang diminta.

Tiga soalan yang setiap ujian di sini menjawab:

  1. POSITIF   — dalam konteks borang N/P/K-001 dan aliran turunannya,
                 adakah SERAH/HANTAR/KEMASKINI benar-benar lulus?
  2. NEGATIF   — di LUAR konteks itu (Tetapan, Menu Selaras, skrin
                 utama, T-008), adakah ia MASIH disekat walaupun
                 bendera hidup?
  3. REGRESI   — dengan bendera MATI (lalai), adakah kelakuan corong
                 IDENTIK dengan sebelum arahan ini wujud?

Soalan (3) yang paling penting dan paling mudah dilupakan: bendera baharu
yang secara senyap mengubah mod lalai bermakna setiap keputusan ujian
sebelum ini perlu dinilai semula. Ia diuji dengan menjalankan matriks
keputusan PENUH dua kali dan membandingkannya.

Semua fixture skrin ialah dump device SEBENAR dari repo. Tiada XML
rekaan digunakan untuk membuktikan sesuatu DIBENARKAN — hanya untuk
membuktikan sesuatu DISEKAT, di mana rekaan hanya boleh menjadikan
ujian lebih ketat.
"""

import glob
import os
import sys

import pytest

AKAR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if AKAR not in sys.path:
    sys.path.insert(0, AKAR)

from guard import dasar                                        # noqa: E402


# ---------------------------------------------------------------------------
# Fixture skrin — dump device sebenar
# ---------------------------------------------------------------------------

def baca(*bahagian):
    with open(os.path.join(AKAR, *bahagian), encoding="utf-8") as fh:
        return fh.read()


# Dalam konteks (skrin yang pemilik luluskan untuk mutasi).
SKRIN_K001 = ("docs", "recon", "k001-01-sebelum-mysikap.xml")
SKRIN_P001 = ("ui_dumps", "denda_tiada_dalam_pokok.xml")
SKRIN_SENARAI = ("docs", "recon", "cetak-B-senarai.xml")
SKRIN_NOTIS_KOMPAUN = ("docs", "recon", "nk-A-skrin-masuk.xml")
SKRIN_PAPARAN_NOTIS = ("ui_dumps", "bookmark_popup.xml")
DIALOG_TARIK = ("docs", "recon", "nk-B-dialog-tarik.xml")

# LUAR konteks.
SKRIN_UTAMA = ("docs", "recon", "cetak-A-skrin-utama.xml")
SKRIN_UTAMA_2 = ("docs", "recon", "nk-E-back-out.xml")
POPUP_PRINTER = ("docs", "recon", "cetak-C-popup-printer.xml")
SKRIN_MENU_SELARAS = ("ui_dumps", "t010_skrin_utama.xml")

DALAM_KONTEKS = [SKRIN_K001, SKRIN_P001, SKRIN_SENARAI, SKRIN_NOTIS_KOMPAUN,
                 SKRIN_PAPARAN_NOTIS, DIALOG_TARIK]
LUAR_KONTEKS = [SKRIN_UTAMA, SKRIN_UTAMA_2, POPUP_PRINTER,
                SKRIN_MENU_SELARAS]

# Butang yang arahan pemilik namakan, ditambah CETAK (N/P/K-002).
BUTANG_MUTASI = ["SERAH", "HANTAR", "HANTAR SEMULA", "HANTAR DATA",
                 "HANTAR GAMBAR", "SAHKAN", "YA", "OK", "KEMASKINI",
                 "CETAK"]


def tetapan(mod_sebenar):
    return dasar.Tetapan(dry_run=True, benarkan_serah=False,
                         izin_serah=False, mod_sebenar=mod_sebenar)


def putuskan(teks, mod_sebenar, src=None):
    """Nilai satu tap seperti corong melakukannya — konteks dikira
    daripada sumber halaman, bukan diberi."""
    konteks = dasar.konteks_mod_sebenar(src) if src else None
    return dasar.nilai([teks], tetapan(mod_sebenar), konteks_mutasi=konteks)


# ---------------------------------------------------------------------------
# 1. POSITIF — dalam konteks, butang yang dinamakan lulus
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("skrin", DALAM_KONTEKS,
                         ids=[s[-1] for s in DALAM_KONTEKS])
def test_konteks_dikenal_pasti_pada_skrin_yang_dibenarkan(skrin):
    assert dasar.konteks_mod_sebenar(baca(*skrin)) is not None


@pytest.mark.parametrize("butang", BUTANG_MUTASI)
def test_positif_butang_mutasi_lulus_pada_borang_k001(butang):
    kep = putuskan(butang, mod_sebenar=True, src=baca(*SKRIN_K001))
    assert kep.benarkan, f"{butang} disekat: {kep.sebab}"
    assert kep.peraturan == "MOD-SEBENAR"


@pytest.mark.parametrize("skrin", DALAM_KONTEKS,
                         ids=[s[-1] for s in DALAM_KONTEKS])
def test_positif_serah_hantar_kemaskini_pada_setiap_skrin_dibenarkan(skrin):
    src = baca(*skrin)
    for butang in ("SERAH", "HANTAR", "KEMASKINI"):
        kep = putuskan(butang, mod_sebenar=True, src=src)
        assert kep.benarkan, f"{skrin[-1]}: {butang} disekat — {kep.sebab}"


def test_positif_sebab_menamakan_konteksnya():
    """Ledger mesti merekod SKRIN MANA yang membenarkan tap itu.
    'dibenarkan' tanpa menamakan konteks tidak boleh diaudit."""
    kep = putuskan("HANTAR", mod_sebenar=True, src=baca(*SKRIN_K001))
    assert "BORANG-K" in kep.sebab


# ---------------------------------------------------------------------------
# 2. NEGATIF — di luar konteks, bendera hidup TIDAK membuka apa-apa
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("skrin", LUAR_KONTEKS,
                         ids=[s[-1] for s in LUAR_KONTEKS])
def test_negatif_tiada_konteks_pada_skrin_luar(skrin):
    assert dasar.konteks_mod_sebenar(baca(*skrin)) is None


@pytest.mark.parametrize("skrin", LUAR_KONTEKS,
                         ids=[s[-1] for s in LUAR_KONTEKS])
@pytest.mark.parametrize("butang", BUTANG_MUTASI)
def test_negatif_butang_mutasi_kekal_disekat_luar_konteks(skrin, butang):
    kep = putuskan(butang, mod_sebenar=True, src=baca(*skrin))
    assert not kep.benarkan, (
        f"{skrin[-1]}: {butang} DIBENARKAN di luar konteks — {kep.sebab}")


def dump_pelanggaran():
    """Dump forensik bagi PELANGGARAN sebenar sahaja.

    `reports/forensik/` mengandungi dua jenis fail. Yang dinamakan
    `<cap-masa>__<tc>__<PERATURAN>.xml` ditulis oleh `Corong.forensik()`
    apabila satu tap DISEKAT — itu rekod skrin yang gerbang tolak.
    Yang lain (`k001_*.xml`, `mysikap_*.xml`, `pra_sweep_*.xml`) ialah
    dump diagnostik biasa yang kebetulan disimpan dalam folder yang
    sama; kebanyakannya IALAH borang Letak Kereta, jadi ia sepatutnya
    memang berkonteks.

    Mencampurkan kedua-duanya menjadikan ujian ini menuduh mod sebenar
    kerana mengenali borang yang memang dibenarkan.
    """
    corak = os.path.join(AKAR, "reports", "forensik", "*__*__*.xml")
    return sorted(glob.glob(corak))


def test_negatif_setiap_dump_pelanggaran_kekal_tanpa_konteks():
    """Setiap dump pelanggaran ialah skrin SEBENAR di mana corong pernah
    menyekat sesuatu: KEMASKINI pada Menu Selaras, OK pada alert,
    SELARAS-PELESEN, SIMPAN pada skrin Tetapan/login.

    Mod sebenar tidak boleh membuka SATU pun daripadanya. Ini ujian
    yang paling dekat dengan soalan sebenar pemilik: 'adakah ia membuka
    apa-apa yang saya tidak minta?'
    """
    dumps = dump_pelanggaran()
    assert len(dumps) >= 10, f"dijangka >=10 dump pelanggaran, ada {len(dumps)}"
    terbuka = []
    for d in dumps:
        with open(d, encoding="utf-8") as fh:
            if dasar.konteks_mod_sebenar(fh.read()) is not None:
                terbuka.append(os.path.basename(d))
    assert not terbuka, (
        f"mod sebenar membuka skrin yang pernah disekat: {terbuka}")


def test_dump_pelanggaran_meliputi_peraturan_yang_penting():
    """Ujian di atas hanya bermakna kalau koleksinya benar-benar
    mengandungi peraturan yang kita risaukan."""
    nama = " ".join(os.path.basename(d) for d in dump_pelanggaran())
    for peraturan in ("KEMASKINI", "OK", "SELARAS-PELESEN", "SIMPAN"):
        assert peraturan in nama, f"tiada dump pelanggaran {peraturan}"


def test_negatif_t008_selaras_pelesen_kekal_haram():
    """T-008 KEKAL SKIP — arahan pemilik menegaskannya semula dalam
    arahan mod sebenar itu sendiri.

    Dua lapisan diuji: skrin Menu Selaras tiada konteks, DAN teks item
    menu itu berada dalam senarai larangan mutlak.
    """
    src = baca(*SKRIN_MENU_SELARAS)
    assert dasar.konteks_mod_sebenar(src) is None
    kep = putuskan("Selaras Maklumat Pelesen", mod_sebenar=True, src=src)
    assert not kep.benarkan
    assert kep.peraturan == "SELARAS-PELESEN"


def test_negatif_pelesen_disekat_walaupun_konteks_sah():
    """Larangan mutlak mengatasi konteks yang sah.

    Kalau item Selaras Pelesen entah bagaimana muncul di atas borang
    yang dibenarkan, ia MASIH tidak boleh ditekan.
    """
    kep = dasar.nilai(["SELARAS MAKLUMAT PELESEN"], tetapan(True),
                      konteks_mutasi="BORANG-K")
    assert not kep.benarkan
    assert kep.peraturan == "SELARAS-PELESEN"


@pytest.mark.parametrize("butang", ["PADAM", "HAPUS", "Padam Rekod",
                                    "HAPUS SEMUA"])
def test_negatif_padam_hapus_tidak_pernah_dibuka(butang):
    """Pemilik meluluskan MENCIPTA rekod, bukan MEMADAM. Pembersihan
    rekod ujian dibuat oleh PM melalui portal."""
    kep = putuskan(butang, mod_sebenar=True, src=baca(*SKRIN_K001))
    assert not kep.benarkan, f"{butang} dibenarkan oleh mod sebenar"


def test_negatif_simpan_tidak_dibuka_oleh_mod_sebenar():
    """SIMPAN kekal pada dua pengecualian berstrukturnya sendiri.
    Mod sebenar tidak menyentuhnya."""
    kep = putuskan("SIMPAN", mod_sebenar=True, src=baca(*SKRIN_K001))
    assert not kep.benarkan
    assert kep.peraturan == "SIMPAN"


@pytest.mark.parametrize("teks", [
    "PENGHANTARAN TIDAK BERJAYA",
    "[SEK 81 (B)] - APA-APA BINATANG YANG DISIMPAN DALAM SESUATU TEMPAT",
    "KOMPAUN YANG TELAH DIHANTAR KE ePBT",
    "TIDAK OK",
    "KEMASKINI NOTIS AMARAN",
])
def test_negatif_teks_data_tidak_dibuka_oleh_sauh(teks):
    """Corak mod sebenar BERSAUH PENUH. Baris data yang menyebut
    perkataan mutasi di tengah ayat tidak boleh dilayan sebagai butang
    mutasi — itu kelas positif-palsu yang membatalkan sweep 284 pada
    set ke-16.

    Nota: sesetengah teks ini memang DIBENARKAN sebelum ini juga, atas
    sebab yang betul ('tiada peraturan memadan' — mengetuk baris
    dropdown memilih nilai, ia tidak menyerahkan apa-apa). Yang diuji
    di sini bukan 'disekat', tetapi bahawa keputusannya TIDAK datang
    daripada mod sebenar. Kalau ia datang dari situ, sauh sudah bocor.
    """
    kep = putuskan(teks, mod_sebenar=True, src=baca(*SKRIN_K001))
    assert kep.peraturan != "MOD-SEBENAR", (
        f"teks data {teks!r} dilayan sebagai butang mutasi: {kep.sebab}")
    # Keputusannya juga mesti sama seperti dengan bendera mati.
    lama = putuskan(teks, mod_sebenar=False, src=baca(*SKRIN_K001))
    assert (kep.benarkan, kep.peraturan) == (lama.benarkan, lama.peraturan)


# ---------------------------------------------------------------------------
# 3. REGRESI — bendera MATI mesti IDENTIK dengan kelakuan sedia ada
# ---------------------------------------------------------------------------

def test_lalai_bendera_adalah_mati(monkeypatch):
    monkeypatch.delenv("MBPG_MOD_SEBENAR", raising=False)
    assert dasar.Tetapan().mod_sebenar is False


@pytest.mark.parametrize("nilai_env,dijangka",
                         [("1", True), ("ya", True), ("true", True),
                          ("0", False), ("", False), ("2", False),
                          ("YES", False), (" 1 ", True)])
def test_bendera_dibaca_dari_persekitaran(monkeypatch, nilai_env, dijangka):
    monkeypatch.setenv("MBPG_MOD_SEBENAR", nilai_env)
    assert dasar.Tetapan().mod_sebenar is dijangka


@pytest.mark.parametrize("skrin", DALAM_KONTEKS + LUAR_KONTEKS,
                         ids=[s[-1] for s in DALAM_KONTEKS + LUAR_KONTEKS])
@pytest.mark.parametrize("butang", BUTANG_MUTASI)
def test_bendera_mati_semua_mutasi_kekal_disekat(skrin, butang):
    kep = putuskan(butang, mod_sebenar=False, src=baca(*skrin))
    assert not kep.benarkan, (
        f"MBPG_MOD_SEBENAR=0 tetapi {butang} dibenarkan pada "
        f"{skrin[-1]} — mod lalai berubah")


def test_bendera_mati_kelakuan_identik_dengan_sebelum():
    """Matriks keputusan PENUH, dinilai dua kali.

    Sebelah kiri: nilai() dipanggil TANPA hujah konteks langsung —
    iaitu tepat seperti kod sebelum arahan ini wujud memanggilnya.
    Sebelah kanan: nilai() dipanggil dengan bendera mati dan konteks
    dikira daripada skrin sebenar.

    Setiap keputusan mesti sepadan, termasuk peraturan yang dinamakan.
    Kalau tidak, sesuatu dalam laluan lalai sudah berubah.
    """
    teks_ujian = BUTANG_MUTASI + [
        "SIMPAN", "BATAL", "TIDAK", "SETERUSNYA", "TARIK", "PATUH",
        "SELARAS MAKLUMAT PELESEN", "PADAM", "HAPUS",
        "Semak Kemaskini Versi Terkini", "PENGHANTARAN TIDAK BERJAYA",
        "KOMPAUN LETAK KERETA",
    ]
    beza = []
    for skrin in DALAM_KONTEKS + LUAR_KONTEKS:
        src = baca(*skrin)
        for t in teks_ujian:
            lama = dasar.nilai([t], tetapan(False))
            baharu = dasar.nilai(
                [t], tetapan(False),
                konteks_mutasi=dasar.konteks_mod_sebenar(src))
            if (lama.benarkan, lama.peraturan) != (baharu.benarkan,
                                                   baharu.peraturan):
                beza.append((skrin[-1], t, lama.peraturan, baharu.peraturan))
    assert not beza, f"kelakuan lalai berubah: {beza}"


def test_konteks_diabaikan_sepenuhnya_bila_bendera_mati():
    """Konteks yang sah TANPA bendera tidak membuka apa-apa. Dua syarat
    bebas, sama seperti dry_run + izin_serah."""
    for butang in BUTANG_MUTASI:
        kep = dasar.nilai([butang], tetapan(False),
                          konteks_mutasi="BORANG-K")
        assert not kep.benarkan, f"{butang} dibenarkan tanpa bendera induk"


def test_bendera_hidup_tanpa_konteks_tidak_membuka_apa_apa():
    """Cermin ujian di atas: bendera TANPA konteks juga tidak cukup."""
    for butang in BUTANG_MUTASI:
        kep = dasar.nilai([butang], tetapan(True), konteks_mutasi=None)
        assert not kep.benarkan, f"{butang} dibenarkan tanpa konteks"


# ---------------------------------------------------------------------------
# 4. Semakan konteks itu sendiri
# ---------------------------------------------------------------------------

def test_tajuk_appbar_tepat_satu_calon_pada_setiap_dump():
    """Semakan 'tepat satu calon' mesti tegas pada dump sebenar —
    kalau ia longgar, tajuk boleh dipungut daripada kandungan skrin."""
    dijangka = {
        "k001-01-sebelum-mysikap.xml": "Letak Kereta",
        "denda_tiada_dalam_pokok.xml": "Pelbagai",
        "cetak-B-senarai.xml": "Senarai Kompaun",
        "nk-A-skrin-masuk.xml": "Notis Kompaun",
        "cetak-A-skrin-utama.xml": "Kompaun e-PBT",
        "bookmark_popup.xml": "Paparan Notis",
    }
    for corak in (("docs", "recon", "*.xml"), ("ui_dumps", "*.xml")):
        for laluan in glob.glob(os.path.join(AKAR, *corak)):
            nama = os.path.basename(laluan)
            if nama not in dijangka:
                continue
            with open(laluan, encoding="utf-8") as fh:
                assert dasar.tajuk_appbar(fh.read()) == dijangka[nama], nama


def test_glif_ikon_bukan_tajuk():
    """Skrin utama membawa TIGA TextView berteks dalam jalur app-bar,
    kesemuanya glif ikon Private Use Area. Kalau ia tidak ditapis,
    kiraan calon menjadi 4 dan tajuk tidak akan pernah dibaca."""
    assert dasar._hanya_glif("\U000f0453")
    assert dasar._hanya_glif("")
    assert not dasar._hanya_glif("Letak Kereta")
    assert not dasar._hanya_glif("")
    assert dasar.tajuk_appbar(baca(*SKRIN_UTAMA)) == "Kompaun e-PBT"


def test_content_desc_navigasi_bukan_tajuk():
    """`content-desc='Notis Amaran, back'` menamakan skrin SEBELUMNYA.
    Menerimanya bermakna membenarkan mutasi berdasarkan skrin yang kita
    sudah tinggalkan."""
    src = baca(*SKRIN_PAPARAN_NOTIS)
    assert "Notis Amaran, back" in src
    assert dasar.tajuk_appbar(src) == "Paparan Notis"


def test_xml_rosak_atau_kosong_gagal_tertutup():
    for buruk in ("", None, "bukan xml", "<hierarchy>"):
        assert dasar.konteks_mod_sebenar(buruk) is None
        assert dasar.tajuk_appbar(buruk) is None


def test_dialog_hanya_dinilai_bila_appbar_tidak_terbaca():
    """Kalau app-bar DIBACA dan skrinnya tidak dibenarkan, semakan
    dialog tidak dijalankan langsung.

    Tanpa peraturan ini, satu baris data pada skrin utama yang
    kebetulan berbunyi 'CETAK SESUATU ?' akan membuka mutasi di sana.
    """
    src = baca(*SKRIN_UTAMA)
    dicemar = src.replace('text="Senarai"', 'text="CETAK KOMPAUN INI ?"')
    assert dasar.tajuk_appbar(dicemar) == "Kompaun e-PBT"
    assert dasar.konteks_mod_sebenar(dicemar) is None

"""Gerbang tangkapan forensik.

Ditulis selepas 2026-08-18, apabila ketiga-tiga borang K gagal dengan
mesej yang dipotong pada 44 aksara dan tiada satu pun artifak ditinggal
untuk membezakan dua punca yang mungkin.
"""

import os
import sys

AKAR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, AKAR)

from tools import forensik                                  # noqa: E402


class DrvPalsu:
    def __init__(self, page_source="<hierarchy/>", meletup=False):
        self.page_source = page_source
        self._meletup = meletup
        self.skrin = None

    def get_screenshot_as_file(self, laluan):
        if self._meletup:
            raise RuntimeError("skrin tidak boleh dibaca")
        self.skrin = laluan
        open(laluan, "wb").write(b"PNG")
        return True


def _bersih(asas):
    for suf in (".txt", ".png", ".xml"):
        try:
            os.remove(asas + suf)
        except OSError:
            pass


def test_mesej_penuh_ditulis_tanpa_dipotong():
    """Sebab modul ini wujud: 44 aksara tidak memberitahu apa-apa."""
    panjang = ("'KETERANGAN KOD KOMPAUN': modal ditutup tetapi TIADA "
               "pressable memaparkan 'AKTA JALAN' selepas pemilihan. "
               "Baca-balik GAGAL — jangan percaya pemilihan ini.")
    forensik.set_driver(None)
    asas = forensik.tangkap("borang K 1/3", AssertionError(panjang))
    assert asas
    try:
        teks = open(asas + ".txt", encoding="utf-8").read()
        assert panjang in teks
        assert "-- TRACEBACK --" in teks
    finally:
        _bersih(asas)


def test_pokok_paparan_ditulis_bila_driver_ada():
    """XML membezakan 'modal tidak buka' daripada 'nilai tidak melekat'."""
    drv = DrvPalsu(page_source="<hierarchy><node text='PILIH'/></hierarchy>")
    forensik.set_driver(drv)
    asas = forensik.tangkap("borang K", AssertionError("x"))
    try:
        assert open(asas + ".xml", encoding="utf-8").read().count("PILIH")
        assert os.path.exists(asas + ".png")
    finally:
        forensik.set_driver(None)
        _bersih(asas)


def test_tiada_driver_masih_menulis_mesej():
    """Kegagalan sebelum sesi dibina masih layak direkod."""
    forensik.set_driver(None)
    asas = forensik.tangkap("selaras", RuntimeError("tiada peranti"))
    try:
        assert os.path.exists(asas + ".txt")
        assert not os.path.exists(asas + ".png")
    finally:
        _bersih(asas)


def test_driver_yang_meletup_tidak_menghalang_fail_teks():
    """Kegagalan menangkap bukti tidak boleh menggantikan kegagalan
    asal — itu menukar satu masalah kepada dua."""
    forensik.set_driver(DrvPalsu(meletup=True))
    asas = forensik.tangkap("borang P", RuntimeError("asal"))
    try:
        assert "asal" in open(asas + ".txt", encoding="utf-8").read()
    finally:
        forensik.set_driver(None)
        _bersih(asas)


def test_tangkap_tidak_pernah_membangkitkan():
    forensik.set_driver(None)
    dir_asal = forensik.DIR_OUT
    forensik.DIR_OUT = "\x00tidak-sah"          # laluan mustahil
    try:
        assert forensik.tangkap("apa-apa", RuntimeError("x")) is None
    finally:
        forensik.DIR_OUT = dir_asal


def test_nama_peringkat_selamat_sebagai_nama_fail():
    """'borang K [1/3] JYX6605' mengandungi aksara yang Windows tolak."""
    n = forensik._nama_selamat("borang K [1/3] JYX6605")
    assert "[" not in n and "/" not in n and " " not in n
    assert "JYX6605" in n


def test_dipanggil_pada_setiap_kegagalan_peringkat():
    import inspect
    from tools import run_penuh
    src = inspect.getsource(run_penuh.jalankan)
    assert "forensik.tangkap(nama, e)" in src

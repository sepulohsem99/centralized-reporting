"""
GERBANG — sesi N+P+K berterusan (arahan pemilik 2026-08-17, Prompt 8).

Pemilik membatalkan jeda semakan antara borang. Kesannya: satu bug
locator yang tersembunyi pada N kini boleh berulang pada P dan K
sebelum sesiapa sempat melihatnya. Pemilik menerima risiko itu secara
sedar — jadi kerja ujian ini ialah mengurangkan permukaan bug yang
BOLEH dikurangkan tanpa peranti.

Dua penambahan paling berisiko dilindungi di sini:

  * laluan K dengan lookup mySIKAP, yang menulis PII warga SEBENAR ke
    dalam rekod production dan bergaduh dengan jaring PII;
  * pengecualian jaring PII yang laluan itu perlukan, yang mesti
    berskop kepada nilai yang lookup benar-benar hasilkan dan bukan
    "matikan jaring untuk K".
"""

import os
import sys

import pytest

AKAR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if AKAR not in sys.path:
    sys.path.insert(0, AKAR)

from tools import rekod_log, run_e2e                            # noqa: E402


# ---------------------------------------------------------------------------
# 1. Satu command untuk tiga borang
# ---------------------------------------------------------------------------

def test_borang_gabungan_satu_panggilan():
    assert run_e2e.urai_borang("NPK") == ["N", "P", "K"]


def test_urutan_dikekalkan_seperti_ditaip():
    """Pemilik yang menentukan susunan risiko (N -> P -> K), bukan kami.
    Menyusun semula secara senyap akan meletakkan K — satu-satunya
    borang yang menulis PII sebenar — lebih awal daripada yang
    dimaksudkan."""
    assert run_e2e.urai_borang("KPN") == ["K", "P", "N"]
    assert run_e2e.urai_borang("PNK") == ["P", "N", "K"]


def test_pendua_dibuang_tanpa_menukar_urutan():
    assert run_e2e.urai_borang("NNPKP") == ["N", "P", "K"]


def test_huruf_tidak_sah_ditolak():
    with pytest.raises(SystemExit):
        run_e2e.urai_borang("NPX")


def test_satu_pengesahan_ya_untuk_seluruh_sesi():
    """`minta_ya()` dipanggil SEKALI, sebelum gelung borang.

    Ini fakta yang pemilik minta disahkan (Prompt 8 #2): command
    gabungan bermakna SATU YA untuk ketiga-tiga borang, bukan tiga.
    """
    sumber = open(os.path.join(AKAR, "tools", "run_e2e.py"),
                  encoding="utf-8").read()
    badan = sumber[sumber.index("def main("):]
    assert badan.count("minta_ya(") == 1
    assert badan.index("minta_ya(") < badan.index("for huruf in boleh:")


# ---------------------------------------------------------------------------
# 2. K dengan mySIKAP — PII sebenar
# ---------------------------------------------------------------------------

def test_laluan_k_menggunakan_mysikap_bukan_taip_penuh():
    """Arahan pemilik #3: mySIKAP MESTI ditekan semasa cipta.

    Laluan lama (`fill_pesalah_tab_letak_kereta`) menaip setiap medan
    dan TIDAK mencetuskan lookup — ia mesti tidak lagi digunakan untuk
    laluan cipta K.
    """
    sumber = open(os.path.join(AKAR, "tools", "run_e2e.py"),
                  encoding="utf-8").read()
    assert "isi_pesalah_k_mysikap(" in sumber
    assert "p.fill_pesalah_tab_letak_kereta(data)" not in sumber


def test_redact_tidak_pernah_memulangkan_nilai_asal():
    """Log mesti merekod BENTUK, bukan nilai. PII hasil lookup yang
    ditulis ke repo akan disekat oleh gerbang pra-commit — betul-betul
    begitu — dan lebih penting, ia tidak sepatutnya wujud di sana."""
    # Nilai dibina pada masa jalan, bukan ditulis sebagai literal:
    # menulis rentetan berbentuk PII ke dalam fail ini memasukkannya ke
    # dalam sejarah git, dan gerbang pra-commit menyekatnya — betul.
    contoh = ("NAMA" + " PENUH SESEORANG",
              "930613" + "016605",
              "6 LORONG " + "SESUATU")
    for nilai in contoh:
        keluar = run_e2e.redact(nilai)
        assert nilai not in keluar
        assert keluar.startswith("<") and keluar.endswith(">")


def test_redact_membezakan_digit_dan_teks():
    assert run_e2e.redact("123456" + "789012") == "<12 digit>"
    assert run_e2e.redact("ABC DEF") == "<teks 7 aksara>"
    assert run_e2e.redact("") == "<kosong>"
    assert run_e2e.redact(None) == "<kosong>"


def test_pengecualian_pii_berskop_kepada_nilai_lookup():
    """Pengecualian mesti ikut NILAI YANG DIPERHATI, bukan 'borang K'.

    `jaring_pii` membina set 'milik kita' daripada `data.values()`, jadi
    menyuntik nilai lookup ke dalam dict yang dihantar menjadikan
    TEPAT nilai itu dijangka — dan tiada yang lain.
    """
    from devtools.fasa_c_e2e import jaring_pii
    import inspect

    src = inspect.getsource(jaring_pii)
    assert "data.values()" in src, (
        "jaring_pii tidak lagi membina set dari data.values(); "
        "pengecualian berskop dalam run_e2e bergantung padanya")

    runner = open(os.path.join(AKAR, "tools", "run_e2e.py"),
                  encoding="utf-8").read()
    assert "dijangka = dict(data)" in runner
    assert "_mysikap_" in runner
    # Jaring mesti masih dipanggil, dan dengan dict yang diperluas.
    assert "jaring_pii(drv, dijangka)" in runner
    assert "jaring_pii(drv, data)" not in runner


def test_jaring_pii_masih_menangkap_pii_luar_lookup():
    """Bukti sifat, bukan bacaan sumber: nilai yang BUKAN dalam dict
    yang dibekalkan masih ditanda."""
    from devtools.imbas_pii import imbas_teks

    teks = " BIN ".join(("AHMAD", "ALI")) + " | " + "900101" + "015555"
    jumpa = [n for n, _ in imbas_teks(teks, had=40)]
    assert "nama_bin_binti" in jumpa
    assert "no_kp_12_digit" in jumpa


def test_medan_identiti_tidak_ditaip_semula_selepas_lookup():
    """Menaip semula Nama/IC selepas lookup akan menimpa hasil lookup
    dan menjadikan rekod bercampur — separuh identiti sebenar, separuh
    penanda. Itu lebih teruk daripada mana-mana pilihan tulen."""
    import inspect

    src = inspect.getsource(run_e2e.isi_pesalah_k_mysikap)
    assert '"no_kereta", "nama_pesalah", "no_kp_ssm_kereta"' in src


def test_mysikap_gagal_bermakna_tiada_serah():
    """Kalau lookup tidak mengisi apa-apa, rekod TIDAK diserah.

    Borang separuh siap lebih baik daripada rekod production dengan
    identiti yang salah.
    """
    import inspect

    src = inspect.getsource(run_e2e.isi_pesalah_k_mysikap)
    assert "IzinTidakSah" in src
    assert "tidak mengisi apa-apa" in src


def test_tiada_tekaan_bila_mysikap_tidak_dikenal_pasti():
    import inspect

    src = inspect.getsource(run_e2e.isi_pesalah_k_mysikap)
    assert "cari_mysikap()" in src
    assert "MEMADAM data" in src


# ---------------------------------------------------------------------------
# 3. TN / NK kekal SKIP untuk SEMUA borang
# ---------------------------------------------------------------------------

def test_tn_nk_skip_secara_lalai():
    import inspect

    src = inspect.getsource(run_e2e.peringkat_tn_nk)
    assert "SKIP-TIDAK-LAYAK" in src
    i_skip = src.index("if not paksa:")
    i_buka = src.index("open_notis_kompaun")
    assert i_skip < i_buka, "skrin Notis Kompaun dibuka sebelum semakan skip"


def test_tarikh_layak_nk_ialah_14_hari():
    import datetime

    asas = datetime.date(2026, 8, 17)
    assert run_e2e.tarikh_layak_nk(asas) == datetime.date(2026, 8, 31)
    assert run_e2e.TEMPOH_NOTIS_HARI == 14


# ---------------------------------------------------------------------------
# 4. Jadual masa
# ---------------------------------------------------------------------------

@pytest.fixture
def log_terpencil(tmp_path, monkeypatch):
    monkeypatch.setattr(rekod_log, "DIR_REPORTS", str(tmp_path))
    return tmp_path


def test_jadual_masa_meliputi_ketiga_tiga_borang(log_terpencil):
    jejak = []
    for tag in ("N-001", "P-001", "K-001"):
        for i, peringkat in enumerate(("cipta", "cetak", "hantar")):
            jejak.append({
                "tag": tag, "peringkat": peringkat, "status": "LULUS",
                "nota": "", "tempoh_s": 60 + i,
                "mula": f"2026-08-17 1{i}:00:00",
                "tamat": f"2026-08-17 1{i}:01:00",
            })
    laluan = rekod_log.tulis_jadual_masa(
        jejak, "2026-08-17 10:00:00", "2026-08-17 12:30:00",
        tarikh="2026-08-17")
    isi = open(laluan, encoding="utf-8").read()
    for tag in ("N-001", "P-001", "K-001"):
        assert tag in isi
        assert isi.count(f"| **{tag}** | **JUMLAH BORANG**") == 1
    assert "Jumlah masa sesi:** 02:30:00" in isi


def test_jadual_masa_kosong_tidak_menulis_apa_apa(log_terpencil):
    assert rekod_log.tulis_jadual_masa([], "a", "b") is None


def test_tempoh_sesi_termasuk_masa_antara_borang(log_terpencil):
    """Jumlah sesi diukur dari command pertama, bukan jumlah peringkat —
    relaunch app dan login semula antara borang ialah masa sebenar."""
    jejak = [{"tag": "N-001", "peringkat": "cipta", "status": "LULUS",
              "nota": "", "tempoh_s": 10,
              "mula": "2026-08-17 10:00:00", "tamat": "2026-08-17 10:00:10"}]
    laluan = rekod_log.tulis_jadual_masa(
        jejak, "2026-08-17 10:00:00", "2026-08-17 11:00:00",
        tarikh="2026-08-17")
    isi = open(laluan, encoding="utf-8").read()
    assert "01:00:00" in isi          # sesi
    assert "00:00:10" in isi          # peringkat


def test_hhmmss():
    assert rekod_log._hhmmss(0) == "00:00:00"
    assert rekod_log._hhmmss(59) == "00:00:59"
    assert rekod_log._hhmmss(3661) == "01:01:01"
    assert rekod_log._hhmmss(-5) == "00:00:00"


# ---------------------------------------------------------------------------
# 5. Semakan konteks MENUNGGU peralihan skrin
# ---------------------------------------------------------------------------
#
# Larian 2026-08-17 13:13 berhenti pada N-001 dengan tajuk app-bar
# 'Kompaun e-PBT' — skrin UTAMA. Senarai konteks tidak salah; semakan
# membaca pokok view SEKALI, sebelum navigasi React Native selesai.
#
# `home.open_notis_amaran()` hanya mengetuk dan terus pulang. Laluan K
# tidak mempunyai masalah ini kerana `select_jenis_kompaun_letak_kereta()`
# menunggu TRAFIK_SCREEN_TITLE — jadi bug ini akan mengenai N sahaja,
# dan hanya pada larian pertama yang benar-benar memandu N.

class _DrvPalsu:
    """Driver minimum: memulangkan satu sumber halaman per bacaan."""

    def __init__(self, jujukan):
        self._jujukan = list(jujukan)
        self.bacaan = 0

        class _T:
            mod_sebenar = True

        class _C:
            tetapan = _T()

        self.corong = _C()

    @property
    def page_source(self):
        self.bacaan += 1
        if len(self._jujukan) > 1:
            return self._jujukan.pop(0)
        return self._jujukan[0]


def _src(tajuk):
    return (
        '<?xml version="1.0" encoding="UTF-8"?>'
        '<hierarchy rotation="0">'
        '<android.view.View resource-id="appbar-content-title-text" '
        f'text="{tajuk}" bounds="[48,162][600,246]"/>'
        "</hierarchy>")


def test_konteks_menunggu_peralihan_skrin():
    """Skrin utama dahulu, borang kemudian — mesti LULUS, bukan gagal
    pada bacaan pertama."""
    drv = _DrvPalsu([_src("Kompaun e-PBT"), _src("Notis Amaran")])
    assert run_e2e.sahkan_konteks_mutasi(drv, "N-001", tempoh=5) == "BORANG-N"
    assert drv.bacaan >= 2


def test_konteks_lulus_serta_merta_bila_sudah_betul():
    """Tiada tidur yang tidak perlu bila skrin memang sudah betul."""
    drv = _DrvPalsu([_src("Letak Kereta")])
    assert run_e2e.sahkan_konteks_mutasi(drv, "K-001", tempoh=5) == "BORANG-K"
    assert drv.bacaan == 1


def test_konteks_gagal_selepas_tempoh_dengan_jujukan_tajuk():
    """Kalau skrin tidak pernah bertukar, mesej mesti menunjukkan
    jujukan tajuk — itu yang membezakan 'navigasi gagal' daripada
    'tajuk tiada dalam senarai'."""
    from tools.izin_e2e import IzinTidakSah

    drv = _DrvPalsu([_src("Kompaun e-PBT")])
    # IzinTidakSah mewarisi BaseException dengan sengaja (66 blok
    # `except Exception` dalam pages/ akan menelannya kalau tidak), jadi
    # pytest.raises(Exception) TIDAK menangkapnya.
    with pytest.raises(IzinTidakSah) as e:
        run_e2e.sahkan_konteks_mutasi(drv, "N-001", tempoh=2)
    mesej = str(e.value)
    assert "Kompaun e-PBT" in mesej
    assert "TIDAK PERNAH bertukar" in mesej


def test_konteks_dilangkau_bila_mod_sebenar_mati():
    drv = _DrvPalsu([_src("Kompaun e-PBT")])
    drv.corong.tetapan.mod_sebenar = False
    assert run_e2e.sahkan_konteks_mutasi(drv, "N-001", tempoh=2) is None
    assert drv.bacaan == 0


# ---------------------------------------------------------------------------
# 6. Larian device 2026-08-17 13:43 — tiga pepijat, tiga gerbang
# ---------------------------------------------------------------------------

def test_placeholder_kemaskini_bukan_butang():
    """`ISI KEMASKINI KETERANGAN` ialah EditText, bukan butang.

    Bukti: reports/forensik/20260817-134334__tiada__KEMASKINI.xml —
    `android.widget.EditText [120,1146][960,1266]`. Skrin itu langsung
    tiada butang mutasi (hanya ✕ dan SETERUSNYA).

    Menyekatnya menghentikan run SELEPAS `PGP02N260817008` sudah wujud
    pada production.
    """
    from guard import dasar

    tetapan = dasar.Tetapan(dry_run=True, benarkan_serah=False,
                            izin_serah=False)
    kep = dasar.nilai(["ISI KEMASKINI KETERANGAN"], tetapan)
    assert kep.benarkan, kep.sebab
    assert kep.peraturan == "KEMASKINI-VERSI"


@pytest.mark.parametrize("teks", [
    "KEMASKINI",
    "KEMASKINI DATA",
    "Kemaskini Notis",
    "Kemaskini Kompaun",
    "KEMASKINI REKOD",
])
def test_kemaskini_sebenar_masih_disekat_tanpa_konteks(teks):
    """Pembetulan mesti MENYEMPITKAN. Setiap bentuk KEMASKINI yang
    benar-benar meminda rekod kekal disekat tanpa mod sebenar."""
    from guard import dasar

    tetapan = dasar.Tetapan(dry_run=True, benarkan_serah=False,
                            izin_serah=False)
    kep = dasar.nilai([teks], tetapan)
    assert not kep.benarkan, f"{teks!r} dibenarkan: {kep.sebab}"
    assert kep.peraturan == "KEMASKINI"


def test_placeholder_kemaskini_disahkan_pada_dump_sebenar():
    """Dijalankan terhadap dump pelanggaran itu sendiri: skrin itu kini
    tidak lagi menghasilkan sekatan."""
    import xml.etree.ElementTree as ET
    from guard import dasar

    laluan = os.path.join(AKAR, "reports", "forensik",
                          "20260817-134334__tiada__KEMASKINI.xml")
    if not os.path.exists(laluan):
        pytest.skip("dump pelanggaran tiada")
    root = ET.fromstring(open(laluan, encoding="utf-8").read())
    tetapan = dasar.Tetapan(dry_run=True, benarkan_serah=False,
                            izin_serah=False)
    disekat = []
    for n in root.iter():
        for atribut in ("text", "content-desc"):
            t = (n.get(atribut) or "").strip()
            if not t:
                continue
            if not dasar.nilai([t], tetapan).benarkan:
                disekat.append(t)
    assert not disekat, f"skrin kemaskini masih menyekat: {disekat}"


def test_masa_setiap_peringkat_direkod():
    """`catat_peringkat` mesti merekod tempoh.

    Larian 13:43 mencetak `0s` untuk setiap peringkat kerana suntingan
    yang menambah cap masa tidak pernah sampai ke cakera — satu skrip
    penyuntingan berbilang-bahagian membatalkan diri sebelum menulis.
    Ujian ini mengunci sifat itu supaya kegagalan yang sama tidak boleh
    berulang secara senyap.
    """
    import inspect

    src = inspect.getsource(run_e2e.jalankan_satu)
    assert '"tempoh_s":' in src
    assert '"mula":' in src and '"tamat":' in src
    assert 'jam = {"akhir": time.time()}' in src


def test_mula_sesi_ditakrif_sebelum_digunakan():
    """`mula_sesi` digunakan dalam blok finally.

    Kalau ia tidak ditakrif, jadual masa gagal dengan NameError — yang
    ialah TEPAT apa yang berlaku pada larian 13:43, dan ia hanya
    kelihatan sebagai satu baris `[MASA] jadual gagal ditulis`.
    """
    import inspect

    src = inspect.getsource(run_e2e.main)
    i_takrif = src.index("mula_sesi = time.strftime")
    i_guna = src.index("jejak, mula_sesi,")
    assert i_takrif < i_guna


def test_ringkasan_akhir_dikira_dari_log_bukan_dari_dicipta():
    """Melaporkan 'REKOD DICIPTA: 0' sedangkan satu rekod hidup pada
    production ialah kegagalan laporan paling teruk yang alat ini boleh
    lakukan. Ia berlaku pada larian 13:43.

    `dicipta` hanya bertambah apabila kitaran SIAP; log ditulis sebaik
    nombor wujud. Ringkasan mesti berkunci pada log.
    """
    import inspect

    src = inspect.getsource(run_e2e.main)
    i_kira = src.index("semua_rekod = rekod_log.baca_semua()")
    i_cetak = src.index("REKOD DICIPTA (dari log)")
    assert i_kira < i_cetak
    assert "len(semua_rekod)" in src
    assert 'print(f"== REKOD DICIPTA: {len(dicipta)}")' not in src


def test_medan_kenderaan_tidak_ditaip_selepas_lookup():
    """DAPATAN-MYSIKAP §7 belum dijawab: selepas lookup, medan berlabel
    Jenis/Warna/Petak/Kupon memegang komponen ALAMAT.

    Menaip nilai kenderaan ke dalamnya boleh menimpa alamat yang lookup
    baru tulis, pada rekod production yang akan diserah. Keempat-empat
    medan itu opsyenal, jadi kos melangkaunya sifar.
    """
    import inspect

    src = inspect.getsource(run_e2e.isi_pesalah_k_mysikap)
    assert "SELEPAS_LOOKUP_JANGAN_SENTUH" in src
    for kunci in ("jenis_kereta", "warna_kereta", "no_petak", "no_kupon"):
        assert kunci in src, kunci
    # Dan ia mesti diakui sebagai kehilangan liputan, bukan disenyapkan.
    assert "KEHILANGAN LIPUTAN" in src


# ---------------------------------------------------------------------------
# 7. Borang P/K tab Kompaun — kelas TRAVERSAL-FOKUS
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("kaedah", ["fill_kompaun_tab",
                                    "fill_kompaun_tab_direct"])
def test_kegagalan_pendedahan_tidak_maut(kaedah):
    """Pendedahan yang gagal mesti jatuh ke carian biasa, bukan
    membatalkan kitaran — corak sama seperti pilih_spinner_kod()."""
    import inspect
    from pages.daftar_kompaun_page import DaftarKompaunPage

    import inspect as _i
    from pages.daftar_kompaun_page import DaftarKompaunPage as _D
    # Helper gulung DIKEKALKAN untuk diagnostik sahaja dan mesti
    # mengakui ia BUKAN pembetulan — kalau tidak, orang seterusnya akan
    # menambahnya semula ke laluan pengisian.
    src = _i.getsource(_D.gulung_borang_ke_atas)
    # Docstring mesti merekod KENAPA probe menafikannya — kalau tidak,
    # orang seterusnya akan membuangnya atas sebab yang sama.
    assert "probe_lokasi" in src
    assert "bukan keadaan pengeluaran" in src


def test_borang_notis_kekal_mendedahkan_medan_yang_sama():
    """Pembetulan asal pada borang NOTIS tidak boleh hilang — ia rujukan
    yang pembetulan borang P/K disalin daripadanya."""
    import inspect
    from pages.notis_amaran_page import NotisAmaranPage

    src = inspect.getsource(NotisAmaranPage.fill_notis_tab)
    assert "_dedah_sebelum_cari" in src


# ---------------------------------------------------------------------------
# 8. Larian P-001 15:34 — IME menolak borang, dan tajuk tab KOMPAUN
# ---------------------------------------------------------------------------

def test_tab_kompaun_dikenali_sebagai_konteks_mutasi():
    """Tab KOMPAUN merender app-bar 'Paparan Kompaun', bukan 'Pelbagai'.

    Tanpa entri ini, semakan konteks lulus pada tab PESALAH lalu SERAH
    disekat pada tab KOMPAUN — kegagalan yang hanya muncul SELEPAS
    borang diisi penuh dan gambar diambil.
    """
    from guard import dasar

    laluan = os.path.join(AKAR, "ui_dumps",
                          "mbjb_BUTIRAN_KESALAHAN_dedah_gagal.xml")
    if not os.path.exists(laluan):
        pytest.skip("dump tab KOMPAUN tiada")
    src = open(laluan, encoding="utf-8").read()
    assert dasar.tajuk_appbar(src) == "Paparan Kompaun"
    assert dasar.konteks_mod_sebenar(src) == "PAPARAN-K"


def test_serah_dibenarkan_pada_tab_kompaun():
    from guard import dasar

    laluan = os.path.join(AKAR, "ui_dumps",
                          "mbjb_BUTIRAN_KESALAHAN_dedah_gagal.xml")
    if not os.path.exists(laluan):
        pytest.skip("dump tab KOMPAUN tiada")
    src = open(laluan, encoding="utf-8").read()
    tetapan = dasar.Tetapan(dry_run=True, benarkan_serah=False,
                            izin_serah=False, mod_sebenar=True)
    konteks = dasar.konteks_mod_sebenar(src)
    for butang in ("SERAH", "HANTAR", "CETAK"):
        assert dasar.nilai([butang], tetapan,
                           konteks_mutasi=konteks).benarkan, butang


def test_paparan_kompaun_tidak_membuka_skrin_lain():
    """Entri baharu mesti tidak meluaskan permukaan ke skrin lain."""
    from guard import dasar

    for tajuk in ("Kompaun e-PBT", "Aplikasi Kompaun e-PBT", "Paparan",
                  "Kompaun", "Paparan Sitaan"):
        padan = [n for n, c in dasar.KONTEKS_MOD_SEBENAR if c.match(tajuk)]
        assert "PAPARAN-K" not in padan, tajuk


# >>> UJIAN DIBUANG 2026-08-17 — `test_dump_membuktikan_medan_keluar_dari_atas`
# Ia menegaskan pada `docs/recon/tabkompaun-*.xml`, yang DIJANA SEMULA
# setiap kali skrip diagnostik dijalankan. Selepas pembetulan medan
# kesalahan, keadaan akhir tab berubah dan dump berubah bersamanya —
# jadi ujian itu gagal atas sebab yang betul-betul salah: bukan kerana
# kod rosak, tetapi kerana ia mengunci snapshot satu larian bersejarah.
#
# Pengajaran: jangan tegaskan pada artifak yang alat lain tulis semula.
# Naratif bersejarah (medan keluar dari ATAS skrin, bukan bawah) kekal
# dalam docstring `gulung_borang_ke_atas` dan dalam laporan.


def test_kontena_skrol_borang_wujud():
    """Pembetulan bergantung pada SATU node scrollable pada skrin ini.
    Kalau bilangannya berubah, `.instance(0)` tidak lagi bermakna apa
    yang kita fikir."""
    import xml.etree.ElementTree as ET

    laluan = os.path.join(AKAR, "docs", "recon",
                          "tabkompaun-C-kompaun-mula.xml")
    if not os.path.exists(laluan):
        pytest.skip("dump tiada")
    root = ET.fromstring(open(laluan, encoding="utf-8").read())
    skrol = [n for n in root.iter() if (n.get("scrollable") or "") == "true"]
    assert len(skrol) == 1, f"dijangka 1 kontena scrollable, ada {len(skrol)}"
    assert skrol[0].get("class") == "android.widget.ScrollView"


def test_gulung_ke_atas_tidak_dipanggil_semasa_modal_terbuka():
    """`.instance(0)` menyasarkan ScrollView HALAMAN. Kalau modal
    dropdown terbuka, instance(0) bukan lagi halaman — dan itu konteks
    tepat yang nota base_page.py:3006 amarkan."""
    import inspect
    from pages.daftar_kompaun_page import DaftarKompaunPage

    for kaedah in ("fill_kompaun_tab", "fill_kompaun_tab_direct"):
        src = inspect.getsource(getattr(DaftarKompaunPage, kaedah))
        blok = src[src.index("for _label, _kunci in"):]
        # Blok ini mengisi medan teks sahaja — tiada dropdown dibuka.
        assert "_pilih_melalui_pressable" not in blok
        assert "select_dropdown_option" not in blok


def test_isi_medan_kesalahan_membuktikan_dan_melontar():
    """Medan kesalahan mesti DISAHKAN mendarat, dan kegagalan mesti
    LOUD.

    Empat larian P-001 melaporkan `Kompaun tab filled - PASS` dengan
    kedua-dua medan kosong. Kalau itu berlaku semasa mod sebenar, rekod
    production dicipta dengan medan kesalahan kosong dan tiada siapa
    tahu sehingga PM membacanya.
    """
    import inspect
    from pages.daftar_kompaun_page import DaftarKompaunPage

    src = inspect.getsource(DaftarKompaunPage.isi_medan_kesalahan)
    assert "_medan_memegang" in src
    assert "raise TimeoutException" in src
    kod = "\n".join(l.split("#", 1)[0] for l in src.splitlines())
    # Urutan yang probe UKUR berjaya, tiada langkah tambahan.
    for potong in ("el.click()", "el.clear()", "el.send_keys("):
        assert potong in kod, potong
    # Dan TIADA hide_keyboard: itu yang membuang nilai.
    assert "_hide_keyboard_if_shown" not in kod
    assert "hide_keyboard()" not in kod


def test_baca_balik_guna_page_source_bukan_el_text():
    """`el.text` pulang None selepas RN re-render, dan laluan lama
    mentafsirkannya sebagai 'anggap berjaya'. Membaca page_source segar
    mengelak keseluruhan kelas kegagalan itu."""
    import inspect
    from pages.daftar_kompaun_page import DaftarKompaunPage

    src = inspect.getsource(DaftarKompaunPage._medan_memegang)
    assert "page_source" in src
    assert "EditText" in src


# ---------------------------------------------------------------------------
# 10. Medan kesalahan — rutin berbukti, kegagalan LOUD
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("kaedah", ["fill_kompaun_tab",
                                    "fill_kompaun_tab_direct"])
def test_medan_kesalahan_melalui_rutin_berbukti(kaedah):
    """LOKASI/BUTIRAN mesti melalui `isi_medan_kesalahan()`.

    `fill_field_by_label` pulang BERJAYA dengan medan KOSONG pada skrin
    ini — disahkan empat kali pada device 2026-08-17. Ia tidak boleh
    digunakan untuk medan ini.
    """
    import inspect
    from pages.daftar_kompaun_page import DaftarKompaunPage

    src = inspect.getsource(getattr(DaftarKompaunPage, kaedah))
    kod = "\n".join(l.split("#", 1)[0] for l in src.splitlines())
    assert "isi_medan_kesalahan(_label" in kod
    assert "fill_field_by_label(_label" not in kod


def test_gulung_ke_atas_dipakai_dalam_rutin_kesalahan():
    """Gulung ke atas MESTI kekal: autocomplete jalan menggerakkan
    borang, dan membuangnya memulangkan TimeoutException (disahkan pada
    device 2026-08-17)."""
    import inspect
    from pages.daftar_kompaun_page import DaftarKompaunPage

    src = inspect.getsource(DaftarKompaunPage.isi_medan_kesalahan)
    kod = "\n".join(l.split("#", 1)[0] for l in src.splitlines())
    assert "gulung_borang_ke_atas()" in kod
    i_gulung = kod.index("gulung_borang_ke_atas()")
    i_cari = kod.index("self.find_element(")
    assert i_gulung < i_cari, "medan dicari sebelum digulung ke atas"


def test_gulung_helper_guna_instance_sifar():
    import inspect
    from pages.daftar_kompaun_page import DaftarKompaunPage

    src = inspect.getsource(DaftarKompaunPage.gulung_borang_ke_atas)
    assert "scrollToBeginning" in src
    assert "instance(0)" in src
    assert "3006" in src


@pytest.mark.parametrize("kaedah", ["fill_kompaun_tab",
                                    "fill_kompaun_tab_direct"])
def test_medan_kesalahan_disemak_semula_di_hujung_tab(kaedah):
    """Nilai mendarat lalu HILANG sebelum tab selesai (diukur
    2026-08-17). Mekanismenya belum dicirikan, jadi tab mesti MENYEMAK
    dan mengisi semula — bukan mengandaikan.

    Rekod N tidak terjejas (`PGP02N260817008` lengkap dalam DB
    production), jadi ini khusus skrin `Paparan Kompaun`.
    """
    import inspect
    from pages.daftar_kompaun_page import DaftarKompaunPage

    src = inspect.getsource(getattr(DaftarKompaunPage, kaedah))
    kod = "\n".join(l.split("#", 1)[0] for l in src.splitlines())
    assert "_sahkan_medan_kesalahan(" in kod, "tiada semakan akhir"
    i_tempoh = kod.index("_apply_tempoh_from_data(data)")
    i_semak = kod.index("_sahkan_medan_kesalahan(")
    assert i_semak > i_tempoh, (
        "semakan akhir mesti SELEPAS tempoh — itu titik di mana nilai "
        "diperhati hilang")


def test_sahkan_medan_kesalahan_menumpu_bukan_satu_laluan():
    """Mengisi semula medan TERAKHIR boleh mengosongkan yang PERTAMA
    sekali lagi. Semakan satu-laluan tidak akan menyedarinya, dan rekod
    diserah dengan medan kosong.

    Diukur 2026-08-17: setiap interaksi medan mengosongkan medan yang
    diisi sebelumnya.
    """
    import inspect
    from pages.daftar_kompaun_page import DaftarKompaunPage

    src = inspect.getsource(DaftarKompaunPage._sahkan_medan_kesalahan)
    kod = "\n".join(l.split("#", 1)[0] for l in src.splitlines())
    # Mesti gelung, bukan satu laluan.
    assert "for pusingan_ke in range" in kod
    # Berhenti hanya bila TIADA yang hilang — keadaan serentak.
    assert "if not hilang:" in kod
    # Dan gagal dengan LANTANG kalau tidak menumpu.
    assert "raise TimeoutException" in kod
    assert "TIDAK diserah" in src


def test_sahkan_medan_kesalahan_menumpu_pada_kes_selang_seli():
    """Sifat sebenar, diuji dengan simulasi: medan yang saling
    mengosongkan mesti akhirnya berisi SERENTAK."""
    from pages.daftar_kompaun_page import DaftarKompaunPage as D

    keadaan = {"a": False, "b": False}

    class Palsu:
        _sahkan_medan_kesalahan = D._sahkan_medan_kesalahan

        def _medan_memegang(self, nilai):
            return keadaan[nilai]

        def isi_medan_kesalahan(self, label, nilai):
            # Mengisi satu medan mengosongkan yang LAIN — corak yang
            # diperhati pada device.
            for k in keadaan:
                keadaan[k] = False
            keadaan[nilai] = True

    medan = (("A", "a"), ("B", "b"))
    data = {"a": "a", "b": "b"}
    # Dengan kelakuan ini, satu laluan TIDAK boleh menumpu; gelung
    # sepatutnya melontar dan bukan melaporkan berjaya secara palsu.
    with pytest.raises(Exception):
        Palsu()._sahkan_medan_kesalahan(medan, data, pusingan=3)


def test_tempoh_tidak_guna_tajuk_seksyen_sebagai_locator():
    """`LABEL_TEMPOH_NOTIS = "MAKLUMAT KOMPAUN"` ialah TAJUK SEKSYEN,
    bukan medan. Medan kekal kosong dan app menolak tab Penerima dengan
    `Ralat | Sila isi Tempoh Notis` (device 2026-08-17).

    Placeholder medan sebenar ialah `Tempoh Kompaun`.
    """
    import inspect
    from pages.daftar_kompaun_page import DaftarKompaunPage

    for kaedah in ("fill_kompaun_tab", "fill_kompaun_tab_direct"):
        src = inspect.getsource(getattr(DaftarKompaunPage, kaedah))
        assert "_isi_tempoh_berbukti(" in src, kaedah
    # Label berbeza antara borang (P guna "Tempoh Kompaun"; borang K
    # menggunakan sesuatu yang lain, belum dirakam). Rutin mesti mencuba
    # beberapa calon dan MENDUMP kalau semua gagal — bukan meneka lagi.
    assert "Tempoh Kompaun" in DaftarKompaunPage.LABEL_TEMPOH_CALON
    src = inspect.getsource(DaftarKompaunPage._isi_tempoh_berbukti)
    assert "tempoh_tidak_dijumpai.xml" in src, (
        "tiada dump bila label tidak dijumpai — larian seterusnya tidak "
        "akan merakam nama sebenarnya")


def test_tempoh_hanya_digit_dihantar():
    """Oracle K-001 membawa '1 HARI'. Menghantarnya bulat-bulat ke medan
    berangka akan ditolak oleh validasi medan."""
    import inspect
    from pages.daftar_kompaun_page import DaftarKompaunPage

    src = inspect.getsource(DaftarKompaunPage.fill_kompaun_tab)
    assert "c.isdigit()" in src


def test_dialog_validasi_tempoh_boleh_ditutup():
    """Dialog `Sila isi Tempoh Notis` ialah VALIDASI — menutupnya tidak
    menghantar apa-apa. Tanpa ini larian tersekat tanpa jalan keluar."""
    from guard import dasar

    ok, badan = dasar.konteks_alert_info(
        '<?xml version="1.0"?><hierarchy>'
        '<node resource-id="android:id/alertTitle" text="Ralat"/>'
        '<node resource-id="android:id/message" text="Sila isi Tempoh Notis"/>'
        '<node resource-id="android:id/button1" text="OK"/>'
        '</hierarchy>')
    assert ok, badan
    tetapan = dasar.Tetapan(dry_run=True, benarkan_serah=False,
                            izin_serah=False)
    kep = dasar.nilai(["OK"], tetapan, alert_info=badan)
    assert kep.benarkan


def test_dialog_penghantaran_masih_disekat():
    """Pengecualian dialog mesti tidak membuka dialog PENGHANTARAN."""
    from guard import dasar

    ok, badan = dasar.konteks_alert_info(
        '<?xml version="1.0"?><hierarchy>'
        '<node resource-id="android:id/alertTitle" text="Berjaya"/>'
        '<node resource-id="android:id/message" text="Data berjaya dihantar"/>'
        '<node resource-id="android:id/button1" text="OK"/>'
        '</hierarchy>')
    assert not ok


def test_kemaskini_tidak_menuntut_seterusnya():
    """Borang kemaskini MBPG pergi TERUS ke MENYERAHKAN.

    Bukti device 2026-08-18 (ui_dumps/kemaskini_no_seterusnya.xml,
    selepas menatal ke bawah): hujung borang ialah
    Pembantu Penguatkuasa / OPEN SIGNATURE / nama / no. KP / MENYERAHKAN.
    Tiada SETERUSNYA.

    Laluan MBJB mengandaikan satu langkah SETERUSNYA yang tidak wujud di
    sini, dan menuntutnya menjadikan P-004 dan K-004 mustahil.
    """
    import inspect
    from pages.kemaskini_page import KemaskiniPage

    src = inspect.getsource(KemaskiniPage.proceed_and_submit)
    kod = "\n".join(l.split("#", 1)[0] for l in src.splitlines())
    assert "ada_seterusnya" in kod
    # MENYERAHKAN mesti diterima sebagai laluan sah.
    assert "BUTTON_MENYERAHKAN" in kod
    # Dan ia hanya melontar kalau KEDUA-DUANYA tiada.
    assert "MAHUPUN MENYERAHKAN" in src


def test_nombor_kemaskini_dibaca_dari_db():
    """Kemaskini BERJAYA diserah pada 2026-08-18 tetapi nombor gantian
    tidak tertangkap — log merekod `(TIDAK TERTANGKAP)`.

    Rekod production yang tidak bernombor dalam log ialah rekod yang PM
    TIDAK BOLEH batalkan. DB ialah tempat rekod itu benar-benar wujud,
    dan ia cara yang sama yang peringkat cipta gunakan.

    Disahkan pada device: PGP02P260818006 -> statuskompaun 'B'
    (dibatalkan), PGP02P260818007 -> 'A' (gantian).
    """
    import inspect
    from tools import run_e2e

    src = inspect.getsource(run_e2e.peringkat_kemaskini)
    assert "_nombor_kemaskini_dari_db(serial" in src
    # Bandingkan KOD sahaja — komen dalam fungsi ini menyebut kedua-dua
    # nama, dan carian subrentetan naif memadan penjelasan itu.
    kod = chr(10).join(l.split("#", 1)[0] for l in src.splitlines())
    i_db = kod.index("_nombor_kemaskini_dari_db(")
    i_ui = kod.index("cari_nombor_baharu(")
    assert i_db < i_ui, "DB mesti dicuba SEBELUM carian senarai UI"
    # Carian UI kekal sebagai sandaran, bukan dibuang.
    assert "if not baharu:" in src


def test_nombor_kemaskini_dilog_walaupun_none():
    """Nombor yang gagal ditangkap TETAP dilog, dengan sebabnya.
    Jurang dalam penomboran rasmi ialah dapatan, bukan sesuatu untuk
    disenyapkan."""
    import inspect
    from tools import run_e2e

    src = inspect.getsource(run_e2e.peringkat_kemaskini)
    assert "rekod_log.log_rekod(" in src
    assert "hasil-kemaskini" in src


def test_tempoh_disahkan_bukan_diandaikan():
    """`_apply_tempoh_from_data` TIDAK melontar bila medan tidak
    dijumpai — ia mencetak `leaving as-is` dan pulang biasa.

    Larian K 2026-08-18 oleh itu tidak pernah mencapai cabang dump, dan
    label sebenar medan tempoh borang Letak Kereta kekal tidak dirakam.
    Bergantung pada exception untuk mengesan kegagalan senyap ialah
    kesilapan yang sama seperti `verify` dalam fill_field_by_label.
    """
    import inspect
    from pages.daftar_kompaun_page import DaftarKompaunPage

    src = inspect.getsource(DaftarKompaunPage._isi_tempoh_berbukti)
    assert "_medan_memegang(nilai)" in src, (
        "tiada pengesahan nilai — kegagalan senyap tidak akan dikesan")
    kod = chr(10).join(l.split("#", 1)[0] for l in src.splitlines())
    i_lama = kod.index("_apply_tempoh_from_data(data)")
    i_sah = kod.index("_medan_memegang(nilai)")
    assert i_sah > i_lama, "pengesahan mesti SELEPAS laluan lama dicuba"
    assert "tempoh_tidak_dijumpai.xml" in src


def test_medan_memegang_tidak_lulus_palsu_pada_nilai_pendek():
    """Padanan subrentetan tidak boleh mengesahkan nilai pendek.

    Tempoh K-001 ialah '1 HARI' -> digit '1'. Medan poskod '81700'
    MENGANDUNGI '1', jadi pengesahan lulus secara palsu dan cabang dump
    tidak pernah dicapai — larian K 2026-08-18 melaporkan tempoh
    berjaya sedangkan medan kekal kosong.
    """
    import xml.etree.ElementTree as ET
    from pages.daftar_kompaun_page import DaftarKompaunPage

    xml = ('<?xml version="1.0"?><hierarchy>'
           '<node class="android.widget.EditText" text="81700"/>'
           '<node class="android.widget.EditText" text="PASIR GUDANG"/>'
           '</hierarchy>')

    class Palsu:
        _medan_memegang = DaftarKompaunPage._medan_memegang

        class driver:
            page_source = xml

    p = Palsu()
    # '1' TIDAK boleh dianggap hadir hanya kerana '81700' mengandunginya.
    assert p._medan_memegang("1") is False
    # Nilai penuh yang memang ada masih dikesan.
    assert p._medan_memegang("81700") is True
    # Nilai panjang kekal padanan subrentetan (medan boleh dipotong).
    assert p._medan_memegang("PASIR GUD") is True


def test_semakan_kesalahan_gulung_dahulu():
    """`page_source` uiautomator MEMBUANG node yang tidak kelihatan.

    Selepas tab diisi, medan kesalahan berada di luar viewport, jadi
    `_medan_memegang` melaporkannya HILANG walaupun terisi — gelung
    penumpuan kemudian mengisi semula tanpa henti lalu melontar.

    Pemilik memerhati device 2026-08-18 dan melaporkan medan MEMANG
    terisi. "Tidak kelihatan" BUKAN "kosong" — PAPAN.md §15 sudah
    merekod kesilapan ini untuk baca-balik.
    """
    import inspect
    from pages.daftar_kompaun_page import DaftarKompaunPage

    src = inspect.getsource(DaftarKompaunPage._sahkan_medan_kesalahan)
    kod = chr(10).join(l.split("#", 1)[0] for l in src.splitlines())
    i_gulung = kod.index("gulung_borang_ke_atas()")
    i_semak = kod.index("_medan_memegang(")
    assert i_gulung < i_semak, (
        "semakan dibuat sebelum medan digulung ke dalam viewport")

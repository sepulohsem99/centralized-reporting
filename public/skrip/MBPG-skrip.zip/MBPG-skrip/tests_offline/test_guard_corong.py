"""
Ujian corong tap — proksi driver/elemen, tanpa peranti.

Dasar (dasar.py) diuji berasingan dalam test_guard_dasar.py. Fail ini
menguji perkara yang berbeza dan lebih penting: bahawa setiap PRIMITIF
tap benar-benar sampai kepada dasar itu. Dasar yang sempurna tidak
bernilai kalau satu laluan tap memintasnya.
"""

import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from guard import corong as C                                   # noqa: E402
from guard.dasar import DryRunViolation, Tetapan                # noqa: E402


# ---------------------------------------------------------------------------
# Peranti palsu
# ---------------------------------------------------------------------------

def xml_skrin(butang_teks="SERAH", bounds="[100,200][300,260]"):
    """Satu skrin borang dengan satu butang bernama."""
    return (
        '<hierarchy>'
        '<node class="android.widget.FrameLayout" bounds="[0,0][1080,2400]">'
        '  <node class="android.widget.TextView" text="Daftar Notis Amaran"'
        '        bounds="[0,0][1080,100]"/>'
        '  <node class="android.widget.EditText" text="NAMA PESALAH"'
        '        bounds="[0,120][1080,180]"/>'
        f'  <node class="android.view.ViewGroup" clickable="true" text=""'
        f'        bounds="{bounds}">'
        f'    <node class="android.widget.TextView" text="{butang_teks}"'
        f'          bounds="{bounds}"/>'
        '  </node>'
        '</node></hierarchy>')


class ElemenPalsu:
    def __init__(self, teks="", desc="", rect=None, eid="e1"):
        self._teks = teks
        self._desc = desc
        self.rect = rect or {"x": 100, "y": 200, "width": 200, "height": 60}
        self.id = eid
        self.diklik = 0

    @property
    def text(self):
        return self._teks

    def get_attribute(self, nama):
        return self._desc if nama in ("content-desc", "contentDescription") else None

    def click(self):
        self.diklik += 1

    def find_element(self, *a, **kw):
        return self

    def find_elements(self, *a, **kw):
        return [self]


class DriverPalsu:
    def __init__(self, src=None):
        self.page_source = src if src is not None else xml_skrin()
        self.tap_dibuat = []
        self.skrip_dibuat = []
        self.keycode_dibuat = []
        self.execute_dibuat = []
        self.swipe_dibuat = []
        self.elemen = ElemenPalsu()

    def find_element(self, *a, **kw):
        return self.elemen

    def find_elements(self, *a, **kw):
        return [self.elemen]

    def tap(self, positions, duration=None):
        self.tap_dibuat.append(positions)

    def execute_script(self, script, *args):
        self.skrip_dibuat.append((script, args))

    def press_keycode(self, keycode, *a):
        self.keycode_dibuat.append(keycode)

    def execute(self, command, params=None):
        self.execute_dibuat.append((command, params))

    def swipe(self, x1, y1, x2, y2, duration=0):
        self.swipe_dibuat.append((x1, y1, x2, y2))

    def get_screenshot_as_file(self, path):
        with open(path, "wb") as fh:
            fh.write(b"\x89PNG-palsu")
        return True


@pytest.fixture
def bina(tmp_path):
    """Pulangkan (driver_berkawal, driver_palsu) dengan reports sementara."""
    def _bina(src=None, benarkan_serah=False, elemen=None):
        drv = DriverPalsu(src)
        if elemen is not None:
            drv.elemen = elemen
        t = Tetapan(dry_run=True, benarkan_serah=benarkan_serah,
                    izin_serah=False)
        g = C.pasang(drv, tetapan=t, dir_reports=str(tmp_path))
        return g, drv
    return _bina


# ---------------------------------------------------------------------------
# Laluan 1 — el.click()
# ---------------------------------------------------------------------------

def test_click_pada_butang_selamat_diteruskan(bina):
    g, drv = bina(elemen=ElemenPalsu(teks="Daftar Notis Amaran"))
    g.find_element("id", "x").click()
    assert drv.elemen.diklik == 1


def test_click_pada_hantar_disekat(bina):
    g, drv = bina(elemen=ElemenPalsu(teks="HANTAR"))
    with pytest.raises(DryRunViolation, match="HANTAR"):
        g.find_element("id", "x").click()
    assert drv.elemen.diklik == 0, "tap SAMPAI ke peranti — gerbang bocor"


def test_click_pada_serah_disekat_secara_default(bina):
    g, drv = bina(elemen=ElemenPalsu(teks="SERAH"))
    with pytest.raises(DryRunViolation, match="SERAH"):
        g.find_element("id", "x").click()
    assert drv.elemen.diklik == 0


def test_click_pada_serah_diteruskan_bila_dibuka(bina):
    g, drv = bina(benarkan_serah=True, elemen=ElemenPalsu(teks="SERAH"))
    g.find_element("id", "x").click()
    assert drv.elemen.diklik == 1


def test_elemen_tanpa_teks_dileraikan_melalui_xml(bina):
    """Bekas RN tanpa teks sendiri: label ada pada anaknya. Kalau corong
    hanya membaca .text ia akan nampak "" dan membenarkan HANTAR."""
    kosong = ElemenPalsu(teks="", desc="",
                         rect={"x": 100, "y": 200, "width": 200, "height": 60})
    g, drv = bina(src=xml_skrin("HANTAR"), elemen=kosong)
    with pytest.raises(DryRunViolation, match="HANTAR"):
        g.find_element("id", "x").click()
    assert kosong.diklik == 0


# ---------------------------------------------------------------------------
# Laluan 2 — driver.tap([(x, y)])
# ---------------------------------------------------------------------------

def test_tap_koordinat_atas_hantar_disekat(bina):
    g, drv = bina(src=xml_skrin("HANTAR"))
    with pytest.raises(DryRunViolation, match="HANTAR"):
        g.tap([(200, 230)])
    assert drv.tap_dibuat == [], "tap koordinat SAMPAI ke peranti"


def test_tap_koordinat_atas_medan_diteruskan(bina):
    g, drv = bina(src=xml_skrin("HANTAR"))
    g.tap([(500, 150)])           # medan NAMA PESALAH, bukan butang
    assert drv.tap_dibuat == [[(500, 150)]]


def test_tap_koordinat_di_luar_setiap_node_disekat(bina):
    """Koordinat yang tidak memadan mana-mana node bermakna kita tidak
    tahu apa yang kita tekan. Pada production itu bukan 'mungkin
    selamat'."""
    g, drv = bina(src=xml_skrin("HANTAR"))
    with pytest.raises(DryRunViolation, match="TIDAK-PASTI"):
        g.tap([(9999, 9999)])
    assert drv.tap_dibuat == []


# ---------------------------------------------------------------------------
# Laluan 3 — mobile: clickGesture
# ---------------------------------------------------------------------------

def test_click_gesture_koordinat_disekat(bina):
    g, drv = bina(src=xml_skrin("SAHKAN"))
    with pytest.raises(DryRunViolation, match="SAHKAN"):
        g.execute_script("mobile: clickGesture", {"x": 200, "y": 230})
    assert drv.skrip_dibuat == []


def test_click_gesture_selamat_diteruskan(bina):
    g, drv = bina(src=xml_skrin("HANTAR"))
    g.execute_script("mobile: clickGesture", {"x": 500, "y": 150})
    assert len(drv.skrip_dibuat) == 1


def test_skrip_bukan_tap_tidak_disentuh(bina):
    """mobile: scrollGesture / getDeviceTime dsb mesti lulus tanpa kos."""
    g, drv = bina()
    g.execute_script("mobile: scrollGesture", {"direction": "down"})
    g.execute_script("mobile: getDeviceTime")
    assert len(drv.skrip_dibuat) == 2


# ---------------------------------------------------------------------------
# Laluan 4 — press_keycode
# ---------------------------------------------------------------------------

def test_keycode_enter_atas_medan_biasa_diteruskan(bina):
    src = ('<hierarchy><node class="android.widget.EditText" focused="true"'
           ' text="NAMA PESALAH" bounds="[0,0][100,100]"/></hierarchy>')
    g, drv = bina(src=src)
    g.press_keycode(66)
    assert drv.keycode_dibuat == [66]


def test_keycode_enter_atas_butang_hantar_disekat(bina):
    src = ('<hierarchy><node class="android.widget.Button" focused="true"'
           ' text="HANTAR" bounds="[0,0][100,100]"/></hierarchy>')
    g, drv = bina(src=src)
    with pytest.raises(DryRunViolation, match="HANTAR"):
        g.press_keycode(66)
    assert drv.keycode_dibuat == []


def test_keycode_enter_tanpa_fokus_yang_boleh_dibaca_disekat(bina):
    """Berbeza daripada tap biasa, ENTER gagal-TERTUTUP. Tiada TC dalam
    skop MBPG memerlukan ENTER, jadi tiada kos; dan butang RN yang
    difokus selalunya tidak berteks, yang tepat kes berbahaya."""
    g, drv = bina(src='<hierarchy><node text="x" bounds="[0,0][10,10]"/></hierarchy>')
    with pytest.raises(DryRunViolation, match="TIDAK-PASTI"):
        g.press_keycode(66)
    assert drv.keycode_dibuat == []


def test_keycode_tidak_berbahaya_tidak_disentuh(bina):
    g, drv = bina()
    g.press_keycode(4)      # BACK
    g.press_keycode(67)     # DEL
    assert drv.keycode_dibuat == [4, 67]


# ---------------------------------------------------------------------------
# Laluan 5 — ActionChains (W3C actions) — laluan tandatangan
# ---------------------------------------------------------------------------

def _urutan(*titik):
    aksi = []
    for (x, y) in titik:
        aksi += [{"type": "pointerMove", "x": x, "y": y},
                 {"type": "pointerDown"}, {"type": "pointerUp"}]
    return {"actions": [{"type": "pointer", "actions": aksi}]}


def test_action_chains_atas_butang_hantar_disekat(bina):
    """_draw_signature memakai ActionChains, yang tidak menyentuh
    driver.tap() mahupun execute_script(). Tanpa cangkuk `execute`,
    pointer-up di atas butang hantar ialah klik yang tidak dikawal."""
    g, drv = bina(src=xml_skrin("HANTAR"))
    with pytest.raises(DryRunViolation, match="HANTAR"):
        g.execute("actions", _urutan((200, 230)))
    assert drv.execute_dibuat == []


def test_action_chains_atas_kanvas_tandatangan_diteruskan(bina):
    """Lukisan tandatangan sebenar berlaku atas kanvas kosong."""
    g, drv = bina(src=xml_skrin("HANTAR"))
    g.execute("actions", _urutan((500, 150), (600, 150)))
    assert len(drv.execute_dibuat) == 1


def test_execute_bukan_actions_tidak_disentuh(bina):
    g, drv = bina()
    g.execute("getPageSource", {})
    assert len(drv.execute_dibuat) == 1


# ---------------------------------------------------------------------------
# Laluan 6 — swipe degenerat
# ---------------------------------------------------------------------------

def test_swipe_biasa_diteruskan(bina):
    g, drv = bina()
    g.swipe(540, 1400, 540, 600, 600)
    assert drv.swipe_dibuat == [(540, 1400, 540, 600)]


def test_swipe_degenerat_atas_hantar_disekat(bina):
    """Bekas berketinggian sifar menjadikan mula == tamat, dan Android
    mendaftarkan itu sebagai ketukan."""
    g, drv = bina(src=xml_skrin("HANTAR"))
    with pytest.raises(DryRunViolation, match="HANTAR"):
        g.swipe(200, 230, 200, 230, 600)
    assert drv.swipe_dibuat == []


# ---------------------------------------------------------------------------
# Sifat yang membuat gerbang ini berfungsi
# ---------------------------------------------------------------------------

def test_pelanggaran_tidak_boleh_ditelan(bina):
    """SIFAT PALING PENTING DALAM FAIL INI.

    pages\\base_page.py mengandungi 66 blok `except Exception`, dan
    setiap gelung cuba-semula dibina di atasnya. Kalau DryRunViolation
    ialah Exception, gelung itu menelannya dan MENCUBA LAGI — gerbang
    menyekat setiap percubaan dengan betul sementara run meneruskan
    seolah-olah tiada apa berlaku."""
    assert not issubclass(DryRunViolation, Exception), \
        "DryRunViolation ialah Exception — 66 blok `except Exception` " \
        "dalam base_page.py akan menelannya"
    assert issubclass(DryRunViolation, BaseException)

    g, drv = bina(elemen=ElemenPalsu(teks="HANTAR"))
    ditelan = False
    try:
        try:
            g.find_element("id", "x").click()
        except Exception:                    # noqa: BLE001 — corak base_page
            ditelan = True
    except DryRunViolation:
        pass
    assert not ditelan, "pelanggaran ditelan oleh `except Exception`"


def test_gelung_cuba_semula_tidak_boleh_meneruskan(bina):
    """Simulasi wait_and_tap (×3) / proceed_and_submit (×4 pusingan)."""
    g, drv = bina(elemen=ElemenPalsu(teks="HANTAR"))
    percubaan = 0
    with pytest.raises(DryRunViolation):
        for _ in range(3):
            percubaan += 1
            try:
                g.find_element("id", "x").click()
            except Exception:                # noqa: BLE001
                continue
    assert percubaan == 1, "gelung cuba-semula meneruskan selepas pelanggaran"
    assert drv.elemen.diklik == 0


# ---------------------------------------------------------------------------
# Batal serta-merta
# ---------------------------------------------------------------------------

def test_pelanggaran_membatalkan_run_secara_kekal(bina):
    g, drv = bina(elemen=ElemenPalsu(teks="HANTAR"))
    with pytest.raises(DryRunViolation):
        g.find_element("id", "x").click()
    # Setiap tap SELEPAS pelanggaran ditolak, walaupun ia selamat.
    drv.elemen = ElemenPalsu(teks="Daftar Notis Amaran")
    with pytest.raises(DryRunViolation, match="sudah DIBATALKAN"):
        g.find_element("id", "x").click()
    with pytest.raises(DryRunViolation, match="sudah DIBATALKAN"):
        g.tap([(500, 150)])


def test_forensik_ditulis_pada_pelanggaran(bina, tmp_path):
    g, drv = bina(elemen=ElemenPalsu(teks="HANTAR"))
    g.corong.tc_semasa = "N-001"
    with pytest.raises(DryRunViolation):
        g.find_element("id", "x").click()
    fail = list((tmp_path / "forensik").iterdir())
    sufiks = sorted(f.suffix for f in fail)
    assert sufiks == [".png", ".txt", ".xml"], f"forensik tidak lengkap: {fail}"
    assert any("N-001" in f.name for f in fail)


def test_ledger_merekod_setiap_tap(bina, tmp_path):
    g, drv = bina(src=xml_skrin("HANTAR"))
    g.tap([(500, 150)])                       # dibenarkan
    with pytest.raises(DryRunViolation):
        g.tap([(200, 230)])                   # disekat
    baris = (tmp_path / "tap_ledger.jsonl").read_text(encoding="utf-8").strip().split("\n")
    assert len(baris) == 2
    import json
    assert json.loads(baris[0])["benarkan"] is True
    assert json.loads(baris[1])["benarkan"] is False
    assert json.loads(baris[1])["peraturan"] == "HANTAR"


# ---------------------------------------------------------------------------
# Ketelusan proksi
# ---------------------------------------------------------------------------

def test_proksi_meneruskan_atribut_tidak_dikenali(bina):
    g, drv = bina()
    assert g.page_source == drv.page_source
    el = g.find_element("id", "x")
    assert el.rect == drv.elemen.rect
    assert el.text == drv.elemen.text


def test_find_elements_membungkus_setiap_hasil(bina):
    g, drv = bina(elemen=ElemenPalsu(teks="HANTAR"))
    hasil = g.find_elements("id", "x")
    assert all(isinstance(e, C.ElemenBerkawal) for e in hasil)
    with pytest.raises(DryRunViolation):
        hasil[0].click()


def test_elemen_bersarang_juga_dibungkus(bina):
    """el.find_element(...) tidak boleh mengeluarkan elemen telanjang."""
    g, drv = bina(elemen=ElemenPalsu(teks="HANTAR"))
    induk = g.find_element("id", "x")
    anak = induk.find_element("id", "y")
    assert isinstance(anak, C.ElemenBerkawal)
    with pytest.raises(DryRunViolation):
        anak.click()


# ---------------------------------------------------------------------------
# Ujian-kena XML
# ---------------------------------------------------------------------------

def test_teks_di_koordinat_memilih_node_terdalam():
    teks, jumpa = C.teks_di_koordinat(xml_skrin("SERAH"), 200, 230)
    assert jumpa
    assert "SERAH" in teks
    assert "Daftar Notis Amaran" not in teks, \
        "memungut teks moyang akan menyekat seluruh skrin"


def test_teks_di_koordinat_naik_kepada_moyang_clickable():
    """Node terdalam pada (200,230) ialah TextView berlabel; tetapi kalau
    ia kosong, corong mesti naik kepada bekas clickable."""
    src = ('<hierarchy><node bounds="[0,0][1080,2400]">'
           '<node clickable="true" text="" bounds="[100,200][300,260]">'
           '<node text="OK" bounds="[100,200][300,260]"/>'
           '</node></node></hierarchy>')
    teks, jumpa = C.teks_di_koordinat(src, 200, 230)
    assert jumpa and "OK" in teks


def test_xml_rosak_dilayan_sebagai_tidak_jumpa():
    teks, jumpa = C.teks_di_koordinat("<hierarchy><node", 10, 10)
    assert not jumpa


# ---------------------------------------------------------------------------
# Semakan penerimaan: tiada laluan yang memintas Appium
# ---------------------------------------------------------------------------

AKAR = os.path.join(os.path.dirname(__file__), "..")


def _literal_kod(laluan):
    """Setiap literal rentetan yang BENAR-BENAR dinilai sebagai kod.

    Docstring dan komen dikecualikan. Ini penting: base_page.py
    memperkatakan `adb shell input swipe` panjang lebar dalam
    docstringnya (baris 587/639/645) sambil TIDAK pernah menjalankannya.
    Imbasan berasaskan baris mentah membaca prosa itu sebagai kod dan
    menimbulkan penggera palsu — yang, diulang cukup kerap, mengajar
    orang mengabaikan gerbang ini."""
    import ast
    with open(laluan, encoding="utf-8", errors="replace") as fh:
        pokok = ast.parse(fh.read(), filename=laluan)
    docstrings = set()
    for n in ast.walk(pokok):
        if isinstance(n, (ast.Module, ast.FunctionDef, ast.AsyncFunctionDef,
                          ast.ClassDef)):
            d = ast.get_docstring(n, clean=False)
            if d is not None:
                docstrings.add(d)
    for n in ast.walk(pokok):
        if isinstance(n, ast.Constant) and isinstance(n.value, str):
            if n.value not in docstrings:
                yield n.lineno, n.value


def test_tiada_adb_input_tap_dalam_kod():
    """`adb shell input tap` memintas Appium sepenuhnya, dan oleh itu
    memintas corong. Tiada dalam projek ini; ujian ini memastikan ia
    kekal begitu."""
    import re as _re
    corak = _re.compile(r"^(tap|keyevent)$")
    pelanggar = []
    for folder in ("pages", "tests", "testdata", "guard", "."):
        d = os.path.join(AKAR, folder)
        if not os.path.isdir(d):
            continue
        for nama in sorted(os.listdir(d)):
            if not nama.endswith(".py"):
                continue
            for lineno, nilai in _literal_kod(os.path.join(d, nama)):
                if corak.match(nilai.strip()):
                    pelanggar.append(f"{folder}/{nama}:{lineno} {nilai!r}")
    assert not pelanggar, ("hujah `adb shell input tap/keyevent` dalam kod "
                           "sebenar — memintas corong: " + ", ".join(pelanggar))


def test_satu_satunya_laluan_adb_input_ialah_swipe_terkawal():
    """Inventori jujur: SATU laluan dalam projek ini memintas Appium,
    iaitu `adb shell input swipe` dalam device_utils.measure_scroll().
    Ia swipe (bukan tap) dan kini menolak kes degenerat mula==tamat.

    Kalau ujian ini gagal, laluan pintasan BAHARU telah muncul dan
    inventori dalam docstring guard/corong.py sudah tidak benar."""
    import ast
    jumpa = set()
    for folder in ("pages", "tests", "testdata", "guard", "."):
        d = os.path.join(AKAR, folder)
        if not os.path.isdir(d):
            continue
        for nama in sorted(os.listdir(d)):
            if not nama.endswith(".py"):
                continue
            p = os.path.join(d, nama)
            baris_input = {ln for ln, v in _literal_kod(p) if v.strip() == "input"}
            if not baris_input:
                continue
            # Namakan fungsi yang mengandunginya, bukan nombor baris:
            # nombor baris beralih setiap kali sesiapa menyunting fail dan
            # menjadikan gerbang ini bising tanpa sebab.
            with open(p, encoding="utf-8", errors="replace") as fh:
                pokok = ast.parse(fh.read(), filename=p)
            for n in ast.walk(pokok):
                if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    akhir = getattr(n, "end_lineno", n.lineno)
                    if any(n.lineno <= ln <= akhir for ln in baris_input):
                        jumpa.add(f"{os.path.basename(p)}::{n.name}")
    assert jumpa == {"device_utils.py::measure_scroll"}, (
        f"laluan `adb shell input` berubah: {sorted(jumpa)}. Kemas kini "
        f"seksyen 'APA YANG CORONG INI TIDAK LINDUNGI' dalam "
        f"guard/corong.py, dan sahkan laluan baharu itu tidak boleh "
        f"menghasilkan tap.")


def test_swipe_degenerat_ditolak():
    """mula == tamat bermakna Android mendaftarkannya sebagai TAP pada
    laluan adb yang memintas corong."""
    sys.path.insert(0, AKAR)
    import device_utils
    hasil = device_utils.measure_scroll("SERIALPALSU", (540, 900, 540, 900, 600))
    assert hasil["ok"] is False
    assert "degenerat" in hasil["sebab"]
    assert "TAP" in hasil["sebab"]


# ===========================================================================
# PENGECUALIAN SIMPAN-TETAPAN, DIUJI MELALUI PROKSI SEBENAR
# Ujian dasar membuktikan peraturan. Ujian ini membuktikan corong
# benar-benar MENGIRA konteks itu daripada skrin, pada setiap laluan tap.
# ===========================================================================

XML_TETAPAN_IP = (
    '<hierarchy><node bounds="[0,0][1080,2400]">'
    '  <node class="android.widget.EditText" resource-id="text-input-outlined"'
    '        text="msc" bounds="[0,100][1080,160]"/>'
    '  <node resource-id="modal-surface" bounds="[0,300][1080,900]">'
    '    <node text="INTERNAL IP ADDRESS" bounds="[0,320][1080,360]"/>'
    '    <node class="android.widget.EditText" resource-id="text-input-outlined"'
    '          text="113.211.155.174" bounds="[0,370][1080,430]"/>'
    '    <node text="EXTERNAL IP ADDRESS" bounds="[0,440][1080,480]"/>'
    '    <node class="android.widget.EditText" resource-id="text-input-outlined"'
    '          text="113.211.155.174" bounds="[0,490][1080,550]"/>'
    '    <node class="android.widget.Button" text="SIMPAN"'
    '          bounds="[400,700][680,780]"/>'
    '  </node>'
    '</node></hierarchy>')

XML_BORANG_DENGAN_SIMPAN = (
    '<hierarchy><node bounds="[0,0][1080,2400]">'
    '  <node text="Daftar Kompaun Letak Kereta" bounds="[0,0][1080,100]"/>'
    '  <node class="android.widget.EditText" text="NAMA PESALAH"'
    '        bounds="[0,120][1080,180]"/>'
    '  <node class="android.widget.Button" text="SIMPAN"'
    '        bounds="[400,700][680,780]"/>'
    '</node></hierarchy>')


def test_simpan_diteruskan_pada_skrin_tetapan(bina):
    """POSITIF: T-001/T-002 mesti benar-benar boleh menekan SIMPAN."""
    g, drv = bina(src=XML_TETAPAN_IP, elemen=ElemenPalsu(teks="SIMPAN"))
    g.find_element("id", "simpan").click()
    assert drv.elemen.diklik == 1


def test_simpan_disekat_dalam_borang_kompaun(bina):
    """NEGATIF: pengecualian tidak boleh bocor keluar dari skrin Tetapan."""
    g, drv = bina(src=XML_BORANG_DENGAN_SIMPAN,
                  elemen=ElemenPalsu(teks="SIMPAN"))
    with pytest.raises(DryRunViolation, match="SIMPAN"):
        g.find_element("id", "simpan").click()
    assert drv.elemen.diklik == 0


def test_simpan_tetapan_juga_diteruskan_melalui_tap_koordinat(bina):
    """Konteks dikira pada SETIAP laluan tap, bukan hanya el.click."""
    g, drv = bina(src=XML_TETAPAN_IP)
    g.tap([(540, 740)])                       # butang SIMPAN
    assert drv.tap_dibuat == [[(540, 740)]]


def test_simpan_borang_disekat_melalui_tap_koordinat(bina):
    g, drv = bina(src=XML_BORANG_DENGAN_SIMPAN)
    with pytest.raises(DryRunViolation, match="SIMPAN"):
        g.tap([(540, 740)])
    assert drv.tap_dibuat == []


def test_hantar_kekal_disekat_walaupun_pada_skrin_tetapan(bina):
    """Pengecualian tetapan melonggarkan SIMPAN SAHAJA."""
    g, drv = bina(src=XML_TETAPAN_IP, elemen=ElemenPalsu(teks="HANTAR"))
    with pytest.raises(DryRunViolation, match="HANTAR"):
        g.find_element("id", "x").click()
    assert drv.elemen.diklik == 0


# ===========================================================================
# SELARAS PELESEN — tiga lapisan pengecualian
# ===========================================================================

def test_tap_pada_item_menu_pelesen_disekat_oleh_corong(bina):
    """Lapisan 3: walaupun sesuatu cuba mengetuknya, ia tidak sampai."""
    g, drv = bina(elemen=ElemenPalsu(teks="SELARAS MAKLUMAT PELESEN"))
    with pytest.raises(DryRunViolation, match="SELARAS-PELESEN"):
        g.find_element("id", "x").click()
    assert drv.elemen.diklik == 0


def test_kaedah_selaras_pelesen_melempar():
    """Lapisan 2: kaedah page-object itu sendiri lumpuh."""
    import ast
    src = open(os.path.join(AKAR, "pages", "pelarasan_page.py"),
               encoding="utf-8").read()
    pokok = ast.parse(src)
    for n in ast.walk(pokok):
        if isinstance(n, ast.FunctionDef) and n.name in (
                "selaras_maklumat_pelesen", "run_full_pelarasan"):
            jenis = [type(x).__name__ for x in ast.walk(n)]
            assert "Raise" in jenis, f"{n.name} tidak melempar"
            # dan ia tidak boleh lagi memandu peranti
            panggilan = {(getattr(c.func, "attr", None)
                          or getattr(c.func, "id", None))
                         for c in ast.walk(n) if isinstance(c, ast.Call)}
            haram = {"_run_selaras_item", "set_tetapan_alamat_ip",
                     "set_tetapan_pelbagai", "open_menu_selaras"}
            assert not (panggilan & haram), \
                f"{n.name} masih memanggil {panggilan & haram}"


def test_t008_dikeluarkan_daripada_urutan_selaras():
    """Lapisan 1: T-008 tiada dalam senarai langkah conftest."""
    import ast
    src = open(os.path.join(AKAR, "tests", "conftest.py"),
               encoding="utf-8").read()
    panggilan = {(getattr(c.func, "attr", None) or getattr(c.func, "id", None))
                 for c in ast.walk(ast.parse(src)) if isinstance(c, ast.Call)}
    assert "selaras_maklumat_pelesen" not in panggilan
    assert "run_full_pelarasan" not in panggilan
    # dan tiada rujukan tidak-dipanggil yang tinggal dalam senarai steps
    assert "p.selaras_maklumat_pelesen)" not in src, \
        "rujukan pelesen masih dalam senarai steps"


def test_tiada_laluan_selaras_semua():
    """Arahan pemilik: tekan modul satu-satu, jangan guna selaras-semua."""
    import ast
    pelanggar = []
    for nama in ("pelarasan_page.py", "home_page.py"):
        p = os.path.join(AKAR, "pages", nama)
        src = open(p, encoding="utf-8").read()
        for n in ast.walk(ast.parse(src)):
            if isinstance(n, ast.FunctionDef):
                badan = ast.dump(n)
                if badan.count("_run_selaras_item") > 1:
                    pelanggar.append(f"{nama}::{n.name}")
    assert not pelanggar, (
        f"fungsi yang menjalankan >1 modul selaras dalam satu panggilan "
        f"(corak 'selaras semua'): {pelanggar}")


# ===========================================================================
# REGRESI DARI DEVICE SEBENAR — positif palsu backdrop modal (2026-08-10)
# ===========================================================================

XML_MODAL_MENU_SELARAS = (
    '<hierarchy>'
    '<node class="android.widget.FrameLayout" bounds="[0,0][1080,2400]">'
    '  <node resource-id="modal" bounds="[0,108][1080,2316]">'
    '    <node class="android.widget.Button" resource-id="modal-backdrop"'
    '          text="Close modal" clickable="true" bounds="[0,108][1080,2316]">'
    '      <node resource-id="modal-wrapper" bounds="[0,108][1080,2316]">'
    '        <node resource-id="modal-surface" bounds="[78,588][1002,1836]">'
    '          <node text="Menu Selaras" bounds="[150,669][930,759]"/>'
    '          <node text="Tetapan Alamat IP" clickable="true"'
    '                bounds="[150,765][930,849]"/>'
    '          <node text="Selaras Maklumat Pelesen" clickable="true"'
    '                bounds="[150,1425][930,1509]"/>'
    '          <node text="Tetapan Skrin Utama" clickable="true"'
    '                bounds="[150,1593][930,1677]"/>'
    '          <node text="Semak Kemaskini Versi Terkini" clickable="true"'
    '                bounds="[150,1677][930,1761]"/>'
    '        </node>'
    '      </node>'
    '    </node>'
    '  </node>'
    '</node></hierarchy>')


def test_tap_backdrop_tidak_memungut_teks_item_menu():
    """REGRESI. Menutup modal mengetuk backdrop pada (540,2076). Item
    menu hidup pada y 669..1761 — ia tidak berada di bawah tap itu.

    Versi pertama teks_di_koordinat() memungut SEMUA keturunan node
    terdalam, jadi ia melihat 'Semak Kemaskini Versi Terkini' dan
    menyekat penutupan modal sebagai pelanggaran KEMASKINI. Itu berlaku
    pada device 2026-08-10 dan membunuh run."""
    teks, jumpa = C.teks_di_koordinat(XML_MODAL_MENU_SELARAS, 540, 2076)
    assert jumpa
    assert "Close modal" in teks
    for bocor in ("Semak Kemaskini Versi Terkini", "Tetapan Skrin Utama",
                  "Selaras Maklumat Pelesen", "Tetapan Alamat IP"):
        assert bocor not in teks, f"teks {bocor!r} bocor dari luar titik tap"


def test_tap_backdrop_dibenarkan_oleh_dasar(bina):
    """Hujung ke hujung: menutup modal mesti BOLEH dilakukan."""
    g, drv = bina(src=XML_MODAL_MENU_SELARAS)
    g.tap([(540, 2076)])
    assert drv.tap_dibuat == [[(540, 2076)]]


def test_tap_pada_item_menu_sebenar_masih_dinilai(bina):
    """Sisi lain: mengetuk item menu Pelesen SEBENAR mesti tetap
    disekat. Pembetulan tidak boleh membutakan corong."""
    g, drv = bina(src=XML_MODAL_MENU_SELARAS)
    with pytest.raises(DryRunViolation, match="SELARAS-PELESEN"):
        g.tap([(540, 1467)])          # tengah baris Selaras Maklumat Pelesen
    assert drv.tap_dibuat == []


def test_tap_pada_semak_kemaskini_kini_dibenarkan(bina):
    """DIUBAH 2026-08-10 — dahulunya menuntut sekatan.

    Ujian asal ditulis sebagai pasangan kepada pembetulan kebocoran
    backdrop; ia merekod apa yang corong LAKUKAN ketika itu, bukan
    keputusan tentang T-011. Pemilik kemudian meluluskan T-011 (Semak
    Kemaskini) secara eksplisit sebagai read-only, dan sekatan itu
    membatalkan run peringkat 6 pada item menu yang diluluskan.

    Trip-wire KEMASKINI menyasarkan PINDAAN REKOD. Ini menyemak versi
    app. Jaminan anti-buta yang penting kekal diuji oleh ujian Pelesen
    tepat di atas: ketukan item menu sebenar MASIH dinilai, dan
    Pelesen masih membunuh run.
    """
    g, drv = bina(src=XML_MODAL_MENU_SELARAS)
    g.tap([(540, 1719)])              # tengah baris Semak Kemaskini
    assert drv.tap_dibuat == [[(540, 1719)]]


# ===========================================================================
# REGRESI 2 — modal bersarang (device sebenar, 2026-08-10)
# ===========================================================================

XML_MODAL_BERSARANG = (
    '<hierarchy><node bounds="[0,0][1080,2400]">'
    '  <node class="android.widget.EditText" text="msc"'
    '        bounds="[105,1414][975,1564]"/>'
    '  <node class="android.widget.Button" resource-id="modal-backdrop"'
    '        text="Close modal" clickable="true" bounds="[0,108][1080,2316]">'
    '    <node resource-id="modal-surface" bounds="[78,588][1002,1836]">'
    '      <node text="Selaras Maklumat Pelesen" clickable="true"'
    '            bounds="[150,1425][930,1509]"/>'
    '      <node resource-id="modal-surface" bounds="[78,861][1002,1563]">'
    '        <node text="INTERNAL IP ADDRESS" bounds="[150,900][930,960]"/>'
    '        <node class="android.widget.EditText"'
    '              resource-id="text-input-outlined"'
    '              text="113.211.155.174" bounds="[150,970][930,1030]"/>'
    '        <node text="SIMPAN" clickable="true"'
    '              bounds="[461,1401][619,1461]"/>'
    '      </node>'
    '    </node>'
    '  </node>'
    '</node></hierarchy>')


def test_modal_bersarang_hanya_kandungan_teratas_dikira():
    """REGRESI. T-001 mengetuk SIMPAN pada (540,1431). Titik itu berada
    dalam DUA modal-surface bersarang: Menu Selaras di belakang dan
    Tetapan Alamat IP di hadapan.

    RN mengekalkan skrin belakang dalam pokok, jadi pungutan mentah
    melihat 'Selaras Maklumat Pelesen' dan membatalkan run atas ketukan
    SIMPAN yang sah. Hanya surface PALING DALAM yang menerima sentuhan."""
    teks, jumpa = C.teks_di_koordinat(XML_MODAL_BERSARANG, 540, 1431)
    assert jumpa
    assert "SIMPAN" in teks
    assert "Selaras Maklumat Pelesen" not in teks, \
        "baris menu di BELAKANG modal bocor ke dalam sasaran tap"
    assert "msc" not in teks


def test_simpan_dalam_modal_tetapan_dibenarkan(bina):
    """Hujung ke hujung: T-001 mesti boleh menekan SIMPAN."""
    g, drv = bina(src=XML_MODAL_BERSARANG)
    g.tap([(540, 1431)])
    assert drv.tap_dibuat == [[(540, 1431)]]


def test_backdrop_masih_betul_dengan_modal_bersarang(bina):
    """Titik di LUAR setiap surface: hanya node bukan-surface dikira."""
    teks, jumpa = C.teks_di_koordinat(XML_MODAL_BERSARANG, 540, 2100)
    assert jumpa
    assert "Close modal" in teks
    assert "Selaras Maklumat Pelesen" not in teks
    assert "SIMPAN" not in teks


def test_pelesen_dalam_surface_belakang_masih_disekat_bila_di_hadapan(bina):
    """Kalau HANYA menu Selaras terbuka (tiada modal Tetapan di atasnya),
    mengetuk baris Pelesen mesti tetap disekat. Pembetulan tidak boleh
    menyembunyikannya."""
    xml = XML_MODAL_BERSARANG.replace(
        '<node resource-id="modal-surface" bounds="[78,861][1002,1563]">',
        '<node resource-id="tiada-modal-di-sini" bounds="[78,861][1002,1563]">')
    g, drv = bina(src=xml)
    with pytest.raises(DryRunViolation, match="SELARAS-PELESEN"):
        g.tap([(540, 1467)])
    assert drv.tap_dibuat == []

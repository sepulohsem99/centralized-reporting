"""
Gerbang untuk RUNNER E2E KENDIRI (tools/run_e2e.py).

Runner ini boleh mencipta rekod penguatkuasaan SEBENAR pada production
tanpa sesi Claude, jadi kebenarannya mesti gagal ke arah TERTUTUP dalam
setiap keadaan: fail tiada, luput, kuota habis, set salah taip.

Ujian di sini juga menjaga PEMBETULAN D-05 — urutan isian borang K.
Urutan yang salah tidak menyebabkan ralat; ia menghasilkan rekod
production dengan nombor plat dalam medan nama. Itu jenis pepijat yang
hanya ujian urutan boleh tangkap.

TIADA peranti. TIADA Appium.
"""

import datetime
import os
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from tools.izin_e2e import IzinE2E, IzinTidakSah, NAMA_FAIL    # noqa: E402
from tools.run_e2e import sah_set, urai_borang                 # noqa: E402


def hari_ini():
    return datetime.date.today().isoformat()


def semalam():
    return (datetime.date.today() - datetime.timedelta(days=1)).isoformat()


def tulis_izin(tmp_path, tarikh=None, n=1, p=1, k=1):
    (tmp_path / NAMA_FAIL).write_text(
        f"tarikh_luput={tarikh if tarikh is not None else hari_ini()}\n"
        f"kuota_N={n}\nkuota_P={p}\nkuota_K={k}\n", encoding="utf-8")
    return IzinE2E.baca(str(tmp_path))


# ===========================================================================
# FAIL IZIN
# ===========================================================================
def test_fail_izin_tiada_menolak(tmp_path):
    with pytest.raises(IzinTidakSah, match="TIDAK WUJUD"):
        IzinE2E.baca(str(tmp_path))


def test_izin_luput_menolak(tmp_path):
    izin = tulis_izin(tmp_path, tarikh=semalam())
    with pytest.raises(IzinTidakSah, match="luput"):
        izin.semak("N")


@pytest.mark.parametrize("tarikh", ["", "12/08/2026", "semalam",
                                    "2026-13-45"])
def test_tarikh_rosak_menolak(tmp_path, tarikh):
    """Tarikh yang tidak boleh dihurai TIDAK dianggap sah — satu salah
    taip tidak boleh membuka izin selama-lamanya."""
    izin = tulis_izin(tmp_path, tarikh=tarikh)
    with pytest.raises(IzinTidakSah):
        izin.semak("N")


def test_kuota_sifar_menolak(tmp_path):
    izin = tulis_izin(tmp_path, k=0)
    assert izin.semak("N") is True
    with pytest.raises(IzinTidakSah, match="kuota_K"):
        izin.semak("K")


def test_kuota_rosak_dikira_sifar(tmp_path):
    (tmp_path / NAMA_FAIL).write_text(
        f"tarikh_luput={hari_ini()}\nkuota_N=banyak\n", encoding="utf-8")
    izin = IzinE2E.baca(str(tmp_path))
    assert izin.kuota["N"] == 0
    with pytest.raises(IzinTidakSah):
        izin.semak("N")


def test_borang_tidak_sah_menolak(tmp_path):
    izin = tulis_izin(tmp_path)
    with pytest.raises(IzinTidakSah, match="tidak sah"):
        izin.semak("Z")


# ===========================================================================
# KUOTA DITOLAK DAN DITULIS BALIK
# ===========================================================================
def test_kuota_ditolak_selepas_rekod(tmp_path):
    izin = tulis_izin(tmp_path, k=1)
    assert izin.semak("K") is True
    assert izin.guna_satu("K") == 0
    with pytest.raises(IzinTidakSah, match="kuota_K"):
        izin.semak("K")


def test_kuota_kekal_selepas_proses_mati(tmp_path):
    """Sifat yang sebenarnya penting: penolakan bertahan pada CAKERA.
    Kalau ia hanya dalam ingatan, menjalankan runner sekali lagi akan
    mencipta rekod kedua."""
    izin = tulis_izin(tmp_path, k=1)
    izin.guna_satu("K")
    semula = IzinE2E.baca(str(tmp_path))       # proses baharu
    assert semula.kuota["K"] == 0
    with pytest.raises(IzinTidakSah):
        semula.semak("K")


def test_kuota_borang_lain_tidak_terjejas(tmp_path):
    izin = tulis_izin(tmp_path, n=1, p=1, k=1)
    izin.guna_satu("K")
    semula = IzinE2E.baca(str(tmp_path))
    assert semula.kuota == {"N": 1, "P": 1, "K": 0, "NK": 0}


def test_tarikh_kekal_selepas_tulis_balik(tmp_path):
    izin = tulis_izin(tmp_path)
    izin.guna_satu("N")
    assert IzinE2E.baca(str(tmp_path)).tarikh_luput == hari_ini()


def test_guna_kuota_sifar_menolak(tmp_path):
    izin = tulis_izin(tmp_path, n=0)
    with pytest.raises(IzinTidakSah, match="sudah 0"):
        izin.guna_satu("N")


def test_fail_izin_sedia_ada_tidak_ditimpa(tmp_path):
    """Kalau pemilik sudah meletakkan fail, runner GUNA ia — bukan
    menulis ganti dengan lalai."""
    (tmp_path / NAMA_FAIL).write_text(
        f"# nota pemilik\ntarikh_luput={hari_ini()}\n"
        f"kuota_N=7\nkuota_P=0\nkuota_K=2\n", encoding="utf-8")
    izin = IzinE2E.baca(str(tmp_path))
    assert izin.kuota == {"N": 7, "P": 0, "K": 2, "NK": 0}


# ===========================================================================
# ARGUMEN
# ===========================================================================
def test_urai_borang():
    assert urai_borang("K") == ["K"]
    assert urai_borang("NPK") == ["N", "P", "K"]
    assert urai_borang("npk") == ["N", "P", "K"]
    assert urai_borang("KKK") == ["K"]          # pendua dibuang
    assert urai_borang("PN") == ["P", "N"]      # urutan pemilik dikekalkan


def test_urai_borang_tidak_sah():
    with pytest.raises(SystemExit):
        urai_borang("X")


def test_set_tidak_wujud_ditolak():
    ok, sebab = sah_set("SET-TIDAK-PERNAH-WUJUD-999")
    assert ok is False and "TIDAK WUJUD" in sebab


def test_set_wujud_diterima():
    from testdata.sets_loader import muat_semua
    ok, _ = sah_set(muat_semua()[0]["set_id"])
    assert ok is True


def test_tiada_set_diterima():
    assert sah_set(None)[0] is True


# ===========================================================================
# PEMBETULAN D-05 — urutan isian borang K
# ===========================================================================
def test_urutan_K_no_kereta_dahulu():
    """>>> INI PEMBETULAN D-05. <<<
    Borang mencerminkan plat ke medan identiti sebaik No. Kereta diisi.
    Mengisi Nama dahulu bermakna plat MENIMPA-nya. Rekod production
    PGP02K260813002 dicipta dengan urutan lama dan medan namapesalah
    padanya membawa nombor plat.
    """
    from pages.daftar_kompaun_page import DaftarKompaunPage
    urutan = [lab for lab, _ in
              DaftarKompaunPage.MEDAN_PESALAH_LETAK_KERETA]
    assert urutan[0] == "No. Kereta", (
        f"No. Kereta MESTI pertama; urutan semasa {urutan}")
    assert urutan.index("No. Kereta") < urutan.index("Nama Pesalah")
    assert urutan.index("No. Kereta") < urutan.index("No K/P/SSM")


def test_urutan_K_dipatuhi_semasa_mengisi():
    """Urutan pemalar tidak bermakna kalau kaedah mengisi mengabaikannya.
    Isian direkod melalui suntikan, tanpa peranti."""
    from pages.daftar_kompaun_page import DaftarKompaunPage
    rekod = []

    class Palsu(DaftarKompaunPage):
        def __init__(self):
            pass

    # Nilai sengaja TIDAK berbentuk plat: ujian ini mengukur
    # URUTAN, dan rentetan berbentuk PII dalam kod sumber akan
    # ditanda oleh pengimbas -- betul-betul.
    data = {"no_kereta": "<plat-ujian>", "nama_pesalah": "SI POLAN",
            "no_kp_ssm_kereta": "000000000000",
            "jenis_kereta": "KERETA UJIAN"}
    Palsu().fill_pesalah_tab_letak_kereta(
        data, isi_medan=lambda _p, label, nilai: rekod.append(label) or True)
    assert rekod[0] == "No. Kereta"
    assert rekod.index("No. Kereta") < rekod.index("Nama Pesalah")


def test_medan_tanpa_nilai_dilangkau_bukan_diteka():
    from pages.daftar_kompaun_page import DaftarKompaunPage
    rekod = []

    class Palsu(DaftarKompaunPage):
        def __init__(self):
            pass

    Palsu().fill_pesalah_tab_letak_kereta(
        {"no_kereta": "<plat-ujian>"},
        isi_medan=lambda _p, label, nilai: rekod.append(label) or True)
    assert rekod == ["No. Kereta"]


def test_borang_K_tiada_medan_alamat():
    """Tab Pesalah Letak Kereta TIADA blok alamat. Menambahnya semula
    akan mengembalikan kegagalan carian 'MAKLUMAT JALAN' selama 15s."""
    from pages.daftar_kompaun_page import DaftarKompaunPage
    label = [lab.upper() for lab, _ in
             DaftarKompaunPage.MEDAN_PESALAH_LETAK_KERETA]
    for terlarang in ("MAKLUMAT JALAN", "TAMAN", "POSKOD", "BANDAR",
                      "NEGERI"):
        assert terlarang not in label


# ===========================================================================
# JEDA BATAL untuk --terus
# ===========================================================================
def test_terus_ada_jeda_batal(monkeypatch, capsys):
    """--terus menjadikan satu command tersilap taip cukup untuk
    mencipta rekod penguatkuasaan sebenar. Jeda memberi peluang Ctrl-C.

    Semasa pembangunan, satu larian --terus yang tidak disengajakan
    hanya terselamat kerana paip ditutup dan proses mati. Itu nasib."""
    from tools import run_e2e
    monkeypatch.setattr(run_e2e, "JEDA_TERUS", 2)
    tidur = []
    monkeypatch.setattr(run_e2e.time, "sleep", lambda s: tidur.append(s))
    assert run_e2e.minta_ya({"borang": "K"}, terus=True) is True
    assert sum(tidur) == 2, "jeda mesti benar-benar menunggu"
    assert "Ctrl-C" in capsys.readouterr().out


def test_terus_boleh_dibatalkan_ctrl_c(monkeypatch):
    from tools import run_e2e
    monkeypatch.setattr(run_e2e, "JEDA_TERUS", 2)

    def tidur_ditekan(_s):
        raise KeyboardInterrupt

    monkeypatch.setattr(run_e2e.time, "sleep", tidur_ditekan)
    assert run_e2e.minta_ya({"borang": "K"}, terus=True) is False


def test_tanpa_tty_dan_tanpa_terus_menolak(monkeypatch):
    """Tanpa terminal, tiada siapa boleh menaip YA — runner mesti
    berhenti, bukan menganggap kebenaran."""
    from tools import run_e2e
    monkeypatch.setattr(run_e2e.sys.stdin, "isatty", lambda: False)
    assert run_e2e.minta_ya({"borang": "K"}, terus=False) is False


# ===========================================================================
# KUOTA NK — berasingan daripada N/P/K
# ===========================================================================
def test_nk_kuota_berasingan_daripada_N(tmp_path):
    """Membenarkan 1 notis TIDAK sepatutnya membenarkan menukarnya
    menjadi kompaun juga — NK menjana rekod kompaun BARU."""
    izin = tulis_izin(tmp_path, n=1)
    assert izin.semak("N") is True
    with pytest.raises(IzinTidakSah, match="kuota_NK"):
        izin.semak("NK")


def test_nk_mesej_beritahu_pemilik_apa_nak_tambah(tmp_path):
    izin = tulis_izin(tmp_path)
    try:
        izin.semak("NK")
        raise AssertionError("sepatutnya disekat")
    except IzinTidakSah as e:
        assert "kuota_NK=1" in str(e), "mesej mesti beri baris TEPAT"


def test_nk_dibenarkan_bila_pemilik_tambah(tmp_path):
    (tmp_path / NAMA_FAIL).write_text(
        f"tarikh_luput={hari_ini()}\nkuota_N=0\nkuota_P=0\nkuota_K=0\n"
        f"kuota_NK=1\n", encoding="utf-8")
    izin = IzinE2E.baca(str(tmp_path))
    assert izin.semak("NK") is True
    assert izin.guna_satu("NK") == 0
    assert IzinE2E.baca(str(tmp_path)).kuota["NK"] == 0


def test_nk_bukan_borang_cipta():
    """--borang tidak boleh menerima NK: ia dipecah ikut huruf, jadi
    'NK' akan dibaca sebagai N kemudian K — dua rekod cipta, bukan satu
    penukaran."""
    from tools.izin_e2e import BORANG_SAH
    assert "NK" not in BORANG_SAH
    assert urai_borang("NK") == ["N", "K"]

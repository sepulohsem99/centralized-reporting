"""
Ujian pengosongan medan — tanpa peranti.

Pemerhatian pemilik dari video run 2026-08-10 11:03: backspace ditekan
berkali-kali pada medan username yang SUDAH KOSONG sebelum 'msc' ditaip.
Versi MBJB menekan 30 kali tanpa syarat pada SETIAP medan.
"""

import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from pages.base_page import BasePage                          # noqa: E402


class ElemenMedan:
    """EditText palsu yang berkelakuan seperti RN: clear() boleh
    diabaikan, dan medan kosong memaparkan placeholder dalam `text`."""

    def __init__(self, nilai="", hint="", clear_berkesan=True):
        self.nilai = nilai
        self.hint = hint
        self.clear_berkesan = clear_berkesan
        self.clear_dipanggil = 0
        self.diklik = 0

    @property
    def text(self):
        return self.nilai if self.nilai else self.hint

    def get_attribute(self, nama):
        return self.hint if nama == "hint" else None

    def click(self):
        self.diklik += 1

    def clear(self):
        self.clear_dipanggil += 1
        if self.clear_berkesan:
            self.nilai = ""


class DriverKekunci:
    def __init__(self, el=None, del_berkesan=True):
        self.keycodes = []
        self.el = el
        self.del_berkesan = del_berkesan

    def press_keycode(self, kod, *a):
        self.keycodes.append(kod)
        if self.el is None or not self.del_berkesan:
            return
        if kod == 112:                      # FORWARD_DEL selepas Ctrl+A
            self.el.nilai = ""
        elif kod == 67 and self.el.nilai:   # backspace
            self.el.nilai = self.el.nilai[:-1]

    def tap(self, *a, **kw):
        pass


def _page(driver):
    p = BasePage.__new__(BasePage)
    p.driver = driver
    return p


def bil_backspace(driver):
    return sum(1 for k in driver.keycodes if k == 67)


# ---------------------------------------------------------------------------

def test_medan_kosong_tiada_backspace_langsung():
    """SIFAT UTAMA. Medan kosong -> SIFAR backspace."""
    el = ElemenMedan(nilai="")
    drv = DriverKekunci(el)
    assert _page(drv)._force_clear(el)
    assert bil_backspace(drv) == 0
    assert el.clear_dipanggil == 0, "clear() dipanggil pada medan kosong"


def test_placeholder_dikira_kosong():
    """Medan kosong memaparkan placeholder dalam `text`. Tanpa semakan
    hint, 'NAMA PESALAH' kelihatan seperti nilai dan mencetuskan
    pengosongan yang tidak perlu."""
    el = ElemenMedan(nilai="", hint="NAMA PESALAH")
    assert el.text == "NAMA PESALAH"
    drv = DriverKekunci(el)
    assert _page(drv)._force_clear(el)
    assert bil_backspace(drv) == 0
    assert el.clear_dipanggil == 0


def test_medan_berisi_guna_clear_dahulu():
    """clear() yang berkesan bermakna TIADA backspace."""
    el = ElemenMedan(nilai="AMIRUL")
    drv = DriverKekunci(el)
    assert _page(drv)._force_clear(el)
    assert el.clear_dipanggil == 1
    assert bil_backspace(drv) == 0
    assert el.nilai == ""


def test_backspace_hanya_bila_clear_diabaikan_dan_ikut_panjang_sebenar():
    """RN kerap mengabaikan clear(). Sandaran mesti berjalan — tetapi
    bilangannya = panjang teks SEBENAR, bukan 30 tetap."""
    el = ElemenMedan(nilai="010123456789", clear_berkesan=False)
    drv = DriverKekunci(el, del_berkesan=False)   # Ctrl+A juga diabaikan
    _page(drv)._force_clear(el)
    n = len("010123456789")
    assert bil_backspace(drv) == n + 2, f"dijangka {n}+2, dapat {bil_backspace(drv)}"
    assert bil_backspace(drv) < 30


def test_ctrl_a_forward_del_dicuba_sebelum_backspace():
    """Laluan pantas dahulu: kalau Ctrl+A + FORWARD_DEL berkesan, tiada
    backspace langsung."""
    el = ElemenMedan(nilai="PANJANG SEKALI NILAINYA", clear_berkesan=False)
    drv = DriverKekunci(el, del_berkesan=True)
    assert _page(drv)._force_clear(el)
    assert 29 in drv.keycodes and 112 in drv.keycodes
    assert bil_backspace(drv) == 0


def test_medan_disahkan_kosong_sebelum_pulang():
    """Pemanggil menaip selepas ini; pulangan mesti mencerminkan
    kebenaran, bukan harapan."""
    el = ElemenMedan(nilai="DEGIL", clear_berkesan=False)
    drv = DriverKekunci(el, del_berkesan=False)   # tiada apa berkesan
    assert _page(drv)._force_clear(el) is False
    assert el.nilai == "DEGIL"


@pytest.mark.parametrize("panjang", [1, 5, 12, 40])
def test_backspace_berskala_dengan_panjang(panjang):
    el = ElemenMedan(nilai="X" * panjang, clear_berkesan=False)
    drv = DriverKekunci(el, del_berkesan=False)
    _page(drv)._force_clear(el)
    assert bil_backspace(drv) == panjang + 2

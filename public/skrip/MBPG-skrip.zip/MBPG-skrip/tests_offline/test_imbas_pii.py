"""
Gerbang untuk IMBASAN PII PRA-COMMIT.

>>> SETIAP NILAI DALAM FAIL INI ADALAH SINTETIK. <<<
Versi pertama fail ini menggunakan IC, nama, dan plat SEBENAR daripada
lookup MySIKAP sebagai fixture — dan dengan itu memasukkan data
peribadi orang sebenar ke dalam repo, di dalam ujian yang ditulis
untuk menghalang tepat perkara itu. Pengimbas menangkapnya; saya yang
terlepas pandang amarannya.

Fixture PII mesti direka. Ujian yang memerlukan data sebenar untuk
lulus ialah ujian yang menyebarkan data sebenar.

Alat ini wujud kerana corak .gitignore terlepas tiga kali dalam satu
hari. Ujian di sini menjaga dua sifat yang bertentangan, dan
kedua-duanya perlu:

  MENANGKAP  PII sebenar yang benar-benar bocor sebelum ini
  SENYAP     pada pengecam kod, IC ujian, dan data rujukan awam —
             alat yang berbunyi pada setiap commit akan diabaikan,
             dan alat yang diabaikan tidak melindungi apa-apa
"""

import os
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from devtools.imbas_pii import imbas_teks                     # noqa: E402


def jenis(teks):
    return sorted({n for n, _ in imbas_teks(teks)})


# ===========================================================================
# MESTI MENANGKAP — ini yang benar-benar bocor
# ===========================================================================
def test_menangkap_ic_12_digit():
    assert "no_kp_12_digit" in jenis("no_kp: 880101011234")


def test_menangkap_ic_bersengkang():
    assert "no_kp_bersengkang" in jenis("IC 880101-01-1234")


def test_menangkap_plat():
    for plat in ("ABC1234", "WA1234A", "BMT7788", "W1234"):
        assert "plat_kenderaan" in jenis(f"No. Kereta {plat}"), plat


def test_menangkap_nama_bin_binti():
    for nama in ("AHMAD CONTOH BIN SINTETIK",
                 "SITI AMINAH BINTI ABDULLAH",
                 "VIMALA DEVI A/P MARAN",
                 "Rajesh A/L Kumar"):
        assert "nama_bin_binti" in jenis(nama), nama


def test_menangkap_pii_dalam_dump_xml():
    """Bentuk sebenar yang bocor: page source dengan medan terisi."""
    xml = ('<node class="android.widget.EditText" '
           'text="AHMAD CONTOH BIN SINTETIK" />'
           '<node class="android.widget.EditText" text="880101011234" />')
    j = jenis(xml)
    assert "no_kp_12_digit" in j and "nama_bin_binti" in j


# ===========================================================================
# MESTI SENYAP — kalau tidak, alat ini diabaikan
# ===========================================================================
@pytest.mark.parametrize("teks", [
    "KA01 T001 T011 C9C9 Z0Z0 PL01",          # pengecam kod
    "MBPG-TC-T-001 MBPG-TC-N-005",            # id TC
    "SET-KK01-AKT2-111",                      # id set
    "000000000000 999999999999 111111111111",  # IC penanda ujian
    "JALAN ALAMANDA 1, poskod 81700",         # alamat rujukan awam
    "SEK 70 (A) / UUK 3 (N) / AKTA 133",      # kod kesalahan
    "denda RM 1000, MIN: 250, MAX: 1000",     # amaun
    "PGP03K260812001",                        # nombor kompaun
    "5008TF2010009401",                       # serial peranti
])
def test_senyap_pada_bukan_pii(teks):
    assert jenis(teks) == [], f"{teks!r} -> {jenis(teks)}"


@pytest.mark.parametrize("baris", [
    "except Exception:                     # noqa: BLE001",
    "        pass  # noqa: BLE001",
    "import os  # noqa: E402",
    "from x import y  # noqa: F401,E402",
])
def test_senyap_pada_arahan_noqa(baris):
    """`# noqa: BLE001` mempunyai bentuk plat Malaysia dan muncul 307
    kali dalam repo. Kalau ia berbunyi, alat ini akan diabaikan."""
    assert jenis(baris) == [], f"{baris!r} -> {jenis(baris)}"


def test_pengecualian_noqa_tidak_membutakan_nilai_itu_sendiri():
    """Yang dibuang ialah token noqa, BUKAN nilai. Plat sebenar yang
    kebetulan berbunyi seperti kod lint mesti KEKAL ditangkap apabila ia
    muncul sebagai data."""
    assert "plat_kenderaan" in jenis("No. Kereta BLE001")
    assert "plat_kenderaan" in jenis('<node text="BLE001" />')


def test_senyap_pada_kod_projek_sebenar():
    """Baris sebenar dari suite ini. Kalau alat berbunyi di sini, ia
    akan menghalang kerja biasa."""
    for baris in (
        'LABEL_TIER1 = (AppiumBy.ANDROID_UIAUTOMATOR, "new UiSelector()")',
        'assert kep.kompaun_ok == "YA" and kep.akta_ok == "YA"',
        'serial = "5008TF2010009401"',
        'print(f"  [{n:02d}/{jumlah}] {tanda} {s[\'set_id\']}")',
    ):
        assert jenis(baris) == [], f"{baris!r} -> {jenis(baris)}"


# ===========================================================================
# Nilai TIDAK PERNAH dicetak penuh
# ===========================================================================
def test_nilai_disamarkan_dalam_laporan(capsys, monkeypatch, tmp_path):
    """Alat yang melaporkan PII penuh ke terminal dan log hanya
    menyebarkannya lagi."""
    from devtools import imbas_pii
    monkeypatch.setattr(imbas_pii, "baris_ditambah",
                        lambda: [("a.xml", "IC 880101011234")])
    assert imbas_pii.main() == 1
    keluar = capsys.readouterr().out
    assert "880101011234" not in keluar     # nilai penuh TIDAK dicetak
    assert "88" in keluar and "*" in keluar  # bentuk cukup untuk dikenali


def test_bersih_pulangkan_sifar(capsys, monkeypatch):
    from devtools import imbas_pii
    monkeypatch.setattr(imbas_pii, "baris_ditambah",
                        lambda: [("a.py", "denda RM 1000")])
    assert imbas_pii.main() == 0
    assert "BERSIH" in capsys.readouterr().out


def test_pengecualian_ikut_laluan_bukan_ikut_nilai():
    """Pengecualian nilai akan mematikan pengesanan di mana-mana nilai
    itu muncul — termasuk dalam dump sebenar. Pengecualian laluan
    hanya melangkau dua fail yang diketahui.

    Jadi imbas_teks() mesti KEKAL mengesan walaupun untuk nilai yang
    fail dikecualikan gunakan."""
    from devtools.imbas_pii import FAIL_DIKECUALIKAN
    assert jenis("no_kp: 880101011234") == ["no_kp_12_digit"]
    assert FAIL_DIKECUALIKAN == {
        "devtools/imbas_pii.py",
        "tests_offline/test_imbas_pii.py",
    }


def test_pengecualian_tidak_meliputi_fail_bukti():
    """Fail yang membawa dump peranti TIDAK boleh dikecualikan —
    itulah tepat yang bocor sebelum ini."""
    from devtools.imbas_pii import FAIL_DIKECUALIKAN
    for f in FAIL_DIKECUALIKAN:
        assert "docs/" not in f and "reports/" not in f, f
        assert f.endswith("imbas_pii.py") or f.endswith("test_imbas_pii.py")


@pytest.mark.parametrize("teks", [
    "SET-KK01-AKT049-048",
    "python tools/run_e2e.py --borang N --set SET-KK01-AKT049-048",
    "SET-KK02-AKT12-003",
])
def test_senyap_pada_id_set_runner(teks):
    """ID set muncul dalam setiap arahan runner yang pemilik taip.
    Serpihan seperti 'AKT049' mempunyai bentuk plat Malaysia; kalau ia
    berbunyi, alat ini akan diabaikan."""
    assert jenis(teks) == [], f"{teks!r} -> {jenis(teks)}"

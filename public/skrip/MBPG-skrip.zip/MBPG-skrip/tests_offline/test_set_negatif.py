"""
Gerbang untuk klasifikasi SET NEGATIF (JANGKA_KOSONG / JANGKA_MATI_T3).

Set negatif menegaskan sesuatu yang TIDAK sepatutnya ada. Kalau
klasifikasinya salah, MATRIX melaporkan dapatan yang tidak wujud —
tepat yang berlaku dalam sweep 284: kelima-lima set JANGKA_MATI_T3
dilabel 'ADA-ISI' dengan mesej "app memaparkan kesalahan", sedangkan
DB mengesahkan akta berkenaan membawa 0 kesalahan dan app berkelakuan
betul.
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from pages.sweep_kombo import _dropdown_kosong                # noqa: E402


class _PageTiruan:
    LABEL_TIER2 = LABEL_TIER3 = ("x", "y")

    def __init__(self, mesej):
        self.mesej = mesej

    def pilih_spinner_kod(self, *a, **kw):
        raise AssertionError(self.mesej)


def test_modal_tidak_terbuka_dikira_kosong():
    """REGRESI SWEEP 2026-08-12. Dropdown ini pressable RN: bila tiada
    baris, TIADA modal dirender. 'Modal tidak terbuka' ialah bentuk
    yang 'kosong' ambil pada kawalan jenis ini."""
    p = _PageTiruan("'KESALAHAN KOMPAUN': modal dropdown tidak terbuka "
                    "selepas 3 ketukan pada pressable.")
    kosong, bukti = _dropdown_kosong(p, 3, p.LABEL_TIER3, "KESALAHAN KOMPAUN")
    assert kosong is True
    assert bukti == ""


def test_sifar_pilihan_masih_dikira_kosong():
    p = _PageTiruan("dialog terbuka tetapi 0 pilihan")
    assert _dropdown_kosong(p, 3, p.LABEL_TIER3, "X")[0] is True


def test_senarai_berisi_bukan_kosong():
    """Kalau modal TERBUKA dan membawa baris, set negatif GAGAL — itu
    dapatan sebenar dan mesti kekal kelihatan."""
    p = _PageTiruan("nilai '__PENANDA__' TIADA dalam modal dropdown. "
                    "7 baris SEBENAR yang dilihat: ['A', 'B', 'C']")
    kosong, bukti = _dropdown_kosong(p, 3, p.LABEL_TIER3, "X")
    assert kosong is False
    assert "baris SEBENAR" in bukti


def test_kegagalan_lain_bukan_kosong():
    """Label hilang bukan bukti senarai kosong — jangan tukar kegagalan
    harnes menjadi 'set negatif LULUS'."""
    p = _PageTiruan("label 'KESALAHAN KOMPAUN' tidak dijumpai pada skrin")
    assert _dropdown_kosong(p, 3, p.LABEL_TIER3, "X")[0] is False

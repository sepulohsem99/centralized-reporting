"""
Ujian enjin dropdown pressable RN — tanpa peranti.

Dibina atas recon device 2026-08-10
(docs/recon/dropdown_tier1_terbuka.xml):
    backdrop  ViewGroup clickable [0,108][1080,2316], teks KOSONG
    bekas     scrollable=true
    baris     ViewGroup clickable, teks = keterangan PENUH
    TIADA medan carian, TIADA butang BATAL
"""

import os
import sys

import pytest       # noqa: F401  (dipakai oleh ujian sedia ada di bawah)


def test_noktah_hujung_dinormalkan_tetapi_awalan_separa_kekal_ditolak():
    """DEVICE 2026-08-10. Baris production:
        '[UUK 3 (N)] - MEMBUAT ... KEROSAKAN HARTA MPPG'
    Oracle membawa ayat sama DENGAN noktah. Padanan tepat menolaknya
    atas satu aksara dan melaporkan baris itu 'tiada'.

    Normalisasi ekor tidak boleh membuka padanan separa — itu sebab
    match-or-FAIL wujud, jadi kedua-dua sifat diuji bersama."""
    from pages.daftar_kompaun_page import DaftarKompaunPage as D
    padan = D._padan_baris_modal

    baris = "[UUK 3 (N)] - MEMBUAT APA-APA YANG BOLEH MENYEBABKAN " \
            "KEROSAKAN HARTA MPPG"
    assert padan(baris, "MEMBUAT APA-APA YANG BOLEH MENYEBABKAN "
                        "KEROSAKAN HARTA MPPG.")
    assert padan(baris, "MEMBUAT APA-APA YANG BOLEH MENYEBABKAN "
                        "KEROSAKAN HARTA MPPG")

    # Awalan separa: MASIH ditolak.
    assert not padan("[X] - KOMPAUN PELBAGAI JP", "KOMPAUN PELBAGAI")
    assert not padan("[X] - KOMPAUN PELBAGAI", "KOMPAUN PELBAGAI JP")
    # Baris berbeza tidak boleh bertembung hanya kerana noktah dibuang.
    assert not padan("[UUK 3 (D)] - MEMAKU, MENGIKAT",
                     "MEMBUAT APA-APA YANG BOLEH")

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from pages.daftar_kompaun_page import DaftarKompaunPage       # noqa: E402
from selenium.common.exceptions import (                       # noqa: E402
    StaleElementReferenceException)


class ElemenBaris:
    def __init__(self, teks, y, tinggi=147, stale_kali=0):
        self._teks = teks
        self._y = y
        self._tinggi = tinggi
        self.stale_kali = stale_kali
        self.tap = 0

    @property
    def text(self):
        if self.stale_kali > 0:
            self.stale_kali -= 1
            raise StaleElementReferenceException("stale")
        return self._teks

    def get_attribute(self, nama):
        return self._teks if nama == "content-desc" else None

    @property
    def rect(self):
        if self.stale_kali > 0:
            raise StaleElementReferenceException("stale")
        return {"x": 81, "y": self._y, "width": 918, "height": self._tinggi}


class DriverModal:
    """Modal palsu: senarai baris + backdrop skrin-penuh."""

    def __init__(self, baris_teks, terbuka=False):
        self.baris_teks = baris_teks
        self.terbuka = terbuka
        self.taps = []
        self.dipilih = None

    def find_elements(self, *a, **kw):
        backdrop = ElemenBaris("", 108, tinggi=2208)
        if not self.terbuka:
            return []
        keluar = [backdrop]
        for i, t in enumerate(self.baris_teks):
            keluar.append(ElemenBaris(t, 551 + i * 147))
        return keluar

    def tap(self, positions, duration=None):
        self.taps.append(positions[0])


class Halaman(DaftarKompaunPage):
    def __init__(self, drv):
        self.driver = drv
        self._tap_elemen = []

    def tap_element(self, el):
        self._tap_elemen.append(el)
        el.tap += 1
        # Memilih baris menutup modal.
        if getattr(el, "_teks", ""):
            self.driver.dipilih = el._teks
            self.driver.terbuka = False

    def _pressable_bawah_label(self, sempadan):
        # Selepas pemilihan, pressable memaparkan nilai yang dipilih.
        nilai = self.driver.dipilih or "-- PILIH KOMPAUN --"
        return [(1109, ElemenBaris(nilai, 1109))]

    def _dump_mbjb(self, nama):
        return nama

    def is_text_visible(self, teks, timeout=5):
        # Baca-balik: nilai kelihatan selepas ia dipilih. Guna peraturan
        # padanan yang SAMA seperti pemilihan baris, supaya baris
        # berawalan '[kod] - ' turut disahkan.
        return bool(self.driver.dipilih) and self._padan_baris_modal(
            self.driver.dipilih, teks)

    def _tag(self, nama):
        return nama.replace(" ", "_")

    def scroll_in_viewport(self, direction="down", percent=0.3, context=""):
        return False          # senarai muat sepenuhnya


BARIS = ["KOMPAUN KEBERSIHAN", "KOMPAUN LESEN JKAP", "KOMPAUN LESEN JP",
         "KOMPAUN LESEN JPLS", "KOMPAUN LETAK KERETA",
         "KOMPAUN PELBAGAI JBGN", "KOMPAUN PELBAGAI JKAP",
         "KOMPAUN PELBAGAI JP", "KOMPAUN PELBAGAI JPLS"]


# ---------------------------------------------------------------------------

def test_baris_dikesan_backdrop_dibuang():
    """Backdrop clickable setinggi skrin bukan baris. Tanpa penapisan ia
    kelihatan sebagai baris kosong dan boleh diketuk."""
    drv = DriverModal(BARIS, terbuka=True)
    p = Halaman(drv)
    baris = p._baris_modal_kini()
    assert len(baris) == 9
    assert all(t for t, _el in baris)
    assert "" not in [t for t, _el in baris]


def test_pilih_padanan_penuh():
    drv = DriverModal(BARIS, terbuka=True)
    p = Halaman(drv)
    p._pilih_melalui_pressable(None, "KETERANGAN KOD KOMPAUN",
                               "KOMPAUN LETAK KERETA", "-")
    assert drv.dipilih == "KOMPAUN LETAK KERETA"


def test_padanan_tidak_peka_huruf():
    drv = DriverModal(BARIS, terbuka=True)
    p = Halaman(drv)
    p._pilih_melalui_pressable(None, "x", "kompaun letak kereta", "-")
    assert drv.dipilih == "KOMPAUN LETAK KERETA"


def test_match_or_fail_tiada_sandaran_baris_pertama():
    """SIFAT PALING PENTING. Nilai yang tiada mesti GAGAL, bukan memilih
    baris pertama. Memilih baris yang salah kelihatan seperti lulus."""
    drv = DriverModal(BARIS, terbuka=True)
    p = Halaman(drv)
    with pytest.raises(AssertionError) as ex:
        p._pilih_melalui_pressable(None, "KETERANGAN KOD KOMPAUN",
                                   "KOMPAUN PELBAGAI", "-")
    assert drv.dipilih is None, "baris dipilih walaupun tiada padanan"
    assert "TIADA sandaran" in str(ex.value)
    # Mesej mesti menyenaraikan baris SEBENAR supaya beza ejaan kelihatan
    assert "KOMPAUN PELBAGAI JP" in str(ex.value)


def test_padanan_separa_bukan_padanan():
    """'KOMPAUN PELBAGAI' ialah awalan kepada empat baris sebenar. Ia
    TIDAK boleh memadan mana-mana — ini betul-betul teks staging lama,
    dan menerimanya akan memilih kod yang salah secara senyap."""
    drv = DriverModal(BARIS, terbuka=True)
    p = Halaman(drv)
    with pytest.raises(AssertionError):
        p._pilih_melalui_pressable(None, "x", "KOMPAUN PELBAGAI", "-")


def test_stale_recovery_semasa_membaca_baris():
    """Pokok RN dirender semula; rujukan yang disimpan mati. Membaca
    baris mesti tahan terhadap itu dan bukan meletup."""
    drv = DriverModal(BARIS, terbuka=True)

    asal = drv.find_elements

    def sekali_stale(*a, **kw):
        els = asal(*a, **kw)
        els[1].stale_kali = 1          # satu baris stale sekali
        return els

    drv.find_elements = sekali_stale
    p = Halaman(drv)
    baris = p._baris_modal_kini()
    assert len(baris) == 8, "baris stale sepatutnya dilangkau, bukan meletup"


def test_modal_tidak_terbuka_melempar():
    drv = DriverModal(BARIS, terbuka=False)
    p = Halaman(drv)

    class TiadaPressable(Halaman):
        def _pressable_bawah_label(self, sempadan):
            return []

    with pytest.raises(AssertionError, match="tidak terbuka"):
        TiadaPressable(drv)._pilih_melalui_pressable(None, "x", "y", "-")


def test_tutup_modal_mengetuk_backdrop_bukan_baris():
    """Tiada butang BATAL dan Android back tidak menutupnya. Penutupan
    mesti mengetuk backdrop DI ATAS baris pertama."""
    drv = DriverModal(BARIS, terbuka=True)
    p = Halaman(drv)
    p._tutup_modal_pressable()
    assert drv.taps, "tiada tap penutupan dihantar"
    x, y = drv.taps[-1]
    assert y < 551, f"tap penutupan pada y={y} berada DALAM senarai baris"
    assert y >= 150


def test_tutup_modal_tanpa_modal_adalah_no_op():
    drv = DriverModal(BARIS, terbuka=False)
    p = Halaman(drv)
    assert p._tutup_modal_pressable() is True
    assert not drv.taps


def test_baca_balik_gagal_melempar():
    """Modal tertutup tetapi pressable tidak memaparkan nilai = pemilihan
    tidak dipercayai."""
    drv = DriverModal(BARIS, terbuka=True)

    class TiadaBacaBalik(Halaman):
        def _pressable_bawah_label(self, sempadan):
            return [(1109, ElemenBaris("-- PILIH KOMPAUN --", 1109))]

        def is_text_visible(self, teks, timeout=5):
            return False        # app tidak memaparkan nilai selepas pilih

    p = TiadaBacaBalik(drv)
    with pytest.raises(AssertionError, match="Baca-balik GAGAL"):
        p._pilih_melalui_pressable(None, "x", "KOMPAUN LETAK KERETA", "-")


# ---------------------------------------------------------------------------
# REGRESI: pressable BORANG bukan baris modal (device 2026-08-10)
# ---------------------------------------------------------------------------

class DriverBorangSahaja:
    """Tab NOTIS tanpa modal: tiga pressable placeholder, TIADA backdrop."""

    def __init__(self):
        self.taps = []
        self.dipilih = None

    def find_elements(self, *a, **kw):
        return [ElemenBaris("-- PILIH KOMPAUN --, \uf20e", 1109),
                ElemenBaris("-- PILIH AKTA --, \uf20e", 1341),
                ElemenBaris("-- PILIH KESALAHAN --, \uf20e", 1573)]

    def tap(self, positions, duration=None):
        self.taps.append(positions[0])


def test_pressable_borang_bukan_baris_modal():
    """REGRESI. Ketiga-tiga pressable borang ialah ViewGroup clickable
    berteks — bentuk yang SAMA seperti baris modal.

    Versi pertama mengiranya sebagai baris, jadi enjin menyangka modal
    sudah terbuka, mencari 'KOMPAUN LETAK KERETA' antara tiga
    placeholder, dan gagal atas sebab yang salah sepenuhnya. Diperhati
    pada device 2026-08-10."""
    p = Halaman(DriverBorangSahaja())
    assert p._baris_modal_kini() == [], \
        "pressable borang tersilap dikira sebagai baris modal"


def test_backdrop_wajib_untuk_mengisytihar_modal_terbuka():
    """Tanpa backdrop skrin-penuh, tiada modal — walaupun ada ViewGroup
    clickable berteks pada skrin."""
    class TanpaBackdrop(DriverModal):
        def find_elements(self, *a, **kw):
            return [ElemenBaris(t, 551 + i * 147)
                    for i, t in enumerate(self.baris_teks)]

    p = Halaman(TanpaBackdrop(BARIS, terbuka=True))
    assert p._baris_modal_kini() == []


def test_placeholder_ditapis_walaupun_modal_terbuka():
    """Kalau placeholder borang kekal dalam pokok di BELAKANG modal
    (corak RN biasa), ia tetap bukan baris yang boleh dipilih."""
    class Bercampur(DriverModal):
        def find_elements(self, *a, **kw):
            els = [ElemenBaris("", 108, tinggi=2208)]
            els.append(ElemenBaris("-- PILIH KOMPAUN --, \uf20e", 1109))
            els += [ElemenBaris(t, 551 + i * 147)
                    for i, t in enumerate(self.baris_teks)]
            return els

    p = Halaman(Bercampur(BARIS, terbuka=True))
    teks = [t for t, _el in p._baris_modal_kini()]
    assert "KOMPAUN LETAK KERETA" in teks
    assert not [t for t in teks if "PILIH" in t]


def test_baris_berawalan_kod_dipadan():
    """Baris tingkat 3 dirender '[SEK 3 (2)] - MELETAKKAN ...' sedangkan
    oracle membawa keterangan sahaja. Diperhati pada device 2026-08-10."""
    baris = ["[SEK 3 (2)] - MELETAKKAN KENDERAAN DIMANA-MANA PADA TEMPAT"]
    drv = DriverModal(baris, terbuka=True)
    p = Halaman(drv)
    p._pilih_melalui_pressable(
        None, "KESALAHAN KOMPAUN",
        "MELETAKKAN KENDERAAN DIMANA-MANA PADA TEMPAT", "-")
    assert drv.dipilih == baris[0]


def test_awalan_kod_tidak_melonggarkan_padanan_separa():
    """Mengupas '[kod] - ' TIDAK menjadikan padanan longgar. Awalan
    separa mesti kekal DITOLAK."""
    assert not DaftarKompaunPage._padan_baris_modal(
        "KOMPAUN PELBAGAI JP", "KOMPAUN PELBAGAI")
    assert not DaftarKompaunPage._padan_baris_modal(
        "[SEK 1] - MELETAKKAN KENDERAAN DI SINI", "MELETAKKAN KENDERAAN")

"""
GERBANG — semantik token statushantar (FIX#30/#31).

Pemilik mengesahkan 2026-10-09:
  "status T = tidak hantar (tidak hantar ke server production),
   status H = hantar (berjaya hantar ke server)"

Jadi hanya 'H' bermakna selesai. 'M' (belum naik) DAN 'T' (tidak hantar)
dua-dua bermakna rekod TIDAK sampai server. Versi lama menguji 'M'
sahaja, meninggalkan lubang 'T' — bentuk false-pass yang human tester
N-004 laporkan terhadap Kemaskini.
"""
import inspect
import os
import sys

AKAR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if AKAR not in sys.path:
    sys.path.insert(0, AKAR)

from tools import run_e2e, run_e2e_menu                             # noqa: E402


def test_definisi_token_wujud_dan_betul():
    assert run_e2e_menu.TOKEN_HANTAR == "H"
    assert set(run_e2e_menu.TOKEN_BELUM) == {"M", "T"}


def test_ringkas_hantar_kira_T_juga_belum():
    """'T' mesti dikira belum-naik, bukan diabaikan."""
    st = {"PGP02N261009001": ("N", "T"),
          "PGP02N261009002": ("N", "M"),
          "PGP02N261009003": ("N", "H")}
    r = run_e2e_menu.ringkas_hantar(st)["H-001"]
    assert r["jumlah"] == 3
    assert sorted(r["belum_naik"]) == ["PGP02N261009001", "PGP02N261009002"]


def test_tiada_ujian_st_sama_dengan_M_sahaja():
    """Tiada KOD boleh menyemak 'M' sahaja (lubang 'T').

    Komen/docstring sahaja yang boleh menyebut `== "M"` (dokumen FIX#31).
    Jadi kita parse AST dan periksa nod Compare sebenar.
    """
    import ast
    for mod in (run_e2e_menu, run_e2e):
        pokok = ast.parse(inspect.getsource(mod))
        for nod in ast.walk(pokok):
            if isinstance(nod, ast.Compare) and len(nod.comparators) == 1:
                kiri, kanan = nod.left, nod.comparators[0]
                const = kanan if isinstance(kanan, ast.Constant) else kiri
                if isinstance(const, ast.Constant) and const.value == "M":
                    op = nod.ops[0] if nod.ops else None
                    rentetan = ast.dump(nod)
                    # 'in ("M","T")' juga Compare tapi dengan Tuple, bukan
                    # Constant — jadi apa-apa Constant 'M' di sini ialah
                    # penapis M-sahaja yang kita nak hapus.
                    if isinstance(op, (ast.Eq, ast.Is)):
                        raise AssertionError(
                            f"penapis M-sahaja masih ada: {rentetan}")


def test_menu_guna_TOKEN_BELUM_di_semua_tempat():
    s = inspect.getsource(run_e2e_menu)
    # ringkas_hantar, pemilihan m, dan pengesahan selepas hantar semula
    assert s.count("TOKEN_BELUM") >= 3


def test_hantar_terima_H_sahaja():
    s = inspect.getsource(run_e2e.peringkat_hantar)
    assert 'if t == "H"' in s
    assert 'in ("M", "T")' in s
    assert "TIDAK HANTAR" in s and "BELUM NAIK" in s


def test_kemaskini_sengaja_tidak_disyaratkan_H():
    """Urutan: kemaskini SEBELUM hantar — menuntut H akan jadi GAGAL palsu."""
    s = inspect.getsource(run_e2e.peringkat_kemaskini)
    assert "GAGAL" in s and "palsu" in s, \
        "sebab keputusan sengaja mesti didokumenkan"
    assert "HANTAR dan" in s or "peringkat HANTAR" in s, \
        "mesti menyatakan tempat token disemak"

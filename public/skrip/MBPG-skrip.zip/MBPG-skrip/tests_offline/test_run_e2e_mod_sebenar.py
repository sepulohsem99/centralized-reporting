"""
GERBANG — pendawaian runner untuk mod sebenar.

Ujian ini menyasarkan kelas pepijat yang tidak akan kelihatan sehingga
larian device: runner melaporkan mod sebenar HIDUP sementara corong
sebenarnya masih menyekat setiap mutasi (atau sebaliknya). Kedua-dua
arah mahal — yang pertama membuang satu kitaran production separuh
jalan, yang kedua membuka mutasi tanpa sesiapa memintanya.
"""

import os
import sys

import pytest

AKAR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if AKAR not in sys.path:
    sys.path.insert(0, AKAR)

from guard import dasar                                         # noqa: E402
from tools import run_e2e                                       # noqa: E402


def test_lalai_mod_sebenar_mati():
    """Menaip command tanpa bendera tidak boleh mencipta mutasi."""
    a = _parser().parse_args(["--borang", "N"])
    assert a.mod_sebenar is False
    assert a.kitaran == "cipta"


def _parser():
    """Bina semula parser runner tanpa menjalankan main()."""
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--borang", required=True)
    ap.add_argument("--kuota", type=int, default=None)
    ap.add_argument("--set", dest="set_id", default=None)
    ap.add_argument("--terus", action="store_true")
    ap.add_argument("--tanpa-printer", action="store_true")
    ap.add_argument("--mod-sebenar", action="store_true")
    ap.add_argument("--kitaran", choices=("cipta", "penuh"), default="cipta")
    return ap


def test_kitaran_penuh_menolak_tanpa_mod_sebenar(capsys):
    """`--kitaran penuh` tanpa `--mod-sebenar` akan disekat di tengah
    kitaran, SELEPAS rekod sebenar sudah wujud. Runner mesti menolaknya
    sebelum menyentuh peranti."""
    kod = run_e2e.main(["--borang", "N", "--kitaran", "penuh"])
    assert kod == 2
    keluaran = capsys.readouterr().out
    assert "--mod-sebenar" in keluaran


def test_setiap_peringkat_kitaran_ada_pelaksana():
    """`PERINGKAT_KITARAN` ialah dokumentasi. Kalau ia menyenaraikan
    peringkat yang tiada kodnya, laporan akan mendakwa liputan yang
    tidak wujud."""
    pelaksana = {
        "cipta": True,                       # dalam jalankan_satu
        "cetak": True,                       # dalam jalankan_satu
        "kemaskini": run_e2e.peringkat_kemaskini,
        "tn_nk": run_e2e.peringkat_tn_nk,
        "hantar": run_e2e.peringkat_hantar,
        "senarai": run_e2e.peringkat_senarai,
        "p006": True,                        # ditanda PERLU-MATA
    }
    for nama, _huraian, _status in run_e2e.PERINGKAT_KITARAN:
        assert pelaksana.get(nama), f"peringkat {nama} tiada pelaksana"


def test_status_port_mbjb_diakui_bukan_disahkan():
    """Peringkat yang page objectnya belum pernah dijalankan pada MBPG
    mesti ditanda demikian. Laporan tidak boleh mendakwa lebih daripada
    yang dibuktikan."""
    status = {n: s for n, _h, s in run_e2e.PERINGKAT_KITARAN}
    assert status["cipta"] == "disahkan"
    assert status["cetak"] == "disahkan"
    for nama in ("kemaskini", "tn_nk", "hantar", "senarai"):
        assert status[nama] == "port-MBJB", nama


def test_bendera_pada_tetapan_benar_benar_membuka_corong():
    """Pendawaian sebenar: menetapkan `tetapan.mod_sebenar = True` pada
    objek yang corong pegang mesti mengubah keputusan.

    Ini yang runner lakukan selepas sesi wujud, dan sebabnya `Tetapan`
    membaca persekitaran SEKALI semasa dibina — menetapkan
    `os.environ` selepas itu akan gagal SENYAP.
    """
    src = open(os.path.join(AKAR, "docs", "recon",
                            "k001-01-sebelum-mysikap.xml"),
               encoding="utf-8").read()
    konteks = dasar.konteks_mod_sebenar(src)
    tetapan = dasar.Tetapan(dry_run=True, benarkan_serah=False,
                            izin_serah=False)

    assert tetapan.mod_sebenar is False
    assert not dasar.nilai(["HANTAR"], tetapan,
                           konteks_mutasi=konteks).benarkan

    tetapan.mod_sebenar = True               # apa yang runner lakukan
    assert dasar.nilai(["HANTAR"], tetapan,
                       konteks_mutasi=konteks).benarkan


def test_env_var_selepas_tetapan_dibina_tidak_berkesan(monkeypatch):
    """Perangkap yang komen runner amarkan, dikunci oleh ujian.

    Kalau seseorang kemudian 'memudahkan' runner dengan menetapkan
    MBPG_MOD_SEBENAR selepas sesi dibina, ujian ini kekal hijau —
    tetapi ia mendokumenkan kenapa cara itu tidak berfungsi, jadi
    kegagalan device tidak menjadi misteri.
    """
    monkeypatch.delenv("MBPG_MOD_SEBENAR", raising=False)
    tetapan = dasar.Tetapan()
    monkeypatch.setenv("MBPG_MOD_SEBENAR", "1")
    assert tetapan.mod_sebenar is False, (
        "Tetapan membaca persekitaran sekali sahaja — menetapkannya "
        "selepas pembinaan tidak boleh berkuat kuasa")
    assert dasar.Tetapan().mod_sebenar is True


def test_penanda_dipakai_sebelum_isi_borang():
    """Runner mesti menandakan data SEBELUM mengisi, bukan selepas.

    Disemak pada sumber kerana laluan ini hanya boleh dijalankan
    dengan peranti — dan pepijat 'ditanda selepas diisi' akan
    menghasilkan rekod production dengan identiti oracle.
    """
    import inspect

    # Diskop kepada BADAN `jalankan_satu`, bukan seluruh fail. Mencari
    # kemunculan pertama dalam fail penuh memberi jawapan yang salah
    # sebaik fungsi pembantu wujud di ATAS fungsi ini — indeksnya
    # kemudian merujuk kod yang tiada kaitan dengan urutan ini.
    badan = inspect.getsource(run_e2e.jalankan_satu)
    i_tanda = badan.index("data = PU.tandai(asal")
    for penanda_isi in ("fill_pesalah_tab", "select_jenis_kompaun",
                        "isi_pesalah_k_mysikap"):
        assert badan.index(penanda_isi) > i_tanda, penanda_isi


def test_runner_berhenti_kalau_penanda_tidak_mengubah_apa_apa():
    """Kalau `tandai()` memulangkan data yang sama, rekod akan dicipta
    dengan identiti oracle. Runner mesti menolak, bukan meneruskan."""
    sumber = open(os.path.join(AKAR, "tools", "run_e2e.py"),
                  encoding="utf-8").read()
    assert "if not beza:" in sumber
    assert "arahan 3.3 larang" in sumber


def test_log_rekod_dipanggil_sebelum_kuota_ditolak():
    """Nombor rekod mesti dilog SEBELUM apa-apa lagi yang boleh gagal.

    Urutan yang salah di sini ialah tepat bagaimana siri 005 hilang
    pada 2026-08-13.
    """
    sumber = open(os.path.join(AKAR, "tools", "run_e2e.py"),
                  encoding="utf-8").read()
    i_log = sumber.index("laluan_log = rekod_log.log_rekod(")
    i_kuota = sumber.index("baki = izin.guna_satu(huruf)")
    i_cetak = sumber.index("hc = cetak.cetak_dari_popup(no_rekod)")
    assert i_log < i_kuota < i_cetak

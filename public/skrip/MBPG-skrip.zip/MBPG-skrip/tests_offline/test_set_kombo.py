"""
Ujian sistem set kombo — generator, kiraan, penapis. Tanpa peranti.

    python -m pytest tests_offline -q
"""

import json
import os
import subprocess
import sys
from collections import Counter

import pytest
import yaml

AKAR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
sys.path.insert(0, AKAR)

from testdata import sets_loader                              # noqa: E402
from tools import jana_set                                    # noqa: E402

MAPPING = os.path.join(AKAR, "testdata", "mapping",
                       "mbpg-mapping-2026-08-07.json")
DIR_SET = os.path.join(AKAR, "testdata", "sets")


# ---------------------------------------------------------------------------
# Kiraan — angka yang pemilik nyatakan
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def semua_fail():
    """Setiap fail set pada cakera, termasuk LUAR SKOP."""
    keluar = []
    for root, _d, files in os.walk(DIR_SET):
        for f in sorted(files):
            if f.endswith(".yaml"):
                p = os.path.join(root, f)
                with open(p, encoding="utf-8") as fh:
                    s = yaml.safe_load(fh)
                s["_laluan"] = p
                keluar.append(s)
    return keluar


def _penuh(sets):
    """Set laluan-penuh: kod x akta x kesalahan. Set negatif tidak
    dikira — ia mewakili ketiadaan laluan, bukan laluan."""
    return [s for s in sets if s["jangkaan"] in ("BOLEH_GUNA", "AMBIGU")]


def test_420_set_laluan_penuh(semua_fail):
    """Kiraan PRODUCTION, bukan staging. Staging memberi 411 dan
    diarkib ke testdata/sets-staging/ untuk rujukan silang sahaja —
    ia terbukti berbeza secara material (BEZA-STAGING-VS-PRODUCTION.md)."""
    assert len(_penuh(semua_fail)) == 420


def test_279_dalam_skop_141_luar_skop(semua_fail):
    p = _penuh(semua_fail)
    assert sum(1 for s in p if s["dalam_skop"]) == 279
    assert sum(1 for s in p if not s["dalam_skop"]) == 141


def test_pecahan_jenis_production(semua_fail):
    c = Counter(s["kod_kompaun"]["jenis"] for s in _penuh(semua_fail))
    assert c["PELBAGAI"] == 232
    assert c["LETAK KERETA"] == 47
    assert c["LESEN"] == 141


def test_sembilan_kod_kompaun_termasuk_yang_tiada_dalam_staging(semua_fail):
    """Production membawa 9 kod. Tiga daripadanya (08/09/10) TIADA dalam
    snapshot staging — ia tidak akan pernah diuji kalau sweep dibina dari
    mapping sahaja."""
    kod = {s["kod_kompaun"]["kod"] for s in semua_fail}
    assert kod == {"01", "02", "03", "05", "06", "07", "08", "09", "10"}
    for baru in ("08", "09", "10"):
        assert baru in kod


def test_setiap_set_penuh_bawa_kadar_denda(semua_fail):
    """Denda datang dari DB (amounnotis/min/max/mahkamah). Set staging
    tiada nilai ini langsung."""
    for s in _penuh(semua_fail):
        assert s.get("denda") is not None, s["set_id"]
        assert "min" in s["denda"] and "max" in s["denda"]


def test_amounnotis_sifar_pada_semua(semua_fail):
    """Dapatan yang direkod: 'denda notis' tidak digunakan pada MBPG.
    Kalau snapshot akan datang menunjukkan bukan-sifar, ujian ini gagal
    dan itu betul — ia bermakna andaian berubah."""
    nilai = {s["denda"]["notis"] for s in _penuh(semua_fail)}
    assert nilai <= {0.0, None}, f"amounnotis bukan-sifar muncul: {nilai}"


def test_sumber_ditanda_db_production(semua_fail):
    assert {s["sumber"] for s in semua_fail} == {"db-production"}


def test_lesen_diasingkan_ke_luar_skop(semua_fail):
    for s in semua_fail:
        if s["kod_kompaun"]["jenis"] == "LESEN":
            assert not s["dalam_skop"]
            assert "_LUAR-SKOP" in s["_laluan"].replace("\\", "/")


def test_borang_dipetakan_betul(semua_fail):
    for s in semua_fail:
        j = s["kod_kompaun"]["jenis"]
        if j == "PELBAGAI":
            assert s["borang"] == ["N", "P"], s["set_id"]
        elif j == "LETAK KERETA":
            assert s["borang"] == ["K"], s["set_id"]
        elif j == "LESEN":
            assert s["borang"] == ["L"], s["set_id"]


# ---------------------------------------------------------------------------
# Jangkaan — dikira dari data, bukan dari senarai dalam arahan
# ---------------------------------------------------------------------------

def test_ambigu_lenyap_pada_production(semua_fail):
    """Snapshot staging mempunyai 3 nama akta berulang, yang menandakan
    130 set AMBIGU. DB production TIDAK mempunyai nama berulang, jadi
    kategori itu hilang sepenuhnya — termasuk 29 daripada 74 set LETAK
    KERETA yang sebelum ini ambigu."""
    assert not [s for s in semua_fail if s["jangkaan"] == "AMBIGU"]


def _rujukan_sahaja_jangkaan_mapping(semua_fail):
    """Ringkasan arahan menamakan 4 kod tanpa akta dan 1 akta mati.
    Mapping sebenar mengandungi 10 dan 5. Generator mesti mengikut DATA —
    mengekodkan senarai pendek itu akan menyembunyikan bakinya daripada
    sweep."""
    with open(MAPPING, encoding="utf-8") as fh:
        d = json.load(fh)
    kosong_data = set(d["analisis"]["kod_kompaun_tanpa_akta"])
    kosong_set = {s["kod_kompaun"]["kod"] for s in semua_fail
                  if s["jangkaan"] == "JANGKA_KOSONG"}
    assert kosong_set == kosong_data
    assert len(kosong_set) == 10, "arahan kata 4; mapping ada 10"

    mati = [s for s in semua_fail if s["jangkaan"] == "JANGKA_MATI_T3"]
    assert len(mati) == 5, "arahan kata 1 (kod 06); mapping ada 5"
    assert "06" in {s["kod_kompaun"]["kod"] for s in mati}


def test_arkib_staging_masih_ada_untuk_rujukan_silang():
    """Set staging lama TIDAK dipadam — ia bukti apa yang portal katakan,
    dan laporan beza bergantung padanya. Tetapi ia mesti TIDAK boleh
    dimuatkan oleh sweep."""
    arkib = os.path.join(AKAR, "testdata", "sets-staging")
    n = sum(1 for _r, _d, fs in os.walk(arkib) for f in fs
            if f.endswith(".yaml"))
    assert n == 426, f"arkib staging ada {n} fail, dijangka 426"
    dimuat = {s["_laluan"].replace("\\", "/")
              for s in sets_loader.muat_semua()}
    assert not any("sets-staging" in p for p in dimuat), \
        "pemuat sweep mengambil set staging yang diarkib"


def test_laporan_beza_dijana():
    """Dapatan untuk PM: apa yang wujud sebelah sana sahaja."""
    p = os.path.join(DIR_SET, "BEZA-STAGING-VS-PRODUCTION.md")
    assert os.path.exists(p)
    isi = open(p, encoding="utf-8").read()
    for mesti in ("Hanya pada PRODUCTION", "Beza TEKS tingkat-1",
                  "`08`", "`09`", "`10`"):
        assert mesti in isi, f"laporan beza tiada {mesti!r}"


def test_set_negatif_tiada_kesalahan(semua_fail):
    for s in semua_fail:
        if s["jangkaan"] == "JANGKA_KOSONG":
            assert s["akta"] is None and s["kesalahan"] is None, s["set_id"]
        if s["jangkaan"] == "JANGKA_MATI_T3":
            assert s["akta"] is not None and s["kesalahan"] is None, s["set_id"]


# ---------------------------------------------------------------------------
# Idempoten
# ---------------------------------------------------------------------------

def test_generator_idempoten():
    """Jana semula = hasil sama, bait demi bait."""
    r = subprocess.run([sys.executable, os.path.join("tools", "jana_set.py"),
                        "--semak"], cwd=AKAR, capture_output=True, text=True)
    assert r.returncode == 0, r.stdout + r.stderr


def test_generator_stabil_merentas_dua_larian(tmp_path):
    a = jana_set.jana(MAPPING, str(tmp_path / "a"))[0]
    b = jana_set.jana(MAPPING, str(tmp_path / "b"))[0]
    assert a == b


def test_generator_membuang_set_stale(tmp_path):
    """Snapshot baharu tidak boleh meninggalkan set hantu — fail yang
    masih dikutip oleh sweep dan dilaporkan lulus walaupun kombinasinya
    sudah tiada dalam mapping."""
    keluar = str(tmp_path / "sets")
    fail, _ = jana_set.jana(MAPPING, keluar)
    for rel, isi in fail.items():
        p = os.path.join(keluar, rel)
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p, "w", encoding="utf-8", newline="\n") as fh:
            fh.write(isi)
    hantu = os.path.join(keluar, "KK99-HANTAR", "SET-HANTU.yaml")
    os.makedirs(os.path.dirname(hantu), exist_ok=True)
    with open(hantu, "w", encoding="utf-8") as fh:
        fh.write("set_id: hantu\n")
    dipadam = jana_set._bersih_stale(keluar, set(fail))
    assert not os.path.exists(hantu)
    assert any("SET-HANTU" in d for d in dipadam)


def test_index_dijana(semua_fail):
    p = os.path.join(DIR_SET, "INDEX.md")
    assert os.path.exists(p)
    isi = open(p, encoding="utf-8").read()
    assert "420" in isi and "279" in isi
    assert "DB PERANTI PRODUCTION" in isi
    assert "tergantung" in isi, "INDEX mesti merekod rujukan akta tergantung"


# ---------------------------------------------------------------------------
# Pemuat — LESEN tidak boleh dimuatkan walaupun dipilih
# ---------------------------------------------------------------------------

@pytest.fixture(scope="module")
def dimuat():
    return sets_loader.muat_semua()


def test_pemuat_hanya_dalam_skop(dimuat):
    assert len(dimuat) == 284            # 279 laluan penuh + 5 set negatif
    assert all(s["dalam_skop"] for s in dimuat)
    assert not any(s["kod_kompaun"]["jenis"] == "LESEN" for s in dimuat)


def test_lesen_tidak_boleh_dipilih_walaupun_sengaja(dimuat):
    """`--kk 02` yang tersilap taip tidak boleh memandu 81 set LESEN."""
    assert sets_loader.tapis(dimuat, kk=["02"]) == []


# ---------------------------------------------------------------------------
# Penapis
# ---------------------------------------------------------------------------

def test_tapis_kk(dimuat):
    r = sets_loader.tapis(dimuat, kk=["01"])
    assert r and all(s["kod_kompaun"]["kod"] == "01" for s in r)
    assert len(r) == 118


def test_tapis_kk_03_ialah_letak_kereta(dimuat):
    r = sets_loader.tapis(dimuat, kk=["03"])
    assert len(r) == 48
    assert all(s["borang"] == ["K"] for s in r)


def test_tapis_set_id(dimuat):
    r = sets_loader.tapis(dimuat, set_id=["SET-KK01-AKT2-111"])
    assert len(r) == 1
    assert r[0]["set_id"] == "SET-KK01-AKT2-111"


def test_tapis_borang(dimuat):
    p = sets_loader.tapis(dimuat, borang=["P"])
    k = sets_loader.tapis(dimuat, borang=["K"])
    assert len(p) == 236 and len(k) == 48
    assert all("P" in s["borang"] for s in p)


def test_tapis_jangkaan(dimuat):
    r = sets_loader.tapis(dimuat, jangkaan=["BOLEH_GUNA"])
    assert r and all(s["jangkaan"] == "BOLEH_GUNA" for s in r)


def test_penapis_digabung_dengan_DAN(dimuat):
    r = sets_loader.tapis(dimuat, kk=["01"], jangkaan=["BOLEH_GUNA"])
    assert all(s["kod_kompaun"]["kod"] == "01"
               and s["jangkaan"] == "BOLEH_GUNA" for s in r)
    assert len(r) < len(sets_loader.tapis(dimuat, kk=["01"]))


def test_flag_diulang_ialah_ATAU(dimuat):
    r = sets_loader.tapis(dimuat, kk=["01", "03"])
    kod = {s["kod_kompaun"]["kod"] for s in r}
    assert kod == {"01", "03"}


def test_penapis_tidak_padan_pulang_kosong(dimuat):
    assert sets_loader.tapis(dimuat, kk=["99"]) == []


# ---------------------------------------------------------------------------
# Sampel N
# ---------------------------------------------------------------------------

def test_sampel_n_26_dan_deterministik(dimuat):
    p = sets_loader.pilih_untuk_borang(dimuat, "N")
    assert len(p) == 26
    assert p == sets_loader.pilih_untuk_borang(dimuat, "N")


def test_sampel_n_merentas_akta_berlainan(dimuat):
    """26 pertama mengikut abjad semuanya jatuh di bawah satu atau dua
    akta. Sampel mesti merentas pokok, bukan mengulang satu cabang."""
    p = sets_loader.pilih_untuk_borang(dimuat, "N")
    aktas = {(s["kod_kompaun"]["kod"], (s["akta"] or {}).get("id"))
             for s in p}
    assert len(aktas) == 26


def test_n_penuh_membuka_semua(dimuat):
    assert len(sets_loader.pilih_untuk_borang(dimuat, "N", n_penuh=True)) == 236


def test_p_dan_k_sentiasa_penuh(dimuat):
    assert len(sets_loader.pilih_untuk_borang(dimuat, "P")) == 236
    assert len(sets_loader.pilih_untuk_borang(dimuat, "K")) == 48


# ---------------------------------------------------------------------------
# Keselamatan CLI — hujung ke hujung
# ---------------------------------------------------------------------------

def _kutip(args):
    env = dict(os.environ, MBPG_PROFILE="_semak_kombo",
               MBPG_IZIN_PRODUCTION="1")
    r = subprocess.run(
        [sys.executable, "-m", "pytest", "--collect-only", "-q",
         "-p", "no:warnings", "tests/menu_pelbagai", "tests/menu_notis",
         "tests/menu_letak_kereta"] + args,
        cwd=AKAR, capture_output=True, text=True, env=env)
    return r.stdout + r.stderr


@pytest.fixture(scope="module", autouse=True)
def _profil_sementara():
    src = os.path.join(AKAR, "profiles", "mbpg-production.json")
    dst = os.path.join(AKAR, "profiles", "_semak_kombo.json")
    with open(src, encoding="utf-8") as fh:
        isi = fh.read()
    with open(dst, "w", encoding="utf-8") as fh:
        fh.write(isi)
    yield
    if os.path.exists(dst):
        os.remove(dst)


def test_tanpa_flag_tiada_set_dijalankan():
    """SIFAT KESELAMATAN. 330 set pada peranti production tidak boleh
    bermula kerana seseorang menaip `pytest`."""
    keluar = _kutip([])
    assert "tiada-set-dipilih" in keluar
    assert "SET-KK" not in keluar, "set sebenar dikutip tanpa flag"


def test_flag_kk_mengutip_set_sebenar():
    keluar = _kutip(["--kk", "01"])
    assert "SET-KK01" in keluar
    # Borang K tiada set kod 01, jadi placeholder langkaunya SAH untuk
    # menu itu — tetapi P mesti mengutip set sebenar.
    assert "SET-KK01-AKT2" in keluar


def test_flag_set_mengutip_satu_sahaja():
    keluar = _kutip(["--set", "SET-KK01-AKT2-111"])
    assert keluar.count("SET-KK01-AKT2-111") >= 1
    assert "SET-KK01-AKT2-124" not in keluar

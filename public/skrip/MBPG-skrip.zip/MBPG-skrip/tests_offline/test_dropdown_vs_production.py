"""
GERBANG — nilai dropdown 3 tingkat SAH pada production, bukan staging.

>>> KENAPA FAIL INI WUJUD. <<<
PAPAN.md §10 merekod bahawa pemetaan staging BERBEZA secara material
daripada DB production, dan bahawa 4 daripada 6 kod yang dikongsi
mempunyai TEKS PAPARAN berbeza ('KOMPAUN PELBAGAI' lawan 'KOMPAUN
PELBAGAI JP'). Enjin dropdown ialah MATCH-OR-FAIL, jadi satu aksara
yang berbeza bermakna kegagalan — dan kegagalan itu berlaku SELEPAS
borang diisi penuh dan gambar diambil, iaitu titik paling mahal.

Ujian ini menjalankan nilai oracle untuk ketiga-tiga borang terhadap
snapshot DB production SEBENAR, membina baris modal persis seperti app
merendernya ('[<kod>] - <keterangan>' untuk tingkat 3), dan menuntut
padanan. Ia menangkap percanggahan oracle-lawan-production di mesin
pembangunan, bukan pada rekod production yang separuh siap.

Perangkap sebenar yang ia lindungi (disahkan 2026-08-17): oracle P-001
dan K-001 membawa NOKTAH di hujung teks kesalahan; DB production tidak.
`_padan_baris_modal` menormalkan ekor sejak 2026-08-10 — ujian ini
memastikan normalisasi itu tidak pernah dibuang.
"""

import os
import sqlite3
import sys

import pytest

AKAR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if AKAR not in sys.path:
    sys.path.insert(0, AKAR)

from pages.daftar_kompaun_page import DaftarKompaunPage as D    # noqa: E402
from testdata import oracle_n001, oracle_pk                     # noqa: E402

DB = os.path.join(AKAR, "data", "snapshot-20260811", "e_kompaunV1.db")

BORANG = [
    ("N-001", oracle_n001.SEMUA),
    ("P-001", oracle_pk.P001),
    ("K-001", oracle_pk.K001),
]


def _norm(s):
    return (s or "").strip().rstrip(".").strip().upper()


@pytest.fixture(scope="module")
def cur():
    if not os.path.exists(DB):
        pytest.skip("snapshot DB production tiada")
    con = sqlite3.connect(DB)
    con.text_factory = str
    return con.cursor()


@pytest.mark.parametrize("nama,data", BORANG, ids=[b[0] for b in BORANG])
def test_tiga_tingkat_wujud_pada_production(nama, data, cur):
    t1 = cur.execute("SELECT kod FROM local_ekpn_kod_kompaun "
                     "WHERE UPPER(TRIM(keterangan))=?",
                     (data["keterangan_kod_kompaun"].strip().upper(),)
                     ).fetchone()
    assert t1, f"{nama}: kod kompaun tiada pada production"
    t2 = cur.execute("SELECT kod FROM local_ekpn_akta "
                     "WHERE UPPER(TRIM(keterangan))=?",
                     (data["kod_akta"].strip().upper(),)).fetchone()
    assert t2, f"{nama}: akta tiada pada production"
    t3 = [r for r in cur.execute(
        "SELECT kodkesalahan,fk_akta FROM local_ekpn_kesalahan_kompaun "
        "WHERE UPPER(TRIM(REPLACE(kesalahan,'.','')))=?",
        (_norm(data["kesalahan_kompaun"]).replace(".", ""),))]
    assert t3, f"{nama}: kesalahan tiada pada production"
    # Kesalahan mesti tergolong di bawah akta yang dipilih, kalau tidak
    # app tidak akan menawarkannya pada tingkat 3.
    assert any(str(r[1]) == str(t2[0]) for r in t3), (
        f"{nama}: kesalahan wujud tetapi fk_akta={[r[1] for r in t3]} "
        f"tidak tergolong di bawah akta kod {t2[0]}")


@pytest.mark.parametrize("nama,data", BORANG, ids=[b[0] for b in BORANG])
def test_baris_modal_sebenar_dipadan(nama, data, cur):
    """Bina baris SEPERTI APP MERENDERNYA dan tuntut padanan."""
    b1 = cur.execute("SELECT keterangan FROM local_ekpn_kod_kompaun "
                     "WHERE UPPER(TRIM(keterangan))=?",
                     (data["keterangan_kod_kompaun"].strip().upper(),)
                     ).fetchone()[0]
    assert D._padan_baris_modal(b1, data["keterangan_kod_kompaun"]), nama

    b2 = cur.execute("SELECT keterangan FROM local_ekpn_akta "
                     "WHERE UPPER(TRIM(keterangan))=?",
                     (data["kod_akta"].strip().upper(),)).fetchone()[0]
    assert D._padan_baris_modal(b2, data["kod_akta"]), nama

    row = [r for r in cur.execute(
        "SELECT kodkesalahan,kesalahan FROM local_ekpn_kesalahan_kompaun")
        if _norm(r[1]) == _norm(data["kesalahan_kompaun"])]
    assert row, f"{nama}: kesalahan tiada"
    baris_t3 = f"[{row[0][0].upper()}] - {row[0][1]}"
    assert D._padan_baris_modal(baris_t3, data["kesalahan_kompaun"]), (
        f"{nama}: baris tingkat 3 tidak dipadan.\n"
        f"  app    = {baris_t3!r}\n"
        f"  oracle = {data['kesalahan_kompaun']!r}")


@pytest.mark.parametrize("nama,data", BORANG, ids=[b[0] for b in BORANG])
def test_kadar_denda_dalam_julat_production(nama, data, cur):
    """Kadar denda oracle mesti berada dalam julat min/max DB, kalau
    tidak medan itu menolak nilai dan SETERUSNYA tersekat senyap."""
    mentah = str(data.get("kadar_denda") or "").upper()
    digit = "".join(c for c in mentah if c.isdigit() or c == ".")
    if not digit:
        pytest.skip(f"{nama}: oracle tiada kadar denda")
    row = [r for r in cur.execute(
        "SELECT kesalahan,amounmin,amounmax FROM local_ekpn_kesalahan_kompaun")
        if _norm(r[0]) == _norm(data["kesalahan_kompaun"])][0]
    nilai, lo, hi = float(digit), row[1], row[2]
    assert lo <= nilai <= hi, (
        f"{nama}: kadar denda {nilai} di luar julat production "
        f"{lo}-{hi}")


def test_noktah_hujung_dinormalkan_tetapi_ketegasan_kekal():
    """Normalisasi ekor menyelesaikan percanggahan oracle-lawan-DB
    TANPA membenarkan baris jiran dipilih."""
    assert D._padan_baris_modal("KEROSAKAN HARTA MPPG",
                                "KEROSAKAN HARTA MPPG.")
    assert D._padan_baris_modal("[UUK 3 (N)] - HARTA MPPG", "HARTA MPPG.")
    # Yang ini mesti KEKAL ditolak — sebab match-or-FAIL wujud.
    assert not D._padan_baris_modal("KOMPAUN PELBAGAI",
                                    "KOMPAUN PELBAGAI JP")
    assert not D._padan_baris_modal("KOMPAUN PELBAGAI JP",
                                    "KOMPAUN PELBAGAI")
    assert not D._padan_baris_modal("[X] - MEMBUAT SESUATU",
                                    "MEMBUAT SESUATU YANG LAIN")

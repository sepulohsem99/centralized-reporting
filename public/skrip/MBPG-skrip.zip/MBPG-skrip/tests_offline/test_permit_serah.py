"""
Gerbang untuk PERMIT BERSKOP Fasa C.

Yang diuji di sini ialah pembetulan paling penting dalam projek:
dry-run OFF tidak lagi bermakna "benarkan semuanya". Trip-wire dinilai
dalam SETIAP mod, dan hanya butang yang permit namakan boleh lulus.

Sebelum pembetulan ini, `MBPG_DRY_RUN=0 + MBPG_IZIN_SERAH=1` — yang
diset untuk membenarkan SATU rekod — turut membuka PADAM, KEMASKINI,
dan Selaras Pelesen (sync 3-4 jam, diharamkan mutlak).
"""

import os
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from guard.dasar import PermitSerah, Tetapan, nilai                # noqa: E402

C1 = "C1-N-001"
WHITELIST = ("C1-N-001", "C2-P-001", "C3-K-001")


@pytest.fixture
def dry_off(monkeypatch):
    """Keadaan Fasa C hidup: kedua-dua bendera diset pemilik."""
    monkeypatch.setenv("MBPG_DRY_RUN", "0")
    monkeypatch.setenv("MBPG_IZIN_SERAH", "1")
    t = Tetapan()
    assert t.dry_run is False
    return t


# ===========================================================================
# Tuntutan pemilik: yang MESTI kekal disekat walau dry-run OFF
# ===========================================================================
@pytest.mark.parametrize("butang", [
    "PADAM", "Padam", "HAPUS", "Hapus", "PADAM REKOD", "HAPUS BOOKMARK",
])
def test_padam_hapus_disekat_mati_walau_dry_run_off(dry_off, butang):
    assert not nilai([butang], dry_off).benarkan, butang


@pytest.mark.parametrize("butang", [
    "Selaras Maklumat Pelesen", "SELARAS MAKLUMAT PELESEN", "PELESEN",
])
def test_pelesen_disekat_mati_walau_dry_run_off(dry_off, butang):
    """Sync 3-4 jam. Diharamkan mutlak sejak hari pertama."""
    assert not nilai([butang], dry_off).benarkan, butang


@pytest.mark.parametrize("butang", ["KEMASKINI", "Kemaskini Notis Amaran"])
def test_kemaskini_disekat_mati_walau_dry_run_off(dry_off, butang):
    assert not nilai([butang], dry_off).benarkan, butang


def test_dengan_permit_pun_padam_pelesen_kemaskini_kekal_disekat(dry_off):
    """Permit dibuka untuk C1 TIDAK membuka apa-apa selain butangnya."""
    dry_off.permit_serah = PermitSerah(C1, had=3)
    for butang in ("PADAM", "HAPUS", "KEMASKINI",
                   "Selaras Maklumat Pelesen"):
        assert not nilai([butang], dry_off).benarkan, butang


# ===========================================================================
# Tuntutan pemilik: SERAH untuk TC dalam/luar whitelist
# ===========================================================================
def test_serah_tanpa_permit_disekat(dry_off):
    """Dua bendera SAHAJA tidak memberi apa-apa."""
    for butang in ("SERAH", "YA", "SAHKAN", "HANTAR", "CETAK"):
        assert not nilai([butang], dry_off).benarkan, butang


def test_serah_dengan_permit_c1_lulus(dry_off):
    dry_off.permit_serah = PermitSerah(C1, had=3)
    for butang in ("SERAH", "YA", "SAHKAN", "HANTAR", "CETAK"):
        k = nilai([butang], dry_off)
        assert k.benarkan, f"{butang}: {k.sebab}"
        assert k.peraturan == "PERMIT-FASA-C"
        assert C1 in k.sebab


def test_permit_untuk_tc_lain_tidak_membuka_tc_ini(dry_off):
    """Permit dinamakan kepada SATU TC. Ia bukan suis global.

    Penguatkuasaan whitelist berlaku pada gerbang_serah.semak(), yang
    dipanggil SEBELUM permit dibina — jadi permit untuk TC luar
    whitelist tidak boleh wujud. Yang diuji di sini: permit membawa
    nama TC-nya, supaya ledger dan sebab menunjukkan rekod MANA yang
    dibenarkan."""
    dry_off.permit_serah = PermitSerah("C2-P-001", had=3)
    k = nilai(["SERAH"], dry_off)
    assert k.benarkan
    assert "C2-P-001" in k.sebab and C1 not in k.sebab


# ===========================================================================
# Had
# ===========================================================================
def test_permit_berhenti_pada_had(dry_off):
    dry_off.permit_serah = PermitSerah(C1, had=1, kiraan=0)
    assert nilai(["SERAH"], dry_off).benarkan
    dry_off.permit_serah.kiraan = 1
    assert not nilai(["SERAH"], dry_off).benarkan


def test_had_sifar_tidak_membenarkan_apa_apa(dry_off):
    dry_off.permit_serah = PermitSerah(C1, had=0)
    assert not nilai(["SERAH"], dry_off).benarkan


# ===========================================================================
# Permukaan permit
# ===========================================================================
def test_permit_hanya_membuka_butang_yang_dinamakan(dry_off):
    """Permit dengan SERAH sahaja tidak membuka YA."""
    dry_off.permit_serah = PermitSerah(C1, butang=("SERAH",), had=3)
    assert nilai(["SERAH"], dry_off).benarkan
    assert not nilai(["YA"], dry_off).benarkan
    assert not nilai(["SAHKAN"], dry_off).benarkan


def test_padanan_permit_bersauh():
    """Diuji pada PERMIT itu sendiri, bukan melalui nilai().

    Melalui nilai(), rentetan seperti 'TIDAK YA' lulus atas sebab LAIN
    (ia bukan trip-wire, dan 'TIDAK' ialah keluar-selamat). Yang perlu
    dibuktikan di sini ialah permit tidak MELUASKAN dirinya kepada
    teks yang hampir menyerupai butangnya."""
    p = PermitSerah(C1, had=3)
    for tepat in ("SERAH", "YA", "SAHKAN", "HANTAR", "CETAK",
                  " serah ", "Hantar Semula"):
        assert p.membenarkan(tepat), tepat
    for hampir in ("SERAH SEMULA KEPADA MAHKAMAH", "TIDAK YA",
                   "SAHKAN PADAM", "YANG", "CETAK SEMULA RESIT",
                   "HANTAR DATA & GAMBAR", "PADAM", "KEMASKINI"):
        assert not p.membenarkan(hampir), hampir


def test_permit_tiada_sumber_persekitaran(monkeypatch):
    """Permit mesti dibina oleh kod yang melepasi gerbang — ia tidak
    boleh dihidupkan dengan pembolehubah persekitaran."""
    monkeypatch.setenv("MBPG_DRY_RUN", "0")
    monkeypatch.setenv("MBPG_IZIN_SERAH", "1")
    monkeypatch.setenv("MBPG_PERMIT_SERAH", "1")
    monkeypatch.setenv("PERMIT_SERAH", "C1-N-001")
    assert Tetapan().permit_serah is None


# ===========================================================================
# Mod dry-run biasa tidak berubah
# ===========================================================================
def test_dry_run_hidup_kekal_menyekat_semua(monkeypatch):
    monkeypatch.setenv("MBPG_DRY_RUN", "1")
    monkeypatch.delenv("MBPG_IZIN_SERAH", raising=False)
    t = Tetapan()
    assert t.dry_run is True
    for butang in ("SERAH", "YA", "SAHKAN", "HANTAR", "PADAM", "KEMASKINI"):
        assert not nilai([butang], t).benarkan, butang


def test_keluar_selamat_kekal_lulus(dry_off):
    """BATAL/TIDAK ialah laluan pemulihan wajib selepas popup serah."""
    for butang in ("BATAL", "TIDAK", "CANCEL", "TUTUP"):
        assert nilai([butang], dry_off).benarkan, butang

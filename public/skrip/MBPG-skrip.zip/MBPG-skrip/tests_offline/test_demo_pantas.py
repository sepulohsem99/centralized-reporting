"""
Gerbang untuk mod DEMO-PANTAS.

Yang mod ini optimumkan ialah masa; yang ia TIDAK boleh korbankan ialah
jaminan borang-bersih. Ujian di sini mengunci tepat itu:

  * relaunch berlaku bila draf ADA,
  * relaunch TIDAK berlaku bila borang bersih,
  * draf diperiksa pada borang YANG DIBUKA, bukan borang lain,
  * kegagalan membaca dikira KOTOR (fail ke arah memulihkan),
  * laluan audit tidak terjejas oleh bendera mod demo.
"""

import os
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from devtools import demo_pantas as DP                        # noqa: E402


# ---------------------------------------------------------------------------
# Dua kali ganda: borang tiruan yang boleh bersih atau berdraf
# ---------------------------------------------------------------------------
class _ElemenTiruan:
    def __init__(self, teks, hint):
        self.teks, self.hint = teks, hint


class _PageTiruan:
    """Meniru bahagian page object yang borang_ada_draf() sentuh."""

    def __init__(self, nama, kosong=True, meletup=False):
        self.nama = nama
        self.kosong = kosong
        self.meletup = meletup
        self.dibaca = 0

    def find_element(self, locator, timeout=None):
        self.dibaca += 1
        if self.meletup:
            raise RuntimeError("elemen tidak dijumpai")
        # Medan kosong memaparkan placeholder sebagai text; berdraf tidak.
        t = self.nama if self.kosong else "DATA LAMA"
        return _ElemenTiruan(t, self.nama)

    def _medan_kosong(self, el):
        return (el.teks == el.hint), ("" if el.teks == el.hint else el.teks)


class _HomeTiruan:
    def is_home_screen_displayed(self):
        return True


class _PagesTiruan:
    def __init__(self, p):
        self.daftar_kompaun = p
        self.notis_amaran = p
        self.home = _HomeTiruan()


# ---------------------------------------------------------------------------
# borang_ada_draf
# ---------------------------------------------------------------------------
def test_borang_bersih_bukan_draf():
    p = _PageTiruan("Nama Pesalah", kosong=True)
    assert DP.borang_ada_draf(_PagesTiruan(p), p) is False


def test_borang_berdraf_dikesan():
    p = _PageTiruan("Nama Pesalah", kosong=False)
    assert DP.borang_ada_draf(_PagesTiruan(p), p) is True


def test_gagal_membaca_dikira_kotor():
    """Fail ke arah memulihkan. Relaunch yang tidak perlu membuang
    ~40s; meneruskan pada borang kotor merosakkan TC dan setiap TC
    selepasnya."""
    p = _PageTiruan("Nama Pesalah", meletup=True)
    assert DP.borang_ada_draf(_PagesTiruan(p), p) is True


def test_draf_diperiksa_pada_borang_yang_diberi():
    """REGRESI: versi terdahulu memeriksa borang NOTIS dan melaporkan
    'tiada draf' sejurus sebelum K-001, yang kemudian gagal atas draf
    borang KOMPAUN PELBAGAI. Draf bersifat PER-BORANG."""
    notis = _PageTiruan("Nama Pesalah", kosong=True)
    kompaun = _PageTiruan("Nama Pesalah", kosong=False)
    pages = _PagesTiruan(notis)
    # Diperiksa terhadap `kompaun` walaupun pages membawa notis:
    # borang_ada_draf mesti menggunakan p yang DIHANTAR.
    assert DP.borang_ada_draf(pages, kompaun) is True
    assert kompaun.dibaca == 1
    assert notis.dibaca == 0


# ---------------------------------------------------------------------------
# buka_borang_bersih — relaunch bersyarat
# ---------------------------------------------------------------------------
@pytest.fixture
def tanpa_peranti(monkeypatch):
    """Potong sentuhan peranti sebenar: pastikan_di_home dan relaunch."""
    jejak = {"relaunch": 0, "buka": 0}

    monkeypatch.setattr("devtools.smoke_tangga.pastikan_di_home",
                        lambda drv, pages: True)

    def _relaunch(drv, pages, sebab):
        jejak["relaunch"] += 1
        # Selepas relaunch, borang menjadi bersih.
        pages.daftar_kompaun.kosong = True
        return True

    monkeypatch.setattr(DP, "relaunch_pantas", _relaunch)
    return jejak


def test_tiada_relaunch_bila_borang_bersih(tanpa_peranti):
    """Inti keseluruhan mod ini. Demo penuh melakukan 3 relaunch tanpa
    syarat; kebanyakannya pada borang yang memang bersih."""
    p = _PageTiruan("Nama Pesalah", kosong=True)
    pages = _PagesTiruan(p)
    ok, bil = DP.buka_borang_bersih(
        None, pages, lambda: tanpa_peranti.__setitem__(
            "buka", tanpa_peranti["buka"] + 1), "TC", p=p)
    assert ok is True
    assert bil == 0
    assert tanpa_peranti["relaunch"] == 0
    assert tanpa_peranti["buka"] == 1


def test_relaunch_bila_draf_ada(tanpa_peranti):
    p = _PageTiruan("Nama Pesalah", kosong=False)
    pages = _PagesTiruan(p)
    ok, bil = DP.buka_borang_bersih(
        None, pages, lambda: tanpa_peranti.__setitem__(
            "buka", tanpa_peranti["buka"] + 1), "TC", p=p)
    assert ok is True
    assert bil == 1
    assert tanpa_peranti["relaunch"] == 1
    # Dibuka sekali sebelum relaunch, sekali selepas.
    assert tanpa_peranti["buka"] == 2


def test_relaunch_tidak_diulang_bila_draf_degil(monkeypatch):
    """Kalau draf KEKAL selepas satu relaunch, jangan gelung. Lapor
    dan biar TC gagal dengan jujur."""
    jejak = {"relaunch": 0}
    monkeypatch.setattr("devtools.smoke_tangga.pastikan_di_home",
                        lambda drv, pages: True)

    def _relaunch(drv, pages, sebab):
        jejak["relaunch"] += 1
        return True       # borang KEKAL kotor

    monkeypatch.setattr(DP, "relaunch_pantas", _relaunch)
    p = _PageTiruan("Nama Pesalah", kosong=False)
    ok, bil = DP.buka_borang_bersih(None, _PagesTiruan(p),
                                    lambda: None, "TC", p=p)
    assert ok is False
    assert bil == 1
    assert jejak["relaunch"] == 1


def test_gagal_sampai_home_tidak_mengaku_bersih(monkeypatch):
    monkeypatch.setattr("devtools.smoke_tangga.pastikan_di_home",
                        lambda drv, pages: False)
    p = _PageTiruan("Nama Pesalah", kosong=True)
    ok, bil = DP.buka_borang_bersih(None, _PagesTiruan(p),
                                    lambda: None, "TC", p=p)
    assert ok is False
    assert bil == 0


# ---------------------------------------------------------------------------
# Laluan audit tidak boleh terjejas
# ---------------------------------------------------------------------------
def test_lalai_borang_kompaun_kekal_relaunch_wajib():
    """`sudah_dibuka` mesti lalai False supaya suite audit — yang
    bergantung pada relaunch tanpa syarat — tidak berubah kelakuan
    hanya kerana mod demo wujud."""
    import inspect
    from devtools import peringkat6 as P6
    sig = inspect.signature(P6.borang_kompaun)
    assert sig.parameters["sudah_dibuka"].default is False
    assert inspect.signature(P6.k001_epbt).parameters["pantas"].default \
        is False


def test_mod_demo_perlukan_bendera(monkeypatch, capsys):
    """Tanpa MBPG_DEMO_PANTAS=1 ia enggan berjalan — supaya laluan
    pantas tidak boleh digunakan secara tidak sengaja untuk audit."""
    monkeypatch.delenv("MBPG_DEMO_PANTAS", raising=False)
    assert DP.main() == 2
    assert "flag" in capsys.readouterr().out.lower()

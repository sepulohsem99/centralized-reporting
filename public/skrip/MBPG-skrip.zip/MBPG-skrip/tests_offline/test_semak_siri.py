"""Gerbang kaunter siri.

Pemasangan APK 2.1.23 mengosongkan `local_system_control`; kedua-dua
kaunter jatuh 9 -> 1 sedangkan rekod `PGP02P260818003`..`008` masih
hidup pada production. Larian seterusnya pada hari yang sama akan
mengeluarkan semula 003.

Larian 2026-08-18 petang terlepas hanya kerana ia mengeluarkan 001 dan
002, yang kebetulan bebas, dan tarikh kemudian berputar. Ujian di sini
menghapuskan kebergantungan pada nasib itu.
"""

import inspect
import os
import sys

AKAR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, AKAR)

from tools import run_penuh, semak_siri                     # noqa: E402


KAUNTER_SELEPAS_WIPE = {
    "local_ekpn_notis_amaran": 1,
    "local_ekpn_tawaran_kompaun": 3,      # 001, 002 sudah dikeluarkan
}
PRODUCTION = {
    "PGP02P260813001", "PGP02K260813002", "PGP02N260813006",
    "PGP02N260813007", "PGP02N260817008", "PGP02P260818003",
    "PGP02P260818004", "PGP02P260818005", "PGP02P260818006",
    "PGP02P260818007", "PGP02K260818008", "PGP02N260818001",
    "PGP02P260818001", "PGP02P260818002",
}


def test_format_nombor_seperti_production():
    calon = dict(semak_siri.calon_seterusnya(
        {"local_ekpn_tawaran_kompaun": 3}, "260819"))
    assert calon["P"] == "PGP02P260819003"
    assert calon["K"] == "PGP02K260819003"


def test_kaunter_kompaun_dikongsi_p_dan_k():
    """Rekod K menaikkan kaunter yang rekod P gunakan. Menyemak satu
    sahaja terlepas separuh daripada risiko."""
    assert set(semak_siri.KAUNTER["local_ekpn_tawaran_kompaun"]) == {"P", "K"}
    assert semak_siri.KAUNTER["local_ekpn_notis_amaran"] == ("N",)


def test_pertembungan_sebenar_dikesan_pada_hari_sama():
    """Senario tepat: run LAGI pada 18hb selepas reset."""
    b = semak_siri.kesan(KAUNTER_SELEPAS_WIPE, PRODUCTION, "260818")
    assert ("P", "PGP02P260818003") in b


def test_tarikh_berbeza_tiada_pertembungan():
    """Tarikh terbenam dalam nombor, jadi hari baharu = ruang baharu."""
    assert semak_siri.kesan(KAUNTER_SELEPAS_WIPE, PRODUCTION, "260819") == []


def test_notis_dan_kompaun_dinilai_berasingan():
    """Kaunter notis pada 1 dengan PGP02N260818001 sedia ada ialah
    pertembungan walaupun kaunter kompaun selamat."""
    b = semak_siri.kesan({"local_ekpn_notis_amaran": 1},
                         PRODUCTION, "260818")
    assert [n for _, n in b] == ["PGP02N260818001"]


def test_kaunter_tiada_tidak_menghasilkan_calon():
    """Jadual yang tidak wujud pada build tertentu dilangkau, bukan
    diandaikan sifar."""
    assert semak_siri.calon_seterusnya({}, "260819") == []


def test_nombor_diketahui_menggabungkan_log_dan_db():
    """DB dipadam oleh pemasangan bersih; log tidak merangkumi rekod
    sebelum 2026-08-17. Kedua-duanya perlu."""
    src = inspect.getsource(semak_siri.nombor_diketahui)
    assert "rekod_log.baca_semua" in src
    assert "JADUAL_NOMBOR" in src


def test_gerbang_membangkitkan_pada_pertembungan():
    src = inspect.getsource(semak_siri.gerbang)
    assert "raise RuntimeError" in src
    assert "DIHENTIKAN sebelum apa-apa" in src


def test_tulisan_terhad_kepada_majukan_dan_kaunter_sahaja():
    """>>> POLISI DIKEMASKINI 2026-08-20 — keputusan pemilik (MCQ,
    run 10). <<< Versi lama modul ini baca-sahaja sepenuhnya. Pemilik
    kemudiannya meluluskan pembetulan kaunter automatik (workflow rasmi
    = pm clear sebelum SETIAP run, jadi pertembungan hari-sama menjadi
    kepastian). Kontrak BARU yang dikunci di sini:
      (a) satu-satunya SQL tulis ialah UPDATE ke local_system_control,
          dan ia tinggal di dalam majukan() sahaja;
      (b) INSERT/DELETE/DROP kekal DILARANG sepenuhnya;
      (c) majukan() MENGESAHKAN nilai dari bacaan semula, bukan
          mempercayai push;
      (d) fungsi semakan (lapor/kesan/baca_kaunter) kekal bersih
          daripada sebarang SQL tulis."""
    src = inspect.getsource(semak_siri)
    for larangan in ("INSERT ", "DELETE ", "DROP "):
        assert larangan not in src.upper()
    # UPDATE hanya wujud dalam majukan() (dan sebutan docstring):
    kod_majukan = inspect.getsource(semak_siri.majukan)
    assert "UPDATE local_system_control SET newserial" in kod_majukan
    for fn in (semak_siri.lapor, semak_siri.kesan, semak_siri.gerbang,
               semak_siri.baca_kaunter, semak_siri.nombor_diketahui,
               semak_siri.kira_sasaran_kaunter):
        assert "UPDATE" not in inspect.getsource(fn).upper().replace(
            "MAJUKAN(", "")
    # (c) bukti bacaan semula:
    assert "TIDAK melekat" in kod_majukan
    assert "tarik_db" in kod_majukan


def test_kira_sasaran_kaunter():
    """Logik teras majukan(): sasaran = seq_maks_hari_ini + 1, hanya
    untuk kaunter yang ketinggalan; P dan K berkongsi satu kaunter."""
    kaunter = {"local_ekpn_notis_amaran": 1,
               "local_ekpn_tawaran_kompaun": 1}
    s = semak_siri.kira_sasaran_kaunter(
        kaunter, {"PGP02N260820001", "PGP02P260819003"}, "260820")
    assert s == {"local_ekpn_notis_amaran": 2}
    s2 = semak_siri.kira_sasaran_kaunter(
        kaunter, {"PGP02K260820007", "PGP02P260820003"}, "260820")
    assert s2 == {"local_ekpn_tawaran_kompaun": 8}
    assert semak_siri.kira_sasaran_kaunter(
        {"local_ekpn_notis_amaran": 9}, {"PGP02N260820001"}, "260820") == {}


def test_had_dinyatakan_dalam_docstring():
    """Rekod dari peranti LAIN tidak kelihatan. 'Tiada pertembungan'
    bermakna 'tiada dengan apa yang kita tahu' — kalau had itu tidak
    ditulis, gerbang ini akan dibaca sebagai jaminan keunikan."""
    d = semak_siri.__doc__
    assert "pengguna LAIN" in d or "peranti" in d
    assert "bukan" in d.lower()


# --- pemasangan dalam orkestrator ---

def test_gerbang_berjalan_sebelum_app_dilancarkan():
    """Kalau ia berjalan selepas `peringkat_2()`, app sudah dibuka dan
    borang boleh membakar nombor siri (D-07) sebelum semakan."""
    src = inspect.getsource(run_penuh.main)
    kod = chr(10).join(l.split("#", 1)[0] for l in src.splitlines())
    assert kod.index("semak_siri.gerbang(serial, baiki=True)") < kod.index("peringkat_2()")


def test_gerbang_menghentikan_larian():
    src = inspect.getsource(run_penuh.main)
    i = src.index("semak_siri.gerbang(serial, baiki=True)")
    assert "return 2" in src[i:i + 900]


def test_jadual_masa_dicetak_walaupun_gerbang_menghentikan():
    """Larian yang berhenti awal masih perlu meninggalkan rekod."""
    src = inspect.getsource(run_penuh.main)
    i = src.index("semak_siri.gerbang(serial, baiki=True)")
    assert "jejak.papar()" in src[i:i + 900]

"""
Gerbang untuk komponen Fasa C: pengesahan manusia, printer, post-check.

TIADA peranti. TIADA Appium. TIADA cetakan sebenar.
"""

import io
import os
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from guard import sahkan_manual                               # noqa: E402
from guard.gerbang_serah import SerahTidakDiizinkan           # noqa: E402
from pages import printer_tsc                                 # noqa: E402
from devtools.fasa_c import (PostCheckGagal,                  # noqa: E402
                             semak_satu_rekod)

SET = "SET-KK01-AKT2-111"
RINGKASAN = {"set_id": SET, "denda": "1000"}


# ===========================================================================
# SAHKAN-PER-SERAH — tidak boleh auto-lepas
# ===========================================================================
class _Stdin:
    """stdin tiruan dengan kawalan isatty — itu perbezaan yang penting."""

    def __init__(self, teks="", tty=True):
        self._buf = io.StringIO(teks)
        self._tty = tty

    def isatty(self):
        return self._tty

    def readline(self):
        return self._buf.readline()


def test_bukan_tty_ditolak():
    """LARIAN TANPA PENGAWASAN. nohup / cron / output diarah-semula:
    tiada manusia di hujungnya. Ketiadaan bantahan BUKAN persetujuan."""
    with pytest.raises(SerahTidakDiizinkan, match="bukan terminal"):
        sahkan_manual.sahkan(SET, RINGKASAN,
                             stdin=_Stdin("SAYA SAHKAN SERAH " + SET,
                                          tty=False))


def test_eof_ditolak():
    with pytest.raises(SerahTidakDiizinkan, match="EOF"):
        sahkan_manual.sahkan(SET, RINGKASAN, stdin=_Stdin("", tty=True))


@pytest.mark.parametrize("jawapan", [
    "\n", "y\n", "ya\n", "YA\n", "ok\n", "SAHKAN\n", "teruskan\n",
    "SAYA SAHKAN SERAH\n", "SAYA SAHKAN SERAH SET-LAIN\n",
    "saya sahkan serah " + SET + "\n",
])
def test_jawapan_hampir_betul_ditolak(jawapan):
    """Frasa mesti TEPAT dan mesti menyebut set. 'ya' yang ditaip untuk
    satu rekod tidak boleh meluluskan rekod yang berbeza."""
    with pytest.raises(SerahTidakDiizinkan):
        sahkan_manual.sahkan(SET, RINGKASAN, stdin=_Stdin(jawapan, tty=True))


def test_frasa_tepat_diterima():
    """Gerbang yang tidak boleh dibuka langsung juga tidak berguna."""
    ok = sahkan_manual.sahkan(
        SET, RINGKASAN,
        stdin=_Stdin(f"SAYA SAHKAN SERAH {SET}\n", tty=True))
    assert ok is True


def test_frasa_khusus_kepada_set():
    assert SET in sahkan_manual.frasa_dijangka(SET)
    assert sahkan_manual.frasa_dijangka("A") != \
        sahkan_manual.frasa_dijangka("B")


def test_sahkan_tidak_pernah_pulangkan_false():
    """Laluan penolakan ialah pengecualian, bukan nilai pulangan —
    supaya pemanggil yang terlupa memeriksa tetap selamat."""
    try:
        sahkan_manual.sahkan(SET, RINGKASAN, stdin=_Stdin("tidak\n"))
        assert False, "sepatutnya membangkitkan"
    except SerahTidakDiizinkan:
        pass


# ===========================================================================
# PRINTER — payload sahaja
# ===========================================================================
REKOD = {
    "pbt": "MBPG", "no_rekod": "PGP03K260812001", "tarikh": "12/08/2026",
    "kod_kompaun": "KOMPAUN PELBAGAI JP",
    "akta": "AKTA KERAJAAN TEMPATAN 1976",
    "kesalahan": "MELETAKKAN ATAU MENYEBABKAN SUPAYA DILETAKKAN " * 6,
    "denda": "1000", "nama_pesalah": "AUTOTEST", "no_kp": "000000000000",
    "lokasi": "DEPAN KEDAI",
}


def test_hantar_sentiasa_membangkitkan():
    """Tiada laluan penghantaran. Ini ujian paling penting dalam
    bahagian printer."""
    with pytest.raises(printer_tsc.PayloadTerkunci):
        printer_tsc.hantar(printer_tsc.bina_payload(REKOD))


def test_payload_terkunci_ialah_BaseException():
    assert issubclass(printer_tsc.PayloadTerkunci, BaseException)
    assert not issubclass(printer_tsc.PayloadTerkunci, Exception)


def test_hantar_tidak_ditelan_oleh_except_exception():
    ditelan = False
    try:
        try:
            printer_tsc.hantar(["x"])
        except Exception:                                     # noqa: BLE001
            ditelan = True
    except printer_tsc.PayloadTerkunci:
        pass
    assert not ditelan


def test_sahkan_terkunci_lulus():
    assert printer_tsc.sahkan_terkunci() is True


def test_payload_dibina_tanpa_io():
    baris = printer_tsc.bina_payload(REKOD)
    assert baris and all(isinstance(b, str) for b in baris)
    teks = printer_tsc.payload_teks(REKOD)
    assert "PGP03K260812001" in teks
    assert "1000" in teks
    assert "MBPG" in teks


def test_payload_memenggal_teks_panjang():
    """Keterangan kesalahan boleh mencecah 434 aksara (kod 111 dalam DB
    production). Tanpa pemenggalan, resit kehilangan maklumat."""
    for b in printer_tsc.bina_payload(REKOD):
        assert len(b) <= printer_tsc.LEBAR, repr(b)


def test_medan_hilang_jadi_sengkang_bukan_kosong():
    """Medan kosong pada resit kompaun mesti kelihatan sebagai tiada
    diisi, bukan hilang senyap."""
    teks = printer_tsc.payload_teks({"pbt": "MBPG"})
    assert "-" in teks


# ===========================================================================
# POST-CHECK — TEPAT satu rekod
# ===========================================================================
JADUAL = "local_ekpn_tawaran_kompaun"
ASAS = {"local_ekpn_notis_amaran": 0, JADUAL: 0, "local_ekpn_sita": 0}


def _selepas(**delta):
    d = dict(ASAS)
    for k, v in delta.items():
        d[k] = d.get(k, 0) + v
    return d


def test_tepat_satu_rekod_lulus():
    assert semak_satu_rekod(ASAS, _selepas(**{JADUAL: 1}), JADUAL) is True


def test_sifar_rekod_gagal_dengan_amaran_jangan_ulang():
    """0 baharu bermakna serah tidak menjadi. Mengulang secara buta
    boleh mencipta dua."""
    with pytest.raises(PostCheckGagal, match="JANGAN ulang"):
        semak_satu_rekod(ASAS, _selepas(**{JADUAL: 0}), JADUAL)


def test_dua_rekod_gagal_sebagai_paling_teruk():
    """>1 bermakna rekod tambahan wujud pada production dan seseorang
    perlu melupuskannya."""
    with pytest.raises(PostCheckGagal, match="dilupuskan"):
        semak_satu_rekod(ASAS, _selepas(**{JADUAL: 2}), JADUAL)


def test_jadual_lain_berubah_gagal():
    """Kalau sesuatu selain yang dijangka tersentuh, itu bukan serah
    yang kami fikir kami buat."""
    with pytest.raises(PostCheckGagal, match="TIDAK DIJANGKA"):
        semak_satu_rekod(ASAS, _selepas(**{JADUAL: 1,
                                           "local_ekpn_sita": 1}), JADUAL)


def test_rekod_hilang_dikesan():
    """Kiraan yang TURUN juga salah — ia bermakna sesuatu memadam."""
    with pytest.raises(PostCheckGagal):
        semak_satu_rekod(_selepas(**{JADUAL: 5}), ASAS, JADUAL)


def test_postcheck_gagal_ialah_BaseException():
    assert issubclass(PostCheckGagal, BaseException)
    assert not issubclass(PostCheckGagal, Exception)


# ===========================================================================
# LEDGER
# ===========================================================================
def test_ledger_setiap_entri_boleh_dibaca():
    """>>> DITULIS SEMULA 2026-08-13. <<<
    Versi lama menegaskan ledger MESTI KOSONG, kerana Fasa C berkunci
    dan sebarang entri bermakna sesuatu telah menyerah tanpa kebenaran.

    Pemilik kemudian meluluskan Fasa C dan rekod SEBENAR pertama
    dicipta (PGP02N260813006). Invarian itu kini sah tidak lagi benar,
    dan menegakkannya hanya akan memaksa sesiapa yang menjalankan ujian
    untuk MEMADAM jejak audit supaya suite bertukar hijau — tepat
    kebalikan tujuan ledger.

    Apa yang MASIH penting: setiap entri boleh dibaca dan membawa cukup
    maklumat untuk mengesan rekod. Ledger rosak tidak berguna sebagai
    jejak audit.
    """
    import json
    from devtools.fasa_c import LEDGER
    if not os.path.exists(LEDGER):
        return
    baris = [b for b in io.open(LEDGER, encoding="utf-8").read().split("\n")
             if b.strip()]
    for i, b in enumerate(baris, 1):
        entri = json.loads(b)          # rosak -> ujian gagal di sini
        assert "peristiwa" in entri, f"baris {i} tiada 'peristiwa': {entri}"

"""
Gerbang untuk RUNNER PERINGKAT MENU (tools/run_e2e_menu.py).

Tiga peringkat pertama TIDAK boleh mencipta rekod. Kalau salah satu
mula mencipta, runner mesti berhenti — bukan meneruskan dan melaporkan
"lulus". Ujian di sini menjaga pembahagian itu, dan menjaga bahawa NK
(yang MEMANG mencipta) tidak boleh berjalan tanpa kuotanya sendiri.

TIADA peranti. TIADA Appium.
"""

import datetime
import json
import os
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from tools.izin_e2e import IzinE2E, IzinTidakSah, NAMA_FAIL    # noqa: E402
from tools.run_e2e_menu import (MENCIPTA, PERINGKAT,           # noqa: E402
                                nombor_rekod_kita, peringkat_nk,
                                urai_peringkat)


# ===========================================================================
# ARGUMEN
# ===========================================================================
def test_urai_peringkat_satu():
    assert urai_peringkat("senarai") == ["senarai"]


def test_urai_peringkat_banyak():
    assert urai_peringkat("senarai,hantar,tarik") == [
        "senarai", "hantar", "tarik"]


def test_urai_peringkat_semua():
    assert urai_peringkat("semua") == list(PERINGKAT)


def test_urai_peringkat_pendua_dibuang():
    assert urai_peringkat("senarai,senarai") == ["senarai"]


def test_urai_peringkat_tidak_sah():
    with pytest.raises(SystemExit):
        urai_peringkat("senarai,karut")


# ===========================================================================
# PEMBAHAGIAN BACA / CIPTA
# ===========================================================================
def test_hanya_nk_yang_mencipta():
    """senarai dan tarik baca-sahaja; hantar menghantar semula data yang
    gagal naik tetapi tidak mencipta rekod baharu. Kalau senarai
    tiba-tiba disenaraikan sebagai pencipta, post-check akan berhenti
    mengadu tentang perubahan yang sepatutnya mustahil."""
    assert MENCIPTA == {"nk"}
    for baca in ("senarai", "hantar", "tarik"):
        assert baca not in MENCIPTA


# ===========================================================================
# NK — kuota berasingan, dan belum diport
# ===========================================================================
def _izin(tmp_path, **kuota):
    baris = [f"tarikh_luput={datetime.date.today().isoformat()}"]
    for k, v in kuota.items():
        baris.append(f"kuota_{k}={v}")
    (tmp_path / NAMA_FAIL).write_text("\n".join(baris) + "\n",
                                      encoding="utf-8")
    return IzinE2E.baca(str(tmp_path))


def test_nk_tanpa_kuota_dilangkau_dengan_arahan(tmp_path):
    izin = _izin(tmp_path, N=1, P=1, K=1)
    with pytest.raises(IzinTidakSah) as ei:
        peringkat_nk({"izin": izin})
    assert "kuota_NK=1" in str(ei.value), (
        "mesej mesti beritahu pemilik baris TEPAT untuk ditambah")


def test_nk_tanpa_notis_langsung_dilangkau(tmp_path):
    """Kuota ADA tidak bermakna ada notis untuk ditukar. Tanpa satu pun
    notis, peringkat dilangkau — bukan gagal dengan locator error."""
    izin = _izin(tmp_path, NK=1)
    with pytest.raises(IzinTidakSah) as ei:
        peringkat_nk({"izin": izin})
    pesan = str(ei.value)
    assert "TAMAT TEMPOH" in pesan
    assert "tiada dalam DB" in pesan


def test_nk_tidak_menggunakan_kuota_bila_belum_diport(tmp_path):
    """Peringkat yang membangkit SEBELUM mencipta apa-apa tidak boleh
    menghanguskan kuota pemilik."""
    izin = _izin(tmp_path, NK=1)
    with pytest.raises(IzinTidakSah):
        peringkat_nk({"izin": izin})
    assert IzinE2E.baca(str(tmp_path)).kuota["NK"] == 1


# ===========================================================================
# NOMBOR REKOD dibaca dari JEJAK AUDIT
# ===========================================================================
def test_nombor_rekod_dari_kedua_dua_jejak(tmp_path, monkeypatch):
    import tools.run_e2e_menu as M
    led = tmp_path / "LEDGER-E2E.jsonl"
    e2e = tmp_path / "E2E.jsonl"
    led.write_text(json.dumps({"peristiwa": "rekod-dicipta",
                               "no_rekod": "PGP02N260813007"}) + "\n",
                   encoding="utf-8")
    e2e.write_text(json.dumps({"no_rekod": "PGP02P260813001"}) + "\n",
                   encoding="utf-8")
    monkeypatch.setattr(M, "AKAR", str(tmp_path))
    monkeypatch.setattr(M, "E2E_JSONL", str(e2e))
    monkeypatch.setattr(M.os.path, "join",
                        lambda *a: str(led) if a[-1].endswith(
                            "LEDGER-E2E.jsonl") else os.sep.join(a))
    nombor = M.nombor_rekod_kita()
    assert "PGP02N260813007" in nombor
    assert "PGP02P260813001" in nombor


def test_nombor_rekod_tiada_jejak_pulangkan_kosong(tmp_path, monkeypatch):
    import tools.run_e2e_menu as M
    monkeypatch.setattr(M, "AKAR", str(tmp_path))
    monkeypatch.setattr(M, "E2E_JSONL", str(tmp_path / "tiada.jsonl"))
    assert nombor_rekod_kita() == []


def test_nombor_rekod_abai_baris_rosak(tmp_path, monkeypatch):
    import tools.run_e2e_menu as M
    e2e = tmp_path / "E2E.jsonl"
    e2e.write_text('{"no_rekod":"PGP02K260813002"}\n{"no_rek\n',
                   encoding="utf-8")
    monkeypatch.setattr(M, "AKAR", str(tmp_path))
    monkeypatch.setattr(M, "E2E_JSONL", str(e2e))
    assert M.nombor_rekod_kita() == ["PGP02K260813002"]


# ===========================================================================
# NK — notis mesti TAMAT TEMPOH dahulu
# ===========================================================================
def test_notis_belum_luput_tidak_layak():
    """Dialog tarik bertajuk 'TARIK NOTIS TAMAT TEMPOH'. Notis yang
    dicipta hari ini TIDAK layak, dan tarikan memulangkan sifar."""
    from tools.run_e2e_menu import notis_layak_nk
    layak, belum = notis_layak_nk(
        [("PGP02N260813007", "2026-08-13", 14)], hari_ini="2026-08-13")
    assert layak == []
    assert belum and belum[0][0] == "PGP02N260813007"
    assert belum[0][1] == "2026-08-27", "tarikh layak dikira salah"


def test_notis_sudah_luput_layak():
    from tools.run_e2e_menu import notis_layak_nk
    layak, belum = notis_layak_nk(
        [("PGP02N260813007", "2026-08-13", 14)], hari_ini="2026-08-27")
    assert layak == ["PGP02N260813007"] and belum == []


def test_tempoh_rosak_dianggap_belum_layak():
    """Tempoh yang tidak boleh dihurai TIDAK boleh dikira layak —
    menganggapnya layak bermakna menukar notis yang masih hidup."""
    from tools.run_e2e_menu import notis_layak_nk
    for buruk in (None, "", "dua minggu"):
        layak, belum = notis_layak_nk(
            [("PGP02N260813007", "2026-08-13", buruk)],
            hari_ini="2026-12-31")
        assert layak == [], buruk


def test_nk_dilangkau_bila_tiada_notis_luput(tmp_path):
    """Kuota ADA, tetapi app sendiri menyekat: tiada notis luput."""
    izin = _izin(tmp_path, NK=1)
    with pytest.raises(IzinTidakSah) as ei:
        peringkat_nk({"izin": izin,
                      "notis_dari_db": lambda: [
                          ("PGP02N260813007", "2026-08-13", 14)]})
    pesan = str(ei.value)
    assert "TAMAT TEMPOH" in pesan
    assert "2026-08-27" in pesan, "mesti beritahu bila ia layak"
    assert "sekatan APP" in pesan


def test_nk_dengan_notis_luput_masih_mengaku_belum_diport(tmp_path):
    """Notis layak + kuota ada TIDAK bermakna laluan wujud. Borang di
    sebalik [KOMPAUN] belum pernah dilihat."""
    izin = _izin(tmp_path, NK=1)
    with pytest.raises(IzinTidakSah) as ei:
        peringkat_nk({"izin": izin,
                      "notis_dari_db": lambda: [
                          ("PGP02N250101001", "2025-01-01", 14)]})
    pesan = str(ei.value)
    assert "LAYAK" in pesan and "belum pernah dilihat" in pesan
    assert "membakar nombor siri" in pesan


def test_nk_tidak_guna_kuota_dalam_mana_mana_kes(tmp_path):
    izin = _izin(tmp_path, NK=1)
    for baris in ([("A", "2026-08-13", 14)], [("A", "2025-01-01", 14)]):
        with pytest.raises(IzinTidakSah):
            peringkat_nk({"izin": izin, "notis_dari_db": lambda b=baris: b})
    assert IzinE2E.baca(str(tmp_path)).kuota["NK"] == 1

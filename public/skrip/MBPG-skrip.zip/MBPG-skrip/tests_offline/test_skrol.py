"""
Ujian laluan skrol — tanpa peranti.

Pengukuran skrol dahulunya melalui `adb shell uiautomator dump`, yang
TIDAK BOLEH berjalan semasa pelayan UiAutomator2 Appium memegang device
(Android membenarkan satu instans sahaja). Setiap skrol oleh itu
melaporkan "TIDAK DAPAT DISAHKAN", dan elemen di bawah lipatan
dilaporkan tidak wujud — itu yang menyekat dropdown Kompaun N-001 pada
2026-08-10.

Sekarang ia mengukur melalui `driver.page_source`.
"""

import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from pages.base_page import BasePage                          # noqa: E402


def skrin(*label_y, sertakan_sasaran=False):
    """XML dengan label pada kedudukan y yang diberi."""
    n = "".join(
        f'<node text="{t}" bounds="[0,{y}][1080,{y + 60}]"/>'
        for t, y in label_y)
    if sertakan_sasaran:
        n += ('<node text="KETERANGAN KOD KOMPAUN" '
              'bounds="[107,900][677,960]"/>')
    return f"<hierarchy><node>{n}</node></hierarchy>"


class DriverSkrol:
    """Driver palsu: setiap swipe menganjakkan setiap label ke ATAS
    sebanyak `anjakan` piksel."""

    def __init__(self, anjakan=400, gagal_source=False, label=None):
        self.anjakan = anjakan
        self.gagal_source = gagal_source
        self.swipes = []
        self.offset = 0
        self.label = label or [("Maklumat Jalan", 1000),
                               ("Lokasi Kesalahan", 1400),
                               ("Butiran Kesalahan", 1800),
                               ("KETERANGAN KOD KOMPAUN", 2283)]

    @property
    def page_source(self):
        if self.gagal_source:
            raise RuntimeError("page_source tidak tersedia")
        return skrin(*[(t, y - self.offset) for t, y in self.label])

    def swipe(self, x1, y1, x2, y2, duration=0):
        self.swipes.append((x1, y1, x2, y2))
        self.offset += self.anjakan


def _page(drv):
    p = BasePage.__new__(BasePage)
    p.driver = drv
    return p


# ---------------------------------------------------------------------------

def test_pergerakan_dikesan():
    drv = DriverSkrol(anjakan=400)
    hasil = _page(drv)._ukur_skrol_melalui_driver((540, 1400, 540, 600, 600),
                                                  settle=0)
    assert hasil["ok"]
    assert hasil["status"] == "BERGERAK"
    assert hasil["anjakan_max_px"] == 400
    assert hasil["dikongsi"] == 4
    assert drv.swipes == [(540, 1400, 540, 600)]


def test_tiada_pergerakan_dikesan():
    """Borang yang benar-benar tidak menatal mesti dilaporkan
    TIDAK_BERGERAK — bukan dikelirukan dengan gagal-ukur."""
    drv = DriverSkrol(anjakan=0)
    hasil = _page(drv)._ukur_skrol_melalui_driver((540, 1400, 540, 600, 600),
                                                  settle=0)
    assert hasil["ok"]
    assert hasil["status"] == "TIDAK_BERGERAK"
    assert hasil["anjakan_max_px"] == 0


def test_anjakan_bawah_ambang_bukan_pergerakan():
    """Getaran kecil (<50px) bukan penatalan."""
    drv = DriverSkrol(anjakan=10)
    hasil = _page(drv)._ukur_skrol_melalui_driver((540, 1400, 540, 600, 600),
                                                  settle=0)
    assert hasil["status"] == "TIDAK_BERGERAK"


def test_gagal_baca_bukan_tidak_bergerak():
    """Kalau page_source gagal, jawapannya TIDAK PASTI (ok=False) — dan
    pemanggil melayan itu sebagai 'teruskan mencuba', bukan 'borang
    tidak bergerak'. Perbezaan ini yang membunuh tiga run K1 MBJB."""
    drv = DriverSkrol(gagal_source=True)
    hasil = _page(drv)._ukur_skrol_melalui_driver((540, 1400, 540, 600, 600),
                                                  settle=0)
    assert hasil["ok"] is False
    assert "page_source" in hasil["sebab"]


def test_swipe_tetap_dilakukan_walaupun_bacaan_selepas_gagal():
    """Swipe berlaku SEBELUM bacaan kedua. Kalau bacaan itu gagal, swipe
    tetap sudah berlaku — jadi pemanggil tidak boleh menyimpulkan
    'tiada apa berlaku'."""
    class Separa(DriverSkrol):
        def __init__(self):
            super().__init__()
            self.kali = 0

        @property
        def page_source(self):
            self.kali += 1
            if self.kali > 1:
                raise RuntimeError("hilang selepas swipe")
            return skrin(("A", 100))

    drv = Separa()
    hasil = _page(drv)._ukur_skrol_melalui_driver((540, 1400, 540, 600, 600),
                                                  settle=0)
    assert hasil["ok"] is False
    assert len(drv.swipes) == 1, "swipe mesti tetap dilakukan"


def test_label_berulang_digugurkan():
    """Label yang muncul >1 kali tidak boleh dipadankan merentas bacaan —
    ia akan mereka-reka anjakan antara dua elemen berlainan."""
    xml = ('<hierarchy><node>'
           '<node text="BARIS" bounds="[0,100][100,160]"/>'
           '<node text="BARIS" bounds="[0,300][100,360]"/>'
           '<node text="UNIK" bounds="[0,500][100,560]"/>'
           '</node></hierarchy>')
    peta = BasePage._peta_label_y_dari_xml(xml)
    assert "UNIK" in peta
    assert "BARIS" not in peta


def test_xml_rosak_pulang_peta_kosong():
    assert BasePage._peta_label_y_dari_xml("<hierarchy><node") == {}
    assert BasePage._peta_label_y_dari_xml("") == {}


def test_sasaran_bawah_lipatan_muncul_selepas_skrol():
    """SENARIO N-001. 'KETERANGAN KOD KOMPAUN' bermula pada y=2283 pada
    skrin 2400 — di bawah lipatan. Selepas dua skrol ia mesti naik ke
    dalam viewport."""
    drv = DriverSkrol(anjakan=700)
    p = _page(drv)
    y_awal = BasePage._peta_label_y_dari_xml(
        drv.page_source)["KETERANGAN KOD KOMPAUN"]
    assert y_awal > 2000, "sasaran sepatutnya bermula di bawah lipatan"
    for _ in range(2):
        p._ukur_skrol_melalui_driver((540, 1400, 540, 600, 600), settle=0)
    y_akhir = BasePage._peta_label_y_dari_xml(
        drv.page_source)["KETERANGAN KOD KOMPAUN"]
    assert y_akhir < 1500, f"sasaran masih di bawah lipatan (y={y_akhir})"


def test_tiada_panggilan_measure_scroll_dalam_laluan_skrol():
    """REGRESI. Pengukuran tidak boleh kembali kepada adb: ia mustahil
    di bawah Appium.

    Disemak pada KOD, bukan teks. Docstring kedua-dua kaedah menerangkan
    panjang lebar kenapa laluan adb dibuang — imbasan teks mentah akan
    memadan penjelasan itu dan menimbulkan penggera atas dokumentasi.
    Kesilapan yang sama sudah ditemui sekali dalam suite ini
    (test_guard_corong._literal_kod)."""
    import ast
    laluan = os.path.join(os.path.dirname(__file__), "..", "pages",
                          "base_page.py")
    with open(laluan, encoding="utf-8") as fh:
        pokok = ast.parse(fh.read(), filename=laluan)

    sasaran = {"_ukur_skrol_melalui_driver", "scroll_in_viewport"}
    dijumpai = set()
    for n in ast.walk(pokok):
        if isinstance(n, ast.FunctionDef) and n.name in sasaran:
            dijumpai.add(n.name)
            for c in ast.walk(n):
                if isinstance(c, ast.Call):
                    nama = (getattr(c.func, "attr", None)
                            or getattr(c.func, "id", None))
                    assert nama != "measure_scroll", (
                        f"{n.name} masih memanggil measure_scroll()")
                # import measure_scroll di dalam fungsi juga dilarang
                if isinstance(c, (ast.Import, ast.ImportFrom)):
                    for a in c.names:
                        assert a.name != "measure_scroll", (
                            f"{n.name} masih mengimport measure_scroll")
    assert dijumpai == sasaran, f"kaedah hilang: {sasaran - dijumpai}"

"""
Gerbang untuk KUNCI FASA C.

Fasa C ialah satu-satunya laluan yang boleh mencipta rekod sebenar
pada production MBPG. Ujian di sini membuktikan ia TIDAK BOLEH, dalam
keadaan repo semasa, dan bahawa setiap lapisan kunci berfungsi
sendirian — bukan hanya secara kolektif.

Kaedah: setiap ujian mengambil konfigurasi yang LULUS SEPENUHNYA,
kemudian mematahkan TEPAT SATU lapisan dan menuntut penolakan. Ujian
yang hanya menyemak "lalai disekat" akan lulus walaupun tiga daripada
empat lapisan tidak disambung.

TIADA peranti. TIADA Appium. TIADA cetakan.
"""

import io
import json
import os
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from guard.gerbang_serah import (FAIL_IZIN, Izin,             # noqa: E402
                                 PLACEHOLDER, SerahTidakDiizinkan,
                                 diagnosis, semak)


SET_OK = "SET-KK01-AKT2-111"


def izin_lulus(**ganti):
    """Konfigurasi yang melepasi keempat-empat lapisan. Setiap ujian
    memecahkan satu bahagian daripadanya."""
    import datetime
    asas = dict(
        dry_run_mati=True,
        token="TOKEN-DARI-PEMILIK",
        medan={"disahkan_oleh": "Shu", "rujukan_kelulusan": "EMEL-PM-123"},
        whitelist=(SET_OK,),
        had=1,
        # Lapisan 5 dan 6 ditambah 2026-08-12. Konfigurasi "lulus
        # sepenuhnya" mesti kini merangkumi kedua-duanya, kalau tidak
        # setiap ujian negatif di bawah akan lulus atas sebab yang
        # SALAH -- disekat oleh lapisan yang tidak diisi, bukan oleh
        # lapisan yang ujian itu sengaja pecahkan.
        sah_sehingga=datetime.date.today().isoformat(),
        borang=("N", "P", "K"),
        kuota={"N": 1, "P": 1, "K": 1},
    )
    asas.update(ganti)
    return Izin(**asas)


# ===========================================================================
# Asas: konfigurasi lengkap MEMANG lulus (kalau tidak, ujian negatif
# di bawah tidak bermakna apa-apa)
# ===========================================================================
def test_konfigurasi_lengkap_lulus():
    assert semak(izin_lulus(), SET_OK, 0) is True


# ===========================================================================
# LAPISAN 1 — MBPG_DRY_RUN
# ===========================================================================
def test_lapisan1_dry_run_masih_hidup_menyekat():
    with pytest.raises(SerahTidakDiizinkan, match="LAPISAN 1"):
        semak(izin_lulus(dry_run_mati=False), SET_OK, 0)


@pytest.mark.parametrize("nilai", ["1", "", "true", "0 ", "00", "yes"])
def test_lapisan1_hanya_sifar_tepat_membuka(nilai):
    """'0' TEPAT sahaja. '0 ' dengan ruang, '00', 'false' — semua
    kekal menyekat. Nilai yang hampir-betul ialah cara kunci terbuka
    secara tidak sengaja."""
    izin = Izin.dari_persekitaran(env={"MBPG_DRY_RUN": nilai})
    assert izin.dry_run_mati is False


def test_lapisan1_sifar_tepat_mematikan_dry_run():
    izin = Izin.dari_persekitaran(env={"MBPG_DRY_RUN": "0"})
    assert izin.dry_run_mati is True


# ===========================================================================
# LAPISAN 2 — token + medan ISI-SINI
# ===========================================================================
def test_lapisan2_token_kosong_menyekat():
    with pytest.raises(SerahTidakDiizinkan, match="LAPISAN 2"):
        semak(izin_lulus(token=""), SET_OK, 0)


def test_lapisan2_token_ruang_sahaja_menyekat():
    with pytest.raises(SerahTidakDiizinkan, match="LAPISAN 2"):
        semak(izin_lulus(token="   "), SET_OK, 0)


@pytest.mark.parametrize("medan", [
    {"disahkan_oleh": PLACEHOLDER, "rujukan_kelulusan": "EMEL-1"},
    {"disahkan_oleh": "Shu", "rujukan_kelulusan": PLACEHOLDER},
    {"disahkan_oleh": "", "rujukan_kelulusan": "EMEL-1"},
    {"disahkan_oleh": "Shu", "rujukan_kelulusan": ""},
    {"disahkan_oleh": "isi-sini", "rujukan_kelulusan": "EMEL-1"},
    {},
])
def test_lapisan2_medan_belum_diisi_menyekat(medan):
    """Pemegang tempat yang tidak disentuh ialah tanda paling jelas
    bahawa tiada manusia membacanya — termasuk huruf kecil."""
    with pytest.raises(SerahTidakDiizinkan, match="LAPISAN 2"):
        semak(izin_lulus(medan=medan), SET_OK, 0)


def test_lapisan2_placeholder_terbenam_masih_menyekat():
    """'diluluskan ISI-SINI kemudian' bukan medan yang diisi."""
    with pytest.raises(SerahTidakDiizinkan, match="LAPISAN 2"):
        semak(izin_lulus(medan={"disahkan_oleh": "Shu",
                                "rujukan_kelulusan": f"rujuk {PLACEHOLDER}"}),
              SET_OK, 0)


# ===========================================================================
# LAPISAN 3 — whitelist
# ===========================================================================
def test_lapisan3_whitelist_kosong_menyekat():
    with pytest.raises(SerahTidakDiizinkan, match="LAPISAN 3"):
        semak(izin_lulus(whitelist=()), SET_OK, 0)


def test_lapisan3_set_luar_whitelist_menyekat():
    with pytest.raises(SerahTidakDiizinkan, match="LAPISAN 3"):
        semak(izin_lulus(whitelist=("SET-LAIN",)), SET_OK, 0)


def test_lapisan3_padanan_mesti_TEPAT():
    """Awalan/subrentetan tidak melayakkan. Set yang MBPG namakan,
    bukan set yang kelihatan serupa."""
    for hampir in ("SET-KK01-AKT2-11", "SET-KK01-AKT2-1110",
                   "set-kk01-akt2-111"):
        with pytest.raises(SerahTidakDiizinkan, match="LAPISAN 3"):
            semak(izin_lulus(whitelist=(hampir,)), SET_OK, 0)


# ===========================================================================
# LAPISAN 4 — had N
# ===========================================================================
def test_lapisan4_had_sifar_menyekat():
    with pytest.raises(SerahTidakDiizinkan, match="LAPISAN 4"):
        semak(izin_lulus(had=0), SET_OK, 0)


def test_lapisan4_had_negatif_menyekat():
    with pytest.raises(SerahTidakDiizinkan, match="LAPISAN 4"):
        semak(izin_lulus(had=-1), SET_OK, 0)


def test_lapisan4_had_dicapai_menyekat():
    izin = izin_lulus(had=2)
    assert semak(izin, SET_OK, 0) is True
    assert semak(izin, SET_OK, 1) is True
    with pytest.raises(SerahTidakDiizinkan, match="LAPISAN 4"):
        semak(izin, SET_OK, 2)
    with pytest.raises(SerahTidakDiizinkan, match="LAPISAN 4"):
        semak(izin, SET_OK, 99)


# ===========================================================================
# Sifat merentas lapisan
# ===========================================================================
def test_penolakan_ialah_BaseException():
    """Kalau ia Exception, 66 blok `except Exception` dalam base_page
    akan menelannya dan gelung cuba-semula akan mencuba lagi — gerbang
    menolak setiap kali sementara run meneruskan."""
    assert issubclass(SerahTidakDiizinkan, BaseException)
    assert not issubclass(SerahTidakDiizinkan, Exception)


def test_penolakan_tidak_ditelan_oleh_except_exception():
    ditelan = False
    try:
        try:
            semak(izin_lulus(had=0), SET_OK, 0)
        except Exception:                                     # noqa: BLE001
            ditelan = True
    except SerahTidakDiizinkan:
        pass
    assert not ditelan


def test_setiap_lapisan_boleh_menyekat_sendirian():
    """Empat kunci berasingan. Membuka tiga tidak membuka yang
    keempat."""
    pecah = [
        dict(dry_run_mati=False),
        dict(token=""),
        dict(whitelist=()),
        dict(had=0),
    ]
    for p in pecah:
        with pytest.raises(SerahTidakDiizinkan):
            semak(izin_lulus(**p), SET_OK, 0)


# ===========================================================================
# LALAI REPO — keadaan sebenar hari ini
# ===========================================================================
def test_lalai_repo_serah_mustahil():
    """Ujian paling penting dalam fail ini: dengan repo seperti yang
    ia berdiri, dan persekitaran kosong, serah TIDAK BOLEH berlaku."""
    akar = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    izin = Izin.dari_persekitaran(akar=akar, env={})
    assert diagnosis(izin)["serah_mungkin"] is False
    with pytest.raises(SerahTidakDiizinkan):
        semak(izin, SET_OK, 0)


def test_fail_izin_tidak_masuk_kawalan_sumber():
    """DIUBAH 2026-08-12 — dahulunya menuntut fail itu TIDAK WUJUD.

    Pemilik kini meletakkannya dengan sah untuk Fasa C, jadi
    ketiadaannya bukan lagi invarian. Yang KEKAL invarian: ia tidak
    boleh masuk kawalan sumber — sekali ia dalam sejarah, sesiapa yang
    clone repo mewarisi kebenaran mencipta rekod pada production."""
    import subprocess
    akar = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    if not os.path.exists(os.path.join(akar, FAIL_IZIN)):
        return
    r = subprocess.run(["git", "check-ignore", FAIL_IZIN],
                       cwd=akar, capture_output=True, text=True)
    assert r.returncode == 0, (
        f"{FAIL_IZIN} wujud tetapi TIDAK digitignore — kebenaran serah "
        f"akan masuk kawalan sumber")


def test_fail_izin_rosak_menyekat(tmp_path):
    """JSON rosak tidak boleh gagal-TERBUKA."""
    (tmp_path / FAIL_IZIN).write_text("{rosak", encoding="utf-8")
    izin = Izin.dari_persekitaran(akar=str(tmp_path),
                                  env={"MBPG_DRY_RUN": "0",
                                       "MBPG_IZIN_SERAH": "T"})
    with pytest.raises(SerahTidakDiizinkan):
        semak(izin, SET_OK, 0)


def test_fail_izin_lengkap_dibaca_betul(tmp_path):
    """Sisi lain: apabila pemilik BENAR-BENAR mengisinya, ia dibaca.
    Gerbang yang tidak boleh dibuka langsung juga tidak berguna."""
    (tmp_path / FAIL_IZIN).write_text(json.dumps({
        "disahkan_oleh": "Shu",
        "rujukan_kelulusan": "EMEL-PM-2026-08-12",
        "whitelist_set": [SET_OK],
        "had_serah": 1,
        "sah_sehingga": __import__("datetime").date.today().isoformat(),
        "borang_dibenarkan": ["N", "P", "K"],
        "kuota": {"N": 1, "P": 1, "K": 1},
    }), encoding="utf-8")
    izin = Izin.dari_persekitaran(akar=str(tmp_path),
                                  env={"MBPG_DRY_RUN": "0",
                                       "MBPG_IZIN_SERAH": "TOKEN"})
    assert diagnosis(izin)["serah_mungkin"] is True
    assert semak(izin, SET_OK, 0) is True
    with pytest.raises(SerahTidakDiizinkan, match="LAPISAN 3"):
        semak(izin, "SET-TIDAK-DILULUSKAN", 0)


# ===========================================================================
# LAPISAN 5 — LUPUT  (ditambah 2026-08-12, arahan pemilik)
# ===========================================================================
# Fail kebenaran yang ditulis untuk satu petang kekal sah selama-lamanya
# tanpa lapisan ini. Itu bukan hipotetikal: fail izin projek ini memang
# tertinggal hidup merentas beberapa sesi.
def _esok():
    import datetime
    return (datetime.date.today() + datetime.timedelta(days=1)).isoformat()


def _semalam():
    import datetime
    return (datetime.date.today() - datetime.timedelta(days=1)).isoformat()


def test_lapisan5_izin_luput_menyekat():
    with pytest.raises(SerahTidakDiizinkan, match="LAPISAN 5"):
        semak(izin_lulus(sah_sehingga=_semalam()), SET_OK, 0, borang="N")


def test_lapisan5_hari_ini_lulus():
    import datetime
    izin = izin_lulus(sah_sehingga=datetime.date.today().isoformat())
    assert semak(izin, SET_OK, 0, borang="N") is True


@pytest.mark.parametrize("nilai", ["", "   ", PLACEHOLDER, "ISI-SINI",
                                   "12/08/2026", "2026-13-45", "semalam"])
def test_lapisan5_tarikh_tiada_atau_rosak_menyekat(nilai):
    """Tarikh yang tidak boleh dihurai TIDAK dianggap sah. Satu salah
    taip tidak boleh membuka izin selama-lamanya."""
    with pytest.raises(SerahTidakDiizinkan, match="LAPISAN 5"):
        semak(izin_lulus(sah_sehingga=nilai), SET_OK, 0, borang="N")


def test_lapisan5_diagnosis_mendedahkan_luput():
    d = diagnosis(izin_lulus(sah_sehingga=_semalam()))
    assert d["lapisan_5_belum_luput"] is False
    assert d["serah_mungkin"] is False


# ===========================================================================
# LAPISAN 6 — BORANG + KUOTA SETIAP BORANG
# ===========================================================================
def test_lapisan6_borang_tidak_diluluskan_menyekat():
    with pytest.raises(SerahTidakDiizinkan, match="LAPISAN 6"):
        semak(izin_lulus(borang=("N",)), SET_OK, 0, borang="P")


def test_lapisan6_borang_kosong_menyekat():
    with pytest.raises(SerahTidakDiizinkan, match="LAPISAN 6"):
        semak(izin_lulus(borang=()), SET_OK, 0, borang="N")


def test_lapisan6_kuota_sifar_menyekat():
    with pytest.raises(SerahTidakDiizinkan, match="LAPISAN 6"):
        semak(izin_lulus(kuota={"N": 0, "P": 1, "K": 1}), SET_OK, 0,
              borang="N")


def test_lapisan6_kuota_habis_menyekat():
    izin = izin_lulus(kuota={"N": 1, "P": 1, "K": 1})
    assert semak(izin, SET_OK, 0, borang="N", kiraan_borang=0) is True
    with pytest.raises(SerahTidakDiizinkan, match="LAPISAN 6"):
        semak(izin, SET_OK, 0, borang="N", kiraan_borang=1)


def test_lapisan6_kuota_satu_borang_tidak_dipinjam_borang_lain():
    """Inilah sebab lapisan ini wujud: had_serah TUNGGAL membenarkan
    3 Notis dan sifar Kompaun sedangkan pemilik meminta satu setiap
    satu."""
    izin = izin_lulus(had=3, kuota={"N": 1, "P": 1, "K": 1})
    assert semak(izin, SET_OK, 0, borang="N", kiraan_borang=0) is True
    with pytest.raises(SerahTidakDiizinkan, match="LAPISAN 6"):
        semak(izin, SET_OK, 1, borang="N", kiraan_borang=1)
    # ...tetapi borang LAIN masih ada kuotanya sendiri.
    assert semak(izin, SET_OK, 1, borang="P", kiraan_borang=0) is True


def test_lapisan6_dilangkau_bila_borang_tidak_dinyatakan():
    """Pemanggil lama yang tidak menghantar `borang` tidak dipaksa
    melalui lapisan 6 -- ia tidak boleh MELONGGARKAN apa-apa kerana
    lapisan 1-5 tetap dinilai."""
    assert semak(izin_lulus(), SET_OK, 0) is True


# ===========================================================================
# Fail izin sebenar: tiada fail -> setiap lapisan gagal tertutup
# ===========================================================================
def test_tiada_fail_izin_menyekat_sepenuhnya(tmp_path):
    izin = Izin.dari_persekitaran(akar=str(tmp_path),
                                  env={"MBPG_DRY_RUN": "0",
                                       "MBPG_IZIN_SERAH": "TOKEN"})
    d = diagnosis(izin)
    assert d["serah_mungkin"] is False
    assert d["lapisan_5_belum_luput"] is False
    assert d["lapisan_6_borang"] == []
    with pytest.raises(SerahTidakDiizinkan):
        semak(izin, SET_OK, 0, borang="N")


def test_izin_luput_dalam_fail_sebenar_menyekat(tmp_path):
    (tmp_path / FAIL_IZIN).write_text(json.dumps({
        "disahkan_oleh": "Shu",
        "rujukan_kelulusan": "EMEL-PM-2026-08-12",
        "whitelist_set": [SET_OK],
        "had_serah": 3,
        "sah_sehingga": _semalam(),
        "borang_dibenarkan": ["N", "P", "K"],
        "kuota": {"N": 1, "P": 1, "K": 1},
    }), encoding="utf-8")
    izin = Izin.dari_persekitaran(akar=str(tmp_path),
                                  env={"MBPG_DRY_RUN": "0",
                                       "MBPG_IZIN_SERAH": "TOKEN"})
    assert diagnosis(izin)["serah_mungkin"] is False
    with pytest.raises(SerahTidakDiizinkan, match="LAPISAN 5"):
        semak(izin, SET_OK, 0, borang="N")

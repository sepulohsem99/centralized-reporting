"""
Gerbang untuk laluan persediaan sweep.

Pengesahan pra-sweep pada device (2026-08-11) membuktikan app
MENYEKAT laluan dropdown-terus dengan 'Maklumat Tidak Lengkap'. Laluan
sweep kini mesti mengisi tab PESALAH dahulu. Ujian di sini mengunci
sifat-sifat laluan itu supaya ia tidak reput semula kepada versi yang
gagal 284 kali.
"""

import os
import sqlite3
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from tests.sweep_kongsi import (data_pesalah_minimum,          # noqa: E402
                                isi_pesalah_minimum,
                                sedia_borang_kompaun)


# ---------------------------------------------------------------------------
# DB tiruan: cukup untuk pemilih sauh, tiada peranti terlibat.
# ---------------------------------------------------------------------------
@pytest.fixture
def db_tiruan(tmp_path):
    laluan = str(tmp_path / "sauh.db")
    c = sqlite3.connect(laluan)
    c.execute("CREATE TABLE local_ekpn_jalan "
              "(kod TEXT, kodjalan TEXT, nama TEXT, taman TEXT, poskod TEXT)")
    c.execute("CREATE TABLE local_ekpn_taman "
              "(kod TEXT, nama TEXT, bandar TEXT, poskod TEXT)")
    c.execute("CREATE TABLE local_ekpn_bandar "
              "(kod TEXT, nama TEXT, negeri TEXT)")
    c.executemany("INSERT INTO local_ekpn_jalan VALUES (?,?,?,?,?)", [
        ("1", "1", "JALAN ALAMANDA 1", "T1", "81700"),
        ("2", "2", "JALAN ALAMANDA 2", "T1", "81700"),
        # Tanpa poskod — D-03. TIDAK boleh dipilih sebagai sauh.
        ("3", "3", "JALAN GUNUNG 12", "T1", ""),
    ])
    c.execute("INSERT INTO local_ekpn_taman VALUES ('T1','TAMAN UJI','B1','')")
    c.execute("INSERT INTO local_ekpn_bandar VALUES "
              "('B1','PASIR GUDANG','JOHOR')")
    c.commit()
    c.close()
    return laluan


def test_sauh_tidak_pernah_memilih_jalan_tanpa_poskod(db_tiruan):
    """Keseluruhan sebab pemilih itu wujud. Jalan tanpa poskod ialah
    tepat keadaan yang D-03 sekat."""
    d = data_pesalah_minimum(db_tiruan)
    assert d["jalan"] == "JALAN ALAMANDA 1"
    assert d["poskod_dijangka"] == "81700"


def test_poskod_tidak_pernah_dihantar_sebagai_input(db_tiruan):
    """Poskod hanya WUJUD sebagai jangkaan. Kalau ia menyelinap masuk
    sebagai medan input, auto-isi app tidak lagi diuji dan bug
    kategori-B akan bertopeng — keputusan pemilik 2026-08-05."""
    d = data_pesalah_minimum(db_tiruan)
    assert "poskod" not in d
    for terlarang in ("taman", "bandar", "negeri"):
        assert terlarang not in d, (
            f"{terlarang} mesti datang dari auto-isi app, bukan ditaip")


def test_data_persediaan_tepat_apa_yang_diperlukan(db_tiruan):
    """Pesalah + tab KOMPAUN. Tab KOMPAUN ditambah selepas melangkaunya
    gagal DUA kali pada tingkat 3 (lihat isi_pesalah_minimum)."""
    d = data_pesalah_minimum(db_tiruan)
    assert set(d) == {
        "nama_pesalah", "no_kp_ssm_kereta", "jalan", "poskod_dijangka",
        "jalan_premis", "kompaun_jalan_partial", "kompaun_jalan_suggestion",
        "kompaun_jalan", "lokasi_kesalahan", "butiran_kesalahan",
    }


def test_satu_sauh_alamat_sahaja_merentas_laluan(db_tiruan):
    """Alamat pesalah dan alamat kesalahan mesti datang dari sauh yang
    SAMA. Dua sauh bermakna dua kelakuan auto-isi untuk dinyahpepijat
    apabila sesuatu gagal."""
    d = data_pesalah_minimum(db_tiruan)
    assert d["jalan"] == d["jalan_premis"] == d["kompaun_jalan"]
    assert d["kompaun_jalan_partial"] == "JALAN ALAMANDA"


# ---------------------------------------------------------------------------
# Laluan: mesti isi Pesalah, kemudian pindah melalui BAR TAB.
# ---------------------------------------------------------------------------
class _PageTiruan:
    TAB_KOMPAUN = ("uiautomator", "tab-kompaun")

    def __init__(self, sudah_di_borang=False):
        self.jejak = []
        self._di_borang = sudah_di_borang

    def is_daftar_kompaun_screen_displayed(self):
        return self._di_borang

    def select_jenis_kompaun(self, jenis):
        self.jejak.append(f"pilih:{jenis}")

    def select_jenis_kompaun_letak_kereta(self):
        self.jejak.append("pilih:letak_kereta")

    def fill_pesalah_tab(self, data):
        self.jejak.append(f"pesalah:{data['jalan']}")

    def fill_kompaun_tab(self, data):
        self.jejak.append(f"kompaun:{data['lokasi_kesalahan']}")

    def wait_and_tap(self, loc):
        self.jejak.append(f"tap:{loc[1]}")


class _HomeTiruan:
    def __init__(self, p):
        self.p = p

    def open_daftar_kompaun(self):
        self.p.jejak.append("buka:daftar")


class _PagesTiruan:
    def __init__(self, p):
        self.daftar_kompaun = p
        self.home = _HomeTiruan(p)


def test_persediaan_mengisi_pesalah_sebelum_tab_kompaun(db_tiruan,
                                                        monkeypatch):
    """REGRESI: app menyekat dropdown-terus dengan 'Maklumat Tidak
    Lengkap'. Persediaan MESTI mengisi Pesalah, dan MESTI berpindah
    melalui bar tab (SETERUSNYA di bawah lipatan pada borang yang
    tidak boleh di-swipe)."""
    monkeypatch.setattr("tests.sweep_kongsi.data_pesalah_minimum",
                        lambda db=None: data_pesalah_minimum(db_tiruan))
    p = _PageTiruan()
    sedia_borang_kompaun(_PagesTiruan(p), "Kompaun Pelbagai")
    assert p.jejak == ["buka:daftar", "pilih:Kompaun Pelbagai",
                       "pesalah:JALAN ALAMANDA 1", "tap:tab-kompaun",
                       "kompaun:AUTOTEST LOKASI"]


def test_persediaan_tidak_membuka_semula_borang_yang_sudah_terbuka():
    """Sweep memandu ratusan set pada borang yang SAMA; membuka semula
    setiap kali menggandakan masa peranti tanpa menambah bukti."""
    p = _PageTiruan(sudah_di_borang=True)
    sedia_borang_kompaun(_PagesTiruan(p), "Kompaun Pelbagai")
    assert p.jejak == []


def test_isi_pesalah_minimum_pulangkan_data_yang_digunakan(db_tiruan,
                                                           monkeypatch):
    monkeypatch.setattr("tests.sweep_kongsi.data_pesalah_minimum",
                        lambda db=None: data_pesalah_minimum(db_tiruan))
    p = _PageTiruan()
    d = isi_pesalah_minimum(p)
    assert d["jalan"] == "JALAN ALAMANDA 1"
    assert "tap:tab-kompaun" in p.jejak

"""Gerbang skop D-09 — rekod larian INI sahaja.

Ditulis selepas larian 2026-08-18 petang, di mana ketiga-tiga borang K
gagal sebelum mencipta apa-apa dan verdik akhir tetap mengisytiharkan

    D-09 mySIKAP : BERSIH pada build ini

Rekod yang diperiksa ialah `PGP02K260818008` daripada sesi PAGI —
dicipta oleh build lain, dalam larian lain. Penapis lama ialah "rekod K
hari ini"; ia sepatutnya "rekod K larian ini".

Ujian di sini memaksa ketiga-tiga keadaan kekal berasingan:
BERSIH / MASIH ROSAK / TIDAK DIUJI.
"""

import inspect
import os
import sys

AKAR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, AKAR)

import pytest                                               # noqa: E402

from tools import run_penuh                                 # noqa: E402


PAGI = {"no_rekod": "PGP02K260818008", "borang": "K",
        "masa": "2026-08-18 12:04:54", "tc": "K-001"}
PETANG = {"no_rekod": "PGP02K260818009", "borang": "K",
          "masa": "2026-08-18 17:20:00", "tc": "K-001"}
BUKAN_K = {"no_rekod": "PGP02P260818001", "borang": "P",
           "masa": "2026-08-18 17:08:35", "tc": "P-001"}


def _log(monkeypatch, baris):
    from tools import rekod_log
    monkeypatch.setattr(rekod_log, "baca_semua", lambda *a, **k: baris)


def test_sejak_adalah_parameter_wajib():
    """Lalai bermakna pemanggil boleh terlupa, dan terlupa di sini
    menghasilkan keyakinan palsu — bukan ralat yang kelihatan."""
    tanda = inspect.signature(run_penuh.semak_d09)
    assert tanda.parameters["sejak"].default is inspect.Parameter.empty


def test_rekod_larian_terdahulu_diabaikan(monkeypatch):
    """Kegagalan tepat pada 2026-08-18."""
    _log(monkeypatch, [PAGI])
    with pytest.raises(run_penuh.D09TidakDiuji) as ei:
        run_penuh.semak_d09("dummy", "2026-08-18 16:15:00")
    assert "0 rekod K dicipta dalam larian ini" in str(ei.value)


def test_bilangan_rekod_lama_disebut(monkeypatch):
    """Pembaca mesti tahu rekod itu WUJUD tetapi sengaja diabaikan —
    kalau tidak, mesej itu kelihatan seperti log yang rosak."""
    _log(monkeypatch, [PAGI, dict(PAGI, no_rekod="PGP02K260813002")])
    with pytest.raises(run_penuh.D09TidakDiuji) as ei:
        run_penuh.semak_d09("dummy", "2026-08-18 16:15:00")
    assert "2 rekod K lain wujud" in str(ei.value)


def test_borang_bukan_k_tidak_dikira(monkeypatch):
    _log(monkeypatch, [BUKAN_K])
    with pytest.raises(run_penuh.D09TidakDiuji):
        run_penuh.semak_d09("dummy", "2026-08-18 16:15:00")


def test_rekod_larian_semasa_diterima(monkeypatch):
    """Melepasi penapis, kemudian gagal pada tarik_db kerana tiada
    peranti — itu membuktikan penapis membenarkannya lalu."""
    _log(monkeypatch, [PAGI, PETANG])
    with pytest.raises(Exception) as ei:
        run_penuh.semak_d09("dummy", "2026-08-18 16:15:00")
    assert not isinstance(ei.value, run_penuh.D09TidakDiuji)


def test_rekod_tanpa_nombor_tidak_dikira(monkeypatch):
    """`no_rekod=None` dilog apabila nombor gagal ditangkap (D-07).
    Ia bukan rekod yang boleh diperiksa."""
    _log(monkeypatch, [dict(PETANG, no_rekod=None)])
    with pytest.raises(run_penuh.D09TidakDiuji):
        run_penuh.semak_d09("dummy", "2026-08-18 16:15:00")


def test_main_menghantar_cap_masa_permulaan():
    src = inspect.getsource(run_penuh.main)
    assert "semak_d09(serial, mula_iso)" in src


def test_cap_masa_diambil_sebelum_sebarang_peringkat():
    """Kalau ia diambil selepas borang berjalan, rekod larian sendiri
    akan jatuh di luar tingkap."""
    src = inspect.getsource(run_penuh.main)
    kod = chr(10).join(l.split("#", 1)[0] for l in src.splitlines())
    assert kod.index("mula_iso =") < kod.index("peringkat_1(serial)")


# --- verdik: tiga keadaan mesti kekal berasingan ---

def _jejak(status, nota):
    j = run_penuh.Jejak()
    j.baris.append({"peringkat": "semak D-09", "status": status,
                    "nota": nota, "tempoh_s": 0.1, "masa": "17:30:00"})
    return j


def test_verdik_tidak_diuji_bukan_rosak(capsys):
    j = _jejak("GAGAL", "D09TidakDiuji: D-09 TIDAK DIUJI - 0 rekod K")
    j.papar_verdik()
    keluar = capsys.readouterr().out
    assert "TIDAK DIUJI" in keluar
    assert "MASIH ROSAK" not in keluar
    assert "BELUM terbukti" in keluar


def test_verdik_tidak_diuji_bukan_bersih(capsys):
    j = _jejak("GAGAL", "D09TidakDiuji: D-09 TIDAK DIUJI - 0 rekod K")
    j.papar_verdik()
    assert "BERSIH" not in capsys.readouterr().out


def test_verdik_rosak_sebenar_masih_dilaporkan(capsys):
    j = _jejak("GAGAL", "RuntimeError: D-09 MASIH ADA pada build ini")
    j.papar_verdik()
    keluar = capsys.readouterr().out
    assert "MASIH ROSAK" in keluar
    assert "Batalkan kesemuanya" in keluar


def test_verdik_bersih_hanya_bila_lulus(capsys):
    j = _jejak("LULUS", "3 rekod K larian ini bersih")
    j.papar_verdik()
    assert "BERSIH pada build ini" in capsys.readouterr().out

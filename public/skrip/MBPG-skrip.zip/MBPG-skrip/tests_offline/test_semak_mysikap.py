"""Gerbang untuk pengesan D-09.

Pengesan ini wujud kerana penegasan lama hanya bertanya "medan terisi?".
Ujian di sini sengaja termasuk kes di mana pengesan mesti DIAM — sebuah
pengesan yang menjerit pada setiap input tidak lebih berguna daripada
yang tidak pernah menjerit.
"""

import os
import sys

AKAR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, AKAR)

from tools.semak_mysikap import kesan, _sulit          # noqa: E402


def r(no, kereta, nama, akaun="", jenis="", warna=""):
    return {"no": no, "kereta": kereta, "nama": nama, "akaun": akaun,
            "jenis": jenis, "warna": warna}


def test_nama_sama_dengan_plat_ditangkap():
    """Tanda (a) sebenar dari production: PGP02K260813002."""
    d, _ = kesan([r("PGP02K260813002", "JYX6605", "JYX6605")])
    assert [x["tanda"] for x in d] == ["a"]


def test_nama_kosong_ditangkap():
    d, _ = kesan([r("K1", "ABC1234", "")])
    assert [x["tanda"] for x in d] == ["a"]


def test_rekod_sihat_tidak_menimbulkan_dapatan():
    d, _ = kesan([r("K1", "JYX6605", "SITI", akaun="1", jenis="MYVI")])
    assert d == []


def test_identiti_melekat_pada_plat_berbeza_ditangkap():
    """Tanda (b) — kompaun kelihatan sah tetapi menamakan orang salah."""
    d, boleh = kesan([
        r("K1", "AAA1111", "SITI", akaun="900101015555"),
        r("K2", "BBB2222", "SITI", akaun="900101015555"),
    ])
    assert boleh is True
    assert [x["tanda"] for x in d] == ["b"]
    assert "AAA1111" in d[0]["mesej"] and "BBB2222" in d[0]["mesej"]


def test_identiti_sama_pada_plat_sama_adalah_betul():
    """Dua kompaun untuk kenderaan yang SAMA sepatutnya menamakan orang
    yang sama. Menandakannya sebagai defek akan melatih pembaca
    mengabaikan pengesan ini."""
    d, boleh = kesan([
        r("K1", "JYX6605", "SITI", akaun="900101015555"),
        r("K2", "JYX6605", "SITI", akaun="900101015555"),
    ])
    assert boleh is False
    assert d == []


def test_plat_sama_dilaporkan_sebagai_TIDAK_DIUJI_bukan_lulus():
    """Perbezaan yang menjadikan laporan jujur."""
    _, boleh = kesan([r("K1", "JYX6605", "SITI"),
                      r("K2", "JYX6605", "SITI")])
    assert boleh is False


def test_plat_berbeza_pemilik_berbeza_bersih():
    d, boleh = kesan([
        r("K1", "AAA1111", "SITI", akaun="900101015555"),
        r("K2", "BBB2222", "AHMAD", akaun="880202025555"),
    ])
    assert boleh is True and d == []


def test_plat_dalam_medan_nama_tidak_dikira_identiti_berulang():
    """Dua rekod yang kedua-duanya gagal carian tidak sepatutnya juga
    dilaporkan sebagai identiti melekat — itu satu defek dilaporkan
    dua kali dengan nama berbeza."""
    d, _ = kesan([r("K1", "AAA1111", "AAA1111"),
                  r("K2", "BBB2222", "BBB2222")])
    assert {x["tanda"] for x in d} == {"a"}


def test_penyulitan_tidak_mendedahkan_kp_penuh():
    assert _sulit("900101015555") == "90********55"
    assert "0101" not in _sulit("900101015555")

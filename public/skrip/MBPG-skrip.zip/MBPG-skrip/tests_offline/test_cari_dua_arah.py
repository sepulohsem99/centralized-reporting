"""
Ujian read-back dua arah — tanpa peranti.

find_with_scroll hanya menatal KE BAWAH. Selepas mengisi borang dan
memilih tiga dropdown, kedudukan skrin berada jauh DI BAWAH medan awal,
jadi mencari 'DEPAN KEDAI' ke bawah tidak akan menjumpainya walaupun ia
terisi. Diperhati pada device 2026-08-10.
"""

import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from pages.base_page import BasePage                          # noqa: E402


class BorangMaya(BasePage):
    """Borang maya: elemen pada kedudukan tetap, viewport bergerak."""

    TINGGI_VIEWPORT = 2000
    LANGKAH = 600

    def __init__(self, kedudukan, offset=0, boleh_skrol=True):
        self.kedudukan = kedudukan       # {teks: y_mutlak}
        self.offset = offset             # bahagian atas viewport
        self.boleh_skrol = boleh_skrol
        self.skrol = []
        self.last_scroll_result = {}

    def _teks_dicari(self, locator):
        m = locator[1]
        return m.split('"')[1] if '"' in m else m

    def is_element_present(self, locator, timeout=5):
        t = self._teks_dicari(locator)
        y = self.kedudukan.get(t)
        if y is None:
            return False
        return self.offset <= y <= self.offset + self.TINGGI_VIEWPORT

    def scroll_in_viewport(self, direction="down", percent=0.3, context=""):
        self.skrol.append(direction)
        if not self.boleh_skrol:
            self.last_scroll_result = {"ok": True, "status": "TIDAK_BERGERAK"}
            return True
        lama = self.offset
        if direction == "down":
            self.offset = min(self.offset + self.LANGKAH, 4000)
        else:
            self.offset = max(self.offset - self.LANGKAH, 0)
        bergerak = self.offset != lama
        self.last_scroll_result = {
            "ok": True,
            "status": "BERGERAK" if bergerak else "TIDAK_BERGERAK"}
        return True


def loc(teks):
    return ("-android uiautomator", f'new UiSelector().textContains("{teks}")')


MEDAN = {
    "DEPAN KEDAI": 400,                       # jauh di ATAS
    "PARKING KERETA DI TEMPAT OKU": 800,
    "KETERANGAN KOD KOMPAUN": 3000,           # jauh di BAWAH
}


# ---------------------------------------------------------------------------

def test_medan_dalam_viewport_dijumpai_tanpa_skrol():
    b = BorangMaya(MEDAN, offset=0)
    assert b.cari_dua_arah(loc("DEPAN KEDAI"))
    assert b.skrol == [], "tiada skrol sepatutnya diperlukan"


def test_medan_DI_ATAS_dijumpai():
    """SENARIO N-001. Selepas dropdown, viewport berada pada y=2800;
    'DEPAN KEDAI' pada y=400 — jauh di atas."""
    b = BorangMaya(MEDAN, offset=2800)
    assert not b.is_element_present(loc("DEPAN KEDAI"))
    assert b.cari_dua_arah(loc("DEPAN KEDAI"))
    assert "up" in b.skrol


def test_medan_DI_BAWAH_dijumpai():
    b = BorangMaya(MEDAN, offset=0)
    assert not b.is_element_present(loc("KETERANGAN KOD KOMPAUN"))
    assert b.cari_dua_arah(loc("KETERANGAN KOD KOMPAUN"))
    assert "down" in b.skrol


def test_medan_tiada_gagal_betul_bukan_false_pass():
    """SIFAT PALING PENTING. Medan yang memang TIADA mesti pulang False.
    Read-back yang memulangkan True secara longgar lebih teruk daripada
    tiada read-back langsung."""
    b = BorangMaya(MEDAN, offset=0)
    assert b.cari_dua_arah(loc("NILAI YANG TIDAK PERNAH DIISI")) is False


def test_borang_tidak_boleh_skrol_tidak_menggantung():
    """Borang yang menolak setiap skrol mesti berhenti awal, bukan
    memutar sehingga had."""
    b = BorangMaya(MEDAN, offset=2800, boleh_skrol=False)
    assert b.cari_dua_arah(loc("DEPAN KEDAI")) is False
    assert len(b.skrol) <= 4, f"terlalu banyak skrol sia-sia: {len(b.skrol)}"


def test_kedua_dua_arah_dicuba_sebelum_mengaku_gagal():
    b = BorangMaya(MEDAN, offset=1500)
    b.cari_dua_arah(loc("TIADA"))
    assert "up" in b.skrol and "down" in b.skrol


@pytest.mark.parametrize("offset", [0, 600, 1200, 2400, 3600])
def test_dijumpai_dari_mana_mana_kedudukan_mula(offset):
    """Read-back tidak boleh bergantung pada kedudukan skrin."""
    for teks in ("DEPAN KEDAI", "PARKING KERETA DI TEMPAT OKU",
                 "KETERANGAN KOD KOMPAUN"):
        b = BorangMaya(MEDAN, offset=offset)
        assert b.cari_dua_arah(loc(teks)), f"{teks!r} dari offset {offset}"

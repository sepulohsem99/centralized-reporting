"""
Ujian dasar dry-run — TIADA peranti, TIADA Appium, TIADA rangkaian.

Dipisahkan daripada tests\\ dengan sengaja: tests\\conftest.py memuatkan
profil dan mencipta sesi Appium sebenar. Gerbang mesti boleh dibuktikan
pada mesin tanpa telefon bersambung, sebelum sesiapa memandu production.

    python -m pytest tests_offline -q
"""

import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from guard import dasar                                        # noqa: E402
from guard.dasar import (Tetapan, nilai, konteks_bookmark,
                         konteks_tetapan)       # noqa: E402


# ---------------------------------------------------------------------------
# Perkakas
# ---------------------------------------------------------------------------

def default():
    """Mod pemilik yang dikunci: dry-run ON, serah OFF."""
    return Tetapan(dry_run=True, benarkan_serah=False, izin_serah=False)


def serah_on():
    """Mod pilihan yang hanya pemilik boleh hidupkan dengan tangan."""
    return Tetapan(dry_run=True, benarkan_serah=True, izin_serah=False)


# ---------------------------------------------------------------------------
# Trip-wire — tidak boleh ditekan dalam APA JUA mod
# ---------------------------------------------------------------------------

TRIPWIRE_TEKS = [
    "HANTAR", "Hantar", "hantar",
    "HANTAR SEMULA", "Hantar Semula", "HANTARSEMULA",
    "YA", "Ya", " ya ",
    "OK", "Ok", "ok",
    "SAHKAN", "Sahkan",
    "KEMASKINI", "Kemaskini", "KEMASKINI REKOD",
]


@pytest.mark.parametrize("teks", TRIPWIRE_TEKS)
@pytest.mark.parametrize("tetapan_f", [default, serah_on],
                         ids=["serah_off", "serah_on"])
def test_tripwire_sentiasa_disekat(teks, tetapan_f):
    k = nilai([teks], tetapan_f())
    assert not k.benarkan, f"{teks!r} SEPATUTNYA disekat — {k.sebab}"


def test_tripwire_tidak_boleh_dibuka_oleh_mana_mana_bendera():
    """Tiada gabungan bendera yang membenarkan HANTAR. Kalau ujian ini
    gagal, seseorang telah menambah pintu belakang."""
    for dr in (True, False):
        for bs in (True, False):
            for izin in (True, False):
                t = Tetapan(dry_run=dr, benarkan_serah=bs, izin_serah=izin)
                if not t.dry_run:
                    continue     # dry-run OFF penuh diuji berasingan
                assert not nilai(["HANTAR"], t).benarkan


# ---------------------------------------------------------------------------
# Sauh ^YA$ / ^OK$ — pendek, jadi mesti tepat
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("teks", [
    "LOKASI", "TIDAK OK JUGA", "OKTOBER", "KOMPAUN OKTOBER",
    "BAYARAN", "YAYASAN", "PENYATA",
])
def test_sauh_tidak_terlebih_padan(teks):
    """'OK'/'YA' sebagai subrentetan perkataan lain BUKAN butang OK."""
    k = nilai([teks], default())
    assert k.benarkan, f"{teks!r} tersalah sekat oleh sauh — {k.sebab}"


def test_setiap_teks_dinilai_berasingan_bukan_dicantum():
    """Sauh hanya berfungsi kalau rentetan tidak pernah dicantum. Butang
    dengan anak TextView 'YA' tiba sebagai rentetan tersendiri."""
    k = nilai(["", "Adakah anda pasti?", "YA"], default())
    assert not k.benarkan
    assert k.padanan == "YA"


# ---------------------------------------------------------------------------
# SERAH — bergantung mod, kuota satu per TC
# ---------------------------------------------------------------------------

def test_serah_disekat_secara_default():
    k = nilai(["SERAH"], default())
    assert not k.benarkan
    assert k.peraturan == "SERAH"


def test_serah_dibenarkan_bila_dibuka_pemilik():
    k = nilai(["SERAH"], serah_on())
    assert k.benarkan


def test_serah_hanya_sekali_setiap_tc():
    t = serah_on()
    assert nilai(["SERAH"], t).benarkan,     "serah pertama sepatutnya lulus"
    assert not nilai(["SERAH"], t).benarkan, "serah kedua sepatutnya disekat"
    t.mula_tc()
    assert nilai(["SERAH"], t).benarkan,     "kuota sepatutnya reset per TC"


# ---------------------------------------------------------------------------
# SIMPAN — hanya dalam dialog bookmark
# ---------------------------------------------------------------------------

def test_simpan_disekat_di_luar_dialog_bookmark():
    k = nilai(["SIMPAN"], default(), konteks_simpan=None)
    assert not k.benarkan


def test_simpan_dibenarkan_dalam_dialog_bookmark():
    k = nilai(["SIMPAN"], default(), konteks_simpan="bookmark")
    assert k.benarkan


def test_simpan_dalam_bookmark_tidak_membuka_tripwire():
    """Konteks bookmark melonggarkan SIMPAN SAHAJA. Kalau dialog itu
    entah bagaimana mengandungi butang HANTAR, ia kekal disekat."""
    k = nilai(["HANTAR"], default(), konteks_simpan="bookmark")
    assert not k.benarkan


# ---------------------------------------------------------------------------
# Konteks bookmark — dua syarat, kedua-duanya wajib
# ---------------------------------------------------------------------------

def _node(**kw):
    return " ".join(f'{k.replace("_", "-")}="{v}"' for k, v in kw.items())


# Dialog bookmark SEBENAR: tajuk + modal-surface + EditText DALAM modal.
XML_DIALOG_BOOKMARK = (
    '<hierarchy>'
    '<node class="android.view.ViewGroup">'
    f'  <node {_node(text="Daftar Notis Amaran")}/>'
    f'  <node {_node(**{"class": "android.widget.EditText"}, text="NAMA PESALAH")}/>'
    f'  <node {_node(resource_id="modal-surface")}>'
    f'    <node {_node(text="PILIHAN KEGEMARAN")}/>'
    f'    <node {_node(**{"class": "android.widget.EditText"}, text="")}/>'
    f'    <node {_node(text="SIMPAN")}/>'
    '  </node>'
    '</node></hierarchy>')

# Borang biasa, ikon buku kelihatan, TIADA modal terbuka.
XML_BORANG_SAHAJA = (
    '<hierarchy><node>'
    f'<node {_node(text="Daftar Notis Amaran")}/>'
    f'<node {_node(text="")}/>'
    f'<node {_node(**{"class": "android.widget.EditText"}, text="NAMA PESALAH")}/>'
    '</node></hierarchy>')

# Popup SENARAI kegemaran (PILIH/HAPUS) — tiada medan nama dalam modal.
XML_SENARAI_KEGEMARAN = (
    '<hierarchy><node>'
    f'<node {_node(**{"class": "android.widget.EditText"}, text="NAMA PESALAH")}/>'
    f'<node {_node(resource_id="modal-surface")}>'
    f'  <node {_node(text="PILIHAN KEGEMARAN")}/>'
    f'  <node {_node(text="AUTO-TEST-N")}/>'
    f'  <node {_node(text="PILIH")}/>'
    '</node>'
    '</node></hierarchy>')


def test_dialog_bookmark_sebenar_dikenali():
    assert konteks_bookmark(XML_DIALOG_BOOKMARK)


def test_borang_dengan_ikon_buku_bukan_dialog_bookmark():
    """REGRESI TERPENTING dalam fail ini.

    Borang Daftar Notis Amaran membawa ikon buku DAN medan EditText
    (NAMA PESALAH). Semakan naif "ada penanda + ada EditText" akan
    memulangkan True di sini dan membuka SIMPAN pada SELURUH borang.
    Semakan berstruktur memulangkan False kerana tiada modal terbuka."""
    assert not konteks_bookmark(XML_BORANG_SAHAJA)


def test_editext_borang_di_belakang_modal_tidak_dikira():
    """Dump K9: borang PESALAH kekal dalam pokok di belakang popup.
    EditText-nya berada DI LUAR modal-surface, jadi ia tidak melayakkan
    popup senarai (yang tiada medan nama) sebagai dialog nama."""
    assert not konteks_bookmark(XML_SENARAI_KEGEMARAN)


def test_konteks_bookmark_gagal_tertutup():
    assert not konteks_bookmark("")
    assert not konteks_bookmark(None)
    assert not konteks_bookmark("<hierarchy><node text='rosak'")   # XML cacat
    assert not konteks_bookmark("<hierarchy/>")


# ---------------------------------------------------------------------------
# Butang keluar — laluan pemulihan mesti sentiasa terbuka
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("teks", ["BATAL", "Batal", "TIDAK", "Tidak",
                                  "CANCEL", "TUTUP", "KEMBALI"])
def test_keluar_selamat_sentiasa_dibenarkan(teks):
    assert nilai([teks], default()).benarkan


def test_keluar_selamat_tidak_mengatasi_tripwire_pada_teks_lain():
    """Popup dengan BATAL dan YA bersebelahan: memungut kedua-dua teks
    daripada satu sasaran tap bermakna kita tidak tahu yang mana ditekan.
    Ini kes yang WAJIB gagal-tertutup... tetapi keluar-selamat diperiksa
    dahulu, jadi ia LULUS. Ujian ini merekod tingkah laku itu supaya ia
    keputusan yang disedari, bukan kejutan."""
    k = nilai(["BATAL", "YA"], default())
    assert k.benarkan
    assert k.peraturan == "KELUAR"


# ---------------------------------------------------------------------------
# Kes tiada teks
# ---------------------------------------------------------------------------

def test_ikon_tanpa_label_dibenarkan():
    """Ikon klip / ikon buku / anak panah dropdown tiada teks. Menyekat
    semuanya akan melumpuhkan suite tanpa memberi keselamatan tambahan —
    butang penghantaran SEMUANYA berlabel."""
    assert nilai([], default()).benarkan
    assert nilai(["", "   "], default()).benarkan


# ---------------------------------------------------------------------------
# Tetapan — gagal-tertutup
# ---------------------------------------------------------------------------

def test_satu_bendera_tidak_boleh_mematikan_dry_run(monkeypatch):
    """MBPG_DRY_RUN=0 sahaja TIDAK cukup. Tanpa MBPG_IZIN_SERAH, gerbang
    memasang semula dirinya. Ini menghalang satu salah taip dalam satu
    terminal daripada melucutkan senjata suite."""
    monkeypatch.setenv("MBPG_DRY_RUN", "0")
    monkeypatch.delenv("MBPG_IZIN_SERAH", raising=False)
    monkeypatch.delenv("MBPG_BENARKAN_SERAH", raising=False)
    t = Tetapan()
    assert t.dry_run is True
    assert not nilai(["HANTAR"], t).benarkan


def test_default_persekitaran_kosong_adalah_paling_selamat(monkeypatch):
    for v in ("MBPG_DRY_RUN", "MBPG_IZIN_SERAH", "MBPG_BENARKAN_SERAH"):
        monkeypatch.delenv(v, raising=False)
    t = Tetapan()
    assert t.dry_run is True
    assert t.benarkan_serah is False
    assert not nilai(["SERAH"], t).benarkan


def test_dua_bendera_TIDAK_lagi_membuka_apa_apa(monkeypatch):
    """DIUBAH 2026-08-12 — dahulunya menegaskan HANTAR LULUS di sini.

    Versi lama merekod litar pintas `if not tetapan.dry_run: allow`.
    Litar pintas itu bermakna dua bendera yang diset untuk membenarkan
    SATU rekod Fasa C turut membuka PADAM, KEMASKINI, dan Selaras
    Pelesen. Ia dibuang atas kelulusan pemilik.

    Sekarang: dua bendera itu hanya PRASYARAT. Tanpa permit berskop,
    tiada butang serah boleh ditekan."""
    monkeypatch.setenv("MBPG_DRY_RUN", "0")
    monkeypatch.setenv("MBPG_IZIN_SERAH", "1")
    t = Tetapan()
    assert t.dry_run is False
    assert t.permit_serah is None
    assert not nilai(["HANTAR"], t).benarkan
    assert not nilai(["YA"], t).benarkan
    assert not nilai(["SERAH"], t).benarkan


# ---------------------------------------------------------------------------
# Terlebih-sekat yang disengajakan
# ---------------------------------------------------------------------------

def test_penghantaran_terlebih_sekat_dengan_sengaja():
    """'PENGHANTARAN TIDAK BERJAYA' mengandungi 'HANTAR' sebagai
    subrentetan dan DISEKAT. Itu positif palsu yang kami terima: kosnya
    ialah run dibatalkan, berbanding kompaun sebenar dikeluarkan.
    Rentetan yang memadan direkod supaya ia boleh dikenal pasti."""
    k = nilai(["PENGHANTARAN TIDAK BERJAYA"], default())
    assert not k.benarkan
    assert k.padanan == "PENGHANTARAN TIDAK BERJAYA"
    assert k.peraturan == "HANTAR"


def test_menu_daftar_notis_amaran_dibenarkan():
    """Membuka borang melalui menu DIBENARKAN — yang diharamkan ialah
    pengesahan akhir."""
    for menu in ["Daftar Notis Amaran", "Daftar Kompaun Pelbagai",
                 "Daftar Kompaun Letak Kereta", "Senarai Kompaun",
                 "Menu Selaras", "Tetapan"]:
        assert nilai([menu], default()).benarkan, menu


def test_menu_hantar_disekat_walaupun_ia_menu():
    """Menu 'Hantar' disekat. Skopnya SKIP, jadi menyekatnya betul —
    tetapi rekodkan bahawa gerbang tidak boleh membezakan menu Hantar
    daripada butang Hantar, dan memilih yang selamat."""
    assert not nilai(["Hantar"], default()).benarkan


# ===========================================================================
# PENGECUALIAN SIMPAN — SKRIN TETAPAN
# Keputusan pemilik 2026-08-07: T-001/T-002/T-010 menulis config LOKAL
# device, bukan rekod production, jadi SIMPAN dibenarkan DI SITU SAHAJA.
# ===========================================================================

XML_TETAPAN_ALAMAT_IP = (
    '<hierarchy><node>'
    f'<node {_node(text="msc", **{"class": "android.widget.EditText"}, resource_id="text-input-outlined")}/>'
    f'<node {_node(resource_id="modal-surface")}>'
    f'  <node {_node(text="INTERNAL IP ADDRESS")}/>'
    f'  <node {_node(resource_id="text-input-outlined", text="113.211.155.174")}/>'
    f'  <node {_node(text="EXTERNAL IP ADDRESS")}/>'
    f'  <node {_node(resource_id="text-input-outlined", text="113.211.155.174")}/>'
    f'  <node {_node(text="SIMPAN")}/>'
    '</node></node></hierarchy>')

XML_TETAPAN_PELBAGAI = (
    '<hierarchy><node>'
    f'<node {_node(resource_id="modal-surface")}>'
    f'  <node {_node(text="LESEN APLIKASI:")}/>'
    f'  <node {_node(resource_id="text-input-outlined", text="999999999999999")}/>'
    f'  <node {_node(text="SIMPAN")}/>'
    '</node></node></hierarchy>')

XML_TETAPAN_SKRIN_UTAMA = (
    '<hierarchy><node>'
    f'<node {_node(resource_id="modal-surface")}>'
    f'  <node {_node(text="PILIHAN SKRIN UTAMA")}/>'
    f'  <node {_node(text="DEFAULT")}/>'
    f'  <node {_node(text="NOTIS AMARAN")}/>'
    '</node></node></hierarchy>')

# Skrin LOGIN — juga guna text-input-outlined, dan kekal dirender DI
# BELAKANG modal Tetapan. Sauh id SAHAJA tidak boleh melayakkannya.
XML_LOGIN_SAHAJA = (
    '<hierarchy><node>'
    f'<node {_node(text="LOG MASUK")}/>'
    f'<node {_node(resource_id="text-input-outlined", text="msc")}/>'
    f'<node {_node(resource_id="text-input-outlined", text="")}/>'
    '</node></hierarchy>')

# Borang kompaun — TIADA text-input-outlined langsung.
XML_BORANG_KOMPAUN = (
    '<hierarchy><node>'
    f'<node {_node(text="Daftar Kompaun Letak Kereta")}/>'
    f'<node {_node(**{"class": "android.widget.EditText"}, text="NAMA PESALAH")}/>'
    f'<node {_node(**{"class": "android.widget.EditText"}, text="NO. KENDERAAN")}/>'
    f'<node {_node(text="SIMPAN")}/>'
    '</node></hierarchy>')


# ---- positif: dibenarkan dalam konteks tetapan ---------------------------

@pytest.mark.parametrize("xml,nama", [
    (XML_TETAPAN_ALAMAT_IP, "Tetapan Alamat IP (T-001)"),
    (XML_TETAPAN_PELBAGAI, "Tetapan Pelbagai (T-002)"),
    (XML_TETAPAN_SKRIN_UTAMA, "Tetapan Skrin Utama (T-010)"),
])
def test_konteks_tetapan_dikenali(xml, nama):
    assert konteks_tetapan(xml), f"{nama} sepatutnya dikenali"


@pytest.mark.parametrize("xml,nama", [
    (XML_TETAPAN_ALAMAT_IP, "T-001"),
    (XML_TETAPAN_PELBAGAI, "T-002"),
    (XML_TETAPAN_SKRIN_UTAMA, "T-010"),
])
def test_simpan_dibenarkan_dalam_skrin_tetapan(xml, nama):
    k = nilai(["SIMPAN"], default(), konteks_simpan="tetapan")
    assert k.benarkan, f"{nama}: {k.sebab}"
    assert "config LOKAL" in k.sebab


def test_ejaan_device_sebenar_lesen_applikasi():
    """REGRESI PERANTI SEBENAR — 2026-08-10.

    Peringkat 6 disekat pada modal Tetapan Pelbagai yang SAH kerana
    sauh menjangka 'LESEN APLIKASI' HURUF BESAR sedangkan app merender
    'Lesen Applikasi:' — Title Case, dua p, ada titik bertindih.
    Rentetan di bawah disalin dari
    reports/forensik/20260810-182859__tiada__SIMPAN.xml, jadi ejaan app
    kini menjadi UJIAN dan bukan andaian.
    """
    xml = ('<hierarchy><node resource-id="modal-surface">'
           '<node text="Menu Selaras"/>'
           '<node text="Lesen Applikasi:"/>'
           '<node resource-id="text-input-outlined" text="999999999999999"/>'
           '<node text="SIMPAN"/>'
           '</node></hierarchy>')
    assert konteks_tetapan(xml)
    assert nilai(["SIMPAN"], default(), konteks_simpan="tetapan").benarkan


def test_sauh_tetapan_tidak_sensitif_huruf():
    """Ketiga-tiga sauh, dalam Title Case seperti MBPG merendernya."""
    for label in ("Internal IP Address", "External IP Address",
                  "Lesen Aplikasi", "lesen applikasi:"):
        xml = (f'<hierarchy><node resource-id="modal-surface">'
               f'<node text="{label}"/>'
               f'<node resource-id="text-input-outlined" text="x"/>'
               f'</node></hierarchy>')
        assert konteks_tetapan(xml), label


# ---- negatif: disekat di mana-mana lagi ----------------------------------

def test_medan_tanpa_sauh_masih_ditolak():
    """Melonggarkan sauh kepada regex tidak boleh melonggarkan syarat
    KEDUA. Medan outlined tanpa mana-mana label Tetapan kekal BUKAN
    konteks tetapan."""
    xml = ('<hierarchy><node resource-id="modal-surface">'
           '<node text="Sesuatu Yang Lain"/>'
           '<node resource-id="text-input-outlined" text="x"/>'
           '</node></hierarchy>')
    assert not konteks_tetapan(xml)


def test_borang_kompaun_bukan_skrin_tetapan():
    """REGRESI: pengecualian tetapan tidak boleh bocor ke borang kompaun.
    Borang kompaun tiada 'text-input-outlined' langsung."""
    assert not konteks_tetapan(XML_BORANG_KOMPAUN)


def test_skrin_login_bukan_skrin_tetapan():
    """Skrin login MENGGUNAKAN text-input-outlined dan kekal dirender di
    BELAKANG modal Tetapan. Kalau sauh id sahaja mencukupi, SIMPAN akan
    terbuka pada skrin login juga — dan lebih teruk, ia akan terbuka
    sepanjang masa modal Tetapan TIDAK dibuka."""
    assert not konteks_tetapan(XML_LOGIN_SAHAJA)


def test_borang_bookmark_bukan_skrin_tetapan():
    assert not konteks_tetapan(XML_DIALOG_BOOKMARK)
    assert not konteks_tetapan(XML_BORANG_SAHAJA)


def test_simpan_dalam_borang_kompaun_kekal_disekat():
    k = nilai(["SIMPAN"], default(), konteks_simpan=None)
    assert not k.benarkan
    assert "bukan skrin\nTetapan" in k.sebab or "bukan skrin Tetapan" in k.sebab


def test_konteks_tetapan_gagal_tertutup():
    assert not konteks_tetapan("")
    assert not konteks_tetapan(None)
    assert not konteks_tetapan("<hierarchy><node text='rosak'")
    assert not konteks_tetapan("<hierarchy/>")


def test_konteks_tetapan_tidak_membuka_tripwire():
    """Pengecualian tetapan melonggarkan SIMPAN SAHAJA. HANTAR/YA/OK/
    SAHKAN/KEMASKINI kekal disekat walaupun di skrin Tetapan."""
    for t in ["HANTAR", "YA", "OK", "SAHKAN", "KEMASKINI"]:
        assert not nilai([t], default(), konteks_simpan="tetapan").benarkan, t


def test_konteks_tetapan_tidak_membuka_serah():
    assert not nilai(["SERAH"], default(), konteks_simpan="tetapan").benarkan


# ===========================================================================
# SELARAS MAKLUMAT PELESEN — EXCLUDE TOTAL (sync 3-4 JAM)
# ===========================================================================

@pytest.mark.parametrize("teks", [
    "SELARAS MAKLUMAT PELESEN",
    "Selaras Maklumat Pelesen",
    "SELARAS  MAKLUMAT  PELESEN",
    "SELARASMAKLUMATPELESEN",
    "PELESEN",
    " pelesen ",
])
def test_selaras_pelesen_sentiasa_disekat(teks):
    k = nilai([teks], default())
    assert not k.benarkan, f"{teks!r} sepatutnya disekat"
    assert k.peraturan == "SELARAS-PELESEN"
    assert "3-4 JAM" in k.sebab


def test_selaras_pelesen_tidak_boleh_dibuka_oleh_mana_mana_bendera():
    """Tiada bendera dan tiada konteks membukanya."""
    for bs in (True, False):
        for ks in (None, "bookmark", "tetapan"):
            t = Tetapan(dry_run=True, benarkan_serah=bs, izin_serah=False)
            assert not nilai(["SELARAS MAKLUMAT PELESEN"], t,
                             konteks_simpan=ks).benarkan


def test_modul_selaras_lain_tidak_tersekat():
    """Sekatan mesti menyasar Pelesen SAHAJA — lima modul selaras yang
    dibenarkan mesti tetap boleh ditekan satu per satu."""
    for m in ["SELARAS PENGGUNA APPS", "SELARAS MAKLUMAT ALAMAT",
              "SELARAS MAKLUMAT KOMPAUN", "SELARAS MAKLUMAT JENIS KENDERAAN",
              "SELARAS MAKLUMAT WARNA", "SELARAS MAKLUMAT BARANG SITA"]:
        k = nilai([m], default())
        assert k.benarkan, f"{m} tersalah sekat — {k.sebab}"


def test_kompaun_lesen_tidak_tersalah_padan_pelesen():
    """'LESEN' bukan 'PELESEN'. Siri L luar skop, tetapi sekatan ini
    tidak sepatutnya jadi sebab tersembunyi kenapa ia gagal."""
    for m in ["KOMPAUN LESEN", "LESEN APLIKASI", "DAFTAR KOMPAUN LESEN"]:
        assert nilai([m], default()).benarkan, m


# ===========================================================================
# DIALOG RALAT/INFO ASLI — pengecualian OK yang sangat sempit
# Spesifikasi pemilik: "^OK$ blocked; kecuali dialog yang TERBUKTI tiada
# kaitan penghantaran (cth dialog error/info) — log teks penuh dulu."
# ===========================================================================

def _alert(tajuk, mesej, butang="OK"):
    return (
        '<hierarchy><node>'
        f'<node resource-id="android:id/alertTitle" text="{tajuk}"/>'
        f'<node resource-id="android:id/message" text="{mesej}"/>'
        f'<node resource-id="android:id/button1" text="{butang}"/>'
        '</node></hierarchy>')


def test_alert_ralat_dikenali_membenarkan_ok():
    """Dilihat pada device 2026-08-10 sejurus selepas LOGIN."""
    ok, badan = dasar.konteks_alert_info(
        _alert("Alert", "Error: Unable to connect device"))
    assert ok
    assert "Unable to connect device" in badan
    k = nilai(["OK"], default(), alert_info=badan)
    assert k.benarkan
    assert k.peraturan == "OK-ALERT-INFO"


def test_alert_status_simpanan_masa_tamat_dibenarkan():
    """Dialog HASIL selepas CETAK borang K — membunuh run 18.

    Kelulusan eksplisit pemilik 2026-10-09. Forensik:
    reports/forensik/20261009-231715__tiada__OK.xml
    (STATUS SIMPANAN | MASA TAMAT (15s). DATA TELAH DISIMPAN SECARA LOKAL.)
    """
    badan_benar = ("STATUS SIMPANAN | MASA TAMAT (15s). DATA TELAH "
                   "DISIMPAN SECARA LOKAL.")
    ok, badan = dasar.konteks_alert_info(
        _alert("STATUS SIMPANAN",
               "MASA TAMAT (15s). DATA TELAH DISIMPAN SECARA LOKAL."))
    assert ok, "dialog HASIL selepas cetak mesti dibenarkan"
    assert badan == badan_benar
    k = nilai(["OK"], default(), alert_info=badan)
    assert k.benarkan
    assert k.peraturan == "OK-ALERT-INFO"


def test_alert_status_simpanan_ayat_penghantaran_kekal_disekat():
    """Sauh bentuk-PENUH: ayat penghantaran tambahan TIDAK boleh memadan."""
    ok, _ = dasar.konteks_alert_info(
        _alert("STATUS SIMPANAN",
               "MASA TAMAT (15s). DATA TELAH DISIMPAN SECARA LOKAL. HANTAR?"))
    assert not ok, "ayat tambahan mesti membatalkan padanan sauh penuh"


def test_alert_status_simpanan_tidak_pecahkan_kembar_kejayaan():
    """Regresi: membenarkan dialog baharu tidak boleh merosakkan corak lain."""
    ok, _ = dasar.konteks_alert_info(
        _alert("BERJAYA", "DATA KOMPAUN BERJAYA DISIMPAN!"))
    assert ok


def test_alert_status_simpanan_butang_domain_kekal_disekat():
    """Skop: PERKATAAN_BAHAYA mengatasi segalanya untuk butang domain."""
    badan = ("STATUS SIMPANAN | MASA TAMAT (15s). DATA TELAH DISIMPAN "
             "SECARA LOKAL.")
    for b in ("HANTAR", "SERAH", "SAHKAN", "KEMASKINI"):
        k = nilai([b], default(), alert_info=badan)
        assert not k.benarkan, f"{b} mesti kekal diseksat"
        assert k.peraturan == b


def test_alert_tidak_dikenali_kekal_disekat_tetapi_badan_dilog():
    """Dialog baharu mesti gagal-tertutup — TETAPI badannya dipulangkan
    supaya ia muncul dalam ledger. Kalau tidak, ia jadi kebuntuan yang
    tiada siapa boleh nyahsulit."""
    ok, badan = dasar.konteks_alert_info(
        _alert("Alert", "Sesuatu yang belum pernah dilihat"))
    assert not ok
    assert "belum pernah dilihat" in badan
    assert not nilai(["OK"], default()).benarkan


def test_alert_dengan_perkataan_penghantaran_tidak_pernah_dibenarkan():
    """Jaring kedua: satu dialog boleh menyebut ralat DAN mengesahkan
    penghantaran. Senarai putih tidak boleh mengatasi itu."""
    for mesej in ("Error: Unable to connect device. HANTAR sekarang?",
                  "Unable to connect device — SERAH kompaun?",
                  "Unable to connect device. Rekod BERJAYA disimpan"):
        ok, badan = dasar.konteks_alert_info(_alert("Alert", mesej))
        assert not ok, mesej
        assert not nilai(["OK"], default(), alert_info=None).benarkan


def test_alert_lesen_sama_dibenarkan_kedua_dua_ejaan():
    """T-002. App mengeja tajuknya "BEJAYA"; kedua-dua ejaan diterima.
    Badan "LESEN SAMA." bermaksud TIADA APA BERUBAH — dialog paling
    tidak berbahaya dalam app."""
    for tajuk in ("BEJAYA", "BERJAYA", "Bejaya"):
        ok, badan = dasar.konteks_alert_info(_alert(tajuk, "LESEN SAMA."))
        assert ok, tajuk
        assert nilai(["OK"], default(), alert_info=badan).benarkan


def test_senarai_putih_lesen_bersauh_bukan_substring():
    """Sauh ^...$ ialah keseluruhan pertahanan. Mana-mana dialog yang
    sekadar MENGANDUNGI 'lesen sama' mesti kekal disekat — kalau tidak,
    senarai putih ini jadi lubang."""
    for mesej in ("LESEN SAMA. Kompaun berjaya dihantar",
                  "Sahkan: LESEN SAMA?",
                  "LESEN SAMA. Rekod PGP03 dikemaskini",
                  "LESEN TIDAK SAMA."):
        ok, _ = dasar.konteks_alert_info(_alert("BEJAYA", mesej))
        assert not ok, mesej


def test_dialog_keputusan_semak_versi_dibenarkan():
    """T-011 pulangan: dialog tajuk-sahaja 'APLIKASI IN TELAH DIKEMAS
    KINI'. Ejaan app dikekalkan; 'INI' juga diterima."""
    for tajuk in ("APLIKASI IN TELAH DIKEMAS KINI",
                  "Aplikasi ini telah dikemas kini"):
        ok, badan = dasar.konteks_alert_info(_alert(tajuk, ""))
        assert ok, tajuk
        assert nilai(["OK"], default(), alert_info=badan).benarkan


def test_dialog_kemas_kini_bersauh():
    for tajuk in ("APLIKASI INI TELAH DIKEMAS KINI. Hantar rekod?",
                  "Kompaun telah dikemas kini"):
        ok, _ = dasar.konteks_alert_info(_alert(tajuk, ""))
        assert not ok, tajuk


def test_semak_kemaskini_versi_bukan_kemaskini_rekod():
    """T-011. Label device: 'Semak Kemaskini Versi Terkini ' (ada ruang
    di hujung). Ia menyemak versi APP."""
    for t in ("Semak Kemaskini Versi Terkini",
              "Semak Kemaskini Versi Terkini ",
              "SEMAK KEMASKINI VERSI TERKINI"):
        k = nilai([t], default())
        assert k.benarkan, f"{t!r}: {k.sebab}"
        assert k.peraturan == "KEMASKINI-VERSI"


def test_kemaskini_rekod_kekal_disekat():
    """Pengecualian bersauh tidak boleh membuka pindaan rekod."""
    for t in ("KEMASKINI", "Kemaskini Notis Amaran",
              "Kemaskini Kompaun Pelbagai", "Semak Kemaskini Versi "
              "Terkini lalu KEMASKINI rekod"):
        assert not nilai([t], default()).benarkan, t


def test_dialog_selaras_bahasa_inggeris_dibenarkan():
    """App bercampur bahasa. Dilihat pada device 2026-08-10 semasa
    T-006: 'Data Jenis Kenderaan saved successfully!'."""
    ok, badan = dasar.konteks_alert_info(
        _alert("Berjaya", "Data Jenis Kenderaan saved successfully!"))
    assert ok
    assert nilai(["OK"], default(), alert_info=badan).benarkan


def test_varian_inggeris_kekal_bersauh():
    for mesej in ("Data Kompaun saved successfully! Serah sekarang?",
                  "Kompaun PGP03N260721001 saved successfully"):
        ok, _ = dasar.konteks_alert_info(_alert("Berjaya", mesej))
        assert not ok, mesej


def test_alert_penolakan_maklumat_tidak_lengkap_dibenarkan():
    """Dialog yang MEMBUNUH run peringkat 6 pertama. App enggan
    meneruskan; menolak keengganan tidak boleh menghantar apa-apa."""
    for tab in ("Pesalah", "Kompaun", "Penerima"):
        ok, badan = dasar.konteks_alert_info(_alert(
            "Maklumat Tidak Lengkap",
            f"Sila lengkapkan maklumat di tab {tab} dahulu."))
        assert ok, tab
        assert nilai(["OK"], default(), alert_info=badan).benarkan


def test_penolakan_bersauh_tidak_boleh_dilanjutkan():
    """Sekali lagi: sauh ialah pertahanan. Apa-apa yang dilekatkan pada
    ayat penolakan mesti membatalkan pengecualian."""
    for mesej in ("Sila lengkapkan maklumat di tab Pesalah dahulu. "
                  "Serah sekarang?",
                  "Maklumat Tidak Lengkap. Hantar juga?"):
        ok, _ = dasar.konteks_alert_info(
            _alert("Maklumat Tidak Lengkap", mesej))
        assert not ok, mesej


def test_dialog_hasil_hantar_gambar_ralat_dibenarkan():
    """Dialog HASIL Hantar Gambar (VERSI RALAT) — butang TUNGGAL OK.

    Dilihat pada device 2026-10-09; ia MEMBUNUH run DUA kali (borang N,
    kemudian gerbang IP dalam 27s kerana ia tinggal di skrin). Forensik:
    reports/forensik/20261009-124151__tiada__OK.xml.

    Muat naik gambar SUDAH tamat sebelum dialog ini muncul, jadi
    menutupnya tidak menghantar apa-apa — kelas sama dengan dialog
    KEJAYAAN yang sudah diluluskan 2026-09-14.
    """
    ok, badan = dasar.konteks_alert_info(
        _alert("Ralat", "Beberapa gambar tidak berjaya di muatnaik."))
    assert ok
    assert "tidak berjaya di muatnaik" in badan
    assert nilai(["OK"], default(), alert_info=badan).benarkan


def test_dialog_hasil_hantar_gambar_kekal_bersauh():
    """Sauh bentuk-PENUH ialah keseluruhan pertahanan. Mana-mana dialog
    yang menambah ayat penghantaran pada mesej hasil ini mesti KEKAL
    disekat — kalau tidak, pengecualian ini jadi lubang penghantaran."""
    for mesej in ("Beberapa gambar tidak berjaya di muatnaik. Hantar "
                  "semula sekarang?",
                  "Beberapa gambar tidak berjaya di muatnaik — SERAH "
                  "kompaun?"):
        ok, _ = dasar.konteks_alert_info(_alert("Ralat", mesej))
        assert not ok, mesej
        assert not nilai(["OK"], default()).benarkan, mesej


def test_dialog_berjaya_hantar_gambar_masih_dibenarkan():
    """Regresi: penambahan pola RALAT tidak boleh merosakkan pola
    KEJAYAAN yang sudah ada (2026-09-14)."""
    for mesej in ("Semua gambar berjaya di muatnaik.",
                  "Semua gambar  berjaya di muatnaik."):
        ok, _ = dasar.konteks_alert_info(_alert("Berjaya", mesej))
        assert ok, mesej


def test_dialog_hasil_gambar_tidak_membenarkan_butang_lain():
    """Pengecualian ini hanya untuk OK. HANTAR/SERAH mesti tetap
    disekat walau badannya sama."""
    badan = "Ralat | Beberapa gambar tidak berjaya di muatnaik."
    for t in ("HANTAR", "SERAH", "SAHKAN", "KEMASKINI"):
        assert not nilai([t], default(), alert_info=badan).benarkan, t


def test_pengecualian_alert_hanya_untuk_ok_dan_ya():
    """HANTAR/SERAH/SAHKAN/KEMASKINI tidak pernah dilonggarkan oleh
    konteks alert, walau apa pun badannya."""
    badan = "Alert | Error: Unable to connect device"
    for t in ("HANTAR", "SERAH", "SAHKAN", "KEMASKINI"):
        assert not nilai([t], default(), alert_info=badan).benarkan, t


def test_tiada_butang_asli_bermakna_bukan_alert():
    """Modal RN yang kebetulan memaparkan perkataan 'OK' bukan dialog
    asli, jadi pengecualian tidak terpakai."""
    xml = ('<hierarchy><node>'
           '<node resource-id="modal-surface"/>'
           '<node text="Unable to connect device"/>'
           '<node text="OK"/></node></hierarchy>')
    ok, _badan = dasar.konteks_alert_info(xml)
    assert not ok


def test_konteks_alert_gagal_tertutup():
    assert dasar.konteks_alert_info("") == (False, "")
    assert dasar.konteks_alert_info(None) == (False, "")
    assert dasar.konteks_alert_info("<hierarchy><node") == (False, "")


# --- keluarga dialog selaras (device 2026-08-10) --------------------------

def test_dialog_selaras_berjaya_dibenarkan():
    """T-003 memaparkan 'Berjaya | Data Pengguna Berjaya Disimpan!'.
    'Disimpan' bermaksud dimuat turun ke DB rujukan tempatan — sync
    baca-sahaja, bukan rekod dihantar."""
    for mesej in ("Data Pengguna Berjaya Disimpan!",
                  "Data Alamat Berjaya Disimpan!",
                  # Modul selaras yang BERNAMA Kompaun — inilah kes yang
                  # membatalkan T-005 pada device 2026-08-10.
                  "Data Kompaun Berjaya Disimpan!",
                  "Data Jenis Kenderaan Berjaya Disimpan!",
                  "Data Barang Sita Berjaya Disimpan!",
                  "Data Warna Berjaya Disimpan!"):
        ok, badan = dasar.konteks_alert_info(_alert("Berjaya", mesej))
        assert ok, mesej
        assert nilai(["OK"], default(), alert_info=badan).benarkan


def test_dialog_berjaya_yang_menyebut_rekod_kekal_disekat():
    """Perkataan kejayaan generik tidak lagi menyekat — istilah DOMAIN
    REKOD yang menyekat. Dialog yang mengesahkan kompaun/notis/sitaan
    tidak boleh lulus walaupun ia berbunyi seperti mesej sync."""
    for mesej in ("Kompaun PGP03N260721001 berjaya dihantar",
                  "Notis berjaya diserahkan kepada penerima",
                  "Rekod kompaun telah dikemaskini",
                  "Data Kompaun Berjaya Disimpan! Sila SAHKAN penghantaran"):
        ok, badan = dasar.konteks_alert_info(_alert("Berjaya", mesej))
        assert not ok, mesej
        assert badan, "badan mesti tetap dipulangkan untuk dilog"
        assert not nilai(["OK"], default()).benarkan


# ===========================================================================
# SIMPAN — sempadan perkataan (regresi sweep 2026-08-12)
# ===========================================================================

def test_simpan_dalam_perkataan_lain_bukan_butang_simpan():
    """REGRESI PERANTI. Sweep dibatalkan pada set ke-16 oleh baris
    dropdown ini — keterangan KESALAHAN, bukan butang:

      [SEK 81 (B)] - APA-APA BINATANG YANG DISIMPAN DALAM SESUATU
      TEMPAT ATAU DENGAN SESUATU CARA ATAU DENGAN SEBEGITU BESAR
      BILANGANNYA HINGGA MENJADI SUATU KACAU GANGGU

    Mengetuknya memilih nilai dropdown; ia tidak boleh menyimpan
    apa-apa."""
    baris = ("[SEK 81 (B)] - APA-APA BINATANG YANG DISIMPAN DALAM "
             "SESUATU TEMPAT ATAU DENGAN SESUATU CARA ATAU DENGAN "
             "SEBEGITU BESAR BILANGANNYA HINGGA MENJADI SUATU KACAU "
             "GANGGU")
    k = nilai([baris], default())
    assert k.benarkan, f"baris kesalahan tersalah sekat — {k.sebab}"


@pytest.mark.parametrize("teks", [
    "DISIMPAN", "Disimpan", "MENYIMPAN", "PENYIMPANAN", "SIMPANAN",
    "BARANG DISIMPAN DI STOR", "TIDAK DISIMPAN DENGAN BETUL",
])
def test_terbitan_simpan_tidak_disekat(teks):
    assert nilai([teks], default()).benarkan, teks


@pytest.mark.parametrize("teks", [
    "SIMPAN", "Simpan", "simpan", " SIMPAN ", "SIMPAN DATA",
    "SIMPAN & TUTUP",
])
def test_butang_simpan_sebenar_masih_disekat(teks):
    """Pembetulan sempadan perkataan tidak boleh membuka butang
    simpan yang SEBENAR di luar konteks yang dibenarkan."""
    k = nilai([teks], default(), konteks_simpan=None)
    assert not k.benarkan, f"{teks!r} sepatutnya disekat"
    assert k.peraturan == "SIMPAN"


def test_simpan_kekal_dibenarkan_dalam_konteks_tetapan_dan_bookmark():
    for konteks in ("tetapan", "bookmark"):
        assert nilai(["SIMPAN"], default(),
                     konteks_simpan=konteks).benarkan, konteks

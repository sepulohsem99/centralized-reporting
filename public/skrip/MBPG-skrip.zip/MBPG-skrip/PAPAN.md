# PAPAN KERJA — MBPG (Majlis Bandaraya Pasir Gudang)

> Persekitaran: **PRODUCTION 113.211.155.174**. Tiada staging MBPG.
> App: IES/KOMPAUN e-PBT. Device: Ulefone Armor 27.
> Build sebenar **2.1.21**, bukan 2.1.20 seperti oracle.

> **Misi asal:** buat script + validate field sahaja, tiada rekod baharu.
>
> **DIKEMAS KINI 2026-08-13 — misi itu sudah berubah.** Pemilik
> meluluskan Fasa C. **Tiga rekod production SEBENAR wujud**, ketiga-tiga
> dicetak dan disahkan fizikal. Senarai untuk pembatalan:
> `docs/FASA-C-REKOD.md`.
>
> **Awalan rekod DISAHKAN `PGP02`**, bukan PGP03. PGP03 memang wujud —
> tetapi pada notis sisi **server** yang dimuat turun ke peranti, bukan
> pada rekod yang peranti ini jana.

## Keadaan semasa (2026-08-17)

| | |
|---|---|
| Rekod production | 3 — lihat `docs/FASA-C-REKOD.md` |
| Kuota izin | `IZIN-E2E.txt`: kunci DIBUANG 2026-08-14, kuota 9999 (kaunter audit) |
| Ujian gerbang | **762 hijau** |
| Kerja device | **BERHENTI** — menunggu kelulusan bendera mod sebenar |

### MOD SEBENAR TERKAWAL — DIBINA, BENDERA MATI

Keputusan pemilik 2026-08-17 (PROMPT 6). Laporan penuh:
**`reports/LAPORAN-PROMPT-6.md`** — mula di situ.

`MBPG_MOD_SEBENAR`, lalai `0`. Bila HIDUP, ia membenarkan
SERAH/HANTAR/SAHKAN/YA/OK/KEMASKINI/CETAK **hanya** dalam konteks skrin
yang disahkan secara STRUKTUR daripada tajuk app-bar (borang N/P/K-001
dan aliran turunannya). Ia BUKAN suis "matikan corong":

- `PADAM`, `HAPUS`, `SELARAS MAKLUMAT PELESEN` = larangan MUTLAK,
  diperiksa SEBELUM senarai butang.
- `SIMPAN` tidak disentuh — kekal pada dua pengecualian berstrukturnya.
- Bendera MATI = kelakuan IDENTIK dengan sebelum ini (diuji: matriks
  keputusan penuh dinilai dua kali dan dibandingkan).
- 11 dump forensik pelanggaran sebenar dijalankan semula melalui
  pengesan konteks — tiada satu pun dibuka.

Sokongan: `testdata/penanda_ujian.py` (penanda data ujian untuk cleanup
PM), `tools/rekod_log.py` (log nombor rekod, ditulis serta-merta).

```
python tools/run_e2e.py --borang N --mod-sebenar --kitaran penuh
```

**Belum pernah dijalankan.** Menunggu kelulusan pemilik.

### K-001 mySIKAP — locator dibetulkan 2026-08-17

Objek halaman masih membawa `ImageView.instance(0)` sehingga hari ini —
ImageView PERTAMA pada skrin, yang lulus hanya kerana borang ini
kebetulan mempunyai tepat satu. Kawalan 66px di kirinya ialah **ePBT**,
yang memadam data.

Diganti dengan `pages/daftar_kompaun_page.cari_mysikap_dari_xml()` —
fungsi TULEN, disauh pada ePBT secara struktur, dikongsi oleh objek
halaman DAN `peringkat6._cari_mysikap()`. Padanan bukan tepat satu →
`None`, tiada tekaan. 28 ujian gerbang.

### JANGAN buat sendiri

- **Benchmark peringkat menu** (`tools/run_e2e_menu.py --peringkat
  senarai,hantar,tarik`) — **pemilik jalankan sendiri** di luar sesi.
  Jangan run. Kalau pemilik tampal output, analisis sahaja.
- **Recon lanjutan NK** — tekan `[KOMPAUN]` dan buka borang penukaran
  perlukan **kelulusan pemilik + PM berasingan**. JANGAN buat sendiri
  **walaupun selepas 2026-08-27**.
- Sebarang run cipta-rekod. Kuota wujud kerana pemilik merancang
  menggunakannya, bukan kerana ia dibenarkan sekarang.

### NK menunggu 2026-08-27

Dialog tarik bertajuk **`TARIK NOTIS TAMAT TEMPOH`** — ia menarik notis
**luput** sahaja. Notis kita `PGP02N260813006` dan `PGP02N260813007`
bertempoh 14 hari dari 2026-08-13, jadi keduanya layak ditukar pada
**2026-08-27**. Tarikan sebelum itu memulangkan sifar hasil.

Dapatan penuh: `docs/recon/DAPATAN-NK.md`.

---

## 0. TANGAN-OVER — baca ini dahulu

### Apa yang SIAP

| Kerja | Status |
|---|---|
| KERJA 1 — setup repo | SIAP |
| KERJA 2 — dry-run guard (corong tap) | SIAP — terbukti pada device, 1400+ tap |
| KERJA 3 — skop 49 TC | SIAP (`testdata/skop.py`) |
| KERJA 3B — sistem set kombo | SIAP — 428 fail set dari DB production, generator idempoten |
| KERJA 4 — tangga smoke peringkat 1–5 | SIAP — N-001 LULUS PENUH |
| KERJA 5 — peringkat 6 (skop penuh) | SIAP — lihat `reports/LAPORAN-49-TC.md` |
| Pengesahan laluan sweep (pathfinder) | SIAP — laluan disahkan, masa diukur |
| **Ujian gerbang offline** | **249 hijau** (`python -m pytest tests_offline -q`) |

> **LAPORAN AKHIR FASA 1+2: `reports/LAPORAN-AKHIR-FASA-1-2.md`**
> Mula di situ. Ia meliputi 49 TC, MATRIX 284, defek D-01..D-06,
> beza staging-vs-production, dan bahagian APA YANG TIDAK TERBUKTI.

Butiran setiap TC: **`reports/LAPORAN-49-TC.md`**.

### Dasar tripwire (keputusan pemilik 2026-08-12)

* Positif palsu pada **teks data** (baris dropdown, keterangan
  kesalahan) → baiki corak + tambah gerbang → **sambung**.
* **Butang tripwire sebenar** (SERAH/HANTAR/SIMPAN luar konteks/YA/
  OK/SAHKAN/KEMASKINI) → **HENTI KERAS**, forensik, tunggu pemilik.
* Pembetulan mesti MENYEMPITKAN corak, bukan meluaskan pengecualian.

### Fasa C — DIBINA, BERKUNCI MATI

Spec: `docs/SPEC-FASA-C-E2E-MBPG.md`. Laluan **sudah dibina** tetapi
**tidak boleh menyerah**. Enam kunci berasingan, setiap satu lalai
kepada DISEKAT:

| # | Kunci | Lalai | Fail |
|---|---|---|---|
| 1 | `MBPG_DRY_RUN == "0"` (padanan TEPAT, tiada pangkas) | `"1"` | `guard/gerbang_serah.py` |
| 2 | `MBPG_IZIN_SERAH` + medan `ISI-SINI` diisi tangan | kosong | `guard/gerbang_serah.py` |
| 3 | `set_id` dalam whitelist | **KOSONG** | `fasa_c_izin.json` (tiada) |
| 4 | kiraan < had N | **N=0** | `fasa_c_izin.json` (tiada) |
| 5 | pengesahan manusia per-serah, **TTY wajib** | — | `guard/sahkan_manual.py` |
| 6 | corong tap — SERAH/HANTAR kekal trip-wire | — | `guard/corong.py` |

```
python devtools/fasa_c.py --diagnosis      # papar keadaan setiap kunci
```

* `fasa_c_izin.json` **tiada dalam repo** dan digitignore. Templat
  `fasa_c_izin.contoh.json` dijejaki dan **tidak memberi apa-apa** —
  medannya masih `ISI-SINI`, yang dikesan dan ditolak.
* Printer: `pages/printer_tsc.py` membina **payload sahaja**;
  `hantar()` sentiasa membangkitkan `PayloadTerkunci`.
* `reports/LEDGER-E2E.jsonl` wujud dan **kosong**. Satu baris di
  dalamnya bermakna rekod sebenar telah dicipta.
* Ketukan butang SERAH sendiri **belum ditulis**, dengan sengaja —
  ia dibina di bawah gerbang bila kelulusan wujud, bukan sebelum.

**60 ujian gerbang** menguatkuasakan ini. Jangan sentuh mana-mana
laluan serah / create / print tanpa kelulusan bertulis PM + MBPG.

**12 TC LULUS**: T-001, T-002, T-003, T-005, T-006, T-007, T-009,
T-010, T-011, N-001, P-001, K-001. Daripada 18 TC dalam skop teknikal
fasa 1, tiada satu pun daripada baki 6 gagal atas kelemahan skrip.

Bukti misi: **1556 tap dinilai corong, 10 disekat (semuanya positif
palsu yang disiasat), 28 relaunch pemulihan, 0 rekod dicipta.**

### Apa yang DITANGGUH — JANGAN MULA TANPA ARAHAN BARU

> **SWEEP 284 SET = SELESAI 2026-08-12. 280/284 LULUS (98.6%).**
> MATRIX: `reports/MATRIX-20260812.csv`. 0 rekod dicipta.
> Jalankan semula dengan `python devtools/sweep_penuh.py`
> (menyambung dari CSV; `--had N` untuk ujian pendek).
>
> 4 gagal: tiga berkongsi kesalahan **148** (baca-balik selepas modal
> ditutup; bukan isu panjang teks — kesalahan 111 lebih panjang dan
> lulus), satu set K berjana-ID. Belum dicirikan.
>
> Butiran penuh + dua pembetulan yang sweep dedahkan (trip-wire
> `\bSIMPAN\b`, klasifikasi set negatif) ada dalam LAPORAN-49-TC.md.

---

### Nota sejarah — sebelum sweep diluluskan

> **SWEEP 284 SET = DITANGGUH. Jangan mula tanpa arahan baru.**
>
> Diluluskan 2026-08-11, kemudian DITANGGUH pada hari yang sama
> (pemilik tutup lid). Akan dimulakan semula atas arahan pemilik
> dari rumah, selepas dia restart Appium + sahkan adb device.
>
> **Semuanya sudah sedia — tiada kerja tertunggak:**
> - Laluan disahkan: laluan A (lompat terus) DISEKAT oleh gerbang
>   urutan tab; laluan B (isi Pesalah minimum + sauh alamat
>   berposkod) BERFUNGSI.
> - Tatalan modal dropdown DIBAIKI (`_skrol_modal`) — set yang gagal
>   dua kali kini lulus ketiga-tiga tingkat.
> - Bacaan kadar denda DIBAIKI + semakan silang julat app-lawan-DB.
> - Anggaran diukur: **~110-137s/set → 9-11 jam** untuk 284 set.
>   (Angka 2.3 jam yang lebih awal ialah masa GAGAL-CEPAT — jangan
>   guna.)
>
> Yang belum wujud: pelari sweep dengan MATRIX CSV + fsync
> setiap baris + resume. Itu kerja pertama bila sweep dimulakan.

> **E2E create / print / submit = FASA 3**, menunggu kelulusan
> pemilik DAN PM. Gerbang `MBPG_IZIN_SERAH` **kekal berkunci**;
> `MBPG_DRY_RUN=1` dan `MBPG_BENARKAN_SERAH=0` kekal lalai.
> Trip-wire HANTAR / YA / OK / SAHKAN kekal aktif dalam SEMUA mod.

> **SELARAS PELESEN (T-008) kekal HARAM** — sync 3–4 jam, 52,317
> rekod. Dikuatkuasakan pada lapisan tap, bukan sekadar dilangkau.

### Defek yang dijumpai (untuk pasukan app)

| ID | Ringkasan | Dokumen |
|---|---|---|
| D-01 | Selaras Alamat tidak idempotent — `Duplicate entry`, app ranap pada sync kedua | `docs/DEFEK-MBPG-2.1.21.md` |
| D-02 | Internal IP tidak kekal — read-back mengesahkan nilai yang app buang | `docs/DEFEK-MBPG-2.1.21.md` |
| D-03 | 1276/3493 (36.5%) rekod jalan tiada poskod → borang Kompaun tersekat | `docs/D-03-POSKOD-KOSONG.md` |
| D-04 | Tiada UI untuk MENCIPTA bookmark pada 2.1.21 | `docs/D-04-BOOKMARK-TIADA-UI-CIPTA.md` |
| D-05 | Plat dicerminkan ke Nama Pesalah + No K/P/SSM pada borang Letak Kereta | `docs/D-05-EPBT-DAN-CERMIN-PLAT.md` |

### Perintah harian

```
python -m pytest tests_offline -q                      # gerbang, tanpa device
python tools/jana_set.py --semak                       # set kombo idempoten
python devtools/smoke_tangga.py --sampai 6 --langkau-selaras
```

---

## 2. Corong tap — reka bentuk

Masalah: kod `pages/` yang diwarisi ada **64 tapak panggilan tap mentah**
merentas tiga primitif (`el.click()`, `driver.tap()`, `mobile: clickGesture`),
ditambah ActionChains dan `press_keycode`. Menampal setiap satu bermakna 64
peluang terlepas, dan suntingan esok menambah yang ke-65 tanpa perlindungan.

Penyelesaian: **jangan tampal tapak panggilan — bungkus objek.**
`guard/corong.pasang(driver)` dipasang sekali dalam `tests/conftest.py`
sejurus selepas `webdriver.Remote()`. Selepas titik itu tiada kod ujian
memegang sesi Appium yang tidak berkawal, dan setiap `WebElement` yang
diagihkan dibungkus semula.

Laluan yang dipintas:

| Laluan | Cara |
|---|---|
| `el.click()` | `ElemenBerkawal.click` |
| `driver.tap([(x,y)])` | ujian-kena koordinat pada XML skrin |
| `mobile: clickGesture` | `execute_script` (elemen atau koordinat) |
| `ActionChains` (tandatangan) | `driver.execute("actions", …)` — pointerDown/Up |
| `press_keycode(ENTER)` | dinilai terhadap elemen berfokus, **gagal-tertutup** |
| `driver.swipe` degenerat | mula == tamat = ketukan |
| `adb shell input swipe` | `device_utils.measure_scroll` menolak kes degenerat |

### Dua keputusan yang perlu difahami sebelum menyunting

**`DryRunViolation` mewarisi `BaseException`, bukan `Exception`.**
`pages/base_page.py` ada **66 blok `except Exception`** dan setiap gelung
cuba-semula dibina di atasnya (`wait_and_tap` ×3, `dismiss_native_alerts` ×6,
`kemaskini.proceed_and_submit` 4 pusingan). Kalau pelanggaran ialah
`Exception`, gelung itu menelannya dan mencuba lagi — gerbang menyekat setiap
percubaan dengan betul sementara run meneruskan seolah-olah tiada apa berlaku.
`AssertionError` pun tidak memadai (2 tapak menangkapnya). Diuji oleh
`test_pelanggaran_tidak_boleh_ditelan`.

**Dua pengecualian SIMPAN, kedua-duanya disahkan secara STRUKTUR.**
SIMPAN disekat di mana-mana KECUALI (a) dialog nama bookmark, (b) skrin
Tetapan (T-001/T-002/T-010 — keputusan pemilik 2026-08-07: ia menulis config
LOKAL device, bukan rekod production). Skrin Tetapan dikenali melalui
resource-id `text-input-outlined` **digandingkan** dengan label sauh skrin
(`INTERNAL IP ADDRESS` / `EXTERNAL IP ADDRESS` / `LESEN APLIKASI`), atau tajuk
`PILIHAN SKRIN UTAMA` untuk T-010. Gandingan itu perlu: skrin **login** juga
guna `text-input-outlined` dan kekal dirender di belakang modal Tetapan, jadi
id sahaja akan membuka SIMPAN sepanjang masa. Konteks dikira di **satu**
tempat (`_konteks_simpan`) supaya lima laluan tap tidak menyimpang.

**Konteks bookmark diuji secara STRUKTUR, bukan subrentetan.**
Semakan naif "ada 'Pilihan Kegemaran' + ada EditText" memulangkan True pada
**seluruh borang Daftar Kompaun**, kerana ikon buku hidup pada borang dan
borang Pesalah membawa EditText sendiri. Itu akan membuka SIMPAN di mana-mana.
Semakan sebenar: tajuk + bekas `modal-surface` + EditText **di dalam**
modal-surface paling dalam. Diuji oleh
`test_borang_dengan_ikon_buku_bukan_dialog_bookmark`.

### Bukti setiap run

`reports/tap_ledger.jsonl` — setiap tap: teks sasaran, peraturan, benarkan/sekat.
`reports/forensik/` — pada pelanggaran: PNG + XML + surih tindanan.

---

## 3. Bendera

| Bendera | Lalai | Kesan |
|---|---|---|
| `MBPG_DRY_RUN` | `1` | Corong aktif. `0` sahaja TIDAK cukup — perlu `MBPG_IZIN_SERAH=1` juga. |
| `MBPG_BENARKAN_SERAH` | `0` | `1` = SERAH dibenarkan **sekali per TC**, wajib diikuti screenshot popup + BATAL/TIDAK/back. |
| `MBPG_IZIN_SERAH` | `0` | Kunci kedua. |
| `MBPG_IZIN_PRODUCTION` | — | Wajib `1` untuk memuatkan profil. |
| `MBPG_MOD_SEBENAR` | `0` | `1` = mutasi dibenarkan dalam konteks skrin yang disahkan berstruktur. Lihat bahagian "MOD SEBENAR" di atas. |

**Trip-wire.** Sebelum 2026-08-17, senarai ini tidak boleh dibuka oleh
mana-mana bendera: `HANTAR`, `HANTAR SEMULA`, `YA`, `OK`, `SAHKAN`,
`KEMASKINI`, `PADAM`, `HAPUS`, `CETAK`, dan `SELARAS MAKLUMAT PELESEN`.

`MBPG_MOD_SEBENAR=1` kini boleh membuka sebahagian daripadanya —
**tetapi hanya dalam konteks skrin yang disahkan**, dan tidak pernah
`PADAM` / `HAPUS` / `SELARAS MAKLUMAT PELESEN`. Ketiga-tiga itu kekal
mutlak dalam SEMUA mod.

---

## 4. Apa yang DIUBAH daripada MBJB, dan kenapa

Perkara ini akan kelihatan seperti pepijat kalau dibaca tanpa konteks.

1. **`profile._pagar_pencemaran_mbpg` DIBALIKKAN → `_pagar_pencemaran_mbjb`.**
   Versi MBJB menolak token MBPG (satu lesen tertentu + akaun `user3`) sebagai
   "pencemaran MBPG". Di sini MBPG ialah PBT yang sah — gerbang asal akan
   menyebabkan **setiap profil MBPG yang betul gagal dimuatkan**. Digit lesen
   warisan itu sengaja tidak disebut di mana-mana dalam repo ini (arahan
   pemilik) supaya ia tidak boleh tersalah salin; lesen rasmi ada dalam profil.
2. **Gerbang IP tidak lagi MENULIS.** MBJB membetulkan IP secara automatik
   (taip + SIMPAN) sebelum test pertama; itu selamat di sana kerana nilai yang
   ditulis ialah staging. Di sini nilai yang sama IALAH production. Sekarang ia
   berhenti dan meminta pembetulan manual.
3. **`_imbas_petanda_production` gagal-TERBUKA → gagal-TERTUTUP.** Ia
   memulangkan `False` pada sebarang ralat adb. Dengan polariti terbalik,
   maksudnya menjadi "tidak dapat sahkan server — teruskan sahaja" pada
   production. Kini tiga keadaan; "tidak dapat sahkan" = BERHENTI.
4. **`drain_printer_alert()` dilumpuhkan (sentiasa `False`).** Ia menekan
   butang **OK** asli — trip-wire. 19 tapak panggilan dikekalkan sebagai
   penyalir generik yang kini tidak berbuat apa-apa.
5. **Regex kutipan `test_mbjb_tc_` → `test_mbpg_tc_`.** Kalau tertinggal,
   `results.json` ditulis sebagai semua-`NOT RUN` secara senyap.
6. **Data ujian MBJB TIDAK dibawa masuk.** `excel_data.py`/`overrides.py`
   dialih ke `docs/rujukan-mbjb/*.ref` (tidak boleh diimport). Membawanya masuk
   ialah perangkap data-palsu yang `config.py` sendiri beri amaran.
7. **Komen yang menyebut "MBJB" DIKEKALKAN dengan sengaja.** Ia merekod
   pemerhatian pada MBJB. Menukarnya kepada "MBPG" akan mereka-cipta
   pengesahan yang kita tidak ada.

---

## 5. Isu terbuka — perlu keputusan pemilik

**(a) ~~T-001 / T-002 vs peraturan SIMPAN~~ — SELESAI 2026-08-07.**
Pemilik membenarkan SIMPAN dalam konteks Tetapan sahaja (config lokal device,
bukan rekod production). Dilaksanakan sebagai pengecualian berstruktur kedua
dalam corong. Aliran sekarang:
- **T-001** masuk semula IP yang **sama** (113.211.155.174) + SIMPAN. Tiada
  nilai beralih, jadi tiada restore diperlukan.
- **T-002** baca asal → ubah satu digit → SIMPAN → verify → **restore** →
  SIMPAN. Restore berada dalam `finally`, dan kegagalannya membangkitkan
  `RestoreGagal` (BaseException, tidak boleh ditelan) yang melaporkan nilai
  asal dan nilai ujian yang mungkin tertinggal.
- **T-010** pilih DEFAULT supaya skrin pendaratan app tidak berubah.

**(b) N-003 — sheet oracle bercanggah dengan arahan pemilik.**
Sheet `MBPG-TC-N-003` bertajuk **"Serah Notis Amaran"**, expected result
"Application accepts the attachment" — iaitu lampirkan gambar kepada notis yang
**sudah wujud**. Klasifikasi pemilik pula kata lakukan dalam borang N-001.
Versi oracle MUSTAHIL di bawah misi ini (perlukan rekod sedia ada, dan
melampir pada rekod production ialah TULISAN kepada rekod itu). Skop yang
dilaksanakan = versi pemilik.

**(c) Sauh JALAN/TAMAN tidak wujud dalam snapshot pemetaan.**
Carian dalam `mbpg-mapping-2026-08-07.json`: `JALAN KALOI 13` = 0,
`TANJONG PUTERI RESORT` = 0, `JALAN LEMBAH 19` = 0, `BANDAR SERI ALAM` = 0.
74 kemunculan "JALAN" semuanya sebahagian **nama akta**. Fail itu hanya
pemetaan kompaun 3 tingkat (25 kod / 34 akta / 146 kesalahan), tiada senarai
alamat. Ia juga dari `epbtstaging.mbpg.gov.my` — **staging**, bukan sasaran kita.
→ Senarai jalan mesti datang dari **T-004 pada device**, disnapshot ke
`data/snapshot-YYYYMMDD/`. Sebelum itu wujud, N/P/K-001 tidak boleh naik
kepada padanan dua-sauh.

**(d) ~~`lesen_aplikasi` belum diketahui~~ — SELESAI 2026-08-07.**
Nilai rasmi pemilik diisi; profil kini dimuat penuh. Calon warisan dibuang
sepenuhnya **termasuk digitnya**, atas arahan pemilik, supaya ia tidak boleh
tersalah salin.

Yang kekal terbuka: **(b)** dan **(c)** sahaja.

---

## 6. Skop — 49 TC

| Kategori | Bil |
|---|---|
| Runnable penuh | 11 (T-001..T-007, T-009..T-012) |
| Partial fill-only | 7 (N/P/K-001, N-003, N/P/K-005) |
| Skip-guard | 18 |
| Skip luar skop | 12 (L, S, H-004, H-005) |
| Skip arahan pemilik | 1 (**T-008 Selaras Pelesen**) |

**T-008 (Selaras Pelesen) — exclude total, TIGA lapisan.** Sync 3-4 JAM;
pemilik menegaskan semula 2026-08-07. Satu lapisan tidak mencukupi untuk
sesuatu yang kosnya sehari kerja:
1. Dibuang terus daripada senarai langkah `pelarasan_results` — bukan sekadar
   digerbang env var, kerana satu env var yang tertinggal sudah cukup.
2. `pelarasan_page.selaras_maklumat_pelesen()` melempar `NotImplementedError`.
3. Corong menyekat mana-mana ketukan yang teksnya memadan item menu itu
   (peraturan `SELARAS-PELESEN`) — jadi ketukan tersasar pun tidak sampai.

Tiada laluan **"selaras semua"**: `run_full_pelarasan()` dilumpuhkan (ia
menjalankan urutan sebagai satu blok dan menekan SIMPAN tanpa restore), dan
ujian `test_tiada_laluan_selaras_semua` menguatkuasakan tiada fungsi lain
menjalankan >1 modul selaras dalam satu panggilan. Enam modul yang dibenarkan
ditekan **satu per satu**.

Perangkap workbook yang direkod dalam `testdata/skop.py`: 10 nama sheet ada
ruang di hujung; sel C3 bercanggah dengan nama sheet pada 6 sheet (kunci pada
**nama sheet**, jangan pada C3); `MBPG-TC-P-006` tersembunyi;
`MBPG-TC-N-006` **tidak wujud** (ia hanya C3 tersalah taip dalam sheet P-006).

---

## 7. Langkah seterusnya (selepas kelulusan)

1. Pemilik isi `lesen_aplikasi` dalam `profiles/mbpg-production.json`.
2. Sahkan device + app v2.1.20 + IP tetapan.
3. Login msc → main menu.
4. T-003 → T-004 (snapshot jalan) → T-005 (snapshot kod).
5. Semak sauh N-001 wujud dalam snapshot. Kalau tidak → cetak semua baris,
   **TUNGGU keputusan pemilik**.
6. N-001 fill-only + read-back + back out + post-check senarai.
7. Baru luaskan ke P-001, K-001, dan T yang lain.

---

## 8. Sistem set kombo (KERJA 3B)

Satu SET = satu kombinasi (kod kompaun x akta x kesalahan).
Sumber: `testdata/mapping/mbpg-mapping-2026-08-07.json` (salinan, jangan edit).

```
python tools/jana_set.py            # jana semula
python tools/jana_set.py --semak    # gagal kalau output akan berubah
```

| Ukuran | Bil |
|---|---|
| Set laluan-penuh | **411** |
| ...dalam skop (PELBAGAI 256 + LETAK KERETA 74) | **330** |
| ...luar skop (LESEN) | **81** |
| Set negatif `JANGKA_KOSONG` | 10 |
| Set negatif `JANGKA_MATI_T3` | 5 |
| **Jumlah fail** | **426** + `INDEX.md` |

Pemuat TIDAK memuatkan set LESEN langsung — `--kk 02` yang tersilap taip
tidak boleh memandu 81 set luar skop.

### Pemilihan (wajib eksplisit)

```
pytest tests/menu_pelbagai --kk 01                    97 set
pytest tests/menu_letak_kereta --kk 03                74 set
pytest tests/menu_pelbagai --set SET-KK01-AKT3-107     1 set
pytest tests/menu_pelbagai --borang P                265 set
pytest tests/menu_pelbagai --kk 01 --jangkaan BOLEH_GUNA
pytest tests/menu_notis --kk 01 --n-penuh
```

**Tanpa flag = 0 set** (disahkan: 3 skipped, fixture device tidak pernah
dibina). Skop lalai: P penuh, K penuh, N sampel 26 merentas 26 pasangan
(kod, akta) BERLAINAN — bukan 26 pertama mengikut abjad, yang semuanya
jatuh di bawah satu atau dua akta.

Set gagal dicatat ke `reports/MATRIX-<tarikh>.csv` dan sweep TERUSKAN —
ia pengumpul bukti, bukan gerbang lulus/gagal. CSV ditulis + `fsync` per
baris supaya batal pada set ke-200 tidak membuang 199 yang pertama.
Hanya `DryRunViolation` / `RestoreGagal` yang membatalkan run.

### Percanggahan dengan ringkasan arahan — data yang menang

- **Kod tanpa akta**: arahan menamakan 4; mapping mengandungi **10**
  (tambahan: `1001, KPKL, KPP, PLS 01, T001, T003`).
- **Akta tanpa kesalahan**: arahan menamakan kod 06 sahaja; mapping
  mengandungi **5** pasangan (tambahan: kod 01 akta 91 & 92, kod 05
  akta 93, kod KPBT akta ACT2026000002).

Generator mengira dari mapping. Mengekodkan senarai pendek dalam arahan
akan menyembunyikan bakinya daripada sweep.

### AMBIGU lebih luas daripada dijangka

130 daripada 411 set ditanda `AMBIGU`, termasuk **29 daripada 74 set
LETAK KERETA** — kerana kod 03 berada di bawah `AKTA 171 - AKTA KERAJAAN
TEMPATAN 1976`, nama yang berulang (id `2` dan `ACT2025000005`).
Kesalahan disambung ikut **nama** akta, bukan id, jadi kedua-duanya
berkongsi senarai yang sama dan mapping tidak dapat memberitahu yang
mana betul. Apa yang app papar ialah jawapannya.

### Contoh PM disahkan sebagai tiada dalam mapping

`SEK 46 (1)(d)` dan `SEK 47` memang wujud — tetapi di bawah **AKTA JALAN
PARIT DAN BANGUNAN 1974**, bukan di bawah **PERINTAH LALULINTAS JALAN
(PMTLK) MPPG 2001** seperti dalam contoh PM. Kalau app membenarkan kombo
PMTLK itu semasa sweep, itu DAPATAN dan mesti direkod jelas dalam MATRIX.

### Halangan terbuka: sweep N

Pada borang N, tiga dropdown berada pada tab **NOTIS**, di sebalik tab
PESALAH + butang SETERUSNYA. Kalau SETERUSNYA mengesahkan medan Pesalah
wajib, sweep N "tanpa isi pesalah" MUSTAHIL. Belum diketahui — hanya
device boleh menjawabnya. Kod mencuba laluan itu SEKALI dan melangkau
baki set N dengan sebab yang menamakan keputusan yang diperlukan, bukan
26 kegagalan serupa. Borang P tidak mempunyai masalah ini (dropdown pada
tab pertama), jadi sweep P kekal sasaran utama.


---

## 9. VERSI APP — KEPUTUSAN RASMI (2026-08-07)

> **Oracle ditulis untuk v2.1.20. App pada peranti ialah v2.1.21.**
> **Pemilik memutuskan: TERUSKAN dengan 2.1.21.**

Setiap keputusan test dalam projek ini ditanda **versi 2.1.21**. Kalau
mana-mana kelakuan berbeza daripada yang oracle jangkakan, **beza versi
mesti dipertimbangkan sebagai punca yang mungkin** sebelum ia dilaporkan
sebagai pepijat.

- Oracle: `IES-MBPG Testing Script V2.1.20_PRODUCTION.xlsx`, 49/49 sheet
  merekod Version = 2.1.20.
- Peranti: `versionName=2.1.21`, dipasang 2026-08-06 17:23.
- Tiada APK MBPG dijumpai pada cakera mesin ini, jadi 2.1.20 tidak boleh
  dipasang semula.
- `device_utils.py --check` melaporkan ini sebagai `[GAGAL]` dengan exit
  1. Itu disengajakan — gerbang versi asal mencetak `[OK]` sambil
  menyebut dua nombor berbeza.

---

## 10. Penemuan device: mapping STAGING != production

DB rujukan tempatan app (`e_kompaunV1.db`, disnapshot baca-sahaja ke
`data/snapshot-YYYYMMDD/`) berbeza secara material daripada snapshot
pemetaan portal yang 411 set asal dibina atasnya.

| | Staging (mapping) | Production (DB peranti) |
|---|---|---|
| kod kompaun | 25 | **9** |
| akta | 34 | **23** |
| kesalahan | 146 | **120** |
| set laluan-penuh | 411 | **420** |
| dalam skop | 330 | **279** |

- **19 daripada 25** kod mapping tiada pada production (kebanyakannya
  data ujian portal: `T001`-`T007`, `KA01`, `100`, `1050`).
- **3 kod production tiada dalam mapping**: `08` JPLS, `09` JPLS lesen,
  `10` JBGN — tidak akan pernah diuji kalau sweep dibina dari mapping.
- **4 daripada 6** kod yang dikongsi mempunyai **teks paparan berbeza**
  (production `KOMPAUN PELBAGAI JP` vs mapping `KOMPAUN PELBAGAI`).
  Sweep memilih tingkat 1 mengikut teks, jadi ini sahaja sudah cukup
  untuk menggagalkan hampir setiap set.
- **Tiada nama akta berulang** pada production → kategori `AMBIGU`
  (130 set staging, termasuk 29 daripada 74 LETAK KERETA) **lenyap**.
- **44 rujukan akta tergantung** dalam jadual pautan DB (id tanpa baris
  akta) + **2 fk_akta yatim** — direkod dalam INDEX, tiada fail set
  kerana tiada nama untuk dipilih pada dropdown.
- DB membawa kadar denda; **`amounnotis` = 0 pada kesemua 120**, jadi
  `amounmin`/`amounmax` yang bermakna.

Set kini dijana dari **DB production** (`tools/jana_set.py --sumber db`,
lalai). Set staging diarkib ke `testdata/sets-staging/` untuk rujukan
silang dan TIDAK boleh dimuatkan oleh sweep. Laporan penuh:
`testdata/sets/BEZA-STAGING-VS-PRODUCTION.md`.

---

## 11. Gerbang IP lapisan 3 — laluan bukti DB

Keputusan pemilik 2026-08-07. Bila skrin login tidak tercapai (sesi
`no_reset=True` masih aktif), gerbang menerima
`local_connection_details.ip_address` sebagai bukti device.

Kenapa ini bukan pelonggaran:
- Ia tetapan itu sendiri; skrin Tetapan cuma memaparkan nilai yang sama.
- Premis MBJB yang mewajarkan laluan-skrin-sahaja ("IP tidak kekal
  merentas restart app") **diuji dan TERBUKTI SALAH untuk MBPG**: selepas
  6 back-press + `driver.quit()`, nilai kekal `113.211.155.174`.
- Ia baca-sahaja.

**Log keluar TIDAK dilakukan** — butang YA ialah trip-wire, jadi suite
secara struktur tidak boleh log keluar. Laluan log-keluar MBJB dibuang.

**T-012 diverifikasi melalui persistence**, bukan aliran login penuh:
sesi bertahan merentas `activate_app()`. Kaedah ini direkod dalam
`_RUN_META["t012_kaedah"]`.


---

## 12. Penemuan device 2026-08-10 — locator MBJB tidak padan MBPG 2.1.21

Tiga pepijat locator ditemui pada device, semuanya kelas yang SAMA:
`UiSelector().text()` dan `.textContains()` PEKA HURUF, dan MBPG 2.1.21
memaparkan **Title Case** sedangkan MBJB memaparkan HURUF BESAR.

| Locator | MBJB jangka | MBPG 2.1.21 sebenar |
|---|---|---|
| `login_page.APP_TITLE` | `APLIKASI KOMPAUN e-PBT` | `Aplikasi Kompaun e-PBT` |
| `pelarasan_page.LOGIN_SCREEN_TITLE` | sama | sama |
| Semua 11 item Menu Selaras | `TETAPAN ALAMAT IP` dll | `Tetapan Alamat IP` dll |

Kesannya bukan kosmetik:
- `is_login_screen_displayed()` memulangkan **False pada skrin login
  sebenar** — skrin yang jelas memaparkan `Login`, `Remember Me`, dan
  username `msc`. Gerbang IP lalu menyimpulkan "app sudah log masuk".
- Setiap item Menu Selaras tidak dapat dijumpai.

Dua perangkap tambahan dari recon yang sama:
- App mengeja **"Selaras Penguna Apps"** dengan SATU `g`. Padanan
  tidak-peka-huruf sahaja masih gagal; corak kini menerima kedua-dua
  ejaan.
- Item kemaskini ialah **"Semak Kemaskini Versi Terkini"**, bukan
  `SEMAK KEMASKINI`.

Semua kini `textMatches("(?i)...")`. Alat: `devtools/recon_skrin.py`
(baca-sahaja, memaparkan glif ikon sebagai `U+XXXX` — MBPG dan MBJB
memakai codepoint BERBEZA untuk ikon yang sama).

### Positif palsu corong — dibetulkan, dengan regresi

Menutup modal Menu Selaras mengetuk backdrop pada `(540,2076)`. Corong
menyekatnya sebagai pelanggaran **KEMASKINI**, kerana ia memungut teks
daripada SEMUA keturunan node terdalam — dan backdrop skrin-penuh
"mengandungi" setiap item menu, termasuk `Semak Kemaskini Versi Terkini`.

Item menu itu berada pada y 669..1761; tap pada y=2076. Ia tidak pernah
di bawah tap itu. `teks_di_koordinat()` kini memungut hanya daripada node
yang **mengandungi titik**, jadi hasilnya `['Close modal']`.

Ini menjadikan corong LEBIH tepat, bukan lebih longgar — disahkan oleh
empat ujian regresi yang dibina daripada XML device sebenar: backdrop
dibenarkan, tetapi mengetuk baris **Selaras Maklumat Pelesen** dan
**Semak Kemaskini** yang SEBENAR masih disekat.

---

## 13. Keputusan tangga smoke pada device (2026-08-10)

| Langkah | Hasil |
|---|---|
| 1 device / app / IP / baseline | **LULUS** (versi 2.1.21, diterima pemilik) |
| 2 login -> skrin utama (T-012) | **LULUS** — aliran login penuh |
| T-001 Tetapan Alamat IP | **LULUS** — lihat dapatan di bawah |
| T-003 Selaras Pengguna Apps | **LULUS** |
| T-004 Selaras Maklumat Alamat | **TIDAK STABIL** — lulus sekali, gagal sekali |
| T-005 Selaras Maklumat Kompaun | sync berjaya; belum lulus hujung-ke-hujung |
| 4 checkpoint sauh | LULUS (dari DB) |
| 5 N-001 fill-only | **BELUM DICAPAI** |

Post-check sepanjang SEMUA run: **0 notis / 0 kompaun / 0 sita / 0 bookmark**,
kaunter siri tidak berubah. Tiada rekod dicipta.

Ledger corong keseluruhan: **149 tap dinilai, 5 disekat** — kesemua
sekatan itu positif palsu yang kemudiannya dibetulkan (lihat 12).

### DAPATAN: medan Internal IP TIDAK KEKAL

T-001 berjaya sepenuhnya setiap kali:
```
SEBELUM : internal=''                 external='113.211.155.174'
SIMPAN  : dibenarkan (konteks Tetapan)
SELEPAS : internal='113.211.155.174'  external='113.211.155.174'  (read-back skrin)
DB      : [('113.211.155.174','Ext')]
```
Tetapi **DUA run berikutnya membaca `internal=''` semula** pada permulaan.
Nilai itu diterima, dipapar, dan disahkan baca-balik — kemudian hilang
selepas app dimulakan semula.

`local_connection_details` hanya membawa SATU baris, `status='Ext'`.
Hipotesis: app menyimpan satu alamat sahaja (External) dan medan Internal
tidak pernah dipersist. Kehendak pemilik ("kekal terisi") TIDAK tercapai —
bukan kerana skrip, tetapi kerana app. Ini calon defek.

### T-004 tidak stabil

Corak MBJB yang diketahui berulang di sini: alert keputusan Selaras tiba
LEWAT. Pada run terakhir, alert `Data Kompaun Berjaya Disimpan!` dari run
SEBELUMNYA muncul semasa gerbang IP. T-004 kemudian melaporkan "no visible
reaction" 3 kali lalu tiada popup keputusan dalam tetingkap menunggu.
Sync itu sendiri nampaknya berjalan; yang tidak stabil ialah pengesanan
mula/tamatnya.

---

## 14. Enjin dropdown pressable RN (2026-08-10)

MBPG 2.1.21 **membuang `android.widget.Spinner`**. Ketiga-tiga tingkat kod
kompaun ialah `ViewGroup clickable` dengan teks placeholder
`-- PILIH ... --`. Enjin MBJB (Spinner + `select_dialog_listview`) tidak
terpakai langsung.

Recon: `docs/recon/dropdown_tier1_terbuka.xml`

| Ciri modal | Fakta |
|---|---|
| Baris | `ViewGroup clickable`, teks = keterangan penuh |
| Bekas | `scrollable=true` |
| Medan carian | TIADA |
| Butang BATAL/TUTUP | TIADA |
| Backdrop | `ViewGroup clickable` skrin-penuh, teks KOSONG |
| Android back | **TIDAK menutup modal** (8 tekanan, kekal terbuka) |

Enjin baharu (`_pilih_melalui_pressable`):
- Elemen dicari SEGAR sebelum setiap tap — tiada cache (pokok RN
  re-render → `StaleElementReferenceException`).
- Modal diisytihar terbuka HANYA bila backdrop hadir. Tanpa syarat itu,
  tiga pressable borang tersilap dikira sebagai baris senarai.
- Placeholder `-- PILIH ... --` ditapis daripada baris.
- Padanan TEPAT, match-or-FAIL. Baris tingkat 3 dirender
  `[<kod>] - <keterangan>`, jadi awalan kurungan-siku dikupas sebelum
  perbandingan penuh — `KOMPAUN PELBAGAI` masih TIDAK memadan
  `KOMPAUN PELBAGAI JP`.
- Penutupan mengetuk BACKDROP, bukan back.
- Baca-balik mencari nilai yang DIPAPAR, bukan placeholder.

Hasil pada production:
```
KETERANGAN KOD KOMPAUN = KOMPAUN LETAK KERETA                     disahkan
KOD AKTA               = PERINTAH LALULINTAS JALAN (PMTLK) MPPG 2001  disahkan
KESALAHAN KOMPAUN      = MELETAKKAN KENDERAAN DIMANA-MANA...      disahkan
```

### Baki merah: read-back `lokasi_kesalahan`

`is_text_visible` hanya melihat viewport; `find_with_scroll` menatal ke
BAWAH sedangkan medan itu di ATAS kedudukan selepas dropdown. Dump device
mengesahkan medan MEMANG terisi (`EditText [107,1238][977,1388]
'DEPAN KEDAI'`). Ini kelemahan ALAT, bukan dapatan app — tetapi ia kekal
merah sehingga read-back menatal dua arah atau membaca nilai medan ikut
label.

---

## 15. N-001 LULUS PENUH (2026-08-10)

```
[OK] borang Notis Amaran terbuka
[OK] tab Pesalah diisi          [OK] read-back Pesalah (5 medan)
[OK] tab Notis diisi            [OK] read-back Notis (2 medan)
[OK] KETERANGAN KOD KOMPAUN = KOMPAUN LETAK KERETA
[OK] KOD AKTA               = PERINTAH LALULINTAS JALAN (PMTLK) MPPG 2001
[OK] KESALAHAN KOMPAUN      = MELETAKKAN KENDERAAN DIMANA-MANA...
[OK] read-back kod kompaun      [OK] read-back akta
[OK] BACK OUT tanpa Serah -> skrin utama
[OK] post-check: 0 rekod, kaunter siri tidak berubah
CORONG: 35 tap dinilai, 0 disekat
```

### Read-back kini DUA ARAH

`find_with_scroll` hanya menatal ke BAWAH. Selepas mengisi borang dan
memilih tiga dropdown, kedudukan skrin berada jauh DI BAWAH medan awal —
jadi mencari 'DEPAN KEDAI' ke bawah tidak akan menjumpainya walaupun ia
terisi. `cari_dua_arah()` memeriksa di sini, naik, kemudian turun
melepasi titik mula. 11 ujian gerbang, termasuk "medan yang memang tiada
→ FAIL betul".

### Borang ini kelas TRAVERSAL-FOKUS

Tiga pra-semakan label gagal secara PALSU sebelum ini difahami:
`is_element_present` hanya melihat viewport; `cari_dua_arah` bergantung
pada swipe, dan borang ini **menolak swipe** (anjakan 0px, diukur
berulang kali). Hanya traversal TAB/DPAD (`_dedah_sebelum_cari`, yang
`pilih_spinner_kod` sudah panggil) menggerakkannya.

Pengajaran yang dikodkan: **jangan pra-semak dengan mekanisme yang lebih
lemah daripada yang sebenarnya digunakan.** Ia hanya boleh menghasilkan
negatif palsu. Pra-semakan itu dibuang.

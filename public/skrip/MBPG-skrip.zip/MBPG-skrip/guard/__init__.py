"""
Gerbang dry-run MBPG.

    from guard import dasar, corong
    driver = corong.pasang(driver_mentah)

`dasar`  — dasar tulen, tiada Appium, boleh diuji unit tanpa peranti.
`corong` — proksi driver/elemen yang menguatkuasakan dasar pada setiap tap.

Baca docstring kedua-dua modul sebelum menyunting apa-apa di sini. Gerbang
ini satu-satunya perkara yang menghalang suite ini daripada mengeluarkan
kompaun sebenar kepada rakyat sebenar.
"""

from .dasar import (           # noqa: F401
    DryRunViolation,
    GuardTidakPasti,
    Keputusan,
    Tetapan,
    konteks_bookmark,
    nilai,
)

__all__ = [
    "DryRunViolation",
    "GuardTidakPasti",
    "Keputusan",
    "Tetapan",
    "konteks_bookmark",
    "nilai",
]

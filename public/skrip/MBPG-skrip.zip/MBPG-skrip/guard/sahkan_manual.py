"""
SAHKAN-PER-SERAH — hook yang WAJIB menunggu manusia.

Spec Fasa C §3: "setiap serah papar ringkasan penuh → pemilik sahkan
secara manual SEBELUM tap pengesahan akhir. Tiada auto-serah pukal."

Masalah dengan hook pengesahan biasa ialah ia gagal-TERBUKA dalam
larian tanpa pengawasan: tiada siapa menaip apa-apa, `input()` melihat
EOF, dan kod menganggap "tiada bantahan" sebagai persetujuan. Modul
ini dibina supaya kes itu MENOLAK.

Tiga syarat, semua wajib:
  1. stdin mesti TTY sebenar. Larian nohup / cron / diarah-semula
     TIDAK mempunyai manusia di hujungnya, dan itu dikesan, bukan
     diandaikan.
  2. Manusia mesti menaip frasa TEPAT yang termasuk set_id. Menekan
     Enter, menaip 'y', atau menampal 'ya' tidak mencukupi — frasa
     mesti khusus kepada rekod yang akan dicipta.
  3. EOF, gangguan, atau frasa salah -> SerahTidakDiizinkan.

Tiada bendera, tiada env var, dan tiada parameter yang memintas ini.
Kalau seseorang perlu automasi, mereka perlu memadam modul ini —
yang kelihatan dalam diff.
"""

import sys

from guard.gerbang_serah import SerahTidakDiizinkan


def frasa_dijangka(set_id):
    """Frasa mesti menyebut set — supaya 'ya' yang ditaip untuk satu
    rekod tidak boleh meluluskan rekod yang berbeza."""
    return f"SAYA SAHKAN SERAH {set_id}"


def papar_ringkasan(ringkasan):
    """Cetak apa yang AKAN dicipta. Setiap medan, tiada pemendekan —
    ini rekod kompaun sebenar terhadap orang sebenar."""
    print("\n" + "=" * 68)
    print("== RINGKASAN SERAH — REKOD SEBENAR AKAN DICIPTA")
    print("=" * 68)
    for k, v in ringkasan.items():
        print(f"  {k:<26}: {v}")
    print("=" * 68)


def sahkan(set_id, ringkasan, stdin=None):
    """Tunggu pengesahan manusia. Pulangkan True, atau bangkitkan.

    TIADA nilai pulangan lain. Fungsi ini tidak pernah memulangkan
    False — laluan penolakan ialah pengecualian, supaya pemanggil yang
    terlupa memeriksa nilai pulangan tetap selamat.
    """
    stdin = sys.stdin if stdin is None else stdin
    papar_ringkasan(ringkasan)

    tty = getattr(stdin, "isatty", lambda: False)()
    if not tty:
        raise SerahTidakDiizinkan(
            "PENGESAHAN MANUAL MUSTAHIL — stdin bukan terminal. Larian "
            "ini tiada manusia di hujungnya (nohup / diarah-semula / "
            "dijadualkan). Serah memerlukan seseorang membacanya dan "
            "menaip pengesahan; ketiadaan bantahan BUKAN persetujuan.")

    jangka = frasa_dijangka(set_id)
    print(f"\n  Taip TEPAT frasa ini untuk meneruskan:\n    {jangka}")
    print("  Apa-apa lain akan membatalkan serah.\n")
    try:
        jawapan = stdin.readline()
    except (EOFError, KeyboardInterrupt):
        raise SerahTidakDiizinkan(
            "PENGESAHAN DIBATALKAN — input ditamatkan sebelum frasa "
            "diterima.")
    if jawapan == "":
        raise SerahTidakDiizinkan(
            "PENGESAHAN DIBATALKAN — EOF pada stdin, tiada frasa "
            "ditaip.")

    if jawapan.strip() != jangka:
        raise SerahTidakDiizinkan(
            f"PENGESAHAN DITOLAK — frasa tidak sepadan. Dijangka "
            f"{jangka!r}, diterima {jawapan.strip()[:60]!r}.")
    print("  Pengesahan diterima.\n")
    return True

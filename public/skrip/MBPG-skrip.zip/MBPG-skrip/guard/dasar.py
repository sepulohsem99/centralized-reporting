"""
DASAR DRY-RUN MBPG — polisi tunggal untuk setiap tap.

KENAPA FAIL INI WUJUD
---------------------
Suite ini berjalan terhadap PRODUCTION Majlis Bandaraya Pasir Gudang
(113.211.155.174). Tiada staging. Misi yang diluluskan pemilik 2026-08-07
ialah: BUAT SCRIPT + VALIDATE FIELD SAHAJA. Tiada rekod PGP02 baharu
dibenarkan wujud selepas run.

Satu tap yang salah pada butang HANTAR mencipta kompaun sebenar dalam
pangkalan data majlis, pada seorang rakyat sebenar. Ia tidak boleh dipadam
dari app. Maka polisi tap BUKAN garis panduan — ia gerbang yang gagal-
tertutup, dan modul ini satu-satunya tempat ia ditakrifkan.

Modul ini TIADA kebergantungan pada Appium dengan sengaja: ia boleh diuji
unit tanpa peranti (lihat tests/test_guard_dasar.py). Lapisan yang
menyambungkannya kepada driver sebenar ada dalam guard/corong.py.

DUA MOD
-------
  MBPG_BENARKAN_SERAH=0  (DEFAULT, keputusan pemilik yang dikunci)
      SERAH turut disekat. Borang diisi, dibaca balik, kemudian BACK OUT.
      Popup validation tidak pernah dicetuskan.

  MBPG_BENARKAN_SERAH=1  (pemilik on-kan dengan TANGAN sahaja)
      SERAH dibenarkan sekali per TC. Selepas itu WAJIB: tunggu popup →
      screenshot + baca semua teks → BATAL/TIDAK/back SAHAJA.

TRIP-WIRE — tidak boleh ditekan dalam APA JUA mod, tanpa pengecualian:
      HANTAR, HANTAR SEMULA, YA, OK, SAHKAN, KEMASKINI.

Menaikkan MBPG_BENARKAN_SERAH tidak melonggarkan trip-wire. Tiada
pembolehubah persekitaran yang melonggarkan trip-wire. Itu disengajakan.
"""

import os
import re
import xml.etree.ElementTree as ET


# ---------------------------------------------------------------------------
# Padanan teks
# ---------------------------------------------------------------------------
#
# SUBRENTETAN, BUKAN PADANAN PENUH, dan itu satu pilihan.
#
# Spesifikasi pemilik menyenaraikan `HANTAR` telanjang (tiada sauh). Kami
# mengekalkannya telanjang walaupun ia bermakna label seperti
# "PENGHANTARAN TIDAK BERJAYA" turut padan. Sebabnya asimetri kos:
#
#   positif palsu  -> run dibatalkan, seseorang membaca log, run semula.
#   negatif palsu  -> kompaun sebenar dikeluarkan kepada orang sebenar.
#
# Jadi kami terlebih-sekat dengan sengaja. Rentetan yang MEMADAN direkod
# verbatim dalam log pelanggaran, supaya positif palsu boleh dikenal pasti
# dalam beberapa saat dan bukan menjadi misteri.
#
# `YA` dan `OK` DISAUH (^...$) kerana ia terlalu pendek: tanpa sauh, 'OK'
# memadan "TIDAK OK", "LOKASI", "KOMPAUN OKTOBER". Sauh berfungsi kerana
# corong menguji setiap rentetan yang dipungut SECARA BERASINGAN dan tidak
# pernah mencantumkannya — anak TextView bertulis "YA" tiba sebagai rentetan
# tersendiri "YA", jadi ^YA$ memadan tepat seperti yang dihajati.
# ---------------------------------------------------------------------------
# DASAR: positif palsu pada TEKS DATA lawan butang sebenar
# ---------------------------------------------------------------------------
# Keputusan pemilik 2026-08-12, selepas sweep 284:
#
#   "Auto-baiki-sambung untuk positif-palsu (tripwire pada teks data)
#    DILULUSKAN. HENTI keras kekal untuk tripwire butang sebenar
#    sahaja."
#
# Maksudnya, apabila corong menyekat sesuatu:
#
#   BUTANG sebenar (SERAH / HANTAR / SIMPAN di luar konteks / YA / OK /
#   SAHKAN / KEMASKINI rekod)
#       -> HENTI KERAS. Forensik. Tunggu pemilik. Tiada pengecualian,
#          tiada larian tanpa pengawasan boleh memutuskan sendiri.
#
#   TEKS DATA yang kebetulan mengandungi perkataan itu — baris
#   dropdown, keterangan kesalahan, nama tempat
#       -> baiki corak (BERLABUH atau bersempadan-perkataan), tambah
#          ujian gerbang yang membuktikan butang sebenar masih disekat,
#          kemudian sambung.
#
# Kes yang mencetuskan dasar ini: baris dropdown berbunyi
# "...BINATANG YANG DISIMPAN DALAM SESUATU TEMPAT..." — 'DISIMPAN'
# mengandungi 'SIMPAN'. Mengetuknya memilih nilai; ia tidak boleh
# menyimpan apa-apa.
#
# Pembetulan mesti MENYEMPITKAN corak, bukan meluaskan pengecualian.
# Setiap satu setakat ini melakukannya: sauh ^...$ penuh untuk dialog,
# \b untuk perkataan, gandingan struktur untuk konteks SIMPAN.
TRIPWIRE = [
    ("HANTAR",         re.compile(r"HANTAR",          re.I)),
    ("HANTAR SEMULA",  re.compile(r"HANTAR\s*SEMULA",  re.I)),
    ("YA",             re.compile(r"^\s*YA\s*$",       re.I)),
    ("OK",             re.compile(r"^\s*OK\s*$",       re.I)),
    ("SAHKAN",         re.compile(r"SAHKAN",           re.I)),
    ("KEMASKINI",      re.compile(r"KEMASKINI",        re.I)),
    # >>> DITAMBAH 2026-08-12. <<< PADAM/HAPUS tidak pernah ada dalam
    # senarai ini. Di bawah dry-run ia tidak pernah menjadi masalah
    # kerana tiada rekod wujud untuk dipadam. Fasa C mencipta rekod
    # SEBENAR, jadi butang padam kini mempunyai sasaran — dan pemilik
    # menuntut ia disekat MATI walaupun dry-run OFF.
    ("PADAM",          re.compile(r"\bPADAM\b",        re.I)),
    ("HAPUS",          re.compile(r"\bHAPUS\b",        re.I)),
    # CETAK juga tiada dalam senarai ini sebelum ini. Ia tidak pernah
    # penting semasa pencetak di luar skop, tetapi ia tindakan LUARAN:
    # sekali kertas keluar, ia wujud. Fasa C membukanya melalui permit;
    # di luar permit ia disekat.
    ("CETAK",          re.compile(r"\bCETAK\b",        re.I)),
]

# Butang yang permit Fasa C boleh benarkan. Senarai ini ialah SELURUH
# permukaan yang boleh dibuka — apa-apa di luarnya kekal disekat walau
# apa pun konfigurasi.
#
# PADAM, HAPUS, KEMASKINI dan SELARAS PELESEN sengaja TIADA di sini.
# Fasa C mencipta rekod; ia tidak memadam, tidak meminda, dan tidak
# mencetuskan sync 3-4 jam.
PERMIT_BUTANG = {
    "SERAH":  re.compile(r"^\s*SERAH\s*$", re.I),
    "YA":     re.compile(r"^\s*YA\s*$", re.I),
    "SAHKAN": re.compile(r"^\s*SAHKAN\s*$", re.I),
    "HANTAR": re.compile(r"^\s*HANTAR(\s*SEMULA)?\s*$", re.I),
    "CETAK":  re.compile(r"^\s*CETAK\s*$", re.I),
}


class PermitSerah:
    """Kebenaran berskop untuk SATU rekod Fasa C.

    Dibuka hanya selepas `gerbang_serah.semak()` lulus, dinamakan
    kepada satu TC dalam whitelist, dan dihadkan oleh `had`. Ia
    membenarkan HANYA butang dalam PERMIT_BUTANG — bukan "semua tap".

    Sengaja tiada cara membina objek ini daripada pembolehubah
    persekitaran. Ia mesti dibina oleh kod yang baru sahaja melepasi
    gerbang, dengan TC di tangan.
    """

    __slots__ = ("tc", "butang", "had", "kiraan")

    def __init__(self, tc, butang=None, had=0, kiraan=0):
        self.tc = tc
        self.butang = tuple(butang or PERMIT_BUTANG)
        self.had = int(had)
        self.kiraan = int(kiraan)

    def membenarkan(self, teks):
        if self.kiraan >= self.had:
            return False
        for nama in self.butang:
            corak = PERMIT_BUTANG.get(nama)
            if corak is not None and corak.match(teks or ""):
                return True
        return False

# ---------------------------------------------------------------------------
# MOD SEBENAR TERKAWAL — keputusan pemilik 2026-08-17
# ---------------------------------------------------------------------------
# Pemilik meluluskan automasi menekan SERAH/HANTAR/SAHKAN/YA/OK/KEMASKINI
# untuk mencipta rekod SEBENAR pada production, khusus untuk melitupi 18
# TC kategori skip-guard (testdata/skop.py bahagian C).
#
# >>> INI BUKAN SUIS "MATIKAN CORONG". <<<
# Arahan pemilik menyebutnya secara eksplisit: "guna pendekatan sama
# macam pengecualian SIMPAN-Tetapan/bookmark: kenal pasti konteks secara
# BERSTRUKTUR (skrin/borang semasa), bukan buka semua butang bahaya
# global."
#
# Jadi ia dibina persis seperti dua pengecualian SIMPAN yang sudah ada:
#
#   1. Satu bendera induk, MBPG_MOD_SEBENAR, lalai 0.
#   2. Satu senarai butang TERHAD dan BERSAUH (MOD_SEBENAR_BUTANG).
#      Apa-apa di luarnya kekal jatuh ke trip-wire.
#   3. Satu semakan konteks BERSTRUKTUR (konteks_mod_sebenar) yang
#      membaca TAJUK APP-BAR skrin semasa daripada pokok view, dan
#      memulangkan None untuk setiap skrin yang bukan dalam senarai.
#   4. Satu senarai larangan MUTLAK yang bendera ini TIDAK BOLEH buka.
#
# Dengan bendera OFF (lalai) fungsi nilai() berkelakuan IDENTIK seperti
# sebelum ini — cabang di bawah tidak pernah dimasuki. Itu diuji secara
# eksplisit oleh test_mod_sebenar_off_kelakuan_identik().

# Butang yang mod sebenar boleh benarkan, DALAM KONTEKS SAHAJA.
#
# Kesemuanya BERSAUH PENUH (^...$) atas sebab yang sama seperti
# PERMIT_BUTANG: corong menguji setiap rentetan yang dipungut SECARA
# BERASINGAN, jadi butang sebenar tiba sebagai rentetannya sendiri.
# Sauh bermakna baris data yang KEBETULAN menyebut 'HANTAR' di tengah
# ayat (cth 'PENGHANTARAN TIDAK BERJAYA', keterangan kesalahan) tidak
# pernah dibuka oleh mod ini.
#
# SERAH/HANTAR/SAHKAN/YA/OK/KEMASKINI dinamakan terus oleh pemilik.
# CETAK ditambah kerana N/P/K-002 ialah TC cetak dan CETAK ialah
# trip-wire sejak 2026-08-12; tanpa ia, tiga daripada 18 TC mustahil.
# HANTAR DATA / HANTAR GAMBAR / HANTAR SEMULA ialah butang skrin Hantar
# (H-001..003) — ketiga-tiganya memadan trip-wire HANTAR, jadi ketiganya
# perlu disenaraikan sendiri.
MOD_SEBENAR_BUTANG = {
    "SERAH":         re.compile(r"^\s*SERAH\s*$", re.I),
    "HANTAR":        re.compile(r"^\s*HANTAR\s*$", re.I),
    "HANTAR SEMULA": re.compile(r"^\s*HANTAR\s+SEMULA\s*$", re.I),
    "HANTAR DATA":   re.compile(r"^\s*HANTAR\s+DATA\s*$", re.I),
    "HANTAR GAMBAR": re.compile(r"^\s*HANTAR\s+GAMBAR\s*$", re.I),
    "SAHKAN":        re.compile(r"^\s*SAHKAN\s*$", re.I),
    "YA":            re.compile(r"^\s*YA\s*$", re.I),
    "OK":            re.compile(r"^\s*OK\s*$", re.I),
    "KEMASKINI":     re.compile(r"^\s*KEMASKINI\s*$", re.I),
    "CETAK":         re.compile(r"^\s*CETAK\s*$", re.I),
}

# Larangan MUTLAK — mod sebenar TIDAK BOLEH membukanya, dalam konteks
# mana pun. Diperiksa SEBELUM senarai butang di atas, jadi satu skrin
# yang membawa kedua-dua jenis teks kekal disekat.
#
# PADAM/HAPUS: pemilik meluluskan MENCIPTA rekod, bukan MEMADAM. Rekod
# ujian dibersihkan oleh PM melalui portal, bukan oleh automasi.
# SELARAS PELESEN: T-008, sync 3-4 jam — dikecualikan sejak 2026-08-07
# dan pemilik menegaskan semula dalam arahan mod sebenar ini
# ("T-008 KEKAL SKIP").
MOD_SEBENAR_MUTLAK_DILARANG = (
    ("PADAM",           re.compile(r"\bPADAM\b", re.I)),
    ("HAPUS",           re.compile(r"\bHAPUS\b", re.I)),
    ("SELARAS-PELESEN", re.compile(r"SELARAS\s*MAKLUMAT\s*PELESEN"
                                   r"|^\s*PELESEN\s*$", re.I)),
)

# Jalur app-bar. Tajuk skrin app ini SENTIASA dirender dalam jalur atas
# dan tiada apa lagi yang berteks di situ kecuali glif ikon.
#
# Bukti device — 15 dump dalam docs/recon/ dan ui_dumps/, setiap satu
# disemak oleh test_tajuk_appbar_dari_dump_sebenar():
#
#   borang (Letak Kereta / Pelbagai)  View rid=appbar-content-title-text
#                                     [168,162][912,246]
#   senarai (Senarai Kompaun)         View tanpa rid [204,152][675,233]
#   Notis Kompaun                     View tanpa rid [204,152][618,233]
#   skrin utama (Kompaun e-PBT)       View rid=appbar-content-title-text
#                                     [48,162][600,246]
#
# Elemen BUKAN-app-bar yang pertama pada mana-mana skrin bermula pada
# y>=324 (butang TARIK NOTIS), jadi 300 memisahkannya dengan selamat.
# Dua rendering berbeza itulah sebab semakan ini tidak boleh disandarkan
# pada resource-id sahaja.
MOD_SEBENAR_BAND_ATAS = 300

# Skrin yang membenarkan mutasi. Setiap corak BERSAUH PENUH.
#
# Senarai ini ialah SELURUH permukaan mod sebenar. Skrin yang tiada di
# sini — skrin utama 'Kompaun e-PBT', skrin login 'Aplikasi Kompaun
# e-PBT', modal Menu Selaras, skrin Tetapan — memulangkan None, dan
# setiap butang mutasi di atasnya kekal disekat oleh trip-wire.
#
# Sumber setiap entri:
#   Letak Kereta   K-001/002/003/004 — dump k001-*.xml, mbpg_letak_
#                  kereta_pesalah.xml (MBPG, disahkan)
#   Pelbagai       P-001/002/003/004/006 — dump denda_tiada_dalam_
#                  pokok.xml (MBPG, disahkan)
#   Notis Amaran   N-001/002/004 — pages/notis_amaran_page.py:20-23
#                  (dump ui_dumps\41, sumber MBJB; MBPG merender Title
#                  Case, jadi corak tidak peka huruf). BELUM disahkan
#                  pada dump MBPG — lihat JURANG BUKTI di bawah.
#   Paparan Notis  skrin papar notis (laluan cetak/kemaskini N) —
#                  dump bookmark_popup.xml (MBJB)
#   Senarai        SK-001 — dump cetak-B-senarai.xml (MBPG, disahkan)
#   Notis Kompaun  TN-001/002/003, NK-001/002 — dump nk-A/nk-C
#                  (MBPG, disahkan)
#   Notis To Kompaun  borang penukaran NK —
#                  pages/notis_kompaun_page.py:176 (BELUM disahkan
#                  pada device; recon berhenti sebelum butang KOMPAUN)
#   Hantar         H-001/002/003 — BELUM disahkan pada dump.
#
# >>> JURANG BUKTI — GAGAL-TERTUTUP, BUKAN DIANDAIKAN. <<<
# Tiga entri terakhir belum ada dump MBPG. Kalau tajuk sebenar berbeza,
# konteks memulangkan None dan corong MENYEKAT — run berhenti dengan
# sebab yang menamakan tajuk yang benar-benar dibaca, dan senarai ini
# dibetulkan daripada bukti itu. Arah kegagalannya SELAMAT.
KONTEKS_MOD_SEBENAR = (
    ("BORANG-K",     re.compile(r"^\s*(KOMPAUN\s+)?LETAK\s*KERETA\s*$", re.I)),
    ("BORANG-P",     re.compile(r"^\s*(KOMPAUN\s+)?PELBAGAI\s*$", re.I)),
    ("BORANG-N",     re.compile(r"^\s*NOTIS\s+AMARAN\s*$", re.I)),
    ("PAPARAN-N",    re.compile(r"^\s*PAPARAN\s+NOTIS\s*$", re.I)),
    # >>> DITAMBAH 2026-08-17, dengan bukti device. <<<
    # Tab KOMPAUN pada borang Pelbagai/Letak Kereta merender app-barnya
    # sendiri bertajuk 'Paparan Kompaun' (back-desc 'MainPelbagai,
    # back') — BUKAN 'Pelbagai', yang hanya tajuk tab PESALAH.
    #
    # Bukti: ui_dumps/mbjb_BUTIRAN_KESALAHAN_dedah_gagal.xml, dirakam
    # oleh larian P-001 2026-08-17 15:34. Tanpa entri ini, semakan
    # konteks lulus pada tab PESALAH ('Pelbagai') dan kemudian SERAH
    # disekat pada tab KOMPAUN — kegagalan yang hanya muncul SELEPAS
    # borang diisi penuh dan gambar diambil.
    #
    # Ia setara dengan 'Paparan Notis' pada borang N, yang sudah
    # disenaraikan di atas atas sebab yang sama.
    ("PAPARAN-K",    re.compile(r"^\s*PAPARAN\s+KOMPAUN\s*$", re.I)),
    ("SENARAI",      re.compile(r"^\s*SENARAI(\s+KOMPAUN)?\s*$", re.I)),
    ("NOTIS-KOMPAUN", re.compile(r"^\s*NOTIS\s+KOMPAUN\s*$", re.I)),
    ("NK-BORANG",    re.compile(r"^\s*NOTIS\s+TO\s+KOMPAUN\s*$", re.I)),
    # >>> DISAHKAN PADA DUMP MBPG 2026-08-20 — jurang bukti DITUTUP. <<<
    # Corak asal `^HANTAR$` ditulis TANPA dump ("BELUM disahkan") dan
    # run 2026-08-20 12:58 membuktikannya salah: trip-wire menyekat
    # HANTAR DATA pada skrin Hantar sebenar. Forensik
    # reports/forensik/20260820-125839__tiada__HANTAR.xml menunjukkan
    # app-bar y=152 bertajuk 'Hantar Kompaun' (tab 'BELUM HANTAR ' /
    # 'DATA RALAT' bermula y=322, bawah MOD_SEBENAR_BAND_ATAS=300).
    # Arah kegagalan memang selamat — dan inilah pembetulan daripada
    # bukti itu, seperti yang blok JURANG BUKTI di atas rancangkan.
    ("HANTAR",       re.compile(r"^\s*HANTAR(\s+KOMPAUN)?\s*$", re.I)),
)

# ---------------------------------------------------------------------------
# Tingkat kedua: dialog yang MENGGANTIKAN pokok view
# ---------------------------------------------------------------------------
# Andaian "modal dirender DI ATAS skrinnya, jadi app-bar kekal dalam
# pokok" adalah BENAR untuk modal React Native (modal-surface) — tetapi
# TIDAK untuk setiap dialog. Bukti bercanggah dalam repo:
#
#   docs/recon/nk-A-skrin-masuk.xml    20,838 bait, app-bar 'Notis Kompaun'
#   docs/recon/nk-B-dialog-tarik.xml    8,052 bait, TIADA app-bar langsung
#
# Dialog TARIK NOTIS TAMAT TEMPOH menggantikan pokok itu sepenuhnya.
# Menyauh pada app-bar sahaja bermakna dialog seperti ini memulangkan
# None, dan setiap butang trip-wire di dalamnya kekal disekat — run
# berhenti di tengah kitaran, selepas rekod sebenar mungkin sudah wujud.
#
# Maka tingkat kedua: dialog yang TEKSNYA SENDIRI mengenal pastinya.
# Setiap entri mesti disertai bukti di mana ia dirakam. Ini senarai
# putih; dialog yang tidak dikenali kekal None, sama seperti
# ALERT_INFO_SELAMAT.
KONTEKS_DIALOG_MOD_SEBENAR = (
    # reports/LEDGER-E2E.jsonl, peristiwa 'dialog-serah' — dirakam TIGA
    # kali (C1-N-001, C2-P-001, C3-K-001), teks penuh
    # ['X', 'SIMPAN MAKLUMAT INI ?', 'HANTAR'].
    ("DIALOG-SERAH",
     re.compile(r"^\s*SIMPAN\s+MAKLUMAT\s+INI\s*\??\s*$", re.I)),
    # reports/LEDGER-E2E.jsonl, peristiwa 'rekod-dicipta' C2-P-001,
    # teks_kejayaan ['X', 'CETAK KOMPAUN PELBAGAI ?',
    # 'No Kompaun: PGP02P260813001', 'CETAK', ...].
    ("DIALOG-CETAK",
     re.compile(r"^\s*CETAK\s+.+\?\s*$", re.I)),
    # docs/recon/nk-B-dialog-tarik.xml (device, 2026-08-13).
    ("DIALOG-TARIK",
     re.compile(r"^\s*TARIK\s+NOTIS\s+TAMAT\s+TEMPOH\s*$", re.I)),
    # pages/kemaskini_page.py:54 POPUP_TITLE.
    ("DIALOG-KEMASKINI",
     re.compile(r"^\s*KEMASKINI\s+DATA\s*$", re.I)),
)

# ---------------------------------------------------------------------------
# Kad NAVIGASI skrin utama — bukan butang penghantaran
# ---------------------------------------------------------------------------
# >>> DITAMBAH 2026-08-17 selepas ia menyekat H-001..003 pada device. <<<
# Skrin utama membawa lima kad menu. Salah satunya berlabel `Hantar`,
# dan ia mencetuskan trip-wire HANTAR:
#
#     DryRunViolation: TRIP-WIRE HANTAR — Padanan: 'Hantar'
#     Laluan tap: el.click  (pages/home_page.py open_hantar)
#
# Kad itu MEMBUKA menu Hantar. Ia tidak menghantar apa-apa — butang
# mutasi sebenar (HANTAR DATA / HANTAR GAMBAR / HANTAR SEMULA) berada
# DI DALAM skrin itu, dan ia dinilai secara berasingan di sana.
#
# Tanpa pengecualian ini, H-001..003 mustahil dicapai: satu-satunya
# jalan masuk ialah kad itu.
#
# >>> KENAPA INI SEMPIT, BUKAN LONGGAR. <<<
# Ia terpakai HANYA apabila tajuk app-bar ialah skrin utama, dan HANYA
# untuk lima label kad yang diketahui. Bukti device
# (docs/recon/cetak-A-skrin-utama.xml) mengesahkan skrin itu TIDAK
# mempunyai sebarang kawalan penghantaran — hanya lima kad navigasi,
# tajuk, dan tiga glif ikon. Jadi membuka lima label itu di sana tidak
# boleh menekan apa-apa yang menghantar.
#
# Pada mana-mana skrin LAIN, 'Hantar' kekal trip-wire.
MENU_UTAMA_TAJUK = re.compile(r"^\s*KOMPAUN\s+e-?PBT\s*$", re.I)

KAD_NAVIGASI_UTAMA = (
    re.compile(r"^\s*NOTIS\s+AMARAN\s*$", re.I),
    re.compile(r"^\s*DAFTAR\s+KOMPAUN\s*$", re.I),
    re.compile(r"^\s*NOTIS\s+KOMPAUN\s*$", re.I),
    re.compile(r"^\s*SENARAI\s*$", re.I),
    re.compile(r"^\s*HANTAR\s*$", re.I),
)


def konteks_menu_utama(sumber_halaman):
    """True HANYA pada skrin utama, disahkan melalui tajuk app-bar.

    Gagal-tertutup: apa-apa yang tidak dapat dibaca => False => kad
    navigasi kekal dinilai sebagai trip-wire.
    """
    tajuk = tajuk_appbar(sumber_halaman)
    return bool(tajuk and MENU_UTAMA_TAJUK.match(tajuk))


# Julat Unicode Private Use Area. Ikon app (bar atas, kad menu) dirender
# sebagai glif PUA dalam TextView berteks — codepoint dalam julat
# tambahan PUA yang `_PUA` di bawah takrifkan. (Codepoint tepat sengaja
# tidak ditulis dalam komen: bentuk 'huruf + empat digit' memadan corak
# plat kenderaan dalam devtools/imbas_pii.py dan menghalang commit.) Ia
# BUKAN tajuk, dan menapisnya ialah yang membolehkan semakan
# "tepat-satu-calon" di bawah menjadi tegas.
_PUA = ((0xE000, 0xF8FF), (0xF0000, 0xFFFFD), (0x100000, 0x10FFFD))


def _hanya_glif(teks):
    """True kalau setiap aksara ialah glif ikon atau ruang."""
    ada = False
    for ch in teks:
        if ch.isspace():
            continue
        ada = True
        o = ord(ch)
        if not any(a <= o <= b for a, b in _PUA):
            return False
    return ada


def tajuk_appbar(sumber_halaman):
    """Tajuk skrin semasa dari jalur app-bar, atau None.

    Membaca atribut `text` SAHAJA, tidak `content-desc`. Sebabnya bukti:
    pada kesemua 15 dump, tajuk sentiasa `text`, sedangkan `content-desc`
    dalam jalur yang sama membawa label navigasi ('Back', 'MainMenu,
    back', 'Notis Amaran, back'). Yang terakhir itu khususnya beracun —
    ia menamakan skrin SEBELUMNYA, bukan skrin semasa, jadi menerimanya
    bermakna membenarkan mutasi berdasarkan skrin yang kita sudah
    tinggalkan.

    Memulangkan None kalau calon bukan TEPAT SATU. Sifar calon bermakna
    kami tidak dapat membaca skrin; lebih daripada satu bermakna kami
    tidak tahu yang mana tajuk. Kedua-duanya => mutasi disekat.
    """
    if not sumber_halaman:
        return None
    try:
        akar = ET.fromstring(sumber_halaman)
    except (ET.ParseError, TypeError):
        return None

    calon = []
    for n in akar.iter():
        t = (n.get("text") or "").strip()
        if not t or _hanya_glif(t):
            continue
        b = re.match(r"\[(-?\d+),(-?\d+)\]\[(-?\d+),(-?\d+)\]",
                     n.get("bounds") or "")
        if not b:
            continue
        if int(b.group(4)) <= MOD_SEBENAR_BAND_ATAS:
            calon.append(t)

    # Node app-bar boleh bersarang (View pembungkus + TextView anak
    # membawa teks yang SAMA). Nilai yang serupa dikira satu.
    unik = []
    for t in calon:
        if t not in unik:
            unik.append(t)
    return unik[0] if len(unik) == 1 else None


def konteks_mod_sebenar(sumber_halaman):
    """Nama konteks skrin yang membenarkan mutasi, atau None.

    Ini pengecualian ketiga yang disahkan secara STRUKTUR dalam modul
    ini, dan ia mengikut peraturan yang sama seperti konteks_bookmark()
    dan konteks_tetapan(): apa-apa yang tidak dapat dibaca => None =>
    disekat. Gagal-tertutup.

    Kenapa TAJUK APP-BAR dan bukan kandungan skrin: dialog mutasi
    (SIMPAN MAKLUMAT INI ?, CETAK ... ?, TARIK NOTIS TAMAT TEMPOH,
    KEMASKINI DATA) ialah modal React Native yang dirender DI ATAS
    skrinnya. Skrin di bawah kekal dalam pokok view bersama app-barnya
    — jadi menyauh pada app-bar melitupi dialog itu secara automatik,
    tanpa perlu menyenaraikan setiap teks dialog satu per satu dan
    tanpa membuka apa-apa pada skrin yang tidak dibenarkan.
    """
    tajuk = tajuk_appbar(sumber_halaman)
    if tajuk:
        for nama, corak in KONTEKS_MOD_SEBENAR:
            if corak.match(tajuk):
                return nama
        # App-bar DIBACA dan skrinnya BUKAN skrin yang dibenarkan.
        # Berhenti di sini — jangan jatuh ke semakan dialog. Kalau
        # tidak, satu baris data pada skrin utama yang kebetulan
        # berbunyi seperti tajuk dialog akan membuka mutasi di sana.
        return None

    # App-bar tidak dapat dibaca. Itu berlaku pada dialog yang
    # menggantikan pokok view (lihat nota KONTEKS_DIALOG_MOD_SEBENAR).
    # Dalam kes itu SAHAJA, dialog dibenarkan mengenal pasti dirinya.
    if not sumber_halaman:
        return None
    try:
        akar = ET.fromstring(sumber_halaman)
    except (ET.ParseError, TypeError):
        return None
    for n in akar.iter():
        for atribut in ("text", "content-desc"):
            t = (n.get(atribut) or "").strip()
            if not t:
                continue
            for nama, corak in KONTEKS_DIALOG_MOD_SEBENAR:
                if corak.match(t):
                    return nama
    return None


# Satu-satunya teks yang mengandungi KEMASKINI dan BUKAN kemaskini rekod.
#
# >>> DITAMBAH 2026-08-10 selepas ia menyekat T-011. <<<
# Item Menu Selaras berbunyi 'Semak Kemaskini Versi Terkini ' (dengan
# ruang di hujung — fakta device). Trip-wire KEMASKINI wujud untuk
# menghalang PINDAAN REKOD; item ini menyemak versi APP dan tidak
# menyentuh sebarang rekod. Pemilik meluluskan T-011 secara eksplisit
# sebagai read-only.
#
# DISAUH PENUH (^...$). 'Kemaskini Notis', 'Kemaskini Kompaun' dan
# apa-apa lagi kekal disekat — tiada satu pun memadan bentuk ini.
#
# >>> DITAMBAH 2026-08-17 selepas ia menyekat N-004 pada device. <<<
# Dialog keterangan kemaskini membawa MEDAN INPUT dengan placeholder
# 'ISI KEMASKINI KETERANGAN'. Corong menyekat ketukan padanya sebagai
# trip-wire KEMASKINI, dan run berhenti SELEPAS rekod production
# `PGP02N260817008` sudah wujud.
#
# Ia bukan butang. Bukti device — dump pelanggaran
# reports/forensik/20260817-134334__tiada__KEMASKINI.xml, kandungan
# PENUH skrin itu:
#
#     ViewGroup  clk=true  [891,940][996,1045]   desc='✕'
#     TextView   clk=false [277,1060][803,1128]  'SILA ISI KETERANGAN'
#     EditText   clk=true  [120,1146][960,1266]  'ISI KEMASKINI KETERANGAN'
#     ViewGroup  clk=true  [99,1308][981,1435]   desc='SETERUSNYA'
#
# `android.widget.EditText`. Mengetuknya memberi fokus kepada medan
# teks; ia tidak boleh meminda apa-apa. Skrin itu langsung TIDAK
# mempunyai butang mutasi — hanya ✕ dan SETERUSNYA.
#
# Ini kelas positif-palsu yang dasar pemilik 2026-08-12 namakan:
# "positif palsu pada TEKS DATA -> baiki corak, tambah gerbang,
# sambung", dan pembetulan mesti MENYEMPITKAN. Sauh penuh melakukannya:
# 'KEMASKINI', 'KEMASKINI DATA', 'Kemaskini Notis' semuanya KEKAL
# disekat — tiada satu pun memadan bentuk ini.
KEMASKINI_BUKAN_REKOD = (
    re.compile(r"^\s*SEMAK\s+KEMASKINI\s+VERSI\s+TERKINI\s*$", re.I),
    re.compile(r"^\s*ISI\s+KEMASKINI\s+KETERANGAN\s*$", re.I),
)

# Disekat bila MBPG_BENARKAN_SERAH=0 (default). Bukan trip-wire: pemilik
# boleh membukanya dengan tangan.
SERAH = ("SERAH", re.compile(r"SERAH", re.I))

# Disekat DI MANA-MANA KECUALI dua konteks yang disahkan secara
# STRUKTUR: dialog nama bookmark, dan skrin Tetapan. Lihat
# konteks_bookmark() dan konteks_tetapan().
#
# >>> SEMPADAN PERKATAAN — DIBAIKI 2026-08-12. <<<
# Corak lama `SIMPAN` ialah subrentetan telanjang. Ia membatalkan
# sweep pada set ke-16, atas baris dropdown yang berbunyi:
#
#   [SEK 81 (B)] - APA-APA BINATANG YANG DISIMPAN DALAM SESUATU
#   TEMPAT ATAU DENGAN SESUATU CARA ATAU DENGAN SEBEGITU BESAR
#   BILANGANNYA HINGGA MENJADI SUATU KACAU GANGGU
#
# 'DISIMPAN' mengandungi 'SIMPAN'. Itu keterangan KESALAHAN, bukan
# butang — tiada apa boleh disimpan dengan mengetuknya; ia memilih
# nilai dropdown.
#
# `\b` menyelesaikannya tanpa melonggarkan apa-apa yang penting:
#   'SIMPAN', 'Simpan', 'SIMPAN DATA'  -> MASIH disekat
#   'DISIMPAN', 'MENYIMPAN', 'PENYIMPANAN', 'SIMPANAN' -> tidak
# Butang simpan sebenar tidak pernah muncul terbenam di tengah ayat.
SIMPAN = ("SIMPAN", re.compile(r"\bSIMPAN\b", re.I))

# Selaras Maklumat Pelesen — DILARANG MUTLAK.
#
# Bukan kerana ia berbahaya kepada data: ia sync baca-sahaja. Kerana ia
# mengambil 3-4 JAM pada peranti, dan pada MBJB ia pernah dicetuskan
# SECARA TIDAK SENGAJA lalu menawan peranti untuk sepanjang hari kerja.
# Pemilik menegaskan semula 2026-08-07 bahawa ia mesti dikecualikan
# sepenuhnya, jadi ia dikuatkuasakan pada lapisan tap dan bukan hanya
# dengan melangkau TC — satu ketukan tersasar pada item menu itu sudah
# cukup untuk membakar hari.
#
# Corak sengaja SPESIFIK (bukan subrentetan 'PELESEN' telanjang) supaya
# ia menyasarkan item menu itu sendiri dan bukan sebarang label yang
# kebetulan menyebut pelesen.
PELESEN = ("SELARAS-PELESEN",
           re.compile(r"SELARAS\s*MAKLUMAT\s*PELESEN|^\s*PELESEN\s*$", re.I))

# Butang keluar yang SENTIASA dibenarkan. Disenaraikan secara eksplisit
# supaya laluan pemulihan selepas popup tidak boleh disekat secara tidak
# sengaja oleh peraturan yang lebih luas.
KELUAR_SELAMAT = re.compile(r"^\s*(BATAL|TIDAK|CANCEL|TUTUP|KEMBALI)\s*$", re.I)

# Tajuk dialog bookmark. Tidak peka huruf: app memaksa huruf besar pada
# sesetengah skrin (reports/fasa2-bootstrap.md 2.4).
TAJUK_BOOKMARK = re.compile(r"pilihan\s*kegemaran", re.I)

# Bekas modal React Native (pages/base_page.py:2151). Bila modal terbuka,
# kandungan aktif berada DI DALAM node ini; borang di BELAKANG kekal dalam
# pokok dan membawa EditText sendiri (dump K9, pages/bookmark_page.py:199).
# Itu sebab "ada EditText di suatu tempat" BUKAN ujian yang sah: borang
# Pesalah di BELAKANG popup membawa EditText juga, dan menerimanya akan
# membuka SIMPAN pada SELURUH borang Daftar Kompaun.
MODAL_SURFACE_ID = "modal-surface"

# ---------------------------------------------------------------------------
# Sauh skrin Tetapan
# ---------------------------------------------------------------------------
# Medan modal Tetapan SEMUANYA membawa resource-id 'text-input-outlined'
# (fakta device, dump ui_dumps/03_tetapan_alamat_ip.xml dan
# 08_tetapan_pelbagai.xml; pages/pelarasan_page.py:499-508). Carian
# seluruh pages/ mengesahkan id itu TIDAK PERNAH muncul pada borang
# Notis Amaran / Daftar Kompaun — medan borang di sana guna placeholder.
#
# Tetapi id itu SAHAJA tidak mencukupi: skrin LOGIN juga menggunakannya
# (pages/login_page.py:87,102), dan skrin login kekal dirender DI BELAKANG
# modal Tetapan. Jadi id digandingkan dengan label sauh skrin tertentu.
TETAPAN_INPUT_ID = "text-input-outlined"

# >>> REGEX, TIDAK SENSITIF HURUF — dibetulkan 2026-08-10. <<<
# Versi pertama ialah padanan subrentetan HURUF BESAR yang tepat. Ia
# tidak pernah boleh padan: device merender label itu sebagai
#     'Lesen Applikasi:'
# — Title Case, DUA huruf p, dan titik bertindih di hujung (disahkan
# dalam reports/forensik/20260810-182859__tiada__SIMPAN.xml).
#
# Akibatnya T-002 disekat pada modal Tetapan yang SAH, iaitu tepat
# konteks yang pemilik benarkan. Ini kelas kegagalan yang sama dengan
# enam kelas locator yang sudah dibetulkan (MBPG menggunakan Title Case
# di mana MBJB guna huruf besar, dan app salah eja 'Penguna') — sauh
# corong sendiri tidak pernah disemak semula terhadapnya.
#
# Melonggarkan ini TIDAK meluaskan kebenaran SIMPAN: kehadiran
# `text-input-outlined` MASIH diperlukan, dan borang Daftar Kompaun /
# Notis Amaran tidak mempunyainya.
TETAPAN_LABEL_SAUH = (
    re.compile(r"INTERNAL\s+IP\s+ADDRESS", re.I),   # T-001
    re.compile(r"EXTERNAL\s+IP\s+ADDRESS", re.I),   # T-001
    re.compile(r"LESEN\s+APP?LIKASI", re.I),        # T-002 (app: 'Applikasi')
)
# T-010 ialah popup pilihan, bukan borang bermedan — sauhnya tajuk popup
# (pages/pelarasan_page.py:908).
TETAPAN_TAJUK_SKRIN_UTAMA = re.compile(r"PILIHAN\s+SKRIN\s+UTAMA", re.I)

# ---------------------------------------------------------------------------
# Dialog ralat/info asli — pengecualian OK yang SANGAT sempit
# ---------------------------------------------------------------------------
# Spesifikasi pemilik: "^YA$/^OK$ blocked; kecuali dialog yang TERBUKTI
# tiada kaitan penghantaran (cth dialog error/info) — log teks penuh
# dulu."
#
# "TERBUKTI" dibaca secara literal: dialog mesti DIKENAL PASTI, bukan
# disimpulkan selamat kerana kami tidak nampak perkataan bahaya. Jadi ini
# senarai putih, bukan senarai hitam. Dialog yang tidak dikenali kekal
# DISEKAT, dengan teks penuhnya dilog supaya pemilik boleh memutuskan
# sama ada ia layak masuk senarai ini.
#
# Setiap entri mesti disertai bukti device: di mana ia dilihat dan bila.
ALERT_INFO_SELAMAT = [
    # Dilihat 2026-08-10 sejurus selepas menekan LOGIN pada peranti
    # Armor 27, app 2.1.21. Tajuk "Alert", badan "Error: Unable to
    # connect device". Ia dialog KEPUTUSAN (sesuatu gagal disambung),
    # bukan pengesahan penghantaran — tiada apa dihantar dengan
    # menutupnya.
    re.compile(r"unable\s+to\s+connect\s+device", re.I),

]

# Dialog yang dipadan SECARA PENUH (bersauh) — dibenarkan TANPA melalui
# semakan perkataan bahaya, kerana coraknya menerangkan KESELURUHAN
# dialog dan bukan sekadar sebahagian daripadanya.
#
# >>> KENAPA INI PERLU BERASINGAN — 2026-08-10. <<<
# Keluarga dialog keputusan Menu Selaras ialah
#     "Berjaya | Data <MODUL> Berjaya Disimpan!"
# dan salah satu MODULnya bernama **Kompaun**. Jadi menapis mengikut kata
# nama domain ("KOMPAUN") menyekat sync yang sah sepenuhnya — diperhati
# pada device: T-003 dan T-004 lulus, T-005 dibatalkan atas dialognya
# sendiri yang berjaya.
#
# Yang membezakan bukan kata nama, tetapi BENTUK. Sauh ^...$ bermakna
# corak ini hanya memadan apabila dialog itu, keseluruhannya, ialah mesej
# sync. "Kompaun PGP02N260813007 berjaya dihantar" tidak memadan bentuk
# ini dan kekal disekat.
#
# >>> DITAMBAH 2026-08-10 (T-002). <<<
# Dialog kedua ialah keputusan SIMPAN Tetapan Pelbagai: tajuk "BEJAYA"
# (app memang salah eja) atau "BERJAYA", badan "LESEN SAMA.". Maknanya
# TIADA APA BERUBAH — nilai lesen yang dihantar sama dengan yang
# tersimpan. Ia dialog paling tidak berbahaya dalam app: ia mengesahkan
# ketiadaan perubahan.
#
# Ia tidak boleh bergantung pada laluan longgar: badannya tiada
# perkataan bahaya, jadi ia akan jatuh terus ke `return False` dan
# menyekat OK — mematikan T-002 pada dialog yang bermaksud "tiada apa
# berlaku". Sauh penuh dikekalkan: hanya dialog yang KESELURUHANNYA
# mesej ini yang lulus.
ALERT_INFO_TEPAT = [
    # >>> DITAMBAH 2026-08-17. <<< Dialog VALIDASI borang, bukan
    # penghantaran: app menolak perpindahan ke tab Penerima apabila
    # Tempoh kosong. Menutupnya tidak menghantar apa-apa — ia hanya
    # memulangkan borang supaya medan boleh diisi.
    #
    # Ia mesti berada DI SINI dan bukan dalam ALERT_INFO_SELAMAT:
    # `ALERT_PERKATAAN_BAHAYA` diperiksa DAHULU dan memadan 'NOTIS'
    # sebagai perkataan domain-rekod, jadi corak longgar tidak akan
    # pernah dicapai. Sauh bentuk-PENUH menang dahulu, dan kerana ia
    # menerangkan keseluruhan dialog tiada ruang untuk ayat
    # penghantaran bersembunyi di dalamnya.
    re.compile(r"^\s*RALAT\s*\|\s*SILA\s+ISI\s+TEMPOH\s+NOTIS\s*!?\s*$",
               re.I),
    re.compile(r"^\s*BERJAYA\s*\|\s*DATA\s+[\w\s]{1,40}?\s+BERJAYA"
               r"\s+DISIMPAN\s*!?\s*$", re.I),
    # Keluarga yang SAMA, ayat Bahasa Inggeris. App bercampur bahasa:
    # Selaras Pengguna/Alamat/Kompaun memulangkan "Data X Berjaya
    # Disimpan!", Selaras Jenis Kenderaan memulangkan "Data Jenis
    # Kenderaan saved successfully!" (disahkan
    # reports/forensik/20260810-184149__tiada__OK.xml). Tanpa varian ini
    # T-006 membatalkan run atas dialog kejayaannya sendiri — persis
    # kegagalan yang sauh bentuk-penuh direka untuk elakkan.
    re.compile(r"^\s*BERJAYA\s*\|\s*DATA\s+[\w\s]{1,40}?\s+SAVED"
               r"\s+SUCCESSFULLY\s*!?\s*$", re.I),
    re.compile(r"^\s*BER?JAYA\s*\|\s*LESEN\s+SAMA\s*\.?\s*$", re.I),
    # Keputusan T-011. Dialog TAJUK-SAHAJA, satu butang OK (disahkan
    # reports/forensik/20260810-185605__tiada__OK.xml). Maknanya "app
    # sudah terkini" — tiada muat turun, tiada pemasangan, tiada rekod.
    # Ejaan app 'IN' (bukan 'INI') dikekalkan sebagai pilihan.
    re.compile(r"^\s*APLIKASI\s+INI?\s+TELAH\s+DIKEMAS\s*KINI\s*!?\.?\s*$",
               re.I),
    # >>> DITAMBAH 2026-08-10 selepas ia MEMBUNUH run peringkat 6. <<<
    # Dialog PENOLAKAN app: "Maklumat Tidak Lengkap | Sila lengkapkan
    # maklumat di tab Pesalah dahulu." Butang tunggal (button1=OK),
    # disahkan dalam reports/forensik/20260810-173737__tiada__OK.xml.
    #
    # Ia hujah TERKUAT yang boleh wujud bahawa tiada apa dihantar: app
    # baru sahaja ENGGAN meneruskan. Menolaknya memulangkan borang ke
    # keadaan sebelum tap.
    #
    # Menyekatnya bukan berkecuali — ia lebih teruk daripada tidak
    # berguna. _sahkan_skrin_kompaun() sengaja menolak dialog ini untuk
    # membangkitkan AssertionError yang menyebut sebab SEBENAR ("tab
    # Pesalah tidak lengkap"). Dengan sekatan, diagnosis yang tepat itu
    # bertukar menjadi run mati tanpa sebab yang dinyatakan.
    re.compile(r"^\s*MAKLUMAT\s+TIDAK\s+LENGKAP\s*\|\s*SILA\s+LENGKAPKAN"
               r"\s+MAKLUMAT\s+DI\s+TAB\s+\w{1,15}\s+DAHULU\s*\.?\s*$",
               re.I),
    # >>> DITAMBAH 2026-08-20 selepas ia MEMBUNUH run 6. <<<
    # Dialog PENOLAKAN login: "Log Masuk Gagal | Nama pengguna atau kata
    # laluan tidak sah" (dilihat pada device selepas pm clear — jadual
    # pengguna lokal kosong, app offline-first menolak kredensial).
    # Forensik: reports/forensik/20260820-114809__tiada__OK.png/.xml.
    #
    # Hujah sama seperti MAKLUMAT TIDAK LENGKAP di atas: app baru sahaja
    # ENGGAN log masuk — menutup dialog ini tidak menghantar apa-apa, ia
    # memulangkan skrin login. Menyekatnya menukar diagnosis yang tepat
    # ("login ditolak — pengguna belum di-sync?") menjadi DryRunViolation
    # yang mengelirukan. Sauh bentuk-PENUH: hanya dialog yang
    # keseluruhannya mesej penolakan ini yang lulus.
    re.compile(r"^\s*LOG\s+MASUK\s+GAGAL\s*\|\s*NAMA\s+PENGGUNA\s+ATAU"
               r"\s+KATA\s+LALUAN\s+TIDAK\s+SAH\s*\.?\s*$", re.I),
    # >>> DITAMBAH 2026-09-14, kelulusan eksplisit pemilik (soalan MCQ,
    # jawapan "Ya, tambah"). <<< Dialog KEJAYAAN asli selepas Hantar
    # Gambar: "Berjaya | Semua gambar  berjaya di muatnaik." (jarak dua
    # ruang antara "gambar" dan "berjaya" disahkan dari peranti sebenar
    # -- \s+ di bawah menampungnya, bukan kebetulan sengaja diabaikan).
    # Forensik: reports/forensik/20260914-004548__tiada__OK.txt (Fix#5,
    # larian 14/9) -- muat naik gambar telah SELESAI berjaya sebelum
    # dialog ini muncul (log [ALERT] Hantar Gambar: popup says: Berjaya
    # | ... sebelum baris DryRunViolation), jadi menutupnya TIDAK
    # menghantar apa-apa lanjut -- ia hanya mengesahkan operasi yang
    # SUDAH selesai, persis keluarga dialog "BERJAYA | DATA ... BERJAYA
    # DISIMPAN" di atas. Disahkan TIADA perkataan dalam
    # ALERT_PERKATAAN_BAHAYA (HANTAR/SERAH/SAHKAN/KEMASKINI/TARIK/
    # KOMPAUN/NOTIS/SITA/REKOD/PGP) wujud dalam teks dialog ini.
    # "MUAT\s*NAIK" (bukan literal "MUATNAIK") menampung sama ada app
    # menulisnya sebagai satu perkataan atau dua, ikut sama gaya
    # toleransi seperti "DIKEMAS\s*KINI" di atas.
    re.compile(r"^\s*BER?JAYA\s*\|\s*SEMUA\s+GAMBAR\s+BERJAYA\s+DI"
               r"\s+MUAT\s*NAIK\s*\.?\s*$", re.I),
    # >>> DITAMBAH 2026-10-05, kelulusan eksplisit pemilik (soalan MCQ,
    # jawapan "Benarkan OK pada dialog RALAT dalam guard"). <<<
    # D-10 -- dialog VALIDASI palsu selepas kemaskini: "RALAT | SILA
    # PILIH KOMPAUN, AKTA DAN KESALAHAN". Muncul SEJURUS selepas popup
    # CETAK ditutup via X dalam konteks skrin KEMASKINI (app validate
    # borang kemaskini yang sudah kosong). Butang TUNGGAL button1=OK,
    # tiada button2 -- disahkan reports/forensik/20261005-103236
    # __tiada__OK.xml (run9, APK 2.1.25). Ia MEMBUNUH run9 selepas
    # borang N (P/K tidak dijalankan, Fix#8 tidak teruji).
    #
    # Hujah sama seperti MAKLUMAT TIDAK LENGKAP / SILA ISI TEMPOH di
    # atas: ini app ENGGAN -- "sila pilih" bermakna tiada apa dipilih,
    # maka tiada apa boleh dihantar. Rekod kemaskini SUDAH wujud di
    # production sebelum dialog ini muncul (log: kemaskini LULUS ->
    # PGP02N261005002 SEBELUM baris DryRunViolation). Menutupnya
    # memulangkan skrin kemaskini kosong; pastikan_di_home() kemudian
    # navigasi keluar seperti biasa.
    #
    # Mesti dalam ALERT_INFO_TEPAT (bukan SELAMAT): badannya mengandungi
    # "KOMPAUN" = ALERT_PERKATAAN_BAHAYA, jadi hanya sauh bentuk-PENUH
    # boleh meluluskannya -- dan sauh itu menjamin KESELURUHAN dialog
    # ialah mesej validasi ini, tiada ayat penghantaran tersembunyi.
    # Fix#7 (BACK) DISAHKAN tidak menutup alert asli ini (run9) --
    # kekal sebagai langkah tambahan tanpa mudarat.
    re.compile(r"^\s*RALAT\s*\|\s*SILA\s+PILIH\s+KOMPAUN\s*,\s*AKTA"
               r"\s+DAN\s+KESALAHAN\s*!?\.?\s*$", re.I),
]

# Kalau MANA-MANA perkataan ini muncul dalam badan dialog, pengecualian
# di atas GUGUR walaupun corak senarai putih memadan.
#
# >>> DIPERHALUSI 2026-08-10. <<<
# Versi pertama menyenaraikan BERJAYA dan SIMPAN. Itu terlalu luas: app
# memaparkan "Data Pengguna Berjaya Disimpan!" selepas sync selaras yang
# BACA-SAHAJA, jadi setiap sync yang berjaya membatalkan run.
#
# Perkataan yang benar-benar membezakan bukan "berjaya" — ia istilah
# DOMAIN REKOD. Dialog yang mengesahkan rekod akan menyebut kompaun,
# notis, sitaan, atau nombor rekod; dialog sync tidak. Jadi kami menyekat
# istilah itu, bukan perkataan kejayaan generik.
ALERT_PERKATAAN_BAHAYA = re.compile(
    r"HANTAR|SERAH|SAHKAN|KEMASKINI|TARIK"
    # PGP\d* bukan PGP03: awalan sebenar peranti ini DISAHKAN
    # PGP02 (rekod PGP02N260813007 dijana oleh app sendiri).
    # Menyenaraikan PGP03 sahaja bermakna dialog yang menyebut
    # nombor rekod SEBENAR kita tidak padan istilah bahaya.
    r"|KOMPAUN|NOTIS|SITA|REKOD|PGP\d*",
    re.I)

# Node butang OK dialog asli Android.
ALERT_BUTANG_OK_ID = "android:id/button1"


class DryRunViolation(BaseException):
    """Satu tap yang dilarang telah CUBA dilakukan dan telah DIHALANG.

    Dibangkitkan SEBELUM tap sampai ke peranti. Ia membatalkan run: sekali
    ia berlaku, kod ujian sudah terbukti cuba menekan sesuatu yang boleh
    menulis ke production, dan tiada sebab untuk mempercayai tap seterusnya.

    KENAPA BaseException DAN BUKAN Exception
    ----------------------------------------
    Ini kelihatan salah. Ia disengajakan, dan ia yang membuat gerbang ini
    berfungsi.

    pages\\base_page.py mengandungi 66 blok `except Exception` — corak
    yang wajar untuk suite UI, di mana kebanyakan kegagalan bermakna
    "cuba cara lain". Tetapi pengecualian yang bermaksud "kami baru cuba
    menekan HANTAR pada production" TIDAK BOLEH dilayan sebagai "cuba
    cara lain". Kalau ia Exception, gelung cuba-semula akan menelannya
    dan mencuba lagi: `wait_and_tap` ×3, `select_dropdown_option` ×3,
    `kemaskini.proceed_and_submit` sehingga 4 pusingan SETERUSNYA→
    MENYERAHKAN→HANTAR, `dismiss_native_alerts` ×6. Gerbang akan menyekat
    setiap percubaan dengan betul dan run akan MENERUSKAN seolah-olah
    tiada apa berlaku — kegagalan senyap yang tepat sama seperti suite
    hijau palsu yang kita cuba elakkan.

    AssertionError pun tidak memadai: dua tapak menangkapnya
    (pages\\daftar_kompaun_page.py:1043, pages\\login_page.py:666).

    BaseException tidak ditangkap di mana-mana dalam projek ini (disemak:
    sifar `except BaseException`, sifar `except:` telanjang). Ia kelas
    yang sama seperti KeyboardInterrupt dan SystemExit, dan maksudnya
    sama: berhenti sekarang, jangan pulih.

    Ujian penerimaan test_pelanggaran_tidak_boleh_ditelan() dalam
    tests_offline\\test_guard_corong.py menguatkuasakan ini.
    """


class GuardTidakPasti(DryRunViolation):
    """Teks sasaran tap TIDAK dapat dileraikan.

    Subkelas DryRunViolation kerana kesannya sama: pada production, tap
    yang kita tidak tahu sasarannya dilayan sebagai tap yang dilarang.
    Gagal-tertutup, bukan gagal-terbuka.
    """


# ---------------------------------------------------------------------------
# Tetapan (dibaca dari persekitaran, sekali, dengan sengaja)
# ---------------------------------------------------------------------------

def _bool_env(nama, default):
    mentah = os.environ.get(nama)
    if mentah is None:
        return default
    return mentah.strip() in ("1", "true", "TRUE", "ya", "YA")


class Tetapan:
    """Tetapan dry-run yang berkuatkuasa untuk satu run.

    Dibina sekali dalam conftest dan tidak diubah selepas itu. Ia bukan
    dict supaya kesilapan menaip nama medan gagal serta-merta.
    """

    def __init__(self, dry_run=None, benarkan_serah=None, izin_serah=None,
                 mod_sebenar=None):
        # MBPG_DRY_RUN kekal ON. Ia tidak boleh dimatikan dengan satu
        # pembolehubah: pematiannya memerlukan MBPG_IZIN_SERAH juga —
        # dua bendera bebas, supaya `set MBPG_DRY_RUN=0` yang tersilap
        # taip dalam satu terminal tidak melucutkan senjata suite.
        self.dry_run = _bool_env("MBPG_DRY_RUN", True) if dry_run is None else dry_run
        self.izin_serah = (
            _bool_env("MBPG_IZIN_SERAH", False) if izin_serah is None else izin_serah
        )
        if not self.dry_run and not self.izin_serah:
            self.dry_run = True   # gagal-tertutup: satu bendera tidak cukup

        self.benarkan_serah = (
            _bool_env("MBPG_BENARKAN_SERAH", False)
            if benarkan_serah is None else benarkan_serah
        )

        # MOD SEBENAR TERKAWAL — keputusan pemilik 2026-08-17.
        #
        # Bendera INDUK yang BERASINGAN daripada tiga di atas, dengan
        # sengaja. Ia tidak menggantikan mereka dan tidak dikira
        # daripada mereka: seseorang yang menetapkan MBPG_DRY_RUN=0
        # untuk sebab lain tidak sepatutnya membuka mutasi, dan
        # seseorang yang menghidupkan mod sebenar tidak sepatutnya
        # perlu meruntuhkan gerbang lain untuk berbuat demikian.
        #
        # OFF (lalai) = corong berkelakuan IDENTIK seperti sebelum
        # arahan ini wujud. Cabang mod sebenar dalam nilai() tidak
        # pernah dimasuki.
        self.mod_sebenar = (
            _bool_env("MBPG_MOD_SEBENAR", False)
            if mod_sebenar is None else mod_sebenar
        )

        # Permit Fasa C. TIADA sumber persekitaran: ia hanya boleh
        # dipasang oleh kod yang baru melepasi gerbang_serah.semak().
        # Lalai None bermakna tiada butang serah boleh ditekan.
        self.permit_serah = None
        # Bila SERAH dibenarkan ia dibenarkan SEKALI PER TC. Kiraan
        # disimpan di sini dan ditetapkan semula oleh fixture per-test.
        self.serah_digunakan = 0

    def mula_tc(self):
        self.serah_digunakan = 0

    def __repr__(self):
        return (f"Tetapan(dry_run={self.dry_run}, "
                f"benarkan_serah={self.benarkan_serah}, "
                f"izin_serah={self.izin_serah}, "
                f"mod_sebenar={self.mod_sebenar})")


# ---------------------------------------------------------------------------
# Keputusan
# ---------------------------------------------------------------------------

class Keputusan:
    """Hasil menilai satu tap. `benarkan` ialah satu-satunya medan yang
    memutuskan; yang lain untuk log dan forensik."""

    __slots__ = ("benarkan", "sebab", "peraturan", "padanan", "teks")

    def __init__(self, benarkan, sebab, peraturan=None, padanan=None, teks=()):
        self.benarkan = benarkan
        self.sebab = sebab
        self.peraturan = peraturan      # cth "HANTAR"
        self.padanan = padanan          # rentetan sebenar yang memadan
        self.teks = tuple(teks)         # semua teks yang dipungut

    def __repr__(self):
        kata = "BENAR" if self.benarkan else "SEKAT"
        return f"<{kata} {self.peraturan or '-'} {self.sebab}>"


def konteks_alert_info(sumber_halaman):
    """(ialah_alert_dikenali, badan) untuk dialog ralat/info asli.

    Memulangkan True HANYA apabila:
      (a) dialog asli Android hadir (butang android:id/button1), DAN
      (b) badannya memadan satu corak dalam senarai putih
          ALERT_INFO_SELAMAT, DAN
      (c) badannya TIDAK mengandungi perkataan penghantaran.

    Semua yang lain False — termasuk dialog asli yang tidak dikenali.
    Badan sentiasa dipulangkan supaya pemanggil boleh MELOG teks penuh
    walaupun ia disekat; itu yang menjadikan dialog baharu boleh dinilai
    pemilik dan bukan sekadar menjadi kebuntuan.
    """
    if not sumber_halaman:
        return False, ""
    try:
        akar = ET.fromstring(sumber_halaman)
    except (ET.ParseError, TypeError):
        return False, ""

    ada_butang = any(ALERT_BUTANG_OK_ID in (n.get("resource-id") or "")
                     for n in akar.iter())
    if not ada_butang:
        return False, ""

    bahagian = []
    for n in akar.iter():
        rid = n.get("resource-id") or ""
        if rid.endswith("alertTitle") or rid.endswith("android:id/message"):
            t = (n.get("text") or "").strip()
            if t:
                bahagian.append(t)
    badan = " | ".join(bahagian)
    if not badan:
        return False, ""

    # (1) Padanan PENUH bersauh menang dahulu: coraknya menerangkan
    #     keseluruhan dialog, jadi tiada ruang untuk ayat penghantaran
    #     bersembunyi di dalamnya.
    if any(c.match(badan) for c in ALERT_INFO_TEPAT):
        return True, badan

    # (2) Perkataan domain-rekod / penghantaran menyekat segala-galanya
    #     yang tinggal.
    if ALERT_PERKATAAN_BAHAYA.search(badan):
        return False, badan

    # (3) Corak longgar (cth ralat sambungan) — dibenarkan hanya selepas
    #     lulus semakan (2).
    if any(c.search(badan) for c in ALERT_INFO_SELAMAT):
        return True, badan
    return False, badan


def nilai(teks_dipungut, tetapan, konteks_simpan=None, alert_info=None,
          konteks_mutasi=None, konteks_navigasi=False):
    """Nilai satu tap terhadap dasar. Fungsi TULEN — tiada I/O, tiada
    kesan sampingan, tiada Appium. Semua ujian unit menyasar fungsi ini.

    `teks_dipungut` ialah setiap rentetan yang boleh mewakili sasaran tap:
    teks elemen itu sendiri, content-desc, dan teks setiap keturunan dalam
    kotak sempadannya. Ia diuji SATU PERSATU dan tidak pernah dicantumkan
    — pencantuman akan memusnahkan sauh ^YA$/^OK$.

    `konteks_simpan` ialah SATU-SATUNYA cara SIMPAN boleh diluluskan:
        None        -> SIMPAN disekat (lalai)
        "bookmark"  -> dialog nama bookmark disahkan berstruktur
        "tetapan"   -> skrin Tetapan disahkan berstruktur
    Pemanggil mesti mengiranya daripada sumber halaman melalui
    konteks_bookmark() / konteks_tetapan(); ia tidak boleh diandaikan.

    `konteks_mutasi` ialah nama skrin yang membenarkan MOD SEBENAR, atau
    None. Ia dikira daripada sumber halaman melalui
    konteks_mod_sebenar(), dan ia hanya bermakna apabila
    `tetapan.mod_sebenar` juga True — dua syarat bebas, atas sebab yang
    sama seperti dry_run + izin_serah. Satu daripadanya tanpa yang lain
    tidak membuka apa-apa.
    """
    teks = [t.strip() for t in teks_dipungut if t and t.strip()]

    # >>> LITAR PINTAS dry_run=False DIBUANG — 2026-08-12. <<<
    # Kod lama di sini ialah:
    #
    #     if not tetapan.dry_run:
    #         return Keputusan(True, "dry-run OFF ...")
    #
    # Satu baris itu memulangkan LULUS untuk SETIAP tap sebelum
    # sebarang trip-wire diperiksa. Jadi sebaik `MBPG_DRY_RUN=0` +
    # `MBPG_IZIN_SERAH=1` diset untuk membenarkan SATU rekod Fasa C,
    # ia turut membuka PADAM, KEMASKINI, dan Selaras Pelesen — sync
    # 3-4 jam yang diharamkan mutlak sejak hari pertama. Pemilik
    # meminta izin untuk satu rekod; konfigurasi memberi izin untuk
    # segalanya.
    #
    # Sekarang: trip-wire dinilai SENTIASA, dalam setiap mod. Dry-run
    # OFF tidak lagi bermakna apa-apa dengan sendirinya — ia cuma
    # prasyarat kepada permit berskop di bawah.
    if not teks:
        # Tiada teks langsung. BUKAN automatik selamat dan bukan automatik
        # bahaya: ikon tanpa label (klip lampiran, ikon buku bookmark,
        # anak panah dropdown) sah tidak berteks, dan menyekat semuanya
        # akan melumpuhkan suite. Pemanggil yang tahu ia gagal MEMBACA
        # (berbanding membaca "tiada apa-apa") mesti membangkitkan
        # GuardTidakPasti sendiri — lihat corong.py.
        return Keputusan(True, "tiada teks pada sasaran (ikon tanpa label)",
                         teks=teks)

    # 1. Keluar selamat diperiksa DAHULU. BATAL/TIDAK ialah laluan pemulihan
    #    yang diwajibkan selepas popup serah; kalau peraturan yang lebih
    #    luas menyekatnya, kita akan terperangkap dalam dialog pada
    #    production tanpa jalan keluar yang diluluskan.
    for t in teks:
        if KELUAR_SELAMAT.match(t):
            return Keputusan(True, f"butang keluar selamat: {t!r}",
                             peraturan="KELUAR", padanan=t, teks=teks)

    # 1b. PERMIT FASA C — berskop, dinamakan, dan terikat kepada gerbang.
    #     Diperiksa SEBELUM trip-wire supaya butang yang permit namakan
    #     boleh lulus; segala yang lain jatuh terus ke trip-wire di
    #     bawah dan kekal disekat.
    permit = getattr(tetapan, "permit_serah", None)
    if permit is not None:
        for t in teks:
            if permit.membenarkan(t):
                return Keputusan(
                    True, f"PERMIT FASA C {permit.tc}: butang {t!r} "
                          f"dibenarkan (rekod {permit.kiraan + 1}/"
                          f"{permit.had})",
                    peraturan="PERMIT-FASA-C", padanan=t, teks=teks)

    # 1c. MOD SEBENAR TERKAWAL — berskop pada SKRIN, bukan global.
    #     Keputusan pemilik 2026-08-17. Diperiksa selepas permit Fasa C
    #     dan sebelum trip-wire, supaya butang yang dinamakan boleh
    #     lulus DALAM konteks yang disahkan; segala yang lain jatuh
    #     terus ke trip-wire di bawah dan kekal disekat.
    #
    #     TIGA syarat, semuanya WAJIB:
    #       (a) bendera induk MBPG_MOD_SEBENAR hidup;
    #       (b) skrin semasa dikenal pasti secara STRUKTUR sebagai salah
    #           satu skrin dalam KONTEKS_MOD_SEBENAR;
    #       (c) teks sasaran memadan senarai butang BERSAUH.
    #
    #     Dan satu syarat penafian yang mengatasi ketiga-tiganya:
    #     larangan MUTLAK (PADAM / HAPUS / SELARAS PELESEN) tidak pernah
    #     boleh dibuka oleh bendera ini. Ia diperiksa DAHULU supaya
    #     skrin yang membawa kedua-dua jenis teks kekal disekat.
    if tetapan.mod_sebenar and konteks_mutasi:
        mutlak = None
        for t in teks:
            for nama, corak in MOD_SEBENAR_MUTLAK_DILARANG:
                if corak.search(t):
                    mutlak = (nama, t)
                    break
            if mutlak:
                break
        if mutlak is None:
            for t in teks:
                for nama, corak in MOD_SEBENAR_BUTANG.items():
                    if corak.match(t):
                        return Keputusan(
                            True,
                            f"MOD SEBENAR: butang {nama} dibenarkan dalam "
                            f"konteks {konteks_mutasi} (disahkan struktur "
                            f"dari tajuk app-bar)",
                            peraturan="MOD-SEBENAR", padanan=t, teks=teks)

    # 1d. KAD NAVIGASI skrin utama. Lihat KAD_NAVIGASI_UTAMA.
    #     Ia MEMBUKA menu, ia tidak menghantar apa-apa — dan tanpa ini
    #     H-001..003 mustahil dicapai kerana kad `Hantar` ialah
    #     satu-satunya jalan masuk.
    if konteks_navigasi:
        for t in teks:
            for corak in KAD_NAVIGASI_UTAMA:
                if corak.match(t):
                    return Keputusan(
                        True,
                        f"kad navigasi skrin utama: {t!r} — membuka menu, "
                        f"tidak menghantar apa-apa",
                        peraturan="NAV-MENU-UTAMA", padanan=t, teks=teks)

    # 2. Trip-wire. Satu pengecualian sahaja, dan ia sempit.
    for t in teks:
        if any(c.match(t) for c in KEMASKINI_BUKAN_REKOD):
            return Keputusan(True, f"semakan versi app, bukan kemaskini "
                                   f"rekod: {t!r}",
                             peraturan="KEMASKINI-VERSI", padanan=t,
                             teks=teks)
        for nama, corak in TRIPWIRE:
            if corak.search(t):
                # Dialog ralat/info asli yang DIKENAL PASTI: menutupnya
                # tidak menghantar apa-apa. Spesifikasi pemilik
                # membenarkan ini secara eksplisit, dengan syarat teks
                # penuh dilog dahulu — pemanggil melakukannya.
                #
                # Pengecualian ini terpakai kepada OK/YA SAHAJA. HANTAR,
                # SERAH, SAHKAN dan KEMASKINI tidak pernah muncul sebagai
                # butang dialog ralat, dan kalau ia muncul, dialog itu
                # bukan dialog ralat.
                if (alert_info and nama in ("OK", "YA")):
                    return Keputusan(
                        True,
                        f"{nama} dibenarkan: dialog ralat/info asli yang "
                        f"dikenali — {alert_info}",
                        peraturan=f"{nama}-ALERT-INFO", padanan=t,
                        teks=teks)
                return Keputusan(
                    False,
                    f"TRIP-WIRE {nama} — dilarang dalam SEMUA mod",
                    peraturan=nama, padanan=t, teks=teks)

    # 3. Selaras Maklumat Pelesen — dilarang mutlak, seperti trip-wire.
    #    Diletak di sini (selepas trip-wire, sebelum segalanya) supaya
    #    tiada bendera dan tiada konteks boleh membukanya.
    for t in teks:
        if PELESEN[1].search(t):
            return Keputusan(
                False,
                "SELARAS MAKLUMAT PELESEN disekat — arahan pemilik "
                "2026-08-07: sync 3-4 JAM, kecualikan sepenuhnya",
                peraturan=PELESEN[0], padanan=t, teks=teks)

    # 4. SERAH — bergantung mod.
    for t in teks:
        if SERAH[1].search(t):
            if not tetapan.benarkan_serah:
                return Keputusan(
                    False,
                    "SERAH disekat (MBPG_BENARKAN_SERAH=0, default pemilik)",
                    peraturan="SERAH", padanan=t, teks=teks)
            if tetapan.serah_digunakan >= 1:
                return Keputusan(
                    False,
                    "SERAH sudah digunakan sekali dalam TC ini — "
                    "kuota satu-per-TC habis",
                    peraturan="SERAH", padanan=t, teks=teks)
            tetapan.serah_digunakan += 1
            return Keputusan(
                True,
                "SERAH dibenarkan (MBPG_BENARKAN_SERAH=1, 1/1 kuota TC) — "
                "WAJIB diikuti screenshot popup + BATAL/TIDAK/back",
                peraturan="SERAH", padanan=t, teks=teks)

    # 5. SIMPAN — hanya dalam dua konteks yang disahkan berstruktur.
    for t in teks:
        if SIMPAN[1].search(t):
            if konteks_simpan == "bookmark":
                return Keputusan(
                    True,
                    "SIMPAN dibenarkan: konteks dialog bookmark disahkan "
                    "(simpanan LOKAL, tiada rekod dicipta)",
                    peraturan="SIMPAN", padanan=t, teks=teks)
            if konteks_simpan == "tetapan":
                return Keputusan(
                    True,
                    "SIMPAN dibenarkan: konteks skrin Tetapan disahkan "
                    "(config LOKAL device, bukan rekod production)",
                    peraturan="SIMPAN", padanan=t, teks=teks)
            return Keputusan(
                False,
                "SIMPAN disekat — bukan dialog bookmark, bukan skrin "
                "Tetapan",
                peraturan="SIMPAN", padanan=t, teks=teks)

    return Keputusan(True, "tiada peraturan memadan", teks=teks)


def konteks_bookmark(sumber_halaman):
    """True HANYA kalau skrin semasa benar-benar dialog nama bookmark.

    Ini satu-satunya pengecualian kepada sekatan SIMPAN, jadi ia diuji
    secara STRUKTUR dan bukan dengan padanan subrentetan. Tiga syarat,
    semuanya WAJIB:

      (a) tajuk "PILIHAN KEGEMARAN" hadir pada skrin;
      (b) sekurang-kurangnya satu bekas resource-id='modal-surface'
          hadir — bukti modal RN memang TERBUKA;
      (c) satu EditText berada DI DALAM modal-surface paling dalam.

    Syarat (c) yang menanggung beban sebenar. Bukti device (dump K9,
    pages/bookmark_page.py:199-208) menunjukkan borang PESALAH KEKAL
    dalam pokok di belakang popup dan membawa EditText sendiri. Ujian
    "ada EditText di suatu tempat pada skrin" oleh itu BENAR pada
    seluruh borang Daftar Kompaun — ia akan membuka SIMPAN di mana-mana
    sahaja, iaitu tepat lubang yang pengecualian ini tidak boleh ada.
    Sarangkan semakan itu ke dalam modal-surface dan ia menjadi tepat.

    Glif ikon buku (U+E866) SENGAJA BUKAN penanda: ikon itu hidup pada
    borang, bukan pada dialog, jadi ia benar sebelum dialog dibuka.

    Apa-apa yang tidak dapat dibaca => False => SIMPAN disekat.
    Gagal-tertutup.
    """
    if not sumber_halaman:
        return False
    try:
        akar = ET.fromstring(sumber_halaman)
    except (ET.ParseError, TypeError):
        return False

    if not any(TAJUK_BOOKMARK.search(n.get("text") or "")
               or TAJUK_BOOKMARK.search(n.get("content-desc") or "")
               for n in akar.iter()):
        return False

    surfaces = [n for n in akar.iter()
                if (n.get("resource-id") or "").endswith(MODAL_SURFACE_ID)]
    if not surfaces:
        return False

    # Modal boleh bersarang (fasa2-bootstrap.md 2.4: bilangan
    # modal-surface = kedalaman sarang). Yang AKTIF ialah yang paling
    # dalam, jadi ambil surface yang tidak mengandungi surface lain.
    def mengandungi_surface(n):
        return any(s is not n and s in list(n.iter()) for s in surfaces)

    paling_dalam = [s for s in surfaces if not mengandungi_surface(s)]
    for s in (paling_dalam or surfaces):
        for n in s.iter():
            if (n.get("class") or "") == "android.widget.EditText":
                return True
    return False


def konteks_tetapan(sumber_halaman):
    """True HANYA kalau skrin semasa ialah salah satu skrin Tetapan.

    Pengecualian kedua kepada sekatan SIMPAN, diluluskan pemilik
    2026-08-07 untuk T-001 / T-002 / T-010. Rasionalnya sempit dan
    penting: skrin-skrin ini menulis KONFIGURASI LOKAL pada peranti
    (alamat IP server, lesen aplikasi, pilihan skrin utama). Ia tidak
    mencipta, mengubah, atau menghantar rekod kompaun. SIMPAN di situ
    bukan penghantaran.

    Diuji secara STRUKTUR, seperti konteks_bookmark(), atas sebab yang
    sama: padanan teks longgar untuk 'Tetapan' akan memadan item menu,
    tajuk, dan breadcrumb pada skrin yang BUKAN skrin tetapan, lalu
    membuka SIMPAN di tempat yang tidak sepatutnya.

    Dua bentuk diterima:

      (a) Borang bermedan (T-001, T-002) — memerlukan KEDUA-DUA:
            - sekurang-kurangnya satu node resource-id
              'text-input-outlined', DAN
            - satu label sauh khusus skrin itu.
          Syarat kedua yang menanggung beban: skrin LOGIN turut
          menggunakan 'text-input-outlined' dan kekal dirender DI
          BELAKANG modal Tetapan, jadi id sahaja benar walaupun kita
          sebenarnya berada di skrin login.

      (b) Popup pilihan (T-010) — tajuk 'PILIHAN SKRIN UTAMA'. Popup ini
          tiada medan input langsung, jadi ujian (a) tidak terpakai.

    Apa-apa yang tidak dapat dibaca => False => SIMPAN disekat.
    """
    if not sumber_halaman:
        return False
    try:
        akar = ET.fromstring(sumber_halaman)
    except (ET.ParseError, TypeError):
        return False

    nod = list(akar.iter())

    def teks_semua():
        for n in nod:
            for atribut in ("text", "content-desc"):
                nilai_atribut = n.get(atribut) or ""
                if nilai_atribut:
                    yield nilai_atribut.upper()

    semua = list(teks_semua())

    if any(TETAPAN_TAJUK_SKRIN_UTAMA.search(t) for t in semua):
        return True

    ada_medan = any(TETAPAN_INPUT_ID in (n.get("resource-id") or "")
                    for n in nod)
    if not ada_medan:
        return False
    return any(sauh.search(t) for t in semua for sauh in TETAPAN_LABEL_SAUH)

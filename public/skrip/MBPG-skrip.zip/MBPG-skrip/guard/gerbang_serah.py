"""
GERBANG SERAH — empat lapisan, semua WAJIB benar.

Fasa C ialah satu-satunya laluan yang mencipta rekod SEBENAR pada
production MBPG. Modul ini ialah kunci pada laluan itu, dan ia direka
supaya keadaan LALAI menjadikan serah **mustahil** — bukan tidak
digalakkan, bukan diamarankan, mustahil.

    Lapisan 1  MBPG_DRY_RUN == "0"                (lalai "1")
    Lapisan 2  MBPG_IZIN_SERAH diisi  DAN  medan
               ISI-SINI dalam fail izin diisi     (lalai kosong)
    Lapisan 3  set_id ada dalam whitelist          (lalai KOSONG)
    Lapisan 4  kiraan serah < had N                (lalai N=0)
    Lapisan 5  izin BELUM LUPUT                    (lalai LUPUT)
    Lapisan 6  borang dibenarkan DAN kuota borang
               itu belum habis                     (lalai TIADA)

Semua enam mesti lulus. Satu gagal -> SerahTidakDiizinkan, dibangkit
SEBELUM sebarang tap dihantar ke peranti.

>>> KENAPA LAPISAN 5 DAN 6 DITAMBAH (arahan pemilik 2026-08-12). <<<
Lapisan 1-4 melindungi daripada serah yang tidak diluluskan. Ia TIDAK
melindungi daripada dua perkara yang benar-benar berlaku dalam projek
ini:

  izin tertinggal hidup   Fail kebenaran ditulis untuk satu petang
                          kekal sah selama-lamanya. Lapisan 5
                          menjadikan izin LUPUT pada tarikh yang
                          pemilik taip — semalam bukan hari ini.

  kuota bercampur         had_serah ialah SATU nombor untuk semua
                          borang, jadi had 3 membenarkan 3 Notis dan
                          sifar Kompaun. Lapisan 6 memberi setiap
                          borang kuotanya sendiri, jadi "satu setiap
                          satu" benar-benar bermakna satu setiap satu.

Kedua-duanya gagal ke arah DISEKAT bila medan tiada, sama seperti yang
lain.

>>> KENAPA BaseException. <<<
Sama seperti DryRunViolation: `pages/base_page.py` membawa 66 blok
`except Exception`, dan setiap gelung cuba-semula dibina atasnya. Kalau
penolakan serah ialah `Exception`, gelung itu menelannya dan mencuba
lagi — gerbang menolak setiap percubaan dengan betul sementara run
meneruskan seolah-olah tiada apa berlaku. `AssertionError` pun tidak
memadai (2 tapak menangkapnya).

>>> KENAPA GERBANG INI TIDAK MENGGANTIKAN CORONG. <<<
Ia berada DI ATASNYA. Corong tetap menilai setiap tap; SERAH dan
HANTAR kekal trip-wire di sana. Gerbang ini ialah kunci KEDUA:
walaupun corong dibuka untuk serah, laluan Fasa C masih perlu keempat
lapisan ini. Membuka satu tidak membuka yang lain.
"""

import json
import os

# Nilai yang fail izin dihantar dengan sengaja supaya ia TIDAK berfungsi
# sehingga seseorang menaip ganti dengan tangan.
PLACEHOLDER = "ISI-SINI"

# Medan yang WAJIB diisi manual sebelum serah boleh berlaku.
MEDAN_WAJIB = ("disahkan_oleh", "rujukan_kelulusan")

FAIL_IZIN = "fasa_c_izin.json"


class SerahTidakDiizinkan(BaseException):
    """Serah cuba berlaku tanpa keempat-empat lapisan lulus.

    BaseException — lihat nota modul. Ia mesti membunuh run, bukan
    ditelan oleh gelung cuba-semula.
    """


class Izin:
    """Keadaan kebenaran, dibaca dari persekitaran + fail izin.

    Tidak pernah dibina daripada nilai lalai yang membenarkan apa-apa.
    Setiap medan yang hilang bermakna DISEKAT.
    """

    def __init__(self, dry_run_mati=False, token="", medan=None,
                 whitelist=(), had=0, sah_sehingga="", borang=(),
                 kuota=None):
        self.dry_run_mati = bool(dry_run_mati)
        self.token = (token or "").strip()
        self.medan = dict(medan or {})
        self.whitelist = tuple(whitelist or ())
        self.had = int(had or 0)
        self.sah_sehingga = (sah_sehingga or "").strip()
        self.borang = tuple(borang or ())
        self.kuota = dict(kuota or {})

    def luput(self, hari_ini=None):
        """(sudah_luput, sebab). Tiada tarikh -> LUPUT."""
        import datetime
        hari_ini = hari_ini or datetime.date.today().isoformat()
        t = self.sah_sehingga
        if not t or PLACEHOLDER in t.upper():
            return True, "tarikh sah_sehingga tidak diisi"
        try:
            datetime.date.fromisoformat(t)
        except ValueError:
            # Tarikh yang tidak boleh dihurai TIDAK dianggap sah.
            # Menganggapnya sah bermakna satu salah taip membuka izin
            # selama-lamanya.
            return True, f"sah_sehingga {t!r} bukan tarikh YYYY-MM-DD"
        if t < hari_ini:
            return True, f"izin luput {t}, hari ini {hari_ini}"
        return False, ""

    # -- pembinaan ------------------------------------------------------
    @classmethod
    def dari_persekitaran(cls, akar=None, env=None):
        env = os.environ if env is None else env
        akar = akar or os.path.dirname(os.path.dirname(
            os.path.abspath(__file__)))
        laluan = os.path.join(akar, FAIL_IZIN)

        data = {}
        try:
            with open(laluan, encoding="utf-8") as fh:
                data = json.load(fh)
        except (OSError, ValueError):
            # Fail tiada atau rosak -> tiada kebenaran. Itu keadaan
            # LALAI repo ini, dan ia disengajakan.
            data = {}

        # >>> TIADA .strip() PADA NILAI INI, DENGAN SENGAJA. <<<
        # Padanan mesti TEPAT "0". Ruang tersasar (`set MBPG_DRY_RUN=0 `
        # mudah berlaku pada Windows) akan membuka kunci kalau kami
        # memangkasnya — kegagalan senyap ke arah BAHAYA.
        #
        # Tanpa pangkas, ruang tersasar mengekalkan kunci dan
        # `--diagnosis` memaparkannya sebagai KUNCI. Itu kegagalan ke
        # arah SELAMAT, dan ia kelihatan.
        return cls(
            dry_run_mati=(env.get("MBPG_DRY_RUN", "1") == "0"),
            token=env.get("MBPG_IZIN_SERAH", ""),
            medan={k: data.get(k, "") for k in MEDAN_WAJIB},
            whitelist=tuple(data.get("whitelist_set") or ()),
            had=data.get("had_serah", 0),
            sah_sehingga=data.get("sah_sehingga", ""),
            borang=tuple(data.get("borang_dibenarkan") or ()),
            kuota=data.get("kuota") or {},
        )


def _medan_diisi(nilai):
    """Medan dikira DIISI hanya kalau ia bukan kosong dan bukan lagi
    pemegang tempat. 'ISI-SINI' yang tidak disentuh ialah tanda paling
    jelas bahawa tiada manusia melihatnya."""
    t = (nilai or "").strip()
    return bool(t) and PLACEHOLDER not in t.upper()


def semak(izin, set_id, kiraan_semasa, borang=None,
          kiraan_borang=0, hari_ini=None):
    """Lulus senyap, atau bangkitkan SerahTidakDiizinkan.

    Setiap lapisan diperiksa dan lapisan yang GAGAL dinamakan dalam
    mesej — laluan yang ditolak tanpa sebab ialah kebuntuan yang tiada
    siapa boleh nyahsulit.

    Semua empat lapisan diperiksa mengikut urutan, dan yang PERTAMA
    gagal menghentikannya. Itu disengajakan: mesej menunjuk kepada satu
    perkara untuk dibetulkan, bukan senarai.
    """
    if not izin.dry_run_mati:
        raise SerahTidakDiizinkan(
            "LAPISAN 1 GAGAL — MBPG_DRY_RUN bukan '0'. Mod dry-run masih "
            "aktif; tiada serah boleh berlaku. (lalai: '1')")

    if not izin.token:
        raise SerahTidakDiizinkan(
            "LAPISAN 2 GAGAL — MBPG_IZIN_SERAH kosong. Token kebenaran "
            "mesti diisi oleh pemilik pada masa run, bukan disimpan "
            "dalam repo.")

    hilang = [k for k in MEDAN_WAJIB if not _medan_diisi(izin.medan.get(k))]
    if hilang:
        raise SerahTidakDiizinkan(
            f"LAPISAN 2 GAGAL — medan {', '.join(hilang)} dalam "
            f"{FAIL_IZIN} masih kosong atau masih '{PLACEHOLDER}'. "
            f"Ia mesti ditaip dengan tangan: siapa yang mengesahkan, "
            f"dan rujukan kelulusan bertulis PM+MBPG.")

    if not izin.whitelist:
        raise SerahTidakDiizinkan(
            "LAPISAN 3 GAGAL — whitelist_set KOSONG. Tiada satu set pun "
            "diluluskan untuk diserah. MBPG mesti menamakan set yang "
            "dibenarkan; senarai kosong bermakna TIADA.")

    if set_id not in izin.whitelist:
        raise SerahTidakDiizinkan(
            f"LAPISAN 3 GAGAL — set {set_id!r} TIADA dalam whitelist "
            f"({len(izin.whitelist)} set diluluskan). Set yang tidak "
            f"dinamakan MBPG tidak boleh diserah.")

    if izin.had <= 0:
        raise SerahTidakDiizinkan(
            "LAPISAN 4 GAGAL — had_serah ialah 0. Had keras mesti "
            "ditetapkan kepada bilangan rekod yang MBPG benarkan untuk "
            "run ini.")

    if kiraan_semasa >= izin.had:
        raise SerahTidakDiizinkan(
            f"LAPISAN 4 GAGAL — had {izin.had} rekod sudah dicapai "
            f"({kiraan_semasa} diserah). Run mesti berhenti, bukan "
            f"meneruskan.")

    sudah_luput, sebab = izin.luput(hari_ini)
    if sudah_luput:
        raise SerahTidakDiizinkan(
            f"LAPISAN 5 GAGAL — {sebab}. Izin serah sah untuk SATU hari "
            f"sahaja; pemilik mesti menaip semula tarikh untuk setiap "
            f"sesi. Fail kebenaran yang tertinggal hidup ialah cara "
            f"serah tanpa kebenaran berlaku.")

    if borang is not None:
        if not izin.borang:
            raise SerahTidakDiizinkan(
                "LAPISAN 6 GAGAL — borang_dibenarkan KOSONG. Tiada jenis "
                "borang diluluskan untuk diserah.")
        if borang not in izin.borang:
            raise SerahTidakDiizinkan(
                f"LAPISAN 6 GAGAL — borang {borang!r} tidak diluluskan "
                f"(dibenarkan: {', '.join(izin.borang)}).")
        had_borang = int(izin.kuota.get(borang, 0) or 0)
        if had_borang <= 0:
            raise SerahTidakDiizinkan(
                f"LAPISAN 6 GAGAL — kuota untuk borang {borang!r} ialah "
                f"0. Setiap borang mesti diberi kuotanya sendiri; tiada "
                f"kuota bermakna TIADA.")
        if (kiraan_borang or 0) >= had_borang:
            raise SerahTidakDiizinkan(
                f"LAPISAN 6 GAGAL — kuota borang {borang!r} habis "
                f"({kiraan_borang}/{had_borang}). Had satu borang tidak "
                f"boleh dipinjam untuk borang lain.")

    return True


def diagnosis(izin):
    """Ringkasan boleh-baca keadaan setiap lapisan. Untuk log dan
    laporan — TIADA kesan pada keputusan."""
    hilang = [k for k in MEDAN_WAJIB if not _medan_diisi(izin.medan.get(k))]
    sudah_luput, sebab_luput = izin.luput()
    kuota_ok = bool(izin.borang) and all(
        int(izin.kuota.get(b, 0) or 0) > 0 for b in izin.borang)
    return {
        "lapisan_1_dry_run_mati": izin.dry_run_mati,
        "lapisan_2_token_diisi": bool(izin.token),
        "lapisan_2_medan_diisi": not hilang,
        "lapisan_3_whitelist": len(izin.whitelist),
        "lapisan_4_had": izin.had,
        "lapisan_5_belum_luput": not sudah_luput,
        "lapisan_5_sebab": sebab_luput or "sah",
        "lapisan_6_borang": list(izin.borang),
        "lapisan_6_kuota": dict(izin.kuota),
        "serah_mungkin": (izin.dry_run_mati and bool(izin.token)
                          and not hilang and bool(izin.whitelist)
                          and izin.had > 0 and not sudah_luput
                          and kuota_ok),
    }

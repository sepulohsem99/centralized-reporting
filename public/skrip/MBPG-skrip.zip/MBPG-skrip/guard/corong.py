"""
CORONG TAP — satu-satunya pintu keluar ke peranti.

MASALAH
-------
Kod pages\\ mewarisi 77 tapak panggilan tap yang berselerak merentas tiga
primitif berbeza: `el.click()`, `driver.tap([(x, y)])`, dan
`execute_script('mobile: clickGesture', ...)`. Menampal setiap satu
bermakna 77 peluang untuk terlepas satu — dan suntingan akan datang boleh
menambah yang ke-78 tanpa sesiapa perasan bahawa ia memintas gerbang.

Pada suite biasa itu hutang teknikal. Pada suite yang memandu PRODUCTION
majlis, tapak panggilan yang terlepas ialah kompaun sebenar.

PENYELESAIAN
------------
Jangan tampal tapak panggilan. Bungkus OBJEK.

`pasang(driver)` memulangkan proksi yang membungkus sesi Appium. Proksi
itu memintas:
    - find_element / find_elements   -> memulangkan ElemenBerkawal
    - tap(...)                       -> ujian-kena koordinat pada XML
    - execute_script('mobile: *Click*Gesture')
    - press_keycode(ENTER / DPAD_CENTER)

ElemenBerkawal memintas `.click()` dan meneruskan semua yang lain tanpa
disentuh (.text, .rect, .send_keys, .clear, .get_attribute…). Ia turut
membungkus find_element/find_elements bersarangnya sendiri, supaya elemen
anak tidak pernah keluar tanpa kawalan.

Ikutannya: kod pages\\ tidak perlu tahu gerbang ini wujud, dan tapak
panggilan ke-78 dilindungi pada hari ia ditulis. Tiada pilihan-serta,
maka tiada terlepas-serta.

APA YANG CORONG INI TIDAK LINDUNGI (dinyatakan jujur)
-----------------------------------------------------
  - `adb shell input tap` yang dipanggil melalui subprocess memintas
    Appium sepenuhnya. Tiada dalam pages\\ hari ini; carian
    penerimaan dalam tests\\test_guard_corong.py menguatkuasakannya.
  - Interaksi manusia pada skrin peranti semasa run.
  - Auto-submit sisi-app yang dicetuskan oleh IME "done" pada medan teks
    terakhir. KEYCODE_ENTER dikawal; kalau app menghantar sendiri tanpa
    keycode, hanya post-check Senarai Kompaun akan mengesannya.
"""

import json
import os
import re
import time
import traceback
import xml.etree.ElementTree as ET

from . import dasar
from .dasar import DryRunViolation, GuardTidakPasti


_BOUNDS = re.compile(r"\[(-?\d+),(-?\d+)\]\[(-?\d+),(-?\d+)\]")

# Keycode yang boleh mencetuskan penyerahan borang. Dinilai melalui dasar
# terhadap medan yang sedang fokus, bukan disekat terus — KEYCODE_ENTER
# yang sah digunakan untuk menutup papan kekunci IME.
KEYCODE_BAHAYA = {66: "KEYCODE_ENTER", 23: "KEYCODE_DPAD_CENTER"}

# Gerak isyarat mobile: yang menghasilkan tap sebenar.
_GESTURE_TAP = re.compile(r"mobile:\s*(click|doubleClick|longClick)Gesture", re.I)


class Corong:
    """Keadaan bersama satu run: tetapan, ledger, dan bendera batal."""

    def __init__(self, tetapan, dir_reports, cache_ttl=0.4):
        self.tetapan = tetapan
        self.dir_reports = dir_reports
        self.dir_forensik = os.path.join(dir_reports, "forensik")
        self.laluan_ledger = os.path.join(dir_reports, "tap_ledger.jsonl")
        self.dibatalkan = None          # sebab, kalau run sudah dibatalkan
        self.tc_semasa = "(tiada)"
        self.bil_tap = 0
        self.bil_sekat = 0
        self._cache_ttl = cache_ttl
        self._cache_src = None
        self._cache_masa = 0.0
        os.makedirs(self.dir_forensik, exist_ok=True)

    # -- sumber halaman, dicache pendek ---------------------------------
    #
    # tap_element() melakukan find -> baca rect -> driver.tap() dalam
    # beberapa milisaat. Tanpa cache, satu tap logik memuat turun XML
    # skrin penuh dua kali. TTL sengaja pendek (0.4s): lebih panjang dan
    # kita berisiko menguji-kena terhadap skrin yang SUDAH berubah, yang
    # bermakna menilai dasar terhadap butang yang salah.
    def sumber_halaman(self, driver, paksa=False):
        sekarang = time.time()
        if (not paksa and self._cache_src is not None
                and sekarang - self._cache_masa < self._cache_ttl):
            return self._cache_src
        src = driver.page_source
        self._cache_src = src
        self._cache_masa = sekarang
        return src

    def batalkan_cache(self):
        self._cache_src = None

    # -- ledger ---------------------------------------------------------
    def catat(self, keputusan, asal, extra=None):
        baris = {
            "masa": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "tc": self.tc_semasa,
            "asal": asal,                     # click / tap / gesture / keycode
            "benarkan": keputusan.benarkan,
            "peraturan": keputusan.peraturan,
            "padanan": keputusan.padanan,
            "sebab": keputusan.sebab,
            "teks": list(keputusan.teks)[:12],
        }
        if extra:
            baris.update(extra)
        try:
            with open(self.laluan_ledger, "a", encoding="utf-8") as fh:
                fh.write(json.dumps(baris, ensure_ascii=False) + "\n")
        except OSError:
            pass      # ledger ialah bukti, bukan gerbang: jangan gagalkan run

    # -- penguatkuasa ---------------------------------------------------
    def kuatkuasa(self, keputusan, driver, asal, extra=None):
        self.bil_tap += 1
        self.catat(keputusan, asal, extra)
        if keputusan.benarkan:
            if keputusan.peraturan in ("SERAH", "SIMPAN"):
                print(f"  [GUARD] {keputusan.peraturan} DIBENARKAN — "
                      f"{keputusan.sebab}")
            return
        self.bil_sekat += 1
        self.dibatalkan = f"{keputusan.peraturan}: {keputusan.padanan!r}"
        laluan = self.forensik(driver, keputusan, extra)
        raise DryRunViolation(
            f"\n"
            f"  ══════════ PELANGGARAN DRY-RUN — RUN DIBATALKAN ══════════\n"
            f"  TC        : {self.tc_semasa}\n"
            f"  Peraturan : {keputusan.peraturan}\n"
            f"  Padanan   : {keputusan.padanan!r}\n"
            f"  Sebab     : {keputusan.sebab}\n"
            f"  Laluan tap: {asal}\n"
            f"  Teks sasaran dipungut: {list(keputusan.teks)[:8]}\n"
            f"  Forensik  : {laluan}\n"
            f"  Tap ini TIDAK dihantar ke peranti. Tiada apa ditekan.\n"
            f"  ═══════════════════════════════════════════════════════════"
        )

    def semak_dibatalkan(self):
        if self.dibatalkan:
            raise DryRunViolation(
                f"Run sudah DIBATALKAN oleh pelanggaran terdahulu "
                f"({self.dibatalkan}). Tiada tap selanjutnya dibenarkan. "
                f"Mulakan sesi baharu selepas punca difahami.")

    # -- forensik -------------------------------------------------------
    def forensik(self, driver, keputusan, extra=None):
        cap = time.strftime("%Y%m%d-%H%M%S")
        tc = re.sub(r"[^A-Za-z0-9_-]", "_", str(self.tc_semasa))
        asas = os.path.join(self.dir_forensik, f"{cap}_{tc}_{keputusan.peraturan}")
        tulis = []
        try:
            driver.get_screenshot_as_file(asas + ".png")
            tulis.append(asas + ".png")
        except Exception as e:                                  # noqa: BLE001
            tulis.append(f"(screenshot gagal: {e})")
        try:
            with open(asas + ".xml", "w", encoding="utf-8") as fh:
                fh.write(self.sumber_halaman(driver, paksa=True))
            tulis.append(asas + ".xml")
        except Exception as e:                                  # noqa: BLE001
            tulis.append(f"(page_source gagal: {e})")
        try:
            with open(asas + ".txt", "w", encoding="utf-8") as fh:
                fh.write(f"TC        : {self.tc_semasa}\n")
                fh.write(f"Peraturan : {keputusan.peraturan}\n")
                fh.write(f"Padanan   : {keputusan.padanan!r}\n")
                fh.write(f"Sebab     : {keputusan.sebab}\n")
                fh.write(f"Tetapan   : {self.tetapan!r}\n")
                fh.write(f"Extra     : {extra!r}\n")
                fh.write(f"Teks      : {list(keputusan.teks)!r}\n\n")
                fh.write("Surih tindanan pemanggil:\n")
                fh.write("".join(traceback.format_stack()))
            tulis.append(asas + ".txt")
        except OSError:
            pass
        return " | ".join(tulis)


# ---------------------------------------------------------------------------
# Ujian-kena koordinat terhadap XML skrin
# ---------------------------------------------------------------------------

def _kotak(node):
    m = _BOUNDS.match(node.get("bounds", "") or "")
    if not m:
        return None
    x1, y1, x2, y2 = (int(v) for v in m.groups())
    return x1, y1, x2, y2


def _teks_node(node):
    for atribut in ("text", "content-desc"):
        nilai = (node.get(atribut) or "").strip()
        if nilai:
            yield nilai


def teks_di_koordinat(sumber, x, y):
    """Setiap rentetan yang boleh mewakili apa yang duduk di (x, y).

    Memilih node TERDALAM (luas terkecil) yang mengandungi titik itu,
    kemudian memungut teksnya dan teks semua keturunannya.

    Kalau node terdalam itu sendiri tiada teks — corak biasa React Native,
    di mana kawasan yang boleh disentuh ialah View kosong — kita naik
    kepada moyang terdekat yang clickable="true" dan memungut dari sana.
    Tanpa langkah naik itu, sasaran tap yang dinamakan oleh anaknya
    (butang HANTAR yang labelnya satu TextView bersarang) akan dibaca
    sebagai "tiada teks" dan dibenarkan.

    Memulangkan (senarai_teks, jumpa) — `jumpa` False bermakna tiada node
    langsung mengandungi titik itu, yang pemanggil mesti layan sebagai
    TIDAK PASTI dan bukan sebagai selamat.
    """
    try:
        akar = ET.fromstring(sumber)
    except ET.ParseError:
        return [], False

    ibu = {}
    calon = []          # (luas, node)
    tindanan = [akar]
    while tindanan:
        n = tindanan.pop()
        for anak in list(n):
            ibu[anak] = n
            tindanan.append(anak)
        k = _kotak(n)
        if k and k[0] <= x <= k[2] and k[1] <= y <= k[3]:
            calon.append(((k[2] - k[0]) * (k[3] - k[1]), n))

    if not calon:
        return [], False

    # Kumpul teks daripada SETIAP node yang mengandungi titik itu —
    # tidak lebih.
    #
    # >>> DIBETULKAN 2026-08-10 selepas positif palsu pada device. <<<
    # Versi sebelum ini memilih node TERDALAM lalu memungut teks daripada
    # SEMUA keturunannya. Itu salah apabila node terdalam ialah bekas
    # besar. Kes sebenar: menutup modal Menu Selaras mengetuk backdrop
    # pada (540,2076). Node terdalam di situ ialah butang backdrop
    # skrin-penuh; keturunannya termasuk SETIAP item menu, salah satunya
    # "Semak Kemaskini Versi Terkini" — jadi corong menyekat penutupan
    # modal yang tidak berbahaya sebagai pelanggaran trip-wire KEMASKINI.
    #
    # Item menu itu berada pada y 669..1761. Titik tap y=2076. Ia tidak
    # pernah berada "di bawah" tap itu. Menapis ikut pembendungan
    # menghasilkan ['Close modal'] — apa yang sebenarnya diketuk.
    #
    # Ini menjadikan gerbang LEBIH tepat, bukan lebih longgar: label
    # butang sebenar bertindih dengan butangnya, jadi ia masih dipungut.
    calon.sort(key=lambda t: t[0])

    # >>> TAPIS IKUT MODAL TERATAS — 2026-08-10, positif palsu ke-2. <<<
    # React Native MENGEKALKAN skrin di belakang modal dalam pokok
    # accessibility. Node itu masih "mengandungi" titik tap secara
    # geometri, tetapi ia BUKAN yang diketuk — modal di hadapannya yang
    # menerima sentuhan.
    #
    # Kes sebenar: T-001 mengetuk SIMPAN pada (540,1431). Dua
    # modal-surface bersarang terbuka —
    #     [78,588][1002,1836]  Menu Selaras      (belakang)
    #     [78,861][1002,1563]  Tetapan Alamat IP (hadapan, ada SIMPAN)
    # Titik itu berada dalam KEDUA-DUANYA, jadi pungutan mentah melihat
    # baris "Selaras Maklumat Pelesen" di belakang dan membatalkan run
    # atas ketukan SIMPAN yang sah sepenuhnya.
    #
    # Peraturan: kalau titik berada dalam mana-mana modal-surface, hanya
    # kandungan surface PALING DALAM yang dikira. Kalau titik berada di
    # LUAR setiap surface (cth backdrop), hanya node yang BUKAN dalam
    # mana-mana surface dikira — itu yang menjadikan tap backdrop
    # menghasilkan 'Close modal' dan bukan seluruh menu.
    surfaces = [n for n in akar.iter()
                if (n.get("resource-id") or "").endswith(
                    dasar.MODAL_SURFACE_ID)]

    def dalam_surface(n):
        """modal-surface terdalam yang mengandungi node n, atau None."""
        p, terakhir = n, None
        while p is not None:
            if p in surfaces_set:
                terakhir = p
                break
            p = ibu.get(p)
        return terakhir

    surfaces_set = set(surfaces)
    if surfaces:
        memuat = [s for s in surfaces
                  if (lambda k: k and k[0] <= x <= k[2] and k[1] <= y <= k[3])(
                      _kotak(s))]
        if memuat:
            # Paling dalam = luas terkecil antara yang memuat titik.
            memuat.sort(key=lambda s: (lambda k: (k[2] - k[0]) * (k[3] - k[1]))(
                _kotak(s)))
            teratas = memuat[0]
            benarkan = set(teratas.iter())
            calon = [(l, n) for l, n in calon if n in benarkan]
        else:
            calon = [(l, n) for l, n in calon if dalam_surface(n) is None]

    teks = []
    for _luas, n in calon:
        for t in _teks_node(n):
            if t not in teks:
                teks.append(t)

    if not teks:
        # Bekas boleh-sentuh tanpa label bertindih: ambil teks moyang
        # boleh-klik TERDEKAT SAHAJA — bukan subpokoknya, atas sebab yang
        # sama seperti di atas.
        naik = calon[0][1]
        for _ in range(6):
            naik = ibu.get(naik)
            if naik is None:
                break
            if (naik.get("clickable") or "").lower() == "true":
                teks = list(_teks_node(naik))
                break
    return teks, True


# ---------------------------------------------------------------------------
# Pengumpul teks untuk elemen
# ---------------------------------------------------------------------------

def teks_elemen(el, corong, driver):
    """Setiap rentetan yang boleh mewakili elemen `el`.

    Laluan pantas dahulu (.text / content-desc, satu panggilan setiap
    satu). Kalau kedua-duanya kosong, elemen itu mungkin bekas RN yang
    labelnya berada pada anaknya — jatuh balik kepada ujian-kena XML pada
    pusatnya, yang memungut keturunan tanpa N panggilan Appium.

    Memulangkan (senarai_teks, pasti). `pasti` False bermakna kami tidak
    dapat membaca elemen langsung.
    """
    teks = []
    try:
        t = (el.text or "").strip()
        if t:
            teks.append(t)
    except Exception:                                           # noqa: BLE001
        pass
    for atribut in ("content-desc", "contentDescription"):
        try:
            v = (el.get_attribute(atribut) or "").strip()
            if v and v not in teks:
                teks.append(v)
        except Exception:                                       # noqa: BLE001
            pass

    if teks:
        return teks, True

    try:
        r = el.rect
        cx = r["x"] + r["width"] // 2
        cy = r["y"] + r["height"] // 2
    except Exception:                                           # noqa: BLE001
        # Elemen basi/hilang. Tap terhadapnya akan gagal dengan
        # sendirinya sebelum menyentuh peranti, jadi ini BUKAN kes
        # tidak-pasti yang berbahaya.
        return [], True

    src = corong.sumber_halaman(driver)
    teks_xml, jumpa = teks_di_koordinat(src, cx, cy)
    return teks_xml, jumpa


# ---------------------------------------------------------------------------
# Proksi
# ---------------------------------------------------------------------------

class ElemenBerkawal:
    """Proksi WebElement. Memintas click(); meneruskan yang lain."""

    __slots__ = ("_el", "_corong", "_driver")

    def __init__(self, el, corong, driver):
        object.__setattr__(self, "_el", el)
        object.__setattr__(self, "_corong", corong)
        object.__setattr__(self, "_driver", driver)

    # -- yang dipintas --
    def click(self):
        _nilai_dan_kuatkuasa_elemen(self._el, self._corong, self._driver,
                                    asal="el.click")
        return self._el.click()

    def find_element(self, *a, **kw):
        return ElemenBerkawal(self._el.find_element(*a, **kw),
                              self._corong, self._driver)

    def find_elements(self, *a, **kw):
        return [ElemenBerkawal(e, self._corong, self._driver)
                for e in self._el.find_elements(*a, **kw)]

    # -- terus lulus --
    def __getattr__(self, nama):
        return getattr(object.__getattribute__(self, "_el"), nama)

    def __setattr__(self, nama, nilai):
        setattr(object.__getattribute__(self, "_el"), nama, nilai)

    def __eq__(self, lain):
        lain = getattr(lain, "_el", lain)
        return self._el == lain

    def __hash__(self):
        return hash(self._el)

    def __repr__(self):
        return f"<Berkawal {self._el!r}>"

    @property
    def asli(self):
        """WebElement yang tidak dibungkus — untuk kod yang benar-benar
        memerlukan objek Selenium sebenar. Tiada apa dalam pages\\
        memerlukannya hari ini."""
        return self._el


def _nilai_dan_kuatkuasa_elemen(el, corong, driver, asal):
    corong.semak_dibatalkan()
    teks, pasti = teks_elemen(el, corong, driver)
    if not pasti:
        # Kami memegang elemen tetapi tidak dapat meletakkannya pada
        # skrin. Pada production itu tap buta.
        kep = dasar.Keputusan(False, "sasaran tap TIDAK dapat dileraikan "
                                     "(elemen tidak dijumpai dalam XML skrin)",
                              peraturan="TIDAK-PASTI", padanan=None, teks=teks)
        corong.kuatkuasa(kep, driver, asal)
        return
    _alert_ok, _badan = _konteks_alert(corong, driver, teks)
    kep = dasar.nilai(teks, corong.tetapan,
                      konteks_simpan=_konteks_simpan(corong, driver, teks),
                      alert_info=_badan if _alert_ok else None,
                      konteks_mutasi=_konteks_mutasi(corong, driver, teks),
                      konteks_navigasi=_konteks_navigasi(corong, driver, teks))
    if _badan:
        kep.sebab += f"   [dialog: {_badan}]"
    corong.kuatkuasa(kep, driver, asal)


def _konteks_alert(corong, driver, teks, src=None):
    """(alert_dibenarkan, badan_dialog) — dikira sekali, dikongsi semua
    laluan tap.

    Hanya melihat sumber halaman apabila sasaran tap benar-benar OK/YA;
    selainnya percuma.

    Badan dialog dipulangkan walaupun ia TIDAK dibenarkan, supaya
    kuatkuasa() boleh melognya. Dialog baharu yang tidak dikenali mesti
    muncul dalam ledger dengan teks penuhnya — kalau tidak, ia menjadi
    kebuntuan yang tiada siapa boleh nyahsulit.
    """
    if not any(re.match(r"^\s*(OK|YA)\s*$", t, re.I) for t in teks):
        return False, ""
    if src is None:
        src = corong.sumber_halaman(driver)
    return dasar.konteks_alert_info(src)


def _konteks_simpan(corong, driver, teks, src=None):
    """Konteks mana (kalau ada) yang membenarkan SIMPAN pada skrin ini.

    Dikira di SATU tempat sahaja supaya kelima-lima laluan tap tidak
    boleh menyimpang antara satu sama lain — pengecualian SIMPAN yang
    berbeza mengikut laluan tap ialah tepat jenis lubang yang gerbang
    ini wujud untuk menutup.

    Sumber halaman hanya diambil apabila SIMPAN benar-benar terlibat;
    kalau tidak ini percuma.
    """
    if not any(dasar.SIMPAN[1].search(t) for t in teks):
        return None
    if src is None:
        src = corong.sumber_halaman(driver)
    if dasar.konteks_bookmark(src):
        return "bookmark"
    if dasar.konteks_tetapan(src):
        return "tetapan"
    return None


def _konteks_navigasi(corong, driver, teks, src=None):
    """True kalau tap ini ialah kad navigasi pada skrin utama.

    Litar pintas: hanya membaca XML apabila teks sasaran benar-benar
    memadan salah satu daripada lima label kad. Selainnya percuma.
    """
    if not any(c.match(t) for t in teks
               for c in dasar.KAD_NAVIGASI_UTAMA):
        return False
    if src is None:
        src = corong.sumber_halaman(driver)
    return dasar.konteks_menu_utama(src)


def _konteks_mutasi(corong, driver, teks, src=None):
    """Nama skrin yang membenarkan MOD SEBENAR, atau None.

    Dikira di SATU tempat sahaja, atas sebab yang sama seperti
    `_konteks_simpan()`: lima laluan tap yang mengira konteks secara
    berasingan akan menyimpang, dan konteks mutasi yang menyimpang
    ialah lubang yang tepat sama seperti pengecualian SIMPAN yang
    menyimpang — cuma taruhannya lebih tinggi, kerana ia mencipta rekod
    dan bukan menyimpan konfigurasi.

    DUA litar pintas, kedua-duanya menjadikan ini percuma dalam mod
    lalai:
      - bendera induk mati  -> None tanpa membaca apa-apa;
      - tiada teks sasaran memadan butang mutasi -> None tanpa
        memuat turun XML skrin.
    """
    if not getattr(corong.tetapan, "mod_sebenar", False):
        return None
    if not any(c.match(t) for t in teks
               for c in dasar.MOD_SEBENAR_BUTANG.values()):
        return None
    if src is None:
        src = corong.sumber_halaman(driver)
    return dasar.konteks_mod_sebenar(src)


def _mungkin_simpan(teks):
    """Elak memuat turun XML skrin melainkan SIMPAN benar-benar terlibat.
    Konteks bookmark ialah satu-satunya semakan yang memerlukannya, dan ia
    hanya relevan apabila salah satu teks memadan SIMPAN."""
    return any(dasar.SIMPAN[1].search(t) for t in teks)


class DriverBerkawal:
    """Proksi sesi Appium. Memintas setiap primitif tap."""

    def __init__(self, driver, corong):
        object.__setattr__(self, "_drv", driver)
        object.__setattr__(self, "_corong", corong)

    # -- pencarian elemen: semua keluar dibungkus --
    def find_element(self, *a, **kw):
        return ElemenBerkawal(self._drv.find_element(*a, **kw),
                              self._corong, self)

    def find_elements(self, *a, **kw):
        return [ElemenBerkawal(e, self._corong, self)
                for e in self._drv.find_elements(*a, **kw)]

    # -- tap koordinat --
    def tap(self, positions, duration=None):
        c = self._corong
        c.semak_dibatalkan()
        for (x, y) in positions:
            src = c.sumber_halaman(self._drv)
            teks, jumpa = teks_di_koordinat(src, x, y)
            if not jumpa:
                kep = dasar.Keputusan(
                    False,
                    f"tiada node dalam XML skrin mengandungi ({x},{y}) — "
                    f"tap koordinat buta pada production",
                    peraturan="TIDAK-PASTI", teks=teks)
                c.kuatkuasa(kep, self._drv, "driver.tap", {"x": x, "y": y})
            kep = dasar.nilai(
                teks, c.tetapan,
                konteks_simpan=_konteks_simpan(c, self._drv, teks, src),
                konteks_mutasi=_konteks_mutasi(c, self._drv, teks, src),
                konteks_navigasi=_konteks_navigasi(c, self._drv, teks, src))
            c.kuatkuasa(kep, self._drv, "driver.tap", {"x": x, "y": y})
        c.batalkan_cache()
        if duration is None:
            return self._drv.tap(positions)
        return self._drv.tap(positions, duration)

    # -- gerak isyarat mobile: --
    def execute_script(self, script, *args):
        c = self._corong
        if isinstance(script, str) and _GESTURE_TAP.search(script):
            c.semak_dibatalkan()
            hujah = args[0] if args else {}
            hujah = hujah if isinstance(hujah, dict) else {}
            eid = hujah.get("elementId") or hujah.get("element")
            if eid is not None:
                # Gerak isyarat berasaskan elemen: leraikan melalui elemen.
                el = _cari_ikut_id(self._drv, eid)
                if el is not None:
                    _nilai_dan_kuatkuasa_elemen(el, c, self._drv,
                                                asal="clickGesture(el)")
                else:
                    kep = dasar.Keputusan(
                        False, f"clickGesture merujuk elementId {eid!r} yang "
                               f"tidak dapat dileraikan",
                        peraturan="TIDAK-PASTI")
                    c.kuatkuasa(kep, self._drv, "clickGesture(el)")
            else:
                x, y = hujah.get("x"), hujah.get("y")
                if x is None or y is None:
                    kep = dasar.Keputusan(
                        False, "clickGesture tanpa elementId dan tanpa (x,y) "
                               "— sasaran tidak diketahui",
                        peraturan="TIDAK-PASTI")
                    c.kuatkuasa(kep, self._drv, "clickGesture(xy)")
                src = c.sumber_halaman(self._drv)
                teks, jumpa = teks_di_koordinat(src, x, y)
                if not jumpa:
                    kep = dasar.Keputusan(
                        False, f"clickGesture pada ({x},{y}) tidak memadan "
                               f"mana-mana node XML",
                        peraturan="TIDAK-PASTI", teks=teks)
                    c.kuatkuasa(kep, self._drv, "clickGesture(xy)",
                                {"x": x, "y": y})
                kep = dasar.nilai(
                    teks, c.tetapan,
                    konteks_simpan=_konteks_simpan(c, self._drv, teks, src),
                    konteks_mutasi=_konteks_mutasi(c, self._drv, teks, src),
                konteks_navigasi=_konteks_navigasi(c, self._drv, teks, src),
                alert_info=(lambda r: r[1] if r[0] else None)(
                    _konteks_alert(c, self._drv, teks, src)))
                c.kuatkuasa(kep, self._drv, "clickGesture(xy)", {"x": x, "y": y})
            c.batalkan_cache()
        return self._drv.execute_script(script, *args)

    # -- keycode --
    def press_keycode(self, keycode, metastate=None, flags=None):
        """KEYCODE_ENTER ialah baris paling berbahaya dalam fork ini.

        `reveal_below_fold` menghantar sehingga 16 KEYCODE_TAB/DPAD_DOWN
        (base_page:3421) yang memindahkan FOKUS ke widget hantar, dan
        notis_kompaun.py:467 kemudian menghantar KEYCODE_ENTER. Itu
        mengaktifkan butang yang difokus TANPA SEBARANG TAP — tidak
        kelihatan kepada mana-mana gerbang berasaskan label tap.

        Jadi ENTER dinilai terhadap elemen yang SEDANG DIFOKUS, dan
        berbeza daripada tap biasa, fokus yang tidak dapat dibaca
        DISEKAT. Tiada TC dalam skop MBPG memerlukan ENTER, jadi
        gagal-tertutup di sini tidak mempunyai kos.
        """
        c = self._corong
        if keycode in KEYCODE_BAHAYA:
            c.semak_dibatalkan()
            src = c.sumber_halaman(self._drv, paksa=True)
            teks = _teks_fokus(src)
            if not teks:
                kep = dasar.Keputusan(
                    False,
                    f"{KEYCODE_BAHAYA[keycode]} dihantar tetapi elemen "
                    f"berfokus tidak dapat dibaca — ENTER boleh "
                    f"mengaktifkan butang hantar tanpa tap",
                    peraturan="TIDAK-PASTI", teks=teks)
            else:
                kep = dasar.nilai(
                    teks, c.tetapan,
                    konteks_simpan=_konteks_simpan(c, self._drv, teks, src),
                    konteks_mutasi=_konteks_mutasi(c, self._drv, teks, src),
                konteks_navigasi=_konteks_navigasi(c, self._drv, teks, src),
                    alert_info=(lambda r: r[1] if r[0] else None)(
                        _konteks_alert(c, self._drv, teks, src)))
            c.kuatkuasa(kep, self._drv,
                        f"press_keycode({KEYCODE_BAHAYA[keycode]})")
            c.batalkan_cache()
        args = [keycode]
        if metastate is not None:
            args.append(metastate)
        if flags is not None:
            args.append(flags)
        return self._drv.press_keycode(*args)

    # -- W3C actions (ActionChains) --
    def execute(self, driver_command, params=None):
        """Kedua-dua `_draw_signature` menggunakan ActionChains
        (daftar_kompaun_page:1886, notis_amaran_page:945).

        ActionChains TIDAK memanggil driver.tap() atau execute_script().
        Ia menghimpun urutan penuding dan menghantarnya melalui
        `driver.execute(Command.W3C_ACTIONS, ...)`. Proksi yang hanya
        membungkus kaedah bernama akan terlepas sepenuhnya, dan satu
        pointer-up yang tersasar di atas butang hantar ialah klik sebenar.

        Kami tidak cuba mentafsir setiap urutan penuding. Kami menilai
        setiap koordinat pointerDown/pointerUp dalam urutan itu terhadap
        dasar yang sama.
        """
        c = self._corong
        if driver_command == "actions" and isinstance(params, dict):
            c.semak_dibatalkan()
            for x, y in _titik_dalam_actions(params):
                src = c.sumber_halaman(self._drv)
                teks, jumpa = teks_di_koordinat(src, x, y)
                if not jumpa:
                    continue      # tandatangan dilukis atas kanvas kosong
                kep = dasar.nilai(
                    teks, c.tetapan,
                    konteks_simpan=_konteks_simpan(c, self._drv, teks, src),
                    konteks_mutasi=_konteks_mutasi(c, self._drv, teks, src),
                konteks_navigasi=_konteks_navigasi(c, self._drv, teks, src),
                alert_info=(lambda r: r[1] if r[0] else None)(
                    _konteks_alert(c, self._drv, teks, src)))
                c.kuatkuasa(kep, self._drv, "ActionChains", {"x": x, "y": y})
            c.batalkan_cache()
        return self._drv.execute(driver_command, params)

    # -- swipe --
    def swipe(self, start_x, start_y, end_x, end_y, duration=0):
        """Swipe tidak menekan butang — KECUALI apabila mula == tamat,
        yang Android daftarkan sebagai ketukan. Punca biasa: bounds bekas
        berketinggian sifar dalam base_page._kira_swipe()."""
        c = self._corong
        if (start_x, start_y) == (end_x, end_y):
            c.semak_dibatalkan()
            src = c.sumber_halaman(self._drv)
            teks, jumpa = teks_di_koordinat(src, start_x, start_y)
            kep = dasar.nilai(
                teks, c.tetapan,
                konteks_mutasi=_konteks_mutasi(c, self._drv, teks, src),
                konteks_navigasi=_konteks_navigasi(c, self._drv, teks, src),
            ) if jumpa else dasar.Keputusan(
                False, "swipe degenerat (mula == tamat) pada koordinat yang "
                       "tidak dapat dileraikan — Android mendaftarkannya "
                       "sebagai TAP",
                peraturan="TIDAK-PASTI", teks=teks)
            c.kuatkuasa(kep, self._drv, "driver.swipe(degenerat)",
                        {"x": start_x, "y": start_y})
            c.batalkan_cache()
        return self._drv.swipe(start_x, start_y, end_x, end_y, duration)

    # -- terus lulus --
    def __getattr__(self, nama):
        return getattr(object.__getattribute__(self, "_drv"), nama)

    def __setattr__(self, nama, nilai):
        setattr(object.__getattribute__(self, "_drv"), nama, nilai)

    def __repr__(self):
        return f"<DriverBerkawal {self._drv!r}>"

    @property
    def corong(self):
        return object.__getattribute__(self, "_corong")

    @property
    def asli(self):
        return object.__getattribute__(self, "_drv")


def _titik_dalam_actions(params):
    """Setiap (x, y) yang disentuh oleh urutan W3C actions.

    Bentuk params: {"actions": [{"type": "pointer", "actions": [
        {"type": "pointerMove", "x": .., "y": ..}, {"type": "pointerDown"},
        ...]}]}. Koordinat pointerMove ialah tempat penuding BERADA
    apabila pointerDown/pointerUp seterusnya berlaku, jadi kami menjejak
    kedudukan semasa dan merekodkannya pada setiap peristiwa turun/naik.
    """
    titik = []
    for sumber in (params or {}).get("actions", []):
        if sumber.get("type") != "pointer":
            continue
        x = y = None
        for a in sumber.get("actions", []):
            jenis = a.get("type")
            if jenis == "pointerMove":
                x, y = a.get("x", x), a.get("y", y)
            elif jenis in ("pointerDown", "pointerUp"):
                if x is not None and y is not None:
                    titik.append((x, y))
    return titik


def _teks_fokus(sumber):
    """Teks node yang sedang focused=\"true\" — sasaran sebenar
    KEYCODE_ENTER."""
    try:
        akar = ET.fromstring(sumber)
    except ET.ParseError:
        return []
    keluar = []
    for n in akar.iter():
        if (n.get("focused") or "").lower() == "true":
            keluar.extend(_teks_node(n))
    return keluar


def _cari_ikut_id(driver, eid):
    """Bina semula objek WebElement daripada elementId mentah yang muncul
    dalam hujah clickGesture."""
    try:
        from selenium.webdriver.remote.webelement import WebElement
        return WebElement(driver, eid)
    except Exception:                                           # noqa: BLE001
        return None


# ---------------------------------------------------------------------------
# Pemasangan
# ---------------------------------------------------------------------------

def pasang(driver, tetapan=None, dir_reports=None):
    """Bungkus `driver` dan pulangkan proksi berkawal.

    Dipanggil SEKALI dalam create_driver(), sejurus selepas
    webdriver.Remote() dan SEBELUM sesi diserahkan kepada mana-mana
    fixture. Selepas titik ini tiada kod ujian yang memegang sesi tidak
    berkawal.
    """
    tetapan = tetapan or dasar.Tetapan()
    if dir_reports is None:
        dir_reports = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "reports")
    c = Corong(tetapan, dir_reports)
    print("  [GUARD] Corong dry-run DIPASANG — "
          f"dry_run={tetapan.dry_run}, benarkan_serah={tetapan.benarkan_serah}")
    print("  [GUARD] Trip-wire kekal: HANTAR / YA / OK / SAHKAN / KEMASKINI")
    if not tetapan.benarkan_serah:
        print("  [GUARD] SERAH turut disekat (default pemilik)")
    return DriverBerkawal(driver, c)

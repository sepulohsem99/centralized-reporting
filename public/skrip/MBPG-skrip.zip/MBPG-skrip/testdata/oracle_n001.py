"""
Data ujian N-001 — verbatim dari oracle, tiada satu pun direka.

Sumber: sel C9 sheet `MBPG-TC-N-001` dalam
IES-MBPG Testing Script V2.1.20_PRODUCTION.xlsx.

Kunci dinamakan mengikut apa yang lapisan pages/ TUNTUT (lihat docstring
fill_pesalah_tab / fill_notis_tab / fill_penerima_tab), bukan mengikut
label pada sheet. Pemetaan itu direkod di sebelah setiap nilai supaya
sesiapa boleh menyemaknya semula terhadap workbook tanpa meneka.

DISAHKAN TERHADAP DB PRODUCTION (snapshot 2026-08-07)
-----------------------------------------------------
Rantaian Kompaun oracle memang wujud pada peranti:
    kod 03  KOMPAUN LETAK KERETA
      akta 49  PERINTAH LALULINTAS JALAN (PMTLK) MPPG 2001
        kesalahan 48  MELETAKKAN KENDERAAN DIMANA-MANA...
Kedua-dua sauh alamat juga wujud dan berpasangan betul:
    JALAN KALOI 13   -> taman 14   TANJONG PUTERI RESORT  (poskod 81700)
    JALAN LEMBAH 19  -> taman 0304 BANDAR SERI ALAM

Nota tentang `notis_jalan_partial`: autolengkap jalan dipandu dengan
menaip SEBAHAGIAN nama, kemudian memilih baris cadangan. Kami menaip
cukup panjang untuk menjadikan padanan tidak taksa — MBJB merekod
kegagalan "pilih baris pertama" pada JALAN ULU TIRAM apabila rentetan
separa terlalu pendek dan beberapa jalan berkongsi awalan.
"""

# --- Tab PESALAH -----------------------------------------------------
# Sheet: Nama Pesalah / No KP / Jalan / Taman / Poskod / Bandar / Negeri
PESALAH = {
    "nama_pesalah": "AMIRUL",
    "no_kp_ssm_kereta": "010123456789",
    "jalan": "JALAN KALOI 13",
    "taman": "TANJONG PUTERI RESORT",
    "poskod": "81700",
    "bandar": "PASIR GUDANG",
    "negeri": "JOHOR",
}

# --- Tab NOTIS (Maklumat Kesalahan + seksyen Kompaun) ----------------
NOTIS = {
    "notis_jalan_partial": "JALAN LEMBAH 19",
    "notis_jalan_suggestion": "JALAN LEMBAH 19",
    "notis_taman": "BANDAR SERI ALAM",
    "notis_poskod": "81750",
    "notis_bandar": "MASAI",
    "notis_negeri": "JOHOR",
    "lokasi_kesalahan": "DEPAN KEDAI",
    "butiran_kesalahan": "PARKING KERETA DI TEMPAT OKU",
    "tempoh_notis": "0",
    "keterangan_kod_kompaun": "KOMPAUN LETAK KERETA",
    "kod_akta": "PERINTAH LALULINTAS JALAN (PMTLK) MPPG 2001",
    "kesalahan_kompaun": (
        "MELETAKKAN KENDERAAN DIMANA-MANA PADA TEMPAT, PADA MANA-MANA "
        "JALAN / SEPANJANG JALAN DIMANA DISEBELAHNYA / YANG BERDEKATAN "
        "DENGANNYA ADA TEMPAT LETAK KERETA."
    ),
    # Sheet TIDAK memberi baris kadar denda untuk N-001. Dibiarkan
    # kosong dengan sengaja — DB production menunjukkan amounnotis = 0
    # pada setiap kesalahan, jadi tiada nilai yang boleh direka di sini
    # tanpa mengarang bukti.
    "kadar_denda": "",
}

# --- Tab PEGAWAI / PENERIMA ------------------------------------------
PENERIMA = {
    "arahan_tindakan": "-",
    "nama_penerima": "AMIRUL",
    "no_ic_penerima": "010123456789",
}

# Gabungan penuh, untuk pemanggil yang mahu satu dict.
SEMUA = {}
SEMUA.update(PESALAH)
SEMUA.update(NOTIS)
SEMUA.update(PENERIMA)

# Medan yang WAJIB dibaca balik selepas diisi. Read-back ialah keseluruhan
# tujuan TC ini: "medan menerima input" hanya boleh dibuktikan dengan
# membaca semula apa yang app simpan, bukan dengan menaip tanpa ralat.
#
# Medan autolengkap (jalan) dikecualikan daripada read-back literal:
# nilai akhirnya datang dari baris cadangan yang dipilih, dan
# pengesahannya dilakukan oleh mekanisme dua-sauh dalam base_page, bukan
# dengan membandingkan rentetan yang kami taip.
READBACK_PESALAH = ("nama_pesalah", "no_kp_ssm_kereta", "poskod",
                    "bandar", "negeri")
READBACK_NOTIS = ("lokasi_kesalahan", "butiran_kesalahan")

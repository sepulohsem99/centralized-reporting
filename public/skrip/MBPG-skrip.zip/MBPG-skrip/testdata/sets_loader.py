"""
Pemuat set kombo + penapis baris arahan.

TIADA SET DIJALANKAN TANPA FLAG — itu keputusan reka bentuk, bukan
kelalaian. Ada 330 set dalam skop; `pytest tests/` tanpa penapis pada
peranti production akan memandu ketiga-tiga dropdown 330 kali tanpa
sesiapa memilih untuk itu. Pemilihan mesti EKSPLISIT.

    pytest --kk 01                     semua set kod kompaun 01
    pytest --kk 03                     semua set letak kereta
    pytest --set SET-KK01-AKT49-048    satu set
    pytest --borang P                  semua set borang P
    pytest --jangkaan BOLEH_GUNA       tapis ikut jangkaan
    pytest --kk 01 --jangkaan AMBIGU   flag boleh digabung (DAN)

Flag boleh diulang: `--kk 01 --kk 03` = kedua-duanya (ATAU dalam flag
yang sama, DAN antara flag berlainan).
"""

import os

import yaml

HERE = os.path.dirname(os.path.abspath(__file__))
DIR_SET = os.path.join(HERE, "sets")

# Bilangan set N dalam sampel lalai. Seksyen Kompaun pada borang Notis
# Amaran dan Kompaun Pelbagai dipercayai IDENTIK, jadi menyapu kesemua
# 256 pada kedua-duanya menggandakan masa peranti untuk membuktikan
# perkara yang sama. Sampel ini menguji dakwaan "N == P" itu sendiri:
# kalau mana-mana daripada 26 berbeza, andaian itu mati dan `--n-penuh`
# membuka kesemuanya.
SAMPEL_N = 26


def muat_semua(dir_set=DIR_SET):
    """Setiap fail set, disusun ikut set_id (deterministik).

    Set LUAR SKOP (LESEN) dijana untuk rekod tetapi TIDAK dimuatkan di
    sini — ia tidak boleh dijalankan walaupun sengaja dipilih dengan
    flag. Kalau ia dimuatkan, satu `--kk 02` yang tersilap taip akan
    memandu 81 set yang pemilik letak di luar skop.
    """
    keluar = []
    for root, _dirs, files in os.walk(dir_set):
        if "_LUAR-SKOP" in root.replace("\\", "/").split("/"):
            continue
        for f in sorted(files):
            if not f.endswith(".yaml"):
                continue
            p = os.path.join(root, f)
            with open(p, encoding="utf-8") as fh:
                s = yaml.safe_load(fh)
            if not s.get("dalam_skop"):
                continue
            s["_laluan"] = p
            keluar.append(s)
    keluar.sort(key=lambda s: s["set_id"])
    return keluar


def tapis(sets, kk=(), set_id=(), borang=(), jangkaan=()):
    """Tapis mengikut penapis CLI. Kosong = tiada penapis untuk dimensi
    itu. Dimensi berlainan digabung dengan DAN."""
    keluar = list(sets)
    if kk:
        mahu = {str(x).strip().upper() for x in kk}
        keluar = [s for s in keluar
                  if str(s["kod_kompaun"]["kod"]).upper() in mahu]
    if set_id:
        mahu = {str(x).strip().upper() for x in set_id}
        keluar = [s for s in keluar if s["set_id"].upper() in mahu]
    if borang:
        mahu = {str(x).strip().upper() for x in borang}
        keluar = [s for s in keluar
                  if mahu & {b.upper() for b in s["borang"]}]
    if jangkaan:
        mahu = {str(x).strip().upper() for x in jangkaan}
        keluar = [s for s in keluar if s["jangkaan"].upper() in mahu]
    return keluar


def sampel_n(sets, bil=SAMPEL_N):
    """Sampel deterministik merentas pasangan (kod, akta) yang BERBEZA.

    Bukan `sets[:26]` — 26 pertama mengikut abjad semuanya jatuh di bawah
    satu atau dua akta, jadi ia akan menguji satu cabang pokok berulang
    kali dan tidak menyentuh yang lain. Kita ambil satu wakil setiap
    pasangan (kod, akta) dahulu, kemudian sampel merentas pasangan itu
    dengan jarak sama rata.
    """
    dilihat = {}
    for s in sets:
        kunci = (s["kod_kompaun"]["kod"],
                 (s["akta"] or {}).get("id"))
        dilihat.setdefault(kunci, s)
    wakil = [dilihat[k] for k in sorted(dilihat,
                                        key=lambda t: (str(t[0]), str(t[1])))]
    if len(wakil) <= bil:
        return wakil
    langkah = len(wakil) / float(bil)
    return [wakil[int(i * langkah)] for i in range(bil)]


def pilih_untuk_borang(sets, huruf_borang, n_penuh=False):
    """Set yang perlu disapu untuk satu borang, selepas penapis CLI.

    Skop lalai (arahan pemilik): P penuh, K penuh, N sampel.
    `--n-penuh` membuka N kepada kesemuanya.
    """
    calon = [s for s in sets if huruf_borang in s["borang"]]
    if huruf_borang == "N" and not n_penuh:
        return sampel_n(calon)
    return calon


# ---------------------------------------------------------------------------
# Cangkuk pytest — didaftarkan dari tests/conftest.py
# ---------------------------------------------------------------------------

def tambah_opsyen(parser):
    g = parser.getgroup("mbpg-set", "Pemilihan set kombo MBPG")
    g.addoption("--kk", action="append", default=[], metavar="KOD",
                help="Kod kompaun, cth --kk 01. Boleh diulang.")
    g.addoption("--set", action="append", default=[], dest="set_id",
                metavar="SET_ID",
                help="set_id penuh, cth --set SET-KK01-AKT49-048.")
    g.addoption("--borang", action="append", default=[], metavar="N|P|K",
                help="Tapis ikut borang sasaran.")
    g.addoption("--jangkaan", action="append", default=[],
                metavar="BOLEH_GUNA|AMBIGU|JANGKA_KOSONG|JANGKA_MATI_T3",
                help="Tapis ikut jangkaan.")
    g.addoption("--n-penuh", action="store_true", default=False,
                help="Sapu KESEMUA set N, bukan sampel 26.")


def ada_penapis(config):
    return bool(config.getoption("kk") or config.getoption("set_id")
                or config.getoption("borang")
                or config.getoption("jangkaan"))


def set_untuk(config, huruf_borang):
    """Set untuk satu borang selepas penapis CLI.

    Senarai KOSONG apabila tiada flag diberi — sweep tidak akan
    dikutip langsung. Itu jaring keselamatan yang dituntut: 330 set
    tidak boleh berjalan hanya kerana seseorang menaip `pytest`.
    """
    if not ada_penapis(config):
        return []
    semua = muat_semua()
    ditapis = tapis(semua,
                    kk=config.getoption("kk"),
                    set_id=config.getoption("set_id"),
                    borang=config.getoption("borang"),
                    jangkaan=config.getoption("jangkaan"))
    return pilih_untuk_borang(ditapis, huruf_borang,
                              n_penuh=config.getoption("n_penuh"))

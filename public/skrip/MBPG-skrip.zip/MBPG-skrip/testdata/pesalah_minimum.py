"""
Medan Pesalah MINIMUM untuk sweep N — diluluskan pemilik 2026-08-07.

KENAPA INI WUJUD
----------------
Pada borang Notis Amaran, tiga dropdown kod kompaun hidup pada tab NOTIS,
di sebalik tab PESALAH dan butang SETERUSNYA. Kalau SETERUSNYA
mengesahkan medan wajib, sweep tidak dapat mencapai dropdown tanpa
mengisi sesuatu.

Pemilik meluluskan mengisi medan WAJIB SAHAJA, dengan alasan risikonya
setara N-001 yang memang sudah diluluskan: borang diisi, dibaca, dan
DIBIARKAN — tidak diserah, tiada rekod dicipta.

NILAI DATANG DARI ORACLE, BUKAN DIREKA
--------------------------------------
Setiap nilai di bawah disalin verbatim dari sel C9 sheet MBPG-TC-N-001
dalam IES-MBPG Testing Script V2.1.20_PRODUCTION.xlsx. Tiada satu pun
direka. Itu penting: suite MBIP pernah membawa nilai rekaan ("Buruh En
Saiful") selama berbulan kerana ia kelihatan seperti data ujian sah.
Kalau medan yang tiada dalam oracle diperlukan, JANGAN isi tekaan —
laporkan dan minta keputusan.

SENGAJA TIDAK LENGKAP
---------------------
Ini BUKAN salinan penuh data N-001. Ia mengandungi medan Pesalah sahaja,
dan hanya yang berkemungkinan wajib. Sweep bukan N-001: kalau kita mengisi
borang penuh di sini, sweep berhenti menjadi "uji pokok dropdown" dan
menjadi 26 salinan separa N-001 dengan kos peranti yang sepadan.
"""

# Sumber: MBPG-TC-N-001 C9, seksyen PESALAH. Verbatim.
PESALAH_N001 = {
    "nama_pesalah": "AMIRUL",
    "no_kp": "010123456789",
    "jalan": "JALAN KALOI 13",
    "taman": "TANJONG PUTERI RESORT",
    "poskod": "81700",
    "bandar": "PASIR GUDANG",
    "negeri": "JOHOR",
}

# Subset yang dicuba DAHULU: dua medan identiti yang hampir pasti wajib.
# Alamat dicuba hanya kalau SETERUSNYA masih ditolak — mengisi alamat
# mencetuskan autolengkap jalan yang diselaras, yang lebih perlahan dan
# membawa risiko memilih baris cadangan yang salah.
MINIMUM_PERINGKAT_1 = ("nama_pesalah", "no_kp")
MINIMUM_PERINGKAT_2 = ("nama_pesalah", "no_kp", "jalan", "taman",
                       "poskod", "bandar", "negeri")


def peringkat(n):
    """Dict medan untuk percubaan ke-n (1 atau 2)."""
    kunci = MINIMUM_PERINGKAT_1 if n == 1 else MINIMUM_PERINGKAT_2
    return {k: PESALAH_N001[k] for k in kunci}

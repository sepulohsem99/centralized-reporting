"""
PENANDA DATA UJIAN — arahan pemilik 2026-08-17, bahagian 3.3.

Setiap rekod yang mod sebenar cipta ialah rekod HIDUP pada production
MBPG. PM membersihkannya melalui portal ePBT. Untuk itu berlaku, rekod
mesti boleh DICARI, dan mesti jelas kepada sesiapa yang membacanya
bahawa ia data ujian dan bukan penguatkuasaan sebenar.

Format yang pemilik tetapkan:

    nama / medan teks bebas : UJIAN AUTOMASI E2E <TC-ID> <YYYYMMDD-HHMM>
    medan catatan/remarks   : ...ditambah 'AUTOMASI-CLEANUP-PM'

DAN: "JANGAN guna data oracle yang nampak macam warga sebenar (nama/IC
nyata) untuk rekod yang benar-benar akan disimpan."

Yang KEKAL dari oracle
----------------------
Kod kompaun, kod akta, kesalahan, jalan/taman/poskod/bandar/negeri,
lokasi kesalahan, tempoh, kadar denda. Itu bukan PII dan menukarnya
akan memusnahkan maksud TC — kombinasi kod itulah yang sedang diuji.

>>> SATU KES DIPERHATI TIDAK DILIPUT DI SINI. <<<
Pada borang K-001, lookup mySIKAP mengisi Nama Pesalah dan No. K/P
daripada pangkalan data kerajaan — iaitu PII warga SEBENAR (recon
2026-08-12 merakam nama penuh 28 aksara + no. KP 12 digit). Modul ini
menandakan data yang KITA taip; ia tidak boleh menghalang app daripada
menulis semula medan itu selepas lookup.

Maka: kalau mySIKAP dicetuskan, rekod yang terhasil membawa PII sebenar
walaupun setiap nilai yang kita taip ditanda. Itu keputusan pemilik,
bukan keputusan kod, dan ia dinaikkan dalam laporan dan bukan diputuskan
di sini. `fill_pesalah_tab_letak_kereta()` (laluan cipta K) TIDAK
mencetuskan mySIKAP — lihat komennya.
"""

import datetime
import re

# Awalan tetap. Dicari oleh PM dalam portal, jadi ia tidak boleh berubah
# antara larian atau antara borang.
AWALAN = "UJIAN AUTOMASI E2E"

# Ditambah kepada medan catatan supaya carian teks bebas menemuinya
# walaupun medan nama dipotong pendek oleh app.
TANDA_CLEANUP = "AUTOMASI-CLEANUP-PM"

# Medan identiti — nilai oracle DIGANTI SEPENUHNYA.
MEDAN_NAMA = ("nama_pesalah", "nama_penerima")

# Medan nombor KP/SSM — diganti dengan pemalar sintetik di bawah.
MEDAN_IC = ("no_kp_ssm_kereta", "no_ic_penerima")

# >>> KENAPA NILAI INI, DAN BUKAN YANG LAIN. <<<
# Tiga syarat perlu dipenuhi serentak:
#
#   1. Bentuk SAH — enam digit pertama menghurai sebagai tarikh
#      (2011-11-11), jadi ia tidak dilenting oleh pengesahan medan app
#      dan membazirkan satu kitaran production.
#   2. Jelas SINTETIK — satu digit berulang; tiada pembaca manusia akan
#      tersilap anggap ia nombor KP sebenar.
#   3. Sudah dikenali oleh gerbang PII — `devtools/imbas_pii.py` KECUALI
#      menyenaraikan 12 digit berulang sebagai penanda ujian yang sah.
#      Memilih nilai di luar senarai itu bermakna melonggarkan gerbang
#      PII supaya ia muat, iaitu arah yang salah sepenuhnya.
#
# Nilai oracle yang digantikannya TIDAK disebut di sini. Dua daripada
# tiga sudah sintetik; yang ketiga (K-001) berpasangan nama-dengan-IC
# dalam bentuk warga sebenar, iaitu tepat yang arahan 3.3 larang —
# menyalinnya ke dalam komen akan memasukkannya ke dalam sejarah git
# untuk selama-lamanya. Lihat `testdata/oracle_pk.py` kalau nilainya
# perlu dilihat. Satu pemalar untuk ketiga-tiga borang bermakna tiada
# borang boleh terlepas.
IC_UJIAN = "111111111111"

# Medan catatan/butiran — nilai oracle DIKEKALKAN (ia sebahagian TC)
# dan tanda cleanup DITAMBAH di belakang.
MEDAN_CATATAN = ("butiran_kesalahan",)

# Had aksara konservatif untuk medan catatan. D-06 merekod satu
# kegagalan baca-balik pada kesalahan 148 selepas modal ditutup; punca
# sebenarnya belum dicirikan, tetapi menambah teks tanpa had kepada
# medan yang sudah panjang ialah cara termudah untuk mencipta kegagalan
# kedua yang kelihatan sama. Kalau gabungan melebihi had, tanda cleanup
# DILANGKAU dan medan nama membawanya sebagai gantinya.
HAD_CATATAN = 120


def cap_masa(masa=None):
    """'YYYYMMDD-HHMM' — format yang pemilik tetapkan."""
    masa = masa or datetime.datetime.now()
    return masa.strftime("%Y%m%d-%H%M")


def penanda(tc_id, masa=None):
    """'UJIAN AUTOMASI E2E N-001 20260817-1430'."""
    return f"{AWALAN} {tc_id} {cap_masa(masa)}"


def ialah_penanda(teks):
    """True kalau nilai itu data ujian yang modul ini hasilkan.

    Digunakan oleh gerbang dan oleh jaring PII: nilai yang KITA taip
    tidak boleh dilaporkan sebagai PII yang muncul secara misteri.
    """
    return bool(re.match(rf"^\s*{re.escape(AWALAN)}\s+\S+\s+\d{{8}}-\d{{4}}",
                         teks or ""))


def tandai(data, tc_id, masa=None):
    """Salinan `data` dengan medan identiti/catatan ditandakan.

    TIDAK mengubah `data` — pemanggil sering menggunakan semula dict
    oracle merentas borang, dan mutasi di tempat akan menyebarkan
    penanda satu borang kepada borang seterusnya bersama TC-ID yang
    salah.

    Medan yang tiada dalam `data` DILANGKAU: setiap borang membawa set
    medannya sendiri (K-001 tiada `nama_penerima`, N-001 tiada
    `no_kereta`), dan mencipta medan yang borang itu tidak ada akan
    menghantar nilai ke tempat yang tidak dijangka.
    """
    keluar = dict(data)
    tanda = penanda(tc_id, masa)

    for medan in MEDAN_NAMA:
        if medan in keluar:
            keluar[medan] = tanda

    for medan in MEDAN_IC:
        if medan in keluar:
            keluar[medan] = IC_UJIAN

    for medan in MEDAN_CATATAN:
        if medan not in keluar:
            continue
        asal = (keluar[medan] or "").strip()
        calon = f"{asal} {TANDA_CLEANUP}".strip()
        keluar[medan] = calon if len(calon) <= HAD_CATATAN else asal

    return keluar


def ringkasan(data_asal, data_ditanda):
    """Senarai (medan, sebelum, selepas) untuk dilog sebelum serah.

    Perubahan pada data yang mencipta rekod production mesti kelihatan
    dalam log larian, bukan hanya dalam kod.
    """
    beza = []
    for k in sorted(set(data_asal) | set(data_ditanda)):
        a, b = data_asal.get(k), data_ditanda.get(k)
        if a != b:
            beza.append((k, a, b))
    return beza

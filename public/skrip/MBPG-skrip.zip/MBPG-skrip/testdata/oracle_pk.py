"""
Data ujian P-001 dan K-001 — verbatim dari oracle V2.1.20, sel C9.

Seperti oracle_n001.py: tiada nilai direka. Di mana workbook senyap,
medan itu DITANDA sebagai tiada dan bukan diisi dengan tekaan.
"""

# =========================================================================
# MBPG-TC-P-001 — Daftar Kompaun Pelbagai
# =========================================================================
P001 = {
    # --- Pesalah ---
    "nama_pesalah": "AFIQ",
    "no_kp_ssm_kereta": "010987654321",
    "jalan": "JALAN GUNUNG 12",
    "taman": "BANDAR SERI ALAM",
    "poskod": "81750",
    "bandar": "PASIR GUDANG",
    "negeri": "JOHOR",

    # --- Kompaun / Maklumat Kesalahan ---
    # Nama kunci mengikut kontrak DaftarKompaunPage.fill_kompaun_tab()
    # (`kompaun_*` / `jalan_premis`) — BUKAN `notis_*`, yang milik
    # NotisAmaranPage. Run pertama menggunakan awalan notis_ dan medan
    # tersebut hanya diabaikan secara senyap.
    "jalan_premis": "JALAN NURI 3",
    "kompaun_jalan_partial": "JALAN NURI",
    "kompaun_jalan_suggestion": "JALAN NURI 3",
    "kompaun_jalan": "JALAN NURI 3",
    "kompaun_taman": "TAMAN SCIENTEX",
    "kompaun_poskod": "81750",
    "kompaun_bandar": "PASIR GUDANG",
    "kompaun_negeri": "JOHOR",
    "lokasi_kesalahan": "DEPAN SEKOLAH",
    "butiran_kesalahan": "PANDU KERETA LAJU",

    # --- Maklumat Kompaun ---
    "tempoh_notis": "1",
    "keterangan_kod_kompaun": "KOMPAUN PELBAGAI JP",
    # Sumber menulis "Kod Akta:P UNDANG-UNDANG..." — huruf 'P' terpencil
    # selepas titik bertindih, tiada ruang. Ditafsir sebagai taip-silap
    # workbook; nama akta sebenar bermula pada "UNDANG-UNDANG".
    "kod_akta": "UNDANG-UNDANG KECIL VANDALISME (MPPG) 2011",
    "kesalahan_kompaun": ("MEMBUAT APA-APA YANG BOLEH MENYEBABKAN "
                          "KEROSAKAN HARTA MPPG."),
    "kadar_denda": "RM 500",

    # --- Pegawai ---
    "arahan_tindakan": "-",
    "nama_penerima": "AFIQ",
    "no_ic_penerima": "010987654321",
}

P001_READBACK_PESALAH = ("nama_pesalah", "no_kp_ssm_kereta", "poskod",
                         "bandar", "negeri")
P001_READBACK_KOMPAUN = ("lokasi_kesalahan", "butiran_kesalahan")


# =========================================================================
# MBPG-TC-K-001 — Daftar Kompaun Letak Kereta
# =========================================================================
#
# >>> TIDAK LENGKAP DALAM ORACLE — BUKAN BOLEH DIJALANKAN SEPENUHNYA. <<<
#
# Sheet C9 TIDAK memberi `no_kereta` mahupun `warna_kereta`, sedangkan
# langkah 1 dan 2 sheet yang sama menuntut kedua-duanya. `no_kereta`
# ialah KUNCI LOOKUP MySIKAP — tanpa ia, langkah MySIKAP tidak mempunyai
# input.
#
# Tiada plat direka di sini. Mereka-cipta nombor kenderaan bermakna
# menanyakan pangkalan data JPJ tentang kereta orang yang RAWAK, dari
# peranti penguatkuasa production. Itu bukan ujian; itu pertanyaan
# sebenar terhadap rekod sebenar seseorang.
#
# Keputusan pemilik diperlukan: bekalkan plat ujian yang SAH untuk
# digunakan, atau sahkan bahagian MySIKAP K-001 dilangkau.
K001 = {
    "nama_pesalah": "VIMALA DEVI A/P MARAN",
    "no_kp_ssm_kereta": "960227145748",
    "no_cukai_jalan": "-",
    "jalan": "BLOK A-16-10",
    "taman": "PPR TAMAN WAHYU 2",
    "bandar": "ULU TIRAM",
    "poskod": "51200",
    "negeri": "KUALA LUMPUR WILAYAH PERSEKUTUAN",
    "jenis_kereta": "PROTON WIRA 1.5 GL (A)",
    "no_petak": "-",
    "no_kupon": "-",

    "jalan_premis": "JALAN RIMBA 2",
    "kompaun_jalan_partial": "JALAN RIMBA",
    "kompaun_jalan_suggestion": "JALAN RIMBA 2",
    "kompaun_jalan": "JALAN RIMBA 2",
    "kompaun_taman": "BANDAR SERI ALAM",
    "kompaun_bandar": "MASAI",
    # PEPIJAT WORKBOOK: baris 'Negeri' membawa poskod 81750, dan tiada
    # baris Poskod langsung. Disalin apa adanya supaya percanggahan
    # kelihatan dalam laporan dan bukan dilicinkan senyap.
    "kompaun_negeri": "81750",
    "lokasi_kesalahan": "DEPAN KEDAI",
    "butiran_kesalahan": "PARKING KERETA DALAM PETAK KUNING",

    "tempoh_notis": "1 HARI",
    "keterangan_kod_kompaun": "KOMPAUN LETAK KERETA",
    "kod_akta": "AKTA PENGANGKUTAN JALAN 1987",
    "kesalahan_kompaun": ("MEMINDAHKAN KENDERAAN YANG ROSAK DAN YANG "
                          "DITINGGALKAN."),
    "kadar_denda": "500",
    "no_pembantu_penguatkuasa": "2",
}

# >>> DISELESAIKAN OLEH PEMILIK 2026-08-10. <<<
# Plat ujian SAH dibekalkan pemilik dari data oracle rasmi: JYX6605.
# Ia BUKAN rekaan — itulah sebabnya ia boleh digunakan terhadap MySIKAP
# pada peranti production. `warna_kereta` masih tiada dan kekal tiada:
# ia dijangka datang dari auto-isi MySIKAP, jadi menaipnya akan
# menopengkan sama ada lookup benar-benar berfungsi.
K001["no_kereta"] = "JYX6605"

K001_TIADA_DALAM_ORACLE = ("warna_kereta",)

K001_READBACK_PESALAH = ("nama_pesalah", "no_kp_ssm_kereta", "poskod",
                         "bandar")
K001_READBACK_KOMPAUN = ("lokasi_kesalahan", "butiran_kesalahan")

"""
Pemilih sauh alamat — keputusan pemilik 2026-08-10, pilihan (a).

>>> INI MENYAHSEKAT UJIAN. IA TIDAK MENUTUP D-03. <<<
D-03 kekal defek app dalam docs/D-03-POSKOD-KOSONG.md: 1276 daripada
3493 rekod jalan production tiada poskod, dan mana-mana kompaun pada
jalan itu berhenti pada dinding yang sama. Yang berubah di sini hanyalah
alamat yang SUITE gunakan, supaya baki borang boleh diuji langsung.

Poskod TIDAK PERNAH ditaip. Auto-isi app kekal perkara yang diuji —
kami hanya memilih jalan yang app MAMPU mengisinya.

Pemilihan bersifat DETERMINISTIK (isih abjad, calon pertama), jadi
larian berulang memilih alamat yang sama dan keputusan boleh
dibandingkan antara larian.
"""

import sqlite3

# Kriteria, mengikut urutan penggunaan. Setiap satu ada sebab operasi,
# bukan citarasa — ia direkodkan supaya laporan boleh menyatakan bukan
# sahaja alamat MANA yang dipilih tetapi KENAPA.
KRITERIA = (
    "1. local_ekpn_jalan.poskod BUKAN kosong — ini tepat keadaan yang "
    "D-03 sekat; jalan tanpa poskod tidak boleh melepasi tab Pesalah.",

    "2. Nama bermula 'JALAN ' dan ada >=3 token — enjin cadangan menapis "
    "dengan awalan DUA perkataan, jadi nama dua-token tidak mempunyai "
    "apa-apa untuk dipersempit dan nama satu-token langsung tiada "
    "awalan.",

    "3. Awalan dua-perkataan itu dikongsi oleh <=6 jalan — senarai "
    "cadangan RN memulangkan 'Tiada rekod dijumpai' untuk penapis yang "
    "terlalu luas, dan baris sasaran mesti benar-benar dirender untuk "
    "boleh diketuk.",

    "4. taman dan bandar kedua-duanya boleh diselesaikan dalam jadual "
    "kodnya — supaya auto-isi yang dijangka boleh disahkan, bukan "
    "sekadar diperhatikan.",

    "5. Isih abjad, ambil yang PERTAMA — deterministik.",
)


def _muat(db):
    c = sqlite3.connect(db)
    jalan = c.execute("SELECT nama, taman, poskod FROM local_ekpn_jalan "
                      "WHERE TRIM(COALESCE(poskod,'')) <> ''").fetchall()
    taman = {r[0]: (r[1], r[2])
             for r in c.execute("SELECT kod, nama, bandar "
                                "FROM local_ekpn_taman")}
    bandar = {r[0]: (r[1], r[2])
              for r in c.execute("SELECT kod, nama, negeri "
                                 "FROM local_ekpn_bandar")}
    c.close()
    return jalan, taman, bandar


def pilih(db):
    """Pulangkan (alamat_dict, jejak) atau bangkitkan kalau tiada calon.

    `jejak` ialah rekod boleh-audit: berapa banyak baris yang tersingkir
    pada setiap kriteria. Laporan mencetaknya supaya pilihan ini boleh
    diperiksa dan bukan sekadar dipercayai.
    """
    jalan, taman, bandar = _muat(db)

    kiraan_awalan = {}
    for nama, _, _ in jalan:
        p = " ".join(nama.split()[:2])
        kiraan_awalan[p] = kiraan_awalan.get(p, 0) + 1

    jejak = {"jalan_berposkod": len(jalan)}
    calon = []
    for nama, kod_taman, poskod in jalan:
        token = nama.split()
        if not nama.upper().startswith("JALAN ") or len(token) < 3:
            continue
        if kiraan_awalan[" ".join(token[:2])] > 6:
            continue
        t = taman.get(kod_taman)
        if not t:
            continue
        b = bandar.get(t[1])
        if not b:
            continue
        calon.append((nama, poskod, t[0], b[0], b[1]))

    jejak["lulus_semua_kriteria"] = len(calon)
    if not calon:
        raise RuntimeError(
            "tiada alamat dalam snapshot yang memenuhi kriteria sauh. "
            "Itu sendiri satu dapatan — laporkan, jangan longgarkan "
            "kriteria secara senyap.")

    calon.sort()
    nama, poskod, nama_taman, nama_bandar, negeri = calon[0]
    jejak["dipilih"] = nama
    jejak["calon_seterusnya"] = [c[0] for c in calon[1:4]]

    return {
        "jalan": nama,
        "jalan_partial": " ".join(nama.split()[:2]),
        "poskod_dijangka": poskod,
        "taman_dijangka": nama_taman,
        "bandar_dijangka": nama_bandar,
        "negeri_dijangka": negeri,
    }, jejak


def cetak(alamat, jejak):
    print("  [SAUH-ALAMAT] dipilih automatik dari snapshot DB:")
    print(f"      jalan  : {alamat['jalan']}  "
          f"(penapis '{alamat['jalan_partial']}')")
    print(f"      jangka : taman={alamat['taman_dijangka']} "
          f"poskod={alamat['poskod_dijangka']} "
          f"bandar={alamat['bandar_dijangka']} "
          f"negeri={alamat['negeri_dijangka']}")
    print(f"      dari {jejak['jalan_berposkod']} jalan berposkod -> "
          f"{jejak['lulus_semua_kriteria']} lulus kriteria; "
          f"seterusnya: {', '.join(jejak['calon_seterusnya'])}")
    print("      poskod TIDAK ditaip — ia mesti datang dari auto-isi app.")

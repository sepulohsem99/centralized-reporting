"""
SKOP MBPG — 49 TC, dengan sebab rasmi bagi setiap satu.

SUMBER KEBENARAN
----------------
Dua dokumen, dan keduanya diperlukan:

  1. IES-MBPG Testing Script V2.1.20_PRODUCTION.xlsx  (52 sheet:
     Introduction + List to Test + SENARAI KOMPAUN (8726) + 49 sheet TC).
     Ia menentukan TC MANA yang wujud dan APA nama modulnya.

  2. MBPG-KLASIFIKASI-TC.md, keputusan pemilik 2026-08-07. Ia menentukan
     TC mana yang BOLEH dijalankan pada production dalam mod dry-run.

Fail ini menggabungkan kedua-duanya. Ia TIDAK mengandungi data ujian
(nilai medan) — itu datang kemudian daripada sheet oracle selepas T-004
memberi snapshot alamat pada device. Lihat "APA YANG TIADA DI SINI".

PERANGKAP SHEET YANG DIREKOD (jangan cuba 'baiki' senyap)
---------------------------------------------------------
  - 9 nama sheet ada RUANG DI HUJUNG: 'MBPG-TC-P-002 ', 'MBPG-TC-P-003 ',
    'MBPG-TC-P-004 ', 'MBPG-TC-K-002 ', 'MBPG-TC-K-004 ',
    'MBPG-TC-L-002 ', 'MBPG-TC-L-004 ', 'MBPG-TC-S-002 ',
    'MBPG-TC-S-004 ', 'MBPG-TC-SK-001 '.
  - Sel C3 ('Test Case ID') BERCANGGAH dengan nama sheet pada 6 sheet:
        sheet T-008 -> C3 = T-007      sheet T-010 -> C3 = T-009
        sheet P-005 -> C3 = N-005      sheet P-006 -> C3 = N-006
        sheet L-005 -> C3 = N-005      sheet S-005 -> C3 = K-005
    Kunci SEGALANYA pada NAMA SHEET, jangan sekali-kali pada C3.
    Nota: 'MBPG-TC-N-006' TIDAK WUJUD sebagai TC. Ia hanya nilai C3 yang
    tersalah taip dalam sheet P-006. Mengira ID unik daripada teks
    workbook menghasilkan 50; sheet sebenar ada 49.
  - Sheet 'MBPG-TC-P-006' TERSEMBUNYI (hidden) dalam workbook.
  - 'List to Test' lajur E ada dua ID cacat: 'MBPG-TC-T012' dan
    'MBPG-TC-L005' (tiada sengkang).

APA YANG TIADA DI SINI
----------------------
JANGKAAN_AUTOISI (padanan dua-sauh JALAN|TAMAN) sengaja KOSONG. Snapshot
pemetaan portal mbpg-mapping-2026-08-07.json TIDAK mengandungi senarai
alamat langsung — carian mendapati 0 padanan untuk setiap sauh yang
dijangka; 74 kemunculan 'JALAN' di dalamnya semuanya sebahagian NAMA AKTA
('AKTA JALAN PARIT DAN BANGUNAN 1974'), bukan nama jalan.

Maka senarai jalan mesti datang dari device melalui T-004 (Selaras
Maklumat Alamat) dan disnapshot ke data/snapshot-YYYYMMDD/. Sehingga itu
wujud, N/P/K-001 TIDAK boleh naik kepada padanan dua-sauh, dan padanan
satu-sauh boleh memilih taman yang SALAH secara senyap (kegagalan itu
didokumen untuk 'JALAN ULU TIRAM' dalam pages/base_page.py:439-448).
"""

# ---------------------------------------------------------------------------
# Kategori skop — keputusan pemilik 2026-08-07
# ---------------------------------------------------------------------------
PENUH = "runnable-penuh"      # boleh dijalankan sepenuhnya
ISI = "partial-isi-sahaja"    # isi medan + baca balik + BACK OUT, tiada serah
SKIP_GUARD = "skip-guard"     # perlu aksi yang dilarang pada production
SKIP_LUAR = "skip-luar-skop"  # di luar skop yang pemilik luluskan
SKIP_PEMILIK = "skip-arahan-pemilik"   # dilangkau atas arahan terus pemilik

# (sheet, nama modul dari 'List to Test', kategori, sebab rasmi)
#
# `nama` verbatim dari lajur Details 'List to Test'. Ejaan workbook
# dikekalkan; jangan betulkan (ia yang muncul dalam laporan dan mesti
# boleh dipadan semula dengan sumbernya).
TC_SPEC = [
    # --- A. RUNNABLE PENUH (12) ---------------------------------------
    ("MBPG-TC-T-001", "Tetapan Alamat IP", PENUH,
     "Masuk semula IP YANG SAMA sahaja (113.211.155.174). Nilai tidak ditukar."),
    ("MBPG-TC-T-002", "Tetapan Pelbagai", PENUH,
     "Baca nilai asal dahulu, uji, kemudian RESTORE nilai asal."),
    ("MBPG-TC-T-003", "Selaras Pengguna Apps", PENUH,
     "Sync baca-sahaja — selamat pada production."),
    ("MBPG-TC-T-004", "Selaras Maklumat Alamat", PENUH,
     "Sync baca-sahaja. Snapshot jalan BERTARIKH — prasyarat padanan "
     "dua-sauh untuk N/P/K-001."),
    ("MBPG-TC-T-005", "Selaras Maklumat Kompaun", PENUH,
     "Sync baca-sahaja. Snapshot kod kompaun 3 tingkat."),
    ("MBPG-TC-T-006", "Selaras Maklumat Jenis Kenderaan", PENUH,
     "Sync baca-sahaja."),
    ("MBPG-TC-T-007", "Selaras Maklumat Warna", PENUH,
     "Sync baca-sahaja."),
    ("MBPG-TC-T-008", "Selaras Maklumat Pelesen", SKIP_PEMILIK,
     "DILANGKAU atas arahan terus pemilik (2026-08-07, susulan kepada "
     "klasifikasi asal): 'kena skipped juga tc yang selaras pelesen'. "
     "Ia baca-sahaja dan oleh itu selamat, tetapi pada MBJB operasi yang "
     "setara mengambil >4 JAM untuk 121,871 rekod dan pernah dicetuskan "
     "secara tidak sengaja. Dilangkau atas sebab masa/operasi, BUKAN "
     "kerana ia berbahaya — bezakan ini dalam laporan."),
    ("MBPG-TC-T-009", "Selaras Maklumat Barang Sita", PENUH,
     "Sync baca-sahaja (walaupun siri S di luar skop, sync tetap selamat)."),
    ("MBPG-TC-T-010", "Tetapan Skrin Utama", PENUH,
     "Baca nilai asal, uji, RESTORE."),
    ("MBPG-TC-T-011", "Semak Kemaskini", PENUH,
     "Semakan versi baca-sahaja."),
    ("MBPG-TC-T-012", "Remember Me Functions", PENUH,
     "Aliran login — msc/<kata-laluan: profil>."),

    # --- B. PARTIAL FILL-ONLY (7) — TERAS MISI -------------------------
    ("MBPG-TC-N-001", "Daftar Notis Amaran", ISI,
     "Isi SEMUA medan Pesalah + Kesalahan + Kompaun + Pegawai, baca balik "
     "setiap satu, BACK OUT. SERAH TIDAK DITEKAN."),
    ("MBPG-TC-N-003", "Serah Notis Amaran", ISI,
     "Pemilik menafsir semula sebagai ujian lampiran DALAM borang N-001 "
     "(ikon klip -> kamera -> thumbnail), bukan serah rekod sedia ada. "
     "Lihat NOTA_N003 di bawah — tafsiran ini BERBEZA daripada sheet."),
    ("MBPG-TC-N-005", "Kompaun Form Notis Amaran - Bookmark", ISI,
     "Bookmark lokal dibenarkan: isi seksyen Kompaun -> ikon buku -> nama "
     "AUTO-TEST-N -> SIMPAN (dibenarkan HANYA dalam dialog bookmark) -> "
     "buka semula -> pilih -> verify medan terisi balik -> back out."),
    ("MBPG-TC-P-001", "Daftar Kompaun Pelbagai", ISI,
     "Sama seperti N-001."),
    ("MBPG-TC-P-005", "Kompaun Form Pelbagai - Bookmark", ISI,
     "Sama seperti N-005, nama AUTO-TEST-P."),
    ("MBPG-TC-K-001", "Daftar Kompaun Letak Kereta", ISI,
     "Sama seperti N-001. MySIKAP DIBENARKAN (lookup baca-sahaja): masuk "
     "No. Kereta -> tap MySIKAP -> verify auto-populate."),
    ("MBPG-TC-K-005", "Kompaun Form Letak Kereta - Bookmark", ISI,
     "Sama seperti N-005, nama AUTO-TEST-K."),

    # --- C. SKIP-GUARD (18) --------------------------------------------
    ("MBPG-TC-N-002", "Daftar Notis Amaran > Cetak", SKIP_GUARD,
     "Cetak — pemilik tidak benarkan cetak rekod sedia ada. Pencetak juga "
     "di luar skop projek dan modulnya tidak disalin ke fork ini."),
    ("MBPG-TC-P-002", "Daftar Kompaun Pelbagai > Cetak", SKIP_GUARD,
     "Cetak — sama seperti N-002."),
    ("MBPG-TC-K-002", "Daftar Kompaun Letak Kereta > Cetak", SKIP_GUARD,
     "Cetak — sama seperti N-002."),
    ("MBPG-TC-N-004", "Kemaskini Notis Amaran", SKIP_GUARD,
     "Kemaskini — manual handheld menyatakan kemaskini MEMBATALKAN rekod "
     "lama dan MENJANA nombor baharu = tulisan production. HARAM."),
    ("MBPG-TC-P-004", "Kemaskini Kompaun Pelbagai", SKIP_GUARD,
     "Kemaskini — sama seperti N-004."),
    ("MBPG-TC-K-004", "Kemaskini Kompaun Letak Kereta", SKIP_GUARD,
     "Kemaskini — sama seperti N-004."),
    ("MBPG-TC-P-003", "Serah Kompaun Pelbagai", SKIP_GUARD,
     "HANTAR akhir dilarang, jadi serah penuh tidak dapat dibuktikan."),
    ("MBPG-TC-K-003", "Serah Kompaun Letak Kereta", SKIP_GUARD,
     "HANTAR akhir dilarang, jadi serah penuh tidak dapat dibuktikan."),
    ("MBPG-TC-P-006", "Isu berkenaan tandatangan", SKIP_GUARD,
     "Perlukan cetakan untuk verify. Sheet juga TERSEMBUNYI dalam workbook."),
    ("MBPG-TC-SK-001", "Senarai Kompaun", SKIP_GUARD,
     "Test tidak mencipta rekod, jadi senarai kosong dan tiada apa untuk "
     "diverify. NOTA: senarai TETAP dibuka baca-sahaja selepas setiap "
     "borang sebagai POST-CHECK — itu jaring keselamatan, bukan TC."),
    ("MBPG-TC-H-001", "Hantar Semula Data & Gambar Notis Amaran", SKIP_GUARD,
     "Menu Hantar — tiada rekod untuk dihantar, dan hantar = tulisan "
     "production."),
    ("MBPG-TC-H-002", "Hantar Semula Data & Gambar Kompaun Pelbagai",
     SKIP_GUARD, "Menu Hantar — sama seperti H-001."),
    ("MBPG-TC-H-003", "Hantar Semula Data & Gambar Kompaun Letak Kereta",
     SKIP_GUARD, "Menu Hantar — sama seperti H-001."),
    ("MBPG-TC-TN-001", "Tarik Notis by Penguatkuasa", SKIP_GUARD,
     "Tarik Notis mengubah status rekod pada pangkalan data production. "
     "Tiada notis dicipta oleh test untuk ditarik."),
    ("MBPG-TC-TN-002", "Tarik Notis by No.Notis", SKIP_GUARD,
     "Sama seperti TN-001."),
    ("MBPG-TC-TN-003", "Tarik Notis by Tarikh", SKIP_GUARD,
     "Sama seperti TN-001. (TN-003 WUJUD dalam MBPG, tidak seperti MBIP "
     "V2.1.14.)"),
    ("MBPG-TC-NK-001", "Notis ke Kompaun > Kompaun", SKIP_GUARD,
     "Tiada notis dicipta, dan ia menjana No Kompaun baharu = tulisan "
     "production. HARAM."),
    ("MBPG-TC-NK-002", "Notis ke Kompaun > Patuh", SKIP_GUARD,
     "Sama seperti NK-001."),

    # --- D. SKIP LUAR SKOP (12) ----------------------------------------
    ("MBPG-TC-L-001", "Daftar Kompaun Lesen", SKIP_LUAR,
     "Siri L di luar skop yang pemilik luluskan (N + P + K sahaja)."),
    ("MBPG-TC-L-002", "Daftar Kompaun Lesen > Cetak", SKIP_LUAR,
     "Siri L di luar skop."),
    ("MBPG-TC-L-003", "Serah Kompaun Lesen", SKIP_LUAR,
     "Siri L di luar skop."),
    ("MBPG-TC-L-004", "Kemaskini Kompaun Lesen", SKIP_LUAR,
     "Siri L di luar skop."),
    ("MBPG-TC-L-005", "Kompaun Form Lesen - Bookmark", SKIP_LUAR,
     "Siri L di luar skop."),
    ("MBPG-TC-S-001", "Daftar Sitaan", SKIP_LUAR,
     "Siri S di luar skop yang pemilik luluskan."),
    ("MBPG-TC-S-002", "Daftar Sitaan > Cetak", SKIP_LUAR,
     "Siri S di luar skop."),
    ("MBPG-TC-S-003", "Serah Sitaan", SKIP_LUAR,
     "Siri S di luar skop."),
    ("MBPG-TC-S-004", "Kemaskini Sitaan", SKIP_LUAR,
     "Siri S di luar skop."),
    ("MBPG-TC-S-005", "Kompaun Form Sitaan - Bookmark", SKIP_LUAR,
     "Siri S di luar skop. NOTA: oracle merekod TC ini sebagai FAIL "
     "(bug bookmark: tukar bookmark tidak kemas kini medan). Kalau bug "
     "yang sama muncul dalam N/P/K-005, itu dapatan SAH."),
    ("MBPG-TC-H-004", "Hantar Semula Data & Gambar Kompaun Lesen", SKIP_LUAR,
     "Di luar skop (pemilik namakan H-004 secara khusus)."),
    ("MBPG-TC-H-005", "Hantar Semula Data & Gambar Kompaun Sitaan", SKIP_LUAR,
     "Di luar skop (pemilik namakan H-005 secara khusus). Oracle merekod "
     "TC ini sebagai FAIL."),
]

# Susunan sheet dalam workbook — susunan laporan mengikutnya, bukan abjad
# nama fail.
SHEET_ORDER = [
    "MBPG-TC-T-001", "MBPG-TC-T-002", "MBPG-TC-T-003", "MBPG-TC-T-004",
    "MBPG-TC-T-005", "MBPG-TC-T-006", "MBPG-TC-T-007", "MBPG-TC-T-008",
    "MBPG-TC-T-009", "MBPG-TC-T-010", "MBPG-TC-T-011", "MBPG-TC-T-012",
    "MBPG-TC-N-001", "MBPG-TC-N-002", "MBPG-TC-N-003", "MBPG-TC-N-004",
    "MBPG-TC-N-005",
    "MBPG-TC-P-001", "MBPG-TC-P-002", "MBPG-TC-P-003", "MBPG-TC-P-004",
    "MBPG-TC-P-005", "MBPG-TC-P-006",
    "MBPG-TC-K-001", "MBPG-TC-K-002", "MBPG-TC-K-003", "MBPG-TC-K-004",
    "MBPG-TC-K-005",
    "MBPG-TC-L-001", "MBPG-TC-L-002", "MBPG-TC-L-003", "MBPG-TC-L-004",
    "MBPG-TC-L-005",
    "MBPG-TC-S-001", "MBPG-TC-S-002", "MBPG-TC-S-003", "MBPG-TC-S-004",
    "MBPG-TC-S-005",
    "MBPG-TC-SK-001",
    "MBPG-TC-H-001", "MBPG-TC-H-002", "MBPG-TC-H-003", "MBPG-TC-H-004",
    "MBPG-TC-H-005",
    "MBPG-TC-TN-001", "MBPG-TC-TN-002", "MBPG-TC-TN-003",
    "MBPG-TC-NK-001", "MBPG-TC-NK-002",
]

# Nama sheet yang membawa ruang di hujung dalam workbook. Disimpan supaya
# mana-mana pembaca Excel kemudian boleh mencarinya tanpa meneka.
SHEET_RUANG_HUJUNG = {
    "MBPG-TC-P-002", "MBPG-TC-P-003", "MBPG-TC-P-004",
    "MBPG-TC-K-002", "MBPG-TC-K-004",
    "MBPG-TC-L-002", "MBPG-TC-L-004",
    "MBPG-TC-S-002", "MBPG-TC-S-004",
    "MBPG-TC-SK-001",
}

SHEET_TERSEMBUNYI = {"MBPG-TC-P-006"}

# TC yang oracle sendiri merekod sebagai FAIL (blok berwibawa 'List to
# Test' baris 65-134). Bukan kegagalan kita — keadaan sedia ada.
FAIL_DALAM_ORACLE = {"MBPG-TC-S-005", "MBPG-TC-H-005"}

NOTA_N003 = """\
N-003 — PERCANGGAHAN YANG MESTI DIPUTUSKAN PEMILIK.

Sheet oracle MBPG-TC-N-003 bertajuk "Serah Notis Amaran" dan Expected
Result C11 berbunyi "Application accepts the attachment". Iaitu:
lampirkan gambar kepada notis yang SUDAH WUJUD, melalui skrin Serah.

Klasifikasi pemilik 2026-08-07 pula mengarahkan N-003 dilakukan DALAM
borang N-001 (tap ikon klip -> kamera -> snap -> verify thumbnail),
borang tidak diserah.

Kedua-duanya tidak boleh benar serentak, dan versi oracle MUSTAHIL di
bawah misi ini: ia perlukan rekod sedia ada, dan melampirkan gambar
kepada rekod production sebenar ialah TULISAN kepada rekod itu
(pages/serah_page.attach_lampiran) walaupun tiada rekod baharu dicipta.

Skop yang dilaksanakan = versi PEMILIK (lampiran dalam borang).
Laporan mesti menyatakan dengan jelas bahawa N-003 sebagaimana DITULIS
dalam oracle TIDAK diuji."""


# ---------------------------------------------------------------------------
# Bentuk yang conftest jangkakan
# ---------------------------------------------------------------------------
TC_LIST = [(sheet, nama) for sheet, nama, _kat, _sebab in TC_SPEC]
TC_ORDER = {tc: i for i, tc in enumerate(SHEET_ORDER)}
TC_NAMES = dict(TC_LIST)

KATEGORI = {sheet: kat for sheet, _n, kat, _s in TC_SPEC}
SEBAB = {sheet: sebab for sheet, _n, _k, sebab in TC_SPEC}

BOLEH_JALAN = [t for t, k in KATEGORI.items() if k in (PENUH, ISI)]
DILANGKAU = [t for t, k in KATEGORI.items()
             if k in (SKIP_GUARD, SKIP_LUAR, SKIP_PEMILIK)]


def sebab_rasmi(tc_id):
    """Sebab rasmi bagi status TC — WAJIB muncul dalam laporan untuk
    kesemua 49, termasuk yang dilangkau."""
    return SEBAB.get(tc_id, "(tiada sebab direkod — ini sendiri satu bug)")


def _semak_ketekalan():
    """Gagal pada import kalau manifes tidak konsisten dengan dirinya.

    Ini menangkap kelas ralat yang paling mudah dibuat semasa menyunting
    fail ini dengan tangan, dan ia menangkapnya pada saat import dan
    bukan pada pertengahan run production."""
    sheets = [s for s, _n, _k, _sb in TC_SPEC]
    assert len(sheets) == 49, f"TC_SPEC ada {len(sheets)} TC, sepatutnya 49"
    assert len(set(sheets)) == 49, "TC_SPEC ada sheet berulang"
    assert set(sheets) == set(SHEET_ORDER), (
        f"TC_SPEC vs SHEET_ORDER tidak sepadan: "
        f"hanya dalam TC_SPEC={set(sheets) - set(SHEET_ORDER)}, "
        f"hanya dalam SHEET_ORDER={set(SHEET_ORDER) - set(sheets)}")
    kiraan = {k: sum(1 for v in KATEGORI.values() if v == k)
              for k in (PENUH, ISI, SKIP_GUARD, SKIP_LUAR, SKIP_PEMILIK)}
    # Klasifikasi asal pemilik 2026-08-07 ialah 12/7/18/12. T-008
    # kemudiannya dipindahkan daripada PENUH ke SKIP_PEMILIK atas arahan
    # susulan pemilik pada hari yang sama, jadi PENUH turun 12 -> 11.
    dijangka = {PENUH: 11, ISI: 7, SKIP_GUARD: 18, SKIP_LUAR: 12,
                SKIP_PEMILIK: 1}
    assert kiraan == dijangka, (
        f"taburan kategori {kiraan} tidak sepadan dengan keputusan pemilik "
        f"2026-08-07 {dijangka}")
    kosong = [s for s, sb in SEBAB.items() if not sb.strip()]
    assert not kosong, f"TC tanpa sebab rasmi: {kosong}"


_semak_ketekalan()

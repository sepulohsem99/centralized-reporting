# BEZA: mapping STAGING vs DB PRODUCTION — MBPG

> Dijana oleh `tools/jana_set.py --beza`.
> Staging : `https://epbtstaging.mbpg.gov.my (staging, view-only)` (snapshot 2026-08-07)
> Production: `C:\Users\mrsai\Documents\antigravity\keen-lovelace\MBPG-testing\data\snapshot-20260811\e_kompaunV1.db` (DB peranti, baca-sahaja)

## Kenapa dokumen ini wujud

Sistem set kombo mula-mula dibina daripada snapshot pemetaan portal. Snapshot itu diambil dari **epbtstaging.mbpg.gov.my**, sedangkan sasaran run ialah **production 113.211.155.174**. Perbezaannya bukan kecil, dan ia akan menyebabkan hampir setiap set gagal pada tingkat 1 — termasuk kerana teks yang dipaparkan berbeza, bukan sekadar kandungan.

## Ringkasan

| | Staging (mapping) | Production (DB peranti) |
|---|---|---|
| kod kompaun | 25 | **9** |
| akta | 34 | **23** |
| kesalahan | 146 | **120** |

## Kod kompaun

### Hanya dalam STAGING (tiada pada production)

| kod | keterangan staging |
|---|---|
| `04` | KOMPAUN PELBAGAI KESIHATAN |
| `100` | KOMPAUN KEBERSIHAN |
| `1001` | KOMPAUN PENCEMARAN AIR |
| `1050` | KOMPAUN KEBERSIHAN |
| `KA 12355` | KAKI LIMA |
| `KA01` | HALANGAN |
| `KPBT` | KOMPAUN PELBAGAI BANGUNAN TEST |
| `KPK` | MBPG KOMPAUN PELBAGAI KESIHATAN |
| `KPKL` | MBPG KOMPAUN PELBAGAI KESIHATAN (LESEN) |
| `KPP` | KOMPAUN PELBAGAI PENGUATKUASA |
| `MDT01` | MDT KOMPAUN JP |
| `PLS 01` | BEROPERASI TANPA LESEN PERNIAGAAN MBPG |
| `T001` | MBPG KOMPAUN PELBAGAI PENGUATKUASA (LESEN) |
| `T002` | MBPG KOMPAUN PELBAGAI PENGUATKUASA |
| `T003` | MBPG KOMPAUN PELBAGAI BANGUNAN (LESEN) |
| `T004` | MBPG KOMPAUN PELBAGAI BANGUNAN |
| `T005` | KOMPAUN PELBAGAI JP |
| `T006` | KOMPAUN PELBAGAI LES |
| `T007` | KOMPAUN PELBAGAI JPPP |

**19 daripada 25** kod dalam mapping tidak wujud pada production. Kebanyakannya kelihatan seperti data ujian portal (`T001`-`T007`, `KA01`, `100`, `1050`).

### Hanya pada PRODUCTION (tiada dalam staging) — PENTING

| kod | keterangan production | jenis |
|---|---|---|
| `08` | KOMPAUN PELBAGAI JPLS | PELBAGAI |
| `09` | KOMPAUN LESEN JPLS | LESEN |
| `10` | KOMPAUN PELBAGAI JBGN | PELBAGAI |

Kod ini TIDAK PERNAH akan diuji kalau sweep dibina dari mapping sahaja.

## Beza TEKS tingkat-1 (paling merosakkan)

Sweep memilih tingkat 1 mengikut teks yang dipaparkan. Kalau teks berbeza, pemilihan gagal walaupun kod itu wujud pada kedua-dua belah.

| kod | teks STAGING | teks PRODUCTION | sama? |
|---|---|---|---|
| `01` | KOMPAUN PELBAGAI | KOMPAUN PELBAGAI JP | **TIDAK** |
| `02` | KOMPAUN LESEN | KOMPAUN LESEN JP | **TIDAK** |
| `03` | KOMPAUN LETAK KERETA | KOMPAUN LETAK KERETA | ya |
| `05` | KOMPAUN KEBERSIHAN | KOMPAUN KEBERSIHAN | ya |
| `06` | KOMPAUN PELBAGAI PELESENAN | KOMPAUN PELBAGAI JKAP | **TIDAK** |
| `07` | KOMPAUN ANTI LITTER | KOMPAUN LESEN JKAP | **TIDAK** |

**4** daripada 6 kod yang dikongsi mempunyai teks paparan yang BERBEZA.

## Akta

- Hanya dalam staging: **23**
  - `AKT 12012026`
  - `AKT T`
  - `AKTA 171 - AKTA KERAJAAN TEMPATAN 1976`
  - `AKTA BARU 231201`
  - `AKTA BARU 231202`
  - `AKTA JALAN PARIT DAN BANGUNAN 1974`
  - `AKTA PENGANGKUTAN JALAN 1987 (AKTA 133)`
  - `BARU`
  - `SEK 15 (1)`
  - `SEK 46 (1) (E)`
  - `SEK 46 (1)(A)-AKTA JALAN PARIT DAN BANGUNAN 1974`
  - `TA`
  - `TEST 1`
  - `UNDANG-UNDANG KECIL IKLAN PILIHANRAYA (MPPG) 2018`
  - `UNDANG-UNDANG KECIL PERLESENAN HAIWAN TERNAKAN, PELIHARAAN DAN HAIWAN MERAYAU (MBPG) 2021`
  - `UUK BAYARAN DENDA (LESEN) PENJAJA & TRED`
  - `UUK KEDAI GUNTING RAMBUT DAN PENDANDAN RAMBUT`
  - `UUK MENCEGAH KEKOTORAN (MPPG) 2010`
  - `UUK PENGAWALAN & PENGAWASAN TEMPAT MAKAN (MPPG)`
  - `UUK PENGAWALAN & PENGAWASAN TEMPAT-TEMPAT MAKAN`
  - `UUK PENGENDALI MAKANAN (MPPG)2010`
  - `UUK TEST 01`
  - `UUK VANDALISME (MPPG) 2011`
- Hanya pada production: **15**
  - `AKTA JALAN, PARIT DAN BANGUNAN 1974`
  - `AKTA KERAJAAN TEMPATAN 1976`
  - `AKTA PENGANGKUTAN JALAN 1987`
  - `TIDAK AKTIF - AKTA JALAN PARIT DAN BANGUNAN 1974 (AKTA 133) - AKTA JALAN, PARIT DAN BANGUNAN 1974`
  - `TIDAK AKTIF - AKTA JALAN, PARIT DAN BANGUNAN 1974 (AKTA 133)`
  - `TIDAK AKTIF - PENYIMPANAN MAKANAN YANG MENYEBABKAN RISIKO PENCEMARAN BAHAN MENTAH`
  - `TIDAK AKTIF - TIADA SEORANG BOLEH MELUDAH, MEMBUANG HINGGUS DAN MENGHISAP/MENGGUNAKAN TEMBAKAU KETIKA PENJUALAN/PENYEDIAAN MAKANAN.`
  - `TIDAK AKTIF - TIADA SIAPA MEMBIARKAN ADANYA TIKUS, KUMAN, BURUNG DAN BINATANG HIDUP DIMANA-MANA TEMPAT MAKAN`
  - `UNDANG-UNDANG KECIL (UUK) TAMAN (PBTPG) 1993`
  - `UNDANG-UNDANG KECIL BAYARAN DENDA (LESEN) (MPPG) 2011`
  - `UNDANG-UNDANG KECIL KEDAI GUNTING RAMBUT DAN PENDANDAN RAMBUT (MPPG) 2010`
  - `UNDANG-UNDANG KECIL MENCEGAH KEKOTORAN (MPPG) 2010`
  - `UNDANG-UNDANG KECIL PENGAWALAN & PENGAWASAN TEMPAT-TEMPAT MAKAN (MPPG) 2011`
  - `UNDANG-UNDANG KECIL TAMAN (PBTPG) 1993`
  - `UNDANG-UNDANG KECIL VANDALISME (MPPG) 2011`

### Nama akta berulang

- Staging: {'AKTA 171 - AKTA KERAJAAN TEMPATAN 1976': 2, 'BARU': 2, 'akta baru 231202': 2}
- Production: **tiada** — jadi kategori `AMBIGU` yang menandai 130 set staging LENYAP sepenuhnya apabila set dijana dari DB.

## Kesalahan

- Hanya dalam staging: **39**
- Hanya pada production: **24**
- Dikongsi: **88**

## Contoh PM (SEK 46(1)(d) / SEKSYEN 47 bawah PMTLK 2001)

- `SEK 46` pada production: 9 kesalahan, di bawah akta id ['3', '85']
- `SEK 47` pada production: 5 kesalahan, di bawah akta id ['3', '85']

Kalau app membenarkan kombinasi yang tiada di sebelah production, itu DAPATAN dan mesti direkod dalam MATRIX.


"""
RUN PENUH — satu command, satu sesi, semua peringkat.

    python tools/run_penuh.py --tanpa-printer      # malam ini (tiada printer)
    python tools/run_penuh.py                      # esok (dengan printer)

>>> DIREKA UNTUK DIJALANKAN PEMILIK SEORANG DIRI. <<<
Tiada Claude, tiada pembetulan di tengah jalan. Maka:

  * SATU pengesahan `YA` di permulaan, kemudian jalan terus.
  * Setiap peringkat mencatat masanya sendiri; ringkasan penuh pada
    akhir, dan jadual masa ditulis ke reports/.
  * Peringkat yang gagal TIDAK membunuh peringkat lain melainkan ia
    memang mesti (lihat PERINGKAT_MAUT) — supaya satu kegagalan lewat
    tidak membuang sejam kerja yang sudah berjaya.
  * Setiap nombor rekod ditulis SERTA-MERTA (fsync) — kalau USB
    tercabut, nombor tetap ada.

>>> KENAPA SATU SESI. <<<
`run_e2e.py` dan `run_e2e_menu.py` masing-masing membina sesi Appium
sendiri: peringkat_1 (device/baseline) + peringkat_2 (sesi + login).
Menjalankan tiga skrip bermakna membayar kos itu TIGA KALI. Skrip ini
membinanya SEKALI dan menghantar `drv`/`pages` yang sama ke setiap
peringkat. Itu pengoptimuman masa terbesar yang tersedia tanpa
menyentuh logik ujian.

>>> D-01 — SELARAS ALAMAT AKAN MERANAP APP. <<<
`docs/DEFEK-MBPG-2.1.21.md`: Selaras Maklumat Alamat BUKAN idempotent.
Peranti ini SUDAH disync, jadi larian kedua menghasilkan
`Duplicate entry for local_ekpn_bandar/jalan` dan app TERCAMPAK KELUAR.
Itu defek app yang sudah direkod, bukan kegagalan skrip.

Prosedur pemulihan yang didokumenkan diikut di sini: relaunch,
sahkan DB tidak korup, sambung. Peringkat itu dicatat `RANAP-D-01`
supaya laporan menamakan defek dan bukan menyalahkan automasi.

>>> T-008 SELARAS PELESEN — TIDAK PERNAH DIJALANKAN. <<<
Sync 3-4 JAM. Ia bukan dalam senarai peringkat, `pelarasan_page`
melontar NotImplementedError, dan corong menyekat ketukan pada item
menu itu. Tiga lapisan, kesemuanya kekal.
"""

import argparse
import os
import sys
import time
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
AKAR = os.path.dirname(HERE)
sys.path.insert(0, AKAR)

from tools import forensik                                      # noqa: E402
from tools import semak_siri                                    # noqa: E402
from tools import rekod_log                                     # noqa: E402
from tools.izin_e2e import IzinE2E, IzinTidakSah                # noqa: E402

# Peringkat yang, kalau gagal, menjadikan peringkat berikutnya tidak
# bermakna. Semua yang lain dicatat GAGAL dan larian TERUSKAN — satu
# kegagalan lewat tidak sepatutnya membuang sejam kerja yang berjaya.
PERINGKAT_MAUT = ("sesi",)

# >>> PLAT mySIKAP — ujian regresi D-09(b). <<<
# Dibekalkan pemilik 2026-08-18. Ketiga-tiganya SAH pada mySIKAP, jadi
# carian yang gagal bermakna defek dan bukan plat rekaan.
#
# Tiga rekod K dicipta berturut-turut, satu plat setiap satu, dalam
# SESI YANG SAMA — kerana itulah keadaan yang pemeriksa laporkan
# menyebabkan butiran pemilik terdahulu melekat. Mencipta satu rekod
# per sesi akan menyembunyikan defek yang sedang diuji.
PLAT_MYSIKAP = ("JYX6605", "JUA3276", "JRT2649")

# Selaras yang dibenarkan. T-008 (Pelesen) SENGAJA TIADA.
SELARAS = [
    ("T-003", "Selaras Pengguna Apps",          "selaras_pengguna_apps"),
    ("T-004", "Selaras Maklumat Alamat",        "selaras_maklumat_alamat"),
    ("T-005", "Selaras Maklumat Kompaun",       "selaras_maklumat_kompaun"),
    ("T-006", "Selaras Maklumat Jenis Kenderaan", "selaras_jenis_kenderaan"),
    ("T-007", "Selaras Maklumat Warna",         "selaras_maklumat_warna"),
    ("T-009", "Selaras Maklumat Barang Sita",   "selaras_barang_sita"),
]


class Jejak:
    """Masa + status setiap peringkat. Dicetak walaupun larian mati."""

    def __init__(self):
        self.baris = []
        self.mula_sesi = time.time()

    def catat(self, nama, status, nota="", tempoh=None):
        self.baris.append({
            "peringkat": nama, "status": status, "nota": nota,
            "tempoh_s": round(tempoh or 0, 1),
            "masa": time.strftime("%H:%M:%S"),
        })
        tanda = {"LULUS": "[OK ]", "GAGAL": "[!! ]", "SKIP": "[-- ]",
                 "RANAP-D-01": "[D01]"}.get(status, "[   ]")
        print(f"\n{tanda} {nama}: {status}  ({round(tempoh or 0, 1)}s)"
              + (f" — {nota}" if nota else ""))

    def jumlah(self):
        return time.time() - self.mula_sesi

    def papar(self):
        print("\n" + "=" * 70)
        print("== JADUAL MASA")
        print("=" * 70)
        print(f"  {'PERINGKAT':<14} {'STATUS':<12} {'TEMPOH':>9}  NOTA")
        for b in self.baris:
            print(f"  {b['peringkat']:<14} {b['status']:<12} "
                  f"{b['tempoh_s']:>8}s  {b['nota'][:44]}")
        jum = self.jumlah()
        print(f"\n  JUMLAH SESI: {int(jum // 60)}m {int(jum % 60)}s "
              f"({jum / 3600:.2f} jam)")
        sasaran = 2 * 3600
        print(f"  Sasaran pemilik: bawah 2 jam — "
              f"{'TERCAPAI' if jum < sasaran else 'TERLEBIH'}")
        self.papar_verdik()

    def gagal(self):
        return [b for b in self.baris if b["status"] == "GAGAL"]

    def papar_verdik(self):
        """Keputusan yang mesti dibaca, dicetak SELEPAS jadual masa.

        >>> KENAPA INI WUJUD BERASINGAN DARIPADA TRACEBACK. <<<
        `semak D-09` bukan peringkat maut, jadi larian meneruskan ke
        peringkat menu selepasnya — kira-kira 20 minit output. Traceback
        yang membuktikan mySIKAP masih rosak akan bergulir hilang jauh
        sebelum larian tamat, dan pemilik menjalankan ini SENDIRI tanpa
        sesiapa membaca skrol bersamanya.
        """
        d09 = [b for b in self.baris if b["peringkat"] == "semak D-09"]
        print("\n" + "=" * 70)
        print("== VERDIK")
        print("=" * 70)
        if not d09:
            print("  D-09 mySIKAP : TIDAK DIUJI - peringkat tidak berjalan")
        elif "TIDAK DIUJI" in d09[0]["nota"]:
            # >>> TIGA KEADAAN, BUKAN DUA. <<<
            # Peringkat yang GAGAL kerana ia tidak dapat dijalankan
            # BUKAN bukti bahawa defek masih ada. Melipatnya ke dalam
            # "MASIH ROSAK" menghasilkan penggera palsu; melipatnya ke
            # dalam "BERSIH" menghasilkan keyakinan palsu. Itu yang
            # berlaku pada 2026-08-18.
            print("  D-09 mySIKAP : TIDAK DIUJI")
            print("                 0 rekod K dicipta - ketiga-tiga "
                  "borang K gagal sebelum")
            print("                 sempat mencipta apa-apa. Hotfix "
                  "BELUM terbukti.")
        elif d09[0]["status"] == "LULUS":
            print("  D-09 mySIKAP : BERSIH pada build ini")
            print("                 identiti padan dengan plat pada "
                  "setiap rekod K")
        else:
            print("  D-09 mySIKAP : >>> MASIH ROSAK <<<")
            print("                 " + d09[0]["nota"][:60])
            print("                 Rekod K yang dicipta membawa "
                  "identiti yang TIDAK BOLEH dipercayai.")
            print("                 Batalkan kesemuanya. Jangan serahkan "
                  "kepada penguatkuasaan.")
        buruk = self.gagal()
        if buruk:
            print("")
            print(f"  {len(buruk)} peringkat GAGAL:")
            for b in buruk:
                print(f"    - {b['peringkat']:<22} {b['nota'][:44]}")
            print("")
            print("  D-08 (selaras T-005) dan D-01 (selaras alamat) "
                  "ialah defek app")
            print("  yang sudah diketahui — kegagalan di situ DIJANGKA.")
        else:
            print("")
            print("  Semua peringkat lulus.")


def minta_tetapan(args):
    """Tanya IP + lesen di AWAL, sebelum apa-apa menyentuh peranti.

    >>> KENAPA DITANYA, BUKAN DIBACA DARI PROFIL SAHAJA. <<<
    Cadangan pemilik 2026-08-18. Nilai ini hidup pada PERANTI, bukan
    dalam repo — dan pemasangan APK bersih memadamnya. Menanyakannya di
    awal bermakna:

      * skrip boleh memulihkan tetapan tanpa sesiapa menyunting kod;
      * nilai yang akan DITULIS kelihatan sebelum ia ditulis, bukan
        tersembunyi dalam fail profil;
      * peranti atau PBT lain boleh digunakan tanpa profil baharu.

    Profil kekal sebagai LALAI — tekan Enter untuk menerimanya. Itu
    menjadikan kes biasa satu ketukan, dan kes luar biasa mungkin.

    `--ip` / `--lesen` mengatasi prompt untuk larian tanpa terminal.
    """
    from config import PROFILE

    ip_lalai = PROFILE.get("external_ip") or ""
    lesen_lalai = PROFILE.get("lesen_aplikasi") or ""

    ip = (args.ip or "").strip()
    lesen = (args.lesen or "").strip()

    boleh_tanya = sys.stdin.isatty() and not args.terus
    if not ip and boleh_tanya:
        jwp = input(f"{chr(10)}  Alamat IP server "
                    f"[{ip_lalai}]: ").strip()
        ip = jwp or ip_lalai
    ip = ip or ip_lalai

    if not lesen and boleh_tanya:
        tunjuk = (lesen_lalai[:4] + "..." + lesen_lalai[-3:]
                  if len(lesen_lalai) > 8 else lesen_lalai)
        jwp = input(f"  Nombor lesen aplikasi [{tunjuk}]: ").strip()
        lesen = jwp or lesen_lalai
    lesen = lesen or lesen_lalai

    # >>> IP YANG BERBEZA DARIPADA PROFIL IALAH TUKAR SASARAN. <<<
    # Memulihkan tetapan yang peranti kehilangan adalah satu perkara;
    # menghala suite ke server LAIN adalah perkara lain sepenuhnya.
    # Gerbang dalam `peringkat_1` membandingkan dengan IP production
    # yang dikodkan, jadi IP lain akan MENGHENTIKAN larian — itu betul,
    # bukan pepijat. Amaran ini menjadikannya jelas sebelum masa.
    if ip and ip != ip_lalai:
        print(f"{chr(10)}  AMARAN: IP yang dimasukkan ({ip}) BERBEZA "
              f"daripada "
              f"profil ({ip_lalai}).")
        print("  Itu menukar SASARAN, bukan memulihkan tetapan. Gerbang "
              "peringkat 1 akan menghentikan larian.")

    return ip, lesen


class D09TidakDiuji(RuntimeError):
    """Semakan tidak dapat dijalankan — BUKAN lulus, BUKAN rosak.

    Tiga keadaan berbeza, dan melipat mana-mana dua daripadanya menjadi
    satu ialah tepat kesilapan yang berlaku pada 2026-08-18.
    """


def semak_d09(serial, sejak):
    """Bandingkan identiti yang DISIMPAN dengan plat yang DIPOHON.

    >>> KENAPA `sejak` WAJIB. <<<
    Versi pertama menapis "rekod K hari ini". Pada larian 2026-08-18
    petang, ketiga-tiga borang K gagal sebelum sempat mencipta apa-apa —
    namun penapis itu menemui `PGP02K260818008` daripada sesi PAGI dan
    melaporkan "1 rekod K bersih". Verdik akhir kemudian mengisytiharkan
    D-09 BERSIH pada build ini, berdasarkan rekod yang dicipta oleh
    build LAMA, dalam larian yang berlainan.

    Itu pengesahan yang tidak boleh gagal — kelas kesilapan yang sama
    yang menyebabkan K-001 dilaporkan LULUS pada mulanya. `sejak` ialah
    cap masa permulaan sesi; hanya rekod selepas itu dikira.

    Perbandingan ini hanya bermakna MERENTAS rekod, jadi ia tidak boleh
    hidup di dalam mana-mana satu daripadanya.

    Nombor diambil dari `rekod_log` dan bukan dari nilai pulangan
    peringkat, kerana log ditulis dengan `fsync` sebaik nombor wujud —
    ia kekal betul walaupun peringkat kemudiannya gagal.
    """
    from tools import rekod_log, semak_mysikap
    from devtools.smoke_tangga import tarik_db

    semua = rekod_log.baca_semua()
    nombor = {d.get("no_rekod") for d in semua
              if d.get("borang") == "K" and d.get("no_rekod")
              and str(d.get("masa", "")) >= sejak}
    if not nombor:
        lama = len([d for d in semua if d.get("borang") == "K"])
        raise D09TidakDiuji(
            "D-09 TIDAK DIUJI - 0 rekod K dicipta dalam larian ini "
            "(sejak %s). %d rekod K lain wujud dari larian terdahulu "
            "dan SENGAJA diabaikan: ia dicipta oleh build lain, dalam "
            "sesi lain, dan tidak membuktikan apa-apa tentang build "
            "ini." % (sejak, lama))

    db = tarik_db(serial, os.path.join(AKAR, "data", "tmp", "semak_d09.db"))
    bil = semak_mysikap.lapor(db, hanya=nombor)
    if bil:
        raise RuntimeError(
            "D-09 MASIH ADA pada build ini - %d dapatan merentas "
            "%d rekod K. Lihat output di atas." % (bil, len(nombor)))
    return "%d rekod K larian ini bersih" % len(nombor)


def ip_peranti_kosong(serial):
    """True kalau peranti TIADA IP dikonfigurasi langsung.

    Bezakan dua keadaan yang kelihatan sama pada gerbang:

      IP TIADA      pemasangan bersih memadam data app. Nilai betul ada
                    dalam profil, jadi automasi boleh memulihkannya
                    tanpa meneka apa-apa. Ini BOOTSTRAP.

      IP ADA tetapi BUKAN production — sesuatu yang tidak dijangka.
                    Gerbang KEKAL berhenti; itu keadaan yang reka
                    bentuk asal (PAPAN §4) wujud untuk menangkap.
    """
    import sqlite3
    from devtools.smoke_tangga import tarik_db

    try:
        db = tarik_db(serial, os.path.join(AKAR, "data", "tmp",
                                           "semak_ip.db"))
        con = sqlite3.connect(db)
        baris = con.execute(
            "SELECT ip_address FROM local_connection_details").fetchall()
        return not baris
    except Exception:                                           # noqa: BLE001
        return False


def bootstrap_tetapan(drv, pages, ip=None, lesen=None):
    """Pulihkan IP + Lesen daripada PROFIL selepas pemasangan bersih.

    >>> KENAPA INI BUKAN PELANGGARAN KEPADA KEPUTUSAN 2026-08-10. <<<
    `peringkat_t001` dihentikan daripada menulis kerana **D-02**: medan
    Internal IP diterima, dipaparkan, read-back lulus — kemudian HILANG
    selepas app dimulakan semula. Keputusan waktu itu ialah berhenti
    mengejar nilai yang app SENDIRI buang.

    Ini keadaan berbeza. Pemasangan 2.1.23 memadam SEMUA data app:
    `local_connection_details` kosong, jadi app tidak boleh capai server
    langsung. Itu bootstrap, bukan mengejar nilai yang dibuang.

    Nilai TIDAK diteka — ia dibaca dari profil, dan pemilik mengesahkan
    2026-08-18 bahawa IP dan lesen tidak berubah; hanya versi APK.

    Dijalankan HANYA apabila IP benar-benar TIADA. Kalau IP wujud tetapi
    salah, gerbang asal kekal berhenti.
    """
    from config import PROFILE

    # Nilai yang pemilik masukkan di awal MENGATASI profil; profil
    # hanya lalai. Lihat `minta_tetapan()`.
    ip_luar = ip or PROFILE.get("external_ip")
    ip_dalam = ip or PROFILE.get("internal_ip")
    lesen = lesen or PROFILE.get("lesen_aplikasi")
    p = pages.pelarasan

    print(chr(10) + "!" * 70)
    print("!! BOOTSTRAP TETAPAN — peranti tiada IP (pemasangan bersih)")
    print(f"!! IP dari profil : {ip_luar}")
    print("!! Lesen dari profil: (tidak dicetak)")
    print("!" * 70)

    p.set_tetapan_alamat_ip(ip_dalam, ip_luar)
    if lesen:
        try:
            p.set_tetapan_pelbagai(lesen)
        except Exception as e:                                  # noqa: BLE001
            print(f"  [BOOTSTRAP] set lesen gagal ({type(e).__name__}) — "
                  f"IP sudah ditetapkan, teruskan")
    return f"IP={ip_luar}, lesen dipulihkan dari profil"


def bersihkan_skrin(drv, pages, tag=""):
    """Salirkan dialog asli yang tersangkut sebelum peringkat bermula.

    >>> KENAPA INI PERLU SETIAP KALI. <<<
    `Alert | Error: Unable to connect device` tersangkut pada skrin
    utama dan menyekat SETIAP ketukan selepasnya — larian 2026-08-17
    mati pada `[HOME] Opening Daftar Kompaun module...` dengan
    `Element not clickable`, tiga kali berturut.

    Bukti kuat ia merujuk PRINTER Bluetooth dan bukan server: larian
    yang sama mencatat `bluetooth=False tersambung=False printer=None`,
    dan `ping 113.211.155.174` dari peranti memulangkan 0% loss. Malam
    ini tiada printer, jadi alert itu berulang; esok dengan printer
    hidup ia mungkin tidak muncul langsung.

    Skrip mesti tahan KEDUA-DUA keadaan, jadi alert disalir sebelum
    setiap peringkat dan bukan diandaikan tiada.

    Teksnya ada dalam `ALERT_INFO_SELAMAT`, jadi corong membenarkan OK
    menutupnya — ini bukan melonggarkan gerbang.
    """
    for objek in (getattr(pages, "home", None),
                  getattr(pages, "daftar_kompaun", None)):
        if objek is None:
            continue
        try:
            objek.dismiss_native_alerts(first_timeout=2,
                                        context=f"pra-{tag}")
            return True
        except Exception:                                       # noqa: BLE001
            continue
    return False


def jalankan(jejak, nama, fn, maut=False):
    """Jalankan satu peringkat, ukur masa, jangan biarkan kegagalannya
    membunuh peringkat lain melainkan ia memang maut."""
    t0 = time.time()
    try:
        nota = fn() or ""
        jejak.catat(nama, "LULUS", str(nota)[:120], time.time() - t0)
        return True
    except BaseException as e:                                  # noqa: BLE001
        ringkas = f"{type(e).__name__}: {str(e).splitlines()[0][:100]}"
        jejak.catat(nama, "GAGAL", ringkas, time.time() - t0)
        forensik.tangkap(nama, e)
        tangkap_kegagalan(nama, e)
        if maut or nama in PERINGKAT_MAUT:
            raise
        # DryRunViolation bermakna corong menyekat sesuatu — itu
        # sentiasa maut, tanpa mengira peringkat.
        from guard.dasar import DryRunViolation
        if isinstance(e, DryRunViolation):
            raise
        traceback.print_exc()
        return False


def peringkat_selaras(drv, pages, serial, jejak):
    """Setiap modul Selaras, satu per satu. T-008 tiada di sini.

    >>> MENU SELARAS HANYA WUJUD PADA SKRIN LOGIN. <<<
    Diukur 2026-08-17, dan ia menjelaskan kenapa larian pertama
    orkestrator ini gagal pada KESEMUA enam modul:

        docs/recon/cetak-A-skrin-utama.xml  (selepas login)  U+F0C9 TIADA
        ui_dumps/t010_skrin_utama.xml       (skrin login)    U+F0C9 ADA

    Hamburger yang membuka Menu Selaras tidak wujud selepas log masuk.
    `home_page.py:154` sudah mencatatnya ("Kaedah ini hanya sah pada
    skrin LOGIN"), dan setiap larian yang BERJAYA sebelum ini membuka
    Menu Selaras semasa gerbang IP — iaitu SEBELUM login.

    Maka peringkat ini merestart app untuk kembali ke skrin login,
    menjalankan keenam-enam modul di sana, dan baru log masuk semula.
    Log masuk dikendalikan oleh pemanggil selepas ini.
    """
    import time as _t
    from config import APP_PACKAGE

    p = pages.pelarasan
    lulus, gagal = 0, 0

    # Kembali ke skrin login. terminate+activate ialah laluan pemulihan
    # rasmi (peringkat6.relaunch) — bukan force-stop, pakej tidak
    # disentuh.
    print("\n  [SELARAS] kembali ke skrin login (hamburger hanya di sana)")
    try:
        drv.terminate_app(APP_PACKAGE)
        _t.sleep(2)
        drv.activate_app(APP_PACKAGE)
        _t.sleep(5)
    except Exception as e:                                      # noqa: BLE001
        print(f"  [SELARAS] restart app gagal ({type(e).__name__})")
    for tc, nama, kaedah in SELARAS:
        t0 = time.time()
        try:
            # >>> BERSIHKAN SKRIN DAHULU — diukur 2026-08-17. <<<
            # Larian pertama orkestrator ini gagal pada KESEMUA enam
            # modul dengan `Element not clickable`. Puncanya bukan
            # rangkaian (ping ke 113.211.155.174 = 0% loss) dan bukan
            # locator: dialog asli `Alert | Error: Unable to connect
            # device` tersangkut pada skrin utama dan menutupi Menu
            # Selaras.
            #
            # Dialog itu gangguan yang diketahui — ia muncul dalam
            # larian N-001 yang BERJAYA juga — tetapi di sana
            # `pastikan_di_home()` menyalirkannya dahulu. Peringkat ini
            # memanggil `open_menu_selaras()` terus, jadi ia tidak
            # pernah dibuang.
            #
            # Ia disenaraikan dalam ALERT_INFO_SELAMAT, jadi corong
            # membenarkan OK menutupnya; ini bukan melonggarkan gerbang.
            # Kita berada pada skrin LOGIN di sini, bukan skrin utama.
            # Alert `Unable to connect device` masih boleh tersangkut,
            # jadi salirkan dahulu — ia disenaraikan dalam
            # ALERT_INFO_SELAMAT, jadi corong membenarkan OK menutupnya.
            try:
                p.dismiss_native_alerts(first_timeout=2,
                                        context=f"pra-{tc}")
            except Exception:                                   # noqa: BLE001
                pass
            p.open_menu_selaras()
            getattr(p, kaedah)()
            try:
                p.close_menu_selaras()
            except Exception:                                   # noqa: BLE001
                pass
            jejak.catat(f"selaras {tc}", "LULUS", nama,
                        time.time() - t0)
            lulus += 1
        except BaseException as e:                              # noqa: BLE001
            from guard.dasar import DryRunViolation
            if isinstance(e, DryRunViolation):
                raise
            # D-01: Selaras Alamat meranapkan app pada sync kedua.
            # Prosedur pemulihan yang didokumenkan: relaunch, sahkan DB
            # bersih, sambung.
            ringkas = f"{type(e).__name__}: {str(e).splitlines()[0][:80]}"
            gagal += 1
            jejak.catat(f"selaras {tc}", "RANAP-D-01" if tc == "T-004"
                        else "GAGAL", ringkas, time.time() - t0)
            # Pemulihan mesti memulangkan kita ke skrin LOGIN, bukan
            # skrin utama — modul seterusnya perlukan hamburger.
            try:
                p.close_menu_selaras()
            except Exception:                                   # noqa: BLE001
                pass
            try:
                drv.terminate_app(APP_PACKAGE)
                _t.sleep(2)
                drv.activate_app(APP_PACKAGE)
                _t.sleep(5)
            except Exception:                                   # noqa: BLE001
                pass
    # >>> AGREGAT TIDAK BOLEH LAPOR LULUS BILA SEMUA ANAK GAGAL. <<<
    # Larian pertama mencetak `selaras LULUS 652.8s` sedangkan
    # kesemua enam modul GAGAL — kerana fungsi ini memulangkan rentetan
    # dan pembungkusnya menganggap "tiada exception" bermakna berjaya.
    # Baris ringkasan yang berbohong lebih teruk daripada tiada
    # ringkasan: ia satu-satunya baris yang pemilik akan baca.
    # Log masuk semula — peringkat selepas ini semuanya perlukan skrin
    # utama. Log masuk dibuat DI SINI dan bukan diserahkan kepada
    # pemanggil supaya kegagalannya dikira sebahagian peringkat selaras
    # dan bukan muncul sebagai kegagalan misteri pada borang P.
    print("\n  [SELARAS] log masuk semula selepas selaras")
    try:
        from devtools.smoke_tangga import pastikan_di_home
        from config import TEST_CREDENTIALS
        if pages.login.is_login_screen_displayed():
            pages.login.login(TEST_CREDENTIALS["username"],
                              TEST_CREDENTIALS["password"])
        pastikan_di_home(drv, pages)
    except Exception as e:                                      # noqa: BLE001
        raise RuntimeError(
            f"tidak dapat log masuk semula selepas selaras: "
            f"{type(e).__name__}: {str(e).splitlines()[0][:90]}")

    ringkas = (f"{lulus} lulus, {gagal} gagal daripada {len(SELARAS)} "
               f"modul (T-008 TIDAK disentuh)")
    if lulus == 0:
        raise RuntimeError(f"SEMUA modul selaras gagal — {ringkas}")
    return ringkas


def main(argv=None):
    ap = argparse.ArgumentParser(
        description="Run penuh MBPG — satu sesi, semua peringkat.")
    ap.add_argument("--borang", default="PK",
                    help="borang untuk dicipta (lalai PK; 'x' untuk langkau)")
    ap.add_argument("--plat", nargs="*", default=None,
                    help="plat mySIKAP untuk borang K (lalai: tiga plat "
                         "ujian D-09). Satu plat = D-09(b) TIDAK DIUJI.")
    ap.add_argument("--tanpa-printer", action="store_true",
                    help="teruskan walaupun printer tidak sedia "
                         "(peringkat CETAK dilangkau)")
    ap.add_argument("--langkau-selaras", action="store_true")
    ap.add_argument("--langkau-menu", action="store_true")
    ap.add_argument("--terus", action="store_true",
                    help="langkau pengesahan YA (jeda 5s Ctrl-C kekal)")
    ap.add_argument("--ip", default=None,
                    help="alamat IP server (lalai: dari profil). "
                         "Mengatasi prompt untuk larian tanpa terminal.")
    ap.add_argument("--lesen", default=None,
                    help="nombor lesen aplikasi (lalai: dari profil)")
    args = ap.parse_args(argv)

    from tools.run_e2e import minta_ya, urai_borang, jalankan_satu

    borang = [] if args.borang.lower() == "x" else urai_borang(args.borang)

    try:
        izin = IzinE2E.baca(AKAR)
    except IzinTidakSah as e:
        print(f"HENTI: {e}")
        return 2
    r = izin.ringkasan()
    if r["luput"]:
        print(f"HENTI: {r['sebab_luput']}")
        return 2

    ip_pilihan, lesen_pilihan = minta_tetapan(args)

    if not minta_ya({
        "IP server": ip_pilihan or "(tiada)",
        "lesen": ("..." + lesen_pilihan[-4:]) if lesen_pilihan else "(tiada)",
        "peringkat": ("selaras -> " if not args.langkau_selaras else "")
                     + ("+".join(borang) + " -> " if borang else "")
                     + ("menu senarai/hantar/tarik"
                        if not args.langkau_menu else "(menu dilangkau)"),
        "mod sebenar": "HIDUP",
        "printer": "DILANGKAU" if args.tanpa_printer else "diperlukan",
        "T-008 Pelesen": "TIDAK DISENTUH",
        "NK": "SKIP (notis belum layak)",
        "log rekod": os.path.relpath(rekod_log.laluan_log(), AKAR),
    }, args.terus):
        return 1

    from devtools import peringkat6 as P6
    from devtools.smoke_tangga import peringkat_1, peringkat_2
    from device_utils import resolve_udid
    from config import APP_PACKAGE

    jejak = Jejak()
    # Sempadan untuk `semak_d09`: rekod SEBELUM detik ini milik
    # larian lain dan tidak membuktikan apa-apa tentang build ini.
    mula_iso = time.strftime('%Y-%m-%d %H:%M:%S')
    serial = resolve_udid(APP_PACKAGE, verbose=False)
    p1 = peringkat_1(serial)
    if not p1["ok"]:
        # >>> BOOTSTRAP: IP TIADA vs IP SALAH. <<<
        # Pemasangan APK bersih (2.1.23, 2026-08-18) memadam SEMUA data
        # app — `local_connection_details` kosong, jadi app tidak boleh
        # capai server dan setiap peringkat selepasnya gagal dengan cara
        # yang mengelirukan.
        #
        # Nilai betul ADA dalam profil dan pemilik mengesahkan ia tidak
        # berubah; hanya versi APK. Jadi automasi memulihkannya — tiada
        # tekaan terlibat.
        #
        # Kalau IP WUJUD tetapi bukan production, itu keadaan lain
        # sepenuhnya dan gerbang asal (PAPAN §4) kekal berhenti.
        if not ip_peranti_kosong(serial):
            print("HENTI: peringkat 1 gagal (IP wujud tetapi bukan "
                  "production — pembetulan manual diperlukan).")
            return 1
        print(chr(10) + "  IP peranti KOSONG — cuba bootstrap dari profil...")
        # Sesi MENTAH: `create_driver()` + `Pages()` sahaja. Kita TIDAK
        # boleh guna `peringkat_2()` di sini kerana ia menjalankan
        # gerbang IP dan log masuk — dan kedua-duanya memerlukan IP yang
        # belum wujud. Ini satu-satunya tempat dalam suite yang memintas
        # gerbang itu, dan ia dibenarkan HANYA kerana semakan
        # `ip_peranti_kosong()` di atas sudah membuktikan tiada IP
        # langsung untuk dilanggar.
        try:
            from tests.conftest import create_driver, Pages
            drv_boot = create_driver()
            pages_boot = Pages(drv_boot)
        except Exception as e:                                  # noqa: BLE001
            print(f"HENTI: tidak dapat membina sesi untuk bootstrap "
                  f"({type(e).__name__}).")
            return 1
        try:
            jalankan(jejak, "bootstrap tetapan",
                     lambda: bootstrap_tetapan(drv_boot, pages_boot,
                                               ip=ip_pilihan,
                                               lesen=lesen_pilihan))
        finally:
            try:
                drv_boot.quit()
            except Exception:                                   # noqa: BLE001
                pass
        p1 = peringkat_1(serial)
        if not p1["ok"]:
            print("HENTI: IP masih tidak betul selepas bootstrap.")
            return 1
    P6.baseline_global = p1["baseline"]

    # >>> GERBANG KAUNTER SIRI — SEBELUM app dilancarkan. <<<
    # Pemasangan APK bersih mengosongkan `local_system_control`, jadi
    # kaunter bermula semula sedangkan rekod lama masih hidup pada
    # production. Kaunter kompaun berdiri pada 3 selepas larian
    # 2026-08-18 petang, dan `PGP02P260818003` SUDAH wujud dari sesi
    # pagi hari itu.
    #
    # Berhenti adalah betul di sini, tidak seperti kebanyakan kegagalan
    # peringkat: kerosakan berlaku pada SAAT rekod dicipta dan tiada
    # pemulihan selepasnya. Diletakkan sebelum `peringkat_2()` supaya
    # app tidak dilancarkan langsung.
    try:
        nota_siri = semak_siri.gerbang(serial)
        jejak.catat("gerbang siri", "LULUS", nota_siri, 0)
    except Exception as e:                                      # noqa: BLE001
        jejak.catat("gerbang siri", "GAGAL", str(e)[:100], 0)
        print("")
        print("!" * 70)
        print("HENTI: " + str(e))
        print("!" * 70)
        jejak.papar()
        return 2

    drv = None
    try:
        t0 = time.time()
        drv, pages = peringkat_2()
        forensik.set_driver(drv)
        drv.corong.tetapan.mod_sebenar = True
        jejak.catat("sesi", "LULUS", "sesi + login + mod sebenar HIDUP",
                    time.time() - t0)
        print("\n" + "!" * 70)
        print("!! MBPG_MOD_SEBENAR = HIDUP — rekod SEBENAR akan dicipta")
        print("!! T-008 Selaras Pelesen TIDAK akan disentuh.")
        print("!" * 70)

        konteks = {"drv": drv, "pages": pages, "serial": serial,
                   "jejak": []}

        if not args.langkau_selaras:
            jalankan(jejak, "selaras",
                     lambda: peringkat_selaras(drv, pages, serial, jejak))

        kelas_args = argparse.Namespace(
            set_id=None, tanpa_printer=args.tanpa_printer,
            mod_sebenar=True, kitaran="penuh", paksa_nk=False,
            kuota=None, terus=True, borang=args.borang)
        plat_k = list(args.plat) if args.plat else list(PLAT_MYSIKAP)
        rekod_k = []
        for huruf in borang:
            if huruf != "K":
                bersihkan_skrin(drv, pages, f"borang-{huruf}")
                jalankan(jejak, f"borang {huruf}",
                         lambda h=huruf: jalankan_satu(h, izin, kelas_args,
                                                       konteks))
                continue
            # >>> K DIULANG SEKALI BAGI SETIAP PLAT. <<<
            # Satu kegagalan plat tidak menamatkan urutan: D-09(b)
            # memerlukan sebanyak mungkin rekod untuk dibandingkan, dan
            # rekod yang sudah dicipta kekal berguna walaupun yang
            # berikutnya gagal.
            for i, pl in enumerate(plat_k, 1):
                bersihkan_skrin(drv, pages, f"borang-K-{i}")
                tag = f"borang K [{i}/{len(plat_k)}] {pl}"
                jalankan(jejak, tag,
                         lambda p=pl: jalankan_satu("K", izin, kelas_args,
                                                    konteks, plat=p))
                rekod_k.append(pl)

        if rekod_k:
            jalankan(jejak, "semak D-09", lambda: semak_d09(serial, mula_iso))

        if not args.langkau_menu:
            bersihkan_skrin(drv, pages, "menu")
            jalankan(jejak, "menu", lambda: peringkat_menu(konteks, izin))

        # >>> KOD KELUAR MESTI MENCERMINKAN KEGAGALAN. <<<
        # Sebelum ini `return 0` tanpa syarat: larian yang mendapati
        # D-09 masih rosak keluar dengan status BERJAYA. Sesiapa yang
        # membungkusnya dalam skrip, atau sekadar melihat prompt kembali
        # tanpa ralat, akan menyangka semuanya baik.
        return 1 if jejak.gagal() else 0
    except BaseException as e:                                  # noqa: BLE001
        print(f"\n{'!' * 70}\n!! BERHENTI — {type(e).__name__}\n{'!' * 70}")
        # >>> CETAK SELAMAT-ENCODING. <<<
        # Mesej DryRunViolation membawa aksara kotak (U+2550). Konsol
        # Windows di sini ialah cp1252, jadi `print` mentah membangkitkan
        # UnicodeEncodeError — yang MENUTUPI ralat sebenar dan menukar
        # exit code. Diperhati 2026-08-17: pelanggaran HANTAR dilaporkan
        # kepada pemilik sebagai UnicodeEncodeError, yang tidak memberi
        # petunjuk langsung tentang apa yang sebenarnya disekat.
        try:
            print(str(e)[:1500])
        except UnicodeEncodeError:
            sys.stdout.buffer.write(
                str(e)[:1500].encode("ascii", "backslashreplace") + b"\n")
        return 1
    finally:
        jejak.papar()
        semua = rekod_log.baca_semua()
        if semua:
            print(f"\n== NOMBOR REKOD DILOG: {len(semua)}")
            for rr in semua:
                print(f"  {str(rr['no_rekod']):<18} {rr['tc']:<8} "
                      f"{rr['status']}")
            print(f"\n  Log untuk PM: "
                  f"{os.path.relpath(rekod_log.laluan_log(), AKAR)}")
        if drv is not None:
            c = getattr(drv, "corong", None)
            if c is not None:
                print(f"  [CORONG] {c.bil_tap} tap dinilai, "
                      f"{c.bil_sekat} disekat")
            try:
                drv.quit()
            except Exception:                                   # noqa: BLE001
                pass


def lapor_kelayakan_nk(serial):
    """Cetak bila setiap notis menjadi layak ditukar. Baca-sahaja.

    Tiada apa yang boleh gagal di sini — ia laporan, bukan gerbang.
    Sekatannya milik APP (notis mesti luput tempoh), jadi melaporkannya
    sebagai kegagalan ujian akan salah menuduh.
    """
    import datetime
    import sqlite3
    from devtools.smoke_tangga import tarik_db
    from tools.run_e2e_menu import notis_layak_nk

    try:
        db = tarik_db(serial, os.path.join(AKAR, "data", "tmp",
                                           "nk_kelayakan.db"))
        c = sqlite3.connect(db)
        baris = c.execute("SELECT noNotis, tarikh, tempoh "
                          "FROM local_ekpn_notis_amaran").fetchall()
        c.close()
    except Exception as e:                                      # noqa: BLE001
        print(f"  [NK] tidak dapat membaca notis ({type(e).__name__})")
        return

    baris = [(n, str(t)[:10], p) for n, t, p in baris]
    layak, belum = notis_layak_nk(baris)
    print("")
    print(f"  [NK] penukaran notis->kompaun: "
          f"{len(layak)} layak, {len(belum)} belum")
    if layak:
        print(f"       LAYAK: {layak[:5]} — NK-001/002 boleh diuji "
              f"sekarang. Peringkat itu masih TIDAK dijalankan secara "
              f"automatik; borang di sebalik [KOMPAUN] belum pernah "
              f"dilihat dan membuka borang membakar nombor siri (D-07).")
    else:
        awal = sorted(b[1] for b in belum if isinstance(b, tuple)
                      and len(b) > 1)
        print(f"       tiada yang layak; paling awal "
              f"{awal[0] if awal else '?'}")
        print(f"       NK-001/002 KEKAL TIDAK DIUJI — sekatan app, "
              f"bukan kekurangan skrip.")


def peringkat_menu(konteks, izin):
    """SK-001 senarai, H-001..003 hantar, TN-001..003 tarik.

    NK sengaja TIDAK dijalankan: notis belum layak ditukar sehingga
    tarikh eligibiliti (lihat run_e2e.tarikh_layak_nk).
    """
    from tools import run_e2e_menu as RM
    from devtools.smoke_tangga import tarik_db
    from devtools import fasa_c as FC

    drv, pages, serial = (konteks["drv"], konteks["pages"],
                          konteks["serial"])

    def db_hantar():
        """Laluan DB segar. `peringkat_hantar` perlukan LAJUR
        statushantar, bukan kiraan baris — memberinya kiraan ialah
        pepijat yang menjadikan H-001/002/003 sentiasa 'lulus'."""
        return tarik_db(serial, os.path.join(AKAR, "data", "tmp",
                                             "run_penuh.db"))

    def db_status():
        return FC.kira_rekod(db_hantar())

    ko = {"drv": drv, "pages": pages, "serial": serial, "izin": izin,
          "nombor": [r["no_rekod"] for r in rekod_log.baca_semua()
                     if r.get("no_rekod")],
          "db_status": db_status, "db_hantar": db_hantar}

    # >>> JURANG NK DILAPORKAN, BUKAN DIDIAMKAN. <<<
    # Skrin Notis Kompaun DICOVER — `peringkat_tarik` masuk melaluinya.
    # Yang tidak dicover ialah penukaran notis->kompaun di sebalik butang
    # [KOMPAUN], kerana ia memerlukan notis yang SUDAH luput tempoh.
    #
    # Tanpa baris ini, larian tamat tanpa menyebut NK langsung, dan
    # pembaca laporan menganggap menu itu lulus sepenuhnya.
    lapor_kelayakan_nk(serial)

    hasil, lulus, gagal = [], 0, 0
    for nama, fn in (("senarai", RM.peringkat_senarai),
                     ("hantar", RM.peringkat_hantar),
                     ("tarik", RM.peringkat_tarik)):
        bersihkan_skrin(drv, pages, nama)
        try:
            hasil.append(f"{nama}={fn(ko)}")
            lulus += 1
        except Exception as e:                                  # noqa: BLE001
            hasil.append(f"{nama}=GAGAL({type(e).__name__})")
            gagal += 1
    # Agregat yang berbohong — sama seperti bug `selaras LULUS` pada
    # larian pertama. Kalau semua anak gagal, peringkat ini GAGAL.
    ringkas = f"{lulus} lulus, {gagal} gagal — " + "; ".join(
        str(h)[:44] for h in hasil)
    if lulus == 0:
        raise RuntimeError(f"SEMUA peringkat menu gagal — {ringkas}")
    return ringkas


if __name__ == "__main__":
    sys.exit(main())

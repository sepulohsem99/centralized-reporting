"""
Kemaskini (record update) flow — Page Object Model. v3-new (Phase 2).

Flow confirmed via live recon (2026-07-16, dumps in ui_dumps/):
  Senarai row tap -> "KEMASKINI DATA" popup (record fields as TextViews,
  X close = content-desc U+2715, KEMASKINI + CETAK buttons, all
  content-desc) -> KEMASKINI -> "SILA ISI KETERANGAN" popup (EditText
  'ISI KEMASKINI KETERANGAN' + SETERUSNYA) -> full-screen
  "KEMASKINI <jenis>" edit form with the old data pre-filled in
  EditTexts.

KNOWN LIMITATION (confirmed via recon rounds 4/5 and the dedicated
scroll-crack recon): the edit form does not respond to ANY scroll
gesture (raw swipes, mobile: scroll/swipeGesture -- element-anchored or
not -- W3C slow drags, UiScrollable). The only technique that moves its
viewport is keyboard-focus traversal (tap an EditText, then TAB /
keycode 61), and that stalls after the Kesalahan address block. So this
flow updates the fields it can genuinely reach -- the Kesalahan address
block, which is exactly what the Kemaskini sheets change most -- and
logs clearly when a below-the-fold field (lokasi/butiran/tempoh/kod
dropdowns) could not be reached.

PORT MBJB — HAD DI ATAS BELUM DISAHKAN UNTUK 2.1.33
---------------------------------------------------
Had "borang Kemaskini tidak boleh diskrol" datang dari APK 2.1.17. MBJB
oracle ialah 2.1.33, 16 keluaran kemudian, dan DEV FIXING LIST baris 30
merekod satu pembaikan UI Kemaskini (DONE). Teknik traversal TAB/DPAD
DIKEKALKAN kerana ia selamat pada kedua-dua keadaan, tetapi ia bukan lagi
fakta yang terbukti untuk MBJB.

# SAHKAN-DEVICE: cuba SWIPE biasa pada borang Kemaskini MBJB DAHULU. Kalau
# ia bergerak, had ini sudah tiada dan medan bawah (lokasi/butiran/tempoh/
# dropdown kod) boleh dicapai -- laporkan supaya kaedah ini dipermudah.
# Nota berkaitan: Training Feedback K10 menyatakan borang Kemaskini MBJB
# TIADA ciri copy alamat -- jangan cari checkbox salin alamat di sini.
# Nota risiko: DEV FIXING LIST baris 75 (status NEW) mencatat "kemaskini
# notis amaran tidak berjaya hantar dan data ralat" pada V2.1.29 tanpa
# fix. N-004 ialah calon kegagalan yang diketahui -- kalau ia gagal, itu
# penemuan, bukan sesuatu untuk dilonggarkan.
"""

from appium.webdriver.common.appiumby import AppiumBy
from selenium.common.exceptions import TimeoutException
from pages.base_page import BasePage
# C-15 — satu salinan sahaja bagi isyarat tunggu "SEDANG DIPROSES".
# Ia hidup dalam senarai_page.py kerana base_page.py ialah SALIN BULAT dan
# tiada fail pages/ baharu boleh dicipta (R2).
from pages.senarai_page import tunggu_selesai_diproses as senarai_tunggu


class KemaskiniPage(BasePage):
    """Record popup + kemaskini edit-form flow (reached from Senarai)."""

    POPUP_TITLE = (AppiumBy.ANDROID_UIAUTOMATOR,
                   'new UiSelector().textMatches("(?i)\s*KEMASKINI\s+DATA\s*")')
    BUTTON_KEMASKINI = (AppiumBy.ANDROID_UIAUTOMATOR,
                         'new UiSelector().descriptionMatches("(?i)\s*KEMASKINI\s*")')
    POPUP_X = (AppiumBy.ACCESSIBILITY_ID, "✕")
    KETERANGAN_FIELD = (AppiumBy.ANDROID_UIAUTOMATOR,
                        'new UiSelector().textMatches("(?i).*ISI\s+KEMASKINI.*")')
    BUTTON_SETERUSNYA_ACC = (AppiumBy.ANDROID_UIAUTOMATOR,
                         'new UiSelector().descriptionMatches("(?i)\s*SETERUSNYA\s*")')

    def _dump(self, name):
        try:
            import os
            os.makedirs("ui_dumps", exist_ok=True)
            path = os.path.join("ui_dumps", name)
            with open(path, "w", encoding="utf-8") as f:
                f.write(self.driver.page_source)
            print(f"  [KEMASKINI] DEBUG: page source dumped to {path}")
            return path
        except Exception:
            return "(dump failed)"

    # ------------------------------------------------------------------
    # Step 1: verify old data on the record popup
    # ------------------------------------------------------------------

    def verify_record_popup(self, old_values):
        """On the just-opened KEMASKINI DATA popup, assert each expected
        old value is displayed (sheet step 1: 'Verify that all existing
        data displayed matches the previously saved information').

        Skrol-dan-cari, bukan hanya semak-tanpa-skrol. Popup ini BOLEH
        diskrol (pages/serah_page.py: kandungannya TextViews, sapuan biasa
        berkesan) dan medan boleh berada DI BAWAH LIPATAN -- persis dapatan
        induk 2026-07-31 (recon/PAPAN.md 'MULA DI SINI'): uiautomator
        MEMBUANG node visible:false, jadi "tidak dijumpai" BUKAN bukti
        "tiada". is_element_present() TIDAK skrol; find_element() (base_page)
        skrol-dan-cuba-semula sebelum mengalah, jadi ia digunakan di sini
        supaya medan lama yang sebenarnya wujud tetapi belum dirender tidak
        dilaporkan sebagai 'missing' secara palsu."""
        assert self.is_element_present(self.POPUP_TITLE, timeout=10), \
            "KEMASKINI DATA popup not displayed after tapping the record"
        missing = []
        for key, value in old_values.items():
            loc = (AppiumBy.ANDROID_UIAUTOMATOR,
                   f'new UiSelector().textContains("{value}")')
            try:
                self.find_element(loc, timeout=3)
                print(f"  [KEMASKINI] old {key} '{value}' displayed — PASS")
            except TimeoutException:
                missing.append((key, value))
        if missing:
            path = self._dump("kemaskini_old_data_missing.xml")
            raise AssertionError(
                f"Old data not displayed on the record popup: {missing}; "
                f"see {path}")

    # ------------------------------------------------------------------
    # Step 2: KEMASKINI -> keterangan popup -> edit form
    # ------------------------------------------------------------------

    def start_kemaskini(self, keterangan):
        """Tap KEMASKINI (verified), fill the SILA ISI KETERANGAN popup,
        SETERUSNYA to the edit form.

        `keterangan` WAJIB dan mesti datang dari TC_DATA (medan
        `keterangan_kemaskini`, didaftarkan dalam
        excel_data.BLANK_BY_DESIGN). TIADA default: default lama
        "KEMASKINI VIA AUTOMATION" ialah nilai rekaan yang tidak
        kelihatan oleh tools/check_vs_excel.py — PERATURAN KERAS #5."""
        if not str(keterangan or "").strip():
            raise AssertionError(
                "start_kemaskini() perlu keterangan dari TC_DATA "
                "['keterangan_kemaskini']; jangan reka nilai di sini")
        import time
        print("  [KEMASKINI] Tapping KEMASKINI...")
        for attempt in range(3):
            el = self.find_element(self.BUTTON_KEMASKINI, timeout=10)
            self.tap_element(el)
            time.sleep(1.5)
            if self.is_element_present(self.KETERANGAN_FIELD, timeout=5):
                break
            print(f"  [KEMASKINI] Keterangan popup didn't open "
                  f"(attempt {attempt + 1}/3) -- re-tapping...")
        else:
            path = self._dump("kemaskini_keterangan_missing.xml")
            raise TimeoutException(
                f"SILA ISI KETERANGAN popup never opened; see {path}")

        print(f"  [KEMASKINI] Entering keterangan: {keterangan}")
        el = self.find_element(self.KETERANGAN_FIELD, timeout=5)
        el.click()
        el.clear()
        # >>> DIBETULKAN 2026-08-04 — DIUKUR, kategori A. <<<
        # Bentuk lama memanggil `mobile: type` TERUS. Pada medan ini ia
        # MERANAPKAN app ke skrin merah RN. Empat varian diuji pada rekod
        # yang sama, app dilancar semula antara setiap satu:
        #     A. mobile: type  "blank dari test script"  -> REDBOX
        #     B. mobile: type  "AB"                      -> OK
        #     C. send_keys     "blank dari test script"  -> OK
        #     D. send_keys     "AB"                      -> OK
        # Teks yang SAMA lulus melalui send_keys (C), jadi puncanya bukan
        # teks itu — hanya `mobile: type` dengan rentetan panjang. Ini
        # kaedah KITA, bukan bug app. Jangan laporkan kepada MBJB.
        #
        # `_emit_text(el, nilai, use_mobile_type=False)` sudah melakukan
        # perkara yang betul: send_keys dahulu, `mobile: type` hanya
        # sebagai fallback untuk medan bertopeng/berangka yang menolak
        # send_keys. Baris lama memintas helper itu sepenuhnya.
        self._emit_text(el, keterangan, False)
        # keep_keyboard semantics: this is a dismissible RN modal --
        # hide_keyboard can act like Back and close the whole popup
        # (bit us live: SETERUSNYA 'not found' because the popup was
        # gone). Only hide as a fallback if the button can't be seen.
        time.sleep(0.5)

        # >>> DIBETULKAN 2026-08-04 — PEMBAIKAN N-004. <<<
        #
        # Bentuk lama: cari SETERUSNYA; kalau gagal -> panggil
        # `_hide_keyboard_if_shown()` -> semak popup -> "got dismissed"
        # -> cuba tap KEMASKINI semula. Diukur pada device, ia gagal
        # begini:
        #     [KEMASKINI] Tapping SETERUSNYA...
        #     [KEMASKINI] keterangan popup got dismissed -- reopening...
        #     TimeoutException: ('accessibility id', 'SETERUSNYA')
        #     TimeoutException: ('accessibility id', 'KEMASKINI')
        #
        # PUNCA: `_hide_keyboard_if_shown()` -> `driver.hide_keyboard()`
        # -> Back pada Android -> ia MENUTUP modal RN ini. Popup tidak
        # "got dismissed" dengan sendirinya; PEMULIHAN KITA yang
        # menutupnya, lalu menyalahkan app. Docstring kaedah ini di atas
        # sudah memberi amaran tepat itu ("hide_keyboard can act like
        # Back and close the whole popup"), tetapi cabang pemulihan tetap
        # memanggilnya. Selepas modal hilang, butang KEMASKINI juga
        # hilang (kita bukan lagi pada popup rekod), jadi "reopen" mesti
        # gagal — kegagalan kedua itu ialah gema kegagalan pertama.
        #
        # Baharu: tutup IME dengan editor action (BUKAN Back), kemudian
        # cari SETERUSNYA TANPA skrol — borang tidak boleh diskrol semasa
        # IME terbuka, dan `find_element` biasa akan membuang masa
        # menyapu sebelum mengalah.
        print("  [KEMASKINI] Tapping SETERUSNYA...")
        self.tutup_ime_tanpa_back()
        time.sleep(0.6)

        from config import IMPLICIT_WAIT
        el = None
        for cubaan in range(3):
            self.driver.implicitly_wait(0)
            try:
                calon = self.driver.find_elements(
                    *self.BUTTON_SETERUSNYA_ACC)
            finally:
                self.driver.implicitly_wait(IMPLICIT_WAIT)
            if calon:
                el = calon[0]
                break
            self.tutup_ime_tanpa_back()
            time.sleep(1.0)

        if el is None:
            # JANGAN mengandaikan "popup ditutup". Ukur dahulu, dan
            # laporkan keadaan SEBENAR — dua sebab ini memerlukan
            # pembetulan yang berbeza sepenuhnya.
            popup_ada = self.is_element_present(self.KETERANGAN_FIELD,
                                                timeout=2)
            path = self._dump("kemaskini_seterusnya_hilang.xml")
            raise TimeoutException(
                "SETERUSNYA tidak dijumpai pada popup SILA ISI "
                "KETERANGAN selepas menaip dan menutup IME tanpa Back. "
                f"popup keterangan MASIH ADA: {popup_ada}. "
                + ("Popup ada, jadi ini kegagalan LOCATOR SETERUSNYA — "
                   "bukan modal yang tertutup."
                   if popup_ada else
                   "Popup TIADA. Kali ini ia bukan disebabkan "
                   "hide_keyboard kita (sudah dibuang), jadi sesuatu "
                   "yang lain menutupnya — siasat sebelum menambah "
                   "sebarang cubaan semula.")
                + f" Dump: {path}")

        self.tap_element(el)
        time.sleep(2.5)

    def is_edit_form_open(self, jenis_title_fragment):
        """The edit form's appbar title is 'KEMASKINI <jenis>' (confirmed
        for Notis Amaran via recon)."""
        loc = (AppiumBy.ANDROID_UIAUTOMATOR,
               f'new UiSelector().textMatches("(?i).*KEMASKINI.*")'
               f'.textContains("{jenis_title_fragment}")')
        # UiSelector chains textContains AND-style only on one call each;
        # fall back to just KEMASKINI-prefix title check.
        if self.is_element_present(loc, timeout=5):
            return True
        loc2 = (AppiumBy.ANDROID_UIAUTOMATOR,
                'new UiSelector().textStartsWith("KEMASKINI ")')
        return self.is_element_present(loc2, timeout=5)

    # ------------------------------------------------------------------
    # Step 3: update fields on the edit form
    # ------------------------------------------------------------------

    def _edit_field_holding(self, old_text, new_text, label):
        """Find the EditText currently holding old_text, clear it, type
        new_text, and verify the value landed. Returns True on success."""
        loc = (AppiumBy.ANDROID_UIAUTOMATOR,
               f'new UiSelector().className("android.widget.EditText")'
               f'.text("{old_text}")')
        try:
            el = self.find_element(loc, timeout=6)
        except TimeoutException:
            print(f"  [KEMASKINI] WARNING: no EditText holding "
                  f"{old_text!r} for {label} -- skipping")
            return False
        el.click()
        el.clear()
        # send_keys DAHULU (dasar 2026-08-04). Laluan Kemaskini ialah
        # laluan yang MEMANG meranap pada 'r'; membaiki start_kemaskini()
        # sahaja meninggalkan tapak ini hidup dengan nilai testdata penuh.
        self._emit_text(el, new_text, False)
        self._hide_keyboard_if_shown()
        import time
        time.sleep(0.5)
        check = (AppiumBy.ANDROID_UIAUTOMATOR,
                 f'new UiSelector().className("android.widget.EditText")'
                 f'.textContains("{new_text}")')
        ok = self.is_element_present(check, timeout=3)
        print(f"  [KEMASKINI] {label}: {old_text!r} -> {new_text!r} "
              f"{'— PASS' if ok else '(could not verify)'}")
        return True

    def update_kesalahan_address(self, old_jalan, data):
        """Update the reachable Kesalahan address block: jalan (located
        by its old value from the create), then taman/poskod right under
        it (located positionally as the following EditTexts -- their old
        values can be auto-fill artifacts, so position beats text here).

        The jalan field on this form may be an autocomplete like the
        create form's: if a suggestion list renders after typing, the
        matching row is picked."""
        import time
        self._dump("kemaskini_edit_form_before.xml")

        changed = self._edit_field_holding(old_jalan,
                                           data["kesalahan_jalan"],
                                           "kesalahan jalan")
        if changed:
            row = (AppiumBy.ANDROID_UIAUTOMATOR,
                   f'new UiSelector().className("android.widget.TextView")'
                   f'.textContains("{data["kesalahan_jalan"]}")')
            if self.is_element_present(row, timeout=4):
                try:
                    el = self.find_element(row, timeout=3)
                    self.tap_element(el)
                    print("  [KEMASKINI] Picked jalan suggestion row")
                    time.sleep(1.5)
                except Exception:
                    pass

        # taman/poskod: the two EditTexts following the (now updated)
        # jalan field under the MAKLUMAT KESALAHAN header.
        xpath = ('//android.widget.TextView[@text="MAKLUMAT KESALAHAN"]'
                 '/following-sibling::android.widget.EditText')
        try:
            els = self.driver.find_elements(AppiumBy.XPATH, xpath)
        except Exception:
            els = []
        if len(els) >= 2:
            for idx, key in ((1, "kesalahan_taman"), (2, "kesalahan_poskod")):
                if idx >= len(els):
                    break
                # type-verify-retry: confirmed live (v3 shakedown) that
                # a typed value can silently fail to stick on this form
                # (the RN re-render triggered by clear() swallows the
                # keystrokes racing it -- same failure mode as Kadar
                # Denda on the create form).
                for attempt in range(3):
                    try:
                        els = self.driver.find_elements(AppiumBy.XPATH,
                                                        xpath)
                        el = els[idx]
                        current = el.text
                        if current == data[key]:
                            print(f"  [KEMASKINI] {key} holds "
                                  f"'{data[key]}' — PASS")
                            break
                        el.click()
                        el.clear()
                        time.sleep(0.3)
                        self._emit_text(el, data[key], False)
                        self._hide_keyboard_if_shown()
                        time.sleep(0.5)
                    except Exception as e:
                        print(f"  [KEMASKINI] WARNING: {key} update "
                              f"attempt {attempt + 1} failed "
                              f"({type(e).__name__})")
                else:
                    print(f"  [KEMASKINI] WARNING: {key} never verified "
                          f"as {data[key]!r}")
        else:
            print("  [KEMASKINI] WARNING: MAKLUMAT KESALAHAN sibling "
                  "EditTexts not found -- taman/poskod left as-is")

        self._dump("kemaskini_edit_form_after.xml")

    # ------------------------------------------------------------------
    # Step 4: proceed (Seterusnya) and submit
    # ------------------------------------------------------------------

    def _reveal_below_fold(self, target_locator, max_tabs=25):
        """Focus traversal (see BasePage.reveal_below_fold -- promoted
        there in Phase 3 since the Notis-to-Kompaun form needs it too)."""
        return self.reveal_below_fold(target_locator, max_tabs=max_tabs)

    def proceed_and_submit(self):
        """Find SETERUSNYA (may be below the fold -> focus traversal),
        tap it, then drive whatever follows to submission: any further
        SETERUSNYA screens, MENYERAHKAN, the 'Simpan maklumat' HANTAR
        popup, and result alerts. Dump-driven at each unknown."""
        import time
        if not self.is_element_present(self.BUTTON_SETERUSNYA_ACC,
                                       timeout=3):
            print("  [KEMASKINI] SETERUSNYA below the fold -- focus "
                  "traversal...")
            if not self._reveal_below_fold(self.BUTTON_SETERUSNYA_ACC):
                # >>> TATAL KONTENA, BUKAN TRAVERSAL — 2026-08-18. <<<
                # Traversal fokus tersekat pada borang edit ini, tetapi
                # borang itu MEMANG boleh ditatal: dump
                # ui_dumps/kemaskini_no_seterusnya.xml menunjukkan DUA
                # node `scrollable=true`, dan yang luar ialah
                # `ScrollView [0,276][1080,2316]` — ScrollView halaman.
                #
                # Kandungan berakhir pada y=2316 dengan medan terakhir
                # yang kelihatan; SETERUSNYA berada di bawahnya. Jadi ia
                # bukan "form resists scrolling" seperti mesej lama
                # dakwa — traversal sahaja yang tidak sampai.
                #
                # `.instance(0)` menyasarkan ScrollView LUAR. Tiada
                # modal terbuka pada titik ini, jadi amaran
                # base_page.py:3006 (yang dirakam dengan modal dropdown
                # TERBUKA) tidak terpakai di sini.
                # >>> CARI YANG MEMANG WUJUD, BUKAN YANG TIADA. <<<
                # Percubaan pertama menyuruh scrollIntoView mencari
                # SETERUSNYA — butang yang TIDAK WUJUD pada borang ini.
                # Ia menatal habis, gagal, dan kadang-kadang meninggalkan
                # borang di kedudukan asal. Larian 2026-08-18 10:13
                # menunjukkan dump bahagian ATAS borang, bukan bawah.
                #
                # MENYERAHKAN memang wujud (dump larian 09:45), jadi
                # tatal ke SITU. scrollIntoView berhenti sebaik ia
                # menemuinya.
                from appium.webdriver.common.appiumby import AppiumBy
                try:
                    self.driver.find_element(
                        AppiumBy.ANDROID_UIAUTOMATOR,
                        'new UiScrollable(new UiSelector().scrollable(true)'
                        '.instance(0)).scrollIntoView('
                        'new UiSelector().descriptionMatches('
                        '"(?i)\s*MENYERAHKAN\s*"));')
                    print("  [KEMASKINI] MENYERAHKAN didedahkan melalui "
                          "scrollIntoView kontena")
                except Exception as e:                       # noqa: BLE001
                    print(f"  [KEMASKINI] scrollIntoView MENYERAHKAN gagal "
                          f"({type(e).__name__})")

                if self.is_element_present(self.BUTTON_MENYERAHKAN,
                                           timeout=3):
                    print("  [KEMASKINI] tiada SETERUSNYA pada borang ini "
                          "— MENYERAHKAN hadir, terus ke serah")
                    ada_seterusnya = False
                else:
                    path = self._dump("kemaskini_no_seterusnya.xml")
                    raise TimeoutException(
                        f"SETERUSNYA MAHUPUN MENYERAHKAN tidak dijumpai "
                        f"pada borang edit; lihat {path}")
            else:
                ada_seterusnya = True
        else:
            ada_seterusnya = True

        if ada_seterusnya:
            el = self.find_element(self.BUTTON_SETERUSNYA_ACC, timeout=5)
            self.tap_element(el)
            print("  [KEMASKINI] SETERUSNYA tapped")
            time.sleep(2.5)
            self._dump("kemaskini_after_seterusnya.xml")

        # Drive to submission, tolerating flow-shape differences.
        menyerahkan = self.BUTTON_MENYERAHKAN
        for _ in range(4):
            if self.is_element_present(self.POPUP_SIMPAN_MAKLUMAT_LOC,
                                       timeout=3):
                print("  [KEMASKINI] 'Simpan maklumat' popup -- HANTAR")
                el = self.find_clickable(self.BUTTON_HANTAR)
                self.tap_element(el)
                break
            if self.is_element_present(menyerahkan, timeout=3):
                print("  [KEMASKINI] MENYERAHKAN visible -- tapping")
                self._hide_keyboard_if_shown()
                el = self.find_clickable(menyerahkan)
                self.tap_element(el)
                time.sleep(2)
                continue
            if self.is_element_present(self.BUTTON_SETERUSNYA_ACC,
                                       timeout=3):
                print("  [KEMASKINI] another SETERUSNYA -- tapping")
                el = self.find_element(self.BUTTON_SETERUSNYA_ACC,
                                       timeout=3)
                self.tap_element(el)
                time.sleep(2)
                continue
            break

        # C-15 — HANTAR boleh memunculkan overlay sibuk. Tunggu ia HILANG
        # (isyarat sebenar) sebelum mengharapkan alert keputusan; sleep
        # tetap sama ada terlalu pendek atau membazir masa run.
        senarai_tunggu(self, tag="KEMASKINI")
        found = self.dismiss_native_alerts(first_timeout=20,
                                           context="kemaskini submit")
        if found:
            print("  [KEMASKINI] Submission result alert dismissed")
        time.sleep(1)

    POPUP_SIMPAN_MAKLUMAT_LOC = (AppiumBy.ANDROID_UIAUTOMATOR,
                                 'new UiSelector().textContains('
                                 '"Simpan maklumat")')

    # ------------------------------------------------------------------
    # Step 5: verify the update landed
    # ------------------------------------------------------------------

    def verify_updated(self, senarai_page, jenis_letter, new_value,
                       no_rekod, before_numbers=None,
                       created_records=None):
        """Buka semula popup rekod IKUT NOMBOR dan sahkan nilai baharu
        dipaparkan. Pulang nombor rekod yang DISAHKAN dikemaskini
        (== `no_rekod` pada Laluan A, nombor BAHARU pada Laluan B).

        TANDATANGAN KONTRAK (§1.4) — apa yang lima fail test `-004` MESTI
        panggil (bahagian Mustaqim; JANGAN ubah di sini tanpa R4):

            no_baharu = pages.kemaskini.verify_updated(
                pages.senarai, JENIS, data["kesalahan_jalan"],
                no_rekod=no,                     # WAJIB, positional-ok
                before_numbers=before,           # C-4b, Laluan B
                created_records=created_records)  # C-4b, kemas kini lejar

        `before` ditangkap SEBELUM start_kemaskini():
            before = pages.senarai.numbers_for_jenis(JENIS)

        `before_numbers=None` mematikan Laluan B: nombor yang bertukar
        akan menjadi AssertionError yang jujur, bukan pemilihan rekod
        ikut kedudukan.

        PERATURAN KERAS #7. Versi asal memanggil
        `senarai_page.open_record_by_jenis(jenis_letter)`, iaitu pemilihan
        IKUT KEDUDUKAN (baris pertama jenis itu). Itu bug MBIP yang sama:
        kalau baris teratas ialah rekod BASI yang kebetulan mengandungi
        `new_value` -> PASS palsu; kalau tidak -> FAIL palsu pada
        kemaskini yang sebenarnya berjaya. Pemilihan ikut kedudukan
        DIBUANG sepenuhnya di sini.

        `no_rekod` WAJIB. `jenis_letter` dikekalkan untuk mesej diagnostik
        sahaja dan tidak lagi memilih apa-apa.

        # SAHKAN-DEVICE: adakah Kemaskini MBJB mengeluarkan NOMBOR REKOD
        # BAHARU? Bukti BERCANGGAH dan tiada satu pun disahkan pada
        # device (tiada rekod pernah dicipta di sini):
        #   Bukti A (docs\IES-MBJB ... V2.1.33, Actual Results C12 vs C9):
        #     N/K/L/S-004 nombor KEKAL; P-004 berubah — tetapi baris P-004
        #     mencurigakan sebagai salin-tampal basi (jenis `N` untuk TC
        #     `P`, awalan `JBM51` dari run September 2025).
        #   Bukti B (IES - DEV FIXING LIST, "KEMASKINI | LESEN DAN
        #     PELBAGAI", DONE): rekod lama ditetapkan status batal — itu
        #     hanya masuk akal kalau satu rekod BAHARU menggantikannya,
        #     dan modulnya PELBAGAI, tepat modul yang berlainan dalam A.
        # Kedua-dua laluan dikendalikan di bawah TANPA perlu tahu
        # jawapannya lebih awal dan TANPA pemilihan ikut kedudukan.
        """
        import time
        time.sleep(1)
        if not no_rekod:
            raise AssertionError(
                "verify_updated() dipanggil tanpa no_rekod. Pemilihan "
                "rekod ikut kedudukan DILARANG (PERATURAN KERAS #7). "
                "Kalau Kemaskini menjana nombor rekod BAHARU, hantar "
                "before_numbers=senarai.numbers_for_jenis(jenis) supaya "
                "nombor baharu dikesan melalui delta, bukan diteka.")

        # C-15 + C-4a — proceed_and_submit() berakhir dengan
        # dismiss_native_alerts() pada skrin yang TIDAK diketahui (borang
        # kemaskini, popup HANTAR, atau skrin utama). Kosongkan alert yang
        # BERATUR dahulu, kemudian TUNTUT kita benar-benar berada di
        # Senarai. Tanpa pengawal ini, open_record_by_number() menyapu 20
        # kali tanpa menjumpai apa-apa dan mesej di bawah menuduh perkara
        # yang SALAH ("kemaskini merosakkan rekod") sedangkan puncanya
        # kita cuma tidak berada di Senarai. Bandingkan laluan Cetak yang
        # betul: cetak_page._navigate_and_print() melakukan ketiga-tiganya
        # (Home -> open_senarai -> is_senarai_screen_displayed ->
        # ensure_records_listed).
        self.dismiss_native_alerts(first_timeout=2,
                                   context="kemaskini verify")
        senarai_tunggu(senarai_page, tag="KEMASKINI")
        if not senarai_page.is_senarai_screen_displayed():
            path = self._dump("kemaskini_verify_bukan_skrin_senarai.xml")
            raise AssertionError(
                f"verify_updated(): TIDAK berada pada skrin Senarai "
                f"selepas kemaskini. Pemanggil MESTI kembali ke skrin "
                f"utama dan membuka Senarai dahulu — pengesahan tidak "
                f"boleh mencari rekod pada skrin yang tidak diketahui, "
                f"kerana 'tidak dijumpai' dari skrin yang salah akan "
                f"dibaca sebagai 'kemaskini merosakkan rekod'. "
                f"Lihat {path}")
        assert senarai_page.ensure_records_listed(), \
            "verify_updated(): tiada baris dalam Senarai untuk disemak"

        # ---- Laluan A: nombor rekod KEKAL (jangkaan N/K/L/S) ----
        if senarai_page.open_record_by_number(no_rekod):
            self._assert_popup_shows(senarai_page, no_rekod, new_value)
            return no_rekod

        # ---- Laluan B: nombor rekod BERTUKAR (jangkaan P) ----
        # C-4b. Nombor baharu dikesan melalui DELTA snapshot, bukan
        # dengan mengambil "yang terakhir". Tiada Laluan C.
        if not before_numbers:
            path = self._dump("kemaskini_verify_no_rekod_hilang.xml")
            raise AssertionError(
                f"rekod {no_rekod} TIDAK dijumpai dalam Senarai selepas "
                f"kemaskini (jenis {jenis_letter}), dan `before_numbers` "
                f"tidak dibekalkan — jadi laluan 'nombor bertukar' tidak "
                f"dapat disemak. Dua kemungkinan, kedua-duanya penemuan: "
                f"(a) kemaskini menukar nombor rekod — hantar "
                f"before_numbers=senarai.numbers_for_jenis(jenis) yang "
                f"ditangkap SEBELUM start_kemaskini(); (b) kemaskini "
                f"merosakkan rekod. JANGAN ganti dengan pemilihan ikut "
                f"kedudukan. Lihat {path}")

        selepas = senarai_page.numbers_for_jenis(jenis_letter)
        baharu = sorted(set(selepas) - set(before_numbers))
        if not baharu:
            path = self._dump("kemaskini_verify_rekod_hilang_tanpa_ganti.xml")
            raise AssertionError(
                f"rekod {no_rekod} hilang dari Senarai dan TIADA rekod "
                f"baharu jenis {jenis_letter} muncul — kemaskini "
                f"KEHILANGAN rekod. Snapshot sebelum "
                f"({len(before_numbers)}) vs selepas ({len(selepas)}). "
                f"Lihat {path}")
        if len(baharu) > 1:
            path = self._dump("kemaskini_verify_nombor_baharu_kabur.xml")
            raise AssertionError(
                f"nombor baharu tidak jelas: {baharu} — enggan meneka "
                f"rekod mana yang dikemaskini (PERATURAN KERAS #7). "
                f"Lihat {path}")
        no_baharu = baharu[0]
        print(f"  [KEMASKINI] nombor rekod BERTUKAR: {no_rekod} -> "
              f"{no_baharu} (Laluan B, dikesan melalui delta snapshot)")
        if not senarai_page.open_record_by_number(no_baharu):
            path = self._dump("kemaskini_verify_baharu_tidak_dibuka.xml")
            raise AssertionError(
                f"nombor baharu {no_baharu} dikesan dalam snapshot tetapi "
                f"popupnya TIDAK dapat dibuka ikut nombor. Lihat {path}")
        self._assert_popup_shows(senarai_page, no_baharu, new_value)
        if created_records is not None:
            # TC hiliran mesti mengikut rekod HIDUP, bukan yang batal.
            created_records[jenis_letter.upper()] = no_baharu
            print(f"  [KEMASKINI] created_records[{jenis_letter.upper()!r}] "
                  f"dikemas kini kepada {no_baharu}")
        # SAHKAN-DEVICE: separuh lagi baris DEV FIXING LIST mendakwa rekod
        # LAMA ditetapkan status batal/`B`. JANGAN assert itu di sini
        # sebelum status itu DILIHAT pada device — ia bersambung dengan
        # P-007/K-007/L-007.
        print(f"  [KEMASKINI] BELUM DISAHKAN: status rekod lama "
              f"{no_rekod} (batal/'B'?) tidak disemak — lihat "
              f"P-007/K-007/L-007")
        return no_baharu

    def _assert_popup_shows(self, senarai_page, no_rekod, new_value):
        """Popup yang TERBUKA mesti (1) betul-betul popup rekod, (2) milik
        `no_rekod`, (3) memaparkan `new_value`. Melempar pada mana-mana
        satu gagal. Popup ditutup pada kedua-dua laluan supaya pemulihan
        mudah.

        (3) skrol-dan-cari, bukan hanya semak-tanpa-skrol. `new_value` di
        sini ialah medan alamat (kesalahan_jalan) yang duduk pertengahan/
        bawah popup rekod yang BOLEH diskrol (serah_page.py) -- risiko
        sebenar, bukan teori: kalau ia belum dirender pada kedudukan skrol
        semasa, is_element_present() melaporkan 'tiada' walaupun kemaskini
        BERJAYA, menjadikan kemaskini yang betul kelihatan GAGAL. Ini
        ORACLE ujian kertas (rantaian create->cetak->kertas bergantung
        padanya), jadi ia tidak boleh gagal kerana skrol semata-mata.
        find_element() (base_page) skrol-dan-cuba-semula sebelum mengalah;
        digunakan di sini menggantikan is_element_present()."""
        assert self.is_element_present(self.POPUP_TITLE, timeout=10), \
            "record popup did not reopen for post-update verification"
        assert senarai_page.record_popup_shows_number(no_rekod), \
            (f"popup yang terbuka BUKAN rekod {no_rekod} — pengesahan "
             f"pasca-kemaskini akan menguji rekod yang salah")
        loc = (AppiumBy.ANDROID_UIAUTOMATOR,
               f'new UiSelector().textContains("{new_value}")')
        try:
            self.find_element(loc, timeout=5)
            ok = True
        except TimeoutException:
            ok = False
        if not ok:
            path = self._dump("kemaskini_verify_failed.xml")
            # close the popup before failing so recovery is trivial
            self._close_popup()
            raise AssertionError(
                f"updated value {new_value!r} not displayed on the "
                f"record popup {no_rekod} after kemaskini; see {path}")
        print(f"  [KEMASKINI] {no_rekod}: updated value {new_value!r} "
              f"displayed — PASS")
        self._close_popup()

    def _close_popup(self):
        try:
            el = self.find_element(self.POPUP_X, timeout=3)
            self.tap_element(el)
        except Exception:                                    # noqa: BLE001
            pass
